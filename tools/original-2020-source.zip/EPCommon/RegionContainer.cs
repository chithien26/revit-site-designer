﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RegionContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class RegionContainer
{
  private string m_strRegionName;
  private Element m_RegionElement;
  private MeshTriangleList m_MeshTriangleList;

  public RegionContainer(string _strRegionName, Element _RegionElement)
  {
    this.m_strRegionName = _strRegionName;
    this.m_RegionElement = _RegionElement;
    this.m_MeshTriangleList = (MeshTriangleList) null;
  }

  public string RegionName
  {
    get => this.m_strRegionName;
    set => this.m_strRegionName = value;
  }

  public Element RegionElement
  {
    get => this.m_RegionElement;
    set => this.m_RegionElement = value;
  }

  public MeshTriangleList MeshTriangleList
  {
    get => this.m_MeshTriangleList;
    set => this.m_MeshTriangleList = value;
  }
}
