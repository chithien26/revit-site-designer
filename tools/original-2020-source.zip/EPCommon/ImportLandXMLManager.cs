﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ImportLandXMLManager
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ImportLandXMLManager : EPForm
{
  private Document m_CurrentDocument;
  private List<TopographySurface> m_ListOfTopoSurfaces = new List<TopographySurface>();
  private double m_dDistance;
  private double m_dHzDirection;
  private double m_dVzDirection;
  private double m_dSharedCoordAngle;
  private Eps_Point m_pBasePoint = new Eps_Point();
  private IContainer components;
  private GroupBox m_GroupBox;
  private Button m_CancelButton;
  private Button m_OKButton;
  private Button m_FilePickerButton;
  private TextBox m_FileNameTxtBox;
  private Label m_FileNameLbl;
  private CheckBox m_ImportSurfaceCheckbox;
  private CheckBox m_ImportAlignmentCheckBox;
  private Label m_ImportOptionsLbl;
  private Label m_ImportOptionLbl;
  private ComboBox m_ImportOptionCmbBox;

  public ImportLandXMLManager(Document _CurrentDocument)
  {
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDimportLandXML";
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_FileNameLbl.Text = EPShared.LocalRM.GetString("AMP_FileNameImportXMLDialog");
    this.Text = EPShared.LocalRM.GetString("ImportLandTitleString");
    this.m_GroupBox.Text = EPShared.LocalRM.GetString("ImportLandXMLString");
    this.m_ImportSurfaceCheckbox.Text = EPShared.LocalRM.GetString("Import_AMP_ToposurfacesInXMLImportXMLDialog");
    this.m_ImportAlignmentCheckBox.Text = EPShared.LocalRM.GetString("Import_AMP_AligmentsInXMLImportXMLDialog");
    this.m_ImportOptionLbl.Text = EPShared.LocalRM.GetString("AMP_PositioningDialog");
    this.m_ImportOptionCmbBox.Items.Add((object) EPShared.LocalRM.GetString("PositioningAutoCenterToCenter"));
    this.m_ImportOptionCmbBox.Items.Add((object) EPShared.LocalRM.GetString("PositioningAutoOriginToOrigin"));
    this.m_ImportOptionCmbBox.Items.Add((object) EPShared.LocalRM.GetString("PositioningManualCenter"));
    this.m_ImportOptionCmbBox.Items.Add((object) EPShared.LocalRM.GetString("PositioningUsePreviousValues"));
    this.m_ImportOptionCmbBox.Items.Add((object) EPShared.LocalRM.GetString("PositioningBySurveyPoints"));
    this.m_ImportOptionCmbBox.SelectedIndex = 0;
    this.m_CurrentDocument = _CurrentDocument;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty1 = string.Empty;
    this.GetDialogPosition();
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ImportLandXMLPositioning", ref empty1))
    {
      string empty2 = string.Empty;
      for (int index = 0; index < this.m_ImportOptionCmbBox.Items.Count; ++index)
      {
        if (this.m_ImportOptionCmbBox.Items[index] is string strA && string.Compare(strA, empty1, true) == 0)
        {
          this.m_ImportOptionCmbBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_ImportSurfaceCheckbox.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ImportLandXMLSurface", ref _nReturnValue))
      this.m_ImportSurfaceCheckbox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ImportAlignmentCheckBox.Checked = true;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ImportLandXMLAlignment", ref _nReturnValue))
      return;
    this.m_ImportAlignmentCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("ImportLandXMLPositioning", Convert.ToString(this.m_ImportOptionCmbBox.SelectedItem));
    ApplicationUtility.Settings.eplSetE_SetSetting("ImportLandXMLSurface", Convert.ToInt32(this.m_ImportSurfaceCheckbox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("ImportLandXMLAlignment", Convert.ToInt32(this.m_ImportAlignmentCheckBox.Checked));
  }

  private void m_FilePickerButton_Click(object sender, EventArgs e)
  {
    OpenFileDialog openFileDialog = new OpenFileDialog();
    openFileDialog.Filter = ApplicationUtility.GetString("XmlFilePickerFilter");
    openFileDialog.FilterIndex = 1;
    openFileDialog.RestoreDirectory = true;
    openFileDialog.Multiselect = false;
    if (openFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_FileNameTxtBox.Text = openFileDialog.FileName;
  }

  private void OKButtonClicked(object sender, EventArgs e)
  {
    if (!this.VerifyFileNameAndPath())
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidFileNameLocationMessageString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.SaveSettings();
      switch (this.GetCurrentLandXMLImportOptions())
      {
        case LandXMLImportOptions.ManualCenter:
          this.DialogResult = DialogResult.Retry;
          return;
        case LandXMLImportOptions.UsePreviousTranslation:
          if (ImportLandXMLClass.GetSiteComponentPlacementFamilyInstance(this.m_CurrentDocument, "", false) == null)
          {
            int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPreviousPositionAvailableMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.DialogResult = DialogResult.Cancel;
            return;
          }
          break;
      }
      int num3 = (int) this.ImportSurfaceAlignments();
    }
  }

  public DialogResult ImportSurfaceAlignments()
  {
    if (!this.m_ImportAlignmentCheckBox.Checked && !this.m_ImportSurfaceCheckbox.Checked)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoImportOptionsSelectedString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return DialogResult.Retry;
    }
    LandXMLParser _XMLParser = new LandXMLParser(this.m_FileNameTxtBox.Text);
    DialogResult dialogResult1 = DialogResult.Cancel;
    DialogResult dialogResult2 = DialogResult.Cancel;
    List<LandXMLSurface> _SelectedSurfacesList = new List<LandXMLSurface>();
    List<LandXMLAlignment> _SelectedAlignmentList = new List<LandXMLAlignment>();
    View _CurrentView = (View) null;
    EPTransactionContainer _TransactionContainer = new EPTransactionContainer(this.m_CurrentDocument);
    _TransactionContainer.Start(EPShared.LocalRM.GetString("ImportingToposurfaceString"));
    if (this.m_ImportSurfaceCheckbox.Checked)
    {
      using (LandXMLTypeList landXmlTypeList = new LandXMLTypeList(LandXMLElementType.Surface, this.m_CurrentDocument, _TransactionContainer, this.GetCurrentLandXMLImportOptions(), this.m_pBasePoint, _XMLParser))
      {
        if (!landXmlTypeList.InvalidXMLFile)
        {
          if (landXmlTypeList.ElementCount <= 0)
          {
            int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSurfacesInLandXMLString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
          }
          else
          {
            int num2 = (int) landXmlTypeList.ShowDialog();
            dialogResult1 = landXmlTypeList.DialogResult;
            if (dialogResult1 == DialogResult.OK)
              _SelectedSurfacesList = landXmlTypeList.SelectedSurfaceList;
          }
        }
        else
        {
          int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidXMLFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
      }
    }
    if (this.m_ImportAlignmentCheckBox.Checked)
    {
      using (LandXMLTypeList landXmlTypeList = new LandXMLTypeList(LandXMLElementType.Allignment, this.m_CurrentDocument, _TransactionContainer, this.GetCurrentLandXMLImportOptions(), this.m_pBasePoint, _XMLParser))
      {
        if (!landXmlTypeList.InvalidXMLFile)
        {
          if (landXmlTypeList.ElementCount <= 0 && !landXmlTypeList.HasSpiral)
          {
            int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoAlignmentInLandXMLString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
          }
          else if (landXmlTypeList.ElementCount > 0)
          {
            int num5 = (int) landXmlTypeList.ShowDialog();
            dialogResult2 = landXmlTypeList.DialogResult;
            if (dialogResult2 == DialogResult.OK)
            {
              _SelectedAlignmentList = landXmlTypeList.SelectedAlignmentList;
              _CurrentView = landXmlTypeList.CurrentView;
            }
          }
        }
        else
        {
          int num6 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidXMLFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
      }
    }
    if (dialogResult1 == DialogResult.OK || dialogResult2 == DialogResult.OK)
    {
      if (dialogResult1 == DialogResult.OK && _SelectedSurfacesList.Count > 0)
      {
        this.FindMinMaxForSelectedSurfaces(_XMLParser, _SelectedSurfacesList);
        for (int index = 0; index < _SelectedSurfacesList.Count; ++index)
          this.CreateAndReassignProposedOrBaseSurface(_TransactionContainer, _SelectedSurfacesList[index]);
      }
      if (dialogResult2 == DialogResult.OK)
      {
        if (_XMLParser != null)
        {
          ProgressBarForm ProgressFrm = (ProgressBarForm) null;
          for (int index = 0; index < _SelectedAlignmentList.Count; ++index)
          {
            LandXMLAlignment _CurrentAlignment = _SelectedAlignmentList[index];
            _XMLParser.ParseLandXMLAlignmentSegments(ref _CurrentAlignment, ref ProgressFrm, _SelectedAlignmentList.Count);
            _SelectedAlignmentList[index] = _CurrentAlignment;
          }
          if (ProgressFrm != null)
          {
            ProgressFrm.SetMaxValue();
            Thread.Sleep(300);
            ProgressFrm.Close();
          }
        }
        if (_SelectedSurfacesList.Count <= 0)
          this.FindMinMaxForSelectedAlignments(_SelectedAlignmentList);
        foreach (LandXMLAlignment _CurrentAlignment in _SelectedAlignmentList)
          this.CreateAlignment(_TransactionContainer, _CurrentAlignment, _CurrentView);
      }
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ImportLandXMLComponentsCompleteString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
      _TransactionContainer.Commit();
      this.DialogResult = DialogResult.OK;
      if (this.GetCurrentLandXMLImportOptions() == LandXMLImportOptions.UseSharedCoordinates)
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_CurrentDocument.PathName, "UseSharedElevation", 1);
    }
    if (_TransactionContainer.HasStarted())
      _TransactionContainer.Rollback();
    return dialogResult1 == DialogResult.OK || dialogResult2 == DialogResult.OK ? DialogResult.OK : DialogResult.Cancel;
  }

  private bool CheckSurfaceExists(string _strSurfaceName) => false;

  private void OnFocusLost(object sender, EventArgs e)
  {
    if (this.VerifyFileNameAndPath())
      return;
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidXMLFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
  }

  private bool VerifyFileNameAndPath()
  {
    if (string.IsNullOrEmpty(this.m_FileNameTxtBox.Text))
      return false;
    if (!string.IsNullOrEmpty(this.m_FileNameTxtBox.Text))
    {
      FileInfo fileInfo = new FileInfo(this.m_FileNameTxtBox.Text);
      if (File.Exists(this.m_FileNameTxtBox.Text) && string.Compare(fileInfo.Extension, ".xml", true) != 0)
      {
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Source")} {EPShared.LocalRM.GetString("NoXMLExtension")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    return true;
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnImportLandXMLClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private LandXMLImportOptions GetCurrentLandXMLImportOptions()
  {
    LandXMLImportOptions xmlImportOptions = LandXMLImportOptions.AutoCenterToCenter;
    if (string.Compare(this.m_ImportOptionCmbBox.Items[this.m_ImportOptionCmbBox.SelectedIndex].ToString(), EPShared.LocalRM.GetString("PositioningAutoCenterToCenter"), true) == 0)
      xmlImportOptions = LandXMLImportOptions.AutoCenterToCenter;
    else if (string.Compare(this.m_ImportOptionCmbBox.Items[this.m_ImportOptionCmbBox.SelectedIndex].ToString(), EPShared.LocalRM.GetString("PositioningAutoOriginToOrigin"), true) == 0)
      xmlImportOptions = LandXMLImportOptions.AutoOriginToOrigin;
    else if (string.Compare(this.m_ImportOptionCmbBox.Items[this.m_ImportOptionCmbBox.SelectedIndex].ToString(), EPShared.LocalRM.GetString("PositioningManualCenter"), true) == 0)
      xmlImportOptions = LandXMLImportOptions.ManualCenter;
    else if (string.Compare(this.m_ImportOptionCmbBox.Items[this.m_ImportOptionCmbBox.SelectedIndex].ToString(), EPShared.LocalRM.GetString("PositioningUsePreviousValues"), true) == 0)
      xmlImportOptions = LandXMLImportOptions.UsePreviousTranslation;
    else if (string.Compare(this.m_ImportOptionCmbBox.Items[this.m_ImportOptionCmbBox.SelectedIndex].ToString(), EPShared.LocalRM.GetString("PositioningBySurveyPoints"), true) == 0)
      xmlImportOptions = LandXMLImportOptions.UseSharedCoordinates;
    return xmlImportOptions;
  }

  private void FindMinMaxForSelectedSurfaces(
    LandXMLParser _XMLParser,
    List<LandXMLSurface> _SelectedSurfacesList)
  {
    LandXMLImportOptions xmlImportOptions = this.GetCurrentLandXMLImportOptions();
    if (_XMLParser != null)
    {
      int _nTotalPointCount = 0;
      for (int index = 0; index < _SelectedSurfacesList.Count; ++index)
        _nTotalPointCount += _SelectedSurfacesList[index].SurfacePointCount;
      ProgressBarForm ProgressFrm = (ProgressBarForm) null;
      for (int index = 0; index < _SelectedSurfacesList.Count; ++index)
      {
        LandXMLSurface selectedSurfaces = _SelectedSurfacesList[index];
        _XMLParser.ParseLandXMLSurfacePoints(ref selectedSurfaces, ref ProgressFrm, _nTotalPointCount);
        _SelectedSurfacesList[index] = selectedSurfaces;
      }
      if (ProgressFrm != null)
      {
        ProgressFrm.SetMaxValue();
        Thread.Sleep(300);
        ProgressFrm.Close();
      }
    }
    if (xmlImportOptions == LandXMLImportOptions.UsePreviousTranslation)
    {
      double _dDistance = 0.0;
      double _dHzDirection = 0.0;
      double _dVzDirection = 0.0;
      FamilyInstance placementFamilyInstance = ImportLandXMLClass.GetSiteComponentPlacementFamilyInstance(this.m_CurrentDocument, "", false);
      if (placementFamilyInstance == null)
        return;
      ImportLandXMLClass.FindPositioningParameters(placementFamilyInstance, ref _dDistance, ref _dHzDirection, ref _dVzDirection);
      this.m_dHzDirection = _dHzDirection;
      this.m_dVzDirection = _dVzDirection;
      this.m_dDistance = _dDistance;
    }
    else
    {
      Eps_Point epsPoint = new Eps_Point();
      if (xmlImportOptions == LandXMLImportOptions.ManualCenter)
      {
        epsPoint = this.m_pBasePoint;
      }
      else
      {
        ProjectPosition projectPosition = this.m_CurrentDocument.ActiveProjectLocation.GetProjectPosition(new XYZ());
        epsPoint.x = projectPosition.EastWest;
        epsPoint.y = projectPosition.NorthSouth;
        epsPoint.z = projectPosition.Elevation;
        this.m_dSharedCoordAngle = projectPosition.Angle;
      }
      if (xmlImportOptions == LandXMLImportOptions.UseSharedCoordinates)
      {
        EPShared.eplGeoE_CalcXYZToPolar(epsPoint, new Eps_Point(), ref this.m_dHzDirection, ref this.m_dVzDirection, ref this.m_dDistance);
      }
      else
      {
        Eps_Point pMinPnt = new Eps_Point();
        Eps_Point pMaxPnt = new Eps_Point();
        pMinPnt.x = double.MaxValue;
        pMaxPnt.x = double.MinValue;
        pMinPnt.y = double.MaxValue;
        pMaxPnt.y = double.MinValue;
        pMinPnt.z = double.MaxValue;
        pMaxPnt.z = double.MinValue;
        foreach (LandXMLSurface selectedSurfaces in _SelectedSurfacesList)
        {
          foreach (Eps_Point surfacePoint in selectedSurfaces.SurfacePoints)
            RevitGeometry.CalcMinMax(surfacePoint, ref pMinPnt, ref pMaxPnt);
        }
        Eps_Point _FirstPnt = new Eps_Point();
        _FirstPnt.x = (pMaxPnt.x + pMinPnt.x) / 2.0;
        _FirstPnt.y = (pMaxPnt.y + pMinPnt.y) / 2.0;
        _FirstPnt.z = (pMaxPnt.z + pMinPnt.z) / 2.0;
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, epsPoint, ref this.m_dHzDirection);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, epsPoint, ref this.m_dDistance);
      }
    }
  }

  private void FindMinMaxForSelectedAlignments(List<LandXMLAlignment> _SelectedAlignmentList)
  {
    LandXMLImportOptions xmlImportOptions = this.GetCurrentLandXMLImportOptions();
    if (xmlImportOptions == LandXMLImportOptions.UsePreviousTranslation)
    {
      double _dDistance = 0.0;
      double _dHzDirection = 0.0;
      double _dVzDirection = 0.0;
      FamilyInstance placementFamilyInstance = ImportLandXMLClass.GetSiteComponentPlacementFamilyInstance(this.m_CurrentDocument, "", false);
      if (placementFamilyInstance == null)
        return;
      ImportLandXMLClass.FindPositioningParameters(placementFamilyInstance, ref _dDistance, ref _dHzDirection, ref _dVzDirection);
      this.m_dHzDirection = _dHzDirection;
      this.m_dVzDirection = _dVzDirection;
      this.m_dDistance = _dDistance;
    }
    else
    {
      Eps_Point epsPoint = new Eps_Point();
      if (xmlImportOptions == LandXMLImportOptions.ManualCenter)
      {
        epsPoint = this.m_pBasePoint;
      }
      else
      {
        ProjectPosition projectPosition = this.m_CurrentDocument.ActiveProjectLocation.GetProjectPosition(new XYZ());
        epsPoint.x = projectPosition.EastWest;
        epsPoint.y = projectPosition.NorthSouth;
        epsPoint.z = projectPosition.Elevation;
        this.m_dSharedCoordAngle = projectPosition.Angle;
      }
      if (xmlImportOptions == LandXMLImportOptions.UseSharedCoordinates)
      {
        EPShared.eplGeoE_CalcXYZToPolar(epsPoint, new Eps_Point(), ref this.m_dHzDirection, ref this.m_dVzDirection, ref this.m_dDistance);
      }
      else
      {
        Eps_Point pMinPnt = new Eps_Point();
        Eps_Point pMaxPnt = new Eps_Point();
        pMinPnt.x = double.MaxValue;
        pMaxPnt.x = double.MinValue;
        pMinPnt.y = double.MaxValue;
        pMaxPnt.y = double.MinValue;
        pMinPnt.z = double.MaxValue;
        pMaxPnt.z = double.MinValue;
        foreach (LandXMLAlignment selectedAlignment in _SelectedAlignmentList)
        {
          Eps_Leg epsLeg1 = Eps_Leg.CopyLeg(this.CreateLegFromAlignment(LandXMLAlignment.CopyAlignment(selectedAlignment)));
          for (Eps_Leg epsLeg2 = epsLeg1; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
          {
            if (epsLeg2.Line != null)
              RevitGeometry.CalcMinMax(epsLeg2.Line.StartPnt, ref pMinPnt, ref pMaxPnt);
            else if (epsLeg2.Arc != null)
              RevitGeometry.CalcMinMax(epsLeg2.Arc.StartPnt, ref pMinPnt, ref pMaxPnt);
            if (epsLeg2.Next == null)
            {
              if (epsLeg2.Line != null)
                RevitGeometry.CalcMinMax(epsLeg2.Line.EndPnt, ref pMinPnt, ref pMaxPnt);
              else if (epsLeg2.Arc != null)
                RevitGeometry.CalcMinMax(epsLeg2.Arc.EndPnt, ref pMinPnt, ref pMaxPnt);
            }
          }
        }
        Eps_Point _FirstPnt = new Eps_Point();
        _FirstPnt.x = (pMaxPnt.x + pMinPnt.x) / 2.0;
        _FirstPnt.y = (pMaxPnt.y + pMinPnt.y) / 2.0;
        _FirstPnt.z = (pMaxPnt.z + pMinPnt.z) / 2.0;
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, epsPoint, ref this.m_dHzDirection);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, epsPoint, ref this.m_dDistance);
      }
    }
  }

  private TopographySurface AddSurfaceToDocument(
    EPTransactionContainer _TransactionContainer,
    LandXMLSurface _CurSurface)
  {
    TopographySurface _Surface = (TopographySurface) null;
    List<XYZ> xyzList = new List<XYZ>();
    this.ConvertLandXMLPntsToRevit(_CurSurface.SurfacePoints, ref xyzList);
    if (xyzList.Count > 0)
    {
      TopographySurfaceManagement.RemoveDuplicateXY(ref xyzList);
      _Surface = TopographySurface.Create(this.m_CurrentDocument, (IList<XYZ>) xyzList);
      this.m_CurrentDocument.Regenerate();
    }
    if (_Surface != null)
    {
      ((Element) _Surface)[(BuiltInParameter) -1006900]?.Set(_CurSurface.SurfaceName);
      Parameter parameter = ((Element) _Surface)[(BuiltInParameter) -1012100];
      if (parameter != null && _CurSurface.Phase != null)
      {
        ElementId id = ((Element) _CurSurface.Phase).Id;
        parameter.Set(id);
      }
      this.LoadLandXMLSurfaceFamily(_TransactionContainer, _Surface);
    }
    return _Surface;
  }

  private void LoadLandXMLSurfaceFamily(
    EPTransactionContainer _TransactionContainer,
    TopographySurface _Surface)
  {
    LandXMLImportOptions xmlImportOptions = this.GetCurrentLandXMLImportOptions();
    if (xmlImportOptions == LandXMLImportOptions.UseSharedCoordinates)
      return;
    string empty = string.Empty;
    FamilySymbol _FamilySymbol = (FamilySymbol) null;
    if (!RevitUtility.GetFullFamilyFilenameIfExist("LandXMLSurface Placement.rfa", ref empty))
      return;
    Family _Family = (Family) null;
    _TransactionContainer.BeginTransaction();
    RevitUtility.LoadFamily(this.m_CurrentDocument, empty, out _Family, true, ref _TransactionContainer);
    _TransactionContainer.EndTransaction();
    if (_Family != null && _Family.GetFamilySymbolIds() != null)
    {
      using (IEnumerator<ElementId> enumerator = _Family.GetFamilySymbolIds().GetEnumerator())
      {
        if (enumerator.MoveNext())
        {
          ElementId current = enumerator.Current;
          _FamilySymbol = ((Element) _Family).Document.GetElement(current) as FamilySymbol;
        }
      }
    }
    if (_FamilySymbol == null)
      return;
    if (!_FamilySymbol.IsActive)
      _FamilySymbol.Activate();
    FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(this.m_CurrentDocument, new XYZ(0.0, 0.0, 0.0), _FamilySymbol, (Element) _Surface, this.m_CurrentDocument.ActiveView.GenLevel, (StructuralType) 0, ref _TransactionContainer);
    Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
    if (parameter1 != null && !((APIObject) parameter1).IsReadOnly)
      parameter1.Set(((Element) _Surface).UniqueId);
    Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.PositioningMethodLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
      parameter2.Set(Convert.ToInt32((object) xmlImportOptions));
    Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PositionDistanceLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter3 != null && !((APIObject) parameter3).IsReadOnly)
      parameter3.Set(Convert.ToDouble(this.m_dDistance));
    Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.PositionHzDirectionLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter4 != null && !((APIObject) parameter4).IsReadOnly)
      parameter4.Set(Convert.ToDouble(this.m_dHzDirection));
    Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.PositionVzDirectionLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter5 == null || ((APIObject) parameter5).IsReadOnly)
      return;
    parameter5.Set(Convert.ToDouble(this.m_dVzDirection));
  }

  private void ConvertLandXMLPntsToRevit(List<Eps_Point> _AllPnts, ref List<XYZ> _RevitPntList)
  {
    _RevitPntList.Clear();
    foreach (Eps_Point allPnt in _AllPnts)
    {
      XYZ CurRevitPnt = new XYZ(allPnt.x, allPnt.y, allPnt.z);
      _RevitPntList.Add(this.ApplyTranslation(CurRevitPnt));
    }
  }

  private XYZ ApplyTranslation(XYZ CurRevitPnt)
  {
    return this.ApplyTranslation(new Eps_Point(CurRevitPnt)).XYZ;
  }

  private Eps_Point ApplyTranslation(Eps_Point CurRevitPnt)
  {
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    switch (this.GetCurrentLandXMLImportOptions())
    {
      case LandXMLImportOptions.AutoCenterToCenter:
      case LandXMLImportOptions.ManualCenter:
      case LandXMLImportOptions.UsePreviousTranslation:
      case LandXMLImportOptions.UseSharedCoordinates:
        Eps_Point _NewPnt = new Eps_Point();
        EPShared.eplGeoE_CalcPolarToXYZ(CurRevitPnt, this.m_dHzDirection, this.m_dVzDirection, this.m_dDistance, ref _NewPnt);
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), _NewPnt, ref _dDirection);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), _NewPnt, ref _dDistance);
        EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, _NewPnt.z), EPShared.eplGeoE_NormalizeRadians(_dDirection - this.m_dSharedCoordAngle), _dDistance, ref _NewPnt);
        return _NewPnt;
      default:
        return CurRevitPnt;
    }
  }

  private void CreateAndReassignProposedOrBaseSurface(
    EPTransactionContainer _TransactionContainer,
    LandXMLSurface _CurSurface)
  {
    _TransactionContainer.BeginTransaction();
    TopographySurface document = this.AddSurfaceToDocument(_TransactionContainer, _CurSurface);
    if (document != null && _CurSurface.OverwriteSurfaceID != string.Empty)
    {
      TopographySurfaceContainer _ProposedTopographySurfaceContainer = (TopographySurfaceContainer) null;
      TopographySurfaceContainer _BaseTopographySurfaceContainer = (TopographySurfaceContainer) null;
      FamilyInstance _ProposedPlacementFamilyInstance = (FamilyInstance) null;
      FamilyInstance _BasePlacementFamilyInstance = (FamilyInstance) null;
      TopographySurfaceManagement.FindBaseLandcaddTopographySurface(this.m_CurrentDocument, ref _BaseTopographySurfaceContainer, ref _BasePlacementFamilyInstance, ref _ProposedTopographySurfaceContainer, ref _ProposedPlacementFamilyInstance, _TransactionContainer);
      if (_ProposedTopographySurfaceContainer != null && _ProposedTopographySurfaceContainer.TopographySurface != null && _ProposedPlacementFamilyInstance != null && string.Compare(((Element) _ProposedTopographySurfaceContainer.TopographySurface).UniqueId, _CurSurface.OverwriteSurfaceID, true) == 0)
        ((Element) _ProposedPlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter)?.Set(((Element) document).UniqueId);
      if (_BaseTopographySurfaceContainer != null && _BaseTopographySurfaceContainer.TopographySurface != null && _BasePlacementFamilyInstance != null && string.Compare(((Element) _BaseTopographySurfaceContainer.TopographySurface).UniqueId, _CurSurface.OverwriteSurfaceID, true) == 0)
        ((Element) _BasePlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter)?.Set(((Element) document).UniqueId);
    }
    _TransactionContainer.EndTransaction();
  }

  private void MoveAlignment(Eps_Leg _CurrentLeg)
  {
    for (Eps_Leg epsLeg = _CurrentLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        epsLeg.Line.StartPnt = this.ApplyTranslation(epsLeg.Line.StartPnt);
        epsLeg.Line.EndPnt = this.ApplyTranslation(epsLeg.Line.EndPnt);
      }
      else if (epsLeg.Arc != null)
      {
        epsLeg.Arc.StartPnt = this.ApplyTranslation(epsLeg.Arc.StartPnt);
        epsLeg.Arc.EndPnt = this.ApplyTranslation(epsLeg.Arc.EndPnt);
        epsLeg.Arc.RadiusPnt = this.ApplyTranslation(epsLeg.Arc.RadiusPnt);
      }
    }
  }

  private void CreateAlignment(
    EPTransactionContainer _TransactionContainer,
    LandXMLAlignment _CurrentAlignment,
    View _CurrentView)
  {
    Eps_Leg epsLeg = Eps_Leg.CopyLeg(this.CreateLegFromAlignment(LandXMLAlignment.CopyAlignment(_CurrentAlignment)));
    if (epsLeg != null)
    {
      switch (this.GetCurrentLandXMLImportOptions())
      {
        case LandXMLImportOptions.AutoCenterToCenter:
        case LandXMLImportOptions.ManualCenter:
        case LandXMLImportOptions.UsePreviousTranslation:
        case LandXMLImportOptions.UseSharedCoordinates:
          this.MoveAlignment(epsLeg);
          break;
      }
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.InaccurateFailures.InaccurateLine);
      if (_CurrentView != null)
      {
        _TransactionContainer.BeginTransaction();
        RevitUtility.NewModelCurveArray(this.m_CurrentDocument, epsLeg, _CurrentView);
        _TransactionContainer.EndTransaction();
      }
    }
    this.DialogResult = DialogResult.OK;
  }

  private Eps_Leg CreateLegFromAlignment(LandXMLAlignment _CurrentAlignment)
  {
    List<Eps_Line> epsLineList = new List<Eps_Line>((IEnumerable<Eps_Line>) _CurrentAlignment.Lines);
    List<Eps_Arc> epsArcList = new List<Eps_Arc>((IEnumerable<Eps_Arc>) _CurrentAlignment.Curves);
    Eps_Leg _FirstLegList = this.FindStartingSegment(_CurrentAlignment);
    if (_FirstLegList == null)
    {
      _FirstLegList = new Eps_Leg();
      if (_CurrentAlignment.Lines.Count > 0)
      {
        _FirstLegList.Line = new Eps_Line(_CurrentAlignment.Lines[0]);
        epsLineList.RemoveAt(0);
      }
      else if (_CurrentAlignment.Curves.Count > 0)
      {
        _FirstLegList.Arc = new Eps_Arc(_CurrentAlignment.Curves[0]);
        epsArcList.RemoveAt(0);
      }
    }
    int index1 = -1;
    int index2 = -1;
    double maxValue = double.MaxValue;
    double num = double.MaxValue;
    bool flag = false;
    while (epsLineList.Count > 0 || epsArcList.Count > 0)
    {
      for (int index3 = epsLineList.Count - 1; index3 >= 0; --index3)
      {
        Eps_Line _CurrentLine = epsLineList[index3];
        if (Eps_Leg.InsertLineLegSegment(ref _FirstLegList, _CurrentLine))
        {
          epsLineList.RemoveAt(index3);
          flag = true;
        }
      }
      for (int index4 = epsArcList.Count - 1; index4 >= 0; --index4)
      {
        Eps_Arc _CurrentArc = epsArcList[index4];
        if (Eps_Leg.InsertArcLegSegment(ref _FirstLegList, _CurrentArc))
        {
          epsArcList.RemoveAt(index4);
          flag = true;
        }
      }
      if (!flag)
      {
        for (int index5 = epsLineList.Count - 1; index5 >= 0; --index5)
        {
          double distanceBetweenLegs = Eps_Leg.FindMinimumDistanceBetweenLegs(_FirstLegList, new Eps_Leg()
          {
            Line = epsLineList[index5]
          });
          if (distanceBetweenLegs < num)
          {
            num = distanceBetweenLegs;
            index1 = index5;
          }
        }
        for (int index6 = epsArcList.Count - 1; index6 >= 0; --index6)
        {
          double distanceBetweenLegs = Eps_Leg.FindMinimumDistanceBetweenLegs(_FirstLegList, new Eps_Leg()
          {
            Arc = epsArcList[index6]
          });
          if (distanceBetweenLegs < num)
          {
            num = distanceBetweenLegs;
            index2 = index6;
            index1 = -1;
          }
        }
        if (index1 >= 0)
        {
          Eps_Leg.CombineLegListsAtShortestGaps(ref _FirstLegList, new Eps_Leg()
          {
            Line = epsLineList[index1]
          });
          epsLineList.RemoveAt(index1);
          index1 = -1;
        }
        else if (index2 >= 0)
        {
          Eps_Leg.CombineLegListsAtShortestGaps(ref _FirstLegList, new Eps_Leg()
          {
            Arc = epsArcList[index2]
          });
          epsArcList.RemoveAt(index2);
          index2 = -1;
        }
        maxValue = double.MaxValue;
        num = double.MaxValue;
      }
      else
        flag = false;
    }
    return _FirstLegList;
  }

  private Eps_Leg FindStartingSegment(LandXMLAlignment _CurrentAlignment)
  {
    Eps_Line _Line = (Eps_Line) null;
    Eps_Leg startingSegment = (Eps_Leg) null;
    int index1 = -1;
    foreach (Eps_Line line in _CurrentAlignment.Lines)
    {
      ++index1;
      if (line.StartPnt.IsEqual(_CurrentAlignment.StartPoint))
      {
        _Line = line;
        break;
      }
      if (line.EndPnt.IsEqual(_CurrentAlignment.StartPoint))
      {
        _Line = line.Reverse();
        break;
      }
    }
    if (_Line != null)
    {
      startingSegment = new Eps_Leg();
      startingSegment.Line = new Eps_Line(_Line);
      _CurrentAlignment.Lines.RemoveAt(index1);
    }
    else
    {
      int index2 = -1;
      Eps_Arc _Arc = (Eps_Arc) null;
      foreach (Eps_Arc curve in _CurrentAlignment.Curves)
      {
        ++index2;
        if (curve.StartPnt.IsEqual(_CurrentAlignment.StartPoint))
        {
          _Arc = curve;
          break;
        }
        if (curve.EndPnt.IsEqual(_CurrentAlignment.StartPoint))
        {
          _Arc = curve.Reverse();
          break;
        }
      }
      if (_Arc != null)
      {
        startingSegment = new Eps_Leg();
        startingSegment.Arc = new Eps_Arc(_Arc);
        _CurrentAlignment.Curves.RemoveAt(index2);
      }
    }
    return startingSegment;
  }

  public Eps_Point ManualCenterBasePoint
  {
    get => this.m_pBasePoint;
    set => this.m_pBasePoint = value;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_GroupBox = new GroupBox();
    this.m_FilePickerButton = new Button();
    this.m_FileNameTxtBox = new TextBox();
    this.m_FileNameLbl = new Label();
    this.m_CancelButton = new Button();
    this.m_OKButton = new Button();
    this.m_ImportSurfaceCheckbox = new CheckBox();
    this.m_ImportAlignmentCheckBox = new CheckBox();
    this.m_ImportOptionsLbl = new Label();
    this.m_ImportOptionLbl = new Label();
    this.m_ImportOptionCmbBox = new ComboBox();
    this.m_GroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_GroupBox.Controls.Add((Control) this.m_FilePickerButton);
    this.m_GroupBox.Controls.Add((Control) this.m_FileNameTxtBox);
    this.m_GroupBox.Controls.Add((Control) this.m_FileNameLbl);
    this.m_GroupBox.Location = new Point(12, 12);
    this.m_GroupBox.Name = "m_GroupBox";
    this.m_GroupBox.Size = new Size(435, 51);
    this.m_GroupBox.TabIndex = 0;
    this.m_GroupBox.TabStop = false;
    this.m_GroupBox.Text = "groupBox1";
    this.m_FilePickerButton.Location = new Point(405, 19);
    this.m_FilePickerButton.Name = "m_FilePickerButton";
    this.m_FilePickerButton.Size = new Size(24, 20);
    this.m_FilePickerButton.TabIndex = 2;
    this.m_FilePickerButton.Text = "...";
    this.m_FilePickerButton.UseVisualStyleBackColor = true;
    this.m_FilePickerButton.Click += new EventHandler(this.m_FilePickerButton_Click);
    this.m_FileNameTxtBox.Location = new Point(88, 19);
    this.m_FileNameTxtBox.Name = "m_FileNameTxtBox";
    this.m_FileNameTxtBox.Size = new Size(311, 20);
    this.m_FileNameTxtBox.TabIndex = 1;
    this.m_FileNameLbl.AutoSize = true;
    this.m_FileNameLbl.Location = new Point(6, 23);
    this.m_FileNameLbl.Name = "m_FileNameLbl";
    this.m_FileNameLbl.Size = new Size(35, 13);
    this.m_FileNameLbl.TabIndex = 0;
    this.m_FileNameLbl.Text = "label1";
    this.m_CancelButton.Location = new Point(372, 154);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClicked);
    this.m_OKButton.Location = new Point(291, 154);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 3;
    this.m_OKButton.Text = "OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OKButtonClicked);
    this.m_ImportSurfaceCheckbox.AutoSize = true;
    this.m_ImportSurfaceCheckbox.Location = new Point(12, 69);
    this.m_ImportSurfaceCheckbox.Name = "m_ImportSurfaceCheckbox";
    this.m_ImportSurfaceCheckbox.Size = new Size(100, 17);
    this.m_ImportSurfaceCheckbox.TabIndex = 1;
    this.m_ImportSurfaceCheckbox.Text = "Import Surfaces";
    this.m_ImportSurfaceCheckbox.UseVisualStyleBackColor = true;
    this.m_ImportAlignmentCheckBox.AutoSize = true;
    this.m_ImportAlignmentCheckBox.Location = new Point(12, 92);
    this.m_ImportAlignmentCheckBox.Name = "m_ImportAlignmentCheckBox";
    this.m_ImportAlignmentCheckBox.Size = new Size(109, 17);
    this.m_ImportAlignmentCheckBox.TabIndex = 2;
    this.m_ImportAlignmentCheckBox.Text = "Import Alignments";
    this.m_ImportAlignmentCheckBox.UseVisualStyleBackColor = true;
    this.m_ImportOptionsLbl.AutoSize = true;
    this.m_ImportOptionsLbl.Location = new Point(12, 116);
    this.m_ImportOptionsLbl.Name = "m_ImportOptionsLbl";
    this.m_ImportOptionsLbl.Size = new Size(0, 13);
    this.m_ImportOptionsLbl.TabIndex = 5;
    this.m_ImportOptionLbl.AutoSize = true;
    this.m_ImportOptionLbl.Location = new Point(11, 119);
    this.m_ImportOptionLbl.Name = "m_ImportOptionLbl";
    this.m_ImportOptionLbl.Size = new Size(58, 13);
    this.m_ImportOptionLbl.TabIndex = 6;
    this.m_ImportOptionLbl.Text = "Positioning";
    this.m_ImportOptionCmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ImportOptionCmbBox.FormattingEnabled = true;
    this.m_ImportOptionCmbBox.Location = new Point(100, 116);
    this.m_ImportOptionCmbBox.Name = "m_ImportOptionCmbBox";
    this.m_ImportOptionCmbBox.Size = new Size(347, 21);
    this.m_ImportOptionCmbBox.TabIndex = 7;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(459, 183);
    this.Controls.Add((Control) this.m_ImportOptionLbl);
    this.Controls.Add((Control) this.m_ImportOptionCmbBox);
    this.Controls.Add((Control) this.m_ImportOptionsLbl);
    this.Controls.Add((Control) this.m_ImportAlignmentCheckBox);
    this.Controls.Add((Control) this.m_ImportSurfaceCheckbox);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_GroupBox);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(465, 182);
    this.Name = nameof (ImportLandXMLManager);
    this.Text = "Import LandXML";
    this.FormClosing += new FormClosingEventHandler(this.OnImportLandXMLClosing);
    this.m_GroupBox.ResumeLayout(false);
    this.m_GroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
