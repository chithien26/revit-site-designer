﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyLoadOptions
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class FamilyLoadOptions : IFamilyLoadOptions
{
  private bool m_bOverwriteParameterValues;

  public FamilyLoadOptions(bool _bOverwriteParameterValues)
  {
    this.m_bOverwriteParameterValues = _bOverwriteParameterValues;
  }

  public bool OnFamilyFound(bool _bFamilyInUse, out bool _bOverwriteParameterValues)
  {
    _bOverwriteParameterValues = false;
    if (_bFamilyInUse)
      _bOverwriteParameterValues = this.m_bOverwriteParameterValues;
    return true;
  }

  public bool OnSharedFamilyFound(
    Family _SharedFamily,
    bool _bFamilyInUse,
    out FamilySource _Source,
    out bool _bOverwriteParameterValues)
  {
    _bOverwriteParameterValues = false;
    // ISSUE: cast to a reference type
    // ISSUE: explicit reference operation
    ^(int&) ref _Source = 1;
    if (_bFamilyInUse)
      _bOverwriteParameterValues = this.m_bOverwriteParameterValues;
    return true;
  }
}
