﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.XmlEngine
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.Xml;

#nullable disable
namespace EPCommon;

public class XmlEngine
{
  private XmlTextReader m_XMLReader;
  private XmlElementInfo m_XMLData;
  private string m_strXMLFile = "";

  public void Read(string _strXMLFile)
  {
    this.m_strXMLFile = _strXMLFile;
    try
    {
      this.m_XMLReader = new XmlTextReader(this.m_strXMLFile);
      this.m_XMLData = new XmlElementInfo();
      while (this.m_XMLReader.Read())
      {
        if (this.m_XMLReader.NodeType == XmlNodeType.Element)
          this.ReadElement(ref this.m_XMLData);
      }
      this.m_XMLReader.Close();
    }
    catch (Exception ex)
    {
    }
  }

  private void ReadElement(ref XmlElementInfo _ElementInfo)
  {
    _ElementInfo.Name = this.m_XMLReader.Name;
    if (this.m_XMLReader.HasAttributes)
    {
      for (int i = 0; i < this.m_XMLReader.AttributeCount; ++i)
      {
        this.m_XMLReader.MoveToAttribute(i);
        XmlAttributeInfo _Attribute = new XmlAttributeInfo(this.m_XMLReader.Name, this.m_XMLReader.Value);
        if (_Attribute != null)
          _ElementInfo.AddAttribute(_Attribute);
      }
      this.m_XMLReader.MoveToElement();
    }
    if (this.m_XMLReader.IsEmptyElement)
      return;
    while (this.m_XMLReader.Read() && this.m_XMLReader.NodeType != XmlNodeType.EndElement)
    {
      if (this.m_XMLReader.NodeType == XmlNodeType.Element)
      {
        XmlElementInfo _ElementInfo1 = new XmlElementInfo();
        this.ReadElement(ref _ElementInfo1);
        _ElementInfo.AddElement(_ElementInfo1);
      }
      else if (this.m_XMLReader.NodeType == XmlNodeType.Comment)
      {
        XmlElementInfo _CommentInfo = new XmlElementInfo();
        this.ReadComment(ref _CommentInfo);
        _ElementInfo.AddElement(_CommentInfo);
      }
    }
  }

  private void ReadComment(ref XmlElementInfo _CommentInfo)
  {
    _CommentInfo.IsComment = true;
    _CommentInfo.Name = this.m_XMLReader.Value;
  }

  public XmlElementInfo GetElement(string _strElement)
  {
    return this.GetElement(this.m_XMLData, _strElement);
  }

  public XmlElementInfo GetElement(XmlElementInfo _ElementInfo, string _strElement)
  {
    if (_ElementInfo != null)
    {
      if (string.Compare(_ElementInfo.Name, _strElement, true) == 0)
        return _ElementInfo;
      for (int index = 0; index < _ElementInfo.ElementCount; ++index)
      {
        if (string.Compare(((XmlElementInfo) _ElementInfo.Children[index]).Name, _strElement, true) == 0)
          return (XmlElementInfo) _ElementInfo.Children[index];
      }
    }
    return (XmlElementInfo) null;
  }

  public string FileName => this.m_strXMLFile;
}
