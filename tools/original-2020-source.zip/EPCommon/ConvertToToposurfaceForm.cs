﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ConvertToToposurfaceForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ConvertToToposurfaceForm : EPForm
{
  private Document m_Document;
  private IContainer components;
  private Button m_ConvertButton;
  private Button m_CancelButton;
  private Label m_ToposurfaceNameLabel;
  private TextBox m_ToposurfaceNameTextBox;
  private Button m_PickButton;
  private ComboBox m_PhaseComboBox;
  private Label m_PhaseLabel;
  private CheckBox m_HideOriginalCheckBox;

  public ConvertToToposurfaceForm(Document _CurDocument)
  {
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDtopoConversion";
    this.Text = EPShared.LocalRM.GetString("ConvertObjectToToposurfaceTitle");
    this.m_ToposurfaceNameLabel.Text = EPShared.LocalRM.GetString("AMP_ToposurfaceNameDialog");
    this.m_PhaseLabel.Text = EPShared.LocalRM.GetString("AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog");
    this.m_PickButton.Text = EPShared.LocalRM.GetString("AMP_PickDialog");
    this.m_ConvertButton.Text = EPShared.LocalRM.GetString("AMP_ConvertDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_HideOriginalCheckBox.Checked = false;
    this.m_Document = _CurDocument;
    this.LoadPhases();
    this.GetDialogPosition();
  }

  private void LoadPhases()
  {
    List<Phase> phaseList = new List<Phase>();
    foreach (Phase phase in this.m_Document.Phases)
      phaseList.Add(phase);
    this.m_PhaseComboBox.DataSource = (object) phaseList;
    this.m_PhaseComboBox.DisplayMember = "Name";
    if (this.m_PhaseComboBox.Items.Count <= 0)
      return;
    this.m_PhaseComboBox.SelectedIndex = 0;
  }

  private void OnConvertButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnPickButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnConvertToToposurfaceFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private bool ValidateFields()
  {
    if (!string.IsNullOrEmpty(this.m_ToposurfaceNameTextBox.Text))
      return true;
    int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Specify_Message")}{EPShared.LocalRM.GetString("ToposurfaceString")}{EPShared.LocalRM.GetString("NameString")} ", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    this.m_ToposurfaceNameTextBox.Focus();
    return false;
  }

  public void EnableConvertButton() => this.m_ConvertButton.Enabled = true;

  public string ToposurfaceName => this.m_ToposurfaceNameTextBox.Text;

  public Phase SelectedPhase
  {
    get
    {
      return this.m_PhaseComboBox.SelectedIndex >= 0 ? this.m_PhaseComboBox.SelectedItem as Phase : (Phase) null;
    }
  }

  public bool HideOriginalTopoSurface => this.m_HideOriginalCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ConvertButton = new Button();
    this.m_CancelButton = new Button();
    this.m_ToposurfaceNameLabel = new Label();
    this.m_ToposurfaceNameTextBox = new TextBox();
    this.m_PickButton = new Button();
    this.m_PhaseComboBox = new ComboBox();
    this.m_PhaseLabel = new Label();
    this.m_HideOriginalCheckBox = new CheckBox();
    this.SuspendLayout();
    this.m_ConvertButton.Enabled = false;
    this.m_ConvertButton.Location = new Point(196, 65);
    this.m_ConvertButton.Name = "m_ConvertButton";
    this.m_ConvertButton.Size = new Size(75, 23);
    this.m_ConvertButton.TabIndex = 5;
    this.m_ConvertButton.Text = "&Convert";
    this.m_ConvertButton.UseVisualStyleBackColor = true;
    this.m_ConvertButton.Click += new EventHandler(this.OnConvertButtonClick);
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(273, 65);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 6;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_ToposurfaceNameLabel.AutoSize = true;
    this.m_ToposurfaceNameLabel.Location = new Point(12, 15);
    this.m_ToposurfaceNameLabel.Name = "m_ToposurfaceNameLabel";
    this.m_ToposurfaceNameLabel.Size = new Size(101, 13);
    this.m_ToposurfaceNameLabel.TabIndex = 0;
    this.m_ToposurfaceNameLabel.Text = "Toposurface Name:";
    this.m_ToposurfaceNameTextBox.Location = new Point(151, 12);
    this.m_ToposurfaceNameTextBox.Name = "m_ToposurfaceNameTextBox";
    this.m_ToposurfaceNameTextBox.Size = new Size(197, 20);
    this.m_ToposurfaceNameTextBox.TabIndex = 1;
    this.m_PickButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_PickButton.Location = new Point(119, 65);
    this.m_PickButton.Name = "m_PickButton";
    this.m_PickButton.Size = new Size(75, 23);
    this.m_PickButton.TabIndex = 4;
    this.m_PickButton.Text = "&Pick";
    this.m_PickButton.UseVisualStyleBackColor = true;
    this.m_PickButton.Click += new EventHandler(this.OnPickButtonClick);
    this.m_PhaseComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PhaseComboBox.FormattingEnabled = true;
    this.m_PhaseComboBox.Location = new Point(151, 38);
    this.m_PhaseComboBox.Name = "m_PhaseComboBox";
    this.m_PhaseComboBox.Size = new Size(197, 21);
    this.m_PhaseComboBox.TabIndex = 3;
    this.m_PhaseLabel.AutoSize = true;
    this.m_PhaseLabel.Location = new Point(12, 41);
    this.m_PhaseLabel.Name = "m_PhaseLabel";
    this.m_PhaseLabel.Size = new Size(37, 13);
    this.m_PhaseLabel.TabIndex = 2;
    this.m_PhaseLabel.Text = "Phase";
    this.m_HideOriginalCheckBox.Location = new Point(15, 57);
    this.m_HideOriginalCheckBox.Name = "m_HideOriginalCheckBox";
    this.m_HideOriginalCheckBox.Size = new Size(98, 37);
    this.m_HideOriginalCheckBox.TabIndex = 7;
    this.m_HideOriginalCheckBox.Text = "Hide Original Toposurface";
    this.m_HideOriginalCheckBox.UseVisualStyleBackColor = true;
    this.AcceptButton = (IButtonControl) this.m_ConvertButton;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
    this.ClientSize = new Size(364, 100);
    this.Controls.Add((Control) this.m_HideOriginalCheckBox);
    this.Controls.Add((Control) this.m_PhaseComboBox);
    this.Controls.Add((Control) this.m_PhaseLabel);
    this.Controls.Add((Control) this.m_PickButton);
    this.Controls.Add((Control) this.m_ToposurfaceNameLabel);
    this.Controls.Add((Control) this.m_ToposurfaceNameTextBox);
    this.Controls.Add((Control) this.m_ConvertButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ConvertToToposurfaceForm);
    this.Text = nameof (ConvertToToposurfaceForm);
    this.FormClosing += new FormClosingEventHandler(this.OnConvertToToposurfaceFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
