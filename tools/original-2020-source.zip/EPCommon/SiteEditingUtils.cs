﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SiteEditingUtils
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace EPCommon;

internal class SiteEditingUtils
{
  public static XYZ MoveXYZToElevation(XYZ input, double elevation)
  {
    return XYZ.op_Addition(input, XYZ.op_Multiply(XYZ.BasisZ, elevation - input.Z));
  }

  public static double GetAverageElevation(IList<XYZ> existingPoints)
  {
    return existingPoints.Count == 0 ? 0.0 : existingPoints.Average<XYZ>((Func<XYZ, double>) (xyz => xyz.Z));
  }

  public static XYZ GetCenterOf(Element element)
  {
    BoundingBoxXYZ boundingBoxXyz = element[(View) null];
    return XYZ.op_Division(XYZ.op_Addition(boundingBoxXyz.Min, boundingBoxXyz.Max), 2.0);
  }

  public static IList<XYZ> GetPointsFromSubregionRough(TopographySurface subregion)
  {
    BoundingBoxXYZ boundingBoxXyz = ((Element) subregion)[(View) null];
    return SiteEditingUtils.GetTopographySurfaceHost(subregion).FindPoints(new Outline(boundingBoxXyz.Min, boundingBoxXyz.Max));
  }

  public static IList<XYZ> GetPointsFromSubregionExact(TopographySurface subregion)
  {
    return subregion.GetPoints();
  }

  public static TopographySurface GetTopographySurfaceHost(TopographySurface subregion)
  {
    return ((Element) subregion).Document.GetElement(subregion.AsSiteSubRegion().HostId) as TopographySurface;
  }

  public static IList<XYZ> GetNonBoundaryPoints(TopographySurface toposurface)
  {
    return toposurface.GetInteriorPoints();
  }
}
