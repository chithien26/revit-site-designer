﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ValueConversion
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Globalization;

#nullable disable
namespace EPCommon;

public class ValueConversion
{
  public static double ToDouble(string _strValue)
  {
    double num;
    if (_strValue.IndexOf(".") >= 0)
      num = Convert.ToDouble(_strValue, (IFormatProvider) new NumberFormatInfo()
      {
        NumberDecimalSeparator = "."
      });
    else if (_strValue.IndexOf(",") >= 0)
      num = Convert.ToDouble(_strValue, (IFormatProvider) new NumberFormatInfo()
      {
        NumberGroupSeparator = ","
      });
    else
      num = Convert.ToDouble(_strValue);
    return num;
  }

  public static double Parse(string _strValue)
  {
    double num;
    if (_strValue.IndexOf(".") >= 0)
      num = double.Parse(_strValue, (IFormatProvider) new NumberFormatInfo()
      {
        NumberDecimalSeparator = "."
      });
    else if (_strValue.IndexOf(",") >= 0)
      num = double.Parse(_strValue, (IFormatProvider) new NumberFormatInfo()
      {
        NumberDecimalSeparator = ","
      });
    else
      num = double.Parse(_strValue);
    return num;
  }

  public static string ToString(double _dValue) => Convert.ToString(_dValue);

  public static string ToString(DecimalSymbol _DecimalSymbolType, double _dValue)
  {
    string str = Convert.ToString(_dValue);
    if (_DecimalSymbolType == null)
      str = str.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, ".");
    else if (_DecimalSymbolType == 1)
      str = str.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, ",");
    return str;
  }

  public static string Format(string _strFormat, params object[] _Arguments)
  {
    return string.Format(_strFormat, _Arguments);
  }

  public static string Format(
    DecimalSymbol _DecimalSymbolType,
    string _strFormat,
    params object[] _Arguments)
  {
    string str = string.Format(_strFormat, _Arguments);
    if (_DecimalSymbolType == null)
      str = str.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, ".");
    else if (_DecimalSymbolType == 1)
      str = str.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, ",");
    return str;
  }
}
