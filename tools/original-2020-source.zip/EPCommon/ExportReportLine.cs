﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ExportReportLine
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class ExportReportLine
{
  private string m_strLevelName;
  private string m_strParameter;
  private string m_strValue;
  private bool m_bBlankLine;

  public ExportReportLine(string _strLevelName, string _strParameter, string _strValue)
  {
    this.m_strLevelName = _strLevelName;
    this.m_strParameter = _strParameter;
    this.m_strValue = _strValue;
    this.m_bBlankLine = false;
  }

  public ExportReportLine() => this.m_bBlankLine = true;

  public string LevelName
  {
    get => this.m_strLevelName;
    set => this.m_strLevelName = value;
  }

  public string Parameter
  {
    get => this.m_strParameter;
    set => this.m_strParameter = value;
  }

  public string Value
  {
    get => this.m_strValue;
    set => this.m_strValue = value;
  }

  public bool BlankLine
  {
    get => this.m_bBlankLine;
    set => this.m_bBlankLine = value;
  }
}
