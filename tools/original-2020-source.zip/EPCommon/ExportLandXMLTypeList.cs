﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ExportLandXMLTypeList
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ExportLandXMLTypeList : EPForm
{
  private LandXMLElementType m_CurrentType;
  private List<LandXMLAlignment> m_AlignmentList = new List<LandXMLAlignment>();
  private List<LandXMLAlignment> m_SelectedAlignmentList;
  private List<TopographySurfaceContainer> m_SurfaceList;
  private List<TopographySurfaceContainer> m_SelectedSurfaceList;
  private string m_strCurrentType = string.Empty;
  private Document m_CurrentDocument;
  private int m_nElementCount;
  private List<View> m_ViewList = new List<View>();
  private List<FamilyInstanceComponentWrapper> m_SiteComponentList;
  private IContainer components;
  private ListView m_LandXMLTypeListView;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;
  private Label m_SelectedTypeLabel;

  public ExportLandXMLTypeList(
    LandXMLElementType _CurrentType,
    Document _CurrentDocument,
    ref List<TopographySurfaceContainer> _SurfaceList)
  {
    this.m_CurrentType = _CurrentType;
    this.m_CurrentDocument = _CurrentDocument;
    this.m_SiteComponentList = new List<FamilyInstanceComponentWrapper>();
    this.m_SurfaceList = new List<TopographySurfaceContainer>();
    this.m_SelectedSurfaceList = _SurfaceList;
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDimportLandXMLinfo";
    this.SetupStrings();
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      try
      {
        this.LoadSurfaces();
        this.m_nElementCount = this.m_SurfaceList.Count;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ErrorParsingXMLFileString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    else
    {
      try
      {
        this.m_nElementCount = this.m_AlignmentList.Count;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ErrorParsingXMLFileString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    this.GetDialogPosition();
    this.UpdateListView();
  }

  public ExportLandXMLTypeList(
    LandXMLElementType _CurrentType,
    Document _CurrentDocument,
    ref List<LandXMLAlignment> _AlignmentList)
  {
    this.m_CurrentType = _CurrentType;
    this.m_CurrentDocument = _CurrentDocument;
    this.m_AlignmentList = new List<LandXMLAlignment>();
    this.m_SelectedAlignmentList = _AlignmentList;
    this.m_SiteComponentList = new List<FamilyInstanceComponentWrapper>();
    this.InitializeComponent();
    this.SetupStrings();
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      try
      {
        this.m_nElementCount = this.m_SurfaceList.Count;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ErrorParsingXMLFileString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    else
    {
      try
      {
        this.LoadAlignments();
        this.m_nElementCount = this.m_AlignmentList.Count;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ErrorParsingXMLFileString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    this.GetDialogPosition();
    this.UpdateListView();
  }

  private void LoadSurfaces()
  {
    FilteredElementCollector elementCollector = new FilteredElementCollector(this.m_CurrentDocument);
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
      this.m_SurfaceList.Add(new TopographySurfaceContainer(this.m_CurrentDocument.Application, element as TopographySurface, true));
  }

  private void LoadAlignments()
  {
    FindFamilyInstance2 = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    Parameter LocateTypeParameter = (Parameter) null;
    FilteredElementCollector source = new FilteredElementCollector(this.m_CurrentDocument);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement =>
    {
      if (CurrentElement is FamilyInstance FindFamilyInstance2 && (SiteworksIDParameter = ((Element) FindFamilyInstance2.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null)
      {
        string strA1 = SiteworksIDParameter.AsString();
        int int32 = Convert.ToInt32((object) LandcaddID.SiteComponentPlacement);
        string strB1 = int32.ToString("000");
        if (string.Compare(strA1, strB1, true) == 0 && (LocateTypeParameter = ((Element) FindFamilyInstance2).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter)) != null)
        {
          string strA2 = LocateTypeParameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.Street);
          string strB2 = int32.ToString("000");
          if (string.Compare(strA2, strB2, true) == 0)
            return CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null;
        }
      }
      return false;
    })).ToList<Element>();
    IList<Element> elements = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051).ToElements();
    bool flag = false;
    foreach (Element element in list)
    {
      if (element is FamilyInstance _FamilyInstance && ((Element) _FamilyInstance).Category != null)
      {
        int integerValue1 = ((Element) _FamilyInstance).Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001260;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1)
        {
          SiteworksIDParameter = ((Element) _FamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
          if (SiteworksIDParameter != null)
          {
            LocateTypeParameter = ((Element) _FamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (LocateTypeParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
            {
              Parameter parameter1 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
              if (parameter1 != null)
              {
                Parameter parameter2 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
                if (parameter2 != null && parameter2.AsString() != string.Empty)
                {
                  for (int index1 = 0; index1 < elements.Count; ++index1)
                  {
                    Element _Element = elements[index1];
                    if (_Element != null && _Element.Category != null)
                    {
                      int integerValue2 = _Element.Category.Id.IntegerValue;
                      builtInCategory = (BuiltInCategory) -2000051;
                      int hashCode2 = builtInCategory.GetHashCode();
                      if (integerValue2 == hashCode2 && string.Compare(parameter1.AsString(), _Element.UniqueId, true) == 0)
                      {
                        for (int index2 = 0; index2 < this.m_SiteComponentList.Count; ++index2)
                        {
                          if (string.Compare(parameter2.AsString(), this.m_SiteComponentList[index2].ChainID, true) == 0)
                          {
                            flag = true;
                            FamilyInstanceComponentContainer componentContainer = new FamilyInstanceComponentContainer(_Element, _FamilyInstance);
                            this.m_SiteComponentList[index2].FamilyContainerList.Add(componentContainer);
                            break;
                          }
                        }
                        if (!flag)
                          this.m_SiteComponentList.Add(new FamilyInstanceComponentWrapper(parameter2.AsString(), new List<FamilyInstanceComponentContainer>()
                          {
                            new FamilyInstanceComponentContainer(_Element, _FamilyInstance)
                          }));
                        else
                          flag = false;
                        elements.RemoveAt(index1);
                        break;
                      }
                    }
                  }
                  if (elements.Count == 0)
                    break;
                }
              }
            }
          }
        }
      }
    }
    string str = "Alignment ";
    int num = 1;
    for (int index3 = 0; index3 < this.m_SiteComponentList.Count; ++index3)
    {
      LandXMLAlignment landXmlAlignment = new LandXMLAlignment();
      FamilyInstance existingFamilyInstance = this.m_SiteComponentList[index3].GetFirstExistingFamilyInstance();
      Element firstExistingElement = this.m_SiteComponentList[index3].GetFirstExistingElement();
      if (existingFamilyInstance != null)
      {
        Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
        if (parameter != null)
          landXmlAlignment.Name = parameter.AsString();
      }
      if (landXmlAlignment.Name == string.Empty)
      {
        landXmlAlignment.Name = str + num.ToString();
        ++num;
      }
      if (firstExistingElement != null)
      {
        Eps_Leg _LegList = RevitGeometry.GetLegFromElementList((Eps_Leg) null, firstExistingElement);
        if (_LegList == null)
        {
          LocationCurve location = firstExistingElement.Location as LocationCurve;
          if (location != null)
          {
            Curve curve = location.Curve;
            if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
            {
              switch (curve)
              {
                case Arc _:
                  Eps_Arc epsArc = new Eps_Arc((Arc) curve);
                  landXmlAlignment.StartPoint = epsArc.StartPnt;
                  landXmlAlignment.Length = ValueConversion.ToString(EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsArc.Radius, epsArc.Delta));
                  landXmlAlignment.Curves.Add(epsArc);
                  break;
                case Line _:
                  Eps_Line epsLine = new Eps_Line();
                  epsLine.StartPnt = new Eps_Point(curve.GetEndPoint(0));
                  epsLine.EndPnt = new Eps_Point(curve.GetEndPoint(1));
                  landXmlAlignment.StartPoint = epsLine.StartPnt;
                  double _dDistance = 0.0;
                  if (EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDistance) == 0)
                    landXmlAlignment.Length = ValueConversion.ToString(_dDistance);
                  landXmlAlignment.Lines.Add(epsLine);
                  break;
                case Ellipse _:
                case NurbSpline _:
                case HermiteSpline _:
                  IList<XYZ> xyzList = curve.Tessellate();
                  int count = xyzList.Count;
                  Eps_Leg epsLeg1 = (Eps_Leg) null;
                  if (count > 1)
                  {
                    Eps_Point epsPoint1 = new Eps_Point();
                    Eps_Point epsPoint2 = new Eps_Point();
                    for (int index4 = 0; index4 < count; index4 += 2)
                    {
                      Eps_Point epsPoint3 = new Eps_Point(xyzList[index4]);
                      if (index4 > 0)
                      {
                        Eps_Leg epsLeg2 = new Eps_Leg();
                        epsLeg2.Line = new Eps_Line();
                        epsLeg2.Line.StartPnt = epsPoint1;
                        epsLeg2.Line.EndPnt = epsPoint3;
                        if (epsLeg1 == null)
                        {
                          epsLeg1 = epsLeg2;
                          epsLeg1.Element = firstExistingElement;
                        }
                        else
                        {
                          epsLeg1.Last.Next = epsLeg2;
                          epsLeg1.Last.Element = firstExistingElement;
                        }
                      }
                      epsPoint1 = epsPoint3;
                    }
                    if (index3 == count)
                    {
                      Eps_Leg epsLeg3 = new Eps_Leg();
                      epsLeg3.Line = new Eps_Line();
                      epsLeg3.Line.StartPnt = epsPoint1;
                      epsLeg3.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
                      if (epsLeg1 == null)
                      {
                        epsLeg1 = epsLeg3;
                        epsLeg1.Element = firstExistingElement;
                      }
                      else
                      {
                        epsLeg1.Last.Next = epsLeg3;
                        epsLeg1.Last.Element = firstExistingElement;
                      }
                    }
                  }
                  if (epsLeg1 != null)
                  {
                    landXmlAlignment.StartPoint = epsLeg1.LegStartPnt;
                    landXmlAlignment.Length = ValueConversion.ToString(RevitGeometry.eplGeoE_CalcLegListLength(_LegList));
                    for (; epsLeg1.Next != null; epsLeg1 = epsLeg1.Next)
                    {
                      if (epsLeg1.Line != null)
                        landXmlAlignment.Lines.Add(epsLeg1.Line);
                      else if (epsLeg1.Arc != null)
                        landXmlAlignment.Curves.Add(epsLeg1.Arc);
                    }
                    break;
                  }
                  break;
              }
            }
          }
        }
        else
        {
          landXmlAlignment.StartPoint = _LegList.LegStartPnt;
          landXmlAlignment.Length = ValueConversion.ToString(RevitGeometry.eplGeoE_CalcLegListLength(_LegList));
          for (; _LegList != null; _LegList = _LegList.Next)
          {
            if (_LegList.Line != null)
              landXmlAlignment.Lines.Add(_LegList.Line);
            else if (_LegList.Arc != null)
              landXmlAlignment.Curves.Add(_LegList.Arc);
          }
        }
      }
      this.m_AlignmentList.Add(landXmlAlignment);
    }
  }

  private void SetupStrings()
  {
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    switch (this.m_CurrentType)
    {
      case LandXMLElementType.Surface:
        this.Text = EPShared.LocalRM.GetString("ToposurfacesToExportDialog");
        this.m_strCurrentType = EPShared.LocalRM.GetString("ToposurfacesString");
        this.m_SelectedTypeLabel.Text = EPShared.LocalRM.GetString("SelectExportTopoSurfaceLabelString");
        break;
      case LandXMLElementType.Allignment:
        this.Text = EPShared.LocalRM.GetString("AlignmentToExportDialog");
        this.m_strCurrentType = EPShared.LocalRM.GetString("AllignmentString");
        this.m_SelectedTypeLabel.Text = EPShared.LocalRM.GetString("SelectExportTopoAlignmentLabelString");
        break;
    }
    this.m_LandXMLTypeListView.View = View.Details;
    this.m_LandXMLTypeListView.MultiSelect = true;
    List<string> stringList = new List<string>();
    this.m_LandXMLTypeListView.Columns.Add(EPShared.LocalRM.GetString("NameSubRegionParameter"));
    this.m_LandXMLTypeListView.Columns[0].Width = this.m_LandXMLTypeListView.Width - 4;
  }

  private void UpdateListView()
  {
    this.m_LandXMLTypeListView.Items.Clear();
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      foreach (TopographySurfaceContainer surface in this.m_SurfaceList)
      {
        ListViewItem listViewItem = new ListViewItem();
        string text = string.Empty;
        Parameter parameter = ((Element) surface.TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter != null && parameter.AsString() != null && parameter.AsString() != string.Empty)
          text = parameter.AsString();
        if (text != string.Empty)
          this.m_LandXMLTypeListView.Items.Add(text).Tag = (object) text;
        else
          this.m_LandXMLTypeListView.Items.Add(EPShared.LocalRM.GetString("NotAvailableString")).Tag = (object) EPShared.LocalRM.GetString("NotAvailableString");
      }
    }
    else
    {
      foreach (LandXMLAlignment alignment in this.m_AlignmentList)
      {
        ListViewItem listViewItem = new ListViewItem();
        this.m_LandXMLTypeListView.Items.Add(alignment.Name).Tag = (object) alignment.Name;
      }
    }
  }

  private void OnButtonOkClicked(object sender, EventArgs e)
  {
    DialogResult dialogResult;
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      if (this.m_LandXMLTypeListView.SelectedIndices.Count <= 0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSurfacesSelectedToExportString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Asterisk);
        return;
      }
      for (int index = 0; index < this.m_LandXMLTypeListView.SelectedIndices.Count; ++index)
        this.m_SelectedSurfaceList.Add(this.m_SurfaceList[this.m_LandXMLTypeListView.SelectedIndices[index]]);
      dialogResult = DialogResult.OK;
    }
    else
    {
      if (this.m_LandXMLTypeListView.SelectedIndices.Count <= 0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoAlignmentSelectedToExportString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Asterisk);
        return;
      }
      for (int index = 0; index < this.m_LandXMLTypeListView.SelectedIndices.Count; ++index)
        this.m_SelectedAlignmentList.Add(this.m_AlignmentList[this.m_LandXMLTypeListView.SelectedIndices[index]]);
      dialogResult = DialogResult.OK;
    }
    this.DialogResult = dialogResult;
  }

  private void OnButtonCancelClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  public int ElementCount
  {
    get => this.m_nElementCount;
    set => this.m_nElementCount = value;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_LandXMLTypeListView = new ListView();
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.m_SelectedTypeLabel = new Label();
    this.SuspendLayout();
    this.m_LandXMLTypeListView.FullRowSelect = true;
    this.m_LandXMLTypeListView.Location = new Point(12, 34);
    this.m_LandXMLTypeListView.Name = "m_LandXMLTypeListView";
    this.m_LandXMLTypeListView.Size = new Size(334, 186);
    this.m_LandXMLTypeListView.TabIndex = 0;
    this.m_LandXMLTypeListView.UseCompatibleStateImageBehavior = false;
    this.m_ButtonOk.Location = new Point(190, 226);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 1;
    this.m_ButtonOk.Text = "Ok";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnButtonOkClicked);
    this.m_ButtonCancel.Location = new Point(271, 226);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 2;
    this.m_ButtonCancel.Text = "Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnButtonCancelClicked);
    this.m_SelectedTypeLabel.AutoSize = true;
    this.m_SelectedTypeLabel.Location = new Point(12, 9);
    this.m_SelectedTypeLabel.Name = "m_SelectedTypeLabel";
    this.m_SelectedTypeLabel.Size = new Size(35, 13);
    this.m_SelectedTypeLabel.TabIndex = 3;
    this.m_SelectedTypeLabel.Text = "label1";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(358, 261);
    this.Controls.Add((Control) this.m_SelectedTypeLabel);
    this.Controls.Add((Control) this.m_ButtonCancel);
    this.Controls.Add((Control) this.m_ButtonOk);
    this.Controls.Add((Control) this.m_LandXMLTypeListView);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(364, 287);
    this.Name = nameof (ExportLandXMLTypeList);
    this.Text = "LandXMLTypeList";
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
