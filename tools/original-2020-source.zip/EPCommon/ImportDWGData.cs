﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ImportDWGData
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;

#nullable disable
namespace EPCommon;

public class ImportDWGData : ImportData
{
  private bool m_bImportThisViewOnly;
  private ViewSet m_Views;
  private View m_ImportView;
  private List<string> m_ColorModes;
  private List<ImportColorMode> m_EnumColorModes;
  private ImportColorMode m_ImportColorMode;
  private List<ImportPlacement> m_EnumPlacements;
  private ImportPlacement m_ImportPlacement;
  private List<ImportUnit> m_EnumUnits;
  private ImportUnit m_ImportUnit;
  private double m_dImportCustomScale;
  private List<string> m_Placements;
  private List<string> m_DimensionTypes;
  private List<string> m_Units;
  private List<string> m_VisibleLayersOnlyList;
  private List<bool> m_EnumVisibleLayersOnlyList;
  private bool m_ImportVisibleLayersOnlyList;

  public bool ImportThisViewOnly
  {
    get => this.m_bImportThisViewOnly;
    set => this.m_bImportThisViewOnly = value;
  }

  public ViewSet Views
  {
    get => this.m_Views;
    set => this.m_Views = value;
  }

  public View ImportView
  {
    get => this.m_ImportView;
    set => this.m_ImportView = value;
  }

  public ReadOnlyCollection<string> ColorModes
  {
    get => new ReadOnlyCollection<string>((IList<string>) this.m_ColorModes);
  }

  public ReadOnlyCollection<ImportColorMode> EnumColorModes
  {
    get => new ReadOnlyCollection<ImportColorMode>((IList<ImportColorMode>) this.m_EnumColorModes);
  }

  public ImportColorMode ImportColorMode
  {
    get => this.m_ImportColorMode;
    set => this.m_ImportColorMode = value;
  }

  public ReadOnlyCollection<ImportPlacement> EnumPlacements
  {
    get => new ReadOnlyCollection<ImportPlacement>((IList<ImportPlacement>) this.m_EnumPlacements);
  }

  public ImportPlacement ImportPlacement
  {
    get => this.m_ImportPlacement;
    set => this.m_ImportPlacement = value;
  }

  public ReadOnlyCollection<ImportUnit> EnumUnits
  {
    get => new ReadOnlyCollection<ImportUnit>((IList<ImportUnit>) this.m_EnumUnits);
  }

  public ImportUnit ImportUnit
  {
    get => this.m_ImportUnit;
    set => this.m_ImportUnit = value;
  }

  public double ImportCustomScale
  {
    get => this.m_dImportCustomScale;
    set => this.m_dImportCustomScale = value;
  }

  public ReadOnlyCollection<string> Placements
  {
    get => new ReadOnlyCollection<string>((IList<string>) this.m_Placements);
  }

  public ReadOnlyCollection<string> DimensionTypes
  {
    get => new ReadOnlyCollection<string>((IList<string>) this.m_DimensionTypes);
  }

  public ReadOnlyCollection<string> Units
  {
    get => new ReadOnlyCollection<string>((IList<string>) this.m_Units);
  }

  public ReadOnlyCollection<string> VisibleLayersOnlyList
  {
    get => new ReadOnlyCollection<string>((IList<string>) this.m_VisibleLayersOnlyList);
  }

  public ReadOnlyCollection<bool> EnumVisibleLayersOnlyList
  {
    get => new ReadOnlyCollection<bool>((IList<bool>) this.m_EnumVisibleLayersOnlyList);
  }

  public bool ImportVisibleLayersOnlyList
  {
    get => this.m_ImportVisibleLayersOnlyList;
    set => this.m_ImportVisibleLayersOnlyList = value;
  }

  public ImportDWGData(Document _CurDocument)
    : base(_CurDocument)
  {
    this.Initialize();
  }

  public override bool Import()
  {
    DWGImportOptions dwgImportOptions = new DWGImportOptions();
    ((BaseImportOptions) dwgImportOptions).ColorMode = this.m_ImportColorMode;
    ((BaseImportOptions) dwgImportOptions).CustomScale = this.m_dImportCustomScale;
    ((BaseImportOptions) dwgImportOptions).OrientToView = false;
    ((BaseImportOptions) dwgImportOptions).Placement = this.m_ImportPlacement;
    ((BaseImportOptions) dwgImportOptions).ThisViewOnly = this.m_bImportThisViewOnly;
    ((BaseImportOptions) dwgImportOptions).Unit = this.m_ImportUnit;
    ((BaseImportOptions) dwgImportOptions).VisibleLayersOnly = this.m_ImportVisibleLayersOnlyList;
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ImportDrawingTransaction") + Path.GetFileName(this.m_strImportFileFullName));
    this.m_TransactionContainer.BeginTransaction();
    ElementId elementId = (ElementId) null;
    bool flag = this.m_ActiveDoc.Import(this.m_strImportFileFullName, dwgImportOptions, this.m_ImportView, ref elementId);
    Element element = this.m_ActiveDoc.GetElement(elementId);
    if (!this.m_bImportThisViewOnly && flag && element != null && element is ImportInstance importInstance)
    {
      FamilyElementVisibility visibility = importInstance.GetVisibility();
      visibility.IsShownInPlanRCPCut = false;
      visibility.IsShownInTopBottom = false;
      importInstance.SetVisibility(visibility);
      ElementSet elm_set = new ElementSet();
      elm_set.Insert((Element) importInstance);
      this.m_ImportView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
    }
    if (this.m_bAbortTransaction)
    {
      FileInfo fileInfo = new FileInfo(this.m_strSaveAsFileName);
      this.m_ActiveDoc.FamilyManager.NewType(fileInfo.Name.TrimEnd(fileInfo.Extension.ToCharArray()));
    }
    this.m_bAbortTransaction = !flag;
    this.m_TransactionContainer.EndTransaction();
    this.m_TransactionContainer.Commit();
    this.m_ActiveDoc.SaveAs(this.m_strSaveAsFileName, new SaveAsOptions()
    {
      OverwriteExistingFile = true
    });
    return flag;
  }

  private void Initialize()
  {
    this.m_ColorModes = new List<string>();
    this.m_EnumColorModes = new List<ImportColorMode>();
    this.m_ColorModes.Add(EPShared.LocalRM.GetString("BlackAndWhiteColorMode"));
    this.m_EnumColorModes.Add((ImportColorMode) 2);
    this.m_ColorModes.Add(EPShared.LocalRM.GetString("PreserveColorsColorMode"));
    this.m_EnumColorModes.Add((ImportColorMode) 0);
    this.m_ColorModes.Add(EPShared.LocalRM.GetString("InvertColorsColorMode"));
    this.m_EnumColorModes.Add((ImportColorMode) 1);
    this.m_Placements = new List<string>();
    this.m_EnumPlacements = new List<ImportPlacement>();
    this.m_Placements.Add(EPShared.LocalRM.GetString("OriginToOriginPlacement"));
    this.m_EnumPlacements.Add((ImportPlacement) 1);
    this.m_Placements.Add(EPShared.LocalRM.GetString("CenterToCenterPlacement"));
    this.m_EnumPlacements.Add((ImportPlacement) 2);
    this.m_Units = new List<string>();
    this.m_EnumUnits = new List<ImportUnit>();
    this.m_Units.Add(EPShared.LocalRM.GetString("AutoDetectUnit"));
    this.m_EnumUnits.Add((ImportUnit) 0);
    this.m_Units.Add(((ImportUnit) 1).ToString());
    this.m_EnumUnits.Add((ImportUnit) 1);
    this.m_Units.Add(((ImportUnit) 2).ToString());
    this.m_EnumUnits.Add((ImportUnit) 2);
    this.m_Units.Add(((ImportUnit) 3).ToString());
    this.m_EnumUnits.Add((ImportUnit) 3);
    this.m_Units.Add(((ImportUnit) 4).ToString());
    this.m_EnumUnits.Add((ImportUnit) 4);
    this.m_Units.Add(((ImportUnit) 5).ToString());
    this.m_EnumUnits.Add((ImportUnit) 5);
    this.m_Units.Add(((ImportUnit) 6).ToString());
    this.m_EnumUnits.Add((ImportUnit) 6);
    this.m_Units.Add(EPShared.LocalRM.GetString("CustomUnit"));
    this.m_EnumUnits.Add((ImportUnit) 0);
    this.m_VisibleLayersOnlyList = new List<string>();
    this.m_EnumVisibleLayersOnlyList = new List<bool>();
    this.m_VisibleLayersOnlyList.Add(EPShared.LocalRM.GetString("AllString"));
    this.m_EnumVisibleLayersOnlyList.Add(false);
    this.m_VisibleLayersOnlyList.Add(EPShared.LocalRM.GetString("VisibleString"));
    this.m_EnumVisibleLayersOnlyList.Add(true);
    this.m_DimensionTypes = new List<string>();
    this.m_DimensionTypes.Add(EPShared.LocalRM.GetString("TwoDDWGSymbolDimensionType"));
    this.m_DimensionTypes.Add(EPShared.LocalRM.GetString("ThreeDDWGSymbolDimensionType"));
    this.m_Views = new ViewSet();
    this.GetViews();
    this.m_dImportCustomScale = 0.0;
    this.m_ImportUnit = (ImportUnit) 0;
    this.m_bImportThisViewOnly = false;
    this.m_ImportView = this.m_ActiveDoc.ActiveView;
    this.m_ImportColorMode = (ImportColorMode) 1;
    this.m_ImportPlacement = (ImportPlacement) 1;
    this.m_ImportVisibleLayersOnlyList = false;
  }

  private void GetViews()
  {
    foreach (View element in (IEnumerable<Element>) new FilteredElementCollector(this.m_ActiveDoc).OfClass(typeof (View)).ToElements())
    {
      if (element.ViewType == 1 || element.ViewType == 115 || element.ViewType == 116)
        this.m_Views.Insert(element);
    }
  }
}
