﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantMixSearchForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantMixSearchForm : EPForm
{
  private Units m_Units;
  private Document m_CurDocument;
  private List<FamilyTypeContainer> m_PlantListFamilyTypeList;
  private List<FamilyTypeContainer> m_SelectedPlantListFamilyTypeList;
  private string m_strSourceDirectory = string.Empty;
  private string m_strSourceFile = string.Empty;
  private List<Document> m_OpenDocumentList;
  private List<KeyValuePair<string, string>> m_RecenFilesList;
  private List<ParameterColumn> m_ParameterList;
  private int m_nPlantListViewSortColumn = -1;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private string m_strCurrentDir = string.Empty;
  private string m_strRFAFileName = string.Empty;
  private string m_strCSVFileName = string.Empty;
  private string m_strTABFileName = string.Empty;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_CancelButton;
  private Button m_SaveFamilyButton;
  private GroupBox m_SourceGroupBox;
  private TextBox m_SingleFileTextBox;
  private Label m_SingleFileLabel;
  private GroupBox m_CollectionGroupBox;
  private Button m_ColumnDisplayButton;
  private Button m_SearchButton;
  private ListView m_PlantListView;
  private RadioButton m_DirectoryRadioButton;
  private RadioButton m_SingleFileRadioButton;
  private GroupBox m_SingleFileGroupBox;
  private RadioButton m_TabSingleFileRadioButton;
  private RadioButton m_CommaSingleFileRadioButton;
  private RadioButton m_RFASingleFileRadioButton;
  private Button m_SingleFileButton;
  private Button m_ShowAllFamiliesButton;

  public PlantMixSearchForm(Document _CurDocument)
  {
    this.InitializeComponent();
    this.m_CurDocument = _CurDocument;
    this.m_FormatOptions = this.m_CurDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_CurDocument.DisplayUnitSystem;
    this.m_Units = this.m_CurDocument.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_CurDocument.GetUnits().DecimalSymbol;
    this.InitializeControls();
    this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    this.m_PlantListView.View = View.Details;
    this.m_SelectedPlantListFamilyTypeList = new List<FamilyTypeContainer>();
  }

  private void SetupString()
  {
    this.m_SourceGroupBox.Text = EPShared.LocalRM.GetString("SourceDialog");
    this.m_SingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleFileDialog");
    this.m_DirectoryRadioButton.Text = EPShared.LocalRM.GetString("AMP_DirectoryMultipleFilesDialog");
    this.m_SingleFileGroupBox.Text = EPShared.LocalRM.GetString("SingleFileDialog");
    this.m_RFASingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_RFAFileDialog");
    this.m_CommaSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
    this.m_TabSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
    this.m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_CollectionGroupBox.Text = $"{EPShared.LocalRM.GetString("PlantDialog")} {EPShared.LocalRM.GetString("CollectionDialog")}";
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("Searc_AMP_hDialog");
    this.m_ColumnDisplayButton.Text = EPShared.LocalRM.GetString("Column_AMP_DisplayDialog");
    this.m_ShowAllFamiliesButton.Text = EPShared.LocalRM.GetString("Sho_AMP_wAllDialog");
    this.m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("AMP_AddToFamilyDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.Text = $"{EPShared.LocalRM.GetString("PlantSearchDialog")}  {EPShared.LocalRM.GetString("ManagerDialog")}";
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.m_strSourceDirectory = string.Empty;
    this.m_strSourceFile = string.Empty;
    this.GetDialogPosition();
    this.m_SingleFileRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchSourceOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_SingleFileRadioButton.Checked = true;
      else
        this.m_DirectoryRadioButton.Checked = true;
    }
    this.m_RFASingleFileRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchSingleFileOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_RFASingleFileRadioButton.Checked = true;
          break;
        case 1:
          this.m_CommaSingleFileRadioButton.Checked = true;
          break;
        default:
          this.m_TabSingleFileRadioButton.Checked = true;
          break;
      }
    }
    if (this.m_SingleFileRadioButton.Checked)
    {
      if (this.m_RFASingleFileRadioButton.Checked)
        ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchRFASingleFileName", ref empty);
      else if (this.m_CommaSingleFileRadioButton.Checked)
        ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchCSVSingleFileName", ref empty);
      else if (this.m_TabSingleFileRadioButton.Checked)
        ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchTABSingleFileName", ref empty);
      this.m_SingleFileTextBox.Text = empty;
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchDirectory", ref empty))
    {
      this.m_strCurrentDir = empty;
      if (this.m_DirectoryRadioButton.Checked)
        this.m_SingleFileTextBox.Text = empty;
    }
    this.LoadColumnSettings();
  }

  private void LoadColumnSettings()
  {
    this.m_ParameterList = ManagePlants.GetParameterList("PlantMixSearch");
    this.m_PlantListView.Columns.Clear();
    string empty = string.Empty;
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string plantParamenterName = ManagePlants.GetPlantParamenterName(this.m_ParameterList[index].PlantField);
      this.m_PlantListView.Columns.Add(plantParamenterName, plantParamenterName.Length * 10, HorizontalAlignment.Left);
    }
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchSourceOption", Convert.ToInt32(!this.m_SingleFileRadioButton.Checked));
    int _nValue = !this.m_RFASingleFileRadioButton.Checked ? (!this.m_CommaSingleFileRadioButton.Checked ? 2 : 1) : 0;
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchSingleFileOption", _nValue);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchCreateSymbolFromDWGCheck", _nValue);
    if (this.m_SingleFileTextBox.Text != string.Empty && this.m_SingleFileRadioButton.Checked)
    {
      if (this.m_RFASingleFileRadioButton.Checked)
        ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchRFASingleFileName", this.m_strRFAFileName);
      else if (this.m_CommaSingleFileRadioButton.Checked)
        ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchCSVSingleFileName", this.m_strCSVFileName);
      else if (this.m_TabSingleFileRadioButton.Checked)
        ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchTABSingleFileName", this.m_strTABFileName);
    }
    else if (this.m_SingleFileTextBox.Text != string.Empty)
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchDirectory", this.m_strCurrentDir);
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
      ApplicationUtility.Settings.eplSetE_SetSetting($"PlantMixSearch{this.m_ParameterList[index].PlantField.ToString()}ColumnOrder", this.m_ParameterList[index].Order);
  }

  private List<FamilyTypeContainer> PopulateFamilyTypeSetList(
    FamilyManager _FamilyManager,
    List<ExternalDefinitionContainer> _ExternalDefinitionList)
  {
    List<FamilyTypeContainer> familyTypeContainerList = (List<FamilyTypeContainer>) null;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    bool flag = false;
    foreach (FamilyType type in _FamilyManager.Types)
    {
      string strA = type.Name.Trim();
      if (strA != string.Empty)
      {
        foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
        {
          if (string.Compare(strA, plantListFamilyType.FamilyTypeWrapper.FamilyTypeName, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
        {
          ListViewItem listViewItem = new ListViewItem();
          listViewItem.Tag = (object) strA;
          for (int index = 0; index < this.m_ParameterList.Count; ++index)
          {
            string empty3 = string.Empty;
            this.FindParamenterValue(_FamilyManager, type, ManagePlants.GetPlantParamenterName(this.m_ParameterList[index].PlantField), ref empty3);
            if (this.m_ParameterList[index].PlantField == PlantField.Height || this.m_ParameterList[index].PlantField == PlantField.PlantHeight || this.m_ParameterList[index].PlantField == PlantField.PlantWidth || this.m_ParameterList[index].PlantField == PlantField.CharacteristicsFoliageSize || this.m_ParameterList[index].PlantField == PlantField.PlantSpacing)
            {
              double _dConvertedDouble = 0.0;
              if (empty3 != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(empty3);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty3);
            }
            if (index == 0)
              listViewItem.Text = empty3;
            else
              listViewItem.SubItems.Add(empty3);
          }
          this.m_PlantListView.Items.Add(listViewItem);
          if (familyTypeContainerList == null)
            familyTypeContainerList = new List<FamilyTypeContainer>();
          familyTypeContainerList.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetFamilyParameterSetForType(type, _FamilyManager, _ExternalDefinitionList)));
        }
        else
          flag = false;
      }
    }
    return familyTypeContainerList;
  }

  private bool FindParamenterValue(
    FamilyManager FamilyManager,
    FamilyType type,
    string _strParamter,
    ref string _strValue)
  {
    bool paramenterValue = false;
    FamilyParameter familyParameter = FamilyManager[_strParamter];
    if (familyParameter != null && ManagePlants.GetPlantFieldFromParamenter(familyParameter.Definition.Name) != PlantField.None && type.HasValue(familyParameter))
    {
      switch (familyParameter.StorageType - 1)
      {
        case 0:
          if ((ValueType) type.AsInteger(familyParameter) is int)
          {
            paramenterValue = true;
            _strValue = Convert.ToString((object) type.AsInteger(familyParameter));
            break;
          }
          break;
        case 1:
          if ((ValueType) type.AsDouble(familyParameter) is double)
          {
            paramenterValue = true;
            _strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
            break;
          }
          break;
        case 2:
          if (type.AsString(familyParameter) != null)
          {
            paramenterValue = true;
            _strValue = type.AsString(familyParameter);
            break;
          }
          break;
      }
    }
    return paramenterValue;
  }

  private void EnableDisableDialogFields(bool _bApplyToListButtons)
  {
    bool flag = false;
    if (this.m_PlantListView.Items.Count > 0)
      flag = true;
    this.m_PlantListView.Enabled = flag;
    if (_bApplyToListButtons)
    {
      this.m_SearchButton.Enabled = flag;
      this.m_ColumnDisplayButton.Enabled = flag;
    }
    this.m_SaveFamilyButton.Enabled = flag;
  }

  private void OnSearchButton(object sender, EventArgs e)
  {
    this.SetSelectedPlantList();
    if (!ManagePlants.FindFamilyTypes(EPShared.LocalRM.GetString("PlantMixPlantSearchTitle"), this.m_CurDocument, ref this.m_PlantListFamilyTypeList))
      return;
    for (int index = 0; index < this.m_PlantListView.Items.Count; ++index)
    {
      if (!this.m_PlantListView.SelectedIndices.Contains(index))
      {
        this.m_PlantListView.Items.RemoveAt(index);
        --index;
      }
    }
    this.m_nPlantListViewSortColumn = -1;
    this.m_PlantListView.Sorting = SortOrder.None;
    string empty = string.Empty;
    foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
    {
      if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
        this.PopulatePlantListView(plantListFamilyType);
    }
  }

  private bool ValidateFields()
  {
    string str = "";
    if (!File.Exists(str))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExistingSymbolFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (string.Compare(new FileInfo(str).Extension, ".rfa", true) == 0)
      return true;
    int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SymbolNoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private void SetSelectedPlantList()
  {
    int count;
    if ((count = this.m_PlantListView.SelectedItems.Count) < 1)
      return;
    for (int index1 = 0; index1 < count; ++index1)
    {
      for (int index2 = 0; index2 < this.m_PlantListFamilyTypeList.Count; ++index2)
      {
        if (this.m_PlantListFamilyTypeList[index2].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string) this.m_PlantListView.SelectedItems[index1].Tag, this.m_PlantListFamilyTypeList[index2].FamilyTypeWrapper.FamilyTypeName, true) == 0)
        {
          this.m_PlantListFamilyTypeList[index2].Status = FamilyParameterWrapperStatus.Selected;
          break;
        }
      }
    }
  }

  private bool FindSelectedPlantList(ref List<FamilyTypeContainer> _SelectedPlantList)
  {
    bool flag1 = false;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    bool flag2 = false;
    bool flag3 = false;
    int index1 = -1;
    string str1 = string.Empty;
    string str2 = string.Empty;
    string str3 = string.Empty;
    int count;
    if ((count = this.m_PlantListView.SelectedItems.Count) >= 1)
    {
      for (int index2 = 0; index2 < count; ++index2)
      {
        for (int index3 = 0; index3 < this.m_PlantListFamilyTypeList.Count; ++index3)
        {
          if (this.m_PlantListFamilyTypeList[index3].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string) this.m_PlantListView.SelectedItems[index2].Tag, this.m_PlantListFamilyTypeList[index3].FamilyTypeWrapper.FamilyTypeName, true) == 0)
          {
            for (int index4 = 0; index4 < this.m_PlantListFamilyTypeList[index3].FamilyParameterList.Count; ++index4)
            {
              string parameterName = this.m_PlantListFamilyTypeList[index3].FamilyParameterList[index4].ParameterName;
              string str4 = this.m_PlantListFamilyTypeList[index3].FamilyParameterList[index4].Value;
              if (string.Compare(parameterName, RevitParameters.ScientificNamePlantMixFamilyParameter, true) == 0)
              {
                if (str4 != null && str4 != string.Empty)
                {
                  flag2 = true;
                  str1 = str4;
                }
              }
              else if (string.Compare(parameterName, RevitParameters.CommonNamePlantMixFamilyParameter, true) == 0)
              {
                if (str4 != null && str4 != string.Empty)
                {
                  flag3 = true;
                  str2 = str4;
                }
              }
              else if (string.Compare(parameterName, EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), true) == 0)
              {
                index1 = index4;
                if (str4 != null && str4 != string.Empty)
                {
                  flag1 = true;
                  str3 = str4;
                  break;
                }
              }
            }
            if (!flag1 && (!flag2 || !flag3))
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeCommonOrScientificName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            }
            else
            {
              if (!flag1 && flag2 && flag3)
              {
                if (index1 != -1 && str1 != string.Empty && str2 != string.Empty)
                  this.m_PlantListFamilyTypeList[index3].FamilyParameterList[index1].Value = $"{str1}/{str2}";
              }
              else if (flag1 && str3 == null && flag2 && flag3 && index1 != -1 && str1 != string.Empty && str2 != string.Empty)
                this.m_PlantListFamilyTypeList[index3].FamilyParameterList[index1].Value = $"{str1}/{str2}";
              _SelectedPlantList.Add(this.m_PlantListFamilyTypeList[index3]);
              break;
            }
          }
        }
      }
      return true;
    }
    int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private void FindRecentFileList()
  {
    this.m_RecenFilesList = Settings.eplSetE_GetSectionValuesAsList("Recent File List", ApplicationUtility.RevitIniFilename);
  }

  private void ResetRecentFileList()
  {
    if (this.m_RecenFilesList == null || this.m_RecenFilesList.Count <= 0 || !Settings.eplSetE_DeleteSection("Recent File List", ApplicationUtility.RevitIniFilename))
      return;
    foreach (KeyValuePair<string, string> recenFiles in this.m_RecenFilesList)
      Settings.eplSetE_SetSetting("Recent File List", recenFiles.Key, recenFiles.Value, ApplicationUtility.RevitIniFilename);
  }

  private void CloseOpenDocuments()
  {
    if (this.m_OpenDocumentList != null && this.m_OpenDocumentList.Count > 0)
    {
      for (int index = this.m_OpenDocumentList.Count - 1; index >= 0; --index)
      {
        this.m_OpenDocumentList[index].Close(false);
        this.m_OpenDocumentList.RemoveAt(index);
      }
    }
    this.ResetRecentFileList();
  }

  private void PopulatePlantListView(FamilyTypeContainer _CurFamilyTypeContainer)
  {
    bool flag = false;
    string empty = string.Empty;
    ListViewItem listViewItem = new ListViewItem();
    listViewItem.Tag = (object) _CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName;
    for (int index1 = 0; index1 < this.m_ParameterList.Count; ++index1)
    {
      string plantParamenterName = ManagePlants.GetPlantParamenterName(this.m_ParameterList[index1].PlantField);
      for (int index2 = 0; index2 < _CurFamilyTypeContainer.FamilyParameterList.Count; ++index2)
      {
        if (string.Compare(plantParamenterName, _CurFamilyTypeContainer.FamilyParameterList[index2].ParameterName, true) == 0)
        {
          flag = true;
          string _strToDisplay = _CurFamilyTypeContainer.FamilyParameterList[index2].Value;
          if (this.m_ParameterList[index1].PlantField == PlantField.Height || this.m_ParameterList[index1].PlantField == PlantField.PlantHeight || this.m_ParameterList[index1].PlantField == PlantField.PlantWidth || this.m_ParameterList[index1].PlantField == PlantField.CharacteristicsFoliageSize || this.m_ParameterList[index1].PlantField == PlantField.PlantSpacing)
          {
            double _dConvertedDouble = 0.0;
            if (_strToDisplay != null && _strToDisplay != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
          }
          if (index1 == 0)
          {
            listViewItem.Text = _strToDisplay;
            break;
          }
          listViewItem.SubItems.Add(_strToDisplay);
          break;
        }
      }
      if (!flag)
      {
        if (index1 == 0)
          listViewItem.Text = string.Empty;
        else
          listViewItem.SubItems.Add(string.Empty);
      }
      else
        flag = false;
    }
    this.m_PlantListView.Items.Add(listViewItem);
  }

  private void VerifyFileAndPopulateFamilyTypeSetList(FileInfo _CurrentFile)
  {
    Document CurDocument = (Document) null;
    string str = _CurrentFile.Name.Substring(0, _CurrentFile.Name.Length - _CurrentFile.Extension.Length);
    int num = str.LastIndexOf('.');
    if (num >= 0 && str.Length - 1 == num + 4)
    {
      int result = -1;
      if (int.TryParse(str.Substring(num + 1), out result))
        return;
    }
    bool flag = ManagePlants.IsDocumentOpen(this.m_CurDocument.Application, _CurrentFile.FullName, ref CurDocument);
    if (!flag)
      CurDocument = this.m_CurDocument.Application.OpenDocumentFile(_CurrentFile.FullName);
    EPTransactionContainer transactionContainer = new EPTransactionContainer(CurDocument);
    transactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
    transactionContainer.BeginTransaction();
    List<FamilyTypeContainer> familyTypeContainerList = this.PopulateFamilyTypeSetList(CurDocument.FamilyManager, ManagePlants.PopulateExternalDefinitionList(ManagePlants.GetAllCurPlantingSharedParameters(this.m_CurDocument.Application)));
    transactionContainer.EndTransaction();
    transactionContainer.Rollback();
    if (familyTypeContainerList != null)
    {
      if (this.m_OpenDocumentList == null)
        this.m_OpenDocumentList = new List<Document>();
      if (!flag)
        this.m_OpenDocumentList.Add(CurDocument);
      foreach (FamilyTypeContainer familyTypeContainer in familyTypeContainerList)
        this.m_PlantListFamilyTypeList.Add(familyTypeContainer);
    }
    else
    {
      if (flag)
        return;
      CurDocument.Close(false);
    }
  }

  private void OnPlantListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nPlantListViewSortColumn)
    {
      this.m_nPlantListViewSortColumn = e.Column;
      this.m_PlantListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_PlantListView.Sorting = this.m_PlantListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_PlantListView.Sort();
    this.m_PlantListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_PlantListView.Sorting);
  }

  private void OnDeleteFamiliesButtonClick(object sender, EventArgs e)
  {
    int count;
    if ((count = this.m_PlantListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = count - 1; index1 >= 0; --index1)
      {
        for (int index2 = 0; index2 < this.m_PlantListFamilyTypeList.Count; ++index2)
        {
          if (this.m_PlantListFamilyTypeList[index2].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string) this.m_PlantListView.SelectedItems[index1].Tag, this.m_PlantListFamilyTypeList[index2].FamilyTypeWrapper.FamilyTypeName, true) == 0)
          {
            this.m_PlantListFamilyTypeList[index2].Status = FamilyParameterWrapperStatus.Excluded;
            this.m_PlantListView.SelectedItems[index1].Remove();
            break;
          }
        }
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void OnSearchButtonClicked(object sender, EventArgs e)
  {
    this.SetSelectedPlantList();
    if (ManagePlants.FindFamilyTypes(EPShared.LocalRM.GetString("PlantSearchDialog"), this.m_CurDocument, ref this.m_PlantListFamilyTypeList))
    {
      int listViewSortColumn = this.m_nPlantListViewSortColumn;
      SortOrder sorting = this.m_PlantListView.Sorting;
      for (int index = 0; index < this.m_PlantListView.Items.Count; ++index)
      {
        if (!this.m_PlantListView.SelectedIndices.Contains(index))
        {
          this.m_PlantListView.Items.RemoveAt(index);
          --index;
        }
      }
      this.m_nPlantListViewSortColumn = -1;
      this.m_PlantListView.Sorting = SortOrder.None;
      string empty = string.Empty;
      foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
      {
        if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
          this.PopulatePlantListView(plantListFamilyType);
      }
      if (sorting != SortOrder.None)
      {
        this.m_nPlantListViewSortColumn = listViewSortColumn;
        this.m_PlantListView.Sorting = sorting;
        this.m_PlantListView.Sort();
        this.m_PlantListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(this.m_nPlantListViewSortColumn, this.m_PlantListView.Sorting);
      }
    }
    this.EnableDisableDialogFields(false);
  }

  private void OnColumnDisplayButtonClicked(object sender, EventArgs e)
  {
    using (PlantFieldsForm plantFieldsForm = new PlantFieldsForm(true, "PlantMixSearch"))
    {
      if (plantFieldsForm.ShowDialog() == DialogResult.Cancel)
        return;
      this.LoadColumnSettings();
      this.m_PlantListView.Items.Clear();
      foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
      {
        if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
        {
          plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
          this.PopulatePlantListView(plantListFamilyType);
        }
      }
    }
  }

  private void OnSaveFamilyButton(object sender, EventArgs e)
  {
    if (!this.FindSelectedPlantList(ref this.m_SelectedPlantListFamilyTypeList))
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnSingleFileDirectoryChecked(object sender, EventArgs e)
  {
    if (this.m_SingleFileRadioButton.Checked)
      this.m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    else
      this.m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_DirectoryDialog");
    this.m_RFASingleFileRadioButton.Enabled = this.m_SingleFileRadioButton.Checked;
    this.m_CommaSingleFileRadioButton.Enabled = this.m_SingleFileRadioButton.Checked;
    this.m_TabSingleFileRadioButton.Enabled = this.m_SingleFileRadioButton.Checked;
    this.SetValues();
  }

  private void SetValues()
  {
    if (this.m_DirectoryRadioButton.Checked)
    {
      this.m_SingleFileTextBox.Text = this.m_strCurrentDir;
    }
    else
    {
      if (!this.m_SingleFileRadioButton.Checked)
        return;
      if (this.m_RFASingleFileRadioButton.Checked)
        this.m_SingleFileTextBox.Text = this.m_strRFAFileName;
      else if (this.m_CommaSingleFileRadioButton.Checked)
      {
        this.m_SingleFileTextBox.Text = this.m_strCSVFileName;
      }
      else
      {
        if (!this.m_TabSingleFileRadioButton.Checked)
          return;
        this.m_SingleFileTextBox.Text = this.m_strTABFileName;
      }
    }
  }

  private void SingleFileDirectoryButtonClick(object sender, EventArgs e)
  {
    if (this.m_SingleFileRadioButton.Checked)
    {
      OpenFileDialog openFileDialog = new OpenFileDialog();
      if (this.m_RFASingleFileRadioButton.Checked)
        openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      else if (this.m_CommaSingleFileRadioButton.Checked)
        openFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
      else
        openFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
      openFileDialog.FilterIndex = 1;
      openFileDialog.RestoreDirectory = true;
      if (openFileDialog.ShowDialog() != DialogResult.OK)
        return;
      this.m_SingleFileTextBox.Text = openFileDialog.FileName;
      if (this.m_RFASingleFileRadioButton.Checked)
        this.m_strRFAFileName = openFileDialog.FileName;
      else if (this.m_CommaSingleFileRadioButton.Checked)
        this.m_strCSVFileName = openFileDialog.FileName;
      else if (this.m_TabSingleFileRadioButton.Checked)
        this.m_strTABFileName = openFileDialog.FileName;
      this.LoadData();
    }
    else
    {
      if (!this.m_DirectoryRadioButton.Checked)
        return;
      FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
      folderBrowserDialog.Description = EPShared.LocalRM.GetString("SelectRFADir");
      folderBrowserDialog.ShowNewFolderButton = false;
      if (this.m_SingleFileTextBox.Text != string.Empty)
        folderBrowserDialog.SelectedPath = Path.GetDirectoryName(this.m_SingleFileTextBox.Text);
      if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
        return;
      this.m_SingleFileTextBox.Text = folderBrowserDialog.SelectedPath;
      this.m_strCurrentDir = folderBrowserDialog.SelectedPath;
      this.LoadData();
    }
  }

  private void SetValuesFromText()
  {
    if (this.m_SingleFileRadioButton.Checked)
    {
      if (this.m_RFASingleFileRadioButton.Checked)
        this.m_strRFAFileName = this.m_SingleFileTextBox.Text;
      else if (this.m_CommaSingleFileRadioButton.Checked)
      {
        this.m_strCSVFileName = this.m_SingleFileTextBox.Text;
      }
      else
      {
        if (!this.m_TabSingleFileRadioButton.Checked)
          return;
        this.m_strTABFileName = this.m_SingleFileTextBox.Text;
      }
    }
    else
      this.m_strCurrentDir = this.m_SingleFileTextBox.Text;
  }

  private void OnSingleFileDirectoryTextBoxLeaveFocus(object sender, EventArgs e)
  {
    this.SetValuesFromText();
    this.LoadData();
  }

  private void OnSingleFileDirectoryTextBoxEnter(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.SetValuesFromText();
    this.LoadData();
  }

  private void LoadData()
  {
    if (this.m_DirectoryRadioButton.Checked)
    {
      if (RevitUtility.CompareDirectoryNames(this.m_strSourceDirectory, this.m_SingleFileTextBox.Text) == 0)
        return;
      this.CloseOpenDocuments();
      this.FindRecentFileList();
      this.m_strSourceDirectory = this.m_SingleFileTextBox.Text;
      this.m_PlantListView.Items.Clear();
      this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
      if (this.m_OpenDocumentList != null)
        this.m_OpenDocumentList.Clear();
      if (string.IsNullOrEmpty(this.m_strSourceDirectory))
        return;
      DirectoryInfo directoryInfo = new DirectoryInfo(this.m_strSourceDirectory);
      if (!Directory.Exists(this.m_strSourceDirectory))
        return;
      foreach (FileInfo file in directoryInfo.GetFiles("*.rfa"))
        this.VerifyFileAndPopulateFamilyTypeSetList(file);
    }
    else
    {
      if (!this.m_SingleFileRadioButton.Checked || RevitUtility.CompareFileNames(this.m_strSourceFile, this.m_SingleFileTextBox.Text) == 0)
        return;
      this.CloseOpenDocuments();
      this.FindRecentFileList();
      this.m_strSourceFile = this.m_SingleFileTextBox.Text;
      this.m_PlantListView.Items.Clear();
      this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
      if (this.m_OpenDocumentList != null)
        this.m_OpenDocumentList.Clear();
      if (!string.IsNullOrEmpty(this.m_strSourceFile))
      {
        FileInfo _CurrentFile = new FileInfo(this.m_strSourceFile);
        if (File.Exists(this.m_strSourceFile))
        {
          if (this.m_RFASingleFileRadioButton.Checked)
          {
            if (string.Compare(_CurrentFile.Extension, ".rfa", true) != 0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return;
            }
            this.VerifyFileAndPopulateFamilyTypeSetList(_CurrentFile);
          }
          else
          {
            if (string.Compare(_CurrentFile.Extension, ".txt", true) != 0 && string.Compare(_CurrentFile.Extension, ".csv", true) != 0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoCSVTXT"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return;
            }
            string _strSeparator = string.Empty;
            if (this.m_CommaSingleFileRadioButton.Checked)
              _strSeparator = ",";
            else if (this.m_TabSingleFileRadioButton.Checked)
              _strSeparator = "\t";
            List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
            ImportExport.ImportFileWithSeparator(this.m_CurDocument, this.m_strSourceFile, _strSeparator, ref this.m_PlantListFamilyTypeList);
            foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
              this.PopulatePlantListView(plantListFamilyType);
          }
        }
      }
      if (this.m_PlantListView.Items.Count <= 0)
        return;
      this.EnableDisableDialogFields(true);
    }
  }

  private void OnPlantMixSearchFormClosing(object sender, FormClosingEventArgs e)
  {
    this.CloseOpenDocuments();
    this.SetDialogPosition();
  }

  private void OnShowAllFamiliesButtonClicked(object sender, EventArgs e)
  {
    this.SetSelectedPlantList();
    for (int index = 0; index < this.m_PlantListView.Items.Count; ++index)
    {
      if (!this.m_PlantListView.SelectedIndices.Contains(index))
      {
        this.m_PlantListView.Items.RemoveAt(index);
        --index;
      }
    }
    string empty = string.Empty;
    foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
    {
      if (plantListFamilyType.Status != FamilyParameterWrapperStatus.Selected)
      {
        plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
        this.PopulatePlantListView(plantListFamilyType);
      }
    }
    this.EnableDisableDialogFields(false);
  }

  public List<FamilyTypeContainer> SelectedPlantListFamilyTypeList
  {
    get => this.m_SelectedPlantListFamilyTypeList;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_CancelButton = new Button();
    this.m_SaveFamilyButton = new Button();
    this.m_SourceGroupBox = new GroupBox();
    this.m_SingleFileGroupBox = new GroupBox();
    this.m_TabSingleFileRadioButton = new RadioButton();
    this.m_CommaSingleFileRadioButton = new RadioButton();
    this.m_RFASingleFileRadioButton = new RadioButton();
    this.m_DirectoryRadioButton = new RadioButton();
    this.m_SingleFileRadioButton = new RadioButton();
    this.m_SingleFileTextBox = new TextBox();
    this.m_SingleFileLabel = new Label();
    this.m_SingleFileButton = new Button();
    this.m_CollectionGroupBox = new GroupBox();
    this.m_ShowAllFamiliesButton = new Button();
    this.m_ColumnDisplayButton = new Button();
    this.m_SearchButton = new Button();
    this.m_PlantListView = new ListView();
    this.m_SourceGroupBox.SuspendLayout();
    this.m_SingleFileGroupBox.SuspendLayout();
    this.m_CollectionGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(526, 385);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(77, 23);
    this.m_CancelButton.TabIndex = 3;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClicked);
    this.m_SaveFamilyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_SaveFamilyButton.Location = new Point(435, 385);
    this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
    this.m_SaveFamilyButton.Size = new Size(85, 23);
    this.m_SaveFamilyButton.TabIndex = 2;
    this.m_SaveFamilyButton.Text = "&Add to Family";
    this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
    this.m_SaveFamilyButton.Click += new EventHandler(this.OnSaveFamilyButton);
    this.m_SourceGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileGroupBox);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_DirectoryRadioButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileRadioButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileTextBox);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileLabel);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileButton);
    this.m_SourceGroupBox.Location = new Point(12, 5);
    this.m_SourceGroupBox.Name = "m_SourceGroupBox";
    this.m_SourceGroupBox.Size = new Size(591, 128 /*0x80*/);
    this.m_SourceGroupBox.TabIndex = 0;
    this.m_SourceGroupBox.TabStop = false;
    this.m_SourceGroupBox.Text = "Source";
    this.m_SingleFileGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SingleFileGroupBox.Controls.Add((Control) this.m_TabSingleFileRadioButton);
    this.m_SingleFileGroupBox.Controls.Add((Control) this.m_CommaSingleFileRadioButton);
    this.m_SingleFileGroupBox.Controls.Add((Control) this.m_RFASingleFileRadioButton);
    this.m_SingleFileGroupBox.Location = new Point(6, 37);
    this.m_SingleFileGroupBox.Name = "m_SingleFileGroupBox";
    this.m_SingleFileGroupBox.Size = new Size(574, 56);
    this.m_SingleFileGroupBox.TabIndex = 2;
    this.m_SingleFileGroupBox.TabStop = false;
    this.m_SingleFileGroupBox.Text = "Single File";
    this.m_TabSingleFileRadioButton.AutoSize = true;
    this.m_TabSingleFileRadioButton.Location = new Point(362, 23);
    this.m_TabSingleFileRadioButton.Name = "m_TabSingleFileRadioButton";
    this.m_TabSingleFileRadioButton.Size = new Size(139, 17);
    this.m_TabSingleFileRadioButton.TabIndex = 2;
    this.m_TabSingleFileRadioButton.TabStop = true;
    this.m_TabSingleFileRadioButton.Text = "&Tab Delimited (Text File)";
    this.m_TabSingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_CommaSingleFileRadioButton.AutoSize = true;
    this.m_CommaSingleFileRadioButton.Location = new Point(158, 23);
    this.m_CommaSingleFileRadioButton.Name = "m_CommaSingleFileRadioButton";
    this.m_CommaSingleFileRadioButton.Size = new Size(155, 17);
    this.m_CommaSingleFileRadioButton.TabIndex = 1;
    this.m_CommaSingleFileRadioButton.TabStop = true;
    this.m_CommaSingleFileRadioButton.Text = "&Comma Delimited (CSV File)";
    this.m_CommaSingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_RFASingleFileRadioButton.AutoSize = true;
    this.m_RFASingleFileRadioButton.Location = new Point(6, 25);
    this.m_RFASingleFileRadioButton.Name = "m_RFASingleFileRadioButton";
    this.m_RFASingleFileRadioButton.Size = new Size(103, 17);
    this.m_RFASingleFileRadioButton.TabIndex = 0;
    this.m_RFASingleFileRadioButton.TabStop = true;
    this.m_RFASingleFileRadioButton.Text = "&RFA (Family File)";
    this.m_RFASingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_DirectoryRadioButton.AutoSize = true;
    this.m_DirectoryRadioButton.Location = new Point(164, 15);
    this.m_DirectoryRadioButton.Name = "m_DirectoryRadioButton";
    this.m_DirectoryRadioButton.Size = new Size(168, 17);
    this.m_DirectoryRadioButton.TabIndex = 1;
    this.m_DirectoryRadioButton.TabStop = true;
    this.m_DirectoryRadioButton.Text = "&Directory (Multiple Family Files)";
    this.m_DirectoryRadioButton.UseVisualStyleBackColor = true;
    this.m_DirectoryRadioButton.CheckedChanged += new EventHandler(this.OnSingleFileDirectoryChecked);
    this.m_SingleFileRadioButton.AutoSize = true;
    this.m_SingleFileRadioButton.Location = new Point(12, 15);
    this.m_SingleFileRadioButton.Name = "m_SingleFileRadioButton";
    this.m_SingleFileRadioButton.Size = new Size(73, 17);
    this.m_SingleFileRadioButton.TabIndex = 0;
    this.m_SingleFileRadioButton.TabStop = true;
    this.m_SingleFileRadioButton.Text = "&Single File";
    this.m_SingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_SingleFileRadioButton.CheckedChanged += new EventHandler(this.OnSingleFileDirectoryChecked);
    this.m_SingleFileTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SingleFileTextBox.Location = new Point(79, 99);
    this.m_SingleFileTextBox.Name = "m_SingleFileTextBox";
    this.m_SingleFileTextBox.Size = new Size(472, 20);
    this.m_SingleFileTextBox.TabIndex = 4;
    this.m_SingleFileTextBox.KeyDown += new KeyEventHandler(this.OnSingleFileDirectoryTextBoxEnter);
    this.m_SingleFileTextBox.Leave += new EventHandler(this.OnSingleFileDirectoryTextBoxLeaveFocus);
    this.m_SingleFileLabel.AutoSize = true;
    this.m_SingleFileLabel.Location = new Point(9, 103);
    this.m_SingleFileLabel.Name = "m_SingleFileLabel";
    this.m_SingleFileLabel.Size = new Size(26, 13);
    this.m_SingleFileLabel.TabIndex = 3;
    this.m_SingleFileLabel.Text = "&File:";
    this.m_SingleFileButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_SingleFileButton.Location = new Point(557, 99);
    this.m_SingleFileButton.Name = "m_SingleFileButton";
    this.m_SingleFileButton.Size = new Size(24, 20);
    this.m_SingleFileButton.TabIndex = 5;
    this.m_SingleFileButton.TabStop = false;
    this.m_SingleFileButton.Text = "...";
    this.m_SingleFileButton.UseVisualStyleBackColor = true;
    this.m_SingleFileButton.Click += new EventHandler(this.SingleFileDirectoryButtonClick);
    this.m_CollectionGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_CollectionGroupBox.Controls.Add((Control) this.m_ShowAllFamiliesButton);
    this.m_CollectionGroupBox.Controls.Add((Control) this.m_ColumnDisplayButton);
    this.m_CollectionGroupBox.Controls.Add((Control) this.m_SearchButton);
    this.m_CollectionGroupBox.Controls.Add((Control) this.m_PlantListView);
    this.m_CollectionGroupBox.Location = new Point(13, 140);
    this.m_CollectionGroupBox.Name = "m_CollectionGroupBox";
    this.m_CollectionGroupBox.Size = new Size(590, 239);
    this.m_CollectionGroupBox.TabIndex = 1;
    this.m_CollectionGroupBox.TabStop = false;
    this.m_CollectionGroupBox.Text = "Plant Collection";
    this.m_ShowAllFamiliesButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ShowAllFamiliesButton.Location = new Point(480, 71);
    this.m_ShowAllFamiliesButton.Name = "m_ShowAllFamiliesButton";
    this.m_ShowAllFamiliesButton.Size = new Size(100, 23);
    this.m_ShowAllFamiliesButton.TabIndex = 3;
    this.m_ShowAllFamiliesButton.Text = "Show &All";
    this.m_ShowAllFamiliesButton.UseVisualStyleBackColor = true;
    this.m_ShowAllFamiliesButton.Click += new EventHandler(this.OnShowAllFamiliesButtonClicked);
    this.m_ColumnDisplayButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ColumnDisplayButton.Location = new Point(479, 42);
    this.m_ColumnDisplayButton.Name = "m_ColumnDisplayButton";
    this.m_ColumnDisplayButton.Size = new Size(100, 23);
    this.m_ColumnDisplayButton.TabIndex = 2;
    this.m_ColumnDisplayButton.Text = "Colu&mn Display";
    this.m_ColumnDisplayButton.UseVisualStyleBackColor = true;
    this.m_ColumnDisplayButton.Click += new EventHandler(this.OnColumnDisplayButtonClicked);
    this.m_SearchButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_SearchButton.Location = new Point(479, 13);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(101, 23);
    this.m_SearchButton.TabIndex = 1;
    this.m_SearchButton.Text = "Searc&h";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButtonClicked);
    this.m_PlantListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_PlantListView.FullRowSelect = true;
    this.m_PlantListView.HideSelection = false;
    this.m_PlantListView.Location = new Point(6, 13);
    this.m_PlantListView.Name = "m_PlantListView";
    this.m_PlantListView.Size = new Size(465, 220);
    this.m_PlantListView.TabIndex = 0;
    this.m_PlantListView.UseCompatibleStateImageBehavior = false;
    this.m_PlantListView.ColumnClick += new ColumnClickEventHandler(this.OnPlantListViewColumnClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(613, 420);
    this.Controls.Add((Control) this.m_CollectionGroupBox);
    this.Controls.Add((Control) this.m_SourceGroupBox);
    this.Controls.Add((Control) this.m_SaveFamilyButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.MinimumSize = new Size(621, 447);
    this.Name = nameof (PlantMixSearchForm);
    this.Text = "Plant Search Manager";
    this.FormClosing += new FormClosingEventHandler(this.OnPlantMixSearchFormClosing);
    this.m_SourceGroupBox.ResumeLayout(false);
    this.m_SourceGroupBox.PerformLayout();
    this.m_SingleFileGroupBox.ResumeLayout(false);
    this.m_SingleFileGroupBox.PerformLayout();
    this.m_CollectionGroupBox.ResumeLayout(false);
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_SaveFamilyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
