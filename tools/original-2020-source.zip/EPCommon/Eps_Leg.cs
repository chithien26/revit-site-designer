﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_Leg
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class Eps_Leg
{
  private bool m_bIs3D;
  private int m_nDrawingType;
  private Eps_Arc m_Arc;
  private Eps_Line m_Line;
  private NurbSpline m_NurbSpline;
  private HermiteSpline m_HermiteSpline;
  private int m_nSplineNum;
  private Eps_Leg m_Next;
  private Element m_Element;
  private bool m_bIsReverse;

  public Eps_Leg()
  {
    this.m_bIs3D = false;
    this.m_nDrawingType = 0;
    this.m_nSplineNum = -1;
  }

  public bool IsEqual(Eps_Leg another)
  {
    if (this.Is3D != another.Is3D || this.DrawingType != another.DrawingType || this.SplineNum != another.SplineNum)
      return false;
    if (this.Element == another.Element)
    {
      if (this.Element != null && ElementId.op_Inequality(this.Element.Id, another.Element.Id))
        return false;
    }
    else if (this.Element == null || another.Element == null || ElementId.op_Inequality(this.Element.Id, another.Element.Id))
      return false;
    if (this.Arc == null && another.Arc != null || this.Arc != null && another.Arc == null || this.Arc != null && another.Arc != null && !this.Arc.IsEqual((BaseArc) another.Arc) || this.Line == null && another.Line != null || this.Line != null && another.Line == null || this.Line != null && another.Line != null && !this.Line.IsEqual((BaseLine) another.Line))
      return false;
    Eps_Leg next1 = this.Next;
    Eps_Leg next2 = another.Next;
    if (next1 == null && next2 != null || next1 != null && next2 == null)
      return false;
    if (next1 == null && next2 == null)
      return true;
    while (next1 != null)
    {
      if (!next1.IsEqual(next2))
        return false;
    }
    return true;
  }

  public bool IsLegClosed()
  {
    return this.LegCount > 0 && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(this), 0.0) && EPShared.eplGeoE_ArePntsDuplicates2D(this.LegStartPnt, this.LegEndPnt);
  }

  public bool IsArcInLeg(Eps_Arc _CompareArc)
  {
    for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.m_Next)
    {
      if (epsLeg.Arc != null && epsLeg.Arc.IsEqual((BaseArc) _CompareArc))
        return true;
    }
    return false;
  }

  public bool IsLineInLeg(Eps_Line _CompareLine)
  {
    for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.m_Next)
    {
      if (epsLeg.Line != null && epsLeg.Line.IsEqual((BaseLine) _CompareLine))
        return true;
    }
    return false;
  }

  public static Eps_Leg CopyLeg(Eps_Leg _CompleteLeg)
  {
    Eps_Leg epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg);
    for (Eps_Leg epsLeg2 = _CompleteLeg; epsLeg2.Next != null; epsLeg2 = epsLeg2.Next)
      epsLeg1.Last.Next = Eps_Leg.SingleLeg(epsLeg2.Next);
    return epsLeg1;
  }

  public static Eps_Leg SingleLeg(Eps_Leg _CompleteLeg)
  {
    return new Eps_Leg()
    {
      Is3D = _CompleteLeg.Is3D,
      DrawingType = _CompleteLeg.DrawingType,
      SplineNum = _CompleteLeg.SplineNum,
      Element = _CompleteLeg.Element,
      HermiteSpline = _CompleteLeg.HermiteSpline,
      NurbSpline = _CompleteLeg.NurbSpline,
      Arc = _CompleteLeg.Arc,
      Line = _CompleteLeg.Line,
      Next = (Eps_Leg) null
    };
  }

  public Eps_Leg Reverse()
  {
    List<Eps_Leg> epsLegList = new List<Eps_Leg>();
    for (Eps_Leg _CompleteLeg = this; _CompleteLeg != null; _CompleteLeg = _CompleteLeg.Next)
      epsLegList.Add(Eps_Leg.SingleLeg(_CompleteLeg));
    if (epsLegList.Count <= 0)
      return (Eps_Leg) null;
    Eps_Leg epsLeg1 = new Eps_Leg();
    for (int index = epsLegList.Count - 1; index >= 0; --index)
    {
      Eps_Leg epsLeg2 = epsLegList[index];
      if (epsLeg2.Arc != null)
        epsLeg2.Arc = epsLeg2.Arc.Reverse();
      else if (epsLeg2.Line != null)
        epsLeg2.Line = epsLeg2.Line.Reverse();
      if (index == epsLegList.Count - 1)
        epsLeg1 = epsLeg2;
      else
        epsLeg1.Last.Next = epsLeg2;
    }
    epsLeg1.IsReverse = !this.m_bIsReverse;
    return epsLeg1;
  }

  public Autodesk.Revit.DB.CurveArray CurveArray(UIDocument _CurDocument)
  {
    return this.CurveArray(_CurDocument.Document);
  }

  public Autodesk.Revit.DB.CurveArray CurveArray(Document _CurDocument)
  {
    Autodesk.Revit.DB.CurveArray curveArray = new Autodesk.Revit.DB.CurveArray();
    for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        if (!EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, 1.0 / 400.0))
          curveArray.Append((Curve) epsLeg.Line.RevitLine(_CurDocument));
      }
      else if (epsLeg.Arc != null && epsLeg.Arc.Radius > 0.0)
        curveArray.Append((Curve) epsLeg.Arc.RevitArc(_CurDocument));
    }
    return curveArray;
  }

  public void ConvertLegToLineArcArrays(
    ref Eps_Line[] aLines,
    ref int nLineCount,
    ref Eps_Arc[] aArcs,
    ref int nArcCount,
    ref int[] aLegOrder,
    bool _bExtendLeg)
  {
    this.ConvertLegToLineArcArrays(ref aLines, ref nLineCount, ref aArcs, ref nArcCount, ref aLegOrder, (List<TopographySurfaceContainer>) null, false, false, 0.0, (Phase) null, _bExtendLeg, (List<Eps_Point>) null);
  }

  public void ConvertLegToLineArcArrays(
    ref Eps_Line[] aLines,
    ref int nLineCount,
    ref Eps_Arc[] aArcs,
    ref int nArcCount,
    ref int[] aLegOrder,
    TopographySurfaceContainer _SurfaceContainer,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dElevation,
    bool _bExtendLeg)
  {
    List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
    if (_SurfaceContainer != null)
      _SurfaceList.Add(_SurfaceContainer);
    this.ConvertLegToLineArcArrays(ref aLines, ref nLineCount, ref aArcs, ref nArcCount, ref aLegOrder, _SurfaceList, _bUseToposurfaceElevation, _bUseConstantElevation, _dElevation, (Phase) null, _bExtendLeg, (List<Eps_Point>) null);
  }

  public void ConvertLegToLineArcArrays(
    ref Eps_Line[] aLines,
    ref int nLineCount,
    ref Eps_Arc[] aArcs,
    ref int nArcCount,
    ref int[] aLegOrder,
    TopographySurfaceContainer _SurfaceContainer,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dElevation,
    bool _bExtendLeg,
    List<Eps_Point> _ApplySurfaceElevationPoints)
  {
    List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
    if (_SurfaceContainer != null)
      _SurfaceList.Add(_SurfaceContainer);
    this.ConvertLegToLineArcArrays(ref aLines, ref nLineCount, ref aArcs, ref nArcCount, ref aLegOrder, _SurfaceList, _bUseToposurfaceElevation, _bUseConstantElevation, _dElevation, (Phase) null, _bExtendLeg, _ApplySurfaceElevationPoints);
  }

  public void ConvertLegToLineArcArrays(
    ref Eps_Line[] aLines,
    ref int nLineCount,
    ref Eps_Arc[] aArcs,
    ref int nArcCount,
    ref int[] aLegOrder,
    List<TopographySurfaceContainer> _SurfaceList,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dElevation,
    Phase _CurPhase,
    bool _bExtendLeg,
    List<Eps_Point> _ApplySurfaceElevationPoints)
  {
    List<Eps_Line> epsLineList = new List<Eps_Line>();
    List<Eps_Arc> epsArcList = new List<Eps_Arc>();
    List<int> intList = new List<int>();
    double _dDirection = 0.0;
    Eps_Leg epsLeg = this;
    bool flag1 = true;
    double _dElevation1 = 0.0;
    double _dElevation2 = 0.0;
    bool flag2 = false;
    bool flag3 = false;
    while (epsLeg != null)
    {
      Eps_Point _NewPnt;
      if (epsLeg.Line != null)
      {
        Eps_Line epsLine = new Eps_Line(epsLeg.Line);
        if (_ApplySurfaceElevationPoints != null)
        {
          for (int index = 0; index < _ApplySurfaceElevationPoints.Count; ++index)
          {
            if (epsLine.StartPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag2 = true;
              epsLine.StartPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag3)
                break;
            }
            else if (epsLine.EndPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag3 = true;
              epsLine.EndPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag2)
                break;
            }
          }
        }
        if (_bExtendLeg && flag1 && !this.IsLegClosed())
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLine.EndPnt, epsLine.StartPnt, ref _dDirection);
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, _dDirection, 0.01, ref _NewPnt);
          epsLine.StartPnt.x = _NewPnt.x;
          epsLine.StartPnt.y = _NewPnt.y;
        }
        if (!flag2)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(epsLine.StartPnt, _SurfaceList, _CurPhase, ref _dElevation1);
            else
              _dElevation1 = epsLine.StartPnt.z;
            epsLine.StartPnt.z = _dElevation1 + _dElevation;
          }
          else if (_bUseConstantElevation)
            epsLine.StartPnt.z = _dElevation;
        }
        else
          flag2 = false;
        if (!flag3)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(epsLine.EndPnt, _SurfaceList, _CurPhase, ref _dElevation2);
            else
              _dElevation2 = epsLine.EndPnt.z;
            epsLine.EndPnt.z = _dElevation2 + _dElevation;
          }
          else if (_bUseConstantElevation)
            epsLine.EndPnt.z = _dElevation;
        }
        else
          flag3 = false;
        if (_bExtendLeg && epsLeg.Next == null && !this.IsLegClosed())
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDirection);
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, _dDirection, 0.01, ref _NewPnt);
          epsLine.EndPnt.x = _NewPnt.x;
          epsLine.EndPnt.y = _NewPnt.y;
        }
        epsLineList.Add(epsLine);
        intList.Add(0);
      }
      else if (epsLeg.Arc != null)
      {
        Eps_Arc epsArc = new Eps_Arc(epsLeg.Arc);
        if (_ApplySurfaceElevationPoints != null)
        {
          for (int index = 0; index < _ApplySurfaceElevationPoints.Count; ++index)
          {
            if (epsArc.StartPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag2 = true;
              epsArc.StartPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag3)
                break;
            }
            else if (epsArc.EndPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag3 = true;
              epsArc.EndPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag2)
                break;
            }
          }
        }
        if (_bExtendLeg && flag1 && !this.IsLegClosed())
        {
          double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsArc.Radius, epsArc.Delta) + 0.01;
          epsArc.Delta = num / epsArc.Radius;
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsArc.RadiusPnt, epsArc.EndPnt, ref _dDirection);
          if (epsArc.Direction == -1)
            _dDirection += epsArc.Delta;
          else
            _dDirection -= epsArc.Delta;
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(epsArc.RadiusPnt, _dDirection, epsArc.Radius, ref _NewPnt);
          epsArc.StartPnt.x = _NewPnt.x;
          epsArc.StartPnt.y = _NewPnt.y;
        }
        if (!flag2)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(epsArc.StartPnt, _SurfaceList, _CurPhase, ref _dElevation1);
            else
              _dElevation1 = epsArc.StartPnt.z;
            epsArc.StartPnt.z = _dElevation1 + _dElevation;
          }
          else if (_bUseConstantElevation)
            epsArc.StartPnt.z = _dElevation;
        }
        else
          flag2 = false;
        if (!flag3)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(epsArc.EndPnt, _SurfaceList, _CurPhase, ref _dElevation2);
            else
              _dElevation2 = epsArc.EndPnt.z;
            epsArc.EndPnt.z = _dElevation2 + _dElevation;
          }
          else if (_bUseConstantElevation)
            epsArc.EndPnt.z = _dElevation;
        }
        else
          flag3 = false;
        epsArc.RadiusPnt.z = (epsArc.StartPnt.z + epsArc.EndPnt.z) / 2.0;
        if (_bExtendLeg && epsLeg.Next == null && !this.IsLegClosed())
        {
          double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsArc.Radius, epsArc.Delta) + 0.01;
          epsArc.Delta = num / epsArc.Radius;
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsArc.RadiusPnt, epsArc.StartPnt, ref _dDirection);
          if (epsArc.Direction == -1)
            _dDirection -= epsArc.Delta;
          else
            _dDirection += epsArc.Delta;
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(epsArc.RadiusPnt, _dDirection, epsArc.Radius, ref _NewPnt);
          epsArc.EndPnt.x = _NewPnt.x;
          epsArc.EndPnt.y = _NewPnt.y;
        }
        epsArcList.Add(epsArc);
        intList.Add(1);
      }
      epsLeg = epsLeg.Next;
      flag1 = false;
    }
    aLines = epsLineList.ToArray();
    aArcs = epsArcList.ToArray();
    aLegOrder = intList.ToArray();
    nLineCount = epsLineList.Count;
    nArcCount = epsArcList.Count;
  }

  public static Eps_Leg ConvertLineArcArraysToLeg(
    Eps_Line[] aLines,
    int nLineCount,
    Eps_Arc[] aArcs,
    int nArcCount,
    int[] aLegOrder)
  {
    int index1 = 0;
    int index2 = 0;
    Eps_Leg leg = (Eps_Leg) null;
    for (int index3 = 0; index3 < nLineCount + nArcCount; ++index3)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (aLegOrder[index3] == 0)
      {
        _CompleteLeg.Line = new Eps_Line(aLines[index1]);
        _CompleteLeg.Element = (Element) null;
        if (leg == null)
          leg = Eps_Leg.SingleLeg(_CompleteLeg);
        else
          leg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
        ++index1;
      }
      else if (aLegOrder[index3] == 1)
      {
        _CompleteLeg.Arc = new Eps_Arc(aArcs[index2]);
        _CompleteLeg.Element = (Element) null;
        if (leg == null)
          leg = Eps_Leg.SingleLeg(_CompleteLeg);
        else
          leg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
        ++index2;
      }
    }
    return leg;
  }

  public static double FindMinimumDistanceBetweenLegs(Eps_Leg _FirstLegList, Eps_Leg _SecondLegList)
  {
    double maxValue1 = double.MaxValue;
    double maxValue2 = double.MaxValue;
    double maxValue3 = double.MaxValue;
    double maxValue4 = double.MaxValue;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstLegList.LegStartPnt, _SecondLegList.LegStartPnt, ref maxValue1);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstLegList.LegStartPnt, _SecondLegList.LegEndPnt, ref maxValue2);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstLegList.LegEndPnt, _SecondLegList.LegStartPnt, ref maxValue3);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstLegList.LegEndPnt, _SecondLegList.LegEndPnt, ref maxValue4);
    return Math.Min(maxValue1, Math.Min(maxValue2, Math.Min(maxValue3, maxValue4)));
  }

  public static void CombineLegListsAtShortestGaps(
    ref Eps_Leg _CombinedLegList,
    Eps_Leg _AddLegList)
  {
    double maxValue1 = double.MaxValue;
    double maxValue2 = double.MaxValue;
    double maxValue3 = double.MaxValue;
    double maxValue4 = double.MaxValue;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CombinedLegList.LegStartPnt, _AddLegList.LegStartPnt, ref maxValue1);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CombinedLegList.LegStartPnt, _AddLegList.LegEndPnt, ref maxValue2);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CombinedLegList.LegEndPnt, _AddLegList.LegStartPnt, ref maxValue3);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CombinedLegList.LegEndPnt, _AddLegList.LegEndPnt, ref maxValue4);
    double num = Math.Min(maxValue1, Math.Min(maxValue2, Math.Min(maxValue3, maxValue4)));
    if (num == maxValue1 || num == maxValue2)
    {
      Eps_Leg epsLeg1 = num != maxValue1 ? Eps_Leg.CopyLeg(_AddLegList) : Eps_Leg.CopyLeg(_AddLegList.Reverse());
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg1.LegEndPnt, _CombinedLegList.LegStartPnt))
      {
        Eps_Leg epsLeg2 = new Eps_Leg();
        epsLeg2.Line = new Eps_Line();
        epsLeg2.Line.StartPnt = epsLeg1.LegEndPnt;
        epsLeg2.Line.EndPnt = _CombinedLegList.LegStartPnt;
        epsLeg1.Last.Next = epsLeg2;
      }
      epsLeg1.Last.Next = _CombinedLegList;
      _CombinedLegList = epsLeg1;
    }
    else
    {
      if (num != maxValue3 && num != maxValue4)
        return;
      Eps_Leg epsLeg = num != maxValue3 ? Eps_Leg.CopyLeg(_AddLegList.Reverse()) : Eps_Leg.CopyLeg(_AddLegList);
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CombinedLegList.LegEndPnt, epsLeg.LegStartPnt))
      {
        Eps_Leg _CompleteLeg = new Eps_Leg();
        _CompleteLeg.Line = new Eps_Line();
        _CompleteLeg.Line.StartPnt = _CombinedLegList.LegEndPnt;
        _CompleteLeg.Line.EndPnt = epsLeg.LegStartPnt;
        _CombinedLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
      }
      _CombinedLegList.Last.Next = epsLeg;
    }
  }

  public static bool InsertLineLegSegment(ref Eps_Leg _CurrentLeg, Eps_Line _CurrentLine)
  {
    return Eps_Leg.InsertLineLegSegment(ref _CurrentLeg, _CurrentLine, false);
  }

  public static bool InsertLineLegSegment(
    ref Eps_Leg _CurrentLeg,
    Eps_Line _CurrentLine,
    bool _bAppendToEndOnly)
  {
    bool flag = false;
    if (_CurrentLeg == null)
    {
      _CurrentLeg = new Eps_Leg();
      _CurrentLeg.Line = _CurrentLine;
      flag = true;
    }
    else if (_CurrentLeg.Line != null && _CurrentLeg.Line.IsEqual((BaseLine) _CurrentLine) || _CurrentLeg.Last.Line != null && _CurrentLeg.Last.Line.IsEqual((BaseLine) _CurrentLine))
      flag = true;
    else if (_CurrentLeg.LegEndPnt.IsEqual(_CurrentLine.StartPnt))
    {
      _CurrentLeg.Last.Next = new Eps_Leg()
      {
        Line = _CurrentLine
      };
      flag = true;
    }
    else if (_CurrentLeg.LegEndPnt.IsEqual(_CurrentLine.EndPnt))
    {
      _CurrentLeg.Last.Next = new Eps_Leg()
      {
        Line = _CurrentLine.Reverse()
      };
      flag = true;
    }
    else if (_CurrentLeg.LegStartPnt.IsEqual(_CurrentLine.StartPnt) && !_bAppendToEndOnly)
    {
      _CurrentLeg = new Eps_Leg()
      {
        Line = _CurrentLine.Reverse(),
        Last = {
          Next = _CurrentLeg
        }
      };
      flag = true;
    }
    else if (_CurrentLeg.LegStartPnt.IsEqual(_CurrentLine.EndPnt) && !_bAppendToEndOnly)
    {
      _CurrentLeg = new Eps_Leg()
      {
        Line = _CurrentLine,
        Last = {
          Next = _CurrentLeg
        }
      };
      flag = true;
    }
    return flag;
  }

  public static bool InsertArcLegSegment(ref Eps_Leg _CurrentLeg, Eps_Arc _CurrentArc)
  {
    return Eps_Leg.InsertArcLegSegment(ref _CurrentLeg, _CurrentArc, false);
  }

  public static bool InsertArcLegSegment(
    ref Eps_Leg _CurrentLeg,
    Eps_Arc _CurrentArc,
    bool _bAppendToEndOnly)
  {
    bool flag = false;
    if (_CurrentLeg == null)
    {
      _CurrentLeg = new Eps_Leg();
      _CurrentLeg.Arc = _CurrentArc;
      flag = true;
    }
    else if (_CurrentLeg.Arc != null && _CurrentLeg.Arc.IsEqual((BaseArc) _CurrentArc) || _CurrentLeg.Last.Arc != null && _CurrentLeg.Last.Arc.IsEqual((BaseArc) _CurrentArc))
      flag = true;
    else if (_CurrentLeg.LegEndPnt.IsEqual(_CurrentArc.StartPnt))
    {
      _CurrentLeg.Last.Next = new Eps_Leg()
      {
        Arc = _CurrentArc
      };
      flag = true;
    }
    else if (_CurrentLeg.LegEndPnt.IsEqual(_CurrentArc.EndPnt))
    {
      _CurrentLeg.Last.Next = new Eps_Leg()
      {
        Arc = _CurrentArc.Reverse()
      };
      flag = true;
    }
    else if (_CurrentLeg.LegStartPnt.IsEqual(_CurrentArc.StartPnt) && !_bAppendToEndOnly)
    {
      _CurrentLeg = new Eps_Leg()
      {
        Arc = _CurrentArc.Reverse(),
        Last = {
          Next = _CurrentLeg
        }
      };
      flag = true;
    }
    else if (_CurrentLeg.LegStartPnt.IsEqual(_CurrentArc.EndPnt) && !_bAppendToEndOnly)
    {
      _CurrentLeg = new Eps_Leg()
      {
        Arc = _CurrentArc,
        Last = {
          Next = _CurrentLeg
        }
      };
      flag = true;
    }
    return flag;
  }

  public static bool InsertLeg(ref Eps_Leg _CurrentLeg, Eps_Leg _AddLeg)
  {
    bool flag = false;
    if (_CurrentLeg == null)
    {
      _CurrentLeg = Eps_Leg.CopyLeg(_AddLeg);
      flag = true;
    }
    else if (_CurrentLeg.LegStartPnt.IsEqual(_AddLeg.LegStartPnt))
    {
      Eps_Leg epsLeg = Eps_Leg.CopyLeg(_AddLeg.Reverse());
      epsLeg.Last.Next = _CurrentLeg;
      _CurrentLeg = epsLeg;
      flag = true;
    }
    else if (_CurrentLeg.LegStartPnt.IsEqual(_AddLeg.LegEndPnt))
    {
      Eps_Leg epsLeg = Eps_Leg.CopyLeg(_AddLeg);
      epsLeg.Last.Next = _CurrentLeg;
      _CurrentLeg = epsLeg;
      flag = true;
    }
    else if (_CurrentLeg.LegEndPnt.IsEqual(_AddLeg.LegStartPnt))
    {
      Eps_Leg epsLeg = Eps_Leg.CopyLeg(_AddLeg);
      _CurrentLeg.Last.Next = epsLeg;
      flag = true;
    }
    else if (_CurrentLeg.LegEndPnt.IsEqual(_AddLeg.LegEndPnt))
    {
      Eps_Leg epsLeg = Eps_Leg.CopyLeg(_AddLeg.Reverse());
      _CurrentLeg.Last.Next = epsLeg;
      flag = true;
    }
    return flag;
  }

  public Eps_Leg ApplyElevationsToLeg()
  {
    return this.ApplyElevationsToLeg((List<TopographySurfaceContainer>) null, false, false, 0.0, (Phase) null, (List<Eps_Point>) null);
  }

  public Eps_Leg ApplyElevationsToLeg(
    TopographySurfaceContainer _SurfaceContainer,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dConstElevation)
  {
    return this.ApplyElevationsToLeg(new List<TopographySurfaceContainer>()
    {
      _SurfaceContainer
    }, _bUseToposurfaceElevation, _bUseConstantElevation, _dConstElevation, (Phase) null, (List<Eps_Point>) null);
  }

  public Eps_Leg ApplyElevationsToLeg(
    List<TopographySurfaceContainer> _SurfaceList,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dConstElevation,
    Phase _CurPhase)
  {
    return this.ApplyElevationsToLeg(_SurfaceList, _bUseToposurfaceElevation, _bUseConstantElevation, _dConstElevation, _CurPhase, (List<Eps_Point>) null);
  }

  public Eps_Leg ApplyElevationsToLeg(
    TopographySurfaceContainer _SurfaceContainer,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dConstElevation,
    List<Eps_Point> _ApplySurfaceElevationPoints)
  {
    List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
    if (_SurfaceContainer != null)
      _SurfaceList.Add(_SurfaceContainer);
    return this.ApplyElevationsToLeg(_SurfaceList, _bUseToposurfaceElevation, _bUseConstantElevation, _dConstElevation, (Phase) null, _ApplySurfaceElevationPoints);
  }

  public Eps_Leg ApplyElevationsToLeg(
    List<TopographySurfaceContainer> _SurfaceList,
    bool _bUseToposurfaceElevation,
    bool _bUseConstantElevation,
    double _dConstElevation,
    Phase _CurPhase,
    List<Eps_Point> _ApplySurfaceElevationPoints)
  {
    Eps_Leg leg = (Eps_Leg) null;
    double _dElevation1 = 0.0;
    double _dElevation2 = 0.0;
    bool flag1 = false;
    bool flag2 = false;
    for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg.Line);
        if (_ApplySurfaceElevationPoints != null)
        {
          for (int index = 0; index < _ApplySurfaceElevationPoints.Count; ++index)
          {
            if (_CompleteLeg.Line.StartPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag1 = true;
              _CompleteLeg.Line.StartPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag2)
                break;
            }
            else if (_CompleteLeg.Line.EndPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag2 = true;
              _CompleteLeg.Line.EndPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag1)
                break;
            }
          }
        }
        if (!flag1)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(_CompleteLeg.Line.StartPnt, _SurfaceList, _CurPhase, ref _dElevation1);
            else
              _dElevation1 = _CompleteLeg.Line.StartPnt.z;
            _CompleteLeg.Line.StartPnt.z = _dElevation1 + _dConstElevation;
          }
          else if (_bUseConstantElevation)
            _CompleteLeg.Line.StartPnt.z = _dConstElevation;
        }
        else
          flag1 = false;
        if (!flag2)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(_CompleteLeg.Line.EndPnt, _SurfaceList, _CurPhase, ref _dElevation2);
            else
              _dElevation2 = _CompleteLeg.Line.EndPnt.z;
            _CompleteLeg.Line.EndPnt.z = _dElevation2 + _dConstElevation;
          }
          else if (_bUseConstantElevation)
            _CompleteLeg.Line.EndPnt.z = _dConstElevation;
        }
        else
          flag2 = false;
      }
      else if (epsLeg.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg.Arc);
        if (_ApplySurfaceElevationPoints != null)
        {
          for (int index = 0; index < _ApplySurfaceElevationPoints.Count; ++index)
          {
            if (_CompleteLeg.Arc.StartPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag1 = true;
              _CompleteLeg.Arc.StartPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag2)
                break;
            }
            else if (_CompleteLeg.Arc.EndPnt.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag2 = true;
              _CompleteLeg.Arc.EndPnt.z = _ApplySurfaceElevationPoints[index].z;
              if (flag1)
                break;
            }
          }
        }
        if (!flag1)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(_CompleteLeg.Arc.StartPnt, _SurfaceList, _CurPhase, ref _dElevation1);
            else
              _dElevation1 = _CompleteLeg.Arc.StartPnt.z;
            _CompleteLeg.Arc.StartPnt.z = _dElevation1 + _dConstElevation;
          }
          else if (_bUseConstantElevation)
            _CompleteLeg.Arc.StartPnt.z = _dConstElevation;
        }
        else
          flag1 = false;
        if (!flag2)
        {
          if (_bUseToposurfaceElevation)
          {
            if (_SurfaceList != null && _SurfaceList.Count > 0)
              RevitUtility.GetSurfaceContainingPoint(_CompleteLeg.Arc.EndPnt, _SurfaceList, _CurPhase, ref _dElevation2);
            else
              _dElevation2 = _CompleteLeg.Arc.EndPnt.z;
            _CompleteLeg.Arc.EndPnt.z = _dElevation2 + _dConstElevation;
          }
          else if (_bUseConstantElevation)
            _CompleteLeg.Arc.EndPnt.z = _dConstElevation;
        }
        else
          flag2 = false;
        _CompleteLeg.Arc.RadiusPnt.z = (_CompleteLeg.Arc.StartPnt.z + _CompleteLeg.Arc.EndPnt.z) / 2.0;
      }
      if (leg == null)
        leg = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        leg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return leg;
  }

  public Eps_Leg ApplyElevationsToLeg(double _dStartingElevation, double _dGrade)
  {
    Eps_Leg leg = (Eps_Leg) null;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg.Line);
        if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CompleteLeg.Line.StartPnt, this, ref _dStation, ref _dOffset) == 1700)
        {
          double num = _dGrade * _dStation;
          _CompleteLeg.Line.StartPnt.z = _dStartingElevation + num;
        }
        if (this.IsLegClosed() && _CompleteLeg.Next == null)
        {
          double num = _dGrade * RevitGeometry.eplGeoE_CalcLegListLength(this);
          _CompleteLeg.Line.EndPnt.z = _dStartingElevation + num;
        }
        else if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CompleteLeg.Line.EndPnt, this, ref _dStation, ref _dOffset) == 1700)
        {
          double num = _dGrade * _dStation;
          _CompleteLeg.Line.EndPnt.z = _dStartingElevation + num;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg.Arc);
        if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CompleteLeg.Arc.StartPnt, this, ref _dStation, ref _dOffset) == 1700)
        {
          double num = _dGrade * _dStation;
          _CompleteLeg.Arc.StartPnt.z = _dStartingElevation + num;
        }
        if (this.IsLegClosed() && _CompleteLeg.Next == null)
        {
          double num = _dGrade * RevitGeometry.eplGeoE_CalcLegListLength(this);
          _CompleteLeg.Arc.EndPnt.z = _dStartingElevation + num;
        }
        else if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CompleteLeg.Arc.EndPnt, this, ref _dStation, ref _dOffset) == 1700)
        {
          double num = _dGrade * _dStation;
          _CompleteLeg.Arc.EndPnt.z = _dStartingElevation + num;
        }
        _CompleteLeg.Arc.RadiusPnt.z = (_CompleteLeg.Arc.StartPnt.z + _CompleteLeg.Arc.EndPnt.z) / 2.0;
      }
      if (leg == null)
        leg = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        leg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return leg;
  }

  public Eps_Leg TopographySurfaceLeg(
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase)
  {
    if (this.LegCount == 0)
      return (Eps_Leg) null;
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    Eps_Leg epsLeg2 = (Eps_Leg) null;
    double num1 = 0.0;
    double num2 = this.LegStartPnt.z;
    int nOffset = -1;
    Eps_Leg _CompleteLeg1 = Eps_Leg.SingleLeg(this.Last);
    for (Eps_Leg epsLeg3 = this; epsLeg3 != null; epsLeg3 = epsLeg3.Next)
    {
      Eps_Leg _CompleteLeg2 = new Eps_Leg();
      if (epsLeg3.Line != null)
      {
        _CompleteLeg2.Line = new Eps_Line(epsLeg3.Line);
        if (RevitUtility.GetSurfaceContainingPoint(_CompleteLeg2.Line.StartPnt, _SurfaceList, _CurPhase, ref num1) != null)
        {
          _CompleteLeg2.Line.StartPnt.z = num1;
          num2 = num1;
        }
        else
        {
          if (nOffset == -1)
            nOffset = this.FindInnerOffsetLegSide();
          epsLeg2 = new Eps_Leg();
          Eps_Leg LegSection = Eps_Leg.SingleLeg(_CompleteLeg1);
          LegSection.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
          if (this.FindSurfaceElevationAtPoint(nOffset, LegSection, _SurfaceList, _CurPhase, ref num1))
          {
            _CompleteLeg2.Line.StartPnt.z = num1;
            num2 = num1;
          }
          else
            _CompleteLeg2.Line.StartPnt.z = num2;
        }
        if (RevitUtility.GetSurfaceContainingPoint(_CompleteLeg2.Line.EndPnt, _SurfaceList, _CurPhase, ref num1) != null)
        {
          _CompleteLeg2.Line.EndPnt.z = num1;
          num2 = num1;
        }
        else
        {
          if (nOffset == -1)
            nOffset = this.FindInnerOffsetLegSide();
          epsLeg2 = new Eps_Leg();
          Eps_Leg LegSection = Eps_Leg.SingleLeg(_CompleteLeg2);
          LegSection.Last.Next = epsLeg3.Next == null ? Eps_Leg.SingleLeg(this) : Eps_Leg.SingleLeg(epsLeg3.Next);
          if (this.FindSurfaceElevationAtPoint(nOffset, LegSection, _SurfaceList, _CurPhase, ref num1))
          {
            _CompleteLeg2.Line.EndPnt.z = num1;
            num2 = num1;
          }
          else
            _CompleteLeg2.Line.EndPnt.z = num2;
        }
      }
      else if (epsLeg3.Arc != null)
      {
        _CompleteLeg2.Arc = new Eps_Arc(epsLeg3.Arc);
        if (RevitUtility.GetSurfaceContainingPoint(_CompleteLeg2.Arc.StartPnt, _SurfaceList, _CurPhase, ref num1) != null)
        {
          _CompleteLeg2.Arc.StartPnt.z = num1;
          num2 = num1;
        }
        else
        {
          if (nOffset == -1)
            nOffset = this.FindInnerOffsetLegSide();
          epsLeg2 = new Eps_Leg();
          Eps_Leg LegSection = Eps_Leg.SingleLeg(_CompleteLeg1);
          LegSection.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
          if (this.FindSurfaceElevationAtPoint(nOffset, LegSection, _SurfaceList, _CurPhase, ref num1))
          {
            _CompleteLeg2.Arc.StartPnt.z = num1;
            num2 = num1;
          }
          else
            _CompleteLeg2.Arc.StartPnt.z = num2;
        }
        if (RevitUtility.GetSurfaceContainingPoint(_CompleteLeg2.Arc.EndPnt, _SurfaceList, _CurPhase, ref num1) != null)
        {
          _CompleteLeg2.Arc.EndPnt.z = num1;
          num2 = num1;
        }
        else
        {
          if (nOffset == -1)
            nOffset = this.FindInnerOffsetLegSide();
          epsLeg2 = new Eps_Leg();
          Eps_Leg LegSection = Eps_Leg.SingleLeg(_CompleteLeg2);
          LegSection.Last.Next = epsLeg3.Next == null ? Eps_Leg.SingleLeg(this) : Eps_Leg.SingleLeg(epsLeg3.Next);
          if (this.FindSurfaceElevationAtPoint(nOffset, LegSection, _SurfaceList, _CurPhase, ref num1))
          {
            _CompleteLeg2.Arc.EndPnt.z = num1;
            num2 = num1;
          }
          else
            _CompleteLeg2.Arc.EndPnt.z = num2;
        }
        _CompleteLeg2.Arc.RadiusPnt.z = (_CompleteLeg2.Arc.StartPnt.z + _CompleteLeg2.Arc.EndPnt.z) / 2.0;
      }
      if (epsLeg1 == null)
        epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg2);
      else
        epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
      _CompleteLeg1 = Eps_Leg.SingleLeg(_CompleteLeg2);
    }
    return epsLeg1;
  }

  private bool FindSurfaceElevationAtPoint(
    int nOffset,
    Eps_Leg LegSection,
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase,
    ref double dPointElevation)
  {
    Eps_Point _FindPoint = (Eps_Point) null;
    for (int index = 4; index <= 10; ++index)
    {
      Eps_Leg ppOffsetLegList = new Eps_Leg();
      RevitGeometry.OffsetLegList(LegSection, (double) index * 0.01, nOffset, ref ppOffsetLegList, true);
      if (ppOffsetLegList.Line != null)
        _FindPoint = ppOffsetLegList.Line.EndPnt;
      else if (ppOffsetLegList.Arc != null)
        _FindPoint = ppOffsetLegList.Arc.EndPnt;
      if (RevitUtility.GetSurfaceContainingPoint(_FindPoint, _SurfaceList, _CurPhase, ref dPointElevation) != null)
        return true;
      LegSection = Eps_Leg.CopyLeg(ppOffsetLegList);
    }
    return false;
  }

  private int FindInnerOffsetLegSide()
  {
    Eps_Leg ppOffsetLegList1 = new Eps_Leg();
    RevitGeometry.OffsetLegList(this, 0.01, 1, ref ppOffsetLegList1, true);
    Eps_Leg ppOffsetLegList2 = new Eps_Leg();
    RevitGeometry.OffsetLegList(this, 0.01, 2, ref ppOffsetLegList2, true);
    return RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2) < RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1) ? 2 : 1;
  }

  public bool FindMinAndMaxElevationOfLeg(
    TopographySurfaceContainer _SurfaceContainer,
    double _dLineInterval,
    double _dArcInterval,
    ref double _dMinElevation,
    ref double _dMaxElevation)
  {
    return this.FindMinAndMaxElevationOfLeg(new List<TopographySurfaceContainer>()
    {
      _SurfaceContainer
    }, (Phase) null, _dLineInterval, _dArcInterval, ref _dMinElevation, ref _dMaxElevation);
  }

  public bool FindMinAndMaxElevationOfLeg(
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase,
    double _dLineInterval,
    double _dArcInterval,
    ref double _dMinElevation,
    ref double _dMaxElevation)
  {
    Eps_Point Pnt = new Eps_Point();
    double DistAlongObj = 0.0;
    double _dElevation = 0.0;
    double num1 = 0.0;
    bool maxElevationOfLeg = false;
    _dMaxElevation = double.MinValue;
    _dMinElevation = double.MaxValue;
    for (Eps_Leg _Leg = this; _Leg != null; _Leg = _Leg.Next)
    {
      double _dX = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
      if (_Leg.Line != null)
        num1 = _dLineInterval;
      else if (_Leg.Arc != null)
        num1 = _dArcInterval;
      maxElevationOfLeg = true;
      double num2 = DistAlongObj;
      for (; DistAlongObj < _dX; DistAlongObj += num1)
      {
        RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, DistAlongObj, 0.0, ref Pnt);
        RevitUtility.GetSurfaceContainingPoint(Pnt, _SurfaceList, _CurPhase, ref _dElevation);
        Pnt.z = _dElevation;
        if (RevitDefines.GT(Pnt.z, _dMaxElevation))
          _dMaxElevation = Pnt.z;
        if (RevitDefines.LT(Pnt.z, _dMinElevation))
          _dMinElevation = Pnt.z;
      }
      if (RevitDefines.GT(_dX, 0.0))
      {
        DistAlongObj = num2 + _dX;
        RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, DistAlongObj, 0.0, ref Pnt);
        RevitUtility.GetSurfaceContainingPoint(Pnt, _SurfaceList, _CurPhase, ref _dElevation);
        Pnt.z = _dElevation;
        if (RevitDefines.GT(Pnt.z, _dMaxElevation))
          _dMaxElevation = Pnt.z;
        if (RevitDefines.LT(Pnt.z, _dMinElevation))
          _dMinElevation = Pnt.z;
      }
    }
    return maxElevationOfLeg;
  }

  public Eps_Leg MoveLeg(double _dPolarDirection, double _dPolarDistance)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    Eps_Point _NewPnt = new Eps_Point();
    for (Eps_Leg epsLeg2 = this; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg2.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg2.Line);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Line.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _CompleteLeg.Line.StartPnt = new Eps_Point(_NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Line.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _CompleteLeg.Line.EndPnt = new Eps_Point(_NewPnt);
      }
      else if (epsLeg2.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg2.Arc);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _CompleteLeg.Arc.StartPnt = new Eps_Point(_NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.RadiusPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _CompleteLeg.Arc.RadiusPnt = new Eps_Point(_NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _CompleteLeg.Arc.EndPnt = new Eps_Point(_NewPnt);
      }
      if (epsLeg1 == null)
        epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return epsLeg1;
  }

  public Eps_Leg MoveLeg(double _dPolarDirection, double _dPolarDistance, double _dElevation)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    Eps_Point _NewPnt = new Eps_Point();
    for (Eps_Leg epsLeg2 = this; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg2.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg2.Line);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Line.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _NewPnt.z += _dElevation;
        _CompleteLeg.Line.StartPnt = new Eps_Point(_NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Line.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _NewPnt.z += _dElevation;
        _CompleteLeg.Line.EndPnt = new Eps_Point(_NewPnt);
      }
      else if (epsLeg2.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg2.Arc);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _NewPnt.z += _dElevation;
        _CompleteLeg.Arc.StartPnt = new Eps_Point(_NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.RadiusPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _NewPnt.z += _dElevation;
        _CompleteLeg.Arc.RadiusPnt = new Eps_Point(_NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection), _dPolarDistance, ref _NewPnt);
        _NewPnt.z += _dElevation;
        _CompleteLeg.Arc.EndPnt = new Eps_Point(_NewPnt);
      }
      if (epsLeg1 == null)
        epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return epsLeg1;
  }

  public Eps_Leg RotateLeg(Eps_Point _BasePoint, double _dAngle)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    Eps_Point epsPoint = new Eps_Point();
    for (Eps_Leg epsLeg2 = this; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      Eps_Point _Point;
      if (epsLeg2.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg2.Line);
        _Point = new Eps_Point(_CompleteLeg.Line.StartPnt);
        EPShared.eplGeoE_RotatePoint(ref _Point, _BasePoint, EPShared.eplGeoE_NormalizeRadians(_dAngle));
        _CompleteLeg.Line.StartPnt.x = _Point.x;
        _CompleteLeg.Line.StartPnt.y = _Point.y;
        _Point = new Eps_Point(_CompleteLeg.Line.EndPnt);
        EPShared.eplGeoE_RotatePoint(ref _Point, _BasePoint, EPShared.eplGeoE_NormalizeRadians(_dAngle));
        _CompleteLeg.Line.EndPnt.x = _Point.x;
        _CompleteLeg.Line.EndPnt.y = _Point.y;
      }
      else if (epsLeg2.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg2.Arc);
        _Point = new Eps_Point(_CompleteLeg.Arc.StartPnt);
        EPShared.eplGeoE_RotatePoint(ref _Point, _BasePoint, EPShared.eplGeoE_NormalizeRadians(_dAngle));
        _CompleteLeg.Arc.StartPnt.x = _Point.x;
        _CompleteLeg.Arc.StartPnt.y = _Point.y;
        _Point = new Eps_Point(_CompleteLeg.Arc.RadiusPnt);
        EPShared.eplGeoE_RotatePoint(ref _Point, _BasePoint, EPShared.eplGeoE_NormalizeRadians(_dAngle));
        _CompleteLeg.Arc.RadiusPnt.x = _Point.x;
        _CompleteLeg.Arc.RadiusPnt.y = _Point.y;
        _Point = new Eps_Point(_CompleteLeg.Arc.EndPnt);
        EPShared.eplGeoE_RotatePoint(ref _Point, _BasePoint, EPShared.eplGeoE_NormalizeRadians(_dAngle));
        _CompleteLeg.Arc.EndPnt.x = _Point.x;
        _CompleteLeg.Arc.EndPnt.y = _Point.y;
      }
      if (epsLeg1 == null)
        epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return epsLeg1;
  }

  public Eps_Leg SplitArcsInLeg()
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    Eps_Point _StaOffPnt1 = new Eps_Point();
    for (Eps_Leg epsLeg2 = this; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      Eps_Leg _CompleteLeg1 = new Eps_Leg();
      if (epsLeg2.Line != null)
        _CompleteLeg1.Line = new Eps_Line(epsLeg2.Line);
      else if (epsLeg2.Arc != null)
      {
        if (RevitDefines.GE(epsLeg2.Arc.Delta, Math.PI))
        {
          double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg2.Arc.Radius, epsLeg2.Arc.Delta);
          if (RevitDefines.EQ(epsLeg2.Arc.Delta, 2.0 * Math.PI))
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg2.Arc, num / 3.0, 0.0, ref _StaOffPnt1);
            Eps_Point _StaOffPnt2 = new Eps_Point();
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg2.Arc, num / 3.0 * 2.0, 0.0, ref _StaOffPnt2);
            _CompleteLeg1.Arc = new Eps_Arc(epsLeg2.Arc);
            _CompleteLeg1.Arc.Delta = epsLeg2.Arc.Delta / 3.0;
            _CompleteLeg1.Arc.StartPnt = epsLeg2.Arc.StartPnt;
            _CompleteLeg1.Arc.EndPnt = _StaOffPnt1;
            if (epsLeg1 == null)
              epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg1);
            else
              epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
            Eps_Leg _CompleteLeg2 = new Eps_Leg();
            _CompleteLeg2.Arc = new Eps_Arc(epsLeg2.Arc);
            _CompleteLeg2.Arc.Delta = epsLeg2.Arc.Delta / 3.0;
            _CompleteLeg2.Arc.StartPnt = _StaOffPnt1;
            _CompleteLeg2.Arc.EndPnt = _StaOffPnt2;
            epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
            _CompleteLeg1 = new Eps_Leg();
            _CompleteLeg1.Arc = new Eps_Arc(epsLeg2.Arc);
            _CompleteLeg1.Arc.Delta = epsLeg2.Arc.Delta / 3.0;
            _CompleteLeg1.Arc.StartPnt = _StaOffPnt2;
            _CompleteLeg1.Arc.EndPnt = epsLeg2.Arc.EndPnt;
          }
          else
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg2.Arc, num / 2.0, 0.0, ref _StaOffPnt1);
            _CompleteLeg1.Arc = new Eps_Arc(epsLeg2.Arc);
            _CompleteLeg1.Arc.Delta = epsLeg2.Arc.Delta / 2.0;
            _CompleteLeg1.Arc.StartPnt = epsLeg2.Arc.StartPnt;
            _CompleteLeg1.Arc.EndPnt = _StaOffPnt1;
            if (epsLeg1 == null)
              epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg1);
            else
              epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
            _CompleteLeg1 = new Eps_Leg();
            _CompleteLeg1.Arc = new Eps_Arc(epsLeg2.Arc);
            _CompleteLeg1.Arc.Delta = epsLeg2.Arc.Delta / 2.0;
            _CompleteLeg1.Arc.StartPnt = _StaOffPnt1;
            _CompleteLeg1.Arc.EndPnt = epsLeg2.Arc.EndPnt;
          }
        }
        else
          _CompleteLeg1.Arc = new Eps_Arc(epsLeg2.Arc);
      }
      if (epsLeg1 == null)
        epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg1);
      else
        epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
    }
    return epsLeg1;
  }

  public List<Eps_Point> GetPointsAtIntervals(double dLinearInterval, double dRadialInterval)
  {
    List<Eps_Point> pointsAtIntervals = new List<Eps_Point>();
    double DistAlongObj = 0.0;
    for (Eps_Leg _Leg = this; _Leg != null; _Leg = _Leg.Next)
    {
      double num1 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
      if (_Leg.Arc != null)
      {
        Eps_Point Pnt = (Eps_Point) null;
        double num2;
        for (num2 = DistAlongObj + num1; DistAlongObj <= num2; DistAlongObj += dRadialInterval)
        {
          Pnt = new Eps_Point();
          RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, DistAlongObj, 0.0, ref Pnt);
          if (pointsAtIntervals.Count == 0 || !EPShared.eplGeoE_ArePntsDuplicates2D(Pnt, pointsAtIntervals[pointsAtIntervals.Count - 1]))
            pointsAtIntervals.Add(Pnt);
        }
        Pnt = new Eps_Point();
        double num3 = DistAlongObj - num2;
        DistAlongObj -= num3;
        RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, DistAlongObj, 0.0, ref Pnt);
        if (pointsAtIntervals.Count == 0 || !EPShared.eplGeoE_ArePntsDuplicates2D(Pnt, pointsAtIntervals[pointsAtIntervals.Count - 1]))
          pointsAtIntervals.Add(Pnt);
      }
      else
      {
        Eps_Point Pnt = (Eps_Point) null;
        double num4;
        for (num4 = DistAlongObj + num1; DistAlongObj <= num4; DistAlongObj += dLinearInterval)
        {
          Pnt = new Eps_Point();
          RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, DistAlongObj, 0.0, ref Pnt);
          if (pointsAtIntervals.Count == 0 || !EPShared.eplGeoE_ArePntsDuplicates2D(Pnt, pointsAtIntervals[pointsAtIntervals.Count - 1]))
            pointsAtIntervals.Add(Pnt);
        }
        double num5 = DistAlongObj - num4;
        DistAlongObj -= num5;
        RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, DistAlongObj, 0.0, ref Pnt);
        if (pointsAtIntervals.Count == 0 || !EPShared.eplGeoE_ArePntsDuplicates2D(Pnt, pointsAtIntervals[pointsAtIntervals.Count - 1]))
          pointsAtIntervals.Add(Pnt);
      }
      if (_Leg.Next == null)
      {
        Eps_Point Pnt = new Eps_Point();
        RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this, RevitGeometry.eplGeoE_CalcLegListLength(this), 0.0, ref Pnt);
        if (pointsAtIntervals.Count == 0 || !EPShared.eplGeoE_ArePntsDuplicates2D(Pnt, pointsAtIntervals[pointsAtIntervals.Count - 1]) && (!this.IsLegClosed() || !EPShared.eplGeoE_ArePntsDuplicates2D(Pnt, pointsAtIntervals[0])))
          pointsAtIntervals.Add(Pnt);
      }
    }
    return pointsAtIntervals;
  }

  public Eps_Leg SplitLegAtStations(List<double> _Stations)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    double num1 = 0.0;
    int index = 0;
    Eps_Point _StaOffPnt = new Eps_Point();
    for (Eps_Leg _Leg = this; _Leg != null; _Leg = _Leg.Next)
    {
      double num2 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
      Eps_Leg epsLeg2 = new Eps_Leg();
      if (_Leg.Line != null)
      {
        epsLeg2.Line = new Eps_Line();
        epsLeg2.Line.StartPnt = _Leg.Line.StartPnt;
        for (; index < _Stations.Count && _Stations[index] < num1 + num2; ++index)
        {
          EPShared.eplGeoE_FindStaOffPointAlongLine(_Leg.Line, _Stations[index] - num1, 0.0, ref _StaOffPnt);
          if (!epsLeg2.Line.StartPnt.IsEqual(_StaOffPnt))
          {
            epsLeg2.Line.EndPnt = _StaOffPnt;
            if (epsLeg1 == null)
              epsLeg1 = Eps_Leg.SingleLeg(epsLeg2);
            else
              epsLeg1.Last.Next = Eps_Leg.SingleLeg(epsLeg2);
            epsLeg2 = new Eps_Leg();
            epsLeg2.Line = new Eps_Line();
            epsLeg2.Line.StartPnt = _StaOffPnt;
          }
        }
        if (!epsLeg2.Line.StartPnt.IsEqual(_Leg.Line.EndPnt))
          epsLeg2.Line.EndPnt = _Leg.Line.EndPnt;
        else
          epsLeg2 = (Eps_Leg) null;
      }
      else if (_Leg.Arc != null)
      {
        epsLeg2.Arc = new Eps_Arc(_Leg.Arc);
        epsLeg2.Arc.StartPnt = _Leg.Arc.StartPnt;
        double _dX = RevitGeometry.eplGeoE_CalcLegLength(epsLeg2);
        for (; index < _Stations.Count && _Stations[index] < num1 + num2; ++index)
        {
          EPShared.eplGeoE_FindStaOffPointAlongArc(_Leg.Arc, _Stations[index] - num1, 0.0, ref _StaOffPnt);
          if (!epsLeg2.Arc.StartPnt.IsEqual(_StaOffPnt))
          {
            epsLeg2.Arc.Delta = (_Stations[index] - num1) / epsLeg2.Arc.Radius;
            epsLeg2.Arc.EndPnt = _StaOffPnt;
            if (epsLeg1 == null)
              epsLeg1 = Eps_Leg.SingleLeg(epsLeg2);
            else
              epsLeg1.Last.Next = Eps_Leg.SingleLeg(epsLeg2);
            epsLeg2 = new Eps_Leg();
            epsLeg2.Arc = new Eps_Arc(_Leg.Arc);
            epsLeg2.Arc.StartPnt = _StaOffPnt;
            epsLeg2.Arc.Delta = (num2 - (_Stations[index] - num1)) / epsLeg2.Arc.Radius;
          }
          _dX = RevitGeometry.eplGeoE_CalcLegLength(epsLeg2);
        }
        if (!epsLeg2.Arc.StartPnt.IsEqual(_Leg.Arc.EndPnt) || RevitDefines.GT(_dX, 0.0))
          epsLeg2.Arc.EndPnt = _Leg.Arc.EndPnt;
        else
          epsLeg2 = (Eps_Leg) null;
      }
      num1 += num2;
      if (epsLeg2 != null)
      {
        if (epsLeg1 == null)
          epsLeg1 = Eps_Leg.SingleLeg(epsLeg2);
        else
          epsLeg1.Last.Next = Eps_Leg.SingleLeg(epsLeg2);
      }
    }
    return epsLeg1;
  }

  public Eps_Leg InsertLegAtStations(double _dStation, Eps_Leg _AddLeg, bool _bAppendOnEnd)
  {
    Eps_Leg epsLeg = (Eps_Leg) null;
    double num1 = 0.0;
    bool flag = false;
    if (!_bAppendOnEnd)
    {
      if (epsLeg == null)
        epsLeg = Eps_Leg.CopyLeg(_AddLeg);
      else
        epsLeg.Last.Next = Eps_Leg.CopyLeg(_AddLeg);
    }
    for (Eps_Leg _Leg = this; _Leg != null; _Leg = _Leg.Next)
    {
      double num2 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (_Leg.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line();
        if (_dStation < num1 + num2)
        {
          flag = true;
          if (!_bAppendOnEnd)
          {
            _CompleteLeg.Line.StartPnt = _AddLeg.LegEndPnt;
            _CompleteLeg.Line.EndPnt = _Leg.Line.EndPnt;
          }
          else
          {
            _CompleteLeg.Line.StartPnt = _Leg.Line.StartPnt;
            _CompleteLeg.Line.EndPnt = _AddLeg.LegStartPnt;
          }
          if (_CompleteLeg.Line.StartPnt.IsEqual(_CompleteLeg.Line.EndPnt))
            _CompleteLeg = (Eps_Leg) null;
        }
        else if (!_Leg.Line.StartPnt.IsEqual(_Leg.Line.EndPnt))
        {
          _CompleteLeg.Line.StartPnt = _Leg.Line.StartPnt;
          _CompleteLeg.Line.EndPnt = _Leg.Line.EndPnt;
        }
        else
          _CompleteLeg = (Eps_Leg) null;
      }
      else if (_Leg.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(_Leg.Arc);
        if (_dStation < num1 + num2)
        {
          flag = true;
          _CompleteLeg.Arc.Delta = (_dStation - num1) / _CompleteLeg.Arc.Radius;
          if (!_bAppendOnEnd)
          {
            _CompleteLeg.Arc.StartPnt = _AddLeg.LegEndPnt;
            _CompleteLeg.Arc.EndPnt = _Leg.Arc.EndPnt;
          }
          else
          {
            _CompleteLeg.Arc.StartPnt = _Leg.Arc.StartPnt;
            _CompleteLeg.Arc.EndPnt = _AddLeg.LegStartPnt;
          }
          _CompleteLeg.Arc.RadiusPnt.z = (_CompleteLeg.Arc.StartPnt.z + _CompleteLeg.Arc.EndPnt.z) / 2.0;
          if (_CompleteLeg.Arc.StartPnt.IsEqual(_CompleteLeg.Arc.EndPnt))
            _CompleteLeg = (Eps_Leg) null;
        }
        else if (!_Leg.Arc.StartPnt.IsEqual(_Leg.Arc.EndPnt))
        {
          _CompleteLeg.Arc.StartPnt = _Leg.Arc.StartPnt;
          _CompleteLeg.Arc.EndPnt = _Leg.Arc.EndPnt;
        }
        else
          _CompleteLeg = (Eps_Leg) null;
      }
      num1 += num2;
      if (_bAppendOnEnd || flag)
      {
        if (_CompleteLeg != null)
        {
          if (epsLeg == null)
            epsLeg = Eps_Leg.SingleLeg(_CompleteLeg);
          else
            epsLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
        }
        if (_bAppendOnEnd && flag)
          break;
      }
    }
    if (_bAppendOnEnd)
    {
      if (epsLeg == null)
        epsLeg = Eps_Leg.CopyLeg(_AddLeg);
      else
        epsLeg.Last.Next = Eps_Leg.CopyLeg(_AddLeg);
    }
    return epsLeg;
  }

  public Eps_Leg ExtendLegList(bool _bStart, double _dDistance)
  {
    Eps_Leg epsLeg = (Eps_Leg) null;
    double _dDirection = 0.0;
    double _dPolarDistance = _dDistance;
    bool flag = true;
    for (Eps_Leg _Leg = this; _Leg != null; _Leg = _Leg.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      double num1 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
      Eps_Point _NewPnt;
      if (_Leg.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(_Leg.Line);
        double num2 = (_Leg.Line.EndPnt.z - _Leg.Line.StartPnt.z) / num1 * -_dDistance;
        if (_bStart && flag && !this.IsLegClosed())
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CompleteLeg.Line.EndPnt, _CompleteLeg.Line.StartPnt, ref _dDirection);
          if (_dPolarDistance < 0.0)
          {
            _dDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI);
            _dPolarDistance = Math.Abs(_dPolarDistance);
          }
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Line.StartPnt, _dDirection, _dPolarDistance, ref _NewPnt);
          _CompleteLeg.Line.StartPnt.x = _NewPnt.x;
          _CompleteLeg.Line.StartPnt.y = _NewPnt.y;
          _CompleteLeg.Line.StartPnt.z += num2;
        }
        else if (!_bStart && _Leg.Next == null && !this.IsLegClosed())
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CompleteLeg.Line.StartPnt, _CompleteLeg.Line.EndPnt, ref _dDirection);
          if (_dPolarDistance < 0.0)
          {
            _dDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI);
            _dPolarDistance = Math.Abs(_dPolarDistance);
          }
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Line.EndPnt, _dDirection, _dPolarDistance, ref _NewPnt);
          _CompleteLeg.Line.EndPnt.x = _NewPnt.x;
          _CompleteLeg.Line.EndPnt.y = _NewPnt.y;
          _CompleteLeg.Line.EndPnt.z += num2;
        }
      }
      else if (_Leg.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(_Leg.Arc);
        double num3 = (_Leg.Arc.EndPnt.z - _Leg.Arc.StartPnt.z) / num1 * -_dDistance;
        if (_bStart && flag && !this.IsLegClosed())
        {
          double num4 = num1 + _dPolarDistance;
          _CompleteLeg.Arc.Delta = num4 / _CompleteLeg.Arc.Radius;
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CompleteLeg.Arc.RadiusPnt, _CompleteLeg.Arc.EndPnt, ref _dDirection);
          if (_CompleteLeg.Arc.Direction == -1)
            _dDirection += _CompleteLeg.Arc.Delta;
          else
            _dDirection -= _CompleteLeg.Arc.Delta;
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.RadiusPnt, _dDirection, _CompleteLeg.Arc.Radius, ref _NewPnt);
          _CompleteLeg.Arc.StartPnt.x = _NewPnt.x;
          _CompleteLeg.Arc.StartPnt.y = _NewPnt.y;
          _CompleteLeg.Arc.StartPnt.z += num3;
        }
        else if (!_bStart && _Leg.Next == null && !this.IsLegClosed())
        {
          double num5 = num1 + _dDirection;
          _CompleteLeg.Arc.Delta = num5 / _CompleteLeg.Arc.Radius;
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CompleteLeg.Arc.RadiusPnt, _CompleteLeg.Arc.StartPnt, ref _dDirection);
          if (_CompleteLeg.Arc.Direction == -1)
            _dDirection -= _CompleteLeg.Arc.Delta;
          else
            _dDirection += _CompleteLeg.Arc.Delta;
          _NewPnt = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(_CompleteLeg.Arc.RadiusPnt, _dDirection, _CompleteLeg.Arc.Radius, ref _NewPnt);
          _CompleteLeg.Arc.EndPnt.x = _NewPnt.x;
          _CompleteLeg.Arc.EndPnt.y = _NewPnt.y;
          _CompleteLeg.Arc.EndPnt.z += num3;
        }
      }
      if (epsLeg == null)
        epsLeg = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        epsLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
      flag = false;
    }
    return epsLeg;
  }

  public bool Is3D
  {
    get => this.m_bIs3D;
    set => this.m_bIs3D = value;
  }

  public int DrawingType
  {
    get => this.m_nDrawingType;
    set => this.m_nDrawingType = value;
  }

  public Eps_Arc Arc
  {
    get => this.m_Arc;
    set => this.m_Arc = value;
  }

  public Eps_Line Line
  {
    get => this.m_Line;
    set => this.m_Line = value;
  }

  public NurbSpline NurbSpline
  {
    get => this.m_NurbSpline;
    set => this.m_NurbSpline = value;
  }

  public HermiteSpline HermiteSpline
  {
    get => this.m_HermiteSpline;
    set => this.m_HermiteSpline = value;
  }

  public int SplineNum
  {
    get => this.m_nSplineNum;
    set => this.m_nSplineNum = value;
  }

  public Eps_Leg Next
  {
    get => this.m_Next;
    set => this.m_Next = value;
  }

  public Element Element
  {
    get => this.m_Element;
    set => this.m_Element = value;
  }

  public ElementSet ElementSet
  {
    get
    {
      ElementSet elementSet = (ElementSet) null;
      for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.m_Next)
      {
        if (elementSet == null)
          elementSet = new ElementSet();
        if (epsLeg.Element != null)
          elementSet.Insert(epsLeg.Element);
      }
      return elementSet;
    }
  }

  public List<Element> ElementList
  {
    get
    {
      List<Element> elementList = (List<Element>) null;
      for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.m_Next)
      {
        if (elementList == null)
          elementList = new List<Element>();
        if (epsLeg.Element != null)
          elementList.Add(epsLeg.Element);
      }
      return elementList;
    }
  }

  public Eps_Leg Last
  {
    get
    {
      Eps_Leg last = this;
      while (last.m_Next != null)
        last = last.m_Next;
      return last;
    }
  }

  public int LegCount
  {
    get
    {
      int legCount = 0;
      for (Eps_Leg epsLeg = this; epsLeg != null; epsLeg = epsLeg.m_Next)
      {
        if (epsLeg.Line != null || epsLeg.Arc != null)
          ++legCount;
      }
      return legCount;
    }
  }

  public Eps_Point LegStartPnt
  {
    get
    {
      Eps_Point legStartPnt = (Eps_Point) null;
      if (this.m_Arc != null)
        legStartPnt = this.m_Arc.StartPnt;
      else if (this.m_Line != null)
        legStartPnt = this.m_Line.StartPnt;
      return legStartPnt;
    }
  }

  public Eps_Point LegEndPnt
  {
    get
    {
      Eps_Point legEndPnt = (Eps_Point) null;
      Eps_Leg last = this.Last;
      if (last.Arc != null)
        legEndPnt = last.Arc.EndPnt;
      else if (last.Line != null)
        legEndPnt = last.Line.EndPnt;
      return legEndPnt;
    }
  }

  public bool IsReverse
  {
    get => this.m_bIsReverse;
    set => this.m_bIsReverse = value;
  }
}
