﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ListViewItemComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ListViewItemComparer : IComparer
{
  private int m_nColumn;
  private SortOrder m_Order;

  public ListViewItemComparer()
  {
    this.m_nColumn = 0;
    this.m_Order = SortOrder.Ascending;
  }

  public ListViewItemComparer(int _Column, SortOrder _Order)
  {
    this.m_nColumn = _Column;
    this.m_Order = _Order;
  }

  public int Compare(object First, object Second)
  {
    int num = string.Compare(((ListViewItem) First).SubItems[this.m_nColumn].Text, ((ListViewItem) Second).SubItems[this.m_nColumn].Text);
    if (this.m_Order == SortOrder.Descending)
      num *= -1;
    return num;
  }
}
