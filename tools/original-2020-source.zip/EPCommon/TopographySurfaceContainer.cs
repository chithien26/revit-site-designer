﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.TopographySurfaceContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace EPCommon;

public class TopographySurfaceContainer
{
  private TopographySurface m_TopographySurface;
  private CeilingAndFloor m_BuildingPad;
  private FamilyInstance m_FamilyInstance;
  private Eps_Point m_MinLeftPoint;
  private Eps_Point m_MaxRightPoint;
  private Application m_CurApplication;
  private bool m_bIsMinMaxPointsFound;
  private bool m_bBuildingPadPresentInDiffentPhase;
  private bool m_bIsBoundaryLegFound;
  private List<Eps_Triangle> m_Triangles;
  private List<Eps_Point> m_Vertices;
  private List<TopoPoint> m_TopoPoints;
  private List<TopographySurfaceContainer> m_SubregionBuildingPadList;
  private List<TopographySurfaceContainer> m_BuildingPadPresentInDifferentPhaseList;
  private TopographySurfaceType m_TopographySurfaceType;
  private Eps_Leg m_BuildingPadLeg;
  private Eps_Leg m_BoundaryLeg;
  private List<Eps_Point> m_BuildingPadPoints;

  public TopographySurfaceContainer(
    Application _CurApplication,
    TopographySurface _TopographySurface)
  {
    this.m_TopographySurfaceType = TopographySurfaceType.MainSurface;
    this.SetupTopographySurfaceContainer(_CurApplication, _TopographySurface, false);
  }

  public TopographySurfaceContainer(
    Application _CurApplication,
    TopographySurface _TopographySurface,
    bool _bFindMinMaxPoints)
  {
    this.m_TopographySurfaceType = TopographySurfaceType.MainSurface;
    this.SetupTopographySurfaceContainer(_CurApplication, _TopographySurface, _bFindMinMaxPoints);
  }

  public TopographySurfaceContainer(
    Application _CurApplication,
    TopographySurface _TopographySurface,
    bool _bFindMinMaxPoints,
    TopographySurfaceType _TopographySurfaceType)
  {
    this.m_TopographySurfaceType = _TopographySurfaceType;
    this.SetupTopographySurfaceContainer(_CurApplication, _TopographySurface, _bFindMinMaxPoints);
  }

  private void SetupTopographySurfaceContainer(
    Application _CurApplication,
    TopographySurface _TopographySurface,
    bool _bFindMinMaxPoints)
  {
    this.m_TopographySurface = _TopographySurface;
    this.m_BuildingPad = (CeilingAndFloor) null;
    this.m_CurApplication = _CurApplication;
    this.m_SubregionBuildingPadList = new List<TopographySurfaceContainer>();
    this.m_BuildingPadPresentInDifferentPhaseList = new List<TopographySurfaceContainer>();
    this.m_BuildingPadPoints = (List<Eps_Point>) null;
    if (!_bFindMinMaxPoints)
      return;
    this.FindMinMaxPointsOfTopographySurface();
  }

  public TopographySurfaceContainer(
    Application _CurApplication,
    FamilyInstance _FamilyInstance,
    bool _bFindMinMaxPoints)
  {
    this.m_FamilyInstance = _FamilyInstance;
    this.m_TopographySurface = (TopographySurface) null;
    this.m_CurApplication = _CurApplication;
    this.m_SubregionBuildingPadList = new List<TopographySurfaceContainer>();
    this.m_BuildingPadPresentInDifferentPhaseList = new List<TopographySurfaceContainer>();
    this.m_BuildingPadPoints = (List<Eps_Point>) null;
    if (!_bFindMinMaxPoints)
      return;
    this.FindMinMaxPointsOfTopographySurface();
  }

  public TopographySurfaceContainer(
    Application _CurApplication,
    CeilingAndFloor _BuildingPad,
    bool _bFindMinMaxPoints)
  {
    this.m_TopographySurfaceType = TopographySurfaceType.BuildingPad;
    this.m_BuildingPad = _BuildingPad;
    this.m_TopographySurface = (TopographySurface) null;
    this.m_CurApplication = _CurApplication;
    this.m_Vertices = new List<Eps_Point>();
    this.m_TopoPoints = new List<TopoPoint>();
    this.m_SubregionBuildingPadList = new List<TopographySurfaceContainer>();
    this.m_BuildingPadPresentInDifferentPhaseList = new List<TopographySurfaceContainer>();
    if (!_bFindMinMaxPoints)
      return;
    this.FindMinMaxPointsOfTopographySurface();
  }

  public bool Refresh()
  {
    try
    {
      this.m_BuildingPad = (CeilingAndFloor) null;
      this.m_SubregionBuildingPadList = new List<TopographySurfaceContainer>();
      this.m_BuildingPadPresentInDifferentPhaseList = new List<TopographySurfaceContainer>();
      this.m_BuildingPadPoints = (List<Eps_Point>) null;
      this.FindMinMaxPointsOfTopographySurface();
      return true;
    }
    catch
    {
      return false;
    }
  }

  public static TopographySurfaceType FindTopographySurfaceType(
    Application _CurApplication,
    TopographySurface _TopographySurface)
  {
    _CurApplication.Create.NewGeometryOptions().ComputeReferences = true;
    if (_TopographySurface != null)
    {
      if (_TopographySurface.IsSiteSubRegion)
        return TopographySurfaceType.Subregion;
      if (((Element) _TopographySurface).Location == null)
        return TopographySurfaceType.BuildingPad;
    }
    return TopographySurfaceType.MainSurface;
  }

  public void FindMinMaxPointsOfTopographySurface()
  {
    this.FindMinMaxPointsOfTopographySurface((List<Eps_Point>) null);
  }

  public void FindMinMaxPointsOfTopographySurface(List<Eps_Point> _BuildingPadPoint)
  {
    this.m_Triangles = new List<Eps_Triangle>();
    this.m_Vertices = new List<Eps_Point>();
    this.m_TopoPoints = new List<TopoPoint>();
    this.m_BuildingPadLeg = (Eps_Leg) null;
    this.m_BoundaryLeg = (Eps_Leg) null;
    Eps_Point pMinPnt = new Eps_Point();
    Eps_Point pMaxPnt = new Eps_Point();
    Options options = this.m_CurApplication.Create.NewGeometryOptions();
    options.ComputeReferences = true;
    if (this.m_TopographySurface != null)
    {
      List<Eps_Point> collection = new List<Eps_Point>();
      List<Eps_Point> source1 = new List<Eps_Point>();
      List<TopoPoint> source2 = new List<TopoPoint>();
      GeometryElement geometryElement = ((Element) this.m_TopographySurface)[options];
      List<GeometryObject> geometryObjectList = new List<GeometryObject>();
      if (GeometryObject.op_Inequality((GeometryObject) geometryElement, (GeometryObject) null))
        geometryObjectList = ElementSetConverter.ToGeometryObjectList(geometryElement.GetEnumerator());
      pMinPnt.x = double.MaxValue;
      pMaxPnt.x = double.MinValue;
      pMinPnt.y = double.MaxValue;
      pMaxPnt.y = double.MinValue;
      pMinPnt.z = double.MaxValue;
      pMaxPnt.z = double.MinValue;
      Eps_Leg epsLeg1 = (Eps_Leg) null;
      Eps_Point Pnt = (Eps_Point) null;
      bool flag1 = true;
      double _dX = double.MinValue;
      double _dStation = 0.0;
      double _dOffset = 0.0;
      for (int index1 = geometryObjectList.Count - 1; index1 >= 0; --index1)
      {
        Mesh mesh = (object) geometryObjectList[index1] as Mesh;
        if (!GeometryObject.op_Equality((GeometryObject) mesh, (GeometryObject) null))
        {
          bool flag2 = true;
          for (int index2 = 0; index2 < mesh.NumTriangles; ++index2)
          {
            MeshTriangle meshTriangle = mesh[index2];
            Eps_Triangle epsTriangle = new Eps_Triangle();
            for (int index3 = 0; index3 < 3; ++index3)
            {
              Eps_Point _Point = new Eps_Point(meshTriangle[index3]);
              if (this.m_TopographySurfaceType == TopographySurfaceType.BuildingPad)
              {
                if (this.m_BuildingPadLeg == null)
                {
                  if (index2 == 0 && index3 == 0)
                    _dX = _Point.z;
                  else if (!RevitDefines.EQ(_dX, _Point.z))
                    flag2 = false;
                }
                else if (epsLeg1 != null && RevitDefines.EQ(_dX, _Point.z))
                {
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, epsLeg1, ref _dStation, ref _dOffset) == 1700 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(epsLeg1, _dStation, 0.0, ref Pnt) == 0)
                    _Point = new Eps_Point(Pnt);
                  else
                    flag1 = false;
                }
              }
              epsTriangle.Verticies[index3] = new TopoPoint(_Point)
              {
                Number = meshTriangle[index3] + 1U
              };
              source2.Add(epsTriangle.Verticies[index3]);
              if (flag1)
                collection.Add((Eps_Point) epsTriangle.Verticies[index3]);
              else
                flag1 = true;
              RevitGeometry.CalcMinMax((Eps_Point) epsTriangle.Verticies[index3], ref pMinPnt, ref pMaxPnt);
            }
            if (epsTriangle.Verticies.Length == 3 && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[0], (Eps_Point) epsTriangle.Verticies[1]) && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[1], (Eps_Point) epsTriangle.Verticies[2]) && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[0], (Eps_Point) epsTriangle.Verticies[2]))
              this.m_Triangles.Add(epsTriangle);
          }
          if (this.m_TopographySurfaceType == TopographySurfaceType.BuildingPad && this.m_BuildingPadLeg == null && flag2)
          {
            collection.Clear();
            IList<XYZ> vertices = mesh.Vertices;
            List<Eps_Point> _BuildingPadPoints = _BuildingPadPoint;
            if (_BuildingPadPoints == null)
            {
              _BuildingPadPoints = new List<Eps_Point>();
              foreach (XYZ _XYZPoint in (IEnumerable<XYZ>) vertices)
                _BuildingPadPoints.Add(new Eps_Point(_XYZPoint));
            }
            this.BuildBuildingPadLeg(_BuildingPadPoints);
            if (this.m_BuildingPadLeg != null)
            {
              Eps_Leg ppOffsetLegList1 = new Eps_Leg();
              RevitGeometry.OffsetLegList(this.m_BuildingPadLeg, 0.01, 1, ref ppOffsetLegList1, true);
              Eps_Leg ppOffsetLegList2 = new Eps_Leg();
              RevitGeometry.OffsetLegList(this.m_BuildingPadLeg, 0.01, 2, ref ppOffsetLegList2, true);
              epsLeg1 = RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2) >= RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1) ? ppOffsetLegList1 : ppOffsetLegList2;
              for (Eps_Leg epsLeg2 = epsLeg1; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
              {
                if (epsLeg2.Line != null)
                {
                  source1.Add(epsLeg2.Line.StartPnt);
                  if (epsLeg2.Next == null && !epsLeg1.IsLegClosed())
                    source1.Add(epsLeg2.Line.EndPnt);
                }
              }
            }
          }
          source1.AddRange((IEnumerable<Eps_Point>) collection);
          collection.Clear();
        }
      }
      this.m_Vertices = source1.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
      this.m_TopoPoints = source2.Distinct<TopoPoint>((IEqualityComparer<TopoPoint>) new TopoPointEqualityComparer()).ToList<TopoPoint>();
    }
    else if (this.m_FamilyInstance != null)
    {
      List<Eps_Point> source3 = new List<Eps_Point>();
      List<TopoPoint> source4 = new List<TopoPoint>();
      GeometryElement geometryElement = ((Element) this.m_FamilyInstance)[options];
      List<GeometryObject> geometryObjectList = new List<GeometryObject>();
      if (GeometryObject.op_Inequality((GeometryObject) geometryElement, (GeometryObject) null))
        geometryObjectList = ElementSetConverter.ToGeometryObjectList(geometryElement.GetEnumerator());
      pMinPnt.x = double.MaxValue;
      pMaxPnt.x = double.MinValue;
      pMinPnt.y = double.MaxValue;
      pMaxPnt.y = double.MinValue;
      pMinPnt.z = double.MaxValue;
      pMaxPnt.z = double.MinValue;
      foreach (object obj in geometryObjectList)
      {
        Solid solid = obj as Solid;
        if (!GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          for (int index4 = 0; index4 < solid.Faces.Size; ++index4)
          {
            Face face = solid.Faces[index4];
            if (!GeometryObject.op_Equality((GeometryObject) face, (GeometryObject) null))
            {
              Mesh mesh = face.Triangulate();
              if (!GeometryObject.op_Equality((GeometryObject) mesh, (GeometryObject) null))
              {
                for (int index5 = 0; index5 < mesh.NumTriangles; ++index5)
                {
                  MeshTriangle meshTriangle = mesh[index5];
                  Eps_Triangle epsTriangle = new Eps_Triangle();
                  for (int index6 = 0; index6 < 3; ++index6)
                  {
                    epsTriangle.Verticies[index6] = new TopoPoint(meshTriangle[index6])
                    {
                      Number = meshTriangle[index6] + 1U
                    };
                    source3.Add((Eps_Point) epsTriangle.Verticies[index6]);
                    source4.Add(epsTriangle.Verticies[index6]);
                    RevitGeometry.CalcMinMax((Eps_Point) epsTriangle.Verticies[index6], ref pMinPnt, ref pMaxPnt);
                  }
                  if (epsTriangle.Verticies.Length == 3 && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[0], (Eps_Point) epsTriangle.Verticies[1]) && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[1], (Eps_Point) epsTriangle.Verticies[2]) && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[0], (Eps_Point) epsTriangle.Verticies[2]))
                    this.m_Triangles.Add(epsTriangle);
                }
              }
            }
          }
        }
      }
      this.m_Vertices = source3.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
      this.m_TopoPoints = source4.Distinct<TopoPoint>((IEqualityComparer<TopoPoint>) new TopoPointEqualityComparer()).ToList<TopoPoint>();
    }
    else if (this.m_BuildingPad != null)
    {
      List<Eps_Point> source5 = new List<Eps_Point>();
      List<TopoPoint> source6 = new List<TopoPoint>();
      GeometryElement geometryElement = ((Element) this.m_BuildingPad)[options];
      List<GeometryObject> geometryObjectList = new List<GeometryObject>();
      if (GeometryObject.op_Inequality((GeometryObject) geometryElement, (GeometryObject) null))
        geometryObjectList = ElementSetConverter.ToGeometryObjectList(geometryElement.GetEnumerator());
      pMinPnt.x = double.MaxValue;
      pMaxPnt.x = double.MinValue;
      pMinPnt.y = double.MaxValue;
      pMaxPnt.y = double.MinValue;
      pMinPnt.z = double.MaxValue;
      pMaxPnt.z = double.MinValue;
      foreach (object obj in geometryObjectList)
      {
        Solid solid = obj as Solid;
        if (!GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          for (int index7 = 0; index7 < solid.Faces.Size; ++index7)
          {
            Face face = solid.Faces[index7];
            if (!GeometryObject.op_Equality((GeometryObject) face, (GeometryObject) null))
            {
              Mesh mesh = face.Triangulate();
              if (!GeometryObject.op_Equality((GeometryObject) mesh, (GeometryObject) null))
              {
                for (int index8 = 0; index8 < mesh.NumTriangles; ++index8)
                {
                  MeshTriangle meshTriangle = mesh[index8];
                  Eps_Triangle epsTriangle = new Eps_Triangle();
                  for (int index9 = 0; index9 < 3; ++index9)
                  {
                    epsTriangle.Verticies[index9] = new TopoPoint(meshTriangle[index9])
                    {
                      Number = meshTriangle[index9] + 1U
                    };
                    source5.Add((Eps_Point) epsTriangle.Verticies[index9]);
                    source6.Add(epsTriangle.Verticies[index9]);
                    RevitGeometry.CalcMinMax((Eps_Point) epsTriangle.Verticies[index9], ref pMinPnt, ref pMaxPnt);
                  }
                  if (epsTriangle.Verticies.Length == 3 && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[0], (Eps_Point) epsTriangle.Verticies[1]) && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[1], (Eps_Point) epsTriangle.Verticies[2]) && !EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) epsTriangle.Verticies[0], (Eps_Point) epsTriangle.Verticies[2]))
                    this.m_Triangles.Add(epsTriangle);
                }
              }
            }
          }
        }
      }
      this.m_Vertices = source5.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
      this.m_TopoPoints = source6.Distinct<TopoPoint>((IEqualityComparer<TopoPoint>) new TopoPointEqualityComparer()).ToList<TopoPoint>();
    }
    this.m_MinLeftPoint = pMinPnt;
    this.m_MaxRightPoint = pMaxPnt;
    this.m_bIsMinMaxPointsFound = true;
  }

  public bool IsPointWithinSurfaceBounds(Eps_Point _FindPoint)
  {
    if (!this.m_bIsMinMaxPointsFound)
      this.FindMinMaxPointsOfTopographySurface();
    return !RevitDefines.LT(_FindPoint.x, this.m_MinLeftPoint.x, 1E-05) && !RevitDefines.GT(_FindPoint.x, this.m_MaxRightPoint.x, 1E-05) && !RevitDefines.LT(_FindPoint.y, this.m_MinLeftPoint.y, 1E-05) && !RevitDefines.GT(_FindPoint.y, this.m_MaxRightPoint.y, 1E-05) && (this.m_BoundaryLeg == null || !this.m_BoundaryLeg.IsLegClosed() || RevitGeometry.eplGeoE_IsPointInsideLegList(this.m_BoundaryLeg, _FindPoint, 1E-05, this.m_MinLeftPoint, this.m_MaxRightPoint) != 6);
  }

  public Element GetSurfaceContainingPoint(Eps_Point _FindPoint)
  {
    double _dElevation = 0.0;
    return (Element) this.GetSurfaceContainingPoint(_FindPoint, ref _dElevation);
  }

  public TopographySurface GetSurfaceContainingPoint(Eps_Point _FindPoint, ref double _dElevation)
  {
    return this.GetSurfaceContainingPoint(_FindPoint, (Phase) null, ref _dElevation);
  }

  public TopographySurface GetSurfaceContainingPoint(
    Eps_Point _FindPoint,
    Phase _CurPhase,
    ref double _dElevation)
  {
    if (_CurPhase == null || this.m_TopographySurface != null && ElementId.op_Inequality(((Element) this.m_TopographySurface).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_TopographySurface).CreatedPhaseId, ((Element) _CurPhase).Id) || this.m_BuildingPad != null && ElementId.op_Inequality(((Element) this.m_BuildingPad).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_BuildingPad).CreatedPhaseId, ((Element) _CurPhase).Id))
    {
      if (!this.IsPointWithinSurfaceBounds(_FindPoint))
        return (TopographySurface) null;
      for (int index = 0; index < this.m_Triangles.Count; ++index)
      {
        if (this.m_Triangles[index].IsPointInside(_FindPoint))
        {
          _dElevation = this.GetElevationFromPlane((Eps_Point) this.m_Triangles[index].Verticies[0], (Eps_Point) this.m_Triangles[index].Verticies[1], (Eps_Point) this.m_Triangles[index].Verticies[2], _FindPoint);
          return this.m_TopographySurface;
        }
      }
      if (this.m_SubregionBuildingPadList != null && this.m_SubregionBuildingPadList.Count > 0)
      {
        for (int index1 = this.m_SubregionBuildingPadList.Count - 1; index1 >= 0; --index1)
        {
          if (_CurPhase == null || this.m_SubregionBuildingPadList[index1].TopographySurface != null && ElementId.op_Inequality(((Element) this.m_SubregionBuildingPadList[index1].TopographySurface).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_SubregionBuildingPadList[index1].TopographySurface).CreatedPhaseId, ((Element) _CurPhase).Id) || this.m_SubregionBuildingPadList[index1].BuildingPad != null && ElementId.op_Inequality(((Element) this.m_SubregionBuildingPadList[index1].BuildingPad).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_SubregionBuildingPadList[index1].BuildingPad).CreatedPhaseId, ((Element) _CurPhase).Id))
          {
            for (int index2 = 0; index2 < this.m_SubregionBuildingPadList[index1].Triangles.Count; ++index2)
            {
              if (this.m_SubregionBuildingPadList[index1].Triangles[index2].IsPointInside(_FindPoint))
              {
                _dElevation = this.GetElevationFromPlane((Eps_Point) this.m_SubregionBuildingPadList[index1].Triangles[index2].Verticies[0], (Eps_Point) this.m_SubregionBuildingPadList[index1].Triangles[index2].Verticies[1], (Eps_Point) this.m_SubregionBuildingPadList[index1].Triangles[index2].Verticies[2], _FindPoint);
                return this.m_TopographySurface;
              }
            }
          }
        }
      }
    }
    return (TopographySurface) null;
  }

  private double GetElevationFromPlane(
    Eps_Point _FirstPoint,
    Eps_Point _SecondPoint,
    Eps_Point _ThirdPoint,
    Eps_Point _FindPoint)
  {
    double num1 = (_SecondPoint.y - _FirstPoint.y) * (_ThirdPoint.z - _FirstPoint.z) - (_ThirdPoint.y - _FirstPoint.y) * (_SecondPoint.z - _FirstPoint.z);
    double num2 = -((_SecondPoint.x - _FirstPoint.x) * (_ThirdPoint.z - _FirstPoint.z) - (_ThirdPoint.x - _FirstPoint.x) * (_SecondPoint.z - _FirstPoint.z));
    double num3 = (_SecondPoint.x - _FirstPoint.x) * (_ThirdPoint.y - _FirstPoint.y) - (_ThirdPoint.x - _FirstPoint.x) * (_SecondPoint.y - _FirstPoint.y);
    double num4 = -num1 * _FirstPoint.x - num2 * _FirstPoint.y - num3 * _FirstPoint.z;
    return -(num1 * _FindPoint.x + num2 * _FindPoint.y + num4) / num3;
  }

  public TopographySurfaceContainer GetSurfaceContainerContainingPoint(Eps_Point _FindPoint)
  {
    return this.GetSurfaceContainerContainingPoint(_FindPoint, (Phase) null, (Phase) null);
  }

  public TopographySurfaceContainer GetSurfaceContainerContainingPoint(
    Eps_Point _FindPoint,
    Phase _PhaseCreated,
    Phase _PhaseDemolished)
  {
    if ((_PhaseCreated == null || this.m_TopographySurface != null && ElementId.op_Inequality(((Element) this.m_TopographySurface).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_TopographySurface).CreatedPhaseId, ((Element) _PhaseCreated).Id) || this.m_BuildingPad != null && ElementId.op_Inequality(((Element) this.m_BuildingPad).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_BuildingPad).CreatedPhaseId, ((Element) _PhaseCreated).Id)) && (_PhaseDemolished == null || this.m_TopographySurface != null && ElementId.op_Inequality(((Element) this.m_TopographySurface).DemolishedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_TopographySurface).DemolishedPhaseId, ((Element) _PhaseDemolished).Id) || this.m_BuildingPad != null && ElementId.op_Inequality(((Element) this.m_BuildingPad).DemolishedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_BuildingPad).DemolishedPhaseId, ((Element) _PhaseDemolished).Id)))
    {
      if (!this.IsPointWithinSurfaceBounds(_FindPoint))
        return (TopographySurfaceContainer) null;
      for (int index = 0; index < this.m_Triangles.Count; ++index)
      {
        if (this.m_Triangles[index].IsPointInside(_FindPoint))
          return this;
      }
      if (this.m_TopographySurfaceType == TopographySurfaceType.BuildingPad && this.m_BuildingPadLeg != null)
      {
        List<Eps_Point> paPntList = new List<Eps_Point>();
        paPntList.Add(_FindPoint);
        RevitGeometry.GetAllPointsInBoundary(ref paPntList, this.m_BuildingPadLeg, (List<Eps_Leg>) null);
        if (paPntList.Count > 0)
          return this;
      }
      if (this.m_SubregionBuildingPadList != null && this.m_SubregionBuildingPadList.Count > 0)
      {
        for (int index1 = this.m_SubregionBuildingPadList.Count - 1; index1 >= 0; --index1)
        {
          if ((_PhaseCreated == null || this.m_SubregionBuildingPadList[index1].TopographySurface != null && ElementId.op_Inequality(((Element) this.m_SubregionBuildingPadList[index1].TopographySurface).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_SubregionBuildingPadList[index1].TopographySurface).CreatedPhaseId, ((Element) _PhaseCreated).Id) || this.m_SubregionBuildingPadList[index1].BuildingPad != null && ElementId.op_Inequality(((Element) this.m_SubregionBuildingPadList[index1].BuildingPad).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_SubregionBuildingPadList[index1].BuildingPad).CreatedPhaseId, ((Element) _PhaseCreated).Id)) && (_PhaseDemolished == null || this.m_SubregionBuildingPadList[index1].TopographySurface != null && ElementId.op_Inequality(((Element) this.m_SubregionBuildingPadList[index1].TopographySurface).DemolishedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_SubregionBuildingPadList[index1].TopographySurface).DemolishedPhaseId, ((Element) _PhaseDemolished).Id) || this.m_SubregionBuildingPadList[index1].BuildingPad != null && ElementId.op_Inequality(((Element) this.m_SubregionBuildingPadList[index1].BuildingPad).DemolishedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) this.m_SubregionBuildingPadList[index1].BuildingPad).DemolishedPhaseId, ((Element) _PhaseDemolished).Id)))
          {
            for (int index2 = 0; index2 < this.m_SubregionBuildingPadList[index1].Triangles.Count; ++index2)
            {
              if (this.m_SubregionBuildingPadList[index1].Triangles[index2].IsPointInside(_FindPoint))
                return this.m_SubregionBuildingPadList[index1];
            }
          }
        }
      }
    }
    return (TopographySurfaceContainer) null;
  }

  public bool IsTopographySurfaceTypePresent(TopographySurfaceType _TopographySurfaceType)
  {
    if (this.m_TopographySurfaceType == _TopographySurfaceType)
      return true;
    if (this.m_SubregionBuildingPadList != null && this.m_SubregionBuildingPadList.Count > 0)
    {
      for (int index = 0; index < this.m_SubregionBuildingPadList.Count; ++index)
      {
        if (this.m_SubregionBuildingPadList[index].TopographySurfaceType == _TopographySurfaceType)
          return true;
      }
    }
    return false;
  }

  public List<Eps_Point> GetAllVertices()
  {
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    List<Eps_Point> paPntList = new List<Eps_Point>();
    List<Eps_Point> collection = new List<Eps_Point>();
    List<int> intList = new List<int>();
    paPntList.AddRange((IEnumerable<Eps_Point>) this.m_Vertices);
    for (int index1 = this.m_SubregionBuildingPadList.Count - 1; index1 >= 0; --index1)
    {
      if (intList.Contains(index1))
        this.m_SubregionBuildingPadList[index1].FindMinMaxPointsOfTopographySurface(this.m_SubregionBuildingPadList[index1].BuildingPadPoints);
      if (this.m_SubregionBuildingPadList[index1].BuildingPadLeg != null)
      {
        RevitGeometry.RemoveAllPointsInBoundary(ref paPntList, this.m_SubregionBuildingPadList[index1].BuildingPadLeg);
        for (int index2 = index1 - 1; index2 >= 0; --index2)
        {
          if (this.m_SubregionBuildingPadList[index2].BuildingPadPoints != null && this.m_SubregionBuildingPadList[index2].BuildingPadPoints.Count != 0)
          {
            for (int index3 = 0; index3 < this.m_SubregionBuildingPadList[index1].BuildingPadPoints.Count; ++index3)
            {
              for (int index4 = this.m_SubregionBuildingPadList[index2].BuildingPadPoints.Count - 1; index4 >= 0; --index4)
              {
                if (EPShared.eplGeoE_ArePntsDuplicates2D(this.m_SubregionBuildingPadList[index1].BuildingPadPoints[index3], this.m_SubregionBuildingPadList[index2].BuildingPadPoints[index4]))
                {
                  this.m_SubregionBuildingPadList[index2].BuildingPadPoints.RemoveAt(index4);
                  if (!intList.Contains(index2))
                    intList.Add(index2);
                }
              }
            }
          }
        }
      }
      collection.AddRange((IEnumerable<Eps_Point>) this.m_SubregionBuildingPadList[index1].Vertices);
    }
    paPntList.AddRange((IEnumerable<Eps_Point>) collection);
    return paPntList.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
  }

  private void BuildBuildingPadLeg(List<Eps_Point> _BuildingPadPoints)
  {
    Eps_Point epsPoint1 = (Eps_Point) null;
    this.m_BuildingPadLeg = (Eps_Leg) null;
    for (int index = 0; index < _BuildingPadPoints.Count; ++index)
    {
      Eps_Point epsPoint2 = new Eps_Point(_BuildingPadPoints[index]);
      if (epsPoint1 != null)
      {
        Eps_Leg _CompleteLeg = new Eps_Leg();
        _CompleteLeg.Line = new Eps_Line();
        _CompleteLeg.Line.StartPnt = epsPoint1;
        _CompleteLeg.Line.EndPnt = epsPoint2;
        if (this.m_BuildingPadLeg == null)
          this.m_BuildingPadLeg = Eps_Leg.SingleLeg(_CompleteLeg);
        else
          this.m_BuildingPadLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
      }
      epsPoint1 = epsPoint2;
    }
    if (this.m_BuildingPadLeg == null || this.m_BuildingPadLeg.IsLegClosed())
      return;
    Eps_Leg _CompleteLeg1 = new Eps_Leg();
    _CompleteLeg1.Line = new Eps_Line();
    _CompleteLeg1.Line.StartPnt = this.m_BuildingPadLeg.LegEndPnt;
    _CompleteLeg1.Line.EndPnt = this.m_BuildingPadLeg.LegStartPnt;
    this.m_BuildingPadLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
  }

  public void BuildBoundaryLeg()
  {
    if (this.m_bIsBoundaryLegFound)
      return;
    this.m_bIsBoundaryLegFound = true;
    this.m_BoundaryLeg = (Eps_Leg) null;
    if (this.m_Triangles == null || this.m_Triangles.Count <= 0)
      return;
    bool flag = false;
    List<Eps_Line> epsLineList = new List<Eps_Line>();
    for (int index1 = 0; index1 < this.m_Triangles.Count; ++index1)
    {
      for (int index2 = 0; index2 < 3; ++index2)
      {
        Eps_Line epsLine = new Eps_Line();
        if (index2 < 2)
        {
          epsLine.StartPnt = (Eps_Point) this.m_Triangles[index1].Verticies[index2];
          epsLine.EndPnt = (Eps_Point) this.m_Triangles[index1].Verticies[index2 + 1];
        }
        else
        {
          epsLine.StartPnt = (Eps_Point) this.m_Triangles[index1].Verticies[index2];
          epsLine.EndPnt = (Eps_Point) this.m_Triangles[index1].Verticies[0];
        }
        epsLineList.Add(epsLine);
      }
    }
    if (epsLineList != null && epsLineList.Count > 0)
    {
      Eps_LineComparer epsLineComparer = new Eps_LineComparer();
      epsLineList.Sort((IComparer<Eps_Line>) epsLineComparer);
      if (epsLineList.Count > 1)
      {
        for (int index3 = 0; index3 < epsLineList.Count - 1; ++index3)
        {
          int index4 = index3 + 1;
          while (epsLineList[index3].IsEqual((BaseLine) epsLineList[index4]))
          {
            flag = true;
            epsLineList.RemoveAt(index4);
            if (index4 > epsLineList.Count - 1)
              break;
          }
          if (flag)
          {
            epsLineList.RemoveAt(index3);
            flag = false;
            --index3;
          }
        }
      }
    }
    Eps_Leg _CurrentLeg = (Eps_Leg) null;
    List<Eps_Leg> epsLegList = new List<Eps_Leg>();
    if (epsLineList != null && epsLineList.Count > 0)
    {
      int num = epsLineList.Count;
      while (num > 0)
      {
        for (int index = epsLineList.Count - 1; index >= 0; --index)
        {
          if (Eps_Leg.InsertLineLegSegment(ref _CurrentLeg, epsLineList[index]))
            epsLineList.RemoveAt(index);
        }
        if (num == epsLineList.Count)
        {
          if (_CurrentLeg != null)
          {
            epsLegList.Add(_CurrentLeg);
            _CurrentLeg = (Eps_Leg) null;
          }
          else
            num = 0;
        }
        else
          num = epsLineList.Count;
      }
    }
    if (_CurrentLeg != null)
      epsLegList.Add(_CurrentLeg);
    if (epsLegList.Count > 1)
    {
      int nLineCount1 = 0;
      int nLineCount2 = 0;
      int nArcCount1 = 0;
      int nArcCount2 = 0;
      Eps_Line[] aLines1 = (Eps_Line[]) null;
      Eps_Line[] aLines2 = (Eps_Line[]) null;
      Eps_Arc[] aArcs1 = (Eps_Arc[]) null;
      Eps_Arc[] aArcs2 = (Eps_Arc[]) null;
      int[] aLegOrder1 = (int[]) null;
      int[] aLegOrder2 = (int[]) null;
      Eps_Leg epsLeg = epsLegList[0];
      epsLeg.ConvertLegToLineArcArrays(ref aLines1, ref nLineCount1, ref aArcs1, ref nArcCount1, ref aLegOrder1, false);
      for (int index = 1; index < epsLegList.Count; ++index)
      {
        epsLegList[index].ConvertLegToLineArcArrays(ref aLines2, ref nLineCount2, ref aArcs2, ref nArcCount2, ref aLegOrder2, false);
        if (EPShared.eplGeoE_IsLegListInsideLegList(aLines1, nLineCount1, aArcs1, nArcCount1, aLegOrder1, aLines2, nLineCount2, aArcs2, nArcCount2, aLegOrder2, 1E-05))
        {
          epsLeg = epsLegList[index];
          epsLeg.ConvertLegToLineArcArrays(ref aLines1, ref nLineCount1, ref aArcs1, ref nArcCount1, ref aLegOrder1, false);
        }
      }
      this.m_BoundaryLeg = epsLeg;
    }
    else
      this.m_BoundaryLeg = _CurrentLeg;
  }

  public TopographySurface TopographySurface => this.m_TopographySurface;

  public CeilingAndFloor BuildingPad => this.m_BuildingPad;

  public List<Eps_Point> Vertices => this.m_Vertices;

  public List<TopographySurfaceContainer> SubregionBuildingPadList
  {
    get => this.m_SubregionBuildingPadList;
  }

  public List<Eps_Triangle> Triangles => this.m_Triangles;

  public List<TopoPoint> TopoPoints => this.m_TopoPoints;

  public TopographySurfaceType TopographySurfaceType => this.m_TopographySurfaceType;

  public Eps_Leg BuildingPadLeg => this.m_BuildingPadLeg;

  public List<Eps_Point> BuildingPadPoints
  {
    get
    {
      if (this.m_BuildingPadPoints == null && this.m_BuildingPadLeg != null)
      {
        this.m_BuildingPadPoints = new List<Eps_Point>();
        for (Eps_Leg epsLeg = this.m_BuildingPadLeg; epsLeg != null; epsLeg = epsLeg.Next)
        {
          this.m_BuildingPadPoints.Add(epsLeg.LegStartPnt);
          if (epsLeg.Next == null)
            this.m_BuildingPadPoints.Add(epsLeg.LegEndPnt);
        }
      }
      return this.m_BuildingPadPoints;
    }
  }

  public Eps_Point MinRightPoint
  {
    get => new Eps_Point(this.m_MaxRightPoint.x, this.m_MinLeftPoint.y, 0.0);
  }

  public Eps_Point MaxLeftPoint
  {
    get => new Eps_Point(this.m_MinLeftPoint.x, this.m_MaxRightPoint.y, 0.0);
  }

  public Eps_Point MaxRightPoint => this.m_MaxRightPoint;

  public Eps_Point MinLeftPoint => this.m_MinLeftPoint;

  public Eps_Leg BoundaryLeg
  {
    get
    {
      if (this.m_BoundaryLeg == null)
        this.BuildBoundaryLeg();
      return this.m_BoundaryLeg;
    }
  }

  public bool BuildingPadPresentInDiffentPhase
  {
    get => this.m_bBuildingPadPresentInDiffentPhase;
    set => this.m_bBuildingPadPresentInDiffentPhase = value;
  }

  public List<TopographySurfaceContainer> BuildingPadPresentInDifferentPhaseList
  {
    get => this.m_BuildingPadPresentInDifferentPhaseList;
  }
}
