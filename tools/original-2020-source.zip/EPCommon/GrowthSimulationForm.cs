﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.GrowthSimulationForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class GrowthSimulationForm : EPForm
{
  private Units m_Units;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private int m_nMixtListViewSortColumn = -1;
  private GrowthSimulation m_dataBuffer;
  private List<FamilySymbolContainer> m_LocalList = new List<FamilySymbolContainer>();
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_PlantGrowthApply;
  private Button m_CancelButton;
  private Button m_ModifyButton;
  private GroupBox m_DynGroupBox;
  private ListView m_TypeListView;
  private Label m_SimulationAge;
  private GroupBox m_PlantGrowthAgeGroupBox;
  private TextBox m_AgeTextBox;
  private RadioButton m_AllInstancesRadioButton;
  private GroupBox m_SelectionMethodsGroupBox;
  private RadioButton m_WindowSelectRadioButton;
  private RadioButton m_SelectionSetRadioButton;

  public GrowthSimulationForm(GrowthSimulation _dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("PlantGrowthSimulationDialog");
    this.m_DynGroupBox.Text = EPShared.LocalRM.GetString("PlantGrowthDialog");
    this.m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
    this.m_PlantGrowthAgeGroupBox.Text = EPShared.LocalRM.GetString("PlantGrowthAgeDialog");
    this.m_SimulationAge.Text = EPShared.LocalRM.GetString("A_AMP_geDialog");
    this.m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
    this.m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
    this.m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
    this.m_AllInstancesRadioButton.Text = EPShared.LocalRM.GetString("All_AMP_InstancesDialog");
    this.m_PlantGrowthApply.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_dataBuffer = _dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
    ManagePlants.VerifySharedParameters(this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer);
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    this.GetDialogPosition();
    this.m_SelectionSetRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("GrowthSimulationSelectMethodOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_SelectionSetRadioButton.Checked = true;
          break;
        case 1:
          this.m_WindowSelectRadioButton.Checked = true;
          break;
        default:
          this.m_AllInstancesRadioButton.Checked = true;
          break;
      }
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("GrowthSimulationAge", ref _nReturnValue))
      _nReturnValue = 0;
    this.m_AgeTextBox.Text = _nReturnValue.ToString();
    this.SetupListView();
  }

  private void SetupListView()
  {
    this.m_LocalList = this.m_dataBuffer.ExistingPlantSymbolList;
    this.m_TypeListView.View = View.Details;
    this.m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("FamilyString"));
    this.m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"));
    this.m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"));
    this.m_TypeListView.Columns.Add($"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter")}");
    this.m_TypeListView.Columns.Add($"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter")}");
    int num = (this.m_TypeListView.Width - 5) / this.m_TypeListView.Columns.Count;
    for (int index = 0; index < this.m_TypeListView.Columns.Count; ++index)
      this.m_TypeListView.Columns[index].Width = num;
    ListViewItem listViewItem1 = new ListViewItem();
    string empty = string.Empty;
    for (int index = 0; index < this.m_LocalList.Count; ++index)
    {
      string _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
      ListViewItem listViewItem2 = this.m_TypeListView.Items.Insert(index, ((Element) this.m_LocalList[index].FamilySymbol.Family).Name, ((Element) this.m_LocalList[index].FamilySymbol.Family).Name, string.Empty);
      listViewItem2.Tag = (object) ((Element) this.m_LocalList[index].FamilySymbol.Family).Name;
      if (string.Compare(((Element) this.m_LocalList[index].FamilySymbol).Name, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
        _strToDisplay = ((Element) this.m_LocalList[index].FamilySymbol).Name;
      listViewItem2.SubItems.Add(_strToDisplay);
      _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
      if (string.Compare(this.m_LocalList[index].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
        _strToDisplay = this.m_LocalList[index].ServiceLife;
      listViewItem2.SubItems.Add(_strToDisplay);
      _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
      if (string.Compare(this.m_LocalList[index].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
        RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(this.m_LocalList[index].MaxHeight), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
      listViewItem2.SubItems.Add(_strToDisplay);
      _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
      if (string.Compare(this.m_LocalList[index].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
        RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(this.m_LocalList[index].MaxWidth), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
      listViewItem2.SubItems.Add(_strToDisplay);
    }
  }

  private void OnApplyPlantGrowthButtonClicked(object sender, EventArgs e)
  {
    if (ValueConversion.ToDouble(this.m_AgeTextBox.Text) <= 0.0 || this.m_AgeTextBox.Text == string.Empty)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidAgeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      List<FamilySymbolContainer> familySymbolContainerList = new List<FamilySymbolContainer>();
      if (this.m_TypeListView.SelectedItems.Count >= 1)
      {
        for (int index = 0; index < this.m_TypeListView.SelectedItems.Count; ++index)
        {
          if (string.Compare(this.m_TypeListView.SelectedItems[index].SubItems[2].Text, EPShared.LocalRM.GetString("NotAvailableString"), true) == 0)
          {
            int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidServiceLifeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
        }
      }
      this.SaveSettings();
      this.DialogResult = DialogResult.OK;
      this.Close();
    }
  }

  private void CancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnGrowthSimulationFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("GrowthSimulationSelectMethodOption", !this.m_SelectionSetRadioButton.Checked ? (!this.m_WindowSelectRadioButton.Checked ? 2 : 1) : 0);
    if (!(this.m_AgeTextBox.Text != string.Empty))
      return;
    int _nReturnedInt = 0;
    RevitGeometry.StrE_GetValidWholeNumber(this.m_AgeTextBox.Text, ref _nReturnedInt);
    ApplicationUtility.Settings.eplSetE_SetSetting("GrowthSimulationAge", _nReturnedInt);
  }

  private void OnModifyButtonClicked(object sender, EventArgs e)
  {
    if (this.m_TypeListView.Items.Count <= 0)
      return;
    this.Modify();
  }

  private void Modify()
  {
    if (this.m_TypeListView.SelectedItems.Count >= 1)
    {
      using (PlantGrowthModify plantGrowthModify = new PlantGrowthModify(ref this.m_LocalList, this.m_dataBuffer.Document.GetUnits(), this.m_DisplayUnitSystem, this.m_FormatOptions, this.m_UnitSymbolType, this.m_DecimalSymbolType, this.m_TypeListView.SelectedIndices[0]))
      {
        int num = (int) plantGrowthModify.ShowDialog();
        if (plantGrowthModify.DialogResult != DialogResult.OK)
          return;
        int selectedIndex = this.m_TypeListView.SelectedIndices[0];
        if (selectedIndex < 0 || selectedIndex >= this.m_TypeListView.Items.Count)
          return;
        this.UpdateList(selectedIndex);
        this.m_TypeListView.Items[selectedIndex].Selected = true;
      }
    }
    else
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantSymbolSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void MixListViewDoubleClicked(object sender, EventArgs e) => this.Modify();

  private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nMixtListViewSortColumn)
    {
      this.m_nMixtListViewSortColumn = e.Column;
      this.m_TypeListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_TypeListView.Sorting = this.m_TypeListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_TypeListView.Sort();
    this.m_TypeListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_TypeListView.Sorting);
  }

  private void UpdateList(int _nSelectedListIndex)
  {
    this.m_TypeListView.Items.RemoveAt(_nSelectedListIndex);
    ListViewItem listViewItem1 = (ListViewItem) null;
    string name = EPShared.LocalRM.GetString("NotAvailableString");
    listViewItem1 = new ListViewItem();
    ListViewItem listViewItem2 = this.m_TypeListView.Items.Insert(_nSelectedListIndex, ((Element) this.m_LocalList[_nSelectedListIndex].FamilySymbol.Family).Name, ((Element) this.m_LocalList[_nSelectedListIndex].FamilySymbol.Family).Name, string.Empty);
    if (string.Compare(((Element) this.m_LocalList[_nSelectedListIndex].FamilySymbol).Name, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      name = ((Element) this.m_LocalList[_nSelectedListIndex].FamilySymbol).Name;
    listViewItem2.SubItems.Add(name);
    string serviceLife = EPShared.LocalRM.GetString("NotAvailableString");
    if (string.Compare(this.m_LocalList[_nSelectedListIndex].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      serviceLife = this.m_LocalList[_nSelectedListIndex].ServiceLife;
    listViewItem2.SubItems.Add(serviceLife);
    string _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
    if (string.Compare(this.m_LocalList[_nSelectedListIndex].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(this.m_LocalList[_nSelectedListIndex].MaxHeight), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
    listViewItem2.SubItems.Add(_strToDisplay);
    _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
    if (string.Compare(this.m_LocalList[_nSelectedListIndex].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(this.m_LocalList[_nSelectedListIndex].MaxWidth), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
    listViewItem2.SubItems.Add(_strToDisplay);
  }

  public bool SelectionSetChecked => this.m_SelectionSetRadioButton.Checked;

  public bool WindowSelectChecked => this.m_WindowSelectRadioButton.Checked;

  public bool AllInstancesChecked => this.m_AllInstancesRadioButton.Checked;

  public List<FamilySymbolContainer> FamilySymbolLocalList
  {
    get
    {
      List<FamilySymbolContainer> familySymbolLocalList = new List<FamilySymbolContainer>();
      if (this.m_TypeListView.SelectedItems.Count >= 1)
      {
        for (int index = 0; index < this.m_TypeListView.SelectedIndices.Count; ++index)
          familySymbolLocalList.Add(this.m_LocalList[this.m_TypeListView.SelectedIndices[index]]);
      }
      else
      {
        int num = (int) MessageBox.Show((IWin32Window) ApplicationUtility.RevitWindowWrapper, EPShared.LocalRM.GetString("NoPlantSymbolSelectedMessage"), EPShared.LocalRM.GetString("Revit"));
      }
      return familySymbolLocalList;
    }
  }

  public double Age
  {
    get
    {
      double _dReturnedDouble = 0.0;
      RevitGeometry.StrE_GetValidRealNumber(this.m_AgeTextBox.Text, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_PlantGrowthApply = new Button();
    this.m_CancelButton = new Button();
    this.m_ModifyButton = new Button();
    this.m_DynGroupBox = new GroupBox();
    this.m_TypeListView = new ListView();
    this.m_SimulationAge = new Label();
    this.m_PlantGrowthAgeGroupBox = new GroupBox();
    this.m_AgeTextBox = new TextBox();
    this.m_AllInstancesRadioButton = new RadioButton();
    this.m_SelectionMethodsGroupBox = new GroupBox();
    this.m_WindowSelectRadioButton = new RadioButton();
    this.m_SelectionSetRadioButton = new RadioButton();
    this.m_DynGroupBox.SuspendLayout();
    this.m_PlantGrowthAgeGroupBox.SuspendLayout();
    this.m_SelectionMethodsGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_PlantGrowthApply.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_PlantGrowthApply.Location = new Point(320, 377);
    this.m_PlantGrowthApply.Name = "m_PlantGrowthApply";
    this.m_PlantGrowthApply.Size = new Size(77, 23);
    this.m_PlantGrowthApply.TabIndex = 3;
    this.m_PlantGrowthApply.Text = "&Apply";
    this.m_PlantGrowthApply.UseVisualStyleBackColor = true;
    this.m_PlantGrowthApply.Click += new EventHandler(this.OnApplyPlantGrowthButtonClicked);
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.Location = new Point(403, 377);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.CancelButtonClicked);
    this.m_ModifyButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ModifyButton.Location = new Point(385, 15);
    this.m_ModifyButton.Name = "m_ModifyButton";
    this.m_ModifyButton.Size = new Size(75, 23);
    this.m_ModifyButton.TabIndex = 1;
    this.m_ModifyButton.Text = "Modify";
    this.m_ModifyButton.UseVisualStyleBackColor = true;
    this.m_ModifyButton.Click += new EventHandler(this.OnModifyButtonClicked);
    this.m_DynGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DynGroupBox.Controls.Add((Control) this.m_ModifyButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_TypeListView);
    this.m_DynGroupBox.Location = new Point(12, 11);
    this.m_DynGroupBox.Name = "m_DynGroupBox";
    this.m_DynGroupBox.Size = new Size(466, (int) byte.MaxValue);
    this.m_DynGroupBox.TabIndex = 0;
    this.m_DynGroupBox.TabStop = false;
    this.m_DynGroupBox.Text = "Plant Growth";
    this.m_TypeListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_TypeListView.FullRowSelect = true;
    this.m_TypeListView.HideSelection = false;
    this.m_TypeListView.Location = new Point(7, 15);
    this.m_TypeListView.Name = "m_TypeListView";
    this.m_TypeListView.Size = new Size(372, 235);
    this.m_TypeListView.TabIndex = 0;
    this.m_TypeListView.UseCompatibleStateImageBehavior = false;
    this.m_TypeListView.DoubleClick += new EventHandler(this.MixListViewDoubleClicked);
    this.m_TypeListView.ColumnClick += new ColumnClickEventHandler(this.OnMixListViewColumnClick);
    this.m_SimulationAge.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_SimulationAge.AutoSize = true;
    this.m_SimulationAge.Location = new Point(6, 23);
    this.m_SimulationAge.Name = "m_SimulationAge";
    this.m_SimulationAge.Size = new Size(26, 13);
    this.m_SimulationAge.TabIndex = 0;
    this.m_SimulationAge.Text = "Age";
    this.m_PlantGrowthAgeGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_PlantGrowthAgeGroupBox.Controls.Add((Control) this.m_AgeTextBox);
    this.m_PlantGrowthAgeGroupBox.Controls.Add((Control) this.m_SimulationAge);
    this.m_PlantGrowthAgeGroupBox.Location = new Point(12, 272);
    this.m_PlantGrowthAgeGroupBox.Name = "m_PlantGrowthAgeGroupBox";
    this.m_PlantGrowthAgeGroupBox.Size = new Size(466, 50);
    this.m_PlantGrowthAgeGroupBox.TabIndex = 1;
    this.m_PlantGrowthAgeGroupBox.TabStop = false;
    this.m_PlantGrowthAgeGroupBox.Text = "Plant Growth Age";
    this.m_AgeTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_AgeTextBox.Location = new Point(38, 19);
    this.m_AgeTextBox.Name = "m_AgeTextBox";
    this.m_AgeTextBox.Size = new Size(100, 20);
    this.m_AgeTextBox.TabIndex = 1;
    this.m_AllInstancesRadioButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_AllInstancesRadioButton.AutoSize = true;
    this.m_AllInstancesRadioButton.Location = new Point(308, 19);
    this.m_AllInstancesRadioButton.Name = "m_AllInstancesRadioButton";
    this.m_AllInstancesRadioButton.Size = new Size(85, 17);
    this.m_AllInstancesRadioButton.TabIndex = 2;
    this.m_AllInstancesRadioButton.TabStop = true;
    this.m_AllInstancesRadioButton.Text = "All &Instances";
    this.m_AllInstancesRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionMethodsGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_AllInstancesRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_WindowSelectRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_SelectionSetRadioButton);
    this.m_SelectionMethodsGroupBox.Location = new Point(12, 328);
    this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
    this.m_SelectionMethodsGroupBox.Size = new Size(466, 43);
    this.m_SelectionMethodsGroupBox.TabIndex = 2;
    this.m_SelectionMethodsGroupBox.TabStop = false;
    this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
    this.m_WindowSelectRadioButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_WindowSelectRadioButton.AutoSize = true;
    this.m_WindowSelectRadioButton.Location = new Point(159, 19);
    this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
    this.m_WindowSelectRadioButton.Size = new Size(97, 17);
    this.m_WindowSelectRadioButton.TabIndex = 1;
    this.m_WindowSelectRadioButton.TabStop = true;
    this.m_WindowSelectRadioButton.Text = "Window S&elect";
    this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionSetRadioButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_SelectionSetRadioButton.AutoSize = true;
    this.m_SelectionSetRadioButton.Location = new Point(6, 19);
    this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
    this.m_SelectionSetRadioButton.Size = new Size(88, 17);
    this.m_SelectionSetRadioButton.TabIndex = 0;
    this.m_SelectionSetRadioButton.TabStop = true;
    this.m_SelectionSetRadioButton.Text = "&Selection Set";
    this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(490, 419);
    this.Controls.Add((Control) this.m_SelectionMethodsGroupBox);
    this.Controls.Add((Control) this.m_PlantGrowthAgeGroupBox);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_PlantGrowthApply);
    this.Controls.Add((Control) this.m_DynGroupBox);
    this.MinimumSize = new Size(498, 446);
    this.Name = nameof (GrowthSimulationForm);
    this.Text = "Plant Growth Simulation";
    this.FormClosing += new FormClosingEventHandler(this.OnGrowthSimulationFormClosing);
    this.m_DynGroupBox.ResumeLayout(false);
    this.m_PlantGrowthAgeGroupBox.ResumeLayout(false);
    this.m_PlantGrowthAgeGroupBox.PerformLayout();
    this.m_SelectionMethodsGroupBox.ResumeLayout(false);
    this.m_SelectionMethodsGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_PlantGrowthApply;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
