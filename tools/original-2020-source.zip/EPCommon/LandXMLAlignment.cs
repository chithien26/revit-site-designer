﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandXMLAlignment
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class LandXMLAlignment
{
  private string m_strName = string.Empty;
  private string m_strLength = string.Empty;
  private string m_strStartStation = string.Empty;
  private Eps_Point m_StartPoint = new Eps_Point();
  private string m_strAreaUnit = string.Empty;
  private string m_strLinearUnit = string.Empty;
  private string m_strVolumeUnit = string.Empty;
  private string m_strAngularUnit = string.Empty;
  private List<Eps_Line> m_Lines = new List<Eps_Line>();
  private List<Eps_Arc> m_Curves = new List<Eps_Arc>();

  public static LandXMLAlignment CopyAlignment(LandXMLAlignment _CurrentAlignment)
  {
    return new LandXMLAlignment()
    {
      AreaUnit = _CurrentAlignment.AreaUnit,
      Curves = new List<Eps_Arc>((IEnumerable<Eps_Arc>) _CurrentAlignment.Curves),
      Length = _CurrentAlignment.Length,
      LinearUnit = _CurrentAlignment.LinearUnit,
      Lines = new List<Eps_Line>((IEnumerable<Eps_Line>) _CurrentAlignment.Lines),
      Name = _CurrentAlignment.Name,
      StartPoint = new Eps_Point(_CurrentAlignment.StartPoint),
      StartStation = _CurrentAlignment.StartStation,
      VolumeUnit = _CurrentAlignment.VolumeUnit
    };
  }

  public string Name
  {
    get => this.m_strName;
    set => this.m_strName = value;
  }

  public string Length
  {
    get => this.m_strLength;
    set => this.m_strLength = value;
  }

  public string StartStation
  {
    get => this.m_strStartStation;
    set => this.m_strStartStation = value;
  }

  public Eps_Point StartPoint
  {
    get => this.m_StartPoint;
    set => this.m_StartPoint = value;
  }

  public List<Eps_Line> Lines
  {
    get => this.m_Lines;
    set => this.m_Lines = value;
  }

  public List<Eps_Arc> Curves
  {
    get => this.m_Curves;
    set => this.m_Curves = value;
  }

  public string AreaUnit
  {
    get => this.m_strAreaUnit;
    set => this.m_strAreaUnit = value;
  }

  public string LinearUnit
  {
    get => this.m_strLinearUnit;
    set => this.m_strLinearUnit = value;
  }

  public string VolumeUnit
  {
    get => this.m_strVolumeUnit;
    set => this.m_strVolumeUnit = value;
  }

  public string AngularUnit
  {
    get => this.m_strAngularUnit;
    set => this.m_strAngularUnit = value;
  }
}
