﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.NewFamilyForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class NewFamilyForm : EPForm
{
  private FamilyBinder m_NewFamilyBinder;
  private Document m_CurrentDocument;
  private LandcaddID m_CurrentFamilyType = LandcaddID.Street;
  private string m_strOriginalName = string.Empty;
  private IContainer components;
  private Button m_CancelButton;
  private Button m_OkButton;
  private Button m_FileBtn;
  private Label m_PathLbl;
  private TextBox m_FileTxt;

  public NewFamilyForm(
    ref FamilyBinder _NewFamily,
    Document _CurDocument,
    LandcaddID _CurrentFamilyType)
  {
    this.InitializeComponent();
    this.m_NewFamilyBinder = _NewFamily;
    this.m_CurrentDocument = _CurDocument;
    this.m_CurrentFamilyType = _CurrentFamilyType;
    this.m_OkButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    string empty = string.Empty;
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.PlantMix:
        empty = ApplicationUtility.GetString("");
        break;
      case LandcaddID.PatioWalk:
        empty = ApplicationUtility.GetString("");
        break;
      case LandcaddID.SoftTerrain:
        empty = EPShared.LocalRM.GetString("SoftTerrainManagerString");
        this.ContextualHelpID = "HID_SDfamilyNewSoftTerrain";
        break;
      case LandcaddID.Street:
        empty = EPShared.LocalRM.GetString("StreetTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyNewStreet";
        break;
      case LandcaddID.Curb:
        empty = EPShared.LocalRM.GetString("CurbTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyNewCurb";
        break;
      case LandcaddID.Sidewalk:
        empty = EPShared.LocalRM.GetString("SidewalkTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyNewSidewalk";
        break;
      case LandcaddID.RetainingWall:
        empty = EPShared.LocalRM.GetString("RetainingWallManagerString");
        this.ContextualHelpID = "HID_SDfamilyNewRetainingWall";
        break;
      case LandcaddID.Steps:
        empty = EPShared.LocalRM.GetString("StepsManagerString");
        break;
      case LandcaddID.ParkingLot:
        empty = EPShared.LocalRM.GetString("ParkingLotManagerString");
        this.ContextualHelpID = "HID_SDfamilyNewParkinglot";
        break;
    }
    this.Text = $"{EPShared.LocalRM.GetString("New_")}{empty} {EPShared.LocalRM.GetString("FamilyString")}";
    this.m_PathLbl.Text = EPShared.LocalRM.GetString("Family_AMP_Name_NewFamilyDialog");
    this.GetDialogPosition();
  }

  private void OkButtonClicked(object sender, EventArgs e)
  {
    if (!this.VerifyFileNameAndPath())
      return;
    if (this.m_FileTxt.Text.LastIndexOf("\\") < 0)
    {
      string empty = string.Empty;
      RevitUtility.GetFullFamilyFilenameIfExist(string.Empty, ref empty);
      string text = this.m_FileTxt.Text;
      this.m_FileTxt.Text = empty + text;
    }
    if (this.m_NewFamilyBinder == null)
      this.m_NewFamilyBinder = new FamilyBinder();
    string str = this.m_FileTxt.Text.Substring(this.m_FileTxt.Text.LastIndexOf("\\") + 1);
    this.m_NewFamilyBinder.FamilyName = str.Substring(0, str.LastIndexOf('.'));
    this.m_NewFamilyBinder.FamilyPath = this.m_FileTxt.Text;
    this.m_NewFamilyBinder.IsModified = true;
    this.DialogResult = DialogResult.OK;
  }

  private bool VerifyFileNameAndPath()
  {
    if (string.IsNullOrEmpty(this.m_FileTxt.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidFamilyNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (string.IsNullOrEmpty(this.m_FileTxt.Text))
    {
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Source")} {EPShared.LocalRM.GetString("NoRFAExtension")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (new FileInfo(this.m_FileTxt.Text).Extension == string.Empty)
      this.m_FileTxt.Text += ".rfa";
    if (File.Exists(this.m_FileTxt.Text))
    {
      Document document = this.m_CurrentDocument.Application.OpenDocumentFile(this.m_FileTxt.Text);
      if (document != null)
      {
        bool flag = false;
        foreach (FamilyType type in document.FamilyManager.Types)
        {
          FamilyParameter familyParameter = document.FamilyManager[RevitParameters.SiteworksIDFamilyParameter];
          if (familyParameter == null || !type.HasValue(familyParameter) || string.Compare(type.AsString(familyParameter), Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000"), true) != 0)
          {
            flag = true;
            break;
          }
        }
        if (flag)
        {
          string empty = string.Empty;
          switch (this.m_CurrentFamilyType)
          {
            case LandcaddID.SoftTerrain:
              empty += EPShared.LocalRM.GetString("ModifySoftTerrainRibbonButton");
              break;
            case LandcaddID.Street:
              empty += EPShared.LocalRM.GetString("StreetFamilyManagerRibbonButton");
              break;
            case LandcaddID.Curb:
              empty += EPShared.LocalRM.GetString("CurbFamilyManagerRibbonButton");
              break;
            case LandcaddID.Sidewalk:
              empty += EPShared.LocalRM.GetString("LocateSidewalkRibbonButton");
              break;
            case LandcaddID.RetainingWall:
              empty += EPShared.LocalRM.GetString("LocateRetainingWallRibbonButton");
              break;
            case LandcaddID.Steps:
              empty += ApplicationUtility.GetString("");
              break;
            case LandcaddID.ParkingLot:
              empty += EPShared.LocalRM.GetString("ParkingLotFamilyManagerRibbonButton");
              break;
          }
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InValidNewFamily_Message")}{empty} {EPShared.LocalRM.GetString("FamilyString")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
    }
    return true;
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnFileBtnClicked(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_FileTxt.Text = saveFileDialog.FileName;
    string str = this.m_FileTxt.Text.Substring(this.m_FileTxt.Text.LastIndexOf("\\") + 1);
    str.Substring(0, str.LastIndexOf('.'));
  }

  private void OnFocusLost(object sender, EventArgs e)
  {
    if (!this.VerifyFileNameAndPath())
      return;
    if (this.m_NewFamilyBinder == null)
      this.m_NewFamilyBinder = new FamilyBinder();
    this.m_NewFamilyBinder.FamilyPath = this.m_FileTxt.Text;
    string str = this.m_FileTxt.Text.Substring(this.m_FileTxt.Text.LastIndexOf("\\") + 1);
    str.Substring(0, str.LastIndexOf('.'));
    this.m_NewFamilyBinder.IsModified = true;
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  public string OriginalFileName => this.m_strOriginalName;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_CancelButton = new Button();
    this.m_OkButton = new Button();
    this.m_FileBtn = new Button();
    this.m_PathLbl = new Label();
    this.m_FileTxt = new TextBox();
    this.SuspendLayout();
    this.m_CancelButton.Location = new Point(414, 38);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClicked);
    this.m_OkButton.Location = new Point(333, 38);
    this.m_OkButton.Name = "m_OkButton";
    this.m_OkButton.Size = new Size(75, 23);
    this.m_OkButton.TabIndex = 3;
    this.m_OkButton.Text = "Ok";
    this.m_OkButton.UseVisualStyleBackColor = true;
    this.m_OkButton.Click += new EventHandler(this.OkButtonClicked);
    this.m_FileBtn.Location = new Point(466, 12);
    this.m_FileBtn.Name = "m_FileBtn";
    this.m_FileBtn.Size = new Size(24, 20);
    this.m_FileBtn.TabIndex = 2;
    this.m_FileBtn.Text = "...";
    this.m_FileBtn.UseVisualStyleBackColor = true;
    this.m_FileBtn.Click += new EventHandler(this.OnFileBtnClicked);
    this.m_PathLbl.AutoSize = true;
    this.m_PathLbl.Location = new Point(12, 15);
    this.m_PathLbl.Name = "m_PathLbl";
    this.m_PathLbl.Size = new Size(67, 13);
    this.m_PathLbl.TabIndex = 0;
    this.m_PathLbl.Text = "Family Name";
    this.m_FileTxt.Location = new Point(122, 12);
    this.m_FileTxt.Name = "m_FileTxt";
    this.m_FileTxt.Size = new Size(338, 20);
    this.m_FileTxt.TabIndex = 1;
    this.AcceptButton = (IButtonControl) this.m_OkButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(502, 66);
    this.Controls.Add((Control) this.m_FileBtn);
    this.Controls.Add((Control) this.m_PathLbl);
    this.Controls.Add((Control) this.m_FileTxt);
    this.Controls.Add((Control) this.m_OkButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (NewFamilyForm);
    this.Text = nameof (NewFamilyForm);
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
