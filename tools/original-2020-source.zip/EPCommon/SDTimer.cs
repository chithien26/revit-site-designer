﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SDTimer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using System;
using System.Diagnostics;

#nullable disable
namespace EPCommon;

internal class SDTimer
{
  internal Stopwatch watch = Stopwatch.StartNew();
  internal double m_totalElapsedTime;
  internal string m_taskName;
  internal string m_keyword = "";
  internal string m_timeFinished;
  internal string m_revitBuildNumber;
  internal Application m_app;

  public void Start()
  {
    this.watch.Reset();
    this.watch.Start();
  }

  public void Stop()
  {
    this.watch.Stop();
    this.m_totalElapsedTime = this.watch.Elapsed.TotalSeconds;
    this.m_timeFinished = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss");
    this.m_revitBuildNumber = $"{this.m_app.VersionBuild} {this.m_app.VersionNumber}";
    this.m_app.WriteJournalComment("[SiteDesigner]" + this.Result, false);
  }

  public double GetTotalElapsedTime() => this.watch.Elapsed.TotalSeconds;

  public string GetTimeFinished() => DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss");

  public string Result
  {
    get
    {
      return $"{this.m_taskName},{this.m_keyword},{this.m_totalElapsedTime},{this.m_revitBuildNumber},{this.m_timeFinished}";
    }
  }

  public SDTimer(string taskName, Application app)
  {
    this.m_taskName = taskName;
    this.m_app = app;
  }
}
