﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyParameterComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class FamilyParameterComparer : IComparer<FamilyParameter>
{
  private bool m_bSortByDefinitionName = true;

  int IComparer<FamilyParameter>.Compare(FamilyParameter first, FamilyParameter second)
  {
    int num = 0;
    if (this.m_bSortByDefinitionName)
    {
      if (first != null && first.Definition != null)
        num = second == null || second.Definition == null ? -1 : string.Compare(first.Definition.Name, second.Definition.Name);
      else if (second != null && second.Definition != null)
        num = 1;
    }
    return num;
  }
}
