using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;

namespace EPCommon;

public class PlantBookletForm : EPForm
{
	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private int m_nMixtListViewSortColumn = -1;

	private PlantBooklet m_dataBuffer;

	private List<FamilySymbol> m_LocalList = new List<FamilySymbol>();

	private IContainer components;

	private Button m_ExportButton;

	private Button m_CancelButton;

	private GroupBox m_DynGroupBox;

	private ListView m_TypeListView;

	private RadioButton m_AllInstancesRadioButton;

	private GroupBox m_SelectionMethodsGroupBox;

	private RadioButton m_WindowSelectRadioButton;

	private RadioButton m_SelectionSetRadioButton;

	private Button m_PickButton;

	private GroupBox m_ExportOptionsGroupBox;

	private TextBox m_ExportFileTextBox;

	private Button m_ExportFileButton;

	private Label m_ExportFileLabel;

	private RichTextBox m_RTFTextBox;

	public bool SelectionSetChecked => m_SelectionSetRadioButton.Checked;

	public bool WindowSelectChecked => m_WindowSelectRadioButton.Checked;

	public bool AllInstancesChecked => m_AllInstancesRadioButton.Checked;

	public PlantBookletForm(PlantBooklet _dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("PlantBookletDialog");
		m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
		m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
		m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
		m_AllInstancesRadioButton.Text = EPShared.LocalRM.GetString("All_AMP_InstancesDialog");
		m_PickButton.Text = EPShared.LocalRM.GetString("AMP_PickDialog");
		m_DynGroupBox.Text = EPShared.LocalRM.GetString("PlantsDialog");
		m_ExportOptionsGroupBox.Text = EPShared.LocalRM.GetString("ExportOptionsDialog");
		m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_ExportButton.Text = EPShared.LocalRM.GetString("AMP_ExportDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		EPToolTip.SetToolTip(m_ExportFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
		m_dataBuffer = _dataBuffer;
		m_FormatOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_dataBuffer.Document.DisplayUnitSystem;
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		InitializeControls();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		GetDialogPosition();
		m_SelectionSetRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantBookletSelectMethodOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_SelectionSetRadioButton.Checked = true;
				break;
			case 1:
				m_WindowSelectRadioButton.Checked = true;
				break;
			default:
				m_AllInstancesRadioButton.Checked = true;
				break;
			}
		}
		string _strReturnValue = string.Empty;
		ApplicationUtility.Settings.eplSetE_GetSetting("PlantBookletExportTextField", ref _strReturnValue);
		m_ExportFileTextBox.Text = _strReturnValue;
		SetupListView();
	}

	private void SetupListView()
	{
		m_LocalList = m_dataBuffer.ExistingPlantSymbolList;
		m_TypeListView.View = System.Windows.Forms.View.Details;
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("FamilyString"));
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"));
		int num = (m_TypeListView.Width - 5) / m_TypeListView.Columns.Count;
		for (int i = 0; i < m_TypeListView.Columns.Count; i++)
		{
			m_TypeListView.Columns[i].Width = num;
		}
	}

	public void UpdateListView()
	{
		ListViewItem listViewItem = new ListViewItem();
		string empty = string.Empty;
		m_LocalList.Clear();
		m_TypeListView.Items.Clear();
		foreach (Element item in m_dataBuffer.InstanceSet)
		{
			if (item is FamilyInstance { Symbol: not null } familyInstance && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode())
			{
				UpdateFamilySymbolContainerList(familyInstance.Symbol);
			}
		}
		for (int i = 0; i < m_LocalList.Count; i++)
		{
			empty = EPShared.LocalRM.GetString("NotAvailableString");
			listViewItem = m_TypeListView.Items.Insert(i, m_LocalList[i].Family.Name, m_LocalList[i].Family.Name, string.Empty);
			listViewItem.Tag = m_LocalList[i].Family.Name;
			if (string.Compare(m_LocalList[i].Name, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
			{
				empty = m_LocalList[i].Name;
			}
			listViewItem.SubItems.Add(empty);
		}
	}

	private void UpdateFamilySymbolContainerList(FamilySymbol _SelectedSymbol)
	{
		FamilySymbolContainer familySymbolContainer = null;
		familySymbolContainer = new FamilySymbolContainer();
		for (int i = 0; i < m_LocalList.Count; i++)
		{
			if (string.Compare(m_LocalList[i].Name, _SelectedSymbol.Name, ignoreCase: true) == 0)
			{
				return;
			}
		}
		m_LocalList.Add(_SelectedSymbol);
	}

	private void OnExportPlantBookletButtonClicked(object sender, EventArgs e)
	{
		CreateRTFFile();
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void CancelButtonClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	private void OnPlantBookletFormFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void SaveSettings()
	{
		int num = 0;
		num = ((!m_SelectionSetRadioButton.Checked) ? (m_WindowSelectRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantBookletSelectMethodOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantBookletExportTextField", m_ExportFileTextBox.Text);
	}

	private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column != m_nMixtListViewSortColumn)
		{
			m_nMixtListViewSortColumn = e.Column;
			m_TypeListView.Sorting = SortOrder.Ascending;
		}
		else if (m_TypeListView.Sorting == SortOrder.Ascending)
		{
			m_TypeListView.Sorting = SortOrder.Descending;
		}
		else
		{
			m_TypeListView.Sorting = SortOrder.Ascending;
		}
		m_TypeListView.Sort();
		m_TypeListView.ListViewItemSorter = new ListViewItemComparer(e.Column, m_TypeListView.Sorting);
	}

	private void UpdateList(int _nSelectedListIndex)
	{
		m_TypeListView.Items.RemoveAt(_nSelectedListIndex);
		ListViewItem listViewItem = null;
		string text = EPShared.LocalRM.GetString("NotAvailableString");
		listViewItem = new ListViewItem();
		listViewItem = m_TypeListView.Items.Insert(_nSelectedListIndex, m_LocalList[_nSelectedListIndex].Family.Name, m_LocalList[_nSelectedListIndex].Family.Name, string.Empty);
		if (string.Compare(m_LocalList[_nSelectedListIndex].Name, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			text = m_LocalList[_nSelectedListIndex].Name;
		}
		listViewItem.SubItems.Add(text);
	}

	private void OnExportFileButtonClicked(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = ApplicationUtility.GetString("RTFFilePickerFilter");
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		if (saveFileDialog.CheckFileExists)
		{
			DialogResult dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("OverwriteMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxButtons.YesNo, MessageBoxIcon.Hand);
			if (dialogResult == DialogResult.No || dialogResult == DialogResult.Cancel)
			{
				return;
			}
		}
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_ExportFileTextBox.Text = saveFileDialog.FileName;
		}
	}

	private void OnExportFileTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			AddExtensionToExportFile();
		}
	}

	private void CreateRTFFile()
	{
		if (m_ExportFileTextBox.Text == string.Empty)
		{
			return;
		}
		ElementSet elementSet = new ElementSet();
		List<FamilySymbol> list = new List<FamilySymbol>();
		if (m_TypeListView.SelectedItems.Count >= 1)
		{
			for (int i = 0; i < m_TypeListView.SelectedIndices.Count; i++)
			{
				list.Add(m_LocalList[m_TypeListView.SelectedIndices[i]]);
			}
			FamilyInstance familyInstance = null;
			foreach (Element item in m_dataBuffer.InstanceSet)
			{
				if (!(item is FamilyInstance familyInstance2))
				{
					continue;
				}
				for (int j = 0; j < list.Count; j++)
				{
					if (string.Compare(familyInstance2.Symbol.Name, list[j].Name, ignoreCase: true) == 0)
					{
						elementSet.Insert(familyInstance2);
						break;
					}
				}
			}
			if (list.Count <= 0)
			{
				return;
			}
			bool flag = false;
			List<string> list2 = new List<string>();
			list2.Add(EPShared.LocalRM.GetString("TrunkRadiusPlantParameter"));
			list2.Add(EPShared.LocalRM.GetString("TrunkHeightPlantParameter"));
			list2.Add(EPShared.LocalRM.GetString("TickLengthPlantParameter"));
			list2.Add(EPShared.LocalRM.GetString("RadiusPlantParameter"));
			list2.Add(EPShared.LocalRM.GetString("OmniClassTitlePlantParameter"));
			list2.Add(EPShared.LocalRM.GetString("OmniClassNumberPlantParameter"));
			list2.Add(EPShared.LocalRM.GetString("RPCRenderAppearancePropertiesFamilyParameter"));
			list2.Add(EPShared.LocalRM.GetString("RPCRenderAppearanceFamilyParameter"));
			if (m_ExportFileTextBox.Text.IndexOf(".rtf") < 0)
			{
				if (m_ExportFileTextBox.Text.IndexOf("\\") <= 0 && m_ExportFileTextBox.Text.IndexOf("/") <= 0)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return;
				}
				int length = -1;
				if (m_ExportFileTextBox.Text.IndexOf("\\") > 0)
				{
					length = m_ExportFileTextBox.Text.LastIndexOf("\\");
				}
				else if (m_ExportFileTextBox.Text.IndexOf("/") > 0)
				{
					length = m_ExportFileTextBox.Text.LastIndexOf("/");
				}
				if (!Directory.Exists(m_ExportFileTextBox.Text.Substring(0, length)))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return;
				}
				m_ExportFileTextBox.Text += ".rtf";
			}
			else
			{
				if (m_ExportFileTextBox.Text.IndexOf("\\") <= 0 && m_ExportFileTextBox.Text.IndexOf("/") <= 0)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return;
				}
				int length2 = -1;
				if (m_ExportFileTextBox.Text.IndexOf("\\") > 0)
				{
					length2 = m_ExportFileTextBox.Text.LastIndexOf("\\");
				}
				else if (m_ExportFileTextBox.Text.IndexOf("/") > 0)
				{
					length2 = m_ExportFileTextBox.Text.LastIndexOf("/");
				}
				if (!Directory.Exists(m_ExportFileTextBox.Text.Substring(0, length2)))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return;
				}
			}
			if (File.Exists(m_ExportFileTextBox.Text))
			{
				DialogResult dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("FileOverwriteMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
				if (dialogResult == DialogResult.No)
				{
					File.Delete(m_ExportFileTextBox.Text);
				}
				else
				{
					flag = true;
				}
			}
			if (flag)
			{
				m_RTFTextBox.LoadFile(m_ExportFileTextBox.Text);
			}
			else
			{
				m_RTFTextBox.Text = "";
			}
			Font selectionFont = new Font("Arial", 16f, FontStyle.Bold);
			Font selectionFont2 = new Font("Arial", 14f, FontStyle.Bold);
			Font selectionFont3 = new Font("Arial", 12f, FontStyle.Bold);
			Font selectionFont4 = new Font("Arial", 12f, FontStyle.Regular);
			m_RTFTextBox.Multiline = true;
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
			Dictionary<string, string> dictionary3 = new Dictionary<string, string>();
			Dictionary<string, string> dictionary4 = new Dictionary<string, string>();
			Dictionary<string, string> dictionary5 = new Dictionary<string, string>();
			Dictionary<string, string> dictionary6 = new Dictionary<string, string>();
			FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_dataBuffer.Document);
			List<Element> list3 = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements()
				.ToList();
			m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
			foreach (FamilySymbol item2 in list)
			{
				FamilySymbol familySymbol = item2;
				string empty = string.Empty;
				string empty2 = string.Empty;
				bool flag2 = false;
				bool flag3 = false;
				Parameter parameter = null;
				Parameter parameter2 = null;
				Eps_Point eps_Point = new Eps_Point();
				FamilyInstance familyInstance3 = null;
				List<Eps_Point> list4 = null;
				LocationPoint locationPoint = null;
				Eps_Point eps_Point2 = null;
				if (familySymbol == null)
				{
					continue;
				}
				list4 = null;
				foreach (Element item3 in list3)
				{
					if (item3 is FamilyInstance { Symbol: not null } familyInstance4 && familyInstance4.Symbol.Category != null && familyInstance4.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(familySymbol.UniqueId, familyInstance4.Symbol.UniqueId, ignoreCase: true) == 0)
					{
						if (list4 == null)
						{
							list4 = new List<Eps_Point>();
						}
						locationPoint = familyInstance4.Location as LocationPoint;
						eps_Point2 = new Eps_Point(locationPoint.Point);
						if (!RevitUtility.IsPointInPointList(eps_Point2, list4))
						{
							list4.Add(eps_Point2);
						}
					}
				}
				if (list4 != null && list4.Count > 0)
				{
					bool flag4 = true;
					while (flag4)
					{
						flag4 = false;
						for (int k = 0; k < list4.Count; k++)
						{
							if (EPShared.eplGeoE_ArePntsDuplicates3D(list4[k], eps_Point))
							{
								eps_Point.z++;
								flag4 = true;
								break;
							}
						}
					}
				}
				EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
				FamilyInstance familyInstance5 = RevitUtility.NewFamilyInstance(m_dataBuffer.Document, eps_Point.XYZ, familySymbol, null, m_dataBuffer.Document.ActiveView.GenLevel, StructuralType.NonStructural, ref _TransactionContainer);
				m_dataBuffer.TransactionContainer = _TransactionContainer;
				if (familyInstance5 != null)
				{
					parameter = familyInstance5.LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
					if (parameter != null)
					{
						flag2 = true;
					}
					parameter2 = familyInstance5.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
					if (parameter2 != null)
					{
						flag3 = true;
					}
				}
				m_RTFTextBox.SelectedText += "\t\t\t\t\t";
				m_RTFTextBox.SelectionFont = selectionFont;
				m_RTFTextBox.SelectedText += familySymbol.Name;
				m_RTFTextBox.SelectedText += "\n";
				m_RTFTextBox.SelectedText += "\n";
				foreach (Parameter parameter3 in familySymbol.Parameters)
				{
					empty = parameter3.Definition.Name;
					empty2 = ((parameter3.StorageType != StorageType.String) ? parameter3.AsValueString() : parameter3.AsString());
					if (empty2 == null)
					{
						empty2 = string.Empty;
					}
					if (empty.StartsWith(EPShared.LocalRM.GetString("Plant"), ignoreCase: true, CultureInfo.CurrentCulture))
					{
						if (empty2 != string.Empty && (string.Compare(empty, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), ignoreCase: true) != 0 || !flag2) && (string.Compare(empty, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), ignoreCase: true) != 0 || flag3))
						{
							try
							{
								dictionary.Add(empty, empty2);
							}
							catch
							{
							}
						}
					}
					else if (empty.StartsWith(EPShared.LocalRM.GetString("Characteristics"), ignoreCase: true, CultureInfo.CurrentCulture))
					{
						if (empty2 != string.Empty)
						{
							empty = empty.Remove(0, EPShared.LocalRM.GetString("Characteristics").Length + 1);
							try
							{
								dictionary2.Add(empty, empty2);
							}
							catch
							{
							}
						}
					}
					else if (empty.StartsWith(EPShared.LocalRM.GetString("Condition"), ignoreCase: true, CultureInfo.CurrentCulture))
					{
						if (empty2 != string.Empty)
						{
							empty = empty.Remove(0, EPShared.LocalRM.GetString("Condition").Length + 1);
							try
							{
								dictionary3.Add(empty, empty2);
							}
							catch
							{
							}
						}
					}
					else if (empty.StartsWith(EPShared.LocalRM.GetString("Growth"), ignoreCase: true, CultureInfo.CurrentCulture))
					{
						if (empty2 != string.Empty)
						{
							empty = empty.Remove(0, EPShared.LocalRM.GetString("Growth").Length + 1);
							try
							{
								dictionary4.Add(empty, empty2);
							}
							catch
							{
							}
						}
					}
					else if (empty.StartsWith(EPShared.LocalRM.GetString("Maintenance"), ignoreCase: true, CultureInfo.CurrentCulture))
					{
						if (empty2 != string.Empty)
						{
							empty = empty.Remove(0, EPShared.LocalRM.GetString("Maintenance").Length + 1);
							try
							{
								dictionary5.Add(empty, empty2);
							}
							catch
							{
							}
						}
					}
					else if (empty2 != string.Empty && (string.Compare(empty, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), ignoreCase: true) != 0 || !flag2))
					{
						try
						{
							dictionary6.Add(empty, empty2);
						}
						catch
						{
						}
					}
				}
				if (flag2)
				{
					dictionary.Add(parameter.Definition.Name, parameter.AsValueString());
				}
				if (flag3)
				{
					dictionary.Add(parameter2.Definition.Name, parameter2.AsValueString());
				}
				m_dataBuffer.TransactionContainer.BeginTransaction();
				m_dataBuffer.Document.Delete(familyInstance5.Id);
				m_dataBuffer.TransactionContainer.EndTransaction();
				int num = 0;
				for (num = 0; num < dictionary.Count; num++)
				{
					if (dictionary.ElementAt(num).Value != string.Empty && !FindMatch(list2, dictionary.ElementAt(num).Key))
					{
						m_RTFTextBox.SelectionFont = selectionFont3;
						m_RTFTextBox.SelectedText += dictionary.ElementAt(num).Key;
						if (dictionary.ElementAt(num).Value != string.Empty)
						{
							m_RTFTextBox.SelectionFont = selectionFont4;
							m_RTFTextBox.SelectedText += " = ";
							m_RTFTextBox.SelectedText += dictionary.ElementAt(num).Value;
						}
						m_RTFTextBox.SelectedText += "\n";
					}
				}
				if (dictionary2.Count > 0)
				{
					m_RTFTextBox.SelectionFont = selectionFont2;
					m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Characteristics");
					m_RTFTextBox.SelectedText += "\n";
					for (num = 0; num < dictionary2.Count; num++)
					{
						if (dictionary2.ElementAt(num).Value != string.Empty && !FindMatch(list2, dictionary2.ElementAt(num).Key))
						{
							m_RTFTextBox.SelectedText += "\t";
							m_RTFTextBox.SelectionFont = selectionFont3;
							m_RTFTextBox.SelectedText += dictionary2.ElementAt(num).Key;
							if (dictionary2.ElementAt(num).Value != string.Empty)
							{
								m_RTFTextBox.SelectionFont = selectionFont4;
								m_RTFTextBox.SelectedText += " = ";
								m_RTFTextBox.SelectedText += dictionary2.ElementAt(num).Value;
							}
							m_RTFTextBox.SelectedText += "\n";
						}
					}
				}
				if (dictionary3.Count > 0)
				{
					m_RTFTextBox.SelectionFont = selectionFont3;
					m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Condition");
					m_RTFTextBox.SelectedText += "\n";
					for (num = 0; num < dictionary3.Count; num++)
					{
						if (dictionary3.ElementAt(num).Value != string.Empty && !FindMatch(list2, dictionary3.ElementAt(num).Key))
						{
							m_RTFTextBox.SelectionFont = selectionFont3;
							m_RTFTextBox.SelectedText += "\t";
							m_RTFTextBox.SelectedText += dictionary3.ElementAt(num).Key;
							if (dictionary3.ElementAt(num).Value != string.Empty)
							{
								m_RTFTextBox.SelectionFont = selectionFont4;
								m_RTFTextBox.SelectedText += " = ";
								m_RTFTextBox.SelectedText += dictionary3.ElementAt(num).Value;
							}
							m_RTFTextBox.SelectedText += "\n";
						}
					}
				}
				if (dictionary4.Count > 0)
				{
					m_RTFTextBox.SelectionFont = selectionFont2;
					m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Growth");
					m_RTFTextBox.SelectedText += "\n";
					for (num = 0; num < dictionary4.Count; num++)
					{
						if (dictionary4.ElementAt(num).Value != string.Empty && !FindMatch(list2, dictionary4.ElementAt(num).Key))
						{
							m_RTFTextBox.SelectedText += "\t";
							m_RTFTextBox.SelectionFont = selectionFont3;
							m_RTFTextBox.SelectedText += dictionary4.ElementAt(num).Key;
							if (dictionary4.ElementAt(num).Value != string.Empty)
							{
								m_RTFTextBox.SelectionFont = selectionFont4;
								m_RTFTextBox.SelectedText += " = ";
								m_RTFTextBox.SelectedText += dictionary4.ElementAt(num).Value;
							}
							m_RTFTextBox.SelectedText += "\n";
						}
					}
				}
				if (dictionary5.Count > 0)
				{
					m_RTFTextBox.SelectionFont = selectionFont2;
					m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Maintenance");
					m_RTFTextBox.SelectedText += "\n";
					for (num = 0; num < dictionary5.Count; num++)
					{
						if (dictionary5.ElementAt(num).Value != string.Empty && !FindMatch(list2, dictionary5.ElementAt(num).Key))
						{
							m_RTFTextBox.SelectedText += "\t";
							m_RTFTextBox.SelectionFont = selectionFont3;
							m_RTFTextBox.SelectedText += dictionary5.ElementAt(num).Key;
							if (dictionary5.ElementAt(num).Value != string.Empty)
							{
								m_RTFTextBox.SelectionFont = selectionFont4;
								m_RTFTextBox.SelectedText += " = ";
								m_RTFTextBox.SelectedText += dictionary5.ElementAt(num).Value;
							}
							m_RTFTextBox.SelectedText += "\n";
						}
					}
				}
				if (dictionary6.Count > 0)
				{
					m_RTFTextBox.SelectionFont = selectionFont2;
					m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Others");
					m_RTFTextBox.SelectedText += "\n";
					for (num = 0; num < dictionary6.Count; num++)
					{
						if (dictionary6.ElementAt(num).Value != string.Empty && !FindMatch(list2, dictionary6.ElementAt(num).Key))
						{
							m_RTFTextBox.SelectionFont = selectionFont3;
							m_RTFTextBox.SelectedText += "\t";
							m_RTFTextBox.SelectedText += dictionary6.ElementAt(num).Key;
							if (dictionary6.ElementAt(num).Value != string.Empty)
							{
								m_RTFTextBox.SelectionFont = selectionFont4;
								m_RTFTextBox.SelectedText += " = ";
								m_RTFTextBox.SelectedText += dictionary6.ElementAt(num).Value;
							}
							m_RTFTextBox.SelectedText += "\n";
						}
					}
				}
				m_RTFTextBox.SelectedText += "\n\n\n";
				dictionary.Clear();
				dictionary2.Clear();
				dictionary3.Clear();
				dictionary4.Clear();
				dictionary5.Clear();
				dictionary6.Clear();
			}
			m_dataBuffer.TransactionContainer.Rollback();
			m_RTFTextBox.SaveFile(m_ExportFileTextBox.Text, RichTextBoxStreamType.RichText);
			Process.Start("\"" + m_ExportFileTextBox.Text + "\"");
		}
		else
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantSymbolSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		}
	}

	private static bool FindMatch(List<string> _List, string _strCurrentString)
	{
		foreach (string _ in _List)
		{
			if (string.Compare(_, _strCurrentString, ignoreCase: true) == 0)
			{
				return true;
			}
		}
		return false;
	}

	private void OnPickButtonClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Retry;
		Close();
	}

	private void AddExtensionToExportFile()
	{
		if (!string.IsNullOrEmpty(m_ExportFileTextBox.Text))
		{
			FileInfo fileInfo = new FileInfo(m_ExportFileTextBox.Text);
			if (fileInfo.Extension == string.Empty)
			{
				m_ExportFileTextBox.Text += ".rtf";
			}
		}
	}

	private void OnExportFileTextBoxLeave(object sender, EventArgs e)
	{
		AddExtensionToExportFile();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ExportButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_DynGroupBox = new System.Windows.Forms.GroupBox();
		this.m_TypeListView = new System.Windows.Forms.ListView();
		this.m_AllInstancesRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionMethodsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_PickButton = new System.Windows.Forms.Button();
		this.m_WindowSelectRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionSetRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ExportOptionsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ExportFileTextBox = new System.Windows.Forms.TextBox();
		this.m_ExportFileButton = new System.Windows.Forms.Button();
		this.m_ExportFileLabel = new System.Windows.Forms.Label();
		this.m_RTFTextBox = new System.Windows.Forms.RichTextBox();
		this.m_DynGroupBox.SuspendLayout();
		this.m_SelectionMethodsGroupBox.SuspendLayout();
		this.m_ExportOptionsGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_ExportButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportButton.Location = new System.Drawing.Point(230, 384);
		this.m_ExportButton.Name = "m_ExportButton";
		this.m_ExportButton.Size = new System.Drawing.Size(77, 23);
		this.m_ExportButton.TabIndex = 3;
		this.m_ExportButton.Text = "&Export";
		this.m_ExportButton.UseVisualStyleBackColor = true;
		this.m_ExportButton.Click += new System.EventHandler(this.OnExportPlantBookletButtonClicked);
		this.m_CancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CancelButton.Location = new System.Drawing.Point(313, 384);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.CancelButtonClicked);
		this.m_DynGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DynGroupBox.Controls.Add(this.m_TypeListView);
		this.m_DynGroupBox.Location = new System.Drawing.Point(12, 93);
		this.m_DynGroupBox.Name = "m_DynGroupBox";
		this.m_DynGroupBox.Size = new System.Drawing.Size(376, 217);
		this.m_DynGroupBox.TabIndex = 1;
		this.m_DynGroupBox.TabStop = false;
		this.m_DynGroupBox.Text = "Plants";
		this.m_TypeListView.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_TypeListView.FullRowSelect = true;
		this.m_TypeListView.HideSelection = false;
		this.m_TypeListView.Location = new System.Drawing.Point(7, 13);
		this.m_TypeListView.Name = "m_TypeListView";
		this.m_TypeListView.Size = new System.Drawing.Size(358, 198);
		this.m_TypeListView.TabIndex = 0;
		this.m_TypeListView.UseCompatibleStateImageBehavior = false;
		this.m_TypeListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.OnMixListViewColumnClick);
		this.m_AllInstancesRadioButton.AutoSize = true;
		this.m_AllInstancesRadioButton.Location = new System.Drawing.Point(6, 64);
		this.m_AllInstancesRadioButton.Name = "m_AllInstancesRadioButton";
		this.m_AllInstancesRadioButton.Size = new System.Drawing.Size(85, 17);
		this.m_AllInstancesRadioButton.TabIndex = 2;
		this.m_AllInstancesRadioButton.TabStop = true;
		this.m_AllInstancesRadioButton.Text = "All &Instances";
		this.m_AllInstancesRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionMethodsGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_PickButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_AllInstancesRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_WindowSelectRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_SelectionSetRadioButton);
		this.m_SelectionMethodsGroupBox.Location = new System.Drawing.Point(12, 0);
		this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
		this.m_SelectionMethodsGroupBox.Size = new System.Drawing.Size(376, 87);
		this.m_SelectionMethodsGroupBox.TabIndex = 0;
		this.m_SelectionMethodsGroupBox.TabStop = false;
		this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
		this.m_PickButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_PickButton.Location = new System.Drawing.Point(290, 35);
		this.m_PickButton.Name = "m_PickButton";
		this.m_PickButton.Size = new System.Drawing.Size(75, 23);
		this.m_PickButton.TabIndex = 3;
		this.m_PickButton.Text = "&Pick";
		this.m_PickButton.UseVisualStyleBackColor = true;
		this.m_PickButton.Click += new System.EventHandler(this.OnPickButtonClicked);
		this.m_WindowSelectRadioButton.AutoSize = true;
		this.m_WindowSelectRadioButton.Location = new System.Drawing.Point(6, 41);
		this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
		this.m_WindowSelectRadioButton.Size = new System.Drawing.Size(97, 17);
		this.m_WindowSelectRadioButton.TabIndex = 1;
		this.m_WindowSelectRadioButton.TabStop = true;
		this.m_WindowSelectRadioButton.Text = "Window S&elect";
		this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionSetRadioButton.AutoSize = true;
		this.m_SelectionSetRadioButton.Location = new System.Drawing.Point(6, 19);
		this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
		this.m_SelectionSetRadioButton.Size = new System.Drawing.Size(88, 17);
		this.m_SelectionSetRadioButton.TabIndex = 0;
		this.m_SelectionSetRadioButton.TabStop = true;
		this.m_SelectionSetRadioButton.Text = "&Selection Set";
		this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
		this.m_ExportOptionsGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFileTextBox);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFileButton);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFileLabel);
		this.m_ExportOptionsGroupBox.Location = new System.Drawing.Point(12, 315);
		this.m_ExportOptionsGroupBox.Name = "m_ExportOptionsGroupBox";
		this.m_ExportOptionsGroupBox.Size = new System.Drawing.Size(376, 57);
		this.m_ExportOptionsGroupBox.TabIndex = 2;
		this.m_ExportOptionsGroupBox.TabStop = false;
		this.m_ExportOptionsGroupBox.Text = "Export Options";
		this.m_ExportFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportFileTextBox.Location = new System.Drawing.Point(57, 23);
		this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
		this.m_ExportFileTextBox.Size = new System.Drawing.Size(282, 20);
		this.m_ExportFileTextBox.TabIndex = 1;
		this.m_ExportFileTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnExportFileTextBoxKeyDown);
		this.m_ExportFileTextBox.Leave += new System.EventHandler(this.OnExportFileTextBoxLeave);
		this.m_ExportFileButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportFileButton.Location = new System.Drawing.Point(345, 23);
		this.m_ExportFileButton.Name = "m_ExportFileButton";
		this.m_ExportFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_ExportFileButton.TabIndex = 2;
		this.m_ExportFileButton.TabStop = false;
		this.m_ExportFileButton.Text = "...";
		this.m_ExportFileButton.UseVisualStyleBackColor = true;
		this.m_ExportFileButton.Click += new System.EventHandler(this.OnExportFileButtonClicked);
		this.m_ExportFileLabel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ExportFileLabel.AutoSize = true;
		this.m_ExportFileLabel.Location = new System.Drawing.Point(5, 26);
		this.m_ExportFileLabel.Name = "m_ExportFileLabel";
		this.m_ExportFileLabel.Size = new System.Drawing.Size(26, 13);
		this.m_ExportFileLabel.TabIndex = 0;
		this.m_ExportFileLabel.Text = "Fi&le:";
		this.m_RTFTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_RTFTextBox.BulletIndent = 5;
		this.m_RTFTextBox.Location = new System.Drawing.Point(12, 37);
		this.m_RTFTextBox.Margin = new System.Windows.Forms.Padding(5);
		this.m_RTFTextBox.Name = "m_RTFTextBox";
		this.m_RTFTextBox.Size = new System.Drawing.Size(317, 197);
		this.m_RTFTextBox.TabIndex = 0;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(400, 419);
		base.Controls.Add(this.m_ExportOptionsGroupBox);
		base.Controls.Add(this.m_SelectionMethodsGroupBox);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_ExportButton);
		base.Controls.Add(this.m_DynGroupBox);
		this.MinimumSize = new System.Drawing.Size(408, 446);
		base.Name = "PlantBookletForm";
		this.Text = "Plant Booklet";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantBookletFormFormClosing);
		this.m_DynGroupBox.ResumeLayout(false);
		this.m_SelectionMethodsGroupBox.ResumeLayout(false);
		this.m_SelectionMethodsGroupBox.PerformLayout();
		this.m_ExportOptionsGroupBox.ResumeLayout(false);
		this.m_ExportOptionsGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.AcceptButton = this.m_ExportButton;
		base.CancelButton = this.m_CancelButton;
	}
}
