﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParameterColumn
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class ParameterColumn
{
  private PlantField m_PlantField;
  private int m_nOrder;

  public ParameterColumn(PlantField _PlantField, int _nOrder)
  {
    this.m_PlantField = _PlantField;
    this.m_nOrder = _nOrder;
  }

  public PlantField PlantField
  {
    get => this.m_PlantField;
    set => this.m_PlantField = value;
  }

  public int Order
  {
    get => this.m_nOrder;
    set => this.m_nOrder = value;
  }
}
