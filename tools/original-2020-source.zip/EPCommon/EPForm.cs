﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.EPForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Microsoft.Win32;
using SITES.Sites_Core;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class EPForm : Form
{
  private FormBorderStyle m_FormBorderStyle;
  private ToolTip m_EPToolTip = new ToolTip();
  private bool m_bOverrideKeyUp;
  private string m_contextualHelpID = "HID_SDaaa";
  private IContainer components;
  private HelpProvider m_HelpProvider;

  public EPForm()
  {
    this.InitializeComponent();
    this.m_EPToolTip.AutoPopDelay = 5000;
    this.m_EPToolTip.InitialDelay = 1000;
    this.m_EPToolTip.ReshowDelay = 500;
    this.m_EPToolTip.ShowAlways = true;
    this.ShowInTaskbar = false;
  }

  private void OnFormLoad(object sender, EventArgs e)
  {
    this.m_FormBorderStyle = this.FormBorderStyle;
    this.MinimizeBox = false;
    this.MaximizeBox = false;
    this.HelpButton = true;
  }

  private void OnHelpButtonClicked(object sender, CancelEventArgs e)
  {
    e.Cancel = true;
    RevitUtility.ShowHelpInRevit(this.m_contextualHelpID);
  }

  private void EPForm_HelpRequested(object sender, HelpEventArgs hlpevent)
  {
    RevitUtility.ShowHelpInRevit(this.m_contextualHelpID);
  }

  public void GetDialogPosition()
  {
    this.m_FormBorderStyle = this.FormBorderStyle;
    Point location1 = Screen.PrimaryScreen.Bounds.Location;
    this.Location = new Point(location1.X + 30, location1.Y + 30);
    this.StartPosition = FormStartPosition.Manual;
    RegistryKey registryKey = Registry.CurrentUser.OpenSubKey($"{ApplicationUtility.CurrentUserRegistryKey}\\{this.Text}");
    if (registryKey == null)
      return;
    if (registryKey.GetValue("X") != null && registryKey.GetValue("Y") != null && (int) registryKey.GetValue("X") >= 0 && (int) registryKey.GetValue("Y") >= 0)
    {
      this.Location = new Point((int) registryKey.GetValue("X"), (int) registryKey.GetValue("Y"));
      bool flag = false;
      Screen[] allScreens = Screen.AllScreens;
      for (int index = 0; index < allScreens.Length; ++index)
      {
        Point location2 = this.Location;
        int x1 = location2.X;
        Rectangle bounds = allScreens[index].Bounds;
        int left = bounds.Left;
        if (x1 >= left)
        {
          location2 = this.Location;
          int x2 = location2.X;
          bounds = allScreens[index].Bounds;
          int right = bounds.Right;
          if (x2 <= right)
          {
            location2 = this.Location;
            int y1 = location2.Y;
            bounds = allScreens[index].Bounds;
            int top = bounds.Top;
            if (y1 >= top)
            {
              location2 = this.Location;
              int y2 = location2.Y;
              bounds = allScreens[index].Bounds;
              int bottom = bounds.Bottom;
              if (y2 <= bottom)
              {
                flag = true;
                break;
              }
            }
          }
        }
      }
      if (!flag)
      {
        this.Location = new Point(location1.X + 30, location1.Y + 30);
        this.SetDialogPosition();
      }
    }
    if ((this.m_FormBorderStyle == FormBorderStyle.Sizable || this.m_FormBorderStyle == FormBorderStyle.SizableToolWindow) && registryKey.GetValue("Height") != null && registryKey.GetValue("Width") != null && (int) registryKey.GetValue("Width") >= this.MinimumSize.Width && (int) registryKey.GetValue("Height") >= this.MinimumSize.Height)
      this.Size = new Size((int) registryKey.GetValue("Width"), (int) registryKey.GetValue("Height"));
    registryKey.Close();
  }

  public void SetDialogPosition()
  {
    RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(ApplicationUtility.CurrentUserRegistryKey + this.Text, true) ?? Registry.CurrentUser.CreateSubKey($"{ApplicationUtility.CurrentUserRegistryKey}\\{this.Text}");
    if (registryKey == null)
      return;
    registryKey.SetValue("X", (object) this.Location.X);
    registryKey.SetValue("Y", (object) this.Location.Y);
    if (this.m_FormBorderStyle == FormBorderStyle.Sizable || this.m_FormBorderStyle == FormBorderStyle.SizableToolWindow)
    {
      registryKey.SetValue("Width", (object) this.Size.Width);
      registryKey.SetValue("Height", (object) this.Size.Height);
    }
    registryKey.Close();
  }

  private void OnFormKeyUp(object sender, KeyEventArgs e)
  {
    if (!this.m_bOverrideKeyUp)
    {
      if (e.KeyCode != Keys.Escape)
        return;
      this.DialogResult = DialogResult.Cancel;
      this.Close();
    }
    else
      this.m_bOverrideKeyUp = false;
  }

  public void OverrideKeyUp() => this.m_bOverrideKeyUp = true;

  public string ContextualHelpID
  {
    set => this.m_contextualHelpID = value;
  }

  public ToolTip EPToolTip
  {
    get => this.m_EPToolTip;
    set => this.m_EPToolTip = value;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_HelpProvider = new HelpProvider();
    this.SuspendLayout();
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(292, 266);
    this.HelpButton = true;
    this.m_HelpProvider.SetHelpNavigator((Control) this, HelpNavigator.KeywordIndex);
    this.Icon = Resources.Siteworks;
    this.KeyPreview = true;
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = nameof (EPForm);
    this.m_HelpProvider.SetShowHelp((Control) this, false);
    this.HelpButtonClicked += new CancelEventHandler(this.OnHelpButtonClicked);
    this.Load += new EventHandler(this.OnFormLoad);
    this.HelpRequested += new HelpEventHandler(this.EPForm_HelpRequested);
    this.KeyUp += new KeyEventHandler(this.OnFormKeyUp);
    this.ResumeLayout(false);
  }
}
