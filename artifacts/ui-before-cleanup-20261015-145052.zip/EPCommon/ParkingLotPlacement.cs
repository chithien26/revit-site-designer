using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;

namespace EPCommon;

public class ParkingLotPlacement
{
	private ParkingLotPlacementForm m_ParkingLotPlacementForm;

	private Document m_Document;

	private List<Autodesk.Revit.DB.View> m_ViewList;

	private List<TopographySurfaceContainer> m_SurfaceList;

	private List<FamilyContainer> m_ParkingStallFamilyList;

	private List<FamilyContainer> m_ParkingBumperFamilyList;

	private List<FamilyContainer> m_ADAParkingStallFamilyList;

	private List<FamilyContainer> m_ParkingIslandFamilyList;

	private PlacementSettings m_PlacementSettings;

	private EPTransactionContainer m_TransactionContainer;

	private FamilySymbol m_PlacementSymbol;

	public ReadOnlyCollection<Autodesk.Revit.DB.View> Views => new ReadOnlyCollection<Autodesk.Revit.DB.View>(m_ViewList);

	public Document Document => m_Document;

	public ReadOnlyCollection<FamilyContainer> ParkingStallFamilyList => new ReadOnlyCollection<FamilyContainer>(m_ParkingStallFamilyList);

	public ReadOnlyCollection<FamilyContainer> ADAParkingStallFamilyList => new ReadOnlyCollection<FamilyContainer>(m_ADAParkingStallFamilyList);

	public ReadOnlyCollection<FamilyContainer> ParkingBumperFamilyList => new ReadOnlyCollection<FamilyContainer>(m_ParkingBumperFamilyList);

	public ReadOnlyCollection<FamilyContainer> ParkingIslandFamilyList => new ReadOnlyCollection<FamilyContainer>(m_ParkingIslandFamilyList);

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList => new ReadOnlyCollection<TopographySurfaceContainer>(m_SurfaceList);

	public ParkingLotPlacement(Document _CurDocument)
	{
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_ViewList = new List<Autodesk.Revit.DB.View>();
		m_SurfaceList = new List<TopographySurfaceContainer>();
		m_ParkingStallFamilyList = new List<FamilyContainer>();
		m_ParkingBumperFamilyList = new List<FamilyContainer>();
		m_ADAParkingStallFamilyList = new List<FamilyContainer>();
		m_ParkingIslandFamilyList = new List<FamilyContainer>();
		InitializeListData();
	}

	public void PopulateFamilyAndSymbolLists()
	{
		PopulateFamilyAndSymbolLists(_bAllSymbols: true, LandcaddID.ParkingStall);
	}

	public void PopulateFamilyAndSymbolLists(LandcaddID _ParkingType)
	{
		PopulateFamilyAndSymbolLists(_bAllSymbols: false, _ParkingType);
	}

	private void PopulateFamilyAndSymbolLists(bool _bAllSymbols, LandcaddID _ParkingType)
	{
		int num = 0;
		if (_bAllSymbols || _ParkingType == LandcaddID.ParkingStall)
		{
			m_ParkingStallFamilyList.Clear();
		}
		if (_bAllSymbols || _ParkingType == LandcaddID.ADAParkingStall)
		{
			m_ADAParkingStallFamilyList.Clear();
		}
		if (_bAllSymbols || _ParkingType == LandcaddID.ParkingBumper)
		{
			m_ParkingBumperFamilyList.Clear();
		}
		if (_bAllSymbols || _ParkingType == LandcaddID.ParkingIsland)
		{
			m_ParkingIslandFamilyList.Clear();
		}
		Parameter parameter = null;
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_Parking);
		IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter) != null);
		List<Element> list = source.ToList();
		FamilySymbol familySymbol = null;
		foreach (Element item in list)
		{
			if (!(item is FamilySymbol { Category: not null } familySymbol2) || familySymbol2.Category.Id.Value64() != BuiltInCategory.OST_Parking.GetHashCode())
			{
				continue;
			}
			parameter = familySymbol2.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
			if (parameter == null)
			{
				continue;
			}
			if (string.Compare(parameter.AsString(), Convert.ToInt32(LandcaddID.ParkingStall).ToString("000"), ignoreCase: true) == 0)
			{
				if (_bAllSymbols || _ParkingType == LandcaddID.ParkingStall)
				{
					PopulateFamilySymbolInList(familySymbol2, ref m_ParkingStallFamilyList);
				}
			}
			else if (string.Compare(parameter.AsString(), Convert.ToInt32(LandcaddID.ADAParkingStall).ToString("000"), ignoreCase: true) == 0)
			{
				if (_bAllSymbols || _ParkingType == LandcaddID.ADAParkingStall)
				{
					PopulateFamilySymbolInList(familySymbol2, ref m_ADAParkingStallFamilyList);
				}
			}
			else if (string.Compare(parameter.AsString(), Convert.ToInt32(LandcaddID.ParkingBumper).ToString("000"), ignoreCase: true) == 0)
			{
				if (_bAllSymbols || _ParkingType == LandcaddID.ParkingBumper)
				{
					PopulateFamilySymbolInList(familySymbol2, ref m_ParkingBumperFamilyList);
				}
			}
			else if (string.Compare(parameter.AsString(), Convert.ToInt32(LandcaddID.ParkingIsland).ToString("000"), ignoreCase: true) == 0 && (_bAllSymbols || _ParkingType == LandcaddID.ParkingIsland))
			{
				PopulateFamilySymbolInList(familySymbol2, ref m_ParkingIslandFamilyList);
			}
		}
		bool flag = true;
		filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel);
		Parameter CurLanddCadID = null;
		IEnumerable<Element> source2 = filteredElementCollector.Where((Element CurrentElement) => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0);
		list = source2.ToList();
		flag = false;
		familySymbol = null;
		foreach (Element item2 in list)
		{
			if (item2 is FamilySymbol { Category: not null } familySymbol3)
			{
				CurLanddCadID = familySymbol3.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
				if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0)
				{
					m_PlacementSymbol = familySymbol3;
					flag = true;
					break;
				}
			}
		}
		if (_bAllSymbols && (m_ParkingStallFamilyList.Count == 0 || m_ADAParkingStallFamilyList.Count == 0 || m_ParkingBumperFamilyList.Count == 0 || m_ParkingIslandFamilyList.Count == 0 || !flag))
		{
			List<string> list2 = new List<string>();
			list2.Add(EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"));
			list2.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, "ParkingLot", EPShared.LocalRM.GetString("ParkingFamiliesNotLoadedMessage"), list2);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), ignoreCase: true) == 0)
			{
				Family _Family = null;
				string _strFullFamilyFilename = string.Empty;
				if (m_ParkingStallFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Standard Parking.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId in _Family.GetFamilySymbolIds())
						{
							if (m_Document.GetElement(familySymbolId) is FamilySymbol curFamilySymbol)
							{
								PopulateFamilySymbolInList(curFamilySymbol, ref m_ParkingStallFamilyList);
							}
						}
					}
				}
				if (m_ADAParkingStallFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Accessible Parking.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadADAParkingFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId2 in _Family.GetFamilySymbolIds())
						{
							if (m_Document.GetElement(familySymbolId2) is FamilySymbol curFamilySymbol2)
							{
								PopulateFamilySymbolInList(curFamilySymbol2, ref m_ADAParkingStallFamilyList);
							}
						}
					}
				}
				if (m_ParkingBumperFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Parking Concrete Bumper.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingBumperFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId3 in _Family.GetFamilySymbolIds())
						{
							if (m_Document.GetElement(familySymbolId3) is FamilySymbol curFamilySymbol3)
							{
								PopulateFamilySymbolInList(curFamilySymbol3, ref m_ParkingBumperFamilyList);
							}
						}
					}
				}
				if (m_ParkingIslandFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Center Parking Island.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingIslandFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId4 in _Family.GetFamilySymbolIds())
						{
							if (m_Document.GetElement(familySymbolId4) is FamilySymbol curFamilySymbol4)
							{
								PopulateFamilySymbolInList(curFamilySymbol4, ref m_ParkingIslandFamilyList);
							}
						}
					}
				}
				if (!flag && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						using IEnumerator<ElementId> enumerator7 = _Family.GetFamilySymbolIds().GetEnumerator();
						if (enumerator7.MoveNext())
						{
							ElementId current7 = enumerator7.Current;
							if (m_Document.GetElement(current7) is FamilySymbol placementSymbol)
							{
								m_PlacementSymbol = placementSymbol;
							}
						}
					}
				}
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		if (_bAllSymbols || _ParkingType == LandcaddID.ParkingStall)
		{
			for (num = 0; num < m_ParkingStallFamilyList.Count; num++)
			{
				m_ParkingStallFamilyList[num].FamilySymbolList.Sort(comparer);
			}
		}
		if (_bAllSymbols || _ParkingType == LandcaddID.ADAParkingStall)
		{
			for (num = 0; num < m_ADAParkingStallFamilyList.Count; num++)
			{
				m_ADAParkingStallFamilyList[num].FamilySymbolList.Sort(comparer);
			}
		}
		if (_bAllSymbols || _ParkingType == LandcaddID.ParkingBumper)
		{
			for (num = 0; num < m_ParkingBumperFamilyList.Count; num++)
			{
				m_ParkingBumperFamilyList[num].FamilySymbolList.Sort(comparer);
			}
		}
		if (_bAllSymbols || _ParkingType == LandcaddID.ParkingIsland)
		{
			for (num = 0; num < m_ParkingIslandFamilyList.Count; num++)
			{
				m_ParkingIslandFamilyList[num].FamilySymbolList.Sort(comparer);
			}
		}
	}

	private void InitializeListData()
	{
		PopulateFamilyAndSymbolLists();
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(Autodesk.Revit.DB.View)).ToElements();
		foreach (Autodesk.Revit.DB.View item in list)
		{
			if (item.GenLevel == null || m_ViewList.Contains(item) || (item.ViewType != ViewType.FloorPlan && item.ViewType != ViewType.EngineeringPlan && item.ViewType != ViewType.AreaPlan) || string.Compare(item.Name, EPShared.LocalRM.GetString("SiteString"), ignoreCase: true) == 0)
			{
				continue;
			}
			bool flag = false;
			for (int i = 0; i < m_ViewList.Count; i++)
			{
				if (string.Compare(m_ViewList[i].GenLevel.UniqueId, item.GenLevel.UniqueId, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				m_ViewList.Add(item);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list2 = filteredElementCollector.OfClass(typeof(TopographySurface)).OfCategory(BuiltInCategory.OST_Topography).ToElements();
		foreach (Element item2 in list2)
		{
			TopographySurface topographySurface = item2 as TopographySurface;
			m_SurfaceList.Add(new TopographySurfaceContainer(m_Document.Application, topographySurface));
		}
	}

	private void PopulateFamilySymbolInList(FamilySymbol _CurFamilySymbol, ref List<FamilyContainer> _FamilyList)
	{
		bool flag = false;
		for (int i = 0; i < _FamilyList.Count; i++)
		{
			if (string.Compare(_FamilyList[i].FamilyName, _CurFamilySymbol.Family.Name, ignoreCase: true) == 0)
			{
				_FamilyList[i].FamilySymbolList.Add(_CurFamilySymbol);
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			FamilyContainer familyContainer = new FamilyContainer(_CurFamilySymbol.Family.Name);
			familyContainer.FamilySymbolList.Add(_CurFamilySymbol);
			_FamilyList.Add(familyContainer);
		}
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		bool flag = false;
		if (m_ParkingStallFamilyList.Count <= 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
		DialogResult _DialogResult = DialogResult.OK;
		using (m_ParkingLotPlacementForm = new ParkingLotPlacementForm(this))
		{
			while (_DialogResult != DialogResult.Cancel)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		m_ParkingLotPlacementForm.ShowDialog();
		_DialogResult = m_ParkingLotPlacementForm.DialogResult;
		if (_DialogResult == DialogResult.Cancel)
		{
			return false;
		}
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("ParkingLotTransaction"));
		List<TopographySurfaceContainer> list = new List<TopographySurfaceContainer>();
		if (m_ParkingLotPlacementForm.PickToposurface)
		{
			list.Add(m_ParkingLotPlacementForm.Surface);
		}
		PopulatePlacementSettingsStructure(list);
		if (!m_ParkingLotPlacementForm.ExistingElementChecked)
		{
			string strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
			ElementSet elementSet = new ElementSet();
			List<ModelCurve> list2 = new List<ModelCurve>();
			Eps_Leg eps_Leg = null;
			Eps_Leg eps_Leg2 = null;
			Eps_Point _Point = null;
			Eps_Point eps_Point = null;
			bool flag = true;
			while (flag)
			{
				flag = RevitUtility.GetPointFromProject(m_Document, strPrompt, ref _Point, _bDisplayError: false);
				if (!flag)
				{
					continue;
				}
				if (eps_Point != null)
				{
					eps_Leg2 = new Eps_Leg();
					eps_Leg2.Line = new Eps_Line();
					eps_Leg2.Line.StartPnt = eps_Point;
					eps_Leg2.Line.EndPnt = _Point;
					if (eps_Leg == null)
					{
						eps_Leg = Eps_Leg.SingleLeg(eps_Leg2);
					}
					else
					{
						eps_Leg.Last.Next = Eps_Leg.SingleLeg(eps_Leg2);
					}
					m_TransactionContainer.BeginTransaction();
					list2.Add(RevitUtility.NewModelCurve(m_Document, eps_Leg2.Line));
					m_TransactionContainer.EndTransaction();
					if (!m_ParkingLotPlacementForm.ParkingChainChecked || m_ParkingLotPlacementForm.ParkingAreaChecked || (m_PlacementSettings.Parking.PlaceIsland && m_ParkingLotPlacementForm.IslandSymbol != null))
					{
						flag = false;
					}
				}
				else
				{
					strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
				}
				eps_Point = _Point;
			}
			for (int i = 0; i < list2.Count; i++)
			{
				elementSet.Insert(list2[i]);
			}
			bool result = true;
			if (eps_Leg != null)
			{
				if (m_ParkingLotPlacementForm.ParkingChainChecked && !m_ParkingLotPlacementForm.ParkingAreaChecked && (!m_PlacementSettings.Parking.PlaceIsland || m_ParkingLotPlacementForm.IslandSymbol == null))
				{
					result = ParkingLotCommon.PlaceLegList(m_Document, m_PlacementSettings, eps_Leg);
				}
				else if (eps_Leg.Line != null)
				{
					result = ParkingLotCommon.PlaceStallsOnLine(m_Document, m_PlacementSettings, null, eps_Leg.Line, null, eps_Leg.Line, _bUseFirstLine: false);
				}
			}
			m_TransactionContainer.BeginTransaction();
			m_Document.Delete(ElementSetConverter.ToIDList(elementSet));
			m_TransactionContainer.EndTransaction();
			return result;
		}
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			LocationCurve locationCurve = item.Location as LocationCurve;
			Curve curve = null;
			if (locationCurve != null)
			{
				curve = locationCurve.Curve;
			}
			if (!(curve != null))
			{
				continue;
			}
			Eps_Leg eps_Leg3 = null;
			if (locationCurve != null && m_ParkingLotPlacementForm.ParkingChainChecked && !m_ParkingLotPlacementForm.ParkingAreaChecked && (!m_PlacementSettings.Parking.PlaceIsland || m_ParkingLotPlacementForm.IslandSymbol == null))
			{
				eps_Leg3 = RevitGeometry.GetLegFromElementList(null, item);
			}
			if (eps_Leg3 != null)
			{
				double dY = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
				if (RevitDefines.GT(m_ParkingLotPlacementForm.StartingDistance, dY))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				ParkingLotCommon.PlaceLegList(m_Document, m_PlacementSettings, eps_Leg3);
				continue;
			}
			if (curve is Arc)
			{
				if (RevitDefines.GT(m_ParkingLotPlacementForm.StartingDistance, curve.Length))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				if (m_ParkingLotPlacementForm.ParkingAreaChecked)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("NoParkingSpacesOnArc"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				if (m_PlacementSettings.Parking.PlaceIsland && m_ParkingLotPlacementForm.IslandSymbol != null)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("NoIslandOnArcMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				bool _bPickFirstArc = true;
				Arc arc = (Arc)curve;
				Eps_Arc eps_Arc = new Eps_Arc(arc);
				Eps_Arc _FirstArc = null;
				Eps_Arc _SecondArc = null;
				if (!RevitUtility.BreakApartArc(m_Document, m_TransactionContainer, m_PlacementSettings.Width / 2.0, eps_Arc, m_PlacementSettings.Parking.PromptForDirection, ref _FirstArc, ref _SecondArc, ref _bPickFirstArc))
				{
					return false;
				}
				m_PlacementSettings.IsReverse = _bPickFirstArc;
				if (_FirstArc != null && _SecondArc != null)
				{
					m_PlacementSettings.Parking.MiddleStallPlacement = true;
				}
				if (!ParkingLotCommon.PlaceStallsOnArc(m_Document, m_PlacementSettings, item, eps_Arc, _FirstArc, _SecondArc, _bPickFirstArc))
				{
					return false;
				}
			}
			else
			{
				if (!(curve is Line))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ParkingNotObjectSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				if (RevitDefines.GT(m_ParkingLotPlacementForm.StartingDistance, curve.Length))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				bool _bPickFirstLine = true;
				Eps_Line _FirstLine = null;
				Eps_Line _SecondLine = null;
				Eps_Line _EvalLine = new Eps_Line();
				_EvalLine.StartPnt = new Eps_Point(curve.GetEndPoint(0));
				_EvalLine.EndPnt = new Eps_Point(curve.GetEndPoint(1));
				if (m_ParkingLotPlacementForm.ParkingAreaChecked)
				{
					if (!RevitUtility.EvaluateLine(m_Document, m_TransactionContainer, m_PlacementSettings.Width / 2.0, ref _EvalLine))
					{
						return false;
					}
					m_PlacementSettings.IsReverse = _EvalLine.IsReverse;
					_FirstLine = _EvalLine;
					_SecondLine = _EvalLine;
				}
				else
				{
					if (!RevitUtility.BreakApartLine(m_Document, m_TransactionContainer, m_PlacementSettings.Width / 2.0, _EvalLine, m_PlacementSettings.Parking.PromptForDirection, ref _FirstLine, ref _SecondLine, ref _bPickFirstLine))
					{
						return false;
					}
					m_PlacementSettings.IsReverse = _bPickFirstLine;
					if (_FirstLine != null && _SecondLine != null)
					{
						m_PlacementSettings.Parking.MiddleStallPlacement = true;
					}
				}
				if (!ParkingLotCommon.PlaceStallsOnLine(m_Document, m_PlacementSettings, item, _EvalLine, _FirstLine, _SecondLine, _bPickFirstLine))
				{
					return false;
				}
			}
			if (m_ParkingLotPlacementForm.DeleteExistingChecked)
			{
				m_TransactionContainer.BeginTransaction();
				m_Document.Delete(item.Id);
				m_TransactionContainer.EndTransaction();
			}
		}
		return true;
	}

	private void PopulatePlacementSettingsStructure(List<TopographySurfaceContainer> _SurfaceList)
	{
		m_PlacementSettings = new PlacementSettings();
		m_PlacementSettings.PlacementType = m_ParkingLotPlacementForm.PlacementType;
		m_PlacementSettings.TransactionContainer = m_TransactionContainer;
		m_PlacementSettings.PlacementSymbol = m_PlacementSymbol;
		m_PlacementSettings.Type = m_ParkingLotPlacementForm.ParkingStallSymbol;
		m_PlacementSettings.LocateType = LocateType.ParkingLot;
		m_PlacementSettings.View = m_ParkingLotPlacementForm.View;
		m_PlacementSettings.Level = m_ParkingLotPlacementForm.Level;
		m_PlacementSettings.DeleteExistingChecked = m_ParkingLotPlacementForm.DeleteExistingChecked;
		m_PlacementSettings.ExistingElementChecked = m_ParkingLotPlacementForm.ExistingElementChecked;
		m_PlacementSettings.SurfaceList = _SurfaceList;
		m_PlacementSettings.Parking.ADAStallSymbol = m_ParkingLotPlacementForm.ADAParkingStallSymbol;
		m_PlacementSettings.Parking.BumperSymbol = m_ParkingLotPlacementForm.BumperSymbol;
		m_PlacementSettings.Parking.IslandSymbol = m_ParkingLotPlacementForm.IslandSymbol;
		m_PlacementSettings.RotationAngle = m_ParkingLotPlacementForm.ParkingAngle;
		m_PlacementSettings.Parking.StallLength = m_ParkingLotPlacementForm.ParkingLength;
		m_PlacementSettings.Width = m_ParkingLotPlacementForm.ParkingWidth;
		m_PlacementSettings.Parking.StallCount = m_ParkingLotPlacementForm.ParkingNumberOfSpaces;
		m_PlacementSettings.Parking.OptimizeParking = m_ParkingLotPlacementForm.ParkingOptimizeChecked;
		if (m_ParkingLotPlacementForm.ADAPlaceParkingSpacesChecked)
		{
			m_PlacementSettings.Parking.ADAStallWidth = m_ParkingLotPlacementForm.ADAParkingWidth;
			m_PlacementSettings.Parking.ADAStallCount = m_ParkingLotPlacementForm.ADAParkingNumberOfSpaces;
			m_PlacementSettings.Parking.ADAStallSharedAccessibleAisle = m_ParkingLotPlacementForm.ADASharedAccessibleAisleChecked;
		}
		m_PlacementSettings.Parking.PlaceBumper = m_ParkingLotPlacementForm.BumperPlaceChecked;
		m_PlacementSettings.Parking.BumperWidth = m_ParkingLotPlacementForm.BumperWidth;
		m_PlacementSettings.Parking.BumperSetback = m_ParkingLotPlacementForm.BumperSetback;
		m_PlacementSettings.Parking.BumperOffset = m_ParkingLotPlacementForm.BumperOffset;
		m_PlacementSettings.Parking.BumperHeight = m_ParkingLotPlacementForm.BumperHeight;
		m_PlacementSettings.Parking.AreaAisleWidth = m_ParkingLotPlacementForm.AreaAisleWidth;
		m_PlacementSettings.Parking.AreaBiDirectionalAisles = m_ParkingLotPlacementForm.AreaBiDirectionalAisles;
		m_PlacementSettings.Parking.AreaDistanceBetweenCenterlines = m_ParkingLotPlacementForm.AreaDistanceBetweenCenterlines;
		m_PlacementSettings.Parking.AreaRowSpacingOptions = m_ParkingLotPlacementForm.AreaRowSpacingOptions;
		m_PlacementSettings.Parking.AreaRowCount = m_ParkingLotPlacementForm.AreaParkingNumberOfRows;
		if (m_PlacementSettings.Parking.OptimizeParking && m_PlacementSettings.Parking.ADAStallCount == 0)
		{
			m_PlacementSettings.Parking.PromptForDirection = false;
		}
		else
		{
			m_PlacementSettings.Parking.PromptForDirection = true;
		}
		m_PlacementSettings.Parking.PlaceIsland = m_ParkingLotPlacementForm.IslandPlaceChecked;
		if (m_ParkingLotPlacementForm.IslandPlaceChecked)
		{
			m_PlacementSettings.Parking.IslandWidth = m_ParkingLotPlacementForm.IslandWidth;
			m_PlacementSettings.Parking.IslandHeight = m_ParkingLotPlacementForm.IslandHeight;
		}
		m_PlacementSettings.StartingDistance = m_ParkingLotPlacementForm.StartingDistance;
	}
}
