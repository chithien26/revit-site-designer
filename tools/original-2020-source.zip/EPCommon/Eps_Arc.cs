﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_Arc
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class Eps_Arc : BaseArc
{
  private bool m_bIsReverse;

  public Eps_Arc()
  {
  }

  public Eps_Arc(Arc _Arc)
    : base(_Arc)
  {
  }

  public Eps_Arc(Eps_Arc _Arc)
    : base((BaseArc) _Arc)
  {
  }

  public Eps_Arc(BaseArc _Arc)
    : base(_Arc)
  {
  }

  public Eps_Arc Reverse()
  {
    Eps_Arc epsArc = new Eps_Arc();
    epsArc.StartPnt = this.EndPnt;
    epsArc.EndPnt = this.StartPnt;
    epsArc.RadiusPnt = this.RadiusPnt;
    epsArc.Radius = this.Radius;
    epsArc.Delta = this.Delta;
    epsArc.Direction = this.Direction;
    if (this.Direction == -1)
      epsArc.Direction = 1;
    else
      epsArc.Direction = -1;
    epsArc.IsReverse = !this.m_bIsReverse;
    return epsArc;
  }

  public Arc RevitArc(UIDocument _CurDocument) => this.RevitArc(_CurDocument.Document);

  public Arc RevitArc(Document _CurDocument)
  {
    if (EPShared.eplGeoE_ArePntsDuplicates2D(this.StartPnt, this.EndPnt))
      return Arc.Create(this.RadiusPnt.XYZ, this.Radius, 0.0, 2.0 * Math.PI, new XYZ(1.0, 0.0, 0.0), new XYZ(0.0, 1.0, 0.0));
    double num = this.Radius * this.Delta;
    Eps_Point _StaOffPnt = new Eps_Point();
    EPShared.eplGeoE_FindStaOffPointAlongArc(this, num / 2.0, 0.0, ref _StaOffPnt);
    return Arc.Create(this.StartPnt.XYZ, this.EndPnt.XYZ, _StaOffPnt.XYZ);
  }

  public bool IsReverse
  {
    get => this.m_bIsReverse;
    set => this.m_bIsReverse = value;
  }
}
