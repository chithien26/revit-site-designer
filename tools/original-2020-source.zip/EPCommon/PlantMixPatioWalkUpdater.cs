﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantMixPatioWalkUpdater
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace EPCommon;

public class PlantMixPatioWalkUpdater : IUpdater
{
  private static AddInId m_ApplicationId = new AddInId(new Guid("da9d271e-f7a0-4291-8837-02947862c85e"));
  private static UpdaterId m_UpdaterId = new UpdaterId(PlantMixPatioWalkUpdater.m_ApplicationId, new Guid("456f44ff-00b1-46dc-ad2a-9eb52be3c270"));
  private List<KeyValuePair<string, Element>> m_RegionElementList;
  private int m_nDocumentsOpenCount;

  public PlantMixPatioWalkUpdater()
  {
    this.m_RegionElementList = new List<KeyValuePair<string, Element>>();
  }

  public void Execute(UpdaterData _Data)
  {
    Document document = _Data.GetDocument();
    bool flag = false;
    ElementId elementId = (ElementId) null;
    for (int index = this.m_RegionElementList.Count - 1; index >= 0; --index)
    {
      try
      {
        elementId = this.m_RegionElementList[index].Value.Id;
      }
      catch (InvalidOperationException ex)
      {
        this.m_RegionElementList.RemoveAt(index);
      }
    }
    List<Element> elementList = (List<Element>) null;
    foreach (ElementId addedElementId in (IEnumerable<ElementId>) _Data.GetAddedElementIds())
    {
      if (elementList == null)
      {
        elementList = new List<Element>();
        foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
        {
          if (element != null && string.Compare(element.Name, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0 && !this.m_RegionElementList.Contains(new KeyValuePair<string, Element>(element.UniqueId, element)))
            elementList.Add(element);
        }
        foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(document).WherePasses((ElementFilter) new ElementCategoryFilter((BuiltInCategory) -2002000)).ToElements())
        {
          if (element != null && string.Compare(element.Name, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), true) == 0 && !this.m_RegionElementList.Contains(new KeyValuePair<string, Element>(element.UniqueId, element)))
            elementList.Add(element);
        }
      }
      if (document.GetElement(addedElementId) is FamilyInstance element1 && ((Element) element1).Category != null && ((Element) element1).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        Parameter parameter1 = ((Element) element1.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (parameter1 != null)
        {
          string strA1 = parameter1.AsString();
          int int32 = Convert.ToInt32((object) LandcaddID.PlantMix);
          string strB1 = int32.ToString("000");
          if (string.Compare(strA1, strB1, true) != 0)
          {
            string strA2 = parameter1.AsString();
            int32 = Convert.ToInt32((object) LandcaddID.PatioWalk);
            string strB2 = int32.ToString("000");
            if (string.Compare(strA2, strB2, true) != 0)
              goto label_34;
          }
          Parameter parameter2 = ((Element) element1).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter2 != null)
          {
            for (int index = 0; index < elementList.Count; ++index)
            {
              string uniqueId = elementList[index].UniqueId;
              if (string.Compare(parameter2.AsString(), uniqueId, true) == 0)
              {
                this.m_RegionElementList.Add(new KeyValuePair<string, Element>(elementList[index].UniqueId, elementList[index]));
                break;
              }
            }
          }
        }
        else
          continue;
      }
label_34:
      flag = true;
    }
    if (flag)
      return;
    List<string> stringList1 = (List<string>) null;
    foreach (ElementId deletedElementId in (IEnumerable<ElementId>) _Data.GetDeletedElementIds())
    {
      for (int index = 0; index < this.m_RegionElementList.Count; ++index)
      {
        KeyValuePair<string, Element> regionElement = this.m_RegionElementList[index];
        if (regionElement.Value.Id.IntegerValue == deletedElementId.IntegerValue)
        {
          if (stringList1 == null)
            stringList1 = new List<string>();
          List<string> stringList2 = stringList1;
          regionElement = this.m_RegionElementList[index];
          string key = regionElement.Key;
          stringList2.Add(key);
          this.m_RegionElementList.RemoveAt(index);
          break;
        }
      }
    }
    if (stringList1 == null || stringList1.Count == 0)
      return;
    List<string> stringList3 = new List<string>();
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151).ToElements())
    {
      if (element is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        Parameter parameter3 = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (parameter3 != null)
        {
          string strA3 = parameter3.AsString();
          int int32 = Convert.ToInt32((object) LandcaddID.PlantMix);
          string strB3 = int32.ToString("000");
          if (string.Compare(strA3, strB3, true) != 0)
          {
            string strA4 = parameter3.AsString();
            int32 = Convert.ToInt32((object) LandcaddID.PatioWalk);
            string strB4 = int32.ToString("000");
            if (string.Compare(strA4, strB4, true) != 0)
              continue;
          }
          Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter4 != null)
          {
            for (int index = 0; index < stringList1.Count; ++index)
            {
              string strB5 = stringList1[index];
              if (string.Compare(parameter4.AsString(), strB5, true) == 0)
              {
                document.Delete(((Element) familyInstance).Id);
                break;
              }
            }
          }
        }
      }
    }
  }

  public void AddElements(Document _CurrentDocument)
  {
    ++this.m_nDocumentsOpenCount;
    List<string> stringList = new List<string>();
    FilteredElementCollector source = new FilteredElementCollector(_CurrentDocument);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151);
    if (source.FirstElement() == null)
      return;
    Parameter LandcaddIDParameter = (Parameter) null;
    FindFamilyInstance2 = (FamilyInstance) null;
    List<Element> list;
    try
    {
      list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement =>
      {
        if (CurrentElement is FamilyInstance FindFamilyInstance2 && (LandcaddIDParameter = ((Element) FindFamilyInstance2.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null)
        {
          string strA1 = LandcaddIDParameter.AsString();
          int int32 = Convert.ToInt32((object) LandcaddID.PlantMix);
          string strB1 = int32.ToString("000");
          if (string.Compare(strA1, strB1, true) != 0)
          {
            string strA2 = LandcaddIDParameter.AsString();
            int32 = Convert.ToInt32((object) LandcaddID.PatioWalk);
            string strB2 = int32.ToString("000");
            if (string.Compare(strA2, strB2, true) != 0)
              goto label_4;
          }
          return CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null;
        }
label_4:
        return false;
      })).ToList<Element>();
    }
    catch (InternalException ex)
    {
      return;
    }
    catch (ApplicationException ex)
    {
      return;
    }
    LandcaddIDParameter = (Parameter) null;
    bool flag = false;
    IList<Element> elements1 = new FilteredElementCollector(_CurrentDocument).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements();
    IList<Element> elements2 = new FilteredElementCollector(_CurrentDocument).WherePasses((ElementFilter) new ElementCategoryFilter((BuiltInCategory) -2002000)).ToElements();
    foreach (Element element1 in list)
    {
      if (element1 is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        LandcaddIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (LandcaddIDParameter != null)
        {
          string strA3 = LandcaddIDParameter.AsString();
          int int32 = Convert.ToInt32((object) LandcaddID.PlantMix);
          string strB3 = int32.ToString("000");
          if (string.Compare(strA3, strB3, true) != 0)
          {
            string strA4 = LandcaddIDParameter.AsString();
            int32 = Convert.ToInt32((object) LandcaddID.PatioWalk);
            string strB4 = int32.ToString("000");
            if (string.Compare(strA4, strB4, true) != 0)
              continue;
          }
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter != null)
          {
            for (int index = 0; index < elements1.Count; ++index)
            {
              Element element2 = elements1[index];
              if (element2 != null && string.Compare(element2.Name, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0 && string.Compare(parameter.AsString(), element2.UniqueId, true) == 0)
              {
                this.m_RegionElementList.Add(new KeyValuePair<string, Element>(element2.UniqueId, element2));
                elements1.RemoveAt(index);
                flag = true;
                break;
              }
            }
            if (!flag)
            {
              for (int index = 0; index < elements2.Count; ++index)
              {
                Element element3 = elements2[index];
                if (element3 != null && string.Compare(element3.Name, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), true) == 0 && string.Compare(parameter.AsString(), element3.UniqueId, true) == 0)
                {
                  this.m_RegionElementList.Add(new KeyValuePair<string, Element>(element3.UniqueId, element3));
                  elements2.RemoveAt(index);
                  break;
                }
              }
            }
            else
              flag = false;
          }
        }
      }
    }
  }

  public void RemoveElements(Document _CurrentDocument)
  {
    --this.m_nDocumentsOpenCount;
    ElementId elementId = (ElementId) null;
    for (int index = this.m_RegionElementList.Count - 1; index >= 0; --index)
    {
      try
      {
        KeyValuePair<string, Element> regionElement = this.m_RegionElementList[index];
        elementId = regionElement.Value.Id;
        regionElement = this.m_RegionElementList[index];
        if (RevitUtility.CompareFileNames(regionElement.Value.Document.PathName, _CurrentDocument.PathName) == 0)
        {
          regionElement = this.m_RegionElementList[index];
          if (RevitUtility.CompareFileNames(regionElement.Value.Document.Title, _CurrentDocument.Title) == 0)
            this.m_RegionElementList.RemoveAt(index);
        }
      }
      catch (InvalidOperationException ex)
      {
        this.m_RegionElementList.RemoveAt(index);
      }
    }
  }

  public string GetAdditionalInformation()
  {
    return "This will delete all Plant Mix and Patio/Walk Generic Models that no longer have corresponding Region/Sub-region elements.";
  }

  public ChangePriority GetChangePriority() => (ChangePriority) 15;

  public UpdaterId GetUpdaterId() => PlantMixPatioWalkUpdater.m_UpdaterId;

  public string GetUpdaterName() => "Plant Mix Patio/Walk Updater";

  public int DocumentsOpenCount() => this.m_nDocumentsOpenCount;
}
