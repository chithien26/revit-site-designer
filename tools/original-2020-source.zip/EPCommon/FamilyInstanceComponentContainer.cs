﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyInstanceComponentContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class FamilyInstanceComponentContainer
{
  private Element m_Element;
  private FamilyInstance m_FamilyInstance;

  public FamilyInstanceComponentContainer(Element _Element, FamilyInstance _FamilyInstance)
  {
    this.m_Element = _Element;
    this.m_FamilyInstance = _FamilyInstance;
  }

  public Element Element => this.m_Element;

  public FamilyInstance FamilyInstance
  {
    get => this.m_FamilyInstance;
    set => this.m_FamilyInstance = value;
  }
}
