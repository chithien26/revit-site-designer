﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SharedParametersFilenameForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class SharedParametersFilenameForm : EPForm
{
  private IContainer components;
  private TextBox m_SharedParameterFileTextBox;
  private Button m_SharedParameterFileButton;
  private Label m_SharedParameterFileLabel;
  private TextBox m_SharedParameterWarningTextBox;
  private Button m_CancelButton;
  private Button m_OKButton;

  public SharedParametersFilenameForm()
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("CreateSharedParameterFileDialog");
    this.m_SharedParameterFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_SharedParameterWarningTextBox.Text = EPShared.LocalRM.GetString("SharedParametersDontExistDialog");
    this.m_SharedParameterFileTextBox.Focus();
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateField())
      return;
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private bool ValidateField()
  {
    string text = this.m_SharedParameterFileTextBox.Text;
    if (string.IsNullOrEmpty(text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySharedParameterFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_SharedParameterFileTextBox.Focus();
      return false;
    }
    string str = ".txt";
    if ((text.LastIndexOf("\\") < 0 || !Directory.Exists(text.Substring(0, text.LastIndexOf("\\")))) && (text.LastIndexOf("/") < 0 || !Directory.Exists(text.Substring(0, text.LastIndexOf("/")))))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (text.IndexOf(str) < 0)
      text += str;
    this.m_SharedParameterFileTextBox.Text = text;
    return true;
  }

  private void OnSharedParameterFileButtonClick(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    saveFileDialog.OverwritePrompt = false;
    string empty = string.Empty;
    int length = -1;
    if (this.m_SharedParameterFileTextBox.Text.IndexOf("\\") >= 0)
      length = this.m_SharedParameterFileTextBox.Text.LastIndexOf("\\");
    if (this.m_SharedParameterFileTextBox.Text.LastIndexOf("/") > length)
      length = this.m_SharedParameterFileTextBox.Text.LastIndexOf("/");
    if (Directory.Exists(this.m_SharedParameterFileTextBox.Text.Substring(0, length)))
      saveFileDialog.InitialDirectory = this.m_SharedParameterFileTextBox.Text.Substring(0, length);
    else if (ApplicationUtility.RegistryPaths.GetSupportPath(string.Empty, ref empty) == 0)
      saveFileDialog.InitialDirectory = empty;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_SharedParameterFileTextBox.Text = saveFileDialog.FileName;
    this.m_SharedParameterFileTextBox.Focus();
  }

  public string SharedParameterFileName
  {
    get => this.m_SharedParameterFileTextBox.Text;
    set => this.m_SharedParameterFileTextBox.Text = value;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_SharedParameterFileTextBox = new TextBox();
    this.m_SharedParameterFileButton = new Button();
    this.m_SharedParameterFileLabel = new Label();
    this.m_SharedParameterWarningTextBox = new TextBox();
    this.m_CancelButton = new Button();
    this.m_OKButton = new Button();
    this.SuspendLayout();
    this.m_SharedParameterFileTextBox.Location = new Point(74, 62);
    this.m_SharedParameterFileTextBox.Name = "m_SharedParameterFileTextBox";
    this.m_SharedParameterFileTextBox.Size = new Size(392, 20);
    this.m_SharedParameterFileTextBox.TabIndex = 2;
    this.m_SharedParameterFileButton.Location = new Point(472, 62);
    this.m_SharedParameterFileButton.Name = "m_SharedParameterFileButton";
    this.m_SharedParameterFileButton.Size = new Size(24, 20);
    this.m_SharedParameterFileButton.TabIndex = 3;
    this.m_SharedParameterFileButton.Text = "...";
    this.m_SharedParameterFileButton.UseVisualStyleBackColor = true;
    this.m_SharedParameterFileButton.Click += new EventHandler(this.OnSharedParameterFileButtonClick);
    this.m_SharedParameterFileLabel.AutoSize = true;
    this.m_SharedParameterFileLabel.Location = new Point(10, 65);
    this.m_SharedParameterFileLabel.Name = "m_SharedParameterFileLabel";
    this.m_SharedParameterFileLabel.Size = new Size(23, 13);
    this.m_SharedParameterFileLabel.TabIndex = 1;
    this.m_SharedParameterFileLabel.Text = "File";
    this.m_SharedParameterWarningTextBox.BorderStyle = BorderStyle.None;
    this.m_SharedParameterWarningTextBox.Location = new Point(13, 13);
    this.m_SharedParameterWarningTextBox.Multiline = true;
    this.m_SharedParameterWarningTextBox.Name = "m_SharedParameterWarningTextBox";
    this.m_SharedParameterWarningTextBox.ReadOnly = true;
    this.m_SharedParameterWarningTextBox.Size = new Size(483, 43);
    this.m_SharedParameterWarningTextBox.TabIndex = 0;
    this.m_SharedParameterWarningTextBox.TabStop = false;
    this.m_CancelButton.Location = new Point(421, 88);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 5;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelClick);
    this.m_OKButton.Location = new Point(340, 88);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 4;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(508, 119);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_SharedParameterWarningTextBox);
    this.Controls.Add((Control) this.m_SharedParameterFileTextBox);
    this.Controls.Add((Control) this.m_SharedParameterFileButton);
    this.Controls.Add((Control) this.m_SharedParameterFileLabel);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (SharedParametersFilenameForm);
    this.Text = "Create Shared Parameters File";
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
