﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ProfileContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class ProfileContainer
{
  private List<Eps_Point> m_PointList;
  private double m_Station;

  public ProfileContainer()
  {
    this.m_Station = 0.0;
    this.m_PointList = new List<Eps_Point>();
  }

  public double Station
  {
    get => this.m_Station;
    set => this.m_Station = value;
  }

  public List<Eps_Point> Points
  {
    get => this.m_PointList;
    set => this.m_PointList = value;
  }

  public bool IsEqual(ProfileContainer another)
  {
    if (!RevitDefines.EQ(this.Station, another.Station) || this.Points == null && another.Points != null || this.Points != null && another.Points == null)
      return false;
    if (this.Points == null && another.Points == null)
      return true;
    if (this.Points.Count != another.Points.Count)
      return false;
    for (int index = 0; index < this.Points.Count; ++index)
    {
      if (!this.Points[index].IsEqual(another.Points[index]))
        return false;
    }
    return true;
  }
}
