using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace EPCommon;

public class PlantDWGCreatorForm : EPForm, IMessageFilter
{
	private ImportDWGData m_ImportData;

	private PlantDWGViewer m_Viewer;

	private Sketch3D m_CurrentSketch;

	private const int WM_KEYDOWN = 256;

	private IContainer components;

	private PictureBox m_PreviewPictureBox;

	private GroupBox m_PreviewGroupBox;

	private ComboBox m_DetailLevelComboBox;

	private Label m_DetailLevelLabel;

	private Label m_PreviewLabel;

	private Button m_OKButton;

	private Button m_CloseButton;

	private Label m_ViewDirectionLabel;

	private ComboBox m_ViewDirectionComboBox;

	private Label m_DrawingFileLabel;

	private TextBox m_DrawingFileTextBox;

	private Label m_ImageTypeLabel;

	private ComboBox m_ImageTypeComboBox;

	private Label m_AutomaticallyPlaceLabel;

	private Label m_PlaceLevelLabel;

	private GroupBox m_ScalingGroupBox;

	private ComboBox m_UnitsComboBox;

	private TextBox m_ScaleTextBox;

	private Label m_ScaleFactorLabel;

	private Label m_UnitsLabel;

	private GroupBox m_ColorsGroupBox;

	private RadioButton m_InvertColorRadioButton;

	private RadioButton m_PreserveRadioButton;

	private RadioButton m_BlackWhiteRadioButton;

	private GroupBox m_PositioningGroupBox;

	private RadioButton m_Center2CenterRadioButton;

	private ComboBox m_LevelComboBox;

	private Label m_LayersLabel;

	private ComboBox m_LayersComboBox;

	private RadioButton m_Origin2OriginRadioButton;

	private TextBox m_FilenameTextBox;

	private Button m_FilePickerButton;

	private Label m_FileNameLabel;

	private Button m_DrawingFileBrowserButton;

	private Button m_ApplyButton;

	private Label m_PreviewWarningLabel;

	public string SaveAsFileName => m_FilenameTextBox.Text;

	public PlantDWGCreatorForm(PlantDWGViewer _Viewer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("PlantDWGCreatorDialog");
		m_ImageTypeLabel.Text = EPShared.LocalRM.GetString("AMP_ImageTypeDialog");
		m_PreviewLabel.Text = EPShared.LocalRM.GetString("PreviewDialog");
		m_ColorsGroupBox.Text = EPShared.LocalRM.GetString("LayerLevelColorsDialog");
		m_BlackWhiteRadioButton.Text = EPShared.LocalRM.GetString("AMP_BlackAndWhiteDialog");
		m_PreserveRadioButton.Text = EPShared.LocalRM.GetString("AMP_PreserveColorsDialog");
		m_InvertColorRadioButton.Text = EPShared.LocalRM.GetString("I_AMP_nvertColorsDialog");
		m_LayersLabel.Text = EPShared.LocalRM.GetString("AMP_LayersDialog");
		m_PositioningGroupBox.Text = EPShared.LocalRM.GetString("PositioningDialog");
		m_AutomaticallyPlaceLabel.Text = EPShared.LocalRM.GetString("AutomaticallyPlaceDialog");
		m_Origin2OriginRadioButton.Text = EPShared.LocalRM.GetString("O_AMP_riginToOriginDialog");
		m_Center2CenterRadioButton.Text = EPShared.LocalRM.GetString("Cen_AMP_terToCenterDialog");
		m_PlaceLevelLabel.Text = EPShared.LocalRM.GetString("Plac_AMP_eAtLevelDialog");
		m_ScalingGroupBox.Text = EPShared.LocalRM.GetString("ScalingDialog");
		m_UnitsLabel.Text = EPShared.LocalRM.GetString("Import_AMP_UnitsDialog");
		m_ScaleFactorLabel.Text = EPShared.LocalRM.GetString("AMP_ScaleFactorDialog");
		m_PreviewWarningLabel.Text = EPShared.LocalRM.GetString("NotAllObjectsAppearDialog");
		m_PreviewGroupBox.Text = EPShared.LocalRM.GetString("PreviewDialog");
		m_DetailLevelLabel.Text = EPShared.LocalRM.GetString("AMP_DetailLevelDialog");
		m_ViewDirectionLabel.Text = EPShared.LocalRM.GetString("AMP_ViewDirectionDialog");
		m_FileNameLabel.Text = EPShared.LocalRM.GetString("NewFami_AMP_lySymbolDialog");
		m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
		m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
		EPToolTip.SetToolTip(m_DrawingFileBrowserButton, EPShared.LocalRM.GetString("LoadDrawingToolTip"));
		EPToolTip.SetToolTip(m_FilePickerButton, EPShared.LocalRM.GetString("NewFamilyToolTip"));
		m_ImportData = new ImportDWGData(_Viewer.CurDocument);
		m_Viewer = _Viewer;
		m_CurrentSketch = _Viewer.CurrentSketch3D;
		InitializeControls();
		Application.AddMessageFilter(this);
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("TopViewDirection"));
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("FrontViewDirection"));
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("LeftViewDirection"));
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("RightViewDirection"));
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("BottomViewDirection"));
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("BackViewDirection"));
		m_ViewDirectionComboBox.Items.Add(EPShared.LocalRM.GetString("IsoMetricViewDirection"));
		m_ViewDirectionComboBox.SelectedIndex = 0;
		m_DetailLevelComboBox.Items.Add(EPShared.LocalRM.GetString("UndefinedDetailLevel"));
		m_DetailLevelComboBox.Items.Add(EPShared.LocalRM.GetString("CoarseDetailLevel"));
		m_DetailLevelComboBox.Items.Add(EPShared.LocalRM.GetString("MediumDetailLevel"));
		m_DetailLevelComboBox.Items.Add(EPShared.LocalRM.GetString("FineDetailLevel"));
		m_DetailLevelComboBox.SelectedIndex = 0;
		foreach (string dimensionType in m_ImportData.DimensionTypes)
		{
			m_ImageTypeComboBox.Items.Add(dimensionType);
		}
		m_ImageTypeComboBox.SelectedIndex = 0;
		foreach (string visibleLayersOnly in m_ImportData.VisibleLayersOnlyList)
		{
			m_LayersComboBox.Items.Add(visibleLayersOnly);
		}
		m_LayersComboBox.SelectedIndex = 0;
		foreach (string unit in m_ImportData.Units)
		{
			m_UnitsComboBox.Items.Add(unit);
		}
		m_UnitsComboBox.SelectedIndex = 0;
		foreach (Autodesk.Revit.DB.View view in m_ImportData.Views)
		{
			m_LevelComboBox.Items.Add(view.Name);
		}
		m_LevelComboBox.SelectedIndex = 0;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorFileSourceName", ref _strReturnValue))
		{
			m_DrawingFileTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorImageTypeOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < m_ImageTypeComboBox.Items.Count)
		{
			m_ImageTypeComboBox.SelectedIndex = _nReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorLayerColorOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_BlackWhiteRadioButton.Checked = true;
				break;
			case 1:
				m_PreserveRadioButton.Checked = true;
				break;
			default:
				m_InvertColorRadioButton.Checked = true;
				break;
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorLayersOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < m_LayersComboBox.Items.Count)
		{
			m_LayersComboBox.SelectedIndex = _nReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorPositioningOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_Origin2OriginRadioButton.Checked = true;
			}
			else
			{
				m_Center2CenterRadioButton.Checked = true;
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ImportData.CurDocument.PathName, "PlantDWGCreatorLevelOption", ref _strReturnValue))
		{
			for (int i = 0; i < m_LevelComboBox.Items.Count; i++)
			{
				if (string.Compare((string)m_LevelComboBox.Items[i], _strReturnValue, ignoreCase: true) == 0)
				{
					m_LevelComboBox.SelectedIndex = i;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorUnitsOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < m_UnitsComboBox.Items.Count)
		{
			m_UnitsComboBox.SelectedIndex = _nReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorScaleValue", ref _strReturnValue))
		{
			m_ScaleTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorFileName", ref _strReturnValue))
		{
			m_FilenameTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorViewDirectionOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < m_ViewDirectionComboBox.Items.Count)
		{
			m_ViewDirectionComboBox.SelectedIndex = _nReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorDetailLevelOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < m_DetailLevelComboBox.Items.Count)
		{
			m_DetailLevelComboBox.SelectedIndex = _nReturnValue;
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		string empty = string.Empty;
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorFileSourceName", m_DrawingFileTextBox.Text);
		num = ((!m_BlackWhiteRadioButton.Checked) ? (m_PreserveRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorLayerColorOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorImageTypeOption", m_ImageTypeComboBox.SelectedIndex);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorLayersOption", m_LayersComboBox.SelectedIndex);
		num = ((!m_Origin2OriginRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorPositioningOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_ImportData.CurDocument.PathName, "PlantDWGCreatorLevelOption", (string)m_LevelComboBox.SelectedItem);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorUnitsOption", m_UnitsComboBox.SelectedIndex);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorScaleValue", m_ScaleTextBox.Text);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorFileName", m_FilenameTextBox.Text);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorViewDirectionOption", m_ViewDirectionComboBox.SelectedIndex);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorDetailLevelOption", m_DetailLevelComboBox.SelectedIndex);
	}

	public bool PreFilterMessage(ref Message _Message)
	{
		if (m_CurrentSketch != null && m_CurrentSketch.Data3D != null && _Message.Msg == 256)
		{
			if (Cursor.Current != Cursors.Cross)
			{
				return false;
			}
			Keys keyData = (Keys)(int)_Message.WParam;
			KeyEventArgs e = new KeyEventArgs(keyData);
			switch (e.KeyCode)
			{
			case Keys.Left:
				m_CurrentSketch.Data3D.RotateY(_bDirection: true);
				break;
			case Keys.Right:
				m_CurrentSketch.Data3D.RotateY(_bDirection: false);
				break;
			case Keys.Up:
				m_CurrentSketch.Data3D.RotateX(_bDirection: true);
				break;
			case Keys.Down:
				m_CurrentSketch.Data3D.RotateX(_bDirection: false);
				break;
			case Keys.Prior:
				m_CurrentSketch.Data3D.RotateZ(_bDirection: true);
				break;
			case Keys.Next:
				m_CurrentSketch.Data3D.RotateZ(_bDirection: false);
				break;
			case Keys.S:
				m_CurrentSketch.MoveY(up: true);
				break;
			case Keys.W:
				m_CurrentSketch.MoveY(up: false);
				break;
			case Keys.A:
				m_CurrentSketch.MoveX(left: true);
				break;
			case Keys.D:
				m_CurrentSketch.MoveX(left: false);
				break;
			case Keys.Home:
				m_CurrentSketch.Zoom(zoomIn: true);
				break;
			case Keys.End:
				m_CurrentSketch.Zoom(zoomIn: false);
				break;
			case Keys.Escape:
				Close();
				break;
			default:
				return false;
			}
			return true;
		}
		return false;
	}

	private void OnPlantDWGCreatorFormClosed(object sender, FormClosedEventArgs e)
	{
		Application.RemoveMessageFilter(this);
	}

	private void OnPreviewBoxPaint(object sender, PaintEventArgs e)
	{
		if (m_CurrentSketch != null && m_CurrentSketch.Data3D != null)
		{
			m_CurrentSketch.Draw(e.Graphics);
		}
	}

	private void OnViewDirectionComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_ViewDirectionComboBox.SelectedIndex >= 0 && m_ViewDirectionComboBox.SelectedIndex < m_ViewDirectionComboBox.Items.Count && m_CurrentSketch != null && m_CurrentSketch.Data3D != null)
		{
			m_CurrentSketch.Data3D.SetViewDirection((Graphics3DData.ViewDirections)m_ViewDirectionComboBox.SelectedIndex);
		}
	}

	private void OnDetailLevelComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (SiteDesigner.UI.WpfFocus.HasFocus(m_DetailLevelComboBox))
		{
			m_Viewer.DetailLevel = (ViewDetailLevel)m_DetailLevelComboBox.SelectedIndex;
		}
	}

	private bool ValidateFileName()
	{
		string text = m_DrawingFileTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySourceFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_DrawingFileTextBox);
			return false;
		}
		if (!File.Exists(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySourceFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_DrawingFileTextBox);
			return false;
		}
		m_ImportData.ImportFileFullName = text;
		text = m_FilenameTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FilenameTextBox);
			return false;
		}
		FileInfo fileInfo = new FileInfo(text);
		if (string.Compare(fileInfo.Extension, ".rfa", ignoreCase: true) != 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FilenameTextBox);
			return false;
		}
		if (File.Exists(text) && RevitUtility.CompareFileNames(m_ImportData.CurDocument.PathName, text) != 0)
		{
			switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation))
			{
			case DialogResult.Yes:
			{
				Document CurDocument = null;
				if (ManagePlants.IsDocumentOpen(m_ImportData.CurDocument.Application, text, ref CurDocument))
				{
					CurDocument.Close(saveModified: false);
				}
				File.Delete(text);
				break;
			}
			case DialogResult.Cancel:
				return false;
			}
		}
		m_ImportData.SaveAsFileName = text;
		return true;
	}

	private void SetImportColorMode()
	{
		string text;
		if (m_BlackWhiteRadioButton.Checked)
		{
			text = m_BlackWhiteRadioButton.Text;
		}
		else
		{
			text = ((!m_PreserveRadioButton.Checked) ? m_InvertColorRadioButton.Text : m_PreserveRadioButton.Text);
		}
		int index = 0;
		for (int i = 0; i < m_ImportData.ColorModes.Count; i++)
		{
			if (text == m_ImportData.ColorModes[i])
			{
				index = i;
				break;
			}
		}
		m_ImportData.ImportColorMode = m_ImportData.EnumColorModes[index];
	}

	private void SetImportPlacement()
	{
		string text = ((!m_Center2CenterRadioButton.Checked) ? m_Origin2OriginRadioButton.Text : m_Center2CenterRadioButton.Text);
		int index = 0;
		for (int i = 0; i < m_ImportData.Placements.Count; i++)
		{
			if (text == m_ImportData.Placements[i])
			{
				index = i;
				break;
			}
		}
		m_ImportData.ImportPlacement = m_ImportData.EnumPlacements[index];
	}

	private void SetImportViewsRelated()
	{
		string text = m_LevelComboBox.SelectedItem.ToString();
		foreach (Autodesk.Revit.DB.View view in m_ImportData.Views)
		{
			if (text == view.Name)
			{
				m_ImportData.ImportView = view;
				break;
			}
		}
		if (string.Compare(m_ImageTypeComboBox.SelectedItem.ToString(), EPShared.LocalRM.GetString("TwoDDWGSymbolDimensionType"), ignoreCase: true) == 0)
		{
			m_ImportData.ImportThisViewOnly = true;
		}
		else
		{
			m_ImportData.ImportThisViewOnly = false;
		}
	}

	private void SetImportLayers()
	{
		m_ImportData.ImportVisibleLayersOnlyList = m_ImportData.EnumVisibleLayersOnlyList[m_LayersComboBox.SelectedIndex];
	}

	private void SetImportUnitsAndScaling()
	{
		if (m_UnitsComboBox.SelectedIndex == 7)
		{
			m_ImportData.ImportCustomScale = ValueConversion.Parse(m_ScaleTextBox.Text);
		}
		else
		{
			m_ImportData.ImportUnit = m_ImportData.EnumUnits[m_UnitsComboBox.SelectedIndex];
		}
	}

	private bool ImportDWGSymbol()
	{
		bool result = false;
		if (ValidateFileName())
		{
			m_Viewer.TransactionContainer.Start(EPShared.LocalRM.GetString("ObtainDrawingImageTransaction"));
			m_Viewer.DeleteSelected();
			m_Viewer.TransactionContainer.Commit();
			SetImportColorMode();
			SetImportPlacement();
			SetImportViewsRelated();
			SetImportLayers();
			SetImportUnitsAndScaling();
			try
			{
				if (!m_ImportData.Import())
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("CannotImport_String") + Path.GetFileName(m_ImportData.ImportFileFullName) + EPShared.LocalRM.GetString("_InSettingString"), EPShared.LocalRM.GetString("ImportString"), MessageBoxIcon.Exclamation);
				}
				else
				{
					result = true;
				}
			}
			catch (Exception ex)
			{
				RevitMessageBox.Show(ex.ToString(), EPShared.LocalRM.GetString("ImportFailedString"), MessageBoxIcon.Hand);
			}
		}
		return result;
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		if (ImportDWGSymbol())
		{
			SaveSettings();
			DialogResult = m_ImportData.CompleteTransaction();
			Close();
		}
	}

	private void OnCloseButtonClick(object sender, EventArgs e)
	{
		m_Viewer.TransactionContainer.Start(EPShared.LocalRM.GetString("ObtainDrawingImageTransaction"));
		m_Viewer.DeleteSelected();
		m_Viewer.TransactionContainer.Commit();
		DialogResult = m_ImportData.CompleteTransaction();
		Close();
	}

	private void LoadFileSourceInformation()
	{
		if (!(m_DrawingFileTextBox.Text != string.Empty))
		{
			return;
		}
		if (m_Viewer.SetupPreview(m_DrawingFileTextBox.Text))
		{
			m_DetailLevelComboBox.SelectedIndex = (int)m_Viewer.DetailLevel;
			m_CurrentSketch = m_Viewer.CurrentSketch3D;
			m_CurrentSketch.DisplayBBox = new RectangleF(new PointF(0f, 0f), m_PreviewPictureBox.Size);
			m_CurrentSketch.UpdateViewEvent += () =>
			{
				m_PreviewPictureBox.Invalidate();
			};
			m_ViewDirectionComboBox.SelectedIndex = -1;
			ResetViewDirection();
		}
		else
		{
			m_CurrentSketch = m_Viewer.CurrentSketch3D;
			m_PreviewPictureBox.Invalidate();
		}
	}

	private void OnFileSourceLeaveFocus(object sender, EventArgs e)
	{
		LoadFileSourceInformation();
	}

	private void OnFileSourceTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			LoadFileSourceInformation();
		}
	}

	private void OnBrowserButtonClick(object sender, EventArgs e)
	{
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Title = EPShared.LocalRM.GetString("ImportDWGTitle");
		openFileDialog.Filter = ApplicationUtility.GetString("DWGFilePickerFilter");
		openFileDialog.RestoreDirectory = true;
		DialogResult dialogResult = openFileDialog.ShowDialog();
		if (dialogResult != DialogResult.Cancel)
		{
			m_DrawingFileTextBox.Text = openFileDialog.FileName;
			SiteDesigner.UI.WpfFocus.Focus(m_DrawingFileTextBox);
		}
	}

	private void OnComboBoxUnitsSelectedIndexChanged(object sender, EventArgs e)
	{
		bool enabled = m_UnitsComboBox.SelectedIndex == 7;
		m_ScaleTextBox.Enabled = enabled;
	}

	private void OnTextBoxScaleKeyPress(object sender, KeyPressEventArgs e)
	{
		if ((e.KeyChar < '.' || e.KeyChar > '9') && (e.KeyChar != '\b' || e.KeyChar == '/'))
		{
			e.Handled = true;
		}
		else
		{
			e.Handled = false;
		}
	}

	private void OnTextBoxScaleTextChanged(object sender, EventArgs e)
	{
		bool flag = false;
		char c = '0';
		string text = m_ScaleTextBox.Text.Trim();
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < text.Length; i++)
		{
			c = char.Parse(text.Substring(i, 1).ToString());
			if (!flag && c == '.')
			{
				stringBuilder.Append(c);
				flag = true;
			}
			else if (char.IsDigit(c))
			{
				stringBuilder.Append(c);
			}
		}
		m_ScaleTextBox.Text = stringBuilder.ToString();
	}

	private void OnComboBoxImageTypeSelectedIndexChanged(object sender, EventArgs e)
	{
		ResetViewDirection();
	}

	private void ResetViewDirection()
	{
		if (string.Compare(m_ImageTypeComboBox.SelectedItem.ToString(), EPShared.LocalRM.GetString("TwoDDWGSymbolDimensionType"), ignoreCase: true) == 0)
		{
			m_ViewDirectionComboBox.SelectedIndex = 0;
		}
		else
		{
			m_ViewDirectionComboBox.SelectedIndex = 1;
		}
	}

	private void OnFilePickerButton(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_FilenameTextBox.Text = saveFileDialog.FileName;
			SiteDesigner.UI.WpfFocus.Focus(m_FilenameTextBox);
		}
	}

	private void OnApplyButtonClick(object sender, EventArgs e)
	{
		ImportDWGSymbol();
	}

	private void OnPlantDWGCreatorFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void AddExtensionToFilename()
	{
		if (!string.IsNullOrEmpty(m_FilenameTextBox.Text))
		{
			FileInfo fileInfo = new FileInfo(m_FilenameTextBox.Text);
			if (fileInfo.Extension == string.Empty)
			{
				m_FilenameTextBox.Text += ".rfa";
			}
		}
	}

	private void OnFilenameTextBoxLeave(object sender, EventArgs e)
	{
		AddExtensionToFilename();
	}

	private void OnFilenameTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			AddExtensionToFilename();
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_PreviewPictureBox = new System.Windows.Forms.PictureBox();
		this.m_PreviewGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ViewDirectionLabel = new System.Windows.Forms.Label();
		this.m_ViewDirectionComboBox = new System.Windows.Forms.ComboBox();
		this.m_DetailLevelLabel = new System.Windows.Forms.Label();
		this.m_DetailLevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_PreviewLabel = new System.Windows.Forms.Label();
		this.m_OKButton = new System.Windows.Forms.Button();
		this.m_CloseButton = new System.Windows.Forms.Button();
		this.m_DrawingFileLabel = new System.Windows.Forms.Label();
		this.m_DrawingFileTextBox = new System.Windows.Forms.TextBox();
		this.m_ImageTypeLabel = new System.Windows.Forms.Label();
		this.m_ImageTypeComboBox = new System.Windows.Forms.ComboBox();
		this.m_AutomaticallyPlaceLabel = new System.Windows.Forms.Label();
		this.m_PlaceLevelLabel = new System.Windows.Forms.Label();
		this.m_ScalingGroupBox = new System.Windows.Forms.GroupBox();
		this.m_UnitsComboBox = new System.Windows.Forms.ComboBox();
		this.m_ScaleTextBox = new System.Windows.Forms.TextBox();
		this.m_ScaleFactorLabel = new System.Windows.Forms.Label();
		this.m_UnitsLabel = new System.Windows.Forms.Label();
		this.m_ColorsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_InvertColorRadioButton = new System.Windows.Forms.RadioButton();
		this.m_PreserveRadioButton = new System.Windows.Forms.RadioButton();
		this.m_BlackWhiteRadioButton = new System.Windows.Forms.RadioButton();
		this.m_PositioningGroupBox = new System.Windows.Forms.GroupBox();
		this.m_Origin2OriginRadioButton = new System.Windows.Forms.RadioButton();
		this.m_Center2CenterRadioButton = new System.Windows.Forms.RadioButton();
		this.m_LevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_LayersLabel = new System.Windows.Forms.Label();
		this.m_LayersComboBox = new System.Windows.Forms.ComboBox();
		this.m_FilenameTextBox = new System.Windows.Forms.TextBox();
		this.m_FilePickerButton = new System.Windows.Forms.Button();
		this.m_FileNameLabel = new System.Windows.Forms.Label();
		this.m_DrawingFileBrowserButton = new System.Windows.Forms.Button();
		this.m_ApplyButton = new System.Windows.Forms.Button();
		this.m_PreviewWarningLabel = new System.Windows.Forms.Label();
		((System.ComponentModel.ISupportInitialize)this.m_PreviewPictureBox).BeginInit();
		this.m_PreviewGroupBox.SuspendLayout();
		this.m_ScalingGroupBox.SuspendLayout();
		this.m_ColorsGroupBox.SuspendLayout();
		this.m_PositioningGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_PreviewPictureBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_PreviewPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.m_PreviewPictureBox.Cursor = System.Windows.Forms.Cursors.Cross;
		this.m_PreviewPictureBox.Location = new System.Drawing.Point(12, 57);
		this.m_PreviewPictureBox.Name = "m_PreviewPictureBox";
		this.m_PreviewPictureBox.Size = new System.Drawing.Size(460, 377);
		this.m_PreviewPictureBox.TabIndex = 4;
		this.m_PreviewPictureBox.TabStop = false;
		this.m_PreviewPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPreviewBoxPaint);
		this.m_PreviewGroupBox.Controls.Add(this.m_ViewDirectionLabel);
		this.m_PreviewGroupBox.Controls.Add(this.m_ViewDirectionComboBox);
		this.m_PreviewGroupBox.Controls.Add(this.m_DetailLevelLabel);
		this.m_PreviewGroupBox.Controls.Add(this.m_DetailLevelComboBox);
		this.m_PreviewGroupBox.Location = new System.Drawing.Point(12, 463);
		this.m_PreviewGroupBox.Name = "m_PreviewGroupBox";
		this.m_PreviewGroupBox.Size = new System.Drawing.Size(460, 68);
		this.m_PreviewGroupBox.TabIndex = 12;
		this.m_PreviewGroupBox.TabStop = false;
		this.m_PreviewGroupBox.Text = "Preview";
		this.m_ViewDirectionLabel.AutoSize = true;
		this.m_ViewDirectionLabel.Location = new System.Drawing.Point(233, 16);
		this.m_ViewDirectionLabel.Name = "m_ViewDirectionLabel";
		this.m_ViewDirectionLabel.Size = new System.Drawing.Size(78, 13);
		this.m_ViewDirectionLabel.TabIndex = 2;
		this.m_ViewDirectionLabel.Text = "&View Direction:";
		this.m_ViewDirectionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ViewDirectionComboBox.FormattingEnabled = true;
		this.m_ViewDirectionComboBox.Location = new System.Drawing.Point(233, 33);
		this.m_ViewDirectionComboBox.Name = "m_ViewDirectionComboBox";
		this.m_ViewDirectionComboBox.Size = new System.Drawing.Size(221, 21);
		this.m_ViewDirectionComboBox.TabIndex = 3;
		this.m_ViewDirectionComboBox.SelectedIndexChanged += new System.EventHandler(this.OnViewDirectionComboBoxSelectedIndexChanged);
		this.m_DetailLevelLabel.AutoSize = true;
		this.m_DetailLevelLabel.Location = new System.Drawing.Point(6, 16);
		this.m_DetailLevelLabel.Name = "m_DetailLevelLabel";
		this.m_DetailLevelLabel.Size = new System.Drawing.Size(66, 13);
		this.m_DetailLevelLabel.TabIndex = 0;
		this.m_DetailLevelLabel.Text = "&Detail Level:";
		this.m_DetailLevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_DetailLevelComboBox.FormattingEnabled = true;
		this.m_DetailLevelComboBox.Location = new System.Drawing.Point(6, 33);
		this.m_DetailLevelComboBox.Name = "m_DetailLevelComboBox";
		this.m_DetailLevelComboBox.Size = new System.Drawing.Size(221, 21);
		this.m_DetailLevelComboBox.TabIndex = 1;
		this.m_DetailLevelComboBox.SelectedIndexChanged += new System.EventHandler(this.OnDetailLevelComboBoxSelectedIndexChanged);
		this.m_PreviewLabel.AutoSize = true;
		this.m_PreviewLabel.Location = new System.Drawing.Point(13, 40);
		this.m_PreviewLabel.Name = "m_PreviewLabel";
		this.m_PreviewLabel.Size = new System.Drawing.Size(48, 13);
		this.m_PreviewLabel.TabIndex = 5;
		this.m_PreviewLabel.Text = "Preview:";
		this.m_OKButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_OKButton.Location = new System.Drawing.Point(503, 564);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 16;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_CloseButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CloseButton.Location = new System.Drawing.Point(584, 564);
		this.m_CloseButton.Name = "m_CloseButton";
		this.m_CloseButton.Size = new System.Drawing.Size(75, 23);
		this.m_CloseButton.TabIndex = 17;
		this.m_CloseButton.Text = "&Close";
		this.m_CloseButton.UseVisualStyleBackColor = true;
		this.m_CloseButton.Click += new System.EventHandler(this.OnCloseButtonClick);
		this.m_DrawingFileLabel.AutoSize = true;
		this.m_DrawingFileLabel.Location = new System.Drawing.Point(12, 15);
		this.m_DrawingFileLabel.Name = "m_DrawingFileLabel";
		this.m_DrawingFileLabel.Size = new System.Drawing.Size(68, 13);
		this.m_DrawingFileLabel.TabIndex = 0;
		this.m_DrawingFileLabel.Text = "&Drawing File:";
		this.m_DrawingFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DrawingFileTextBox.Location = new System.Drawing.Point(142, 12);
		this.m_DrawingFileTextBox.Name = "m_DrawingFileTextBox";
		this.m_DrawingFileTextBox.Size = new System.Drawing.Size(300, 20);
		this.m_DrawingFileTextBox.TabIndex = 1;
		this.m_DrawingFileTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnFileSourceTextBoxKeyDown);
		this.m_DrawingFileTextBox.Leave += new System.EventHandler(this.OnFileSourceLeaveFocus);
		this.m_ImageTypeLabel.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ImageTypeLabel.AutoSize = true;
		this.m_ImageTypeLabel.Location = new System.Drawing.Point(478, 16);
		this.m_ImageTypeLabel.Name = "m_ImageTypeLabel";
		this.m_ImageTypeLabel.Size = new System.Drawing.Size(66, 13);
		this.m_ImageTypeLabel.TabIndex = 3;
		this.m_ImageTypeLabel.Text = "&Image Type:";
		this.m_ImageTypeComboBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ImageTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ImageTypeComboBox.FormattingEnabled = true;
		this.m_ImageTypeComboBox.Location = new System.Drawing.Point(590, 12);
		this.m_ImageTypeComboBox.Name = "m_ImageTypeComboBox";
		this.m_ImageTypeComboBox.Size = new System.Drawing.Size(150, 21);
		this.m_ImageTypeComboBox.TabIndex = 4;
		this.m_ImageTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.OnComboBoxImageTypeSelectedIndexChanged);
		this.m_AutomaticallyPlaceLabel.AutoSize = true;
		this.m_AutomaticallyPlaceLabel.Location = new System.Drawing.Point(15, 18);
		this.m_AutomaticallyPlaceLabel.Name = "m_AutomaticallyPlaceLabel";
		this.m_AutomaticallyPlaceLabel.Size = new System.Drawing.Size(98, 13);
		this.m_AutomaticallyPlaceLabel.TabIndex = 0;
		this.m_AutomaticallyPlaceLabel.Text = "Automatically place";
		this.m_PlaceLevelLabel.AutoSize = true;
		this.m_PlaceLevelLabel.Location = new System.Drawing.Point(14, 87);
		this.m_PlaceLevelLabel.Name = "m_PlaceLevelLabel";
		this.m_PlaceLevelLabel.Size = new System.Drawing.Size(78, 13);
		this.m_PlaceLevelLabel.TabIndex = 3;
		this.m_PlaceLevelLabel.Text = "Plac&e at Level:";
		this.m_ScalingGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ScalingGroupBox.Controls.Add(this.m_UnitsComboBox);
		this.m_ScalingGroupBox.Controls.Add(this.m_ScaleTextBox);
		this.m_ScalingGroupBox.Controls.Add(this.m_ScaleFactorLabel);
		this.m_ScalingGroupBox.Controls.Add(this.m_UnitsLabel);
		this.m_ScalingGroupBox.Location = new System.Drawing.Point(478, 305);
		this.m_ScalingGroupBox.Name = "m_ScalingGroupBox";
		this.m_ScalingGroupBox.Size = new System.Drawing.Size(262, 74);
		this.m_ScalingGroupBox.TabIndex = 10;
		this.m_ScalingGroupBox.TabStop = false;
		this.m_ScalingGroupBox.Text = "Scaling";
		this.m_UnitsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_UnitsComboBox.FormattingEnabled = true;
		this.m_UnitsComboBox.Location = new System.Drawing.Point(135, 18);
		this.m_UnitsComboBox.Name = "m_UnitsComboBox";
		this.m_UnitsComboBox.Size = new System.Drawing.Size(121, 21);
		this.m_UnitsComboBox.TabIndex = 1;
		this.m_UnitsComboBox.SelectedIndexChanged += new System.EventHandler(this.OnComboBoxUnitsSelectedIndexChanged);
		this.m_ScaleTextBox.Enabled = false;
		this.m_ScaleTextBox.Location = new System.Drawing.Point(134, 45);
		this.m_ScaleTextBox.Name = "m_ScaleTextBox";
		this.m_ScaleTextBox.Size = new System.Drawing.Size(122, 20);
		this.m_ScaleTextBox.TabIndex = 3;
		this.m_ScaleTextBox.Text = "1.000000";
		this.m_ScaleTextBox.TextChanged += new System.EventHandler(this.OnTextBoxScaleTextChanged);
		this.m_ScaleTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnTextBoxScaleKeyPress);
		this.m_ScaleFactorLabel.AutoSize = true;
		this.m_ScaleFactorLabel.Location = new System.Drawing.Point(6, 48);
		this.m_ScaleFactorLabel.Name = "m_ScaleFactorLabel";
		this.m_ScaleFactorLabel.Size = new System.Drawing.Size(70, 13);
		this.m_ScaleFactorLabel.TabIndex = 2;
		this.m_ScaleFactorLabel.Text = "&Scale Factor:";
		this.m_UnitsLabel.AutoSize = true;
		this.m_UnitsLabel.Location = new System.Drawing.Point(7, 22);
		this.m_UnitsLabel.Name = "m_UnitsLabel";
		this.m_UnitsLabel.Size = new System.Drawing.Size(66, 13);
		this.m_UnitsLabel.TabIndex = 0;
		this.m_UnitsLabel.Text = "Import &Units:";
		this.m_ColorsGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ColorsGroupBox.Controls.Add(this.m_InvertColorRadioButton);
		this.m_ColorsGroupBox.Controls.Add(this.m_PreserveRadioButton);
		this.m_ColorsGroupBox.Controls.Add(this.m_BlackWhiteRadioButton);
		this.m_ColorsGroupBox.Location = new System.Drawing.Point(478, 57);
		this.m_ColorsGroupBox.Name = "m_ColorsGroupBox";
		this.m_ColorsGroupBox.Size = new System.Drawing.Size(262, 95);
		this.m_ColorsGroupBox.TabIndex = 6;
		this.m_ColorsGroupBox.TabStop = false;
		this.m_ColorsGroupBox.Text = "Layer/Level Colors";
		this.m_InvertColorRadioButton.AutoSize = true;
		this.m_InvertColorRadioButton.Checked = true;
		this.m_InvertColorRadioButton.Location = new System.Drawing.Point(14, 66);
		this.m_InvertColorRadioButton.Name = "m_InvertColorRadioButton";
		this.m_InvertColorRadioButton.Size = new System.Drawing.Size(84, 17);
		this.m_InvertColorRadioButton.TabIndex = 2;
		this.m_InvertColorRadioButton.TabStop = true;
		this.m_InvertColorRadioButton.Text = "I&nvert Colors";
		this.m_InvertColorRadioButton.UseVisualStyleBackColor = true;
		this.m_PreserveRadioButton.AutoSize = true;
		this.m_PreserveRadioButton.Location = new System.Drawing.Point(14, 43);
		this.m_PreserveRadioButton.Name = "m_PreserveRadioButton";
		this.m_PreserveRadioButton.Size = new System.Drawing.Size(99, 17);
		this.m_PreserveRadioButton.TabIndex = 1;
		this.m_PreserveRadioButton.Text = "&Preserve Colors";
		this.m_PreserveRadioButton.UseVisualStyleBackColor = true;
		this.m_BlackWhiteRadioButton.AutoSize = true;
		this.m_BlackWhiteRadioButton.Location = new System.Drawing.Point(15, 20);
		this.m_BlackWhiteRadioButton.Name = "m_BlackWhiteRadioButton";
		this.m_BlackWhiteRadioButton.Size = new System.Drawing.Size(104, 17);
		this.m_BlackWhiteRadioButton.TabIndex = 0;
		this.m_BlackWhiteRadioButton.Text = "&Black and White";
		this.m_BlackWhiteRadioButton.UseVisualStyleBackColor = true;
		this.m_PositioningGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_PositioningGroupBox.Controls.Add(this.m_Origin2OriginRadioButton);
		this.m_PositioningGroupBox.Controls.Add(this.m_AutomaticallyPlaceLabel);
		this.m_PositioningGroupBox.Controls.Add(this.m_PlaceLevelLabel);
		this.m_PositioningGroupBox.Controls.Add(this.m_Center2CenterRadioButton);
		this.m_PositioningGroupBox.Controls.Add(this.m_LevelComboBox);
		this.m_PositioningGroupBox.Location = new System.Drawing.Point(478, 185);
		this.m_PositioningGroupBox.Name = "m_PositioningGroupBox";
		this.m_PositioningGroupBox.Size = new System.Drawing.Size(262, 114);
		this.m_PositioningGroupBox.TabIndex = 9;
		this.m_PositioningGroupBox.TabStop = false;
		this.m_PositioningGroupBox.Text = "Positioning";
		this.m_Origin2OriginRadioButton.AutoSize = true;
		this.m_Origin2OriginRadioButton.Checked = true;
		this.m_Origin2OriginRadioButton.Location = new System.Drawing.Point(19, 37);
		this.m_Origin2OriginRadioButton.Name = "m_Origin2OriginRadioButton";
		this.m_Origin2OriginRadioButton.Size = new System.Drawing.Size(94, 17);
		this.m_Origin2OriginRadioButton.TabIndex = 1;
		this.m_Origin2OriginRadioButton.TabStop = true;
		this.m_Origin2OriginRadioButton.Text = "O&rigin-to-Origin";
		this.m_Origin2OriginRadioButton.UseVisualStyleBackColor = true;
		this.m_Center2CenterRadioButton.AutoSize = true;
		this.m_Center2CenterRadioButton.Location = new System.Drawing.Point(19, 60);
		this.m_Center2CenterRadioButton.Name = "m_Center2CenterRadioButton";
		this.m_Center2CenterRadioButton.Size = new System.Drawing.Size(102, 17);
		this.m_Center2CenterRadioButton.TabIndex = 2;
		this.m_Center2CenterRadioButton.Text = "Cen&ter-to-Center";
		this.m_Center2CenterRadioButton.UseVisualStyleBackColor = true;
		this.m_LevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LevelComboBox.FormattingEnabled = true;
		this.m_LevelComboBox.Location = new System.Drawing.Point(134, 84);
		this.m_LevelComboBox.Name = "m_LevelComboBox";
		this.m_LevelComboBox.Size = new System.Drawing.Size(122, 21);
		this.m_LevelComboBox.TabIndex = 4;
		this.m_LayersLabel.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_LayersLabel.AutoSize = true;
		this.m_LayersLabel.Location = new System.Drawing.Point(482, 162);
		this.m_LayersLabel.Name = "m_LayersLabel";
		this.m_LayersLabel.Size = new System.Drawing.Size(41, 13);
		this.m_LayersLabel.TabIndex = 7;
		this.m_LayersLabel.Text = "&Layers:";
		this.m_LayersComboBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_LayersComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LayersComboBox.FormattingEnabled = true;
		this.m_LayersComboBox.Location = new System.Drawing.Point(590, 158);
		this.m_LayersComboBox.Name = "m_LayersComboBox";
		this.m_LayersComboBox.Size = new System.Drawing.Size(150, 21);
		this.m_LayersComboBox.TabIndex = 8;
		this.m_FilenameTextBox.Location = new System.Drawing.Point(142, 537);
		this.m_FilenameTextBox.Name = "m_FilenameTextBox";
		this.m_FilenameTextBox.Size = new System.Drawing.Size(300, 20);
		this.m_FilenameTextBox.TabIndex = 14;
		this.m_FilenameTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnFilenameTextBoxKeyDown);
		this.m_FilenameTextBox.Leave += new System.EventHandler(this.OnFilenameTextBoxLeave);
		this.m_FilePickerButton.Location = new System.Drawing.Point(448, 537);
		this.m_FilePickerButton.Name = "m_FilePickerButton";
		this.m_FilePickerButton.Size = new System.Drawing.Size(24, 20);
		this.m_FilePickerButton.TabIndex = 15;
		this.m_FilePickerButton.TabStop = false;
		this.m_FilePickerButton.Text = "...";
		this.m_FilePickerButton.UseVisualStyleBackColor = true;
		this.m_FilePickerButton.Click += new System.EventHandler(this.OnFilePickerButton);
		this.m_FileNameLabel.AutoSize = true;
		this.m_FileNameLabel.Location = new System.Drawing.Point(12, 540);
		this.m_FileNameLabel.Name = "m_FileNameLabel";
		this.m_FileNameLabel.Size = new System.Drawing.Size(101, 13);
		this.m_FileNameLabel.TabIndex = 13;
		this.m_FileNameLabel.Text = "New Fami&ly Symbol:";
		this.m_DrawingFileBrowserButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_DrawingFileBrowserButton.Location = new System.Drawing.Point(448, 12);
		this.m_DrawingFileBrowserButton.Name = "m_DrawingFileBrowserButton";
		this.m_DrawingFileBrowserButton.Size = new System.Drawing.Size(24, 20);
		this.m_DrawingFileBrowserButton.TabIndex = 2;
		this.m_DrawingFileBrowserButton.TabStop = false;
		this.m_DrawingFileBrowserButton.Text = "...";
		this.m_DrawingFileBrowserButton.UseVisualStyleBackColor = true;
		this.m_DrawingFileBrowserButton.Click += new System.EventHandler(this.OnBrowserButtonClick);
		this.m_ApplyButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_ApplyButton.Location = new System.Drawing.Point(665, 564);
		this.m_ApplyButton.Name = "m_ApplyButton";
		this.m_ApplyButton.Size = new System.Drawing.Size(75, 23);
		this.m_ApplyButton.TabIndex = 18;
		this.m_ApplyButton.Text = "&Apply";
		this.m_ApplyButton.UseVisualStyleBackColor = true;
		this.m_ApplyButton.Click += new System.EventHandler(this.OnApplyButtonClick);
		this.m_PreviewWarningLabel.AutoSize = true;
		this.m_PreviewWarningLabel.Location = new System.Drawing.Point(12, 440);
		this.m_PreviewWarningLabel.Name = "m_PreviewWarningLabel";
		this.m_PreviewWarningLabel.Size = new System.Drawing.Size(208, 13);
		this.m_PreviewWarningLabel.TabIndex = 11;
		this.m_PreviewWarningLabel.Text = "Not all objects may appear on the preview.";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.CancelButton = this.m_CloseButton;
		base.ClientSize = new System.Drawing.Size(752, 599);
		base.Controls.Add(this.m_PreviewWarningLabel);
		base.Controls.Add(this.m_ApplyButton);
		base.Controls.Add(this.m_DrawingFileBrowserButton);
		base.Controls.Add(this.m_FilenameTextBox);
		base.Controls.Add(this.m_FilePickerButton);
		base.Controls.Add(this.m_FileNameLabel);
		base.Controls.Add(this.m_ScalingGroupBox);
		base.Controls.Add(this.m_ColorsGroupBox);
		base.Controls.Add(this.m_PositioningGroupBox);
		base.Controls.Add(this.m_LayersLabel);
		base.Controls.Add(this.m_LayersComboBox);
		base.Controls.Add(this.m_ImageTypeLabel);
		base.Controls.Add(this.m_ImageTypeComboBox);
		base.Controls.Add(this.m_DrawingFileLabel);
		base.Controls.Add(this.m_DrawingFileTextBox);
		base.Controls.Add(this.m_CloseButton);
		base.Controls.Add(this.m_OKButton);
		base.Controls.Add(this.m_PreviewLabel);
		base.Controls.Add(this.m_PreviewGroupBox);
		base.Controls.Add(this.m_PreviewPictureBox);
		this.MinimumSize = new System.Drawing.Size(700, 626);
		base.Name = "PlantDWGCreatorForm";
		this.Text = "Plant DWG Creator";
		base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnPlantDWGCreatorFormClosed);
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantDWGCreatorFormClosing);
		((System.ComponentModel.ISupportInitialize)this.m_PreviewPictureBox).EndInit();
		this.m_PreviewGroupBox.ResumeLayout(false);
		this.m_PreviewGroupBox.PerformLayout();
		this.m_ScalingGroupBox.ResumeLayout(false);
		this.m_ScalingGroupBox.PerformLayout();
		this.m_ColorsGroupBox.ResumeLayout(false);
		this.m_ColorsGroupBox.PerformLayout();
		this.m_PositioningGroupBox.ResumeLayout(false);
		this.m_PositioningGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_ApplyButton;
		base.CancelButton = this.m_CloseButton;
	}
}
