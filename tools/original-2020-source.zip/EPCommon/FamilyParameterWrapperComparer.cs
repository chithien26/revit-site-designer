﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyParameterWrapperComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class FamilyParameterWrapperComparer : IComparer<FamilyParameterWrapper>
{
  private bool m_bSortByDefinitionName = true;

  int IComparer<FamilyParameterWrapper>.Compare(
    FamilyParameterWrapper first,
    FamilyParameterWrapper second)
  {
    int num = 0;
    if (this.m_bSortByDefinitionName)
    {
      if (first != null)
        num = first.FamilyParameter == null || first.FamilyParameter.Definition == null ? (second.FamilyParameter == null || second.FamilyParameter.Definition == null ? string.Compare(first.ParameterName, second.ParameterName) : string.Compare(first.ParameterName, second.FamilyParameter.Definition.Name)) : (second == null ? -1 : (second.FamilyParameter == null || second.FamilyParameter.Definition == null ? string.Compare(first.FamilyParameter.Definition.Name, second.ParameterName) : string.Compare(first.FamilyParameter.Definition.Name, second.FamilyParameter.Definition.Name)));
      else if (second != null && (second.FamilyParameter != null && second.FamilyParameter.Definition != null || second.ParameterName != string.Empty))
        num = 1;
    }
    return num;
  }
}
