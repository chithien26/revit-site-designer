﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_Triangle
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class Eps_Triangle
{
  private TopoPoint[] m_Verticies;

  public Eps_Triangle() => this.m_Verticies = new TopoPoint[3];

  public bool IsPointInside(Eps_Point _FindPoint)
  {
    Eps_Line pLine = new Eps_Line();
    bool flag = true;
    for (int index = 0; index < 3; ++index)
    {
      if (index < 2)
      {
        pLine.StartPnt = (Eps_Point) this.m_Verticies[index];
        pLine.EndPnt = (Eps_Point) this.m_Verticies[index + 1];
      }
      else
      {
        pLine.StartPnt = (Eps_Point) this.m_Verticies[index];
        pLine.EndPnt = (Eps_Point) this.m_Verticies[0];
      }
      if (RevitGeometry.GeoE_CalcSignedArea(pLine, _FindPoint) > 0.0)
      {
        flag = false;
        break;
      }
    }
    return flag;
  }

  public TopoPoint[] Verticies
  {
    get => this.m_Verticies;
    set => this.m_Verticies = value;
  }
}
