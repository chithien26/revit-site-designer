﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParameterColumnComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class ParameterColumnComparer : IComparer<ParameterColumn>
{
  private bool m_bSortByOrder = true;

  int IComparer<ParameterColumn>.Compare(ParameterColumn first, ParameterColumn second)
  {
    int num = 0;
    if (this.m_bSortByOrder)
    {
      if (first != null)
        num = second == null ? -1 : first.Order.CompareTo(second.Order);
      else if (second != null)
        num = 1;
    }
    return num;
  }
}
