﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RevitDefaults
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public sealed class RevitDefaults
{
  public const double SIDEWALK_CUT_FILL_SLOPE = 0.01;
  public const double SIDEWALK_WIDTH_ENG = 4.0;
  public const double SIDEWALK_DEPTH_ENG = 0.25;
  public const double SIDEWALK_BASE_ENG = 0.16666666666666666;
  public const double SIDEWALK_SUBBASE_ENG = 0.0;
  public const double CURB_HEIGHT_ENG = 0.5;
  public const double CURB_WIDTH_ENG = 0.41666666666666669;
  public const double CURB_OFFSET_ENG = 0.083333333333333329;
  public const double CURB_BASE_ENG = 0.16666666666666666;
  public const double CURB_SUBBASE_ENG = 1.0;
  public const double GUTTER_SLOPE = 0.03;
  public const double GUTTER_HEIGHT_ENG = 1.0;
  public const double GUTTER_WIDTH_ENG = 2.0;
  public const int STREET_LANES = 2;
  public const double STREET_SLOPE = 0.02;
  public const double STREET_CUT_FILL_SLOPE = 0.333;
  public const double STREET_LANE_WIDTH_ENG = 15.0;
  public const double STREET_BOULEVARD_ENG = 7.5;
  public const double STREET_PAVEMENT_ENG = 0.5;
  public const double STREET_BASE_ENG = 0.66666666666666663;
  public const double STREET_SUBBASE_ENG = 1.0;
  public const double RETAINING_CUT_FILL_SLOPE = 0.01;
  public const double RETAINING_WIDTH_ENG = 0.66666666666666663;
  public const double RETAINING_HEIGHT_ENG = 10.0;
  public const double RETAINING_BASE_ENG = 0.66666666666666663;
  public const double RETAINING_SUBBASE_ENG = 1.0;
  public const double PARKING_DEPTH_ENG = 0.5;
  public const double PARKING_BASE_ENG = 0.66666666666666663;
  public const double PARKING_SUBBASE_ENG = 1.0;
  public const double SOFTTERRAIN_CUT_FILL_SLOPE = 1.0;
  public const double SOFTTERRAIN_WIDTH_ENG = 4.0;
}
