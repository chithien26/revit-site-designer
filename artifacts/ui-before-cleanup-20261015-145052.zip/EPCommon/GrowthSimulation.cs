using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;

namespace EPCommon;

public class GrowthSimulation
{
	private Autodesk.Revit.ApplicationServices.Application m_CurApplication;

	private Document m_Document;

	private GrowthSimulationForm m_DisplayForm;

	private List<FamilySymbolContainer> m_ExistingPlantSymbolList;

	private bool m_bShowUI = true;

	private FormatOptions m_LengthFormatOptions;

	private EPTransactionContainer m_TransactionContainer;

	private List<Element> m_CurrentElementList;

	public Document Document => m_Document;

	public List<FamilySymbolContainer> ExistingPlantSymbolList
	{
		get
		{
			return m_ExistingPlantSymbolList;
		}
		set
		{
			m_ExistingPlantSymbolList = value;
		}
	}

	public EPTransactionContainer TransactionContainer => m_TransactionContainer;

	public GrowthSimulation(Document _CurDocument)
	{
		m_CurApplication = _CurDocument.Application;
		m_ExistingPlantSymbolList = new List<FamilySymbolContainer>();
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_LengthFormatOptions = m_Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		InitializeListData();
	}

	private void InitializeListData()
	{
		PopulateExistingPlantList();
	}

	private void PopulateExistingPlantList()
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		filteredElementCollector = new FilteredElementCollector(m_Document);
		m_CurrentElementList = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements()
			.ToList();
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
		List<Eps_Point> list2 = new List<Eps_Point>();
		bool flag = false;
		foreach (Element item in list)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				flag = true;
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, list2))
				{
					list2.Add(eps_Point);
					UpdateFamilySymbolContainerList(familyInstance.Symbol);
				}
			}
		}
		m_TransactionContainer.Rollback();
		if (m_ExistingPlantSymbolList.Count <= 0)
		{
			if (!flag)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("GrowthSimulationNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("GrowthSimulationNoLandCaddFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			m_bShowUI = false;
		}
	}

	private void UpdateFamilySymbolContainerList(FamilySymbol _SelectedSymbol)
	{
		FamilySymbolContainer familySymbolContainer = null;
		Parameter parameter = null;
		familySymbolContainer = new FamilySymbolContainer();
		for (int i = 0; i < m_ExistingPlantSymbolList.Count; i++)
		{
			if (string.Compare(m_ExistingPlantSymbolList[i].FamilySymbol.Name, _SelectedSymbol.Name, ignoreCase: true) == 0)
			{
				return;
			}
		}
		familySymbolContainer.FamilySymbol = _SelectedSymbol;
		parameter = _SelectedSymbol.LookupParameter(RevitParameters.GrowthServiceLifePlantFamilyParameter);
		if (parameter != null)
		{
			if (string.IsNullOrEmpty(parameter.AsString()))
			{
				familySymbolContainer.ServiceLife = EPShared.LocalRM.GetString("NotAvailableString");
			}
			else
			{
				familySymbolContainer.ServiceLife = parameter.AsString();
			}
		}
		else
		{
			familySymbolContainer.ServiceLife = EPShared.LocalRM.GetString("NotAvailableString");
		}
		bool flag = false;
		bool flag2 = false;
		Eps_Point eps_Point = new Eps_Point();
		double num = 0.0;
		double num2 = 0.0;
		FamilyInstance familyInstance = null;
		List<Eps_Point> list = null;
		LocationPoint locationPoint = null;
		Eps_Point eps_Point2 = null;
		list = null;
		foreach (Element currentElement in m_CurrentElementList)
		{
			if (currentElement is FamilyInstance { Symbol: not null } familyInstance2 && familyInstance2.Symbol.Category != null && familyInstance2.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(_SelectedSymbol.UniqueId, familyInstance2.Symbol.UniqueId, ignoreCase: true) == 0)
			{
				if (list == null)
				{
					list = new List<Eps_Point>();
				}
				locationPoint = familyInstance2.Location as LocationPoint;
				eps_Point2 = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point2, list))
				{
					list.Add(eps_Point2);
				}
			}
		}
		if (list != null && list.Count > 0)
		{
			bool flag3 = true;
			while (flag3)
			{
				flag3 = false;
				for (int j = 0; j < list.Count; j++)
				{
					if (EPShared.eplGeoE_ArePntsDuplicates3D(list[j], eps_Point))
					{
						eps_Point.z++;
						flag3 = true;
						break;
					}
				}
			}
		}
		FamilyInstance familyInstance3 = RevitUtility.NewFamilyInstance(m_Document, eps_Point.XYZ, _SelectedSymbol, null, m_Document.ActiveView.GenLevel, StructuralType.NonStructural, ref m_TransactionContainer);
		if (familyInstance3 != null)
		{
			parameter = familyInstance3.LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
			if (parameter != null)
			{
				num = parameter.AsDouble();
				familySymbolContainer.MaxHeight = ValueConversion.ToString(num);
				flag = true;
			}
			else
			{
				familySymbolContainer.MaxHeight = EPShared.LocalRM.GetString("NotAvailableString");
			}
			parameter = familyInstance3.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
			if (parameter != null)
			{
				num2 = parameter.AsDouble();
				familySymbolContainer.MaxWidth = ValueConversion.ToString(num2);
				flag2 = true;
			}
			else
			{
				familySymbolContainer.MaxWidth = EPShared.LocalRM.GetString("NotAvailableString");
			}
		}
		else
		{
			parameter = ((Element)_SelectedSymbol).get_Parameter(BuiltInParameter.RENDER_PLANT_HEIGHT);
			if (parameter != null)
			{
				num = parameter.AsDouble();
				familySymbolContainer.MaxHeight = ValueConversion.ToString(num);
			}
			else
			{
				familySymbolContainer.MaxHeight = EPShared.LocalRM.GetString("NotAvailableString");
			}
		}
		if (flag || flag2)
		{
			m_ExistingPlantSymbolList.Add(familySymbolContainer);
		}
		m_TransactionContainer.BeginTransaction();
		m_Document.Delete(familyInstance3.Id);
		m_TransactionContainer.EndTransaction();
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		if (!m_bShowUI)
		{
			return m_bShowUI;
		}
		bool flag = false;
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new GrowthSimulationForm(this))
		{
			while (_DialogResult != DialogResult.Cancel)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool GetFindSymbol()
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString(EPShared.LocalRM.GetString("PickPlantMessage")), ref _Elements, _bDisplayError: true) || _Elements == null)
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			if (!(item is FamilyInstance { Symbol: not null } familyInstance) || familyInstance.Symbol.Category == null || familyInstance.Symbol.Category.Id.Value64() != BuiltInCategory.OST_Planting.GetHashCode())
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		return true;
	}

	private bool GetSinglePoint(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, _bDisplayError: true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
				else
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				}
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportedForPlantsMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		return true;
	}

	private bool GetWindowPoints(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, _bDisplayError: true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
			}
		}
		return true;
	}

	private bool GetAllPointsWithType(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		if (list == null || list.Count == 0)
		{
			return false;
		}
		foreach (Element item in list)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
			}
		}
		return true;
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		bool flag = false;
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult == DialogResult.Cancel)
		{
			return false;
		}
		if (_DialogResult == DialogResult.Retry)
		{
			return GetFindSymbol();
		}
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GrowthSimulationTransaction"));
		if (m_DisplayForm.FamilySymbolLocalList.Count <= 0)
		{
			return false;
		}
		ElementSet _InstanceSet = new ElementSet();
		List<Eps_Point> _PointList = new List<Eps_Point>();
		if (m_DisplayForm.SelectionSetChecked)
		{
			if (!GetSinglePoint(ref _InstanceSet, ref _PointList))
			{
				return false;
			}
		}
		else if (m_DisplayForm.WindowSelectChecked)
		{
			if (!GetWindowPoints(ref _InstanceSet, ref _PointList))
			{
				return false;
			}
		}
		else if (m_DisplayForm.AllInstancesChecked && !GetAllPointsWithType(ref _InstanceSet, ref _PointList))
		{
			return false;
		}
		return UpdateDocument(_InstanceSet);
	}

	private bool UpdateDocument(ElementSet _InstanceSet)
	{
		List<FamilySymbolContainer> list = new List<FamilySymbolContainer>();
		list = m_DisplayForm.FamilySymbolLocalList;
		if (list.Count <= 0)
		{
			return false;
		}
		ProgressBarForm progressBarForm = new ProgressBarForm();
		progressBarForm.MinValue = 0;
		progressBarForm.MaxValue = _InstanceSet.Size;
		if (_InstanceSet.Size <= 0)
		{
			progressBarForm.MaxValue = 10000;
		}
		progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarGrowingPlantsMessage");
		progressBarForm.ShowForm();
		progressBarForm.Refresh();
		m_TransactionContainer.BeginTransaction();
		foreach (Element item in _InstanceSet)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			Parameter parameter = null;
			double num = -1.0;
			double num2 = 0.0;
			double num3 = 0.0;
			if (familyInstance != null)
			{
				for (int i = 0; i < list.Count; i++)
				{
					bool flag = false;
					if (string.Compare(familyInstance.Symbol.Name, list[i].FamilySymbol.Name, ignoreCase: true) != 0)
					{
						continue;
					}
					parameter = familyInstance.Symbol.LookupParameter(RevitParameters.GrowthServiceLifePlantFamilyParameter);
					if (parameter != null && string.Compare(list[i].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
					{
						parameter.Set(Convert.ToInt32(list[i].ServiceLife));
						num = ValueConversion.ToDouble(list[i].ServiceLife);
						flag = true;
					}
					else if (string.Compare(list[i].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
					{
						num = ValueConversion.ToDouble(list[i].ServiceLife);
						flag = true;
					}
					else
					{
						flag = false;
					}
					if (m_DisplayForm.Age > num || !flag)
					{
						parameter = familyInstance.LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
						if (parameter != null && string.Compare(list[i].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
						{
							num2 = ValueConversion.ToDouble(list[i].MaxHeight);
							parameter.Set(num2);
						}
						parameter = familyInstance.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
						if (parameter != null && string.Compare(list[i].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
						{
							num3 = ValueConversion.ToDouble(list[i].MaxWidth);
							parameter.Set(ValueConversion.ToDouble(list[i].MaxWidth));
						}
						continue;
					}
					parameter = familyInstance.LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
					if (parameter != null && string.Compare(list[i].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
					{
						double num4 = ValueConversion.ToDouble(list[i].MaxHeight) * m_DisplayForm.Age / num;
						num2 = num4;
						parameter.Set(num2);
					}
					parameter = familyInstance.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
					if (parameter != null && string.Compare(list[i].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
					{
						double num5 = ValueConversion.ToDouble(list[i].MaxWidth) * m_DisplayForm.Age / num;
						num3 = num5;
						parameter.Set(num3);
					}
				}
			}
			progressBarForm.UpdateProgressBar(1);
		}
		m_TransactionContainer.EndTransaction();
		progressBarForm.SetMaxValue();
		Thread.Sleep(300);
		progressBarForm.Close();
		return true;
	}
}
