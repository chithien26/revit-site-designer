﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ConvertToToposurface
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ConvertToToposurface
{
  private Application m_CurApplication;
  private Document m_Document;
  private ConvertToToposurfaceForm m_DisplayForm;
  private EPTransactionContainer m_TransactionContainer;
  private Element m_PickedElement;
  private List<Eps_Point> m_TopoPointList;
  private const string m_strNummericSeperator = " - ";
  private ProgressBarForm m_ProgressFrm;
  private bool m_HideOriginalTopoSurface;

  public ConvertToToposurface(Document _CurDocument)
  {
    this.m_CurApplication = _CurDocument.Application;
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_PickedElement = (Element) null;
    this.m_TopoPointList = new List<Eps_Point>();
    this.m_ProgressFrm = (ProgressBarForm) null;
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    DialogResult _DialogResult = DialogResult.Retry;
    using (this.m_DisplayForm = new ConvertToToposurfaceForm(this.m_Document))
    {
      while (_DialogResult == DialogResult.Retry)
        flag = this.ShowDialog(ref _DialogResult);
    }
    return flag;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    bool flag = false;
    _DialogResult = this.m_DisplayForm.ShowDialog();
    if (_DialogResult == DialogResult.OK)
    {
      if (this.m_PickedElement != null)
      {
        this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ConvertObjectToToposurfaceTransaction"));
        this.m_HideOriginalTopoSurface = this.m_DisplayForm.HideOriginalTopoSurface;
        flag = this.VerifyAndCreateToposurface();
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    else if (_DialogResult == DialogResult.Cancel)
      flag = false;
    else if (_DialogResult == DialogResult.Retry)
    {
      ElementSet _InstanceSet = new ElementSet();
      if (!this.PickOject(ref _InstanceSet))
        return false;
      this.m_DisplayForm.EnableConvertButton();
    }
    return flag;
  }

  private bool VerifyAndCreateToposurface()
  {
    bool flag = false;
    string _strSurfaceName = string.Empty;
    if (this.m_DisplayForm.ToposurfaceName == string.Empty)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSurfaceNameString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    Phase selectedPhase = this.m_DisplayForm.SelectedPhase;
    int nBeginningIndex = 0;
    TopographySurface startingNumberName = this.FindTopographySurfaceStartingNumberName(this.m_DisplayForm.ToposurfaceName, selectedPhase, ref nBeginningIndex);
    if (startingNumberName != null)
    {
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), this.m_Document.PathName, nameof (ConvertToToposurface), EPShared.LocalRM.GetString("ToposurfaceSameNameAndPhaseMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("OverwriteToposurfaceOption"),
        EPShared.LocalRM.GetString("CreateNewToposurfaceOption")
      }, 0, true, false);
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult != DialogResult.OK)
        return false;
      if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("OverwriteToposurfaceOption"), true) == 0)
        flag = true;
      else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("CreateNewToposurfaceOption"), true) == 0)
        _strSurfaceName = $"{this.GetNameWithoutSeperator(this.m_DisplayForm.ToposurfaceName)} - {Convert.ToString(nBeginningIndex)}";
    }
    else
      _strSurfaceName = this.m_DisplayForm.ToposurfaceName;
    this.m_ProgressFrm = new ProgressBarForm();
    this.m_ProgressFrm.ShowForm();
    this.m_ProgressFrm.Refresh();
    this.m_ProgressFrm.MinValue = 0;
    this.m_ProgressFrm.MaxValue = Convert.ToInt32(3);
    this.m_ProgressFrm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingNewToposurfaceMessage");
    this.m_TransactionContainer.BeginTransaction();
    TopographySurface toposurface = this.ConvertObjectToToposurface(_strSurfaceName);
    this.m_ProgressFrm.UpdateProgressBar(1);
    if (startingNumberName != null)
    {
      if (toposurface != null)
      {
        TopographySurfaceContainer _ProposedTopographySurfaceContainer = (TopographySurfaceContainer) null;
        TopographySurfaceContainer _BaseTopographySurfaceContainer = (TopographySurfaceContainer) null;
        FamilyInstance _ProposedPlacementFamilyInstance = (FamilyInstance) null;
        FamilyInstance _BasePlacementFamilyInstance = (FamilyInstance) null;
        TopographySurfaceManagement.FindBaseLandcaddTopographySurface(this.m_Document, ref _BaseTopographySurfaceContainer, ref _BasePlacementFamilyInstance, ref _ProposedTopographySurfaceContainer, ref _ProposedPlacementFamilyInstance, this.m_TransactionContainer);
        if (_ProposedTopographySurfaceContainer != null && _ProposedTopographySurfaceContainer.TopographySurface != null && _ProposedPlacementFamilyInstance != null && string.Compare(((Element) _ProposedTopographySurfaceContainer.TopographySurface).UniqueId, ((Element) startingNumberName).UniqueId, true) == 0)
          ((Element) _ProposedPlacementFamilyInstance)[new Guid(RevitParameters.UniqueIDGenericModelFamilyParameter)]?.Set(((Element) toposurface).UniqueId);
        if (_BaseTopographySurfaceContainer != null && _BaseTopographySurfaceContainer.TopographySurface != null && _BasePlacementFamilyInstance != null && string.Compare(((Element) _BaseTopographySurfaceContainer.TopographySurface).UniqueId, ((Element) startingNumberName).UniqueId, true) == 0)
          ((Element) _BasePlacementFamilyInstance)[new Guid(RevitParameters.UniqueIDGenericModelFamilyParameter)]?.Set(((Element) toposurface).UniqueId);
      }
      if (flag)
        this.m_Document.Delete(((Element) startingNumberName).Id);
    }
    this.m_TransactionContainer.EndTransaction();
    this.m_ProgressFrm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressFrm.Close();
    return true;
  }

  private TopographySurface FindTopographySurfaceStartingNumberName(
    string _strFindName,
    Phase SelectedPhase,
    ref int nBeginningIndex)
  {
    TopographySurface startingNumberName = (TopographySurface) null;
    List<Element> list = ((IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340)).ToList<Element>();
    nBeginningIndex = 0;
    bool flag = true;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    string withoutSeperator = this.GetNameWithoutSeperator(_strFindName);
    int num = 1;
    foreach (Element element in list)
    {
      if (element is TopographySurface topographySurface)
      {
        Parameter parameter1 = ((Element) topographySurface)[(BuiltInParameter) -1012100];
        if (parameter1 != null && ElementId.op_Equality(parameter1.AsElementId(), ((Element) SelectedPhase).Id))
        {
          Parameter parameter2 = ((Element) topographySurface)[(BuiltInParameter) -1006900];
          empty3 = string.Empty;
          string strA;
          if (parameter2 != null && parameter2.AsString() != null && parameter2.AsString() != string.Empty)
          {
            strA = parameter2.AsString();
          }
          else
          {
            strA = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
            ++num;
          }
          if (strA != string.Empty && strA.ToUpper().StartsWith(withoutSeperator.ToUpper()))
          {
            int startIndex = strA.LastIndexOf(" - ");
            if (startIndex >= 0 && startIndex < strA.Length)
            {
              string str1 = strA.Substring(startIndex);
              if (str1.StartsWith(" - ") && str1.Length > " - ".Length)
              {
                string str2 = str1.Substring(" - ".Length);
                for (int index = 0; index < str2.Length; ++index)
                {
                  if (!char.IsDigit(str2[index]))
                  {
                    flag = false;
                    break;
                  }
                }
                if (flag)
                {
                  int int32 = Convert.ToInt32(str2);
                  if (int32 > nBeginningIndex)
                    nBeginningIndex = int32;
                }
                else
                  flag = true;
              }
            }
            else if (string.Compare(strA, _strFindName, true) == 0)
              startingNumberName = topographySurface;
          }
        }
      }
    }
    ++nBeginningIndex;
    return startingNumberName;
  }

  private string GetNameWithoutSeperator(string _strValue)
  {
    int num = _strValue.LastIndexOf(" - ");
    if (num >= 0 && num < _strValue.Length)
    {
      string str = _strValue.Substring(num);
      if (str.StartsWith(" - ") && str.Length > " - ".Length)
      {
        bool flag = true;
        foreach (char c in str.Substring(" - ".Length))
        {
          if (!char.IsDigit(c))
          {
            flag = false;
            break;
          }
        }
        if (flag)
          _strValue = _strValue.Substring(0, num);
      }
    }
    return _strValue;
  }

  private TopographySurface ConvertObjectToToposurface(string _strSurfaceName)
  {
    TopographySurface toposurface = (TopographySurface) null;
    if (this.m_PickedElement != null)
    {
      if (this.m_PickedElement is Group pickedElement && pickedElement.GetMemberIds().Count != 0)
      {
        foreach (ElementId memberId in (IEnumerable<ElementId>) pickedElement.GetMemberIds())
          this.GetPointsFromElement(this.m_Document.GetElement(memberId));
      }
      else
        this.GetPointsFromElement(this.m_PickedElement);
      this.m_ProgressFrm.UpdateProgressBar(1);
      if (this.m_TopoPointList.Count > 0)
      {
        List<Eps_Point> epsPointList = new List<Eps_Point>();
        this.m_TopoPointList.Sort((IComparer<Eps_Point>) new Eps_PointComparer());
        List<Eps_Point> list = this.m_TopoPointList.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
        List<XYZ> PointXYZList = new List<XYZ>();
        for (int index = 0; index < list.Count; ++index)
          PointXYZList.Add(list[index].XYZ);
        if (PointXYZList.Count > 0)
        {
          TopographySurfaceManagement.RemoveDuplicateXY(ref PointXYZList);
          toposurface = TopographySurface.Create(this.m_Document, (IList<XYZ>) PointXYZList);
          this.m_Document.Regenerate();
        }
        if (toposurface != null)
        {
          ((Element) toposurface)[(BuiltInParameter) -1006900]?.Set(_strSurfaceName);
          Parameter parameter = ((Element) toposurface)[(BuiltInParameter) -1012100];
          if (parameter != null && this.m_DisplayForm.SelectedPhase != null)
          {
            ElementId id = ((Element) this.m_DisplayForm.SelectedPhase).Id;
            parameter.Set(id);
          }
        }
      }
      if (this.m_HideOriginalTopoSurface)
      {
        ElementSet _ElementSet = new ElementSet();
        _ElementSet.Insert(this.m_PickedElement);
        RevitUtility.HideElementsInAllViews(this.m_Document, _ElementSet);
      }
    }
    return toposurface;
  }

  private bool PickOject(ref ElementSet _InstanceSet)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements) || _Elements == null || _Elements.Size == 0)
      return false;
    foreach (Element element in _Elements)
      this.m_PickedElement = element;
    return true;
  }

  private void GetPointsFromElement(Element _CurrentElement)
  {
    Options options = this.m_CurApplication.Create.NewGeometryOptions();
    options.ComputeReferences = true;
    GeometryElement source = _CurrentElement[options];
    if (!GeometryObject.op_Inequality((GeometryObject) source, (GeometryObject) null) || ((IEnumerable<GeometryObject>) source).Count<GeometryObject>() <= 0)
      return;
    this.AddGeometryObjects(ElementSetConverter.ToGeometryObjectList(source.GetEnumerator()));
  }

  private void AddGeometryObjects(List<GeometryObject> _Objects)
  {
    if (_Objects == null)
      return;
    foreach (GeometryObject _Object in _Objects)
    {
      switch (_Object)
      {
        case Solid _:
          this.AddSolid(_Object);
          continue;
        case Face _:
          this.AddFace(_Object);
          continue;
        case Mesh _:
          this.AddMesh(_Object);
          continue;
        case Edge _:
          this.AddEdge(_Object);
          continue;
        default:
          string str = _Object.GetType().Name;
          if (str.StartsWith("Geometry"))
            str = str.Remove(0, 8);
          switch (str)
          {
            case "Element":
              this.AddGeoElement(_Object);
              continue;
            case "Instance":
              this.AddInstance(_Object);
              continue;
            default:
              continue;
          }
      }
    }
  }

  private void AddInstance(GeometryObject _Object)
  {
    GeometryInstance geometryInstance = _Object as GeometryInstance;
    if (GeometryObject.op_Equality((GeometryObject) geometryInstance, (GeometryObject) null))
      return;
    GeometryElement symbolGeometry = geometryInstance.SymbolGeometry;
    if (GeometryObject.op_Equality((GeometryObject) symbolGeometry, (GeometryObject) null))
      return;
    List<GeometryObject> _Objects = new List<GeometryObject>();
    if (GeometryObject.op_Inequality((GeometryObject) symbolGeometry, (GeometryObject) null))
      _Objects = ElementSetConverter.ToGeometryObjectList(symbolGeometry.GetEnumerator());
    this.AddGeometryObjects(_Objects);
  }

  private void AddGeoElement(GeometryObject _Object)
  {
    GeometryElement geometryElement = _Object as GeometryElement;
    if (GeometryObject.op_Equality((GeometryObject) geometryElement, (GeometryObject) null))
      return;
    this.AddGeometryObjects(ElementSetConverter.ToGeometryObjectList(geometryElement.GetEnumerator()));
  }

  private void AddSolid(GeometryObject _Object)
  {
    Solid solid = _Object as Solid;
    if (GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
      return;
    FaceArray faces = solid.Faces;
    if (faces.Size == 0)
      return;
    foreach (GeometryObject _Object1 in faces)
      this.AddFace(_Object1);
  }

  private void AddFace(GeometryObject _Object)
  {
    Face face = _Object as Face;
    if (GeometryObject.op_Equality((GeometryObject) face, (GeometryObject) null))
      return;
    Mesh _Object1 = face.Triangulate();
    if (GeometryObject.op_Equality((GeometryObject) _Object1, (GeometryObject) null))
      return;
    this.AddMesh((GeometryObject) _Object1);
  }

  private void AddProfile(GeometryObject _Object)
  {
    Profile profile = _Object as Profile;
    if (GeometryObject.op_Equality((GeometryObject) profile, (GeometryObject) null))
      return;
    foreach (GeometryObject curve in profile.Curves)
      this.AddCurve(curve);
  }

  private void AddMesh(GeometryObject _Object)
  {
    Mesh mesh = _Object as Mesh;
    if (GeometryObject.op_Equality((GeometryObject) mesh, (GeometryObject) null))
      return;
    List<Eps_Point> collection = new List<Eps_Point>();
    for (int index1 = 0; index1 < mesh.NumTriangles; ++index1)
    {
      MeshTriangle meshTriangle = mesh[index1];
      try
      {
        for (int index2 = 0; index2 < 3; ++index2)
          collection.Add(new Eps_Point(meshTriangle[index2]));
      }
      catch
      {
      }
    }
    if (collection.Count <= 0)
      return;
    this.m_TopoPointList.AddRange((IEnumerable<Eps_Point>) collection);
  }

  private void AddCurve(GeometryObject _Object)
  {
    Curve curve = _Object as Curve;
    if (GeometryObject.op_Equality((GeometryObject) curve, (GeometryObject) null))
      return;
    List<Eps_Point> collection = new List<Eps_Point>();
    if (curve.IsBound)
    {
      IList<XYZ> xyzList = curve.Tessellate();
      for (int index = 0; index < xyzList.Count; ++index)
        collection.Add(new Eps_Point(xyzList[index]));
    }
    if (collection.Count <= 0)
      return;
    this.m_TopoPointList.AddRange((IEnumerable<Eps_Point>) collection);
  }

  private void AddEdge(GeometryObject _Object)
  {
    Edge edge = _Object as Edge;
    if (GeometryObject.op_Equality((GeometryObject) edge, (GeometryObject) null))
      return;
    List<Eps_Point> collection = new List<Eps_Point>();
    IList<XYZ> xyzList = edge.Tessellate();
    for (int index = 0; index < xyzList.Count; ++index)
      collection.Add(new Eps_Point(xyzList[index]));
    if (collection.Count <= 0)
      return;
    this.m_TopoPointList.AddRange((IEnumerable<Eps_Point>) collection);
  }
}
