using System;
using System.Drawing;
using System.Windows.Forms;

namespace EPCommon;

public class PlantGrowthListView : ListView
{
	private ListViewItem m_ListItem;

	private int m_nX;

	private int m_nY;

	private string m_strSubItemText;

	private int m_nSubItemSelected;

	private TextBox m_EditBox = new TextBox();

	private ComboBox m_CmbBox = new ComboBox();

	private bool m_bKeyBoard;

	private bool m_bHandleListViewItem = true;

	public ComboBox CmbBox
	{
		get
		{
			return m_CmbBox;
		}
		set
		{
			m_CmbBox = value;
		}
	}

	public ListViewItem CurrListItem
	{
		get
		{
			return m_ListItem;
		}
		set
		{
			m_ListItem = value;
		}
	}

	public event ListViewItemChanged OnListViewItemChanged;

	public PlantGrowthListView()
	{
		Dock = DockStyle.None;
		FullRowSelect = true;
		MaximumSize = new Size(430, 94);
		Name = "PlantGrowthListView";
		Size = new Size(430, 94);
		Location = new Point(9, 54);
		TabIndex = 0;
		View = View.Details;
		MouseDown += ListViewMouseDown;
		KeyDown += ListViewKeyDown;
		Click += ListViewSingleClick;
		GridLines = true;
		Scrollable = false;
		OwnerDraw = false;
		m_EditBox.Size = new Size(0, 0);
		m_EditBox.Location = new Point(0, 0);
		Controls.AddRange(new Control[1] { m_EditBox });
		m_EditBox.KeyPress += EditOver;
		m_EditBox.LostFocus += FocusOver;
		m_EditBox.BackColor = Color.White;
		m_EditBox.BorderStyle = BorderStyle.Fixed3D;
		m_EditBox.Hide();
		m_EditBox.Text = "";
		Controls.AddRange(new Control[1] { m_CmbBox });
		m_CmbBox.SelectedIndexChanged += CmbSelected;
		m_CmbBox.LostFocus += CmbFocusOver;
		m_CmbBox.KeyPress += CmbKeyPress;
		m_CmbBox.BackColor = Color.White;
		m_CmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
		m_CmbBox.Hide();
	}

	private void EditOver(object sender, KeyPressEventArgs e)
	{
		if (e.KeyChar == '\r')
		{
			e.Handled = true;
			if (m_bHandleListViewItem)
			{
				m_bHandleListViewItem = false;
				m_ListItem.SubItems[m_nSubItemSelected].Text = m_EditBox.Text;
				if (OnListViewItemChanged != null)
				{
					OnListViewItemChanged(m_ListItem.Index);
				}
				m_EditBox.Hide();
				m_bHandleListViewItem = true;
			}
		}
		else if (e.KeyChar == '\t' && m_bHandleListViewItem)
		{
			m_bHandleListViewItem = false;
			m_ListItem.SubItems[m_nSubItemSelected].Text = m_EditBox.Text;
			if (OnListViewItemChanged != null)
			{
				OnListViewItemChanged(m_ListItem.Index);
			}
			m_EditBox.Hide();
			m_bHandleListViewItem = true;
		}
		if (e.KeyChar == '\u001b')
		{
			m_EditBox.Hide();
		}
	}

	private void FocusOver(object sender, EventArgs e)
	{
		if (m_bHandleListViewItem)
		{
			m_bHandleListViewItem = false;
			m_ListItem.SubItems[m_nSubItemSelected].Text = m_EditBox.Text;
			if (OnListViewItemChanged != null)
			{
				OnListViewItemChanged(m_ListItem.Index);
			}
			m_EditBox.Hide();
			Refresh();
			FocusedItem = SelectedItems[0];
			Focus();
			m_bHandleListViewItem = true;
		}
	}

	public void ListViewSingleClick(object sender, EventArgs e)
	{
		Draw();
	}

	private void Draw()
	{
		int num = 0;
		int num2 = Columns[0].Width;
		if (!m_bKeyBoard)
		{
			int nX = m_nX;
			for (int i = 0; i < Columns.Count; i++)
			{
				if (nX > num && nX < num2)
				{
					m_nSubItemSelected = i;
					break;
				}
				num = num2;
				num2 += Columns[i].Width;
			}
			if (m_nSubItemSelected == 0)
			{
				return;
			}
		}
		else
		{
			num = num2;
			num2 += Columns[1].Width;
			m_nSubItemSelected = 1;
		}
		if (string.Compare(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), m_ListItem.SubItems[0].Text, ignoreCase: true) != 0 && string.Compare(string.Empty, m_ListItem.SubItems[0].Text, ignoreCase: true) != 0)
		{
			m_strSubItemText = m_ListItem.SubItems[m_nSubItemSelected].Text;
			string text = Columns[m_nSubItemSelected].Text;
			string text2 = m_ListItem.SubItems[0].Text;
			Rectangle rectangle = new Rectangle(num, m_ListItem.Bounds.Y, num2, m_ListItem.Bounds.Bottom);
			m_EditBox.Size = new Size(Columns[m_nSubItemSelected].Width, rectangle.Height);
			m_EditBox.Location = new Point(num, m_ListItem.Bounds.Y - 4);
			m_EditBox.Show();
			m_EditBox.Text = m_strSubItemText;
			SiteDesigner.UI.WpfFocus.SelectAll(m_EditBox);
			SiteDesigner.UI.WpfFocus.Focus(m_EditBox);
		}
	}

	public void SetFocus(int _nIndex)
	{
		Refresh();
		Rectangle rectangle = new Rectangle(m_ListItem.SubItems[1].Bounds.X, m_ListItem.SubItems[1].Bounds.Y, Columns[0].Width + Columns[m_nSubItemSelected].Width, m_ListItem.SubItems[1].Bounds.Bottom);
		m_EditBox.Size = new Size(Columns[m_nSubItemSelected].Width, rectangle.Height);
		m_EditBox.Location = new Point(m_ListItem.SubItems[1].Bounds.X, m_ListItem.SubItems[1].Bounds.Y - 4);
		m_EditBox.Text = string.Empty;
		m_EditBox.Show();
		SiteDesigner.UI.WpfFocus.SelectAll(m_EditBox);
		SiteDesigner.UI.WpfFocus.Focus(m_EditBox);
	}

	public void ListViewMouseDown(object sender, MouseEventArgs e)
	{
		m_ListItem = GetItemAt(e.X, e.Y);
		m_nX = e.X;
		m_nY = e.Y;
		m_bKeyBoard = false;
	}

	private void ListViewKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			m_bKeyBoard = true;
			Rectangle itemRect = GetItemRect(SelectedIndices[0]);
			m_nX = itemRect.X + Columns[1].Width;
			m_nY = itemRect.Y;
			m_ListItem = FindItemWithText(SelectedItems[0].Text);
			Draw();
		}
	}

	private void CmbKeyPress(object sender, KeyPressEventArgs e)
	{
		if (e.KeyChar == '\r' || e.KeyChar == '\u001b')
		{
			m_CmbBox.Hide();
		}
	}

	private void CmbSelected(object sender, EventArgs e)
	{
		int selectedIndex = m_CmbBox.SelectedIndex;
		if (selectedIndex >= 0)
		{
			string text = m_CmbBox.Items[selectedIndex].ToString();
			m_ListItem.SubItems[m_nSubItemSelected].Text = text;
			m_CmbBox.Hide();
			if (OnListViewItemChanged != null)
			{
				OnListViewItemChanged(m_ListItem.Index);
			}
		}
	}

	private void CmbFocusOver(object sender, EventArgs e)
	{
		m_CmbBox.Hide();
		Focus();
	}
}
