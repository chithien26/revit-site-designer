using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;

namespace EPCommon;

public class FenceCreation
{
	private Document m_Document;

	private List<Autodesk.Revit.DB.View> m_ViewList;

	private LocateFenceForm m_DisplayForm;

	private List<TopographySurfaceContainer> m_SurfaceList;

	private List<FamilyContainer> m_FamilyList;

	private List<BuiltInCategory> m_CategoryList;

	private EPTransactionContainer m_TransactionContainer;

	private FamilySymbol m_PlacementSymbol;

	public ReadOnlyCollection<Autodesk.Revit.DB.View> Views => new ReadOnlyCollection<Autodesk.Revit.DB.View>(m_ViewList);

	public Document Document => m_Document;

	public ReadOnlyCollection<FamilyContainer> FamilyList => new ReadOnlyCollection<FamilyContainer>(m_FamilyList);

	public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList => new ReadOnlyCollection<TopographySurfaceContainer>(m_SurfaceList);

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public FenceCreation(Document _CurDocument)
	{
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_ViewList = new List<Autodesk.Revit.DB.View>();
		m_SurfaceList = new List<TopographySurfaceContainer>();
		m_FamilyList = new List<FamilyContainer>();
		m_CategoryList = new List<BuiltInCategory>();
		m_CategoryList.Add(BuiltInCategory.OST_GenericModel);
		InitializeListData();
	}

	public void PopulateFamilyAndSymbolLists()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: false);
	}

	private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
	{
		int num = 0;
		m_FamilyList.Clear();
		Parameter CurLanddCadID = null;
		FamilySymbol familySymbol = null;
		FilteredElementCollector filteredElementCollector;
		List<Element> list;
		for (int i = 0; i < m_CategoryList.Count; i++)
		{
			filteredElementCollector = new FilteredElementCollector(m_Document);
			filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(m_CategoryList.ElementAt(i));
			IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.Fence).ToString("000"), ignoreCase: true) == 0);
			list = source.ToList();
			familySymbol = null;
			foreach (Element item in list)
			{
				if (!(item is FamilySymbol { Category: not null } familySymbol2) || m_CategoryList.ElementAt(i) != BuiltInCategory.OST_GenericModel)
				{
					continue;
				}
				CurLanddCadID = familySymbol2.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
				if (CurLanddCadID == null || string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.Fence).ToString("000"), ignoreCase: true) != 0)
				{
					continue;
				}
				bool flag = false;
				for (num = 0; num < m_FamilyList.Count; num++)
				{
					if (string.Compare(m_FamilyList[num].FamilyName, familySymbol2.Family.Name, ignoreCase: true) == 0)
					{
						m_FamilyList[num].FamilySymbolList.Add(familySymbol2);
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					FamilyContainer familyContainer = new FamilyContainer(familySymbol2.Family.Name);
					familyContainer.FamilySymbolList.Add(familySymbol2);
					m_FamilyList.Add(familyContainer);
				}
			}
		}
		bool flag2 = true;
		filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel);
		CurLanddCadID = null;
		IEnumerable<Element> source2 = filteredElementCollector.Where((Element CurrentElement) => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0);
		list = source2.ToList();
		flag2 = false;
		familySymbol = null;
		foreach (Element item2 in list)
		{
			if (item2 is FamilySymbol { Category: not null } familySymbol3)
			{
				CurLanddCadID = familySymbol3.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
				if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0)
				{
					m_PlacementSymbol = familySymbol3;
					flag2 = true;
					break;
				}
			}
		}
		string _strFullFamilyFilename = string.Empty;
		if (_bCheckForFamily && (m_FamilyList.Count == 0 || !flag2))
		{
			List<string> list2 = new List<string>();
			list2.Add(EPShared.LocalRM.GetString("LoadDefaultFamilyOption"));
			list2.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamilyOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, "LocateFence", EPShared.LocalRM.GetString("FenceFamilyNotLoadedMessage"), list2);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamilyOption"), ignoreCase: true) == 0)
			{
				Family _Family = null;
				if (RevitUtility.GetFullFamilyFilenameIfExist("Fence", "Picket Fence.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadFenceFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId in _Family.GetFamilySymbolIds())
						{
							FamilySymbol familySymbol4 = m_Document.GetElement(familySymbolId) as FamilySymbol;
							bool flag3 = false;
							for (num = 0; num < m_FamilyList.Count; num++)
							{
								if (string.Compare(m_FamilyList[num].FamilyName, familySymbol4.Family.Name, ignoreCase: true) == 0)
								{
									m_FamilyList[num].FamilySymbolList.Add(familySymbol4);
									flag3 = true;
									break;
								}
							}
							if (!flag3)
							{
								FamilyContainer familyContainer2 = new FamilyContainer(familySymbol4.Family.Name);
								familyContainer2.FamilySymbolList.Add(familySymbol4);
								m_FamilyList.Add(familyContainer2);
							}
						}
					}
				}
				if (!flag2 && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						using IEnumerator<ElementId> enumerator4 = _Family.GetFamilySymbolIds().GetEnumerator();
						if (enumerator4.MoveNext())
						{
							ElementId current4 = enumerator4.Current;
							m_PlacementSymbol = m_Document.GetElement(current4) as FamilySymbol;
						}
					}
				}
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		for (num = 0; num < m_FamilyList.Count; num++)
		{
			m_FamilyList[num].FamilySymbolList.Sort(comparer);
		}
	}

	private void InitializeListData()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: true);
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(Autodesk.Revit.DB.View)).ToElements();
		foreach (Autodesk.Revit.DB.View item in list)
		{
			if (item.GenLevel == null || m_ViewList.Contains(item) || (item.ViewType != ViewType.FloorPlan && item.ViewType != ViewType.EngineeringPlan && item.ViewType != ViewType.AreaPlan) || string.Compare(item.Name, EPShared.LocalRM.GetString("SiteString"), ignoreCase: true) == 0)
			{
				continue;
			}
			bool flag = false;
			for (int i = 0; i < m_ViewList.Count; i++)
			{
				if (m_ViewList[i].ViewType == item.ViewType && string.Compare(m_ViewList[i].GenLevel.UniqueId, item.GenLevel.UniqueId, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				m_ViewList.Add(item);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list2 = filteredElementCollector.OfClass(typeof(TopographySurface)).OfCategory(BuiltInCategory.OST_Topography).ToElements();
		foreach (Element item2 in list2)
		{
			TopographySurface topographySurface = item2 as TopographySurface;
			m_SurfaceList.Add(new TopographySurfaceContainer(m_Document.Application, topographySurface));
		}
	}

	private FamilyInstance PlaceSingleOnPoint(Eps_Point originPoint, List<TopographySurfaceContainer> _SurfaceList)
	{
		m_TransactionContainer.BeginTransaction();
		FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(m_Document, originPoint.XY, m_DisplayForm.Type, RevitUtility.GetSurfaceContainingPoint(originPoint, _SurfaceList), m_DisplayForm.Level, StructuralType.NonStructural, ref m_TransactionContainer);
		if (Math.Abs(m_DisplayForm.FenceHeight) > 0.0)
		{
			familyInstance.LookupParameter(RevitParameters.FenceFamilyHeightParameter)?.Set(m_DisplayForm.FenceHeight);
		}
		if (Math.Abs(m_DisplayForm.FenceSpan) > 0.0)
		{
			familyInstance.LookupParameter(RevitParameters.FenceFamilySpanParameter)?.Set(m_DisplayForm.FenceSpan);
		}
		Parameter parameter = familyInstance.LookupParameter(RevitParameters.FenceRightVisiability);
		Parameter parameter2 = familyInstance.LookupParameter(RevitParameters.FenceLeftVisiability);
		if (parameter != null && parameter2 != null)
		{
			parameter.Set(Convert.ToInt32(value: true));
			parameter2.Set(Convert.ToInt32(value: true));
		}
		m_TransactionContainer.EndTransaction();
		return familyInstance;
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		bool flag = false;
		if (m_FamilyList.Count <= 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new LocateFenceForm(this))
		{
			while (_DialogResult == DialogResult.OK)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult != DialogResult.OK)
		{
			return false;
		}
		List<TopographySurfaceContainer> list = new List<TopographySurfaceContainer>();
		if (m_DisplayForm.PickToposurface)
		{
			list.Add(m_DisplayForm.Surface);
		}
		PlacementSettings placementSettings = new PlacementSettings(LocateType.Fence, PlacementType.HedgeRowCenter, m_DisplayForm.DeleteExistingChecked, m_DisplayForm.ExistingElementChecked, _bPlaceGroupTagChecked: false, m_DisplayForm.Level, m_DisplayForm.View, m_DisplayForm.Type, list, m_DisplayForm.SetbackSpacing, m_DisplayForm.FenceHeight, 0.0, m_DisplayForm.FenceSpan, 0.0, m_DisplayForm.FenceSpan, 0.0, m_DisplayForm.StartingDistance, m_PlacementSymbol, m_TransactionContainer);
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocateFenceTransaction"));
		ElementSet _Elements = null;
		string empty = string.Empty;
		if (!m_DisplayForm.ExistingElementChecked)
		{
			empty = EPShared.LocalRM.GetString("PickStartPointPrompt");
			ElementSet elementSet = new ElementSet();
			List<ModelCurve> list2 = new List<ModelCurve>();
			Eps_Leg eps_Leg = null;
			Eps_Leg eps_Leg2 = null;
			Eps_Point _Point = null;
			Eps_Point eps_Point = null;
			bool flag = true;
			while (flag)
			{
				flag = RevitUtility.GetPointFromProject(m_Document, empty, ref _Point, _bDisplayError: false);
				if (flag)
				{
					if (eps_Point != null)
					{
						eps_Leg2 = new Eps_Leg();
						eps_Leg2.Line = new Eps_Line();
						eps_Leg2.Line.StartPnt = eps_Point;
						eps_Leg2.Line.EndPnt = _Point;
						if (eps_Leg == null)
						{
							eps_Leg = Eps_Leg.SingleLeg(eps_Leg2);
						}
						else
						{
							eps_Leg.Last.Next = Eps_Leg.SingleLeg(eps_Leg2);
						}
						m_TransactionContainer.BeginTransaction();
						list2.Add(RevitUtility.NewModelCurve(m_Document, eps_Leg2.Line));
						m_TransactionContainer.EndTransaction();
						if (m_DisplayForm.SegmentChecked)
						{
							flag = false;
						}
					}
					else
					{
						empty = EPShared.LocalRM.GetString("PickEndPointPrompt");
					}
					eps_Point = _Point;
				}
				m_Document.Regenerate();
			}
			for (int i = 0; i < list2.Count; i++)
			{
				elementSet.Insert(list2[i]);
			}
			bool result = true;
			if (eps_Leg != null)
			{
				result = FenceCommon.PlaceLegList(m_Document, placementSettings, eps_Leg);
			}
			m_TransactionContainer.BeginTransaction();
			m_Document.Delete(ElementSetConverter.ToIDList(elementSet));
			m_TransactionContainer.EndTransaction();
			return result;
		}
		empty = EPShared.LocalRM.GetString("PickObjectMessage");
		if (!RevitUtility.GetElementsFromProject(m_Document, empty, ref _Elements))
		{
			return false;
		}
		foreach (Element item5 in _Elements)
		{
			LocationCurve locationCurve = item5.Location as LocationCurve;
			Curve curve = null;
			if (locationCurve != null)
			{
				curve = locationCurve.Curve;
			}
			if (curve != null)
			{
				Eps_Leg eps_Leg3 = null;
				if (locationCurve != null && m_DisplayForm.ChainChecked)
				{
					eps_Leg3 = RevitGeometry.GetLegFromElementList(null, item5);
				}
				if (eps_Leg3 != null)
				{
					double dY = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, dY))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					return FenceCommon.PlaceLegList(m_Document, placementSettings, eps_Leg3);
				}
				if (curve is Arc)
				{
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, curve.Length))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					Arc arc = (Arc)curve;
					Eps_Arc _EvalArc = new Eps_Arc(arc);
					if (!RevitUtility.EvaluateArc(m_Document, m_TransactionContainer, m_DisplayForm.FenceSpan, ref _EvalArc))
					{
						return false;
					}
					placementSettings.IsReverse = _EvalArc.IsReverse;
					if (RevitDefines.EQ(m_DisplayForm.SetbackSpacing, 0.0))
					{
						FenceCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _EvalArc);
					}
					else
					{
						Eps_Arc _OffsetArc = new Eps_Arc();
						EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, m_DisplayForm.SetbackSpacing, 1, ref _OffsetArc);
						Eps_Arc _OffsetArc2 = new Eps_Arc();
						EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, m_DisplayForm.SetbackSpacing, 2, ref _OffsetArc2);
						ElementSet elementSet2 = new ElementSet();
						if (_OffsetArc.Radius > 0.0)
						{
							m_TransactionContainer.BeginTransaction();
							ModelCurve item = RevitUtility.NewModelCurve(m_Document, _OffsetArc);
							m_TransactionContainer.EndTransaction();
							elementSet2.Insert(item);
						}
						if (_OffsetArc2.Radius > 0.0)
						{
							m_TransactionContainer.BeginTransaction();
							ModelCurve item2 = RevitUtility.NewModelCurve(m_Document, _OffsetArc2);
							m_TransactionContainer.EndTransaction();
							elementSet2.Insert(item2);
						}
						bool _UseRightSide = true;
						bool flag2 = RevitUtility.PickSideArc(m_Document, _EvalArc, ref _UseRightSide);
						m_TransactionContainer.BeginTransaction();
						m_Document.Delete(ElementSetConverter.ToIDList(elementSet2));
						m_TransactionContainer.EndTransaction();
						if (!flag2)
						{
							return false;
						}
						placementSettings.UseRightSide = _UseRightSide;
						if (_UseRightSide)
						{
							FenceCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _OffsetArc);
						}
						else
						{
							FenceCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _OffsetArc2);
						}
					}
				}
				else if (curve is Line)
				{
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, curve.Length))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					Eps_Line _EvalLine = new Eps_Line();
					_EvalLine.StartPnt = new Eps_Point(curve.GetEndPoint(0));
					_EvalLine.EndPnt = new Eps_Point(curve.GetEndPoint(1));
					if (!RevitUtility.EvaluateLine(m_Document, m_TransactionContainer, m_DisplayForm.FenceSpan, ref _EvalLine))
					{
						return false;
					}
					placementSettings.IsReverse = _EvalLine.IsReverse;
					if (m_DisplayForm.SetbackSpacing == 0.0)
					{
						FenceCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _EvalLine);
					}
					else
					{
						Eps_Line _OffsetLine = new Eps_Line();
						EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, m_DisplayForm.SetbackSpacing, 1, ref _OffsetLine);
						Eps_Line _OffsetLine2 = new Eps_Line();
						EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, m_DisplayForm.SetbackSpacing, 2, ref _OffsetLine2);
						m_TransactionContainer.BeginTransaction();
						ModelCurve item3 = RevitUtility.NewModelCurve(m_Document, _OffsetLine);
						ModelCurve item4 = RevitUtility.NewModelCurve(m_Document, _OffsetLine2);
						m_TransactionContainer.EndTransaction();
						m_Document.Regenerate();
						bool _UseRightSide2 = true;
						bool flag3 = RevitUtility.PickSideLine(m_Document, _EvalLine, ref _UseRightSide2);
						ElementSet elementSet3 = new ElementSet();
						elementSet3.Insert(item3);
						elementSet3.Insert(item4);
						m_TransactionContainer.BeginTransaction();
						m_Document.Delete(ElementSetConverter.ToIDList(elementSet3));
						m_TransactionContainer.EndTransaction();
						if (!flag3)
						{
							return false;
						}
						placementSettings.UseRightSide = _UseRightSide2;
						if (_UseRightSide2)
						{
							FenceCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _OffsetLine);
						}
						else
						{
							FenceCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _OffsetLine2);
						}
					}
				}
				else
				{
					if (!(curve is Ellipse) && !(curve is NurbSpline) && !(curve is HermiteSpline))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					IList<XYZ> list3 = curve.Tessellate();
					int count = list3.Count;
					if (count > 1)
					{
						int num = 0;
						Eps_Point startPnt = new Eps_Point();
						Eps_Point eps_Point2 = new Eps_Point();
						eps_Leg3 = null;
						Eps_Leg eps_Leg4 = null;
						for (num = 0; num < count; num += 2)
						{
							eps_Point2 = new Eps_Point(list3[num]);
							if (num > 0)
							{
								eps_Leg4 = new Eps_Leg();
								eps_Leg4.Line = new Eps_Line();
								eps_Leg4.Line.StartPnt = startPnt;
								eps_Leg4.Line.EndPnt = eps_Point2;
								if (eps_Leg3 == null)
								{
									eps_Leg3 = eps_Leg4;
									eps_Leg3.Element = item5;
								}
								else
								{
									eps_Leg3.Last.Next = eps_Leg4;
									eps_Leg3.Last.Element = item5;
								}
							}
							startPnt = eps_Point2;
						}
						if (num == count)
						{
							eps_Leg4 = new Eps_Leg();
							eps_Leg4.Line = new Eps_Line();
							eps_Leg4.Line.StartPnt = startPnt;
							eps_Leg4.Line.EndPnt = new Eps_Point(list3[count - 1]);
							if (eps_Leg3 == null)
							{
								eps_Leg3 = eps_Leg4;
								eps_Leg3.Element = item5;
							}
							else
							{
								eps_Leg3.Last.Next = eps_Leg4;
								eps_Leg3.Last.Element = item5;
							}
						}
					}
					double dY2 = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, dY2))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					if (!FenceCommon.PlaceLegList(m_Document, placementSettings, eps_Leg3))
					{
						return false;
					}
				}
				if (m_DisplayForm.DeleteExistingChecked)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(item5.Id);
					m_TransactionContainer.EndTransaction();
				}
			}
			else
			{
				if (!(item5.Location is LocationPoint locationPoint))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				PlaceSingleOnPoint(new Eps_Point(locationPoint.Point), placementSettings.SurfaceList);
				if (m_DisplayForm.DeleteExistingChecked)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(item5.Id);
					m_TransactionContainer.EndTransaction();
				}
			}
		}
		return true;
	}
}
