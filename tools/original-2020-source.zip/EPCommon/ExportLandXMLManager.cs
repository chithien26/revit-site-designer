﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ExportLandXMLManager
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;

#nullable disable
namespace EPCommon;

public class ExportLandXMLManager : EPForm
{
  private Document m_CurrentDocument;
  private IContainer components;
  private GroupBox m_ExportInformation;
  private Label m_ProjectName;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;
  private CheckBox m_ExportSurfaceChkBox;
  private CheckBox m_ExportAlignmentChkBox;
  private TextBox m_CompanyTextBox;
  private TextBox m_EmailTextBox;
  private TextBox m_CreatedByTextBox;
  private TextBox m_ProjectTextBox;
  private Label m_CompanyLbl;
  private Label m_EmailLbl;
  private Label m_CreatedByLbl;
  private Button m_FileOpen;
  private TextBox m_FileNameTextBox;
  private Label m_FileName;
  private CheckBox m_BySharedCoordinatesChkBox;

  public ExportLandXMLManager(Document _CurrentDocument)
  {
    this.m_CurrentDocument = _CurrentDocument;
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDexportLandXML";
    this.SetupStrings();
    this.GetDialogPosition();
  }

  private void SetupStrings()
  {
    this.Text = EPShared.LocalRM.GetString("ExportLandXMLString");
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_ExportInformation.Text = EPShared.LocalRM.GetString("UserInformationString");
    this.m_ExportSurfaceChkBox.Text = EPShared.LocalRM.GetString("Export_AMP_TopoSurfacesExportXMLDialog");
    this.m_ExportAlignmentChkBox.Text = EPShared.LocalRM.GetString("Export_AMP_AligmentsExportXMLDialog");
    this.m_ProjectName.Text = EPShared.LocalRM.GetString("AMP_ProjectNameExportXMLDialog");
    this.m_CompanyLbl.Text = EPShared.LocalRM.GetString("AMP_CompanyExportXMLDialog");
    this.m_EmailLbl.Text = EPShared.LocalRM.GetString("Created_AMP_ByExportXMLDialog");
    this.m_CreatedByLbl.Text = EPShared.LocalRM.GetString("CreatedBy_AMP_EmailExportXMLDialog");
    this.m_FileName.Text = EPShared.LocalRM.GetString("AMP_FileNameExportXMLDialog");
    this.m_BySharedCoordinatesChkBox.Text = EPShared.LocalRM.GetString("B_AMP_ySurveyPointsDialog");
    int num = this.m_CurrentDocument.PathName.LastIndexOf("\\");
    string str = string.Empty;
    if (num > 0)
      str = this.m_CurrentDocument.PathName.Substring(num + 1);
    this.m_ProjectTextBox.Text = str;
    this.m_CreatedByTextBox.Text = Environment.UserName;
    string empty1 = string.Empty;
    this.m_EmailTextBox.Text = empty1;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ExportLandXMLEmailText", ref empty1))
      this.m_EmailTextBox.Text = empty1;
    string empty2 = string.Empty;
    this.m_CompanyTextBox.Text = empty2;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ExportLandXMLCompanyText", ref empty2))
      this.m_CompanyTextBox.Text = empty2;
    int _nReturnValue = 0;
    this.m_ExportSurfaceChkBox.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ExportLandXMLSurface", ref _nReturnValue))
      this.m_ExportSurfaceChkBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ExportAlignmentChkBox.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ExportLandXMLAlignment", ref _nReturnValue))
      this.m_ExportAlignmentChkBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_BySharedCoordinatesChkBox.Checked = false;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ExportLandXMLUseSharedCoordinates", ref _nReturnValue))
      return;
    this.m_BySharedCoordinatesChkBox.Checked = Convert.ToBoolean(_nReturnValue);
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("ExportLandXMLEmailText", this.m_EmailTextBox.Text);
    ApplicationUtility.Settings.eplSetE_SetSetting("ExportLandXMLCompanyText", this.m_CompanyTextBox.Text);
    ApplicationUtility.Settings.eplSetE_SetSetting("ExportLandXMLSurface", Convert.ToInt32(this.m_ExportSurfaceChkBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("ExportLandXMLAlignment", Convert.ToInt32(this.m_ExportAlignmentChkBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("ExportLandXMLUseSharedCoordinates", Convert.ToInt32(this.m_BySharedCoordinatesChkBox.Checked));
  }

  private void OnOkButtonClicked(object sender, EventArgs e)
  {
    if (!this.VerifyFileNameAndPath())
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidFileNameLocationMessageString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.SaveSettings();
      if (!this.m_ExportAlignmentChkBox.Checked && !this.m_ExportSurfaceChkBox.Checked)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoExportOptionsSelectedString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        DialogResult dialogResult1 = DialogResult.Cancel;
        DialogResult dialogResult2 = DialogResult.Cancel;
        List<LandXMLAlignment> _AlignmentList = new List<LandXMLAlignment>();
        List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
        if (this.m_ExportSurfaceChkBox.Checked)
        {
          using (ExportLandXMLTypeList exportLandXmlTypeList = new ExportLandXMLTypeList(LandXMLElementType.Surface, this.m_CurrentDocument, ref _SurfaceList))
          {
            if (exportLandXmlTypeList.ElementCount <= 0)
            {
              int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSurfacesInProjectString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
            }
            else
            {
              int num4 = (int) exportLandXmlTypeList.ShowDialog();
              dialogResult1 = exportLandXmlTypeList.DialogResult;
            }
          }
        }
        if (this.m_ExportAlignmentChkBox.Checked)
        {
          using (ExportLandXMLTypeList exportLandXmlTypeList = new ExportLandXMLTypeList(LandXMLElementType.Allignment, this.m_CurrentDocument, ref _AlignmentList))
          {
            if (exportLandXmlTypeList.ElementCount <= 0)
            {
              int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoAlignmentInProjectString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
            }
            else
            {
              int num6 = (int) exportLandXmlTypeList.ShowDialog();
              dialogResult2 = exportLandXmlTypeList.DialogResult;
            }
          }
        }
        if ((dialogResult1 == DialogResult.OK || dialogResult2 == DialogResult.OK) && (_SurfaceList.Count > 0 || _AlignmentList.Count > 0))
        {
          XmlTextWriter xmlTextWriter = new XmlTextWriter(this.m_FileNameTextBox.Text, Encoding.UTF8);
          xmlTextWriter.Formatting = Formatting.Indented;
          xmlTextWriter.WriteStartDocument(false);
          xmlTextWriter.WriteStartElement("LandXML");
          xmlTextWriter.WriteAttributeString("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
          xmlTextWriter.WriteAttributeString("xsi:schemaLocation", "http://www.landxml.org/schema/LandXML-1.1 http://www.landxml.org/schema/LandXML-1.1/LandXML-1.1.xsd");
          xmlTextWriter.WriteAttributeString("xmlns", "http://www.landxml.org/schema/LandXML-1.1");
          xmlTextWriter.WriteAttributeString("version", "1.1");
          string[] strArray1 = new string[5];
          int num7 = DateTime.Now.Year;
          strArray1[0] = num7.ToString("0000");
          strArray1[1] = "-";
          num7 = DateTime.Now.Month;
          strArray1[2] = num7.ToString("00");
          strArray1[3] = "-";
          DateTime now = DateTime.Now;
          num7 = now.Day;
          strArray1[4] = num7.ToString("00");
          string str1 = string.Concat(strArray1);
          xmlTextWriter.WriteAttributeString("date", str1);
          string[] strArray2 = new string[5];
          now = DateTime.Now;
          num7 = now.Hour;
          strArray2[0] = num7.ToString("00");
          strArray2[1] = ":";
          now = DateTime.Now;
          num7 = now.Minute;
          strArray2[2] = num7.ToString("00");
          strArray2[3] = ":";
          now = DateTime.Now;
          num7 = now.Minute;
          strArray2[4] = num7.ToString("00");
          string str2 = string.Concat(strArray2);
          xmlTextWriter.WriteAttributeString("time", str2);
          xmlTextWriter.WriteAttributeString("readOnly", "false");
          xmlTextWriter.WriteAttributeString("language", "English");
          xmlTextWriter.WriteStartElement("Project");
          xmlTextWriter.WriteAttributeString("name", this.m_ProjectTextBox.Text);
          xmlTextWriter.WriteEndElement();
          string text1 = "squareFoot";
          string str3 = "foot";
          string text2 = "cubicFeet";
          string localName;
          string text3;
          string text4;
          if (this.m_CurrentDocument.DisplayUnitSystem == 1)
          {
            localName = "Imperial";
            text3 = "inHG";
            text4 = "fahrenheit";
          }
          else
          {
            localName = "Metric";
            text3 = "mmHG";
            text4 = "celsius";
          }
          switch ((int) this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 0).DisplayUnits)
          {
            case 0:
              str3 = "meter";
              break;
            case 1:
              str3 = "centimeter";
              break;
            case 2:
              str3 = "millimeter";
              break;
            case 3:
              str3 = "foot";
              break;
            case 4:
              str3 = "foot";
              break;
            case 5:
              str3 = "foot";
              break;
            case 6:
              str3 = "inch";
              break;
            case 9:
              str3 = "meter";
              break;
          }
          DisplayUnitType displayUnits1 = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 1).DisplayUnits;
          switch (displayUnits1 - 7)
          {
            case 0:
              text1 = "acre";
              goto case 2;
            case 1:
              text1 = "hectare";
              goto case 2;
            case 2:
            case 3:
label_42:
              DisplayUnitType displayUnits2 = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 2).DisplayUnits;
              switch (displayUnits2 - 10)
              {
                case 0:
                  text2 = "cubicYard";
                  goto case 1;
                case 1:
                case 2:
label_52:
                  xmlTextWriter.WriteStartElement("Units");
                  xmlTextWriter.WriteStartElement(localName);
                  xmlTextWriter.WriteStartAttribute("areaUnit");
                  xmlTextWriter.WriteString(text1);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("linearUnit");
                  xmlTextWriter.WriteString(str3);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("volumeUnit");
                  xmlTextWriter.WriteString(text2);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("temperatureUnit");
                  xmlTextWriter.WriteString(text4);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("pressureUnit");
                  xmlTextWriter.WriteString(text3);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteEndElement();
                  xmlTextWriter.WriteEndElement();
                  xmlTextWriter.WriteStartElement("Application");
                  xmlTextWriter.WriteStartAttribute("name");
                  xmlTextWriter.WriteString($"Site Designer for Revit {ApplicationUtility.RevitVersion}");
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("manufacturer");
                  xmlTextWriter.WriteString("Autodesk");
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("manufacturerURL");
                  xmlTextWriter.WriteString("www.autodesk.com");
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartElement("Author");
                  xmlTextWriter.WriteStartAttribute("createdBy");
                  xmlTextWriter.WriteString(this.m_CreatedByTextBox.Text);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("createdByEmail");
                  xmlTextWriter.WriteString(this.m_EmailTextBox.Text);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteStartAttribute("company");
                  xmlTextWriter.WriteString(this.m_CompanyTextBox.Text);
                  xmlTextWriter.WriteEndAttribute();
                  xmlTextWriter.WriteEndElement();
                  xmlTextWriter.WriteEndElement();
                  double _dPolarSlopeDistance = 0.0;
                  double num8 = 0.0;
                  double num9 = 0.0;
                  double num10 = 0.0;
                  double _dDirection1 = 0.0;
                  double _dDistance1 = 0.0;
                  Eps_Point _NewPnt1 = (Eps_Point) null;
                  if (this.m_BySharedCoordinatesChkBox.Checked)
                  {
                    ProjectPosition projectPosition = this.m_CurrentDocument.ActiveProjectLocation.GetProjectPosition(new XYZ());
                    Eps_Point _StartPnt = new Eps_Point();
                    _StartPnt.x = projectPosition.EastWest;
                    _StartPnt.y = projectPosition.NorthSouth;
                    _StartPnt.z = projectPosition.Elevation;
                    num10 = projectPosition.Angle;
                    EPShared.eplGeoE_CalcXYZToPolar(_StartPnt, new Eps_Point(), ref num8, ref num9, ref _dPolarSlopeDistance);
                  }
                  if (_SurfaceList.Count > 0)
                  {
                    xmlTextWriter.WriteStartElement("Surfaces");
                    xmlTextWriter.WriteAttributeString("name", "");
                    xmlTextWriter.WriteAttributeString("desc", "");
                    foreach (TopographySurfaceContainer surfaceContainer in _SurfaceList)
                    {
                      string str4 = string.Empty;
                      Parameter parameter1 = ((Element) surfaceContainer.TopographySurface)[(BuiltInParameter) -1006900];
                      if (parameter1 != null && parameter1.AsString() != null && parameter1.AsString() != string.Empty)
                        str4 = parameter1.AsString();
                      string str5 = string.Empty;
                      Parameter parameter2 = ((Element) surfaceContainer.TopographySurface)[(BuiltInParameter) -1010106];
                      if (parameter2 != null)
                        str5 = parameter2.AsString();
                      string empty = string.Empty;
                      int num11 = 0;
                      Parameter parameter3 = ((Element) surfaceContainer.TopographySurface)[(BuiltInParameter) -1012101];
                      if (parameter3 != null && parameter3.AsElementId().IntegerValue >= 0)
                      {
                        foreach (Element phase in this.m_CurrentDocument.Phases)
                        {
                          if (phase.Id.IntegerValue == parameter3.AsElementId().IntegerValue)
                          {
                            num11 = parameter3.AsElementId().IntegerValue;
                            break;
                          }
                        }
                      }
                      else
                      {
                        Parameter parameter4 = ((Element) surfaceContainer.TopographySurface)[(BuiltInParameter) -1012100];
                        foreach (Element phase in this.m_CurrentDocument.Phases)
                        {
                          if (phase.Id.IntegerValue == parameter4.AsElementId().IntegerValue)
                          {
                            num11 = parameter4.AsElementId().IntegerValue;
                            break;
                          }
                        }
                      }
                      if (num11 <= 12589)
                      {
                        if (num11 != 0 && num11 == 12589)
                          goto label_84;
                      }
                      else if (num11 != 32440)
                      {
                        if (num11 != 86961)
                          ;
                      }
                      else
                        goto label_84;
                      string str6 = "proposed";
                      goto label_85;
label_84:
                      str6 = "existing";
label_85:
                      bool positioningParameters = this.m_BySharedCoordinatesChkBox.Checked;
                      if (!positioningParameters)
                      {
                        _dPolarSlopeDistance = 0.0;
                        num8 = 0.0;
                        num9 = 0.0;
                        FamilyInstance placementFamilyInstance = ImportLandXMLClass.GetSiteComponentPlacementFamilyInstance(this.m_CurrentDocument, ((Element) surfaceContainer.TopographySurface).UniqueId, true);
                        if (placementFamilyInstance != null)
                          positioningParameters = ImportLandXMLClass.FindPositioningParameters(placementFamilyInstance, ref _dPolarSlopeDistance, ref num8, ref num9);
                      }
                      xmlTextWriter.WriteStartElement("Surface");
                      xmlTextWriter.WriteAttributeString("name", str4);
                      xmlTextWriter.WriteAttributeString("desc", str5);
                      xmlTextWriter.WriteAttributeString("state", str6);
                      xmlTextWriter.WriteStartElement("Definition");
                      xmlTextWriter.WriteAttributeString("surfType", "TIN");
                      xmlTextWriter.WriteStartElement("Pnts");
                      surfaceContainer.TopoPoints.Sort((Comparison<TopoPoint>) ((p1, p2) => p1.Number.CompareTo(p2.Number)));
                      foreach (TopoPoint topoPoint in surfaceContainer.TopoPoints)
                      {
                        xmlTextWriter.WriteStartElement("P");
                        xmlTextWriter.WriteAttributeString("id", topoPoint.Number.ToString());
                        if (positioningParameters)
                        {
                          _NewPnt1 = new Eps_Point(topoPoint.x, topoPoint.y, topoPoint.z);
                          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), _NewPnt1, ref _dDirection1);
                          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), _NewPnt1, ref _dDistance1);
                          EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, _NewPnt1.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                          Eps_Point _NewPnt2 = new Eps_Point();
                          EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt2);
                          xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt2.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt2.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt2.z)}");
                        }
                        else
                          xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, topoPoint.y)} {this.ConvertToLandXMLUnits(str3, topoPoint.x)} {this.ConvertToLandXMLUnits(str3, topoPoint.z)}");
                        xmlTextWriter.WriteEndElement();
                      }
                      xmlTextWriter.WriteEndElement();
                      xmlTextWriter.WriteStartElement("Faces");
                      foreach (Eps_Triangle triangle in surfaceContainer.Triangles)
                      {
                        xmlTextWriter.WriteStartElement("F");
                        xmlTextWriter.WriteString($"{(object) triangle.Verticies[0].Number} {(object) triangle.Verticies[1].Number} {(object) triangle.Verticies[2].Number}");
                        xmlTextWriter.WriteEndElement();
                      }
                      xmlTextWriter.WriteEndElement();
                      xmlTextWriter.WriteEndElement();
                      xmlTextWriter.WriteEndElement();
                    }
                    xmlTextWriter.WriteEndElement();
                  }
                  if (_AlignmentList.Count > 0)
                  {
                    xmlTextWriter.WriteStartElement("Alignments");
                    xmlTextWriter.WriteAttributeString("name", "");
                    foreach (LandXMLAlignment landXmlAlignment in _AlignmentList)
                    {
                      xmlTextWriter.WriteStartElement("Alignment");
                      xmlTextWriter.WriteAttributeString("name", landXmlAlignment.Name);
                      xmlTextWriter.WriteAttributeString("length", landXmlAlignment.Length);
                      xmlTextWriter.WriteAttributeString("staStart", "0");
                      xmlTextWriter.WriteStartElement("Start");
                      if (this.m_BySharedCoordinatesChkBox.Checked)
                      {
                        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), landXmlAlignment.StartPoint, ref _dDirection1);
                        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), landXmlAlignment.StartPoint, ref _dDistance1);
                        EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, landXmlAlignment.StartPoint.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                        Eps_Point _NewPnt3 = new Eps_Point();
                        EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt3);
                        xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt3.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt3.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt3.z)}");
                      }
                      else
                        xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, landXmlAlignment.StartPoint.y)} {this.ConvertToLandXMLUnits(str3, landXmlAlignment.StartPoint.x)} {this.ConvertToLandXMLUnits(str3, landXmlAlignment.StartPoint.z)}");
                      xmlTextWriter.WriteEndElement();
                      xmlTextWriter.WriteStartElement("CoordGeom");
                      Eps_Point epsPoint = landXmlAlignment.StartPoint;
                      bool flag = true;
                      while ((landXmlAlignment.Lines.Count > 0 || landXmlAlignment.Curves.Count > 0) && flag)
                      {
                        flag = false;
                        for (int index = 0; index < landXmlAlignment.Lines.Count; ++index)
                        {
                          Eps_Line line = landXmlAlignment.Lines[index];
                          if (epsPoint.IsEqual(line.StartPnt))
                          {
                            xmlTextWriter.WriteStartElement("Line");
                            double _dDirection2 = 0.0;
                            string empty1 = string.Empty;
                            if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(line.StartPnt, line.EndPnt, ref _dDirection2) == 0)
                              empty1 = ValueConversion.ToString(_dDirection2);
                            xmlTextWriter.WriteAttributeString("dir", empty1);
                            double _dDistance2 = 0.0;
                            string empty2 = string.Empty;
                            if (EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(line.StartPnt, line.EndPnt, ref _dDistance2) == 0)
                              empty2 = ValueConversion.ToString(_dDistance2);
                            xmlTextWriter.WriteAttributeString("length", empty2);
                            xmlTextWriter.WriteStartElement("Start");
                            if (this.m_BySharedCoordinatesChkBox.Checked)
                            {
                              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), line.StartPnt, ref _dDirection1);
                              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), line.StartPnt, ref _dDistance1);
                              EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, line.StartPnt.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                              Eps_Point _NewPnt4 = new Eps_Point();
                              EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt4);
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt4.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt4.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt4.z)}");
                            }
                            else
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, line.StartPnt.y)} {this.ConvertToLandXMLUnits(str3, line.StartPnt.x)} {this.ConvertToLandXMLUnits(str3, line.StartPnt.z)}");
                            xmlTextWriter.WriteEndElement();
                            xmlTextWriter.WriteStartElement("End");
                            if (this.m_BySharedCoordinatesChkBox.Checked)
                            {
                              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), line.EndPnt, ref _dDirection1);
                              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), line.EndPnt, ref _dDistance1);
                              EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, line.EndPnt.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                              Eps_Point _NewPnt5 = new Eps_Point();
                              EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt5);
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt5.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt5.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt5.z)}");
                            }
                            else
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, line.EndPnt.y)} {this.ConvertToLandXMLUnits(str3, line.EndPnt.x)} {this.ConvertToLandXMLUnits(str3, line.EndPnt.z)}");
                            xmlTextWriter.WriteEndElement();
                            xmlTextWriter.WriteEndElement();
                            flag = true;
                            epsPoint = line.EndPnt;
                            landXmlAlignment.Lines.RemoveAt(index);
                            --index;
                          }
                        }
                        for (int index = 0; index < landXmlAlignment.Curves.Count; ++index)
                        {
                          Eps_Arc curve = landXmlAlignment.Curves[index];
                          if (epsPoint.IsEqual(curve.StartPnt))
                          {
                            xmlTextWriter.WriteStartElement("Curve");
                            string str7 = "cw";
                            if (curve.Direction == 1)
                              str7 = "ccw";
                            xmlTextWriter.WriteAttributeString("rot", str7);
                            xmlTextWriter.WriteAttributeString("delta", ValueConversion.ToString(curve.Delta));
                            double _dValue = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(curve.Radius, curve.Delta);
                            xmlTextWriter.WriteAttributeString("length", ValueConversion.ToString(_dValue));
                            xmlTextWriter.WriteAttributeString("radius", ValueConversion.ToString(curve.Radius));
                            xmlTextWriter.WriteStartElement("Start");
                            if (this.m_BySharedCoordinatesChkBox.Checked)
                            {
                              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), curve.StartPnt, ref _dDirection1);
                              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), curve.StartPnt, ref _dDistance1);
                              EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, curve.StartPnt.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                              Eps_Point _NewPnt6 = new Eps_Point();
                              EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt6);
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt6.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt6.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt6.z)}");
                            }
                            else
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, curve.StartPnt.y)} {this.ConvertToLandXMLUnits(str3, curve.StartPnt.x)} {this.ConvertToLandXMLUnits(str3, curve.StartPnt.z)}");
                            xmlTextWriter.WriteEndElement();
                            xmlTextWriter.WriteStartElement("Center");
                            if (this.m_BySharedCoordinatesChkBox.Checked)
                            {
                              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), curve.RadiusPnt, ref _dDirection1);
                              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), curve.RadiusPnt, ref _dDistance1);
                              EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, curve.RadiusPnt.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                              Eps_Point _NewPnt7 = new Eps_Point();
                              EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt7);
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt7.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt7.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt7.z)}");
                            }
                            else
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, curve.RadiusPnt.y)} {this.ConvertToLandXMLUnits(str3, curve.RadiusPnt.x)} {this.ConvertToLandXMLUnits(str3, curve.RadiusPnt.z)}");
                            xmlTextWriter.WriteEndElement();
                            xmlTextWriter.WriteStartElement("End");
                            if (this.m_BySharedCoordinatesChkBox.Checked)
                            {
                              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(new Eps_Point(), curve.EndPnt, ref _dDirection1);
                              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(new Eps_Point(), curve.EndPnt, ref _dDistance1);
                              EPShared.eplGeoE_CalcPolarToXY(new Eps_Point(0.0, 0.0, curve.EndPnt.z), EPShared.eplGeoE_NormalizeRadians(_dDirection1 + num10), _dDistance1, ref _NewPnt1);
                              Eps_Point _NewPnt8 = new Eps_Point();
                              EPShared.eplGeoE_CalcPolarToXYZ(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(num8 + Math.PI), -num9, _dPolarSlopeDistance, ref _NewPnt8);
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, _NewPnt8.y)} {this.ConvertToLandXMLUnits(str3, _NewPnt8.x)} {this.ConvertToLandXMLUnits(str3, _NewPnt8.z)}");
                            }
                            else
                              xmlTextWriter.WriteString($"{this.ConvertToLandXMLUnits(str3, curve.EndPnt.y)} {this.ConvertToLandXMLUnits(str3, curve.EndPnt.x)} {this.ConvertToLandXMLUnits(str3, curve.EndPnt.z)}");
                            xmlTextWriter.WriteEndElement();
                            xmlTextWriter.WriteEndElement();
                            flag = true;
                            epsPoint = curve.EndPnt;
                            landXmlAlignment.Curves.RemoveAt(index);
                            --index;
                          }
                        }
                      }
                      xmlTextWriter.WriteEndElement();
                      xmlTextWriter.WriteEndElement();
                    }
                    xmlTextWriter.WriteEndElement();
                  }
                  xmlTextWriter.WriteEndElement();
                  xmlTextWriter.WriteEndDocument();
                  xmlTextWriter.Close();
                  if (this.m_ExportAlignmentChkBox.Checked && this.m_ExportSurfaceChkBox.Checked)
                  {
                    int num12 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExportLandXMLComponentsCompleteString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
                    break;
                  }
                  if (this.m_ExportAlignmentChkBox.Checked)
                  {
                    if (_AlignmentList.Count > 0)
                    {
                      int num13 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExportAlignmentLandXMLCompleteString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
                      break;
                    }
                    int num14 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoAlignmentToExportString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
                    break;
                  }
                  if (this.m_ExportSurfaceChkBox.Checked)
                  {
                    if (_SurfaceList.Count > 0)
                    {
                      int num15 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExportSurfaceLandXMLCompleteString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
                      break;
                    }
                    int num16 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSurfacesToExportString"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
                    break;
                  }
                  break;
                case 3:
                  text2 = "cubicFeet";
                  goto case 1;
                case 4:
                  text2 = "cubicMeter";
                  goto case 1;
                default:
                  switch (displayUnits2 - 23)
                  {
                    case 0:
                      text2 = "cubicInch";
                      goto label_52;
                    case 1:
                      text2 = "cubicMeter";
                      goto label_52;
                    case 2:
                      text2 = "cubicMeter";
                      goto label_52;
                    case 3:
                      text2 = "liter";
                      goto label_52;
                    case 4:
                      text2 = "liter";
                      goto label_52;
                    default:
                      goto label_52;
                  }
              }
              break;
            case 4:
              text1 = "squareFoot";
              goto case 2;
            case 5:
              text1 = "squareMeter";
              goto case 2;
            default:
              switch (displayUnits1 - 20)
              {
                case 0:
                  text1 = "squareInch";
                  goto label_42;
                case 1:
                  text1 = "squareCentimeter";
                  goto label_42;
                case 2:
                  text1 = "squareMillimeter";
                  goto label_42;
                default:
                  goto label_42;
              }
          }
        }
        this.DialogResult = DialogResult.OK;
      }
    }
  }

  private string ConvertToLandXMLUnits(string _strCurrentUnit, double _dValue)
  {
    if (string.Compare(_strCurrentUnit, "foot", true) == 0)
      return ValueConversion.ToString(_dValue);
    if (string.Compare(_strCurrentUnit, "inch", true) == 0)
      return ValueConversion.ToString(_dValue * 12.0);
    if (string.Compare(_strCurrentUnit, "meter", true) == 0)
      return ValueConversion.ToString(_dValue * 0.3048);
    if (string.Compare(_strCurrentUnit, "centimeter", true) == 0)
      return ValueConversion.ToString(_dValue * 0.3048 * 100.0);
    return string.Compare(_strCurrentUnit, "millimeter", true) == 0 ? ValueConversion.ToString(_dValue * 0.3048 * 1000.0) : ValueConversion.ToString(_dValue);
  }

  private void OnCanceButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnExportXMLClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private bool VerifyFileNameAndPath()
  {
    if (string.IsNullOrEmpty(this.m_FileNameTextBox.Text))
      return false;
    if (!string.IsNullOrEmpty(this.m_FileNameTextBox.Text))
    {
      FileInfo fileInfo = new FileInfo(this.m_FileNameTextBox.Text);
      if (File.Exists(this.m_FileNameTextBox.Text) && string.Compare(fileInfo.Extension, ".xml", true) != 0)
      {
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Source")} {EPShared.LocalRM.GetString("NoXMLExtension")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    return true;
  }

  private void OnXMLFileOpenClicked(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.Filter = ApplicationUtility.GetString("XmlFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_FileNameTextBox.Text = saveFileDialog.FileName;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ExportInformation = new GroupBox();
    this.m_CompanyTextBox = new TextBox();
    this.m_EmailTextBox = new TextBox();
    this.m_CreatedByTextBox = new TextBox();
    this.m_ProjectTextBox = new TextBox();
    this.m_CompanyLbl = new Label();
    this.m_EmailLbl = new Label();
    this.m_CreatedByLbl = new Label();
    this.m_ProjectName = new Label();
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.m_ExportSurfaceChkBox = new CheckBox();
    this.m_ExportAlignmentChkBox = new CheckBox();
    this.m_FileOpen = new Button();
    this.m_FileNameTextBox = new TextBox();
    this.m_FileName = new Label();
    this.m_BySharedCoordinatesChkBox = new CheckBox();
    this.m_ExportInformation.SuspendLayout();
    this.SuspendLayout();
    this.m_ExportInformation.Controls.Add((Control) this.m_CompanyTextBox);
    this.m_ExportInformation.Controls.Add((Control) this.m_EmailTextBox);
    this.m_ExportInformation.Controls.Add((Control) this.m_CreatedByTextBox);
    this.m_ExportInformation.Controls.Add((Control) this.m_ProjectTextBox);
    this.m_ExportInformation.Controls.Add((Control) this.m_CompanyLbl);
    this.m_ExportInformation.Controls.Add((Control) this.m_EmailLbl);
    this.m_ExportInformation.Controls.Add((Control) this.m_CreatedByLbl);
    this.m_ExportInformation.Controls.Add((Control) this.m_ProjectName);
    this.m_ExportInformation.Location = new Point(12, 32 /*0x20*/);
    this.m_ExportInformation.Name = "m_ExportInformation";
    this.m_ExportInformation.Size = new Size(369, 123);
    this.m_ExportInformation.TabIndex = 3;
    this.m_ExportInformation.TabStop = false;
    this.m_ExportInformation.Text = "User Information";
    this.m_CompanyTextBox.Location = new Point(126, 97);
    this.m_CompanyTextBox.Name = "m_CompanyTextBox";
    this.m_CompanyTextBox.Size = new Size(235, 20);
    this.m_CompanyTextBox.TabIndex = 7;
    this.m_EmailTextBox.Location = new Point(126, 71);
    this.m_EmailTextBox.Name = "m_EmailTextBox";
    this.m_EmailTextBox.Size = new Size(235, 20);
    this.m_EmailTextBox.TabIndex = 5;
    this.m_CreatedByTextBox.Location = new Point(126, 45);
    this.m_CreatedByTextBox.Name = "m_CreatedByTextBox";
    this.m_CreatedByTextBox.Size = new Size(235, 20);
    this.m_CreatedByTextBox.TabIndex = 3;
    this.m_ProjectTextBox.Location = new Point(126, 19);
    this.m_ProjectTextBox.Name = "m_ProjectTextBox";
    this.m_ProjectTextBox.Size = new Size(235, 20);
    this.m_ProjectTextBox.TabIndex = 1;
    this.m_CompanyLbl.AutoSize = true;
    this.m_CompanyLbl.Location = new Point(6, 100);
    this.m_CompanyLbl.Name = "m_CompanyLbl";
    this.m_CompanyLbl.Size = new Size(51, 13);
    this.m_CompanyLbl.TabIndex = 6;
    this.m_CompanyLbl.Text = "Company";
    this.m_EmailLbl.AutoSize = true;
    this.m_EmailLbl.Location = new Point(6, 74);
    this.m_EmailLbl.Name = "m_EmailLbl";
    this.m_EmailLbl.Size = new Size(86, 13);
    this.m_EmailLbl.TabIndex = 4;
    this.m_EmailLbl.Text = "Created by Email";
    this.m_CreatedByLbl.AutoSize = true;
    this.m_CreatedByLbl.Location = new Point(6, 48 /*0x30*/);
    this.m_CreatedByLbl.Name = "m_CreatedByLbl";
    this.m_CreatedByLbl.Size = new Size(58, 13);
    this.m_CreatedByLbl.TabIndex = 2;
    this.m_CreatedByLbl.Text = "Created by";
    this.m_ProjectName.AutoSize = true;
    this.m_ProjectName.Location = new Point(6, 22);
    this.m_ProjectName.Name = "m_ProjectName";
    this.m_ProjectName.Size = new Size(40, 13);
    this.m_ProjectName.TabIndex = 0;
    this.m_ProjectName.Text = "Project";
    this.m_ButtonOk.Location = new Point(225, 230);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 7;
    this.m_ButtonOk.Text = "Ok";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnOkButtonClicked);
    this.m_ButtonCancel.Location = new Point(306, 230);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 8;
    this.m_ButtonCancel.Text = "Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnCanceButtonClicked);
    this.m_ExportSurfaceChkBox.AutoSize = true;
    this.m_ExportSurfaceChkBox.Location = new Point(12, 161);
    this.m_ExportSurfaceChkBox.Name = "m_ExportSurfaceChkBox";
    this.m_ExportSurfaceChkBox.Size = new Size(162, 17);
    this.m_ExportSurfaceChkBox.TabIndex = 4;
    this.m_ExportSurfaceChkBox.Text = "Export Surfaces to LandXML";
    this.m_ExportSurfaceChkBox.UseVisualStyleBackColor = true;
    this.m_ExportAlignmentChkBox.AutoSize = true;
    this.m_ExportAlignmentChkBox.Location = new Point(12, 184);
    this.m_ExportAlignmentChkBox.Name = "m_ExportAlignmentChkBox";
    this.m_ExportAlignmentChkBox.Size = new Size(187, 17);
    this.m_ExportAlignmentChkBox.TabIndex = 5;
    this.m_ExportAlignmentChkBox.Text = "Export Alignments to LandXML file";
    this.m_ExportAlignmentChkBox.UseVisualStyleBackColor = true;
    this.m_FileOpen.Location = new Point(357, 6);
    this.m_FileOpen.Name = "m_FileOpen";
    this.m_FileOpen.Size = new Size(24, 20);
    this.m_FileOpen.TabIndex = 2;
    this.m_FileOpen.Text = "...";
    this.m_FileOpen.UseVisualStyleBackColor = true;
    this.m_FileOpen.Click += new EventHandler(this.OnXMLFileOpenClicked);
    this.m_FileNameTextBox.Location = new Point(138, 6);
    this.m_FileNameTextBox.Name = "m_FileNameTextBox";
    this.m_FileNameTextBox.Size = new Size(213, 20);
    this.m_FileNameTextBox.TabIndex = 1;
    this.m_FileName.AutoSize = true;
    this.m_FileName.Location = new Point(12, 9);
    this.m_FileName.Name = "m_FileName";
    this.m_FileName.Size = new Size(35, 13);
    this.m_FileName.TabIndex = 0;
    this.m_FileName.Text = "Name";
    this.m_BySharedCoordinatesChkBox.AutoSize = true;
    this.m_BySharedCoordinatesChkBox.Location = new Point(12, 207);
    this.m_BySharedCoordinatesChkBox.Name = "m_BySharedCoordinatesChkBox";
    this.m_BySharedCoordinatesChkBox.Size = new Size(141, 17);
    this.m_BySharedCoordinatesChkBox.TabIndex = 6;
    this.m_BySharedCoordinatesChkBox.Text = "Use Shared Coordinates";
    this.m_BySharedCoordinatesChkBox.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(393, 265);
    this.Controls.Add((Control) this.m_BySharedCoordinatesChkBox);
    this.Controls.Add((Control) this.m_FileOpen);
    this.Controls.Add((Control) this.m_FileNameTextBox);
    this.Controls.Add((Control) this.m_FileName);
    this.Controls.Add((Control) this.m_ExportAlignmentChkBox);
    this.Controls.Add((Control) this.m_ExportSurfaceChkBox);
    this.Controls.Add((Control) this.m_ButtonCancel);
    this.Controls.Add((Control) this.m_ButtonOk);
    this.Controls.Add((Control) this.m_ExportInformation);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ExportLandXMLManager);
    this.Text = "ExportToLandXML";
    this.FormClosing += new FormClosingEventHandler(this.OnExportXMLClosing);
    this.m_ExportInformation.ResumeLayout(false);
    this.m_ExportInformation.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
