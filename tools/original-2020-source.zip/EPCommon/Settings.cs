﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Settings
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

#nullable disable
namespace EPCommon;

public class Settings
{
  private const string m_strIntegerAbbr = "I";
  private const string m_strLongAbbr = "L";
  private const string m_strShortAbbr = "H";
  private const string m_strStringAbbr = "S";
  private const string m_strDoubleAbbr = "D";
  private const string m_strFloatAbbr = "F";
  private const string m_strSettingAppName = "Setting";
  private const string m_strAppDateTime = "DateTime";
  private const int m_nMaxStringBuilderSize = 32767 /*0x7FFF*/;
  private const int m_nMaxProjectSettingsInIni = 10;
  private string m_strProjectIniFileName;
  private List<ProjectSettingContainer> m_ProjectSettingList;

  public Settings(string _strProjectIniFileName)
  {
    this.m_strProjectIniFileName = _strProjectIniFileName;
  }

  public bool eplSetE_GetSetting(string _strSettingsName, ref double _dReturnValue)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _dReturnValue);
  }

  public bool eplSetE_GetSetting(
    string _strSettingsName,
    ref double _dReturnValue,
    string _strProjectIniFileName)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _dReturnValue, _strProjectIniFileName);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref double _dReturnValue)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "D", this.m_strProjectIniFileName);
    if (setting)
      _dReturnValue = ValueConversion.ToDouble(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref double _dReturnValue,
    string _strProjectIniFileName)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "D", _strProjectIniFileName);
    if (setting)
      _dReturnValue = ValueConversion.ToDouble(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(string _strSettingsName, ref float _fReturnValue)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _fReturnValue);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref float _fReturnValue)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "F", this.m_strProjectIniFileName);
    if (setting)
      _fReturnValue = Convert.ToSingle(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(string _strSettingsName, ref string _strReturnValue)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _strReturnValue);
  }

  public bool eplSetE_GetSetting(
    string _strSettingsName,
    ref string _strReturnValue,
    string _strProjectIniFileName)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _strReturnValue, _strProjectIniFileName);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref string _strReturnValue)
  {
    return this.GetSetting(_strSettingAppName, _strSettingsName, ref _strReturnValue, "S", this.m_strProjectIniFileName);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref string _strReturnValue,
    string _strProjectIniFileName)
  {
    return this.GetSetting(_strSettingAppName, _strSettingsName, ref _strReturnValue, "S", _strProjectIniFileName);
  }

  public bool eplSetE_GetSetting(string _strSettingsName, ref int _nReturnValue)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _nReturnValue);
  }

  public bool eplSetE_GetSetting(
    string _strSettingsName,
    ref int _nReturnValue,
    string _strProjectIniFileName)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _nReturnValue, _strProjectIniFileName);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref int _nReturnValue)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "I", this.m_strProjectIniFileName);
    if (setting)
      _nReturnValue = Convert.ToInt32(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref int _nReturnValue,
    string _strProjectIniFileName)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "I", _strProjectIniFileName);
    if (setting)
      _nReturnValue = Convert.ToInt32(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(string _strSettingsName, ref long _lReturnValue)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _lReturnValue);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref long _lReturnValue)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "L", this.m_strProjectIniFileName);
    if (setting)
      _lReturnValue = Convert.ToInt64(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(string _strSettingsName, ref short _sReturnValue)
  {
    return this.eplSetE_GetSetting("Setting", _strSettingsName, ref _sReturnValue);
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref short _sReturnValue)
  {
    string empty = string.Empty;
    bool setting = this.GetSetting(_strSettingAppName, _strSettingsName, ref empty, "H", this.m_strProjectIniFileName);
    if (setting)
      _sReturnValue = Convert.ToInt16(empty);
    return setting;
  }

  public bool eplSetE_GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref string _strReturnValue,
    string _strAbbr,
    string _strProjectIniFileName)
  {
    return this.GetSetting(_strSettingAppName, _strSettingsName, ref _strReturnValue, _strAbbr, _strProjectIniFileName);
  }

  private bool GetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    ref string _strReturnValue,
    string _strAbbr,
    string _strProjectIniFileName)
  {
    if (_strSettingsName != string.Empty)
    {
      StringBuilder ReturnedString = new StringBuilder((int) short.MaxValue);
      string empty = string.Empty;
      string _strKeyName = $"{_strSettingsName}" + _strAbbr;
      int privateProfileString = (int) Settings.GetPrivateProfileString(_strSettingAppName, _strKeyName, empty, ReturnedString, (int) short.MaxValue, _strProjectIniFileName);
      if (ReturnedString != null && ReturnedString.Length > 0)
      {
        _strReturnValue = ReturnedString.ToString();
        return true;
      }
    }
    return false;
  }

  public bool eplSetE_SetSetting(string _strSettingsName, int _nValue)
  {
    return this.SetSetting("Setting", _strSettingsName, Convert.ToString(_nValue), "I");
  }

  public bool eplSetE_SetSetting(string _strSettingAppName, string _strSettingsName, int _nValue)
  {
    return this.SetSetting(_strSettingAppName, _strSettingsName, Convert.ToString(_nValue), "I");
  }

  public bool eplSetE_SetSetting(string _strSettingsName, long _lValue)
  {
    return this.SetSetting("Setting", _strSettingsName, Convert.ToString(_lValue), "L");
  }

  public bool eplSetE_SetSetting(string _strSettingAppName, string _strSettingsName, long _lValue)
  {
    return this.SetSetting(_strSettingAppName, _strSettingsName, Convert.ToString(_lValue), "L");
  }

  public bool eplSetE_SetSetting(string _strSettingsName, short _sValue)
  {
    return this.SetSetting("Setting", _strSettingsName, Convert.ToString(_sValue), "H");
  }

  public bool eplSetE_SetSetting(string _strSettingAppName, string _strSettingsName, short _sValue)
  {
    return this.SetSetting(_strSettingAppName, _strSettingsName, Convert.ToString(_sValue), "H");
  }

  public bool eplSetE_SetSetting(string _strSettingsName, double _dValue)
  {
    return this.SetSetting("Setting", _strSettingsName, ValueConversion.ToString(_dValue), "D");
  }

  public bool eplSetE_SetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    double _dValue)
  {
    return this.SetSetting(_strSettingAppName, _strSettingsName, ValueConversion.ToString(_dValue), "D");
  }

  public bool eplSetE_SetSetting(string _strSettingsName, float _fValue)
  {
    return this.SetSetting("Setting", _strSettingsName, Convert.ToString(_fValue), "F");
  }

  public bool eplSetE_SetSetting(string _strSettingAppName, string _strSettingsName, float _fValue)
  {
    return this.SetSetting(_strSettingAppName, _strSettingsName, Convert.ToString(_fValue), "F");
  }

  public bool eplSetE_SetSetting(string _strSettingsName, string _strValue)
  {
    return this.SetSetting("Setting", _strSettingsName, _strValue, "S");
  }

  public bool eplSetE_SetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    string _strValue)
  {
    return this.SetSetting(_strSettingAppName, _strSettingsName, _strValue, "S");
  }

  private bool SetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    string _strValue,
    string _strAbbr)
  {
    string _strKeyName = $"{_strSettingsName}" + _strAbbr;
    Settings.WritePrivateProfileString(_strSettingAppName, _strKeyName, _strValue, this.m_strProjectIniFileName);
    return true;
  }

  public static bool eplSetE_SetSetting(
    string _strSettingAppName,
    string _strSettingsName,
    string _strValue,
    string _strFileName)
  {
    return Settings.WritePrivateProfileString(_strSettingAppName, _strSettingsName, _strValue, _strFileName);
  }

  public bool eplSetE_SetSettingWithAbbreviation(
    string _strSettingAppName,
    string _strSettingsName,
    string _strValue)
  {
    return Settings.WritePrivateProfileString(_strSettingAppName, _strSettingsName, _strValue, this.m_strProjectIniFileName);
  }

  public void eplSetE_UpdateIniInformation(string _strSettingAppName)
  {
    string empty1 = string.Empty;
    DateTime now = DateTime.Now;
    this.eplSetE_SetSetting(_strSettingAppName, "DateTime", Convert.ToString(now));
    if (this.m_ProjectSettingList == null)
    {
      this.m_ProjectSettingList = new List<ProjectSettingContainer>();
      IntPtr num = Marshal.AllocCoTaskMem((int) short.MaxValue);
      string[] stringArray;
      try
      {
        int profileSectionNames = Settings.GetPrivateProfileSectionNames(num, (uint) short.MaxValue, this.m_strProjectIniFileName);
        stringArray = Settings.ConvertNullSeperatedStringToStringArray(num, profileSectionNames);
      }
      finally
      {
        Marshal.FreeCoTaskMem(num);
      }
      for (int index = 0; index < stringArray.Length; ++index)
      {
        if (string.Compare(stringArray[index], "Setting", true) != 0)
        {
          string empty2 = string.Empty;
          if (this.eplSetE_GetSetting(stringArray[index], "DateTime", ref empty2) && empty2 != string.Empty)
            this.m_ProjectSettingList.Add(new ProjectSettingContainer(stringArray[index], Convert.ToDateTime(empty2)));
        }
      }
    }
    else
    {
      bool flag = false;
      for (int index = 0; index < this.m_ProjectSettingList.Count; ++index)
      {
        string appName = this.m_ProjectSettingList[index].AppName;
        if (string.Compare(_strSettingAppName, appName, true) == 0)
        {
          flag = true;
          this.m_ProjectSettingList[index].CurrentDateTime = now;
          break;
        }
      }
      if (!flag)
        this.m_ProjectSettingList.Add(new ProjectSettingContainer(_strSettingAppName, now));
    }
    this.m_ProjectSettingList.Sort((IComparer<ProjectSettingContainer>) new ProjectSettingComparer(true));
    for (int index = this.m_ProjectSettingList.Count - 1; index >= 10; --index)
    {
      Settings.WritePrivateProfileString(this.m_ProjectSettingList[index].AppName, (string) null, (string) null, this.m_strProjectIniFileName);
      this.m_ProjectSettingList.RemoveAt(index);
    }
  }

  private static string[] ConvertNullSeperatedStringToStringArray(IntPtr _IntPtr, int _nValueLength)
  {
    return _nValueLength != 0 ? Marshal.PtrToStringAuto(_IntPtr, _nValueLength - 1).Split(new char[1]) : new string[0];
  }

  public List<KeyValuePair<string, string>> eplSetE_GetSectionValuesAsList(string _strSettingAppName)
  {
    return Settings.eplSetE_GetSectionValuesAsList(_strSettingAppName, this.m_strProjectIniFileName);
  }

  public static List<KeyValuePair<string, string>> eplSetE_GetSectionValuesAsList(
    string _strSettingAppName,
    string _strFileName)
  {
    if (_strSettingAppName == null)
      throw new ArgumentNullException("SettingAppName");
    IntPtr num = Marshal.AllocCoTaskMem((int) short.MaxValue);
    string[] stringArray;
    try
    {
      int privateProfileSection = Settings.GetPrivateProfileSection(_strSettingAppName, num, (int) short.MaxValue, _strFileName);
      stringArray = Settings.ConvertNullSeperatedStringToStringArray(num, privateProfileSection);
    }
    finally
    {
      Marshal.FreeCoTaskMem(num);
    }
    List<KeyValuePair<string, string>> sectionValuesAsList = new List<KeyValuePair<string, string>>(stringArray.Length);
    for (int index = 0; index < stringArray.Length; ++index)
    {
      int length = stringArray[index].IndexOf('=');
      string key = stringArray[index].Substring(0, length);
      string str = stringArray[index].Substring(length + 1, stringArray[index].Length - length - 1);
      sectionValuesAsList.Add(new KeyValuePair<string, string>(key, str));
    }
    return sectionValuesAsList;
  }

  public static bool eplSetE_DeleteSection(string _strSettingAppName, string _strFileName)
  {
    return _strSettingAppName != null ? Settings.WritePrivateProfileString(_strSettingAppName, (string) null, (string) null, _strFileName) : throw new ArgumentNullException("SettingAppName");
  }

  public bool eplSetE_DeleteIntegerSetting(string _strSettingsName)
  {
    return Settings.WritePrivateProfileString("Setting", $"{_strSettingsName}" + "I", (string) null, this.m_strProjectIniFileName);
  }

  public bool eplSetE_DeleteStringSetting(string _strSettingsName)
  {
    return Settings.WritePrivateProfileString("Setting", $"{_strSettingsName}" + "S", (string) null, this.m_strProjectIniFileName);
  }

  [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
  public static extern int GetPrivateProfileSectionNames(
    IntPtr lpszReturnBuffer,
    uint nSize,
    string lpFileName);

  [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
  private static extern uint GetPrivateProfileString(
    string _strAppName,
    string _strKeyName,
    string _strDefault,
    StringBuilder ReturnedString,
    int _nSize,
    string _strFileName);

  [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
  private static extern int GetPrivateProfileInt(
    string _strAppName,
    string _strKeyName,
    int _strDefault,
    string _strFileName);

  [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
  private static extern int GetPrivateProfileSection(
    string _strAppName,
    IntPtr lpReturnedString,
    int _nSize,
    string _strFileName);

  [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
  private static extern bool WritePrivateProfileString(
    string _strAppName,
    string _strKeyName,
    string _strValue,
    string _strFileName);

  public string ProjectIniFileName
  {
    get => this.m_strProjectIniFileName;
    set => this.m_strProjectIniFileName = value;
  }
}
