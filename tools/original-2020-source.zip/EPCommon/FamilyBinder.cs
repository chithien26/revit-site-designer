﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyBinder
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FamilyBinder
{
  private string m_strFamilyName;
  private string m_strFamilyPath;
  private List<FamilyTypeContainer> m_FamilySymbolList;
  private bool m_bModified;
  private Document m_FamilyDocument;
  private Family m_Family;
  private bool m_bLoaded;

  public FamilyBinder()
  {
    this.m_strFamilyName = string.Empty;
    this.m_strFamilyPath = string.Empty;
    this.m_FamilySymbolList = new List<FamilyTypeContainer>();
    this.m_bModified = false;
  }

  public FamilyBinder(string _strFamilyName)
  {
    this.m_strFamilyName = _strFamilyName;
    this.m_strFamilyPath = string.Empty;
    this.m_FamilySymbolList = new List<FamilyTypeContainer>();
    this.m_bModified = false;
    this.m_FamilyDocument = (Document) null;
    this.m_Family = (Family) null;
  }

  public FamilyBinder(string _strFamilyName, string _strFamilyPath)
  {
    this.m_strFamilyName = _strFamilyName;
    this.m_strFamilyPath = _strFamilyPath;
    this.m_FamilySymbolList = new List<FamilyTypeContainer>();
    this.m_bModified = false;
    this.m_FamilyDocument = (Document) null;
    this.m_Family = (Family) null;
  }

  public FamilyBinder(string _strFamilyName, string _strFamilyPath, Document _FamilyDocument)
  {
    this.m_strFamilyName = _strFamilyName;
    this.m_strFamilyPath = _strFamilyPath;
    this.m_FamilySymbolList = new List<FamilyTypeContainer>();
    this.m_bModified = false;
    this.m_FamilyDocument = _FamilyDocument;
    this.m_Family = (Family) null;
  }

  public FamilyBinder(
    string _strFamilyName,
    string _strFamilyPath,
    Document _FamilyDocument,
    Family _Family)
  {
    this.m_strFamilyName = _strFamilyName;
    this.m_strFamilyPath = _strFamilyPath;
    this.m_FamilySymbolList = new List<FamilyTypeContainer>();
    this.m_bModified = false;
    this.m_FamilyDocument = _FamilyDocument;
    this.m_Family = _Family;
  }

  public string FamilyName
  {
    get => this.m_strFamilyName;
    set => this.m_strFamilyName = value;
  }

  public string FamilyPath
  {
    get => this.m_strFamilyPath;
    set => this.m_strFamilyPath = value;
  }

  public List<FamilyTypeContainer> FamilyTypeList
  {
    get => this.m_FamilySymbolList;
    set => this.m_FamilySymbolList = value;
  }

  public bool IsModified
  {
    get => this.m_bModified;
    set => this.m_bModified = value;
  }

  public Document FamilyDocument
  {
    get => this.m_FamilyDocument;
    set => this.m_FamilyDocument = value;
  }

  public Family BinderFamily
  {
    get => this.m_Family;
    set => this.m_Family = value;
  }

  public bool Loaded
  {
    get => this.m_bLoaded;
    set => this.m_bLoaded = value;
  }
}
