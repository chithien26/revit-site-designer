﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ModifyPlantForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ModifyPlantForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private ModifyPlant m_dataBuffer;
  private FamilySymbol m_CurType;
  private FamilySymbol m_ExistingType;
  private FormatOptions m_FormatOptions;
  private UnitSymbolType m_UnitSymbolType;
  private DisplayUnit m_DisplayUnitSystem;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private GroupBox m_ExistingGroupBox;
  private Button m_PickPlantButton;
  private ComboBox m_ExistingPlantNameComboBox;
  private Label m_ExistingPlantNameLabel;
  private ComboBox m_ExistingPlantFamilyComboBox;
  private Label m_ExistingPlantFamilyLabel;
  private GroupBox m_ModifyPlantGroupBox;
  private Button m_SearchButton;
  private ComboBox m_PlantNameComboBox;
  private Label m_PlantNameLabel;
  private ComboBox m_PlantFamilyComboBox;
  private Label m_PlantFamilyLabel;
  private TextBox m_PlantHeightTextBox;
  private Label m_PlantHeightLabel;
  private TextBox m_PlantWidthTextBox;
  private Label m_PlantWidthLabel;
  private RadioButton m_AllInstancesRadioButton;
  private GroupBox m_SelectionMethodsGroupBox;
  private RadioButton m_WindowSelectRadioButton;
  private RadioButton m_SelectionSetRadioButton;
  private CheckBox m_ModifyPlantHeightCheckBox;
  private CheckBox m_ModifyPlantWidthCheckBox;
  private CheckBox m_ModifyPlantTypeCheckBox;
  private Button m_ApplyButton;
  private Button m_CancelButton;
  private Button m_LoadFamilyButton;

  public ModifyPlantForm(ModifyPlant _dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ModifyPlantsDialog");
    this.m_ExistingGroupBox.Text = EPShared.LocalRM.GetString("ExistingPlantsInProjDialog");
    this.m_ExistingPlantFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_PlantFamilyDialog");
    this.m_ExistingPlantNameLabel.Text = EPShared.LocalRM.GetString("P_AMP_lantNameDialog");
    this.m_PickPlantButton.Text = EPShared.LocalRM.GetString("Pic_AMP_kPlantDialog");
    this.m_ModifyPlantGroupBox.Text = EPShared.LocalRM.GetString("ModifyPlantsInProjDialog");
    this.m_ModifyPlantTypeCheckBox.Text = EPShared.LocalRM.GetString("AMP_ModifyPlantTypeDialog");
    this.m_PlantFamilyLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_FamilyDialog");
    this.m_PlantNameLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_NameDialog");
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("Sea_AMP_rchDialog");
    this.m_ModifyPlantWidthCheckBox.Text = EPShared.LocalRM.GetString("M_AMP_odifyPlantWidthDialog");
    this.m_PlantWidthLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_WidthDialog");
    this.m_ModifyPlantHeightCheckBox.Text = EPShared.LocalRM.GetString("Mo_AMP_difyPlantWidthDialog");
    this.m_PlantHeightLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_HeightDialog");
    this.m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
    this.m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
    this.m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
    this.m_AllInstancesRadioButton.Text = EPShared.LocalRM.GetString("All_AMP_InstancesDialog");
    this.m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.m_dataBuffer = _dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
    ManagePlants.VerifySharedParameters(this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer);
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_SelectionSetRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsSelectMethodOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_SelectionSetRadioButton.Checked = true;
          break;
        case 1:
          this.m_WindowSelectRadioButton.Checked = true;
          break;
        default:
          this.m_AllInstancesRadioButton.Checked = true;
          break;
      }
    }
    this.m_ModifyPlantTypeCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsModifyPlantType", ref _nReturnValue))
      this.m_ModifyPlantTypeCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ModifyPlantWidthCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsModifyPlantWidth", ref _nReturnValue))
      this.m_ModifyPlantWidthCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsPlantWidth", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
    this.m_PlantWidthTextBox.Text = empty;
    this.m_ModifyPlantHeightCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsModifyPlantHeight", ref _nReturnValue))
      this.m_ModifyPlantHeightCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsPlantHeight", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
    this.m_PlantHeightTextBox.Text = empty;
    this.m_PlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.PlantFamilyList;
    this.m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsFamilyName", ref empty))
    {
      for (int index = 0; index < this.m_PlantFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_PlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty, true) == 0)
        {
          this.m_PlantFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsPlantName", ref empty))
    {
      for (int index = 0; index < this.m_PlantNameComboBox.Items.Count; ++index)
      {
        if (this.m_PlantNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty, true) == 0)
        {
          this.m_PlantNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_ExistingPlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.ExistingPlantFamilyList;
    this.m_ExistingPlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsExistingFamilyName", ref empty))
      this.SetExistingPlantFamilyComboBox(empty);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsExistingPlantName", ref empty))
      return;
    this.SetExistingPlantNameComboBox(empty);
  }

  private void OnPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_PlantNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnExistingPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_ExistingPlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_ExistingPlantNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_ExistingPlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnSearchButtonClick(object sender, EventArgs e)
  {
    if (!(this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    List<FamilySymbol> _SearchSymbolList = new List<FamilySymbol>();
    if (!ManagePlants.FindFamilySymbols(EPShared.LocalRM.GetString("ModifyPlantSearchTitle"), this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer, selectedItem.FamilySymbolList, ref _SearchSymbolList))
      return;
    this.m_PlantNameComboBox.DataSource = (object) _SearchSymbolList;
    this.m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void SaveSettings()
  {
    this.m_CurType = this.m_PlantNameComboBox.SelectedItem as FamilySymbol;
    if (this.m_CurType == null)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsSelectMethodOption", !this.m_SelectionSetRadioButton.Checked ? (!this.m_WindowSelectRadioButton.Checked ? 2 : 1) : 0);
      if (this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem1)
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsFamilyName", selectedItem1.FamilyName);
      ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsModifyPlantType", Convert.ToInt32(this.m_ModifyPlantTypeCheckBox.Checked));
      ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsModifyPlantWidth", Convert.ToInt32(this.m_ModifyPlantWidthCheckBox.Checked));
      double _dReturnedDouble = 0.0;
      if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
        ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsPlantWidth", _dReturnedDouble);
      ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsModifyPlantHeight", Convert.ToInt32(this.m_ModifyPlantHeightCheckBox.Checked));
      if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
        ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsPlantHeight", _dReturnedDouble);
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsPlantName", ((Element) this.m_CurType).Name);
      if (this.m_ExistingPlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem2)
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsExistingFamilyName", selectedItem2.FamilyName);
      this.m_ExistingType = this.m_ExistingPlantNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_ExistingType == null)
        return;
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ModifyPlantsExistingPlantName", ((Element) this.m_ExistingType).Name);
    }
  }

  private void OnModifyPlantTypeCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_PlantFamilyLabel.Enabled = this.m_ModifyPlantTypeCheckBox.Checked;
    this.m_PlantFamilyComboBox.Enabled = this.m_ModifyPlantTypeCheckBox.Checked;
    this.m_PlantNameLabel.Enabled = this.m_ModifyPlantTypeCheckBox.Checked;
    this.m_PlantNameComboBox.Enabled = this.m_ModifyPlantTypeCheckBox.Checked;
    this.m_SearchButton.Enabled = this.m_ModifyPlantTypeCheckBox.Checked;
  }

  private void OnModifyPlantWidthCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_PlantWidthLabel.Enabled = this.m_ModifyPlantWidthCheckBox.Checked;
    this.m_PlantWidthTextBox.Enabled = this.m_ModifyPlantWidthCheckBox.Checked;
  }

  private void OnModifyPlantHeightCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_PlantHeightLabel.Enabled = this.m_ModifyPlantHeightCheckBox.Checked;
    this.m_PlantHeightTextBox.Enabled = this.m_ModifyPlantHeightCheckBox.Checked;
  }

  private void OnPickPlantButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void FormatPlantWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_PlantWidthTextBox.Text = empty;
    }
    else
      this.m_PlantWidthTextBox.Focus();
  }

  private void OnPlantWidthTextBoxLeave(object sender, EventArgs e) => this.FormatPlantWidthValue();

  private void FormatPlantHeightValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_PlantHeightTextBox.Text = empty;
    }
    else
      this.m_PlantHeightTextBox.Focus();
  }

  private void OnPlantHeightTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatPlantHeightValue();
  }

  private void OnPlantWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatPlantWidthValue();
  }

  private void OnPlantHeightTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatPlantHeightValue();
  }

  private void OnApplyButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  public void SetExistingPlantFamilyComboBox(string _strFamilyName)
  {
    for (int index = 0; index < this.m_ExistingPlantFamilyComboBox.Items.Count; ++index)
    {
      if (this.m_ExistingPlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, _strFamilyName, true) == 0)
      {
        this.m_ExistingPlantFamilyComboBox.SelectedIndex = index;
        break;
      }
    }
  }

  public void SetExistingPlantNameComboBox(string _strPlantName)
  {
    for (int index = 0; index < this.m_ExistingPlantNameComboBox.Items.Count; ++index)
    {
      if (this.m_ExistingPlantNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, _strPlantName, true) == 0)
      {
        this.m_ExistingPlantNameComboBox.SelectedIndex = index;
        break;
      }
    }
  }

  private void OnModifyPlantFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_PlantFamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectPlantingFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            this.m_dataBuffer.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_PlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.PlantFamilyList;
        this.m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_PlantFamilyComboBox.Items.Count; ++index)
          {
            if (this.m_PlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_PlantFamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_PlantFamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  public bool SelectionSetChecked => this.m_SelectionSetRadioButton.Checked;

  public bool WindowSelectChecked => this.m_WindowSelectRadioButton.Checked;

  public bool AllInstancesChecked => this.m_AllInstancesRadioButton.Checked;

  public FamilySymbol Type => this.m_CurType;

  public FamilySymbol ExistingType => this.m_ExistingType;

  public bool ModifyPlantTypeChecked => this.m_ModifyPlantTypeCheckBox.Checked;

  public bool ModifyPlantWidthChecked => this.m_ModifyPlantWidthCheckBox.Checked;

  public bool ModifyPlantHeightChecked => this.m_ModifyPlantHeightCheckBox.Checked;

  public double PlantHeight
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_PlantHeightTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_PlantHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double PlantWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_PlantWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_PlantWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ExistingGroupBox = new GroupBox();
    this.m_PickPlantButton = new Button();
    this.m_ExistingPlantNameComboBox = new ComboBox();
    this.m_ExistingPlantNameLabel = new Label();
    this.m_ExistingPlantFamilyComboBox = new ComboBox();
    this.m_ExistingPlantFamilyLabel = new Label();
    this.m_ModifyPlantGroupBox = new GroupBox();
    this.m_LoadFamilyButton = new Button();
    this.m_ModifyPlantTypeCheckBox = new CheckBox();
    this.m_ModifyPlantHeightCheckBox = new CheckBox();
    this.m_ModifyPlantWidthCheckBox = new CheckBox();
    this.m_PlantHeightTextBox = new TextBox();
    this.m_PlantHeightLabel = new Label();
    this.m_PlantWidthTextBox = new TextBox();
    this.m_PlantWidthLabel = new Label();
    this.m_SearchButton = new Button();
    this.m_PlantNameComboBox = new ComboBox();
    this.m_PlantNameLabel = new Label();
    this.m_PlantFamilyComboBox = new ComboBox();
    this.m_PlantFamilyLabel = new Label();
    this.m_AllInstancesRadioButton = new RadioButton();
    this.m_SelectionMethodsGroupBox = new GroupBox();
    this.m_WindowSelectRadioButton = new RadioButton();
    this.m_SelectionSetRadioButton = new RadioButton();
    this.m_ApplyButton = new Button();
    this.m_CancelButton = new Button();
    this.m_ExistingGroupBox.SuspendLayout();
    this.m_ModifyPlantGroupBox.SuspendLayout();
    this.m_SelectionMethodsGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_ExistingGroupBox.Controls.Add((Control) this.m_PickPlantButton);
    this.m_ExistingGroupBox.Controls.Add((Control) this.m_ExistingPlantNameComboBox);
    this.m_ExistingGroupBox.Controls.Add((Control) this.m_ExistingPlantNameLabel);
    this.m_ExistingGroupBox.Controls.Add((Control) this.m_ExistingPlantFamilyComboBox);
    this.m_ExistingGroupBox.Controls.Add((Control) this.m_ExistingPlantFamilyLabel);
    this.m_ExistingGroupBox.Location = new Point(12, 12);
    this.m_ExistingGroupBox.Name = "m_ExistingGroupBox";
    this.m_ExistingGroupBox.Size = new Size(453, 78);
    this.m_ExistingGroupBox.TabIndex = 0;
    this.m_ExistingGroupBox.TabStop = false;
    this.m_ExistingGroupBox.Text = "Existing Plant(s) in Project";
    this.m_PickPlantButton.Location = new Point(372, 44);
    this.m_PickPlantButton.Name = "m_PickPlantButton";
    this.m_PickPlantButton.Size = new Size(75, 23);
    this.m_PickPlantButton.TabIndex = 4;
    this.m_PickPlantButton.Text = "&Pick Plant";
    this.m_PickPlantButton.UseVisualStyleBackColor = true;
    this.m_PickPlantButton.Click += new EventHandler(this.OnPickPlantButtonClick);
    this.m_ExistingPlantNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ExistingPlantNameComboBox.FormattingEnabled = true;
    this.m_ExistingPlantNameComboBox.Location = new Point(124, 46);
    this.m_ExistingPlantNameComboBox.Name = "m_ExistingPlantNameComboBox";
    this.m_ExistingPlantNameComboBox.Size = new Size(242, 21);
    this.m_ExistingPlantNameComboBox.TabIndex = 3;
    this.m_ExistingPlantNameLabel.AutoSize = true;
    this.m_ExistingPlantNameLabel.Location = new Point(6, 50);
    this.m_ExistingPlantNameLabel.Name = "m_ExistingPlantNameLabel";
    this.m_ExistingPlantNameLabel.Size = new Size(65, 13);
    this.m_ExistingPlantNameLabel.TabIndex = 2;
    this.m_ExistingPlantNameLabel.Text = "Plan&t Name:";
    this.m_ExistingPlantFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ExistingPlantFamilyComboBox.FormattingEnabled = true;
    this.m_ExistingPlantFamilyComboBox.Location = new Point(124, 19);
    this.m_ExistingPlantFamilyComboBox.Name = "m_ExistingPlantFamilyComboBox";
    this.m_ExistingPlantFamilyComboBox.Size = new Size(242, 21);
    this.m_ExistingPlantFamilyComboBox.TabIndex = 1;
    this.m_ExistingPlantFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnExistingPlantFamilyComboBoxSelectedIndexChanged);
    this.m_ExistingPlantFamilyLabel.AutoSize = true;
    this.m_ExistingPlantFamilyLabel.Location = new Point(6, 22);
    this.m_ExistingPlantFamilyLabel.Name = "m_ExistingPlantFamilyLabel";
    this.m_ExistingPlantFamilyLabel.Size = new Size(66, 13);
    this.m_ExistingPlantFamilyLabel.TabIndex = 0;
    this.m_ExistingPlantFamilyLabel.Text = "P&lant Family:";
    this.m_ModifyPlantGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_LoadFamilyButton);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_ModifyPlantTypeCheckBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_ModifyPlantHeightCheckBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_ModifyPlantWidthCheckBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantHeightTextBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantHeightLabel);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantWidthTextBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantWidthLabel);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_SearchButton);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantNameComboBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantNameLabel);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantFamilyComboBox);
    this.m_ModifyPlantGroupBox.Controls.Add((Control) this.m_PlantFamilyLabel);
    this.m_ModifyPlantGroupBox.Location = new Point(12, 96 /*0x60*/);
    this.m_ModifyPlantGroupBox.Name = "m_ModifyPlantGroupBox";
    this.m_ModifyPlantGroupBox.Size = new Size(453, 202);
    this.m_ModifyPlantGroupBox.TabIndex = 1;
    this.m_ModifyPlantGroupBox.TabStop = false;
    this.m_ModifyPlantGroupBox.Text = "Modify Plant(s) in Project";
    this.m_LoadFamilyButton.Location = new Point(372, 44);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 3;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_ModifyPlantTypeCheckBox.AutoSize = true;
    this.m_ModifyPlantTypeCheckBox.Location = new Point(7, 20);
    this.m_ModifyPlantTypeCheckBox.Name = "m_ModifyPlantTypeCheckBox";
    this.m_ModifyPlantTypeCheckBox.Size = new Size(111, 17);
    this.m_ModifyPlantTypeCheckBox.TabIndex = 0;
    this.m_ModifyPlantTypeCheckBox.Text = "&Modify Plant Type";
    this.m_ModifyPlantTypeCheckBox.UseVisualStyleBackColor = true;
    this.m_ModifyPlantTypeCheckBox.CheckStateChanged += new EventHandler(this.OnModifyPlantTypeCheckBoxChecked);
    this.m_ModifyPlantHeightCheckBox.AutoSize = true;
    this.m_ModifyPlantHeightCheckBox.Location = new Point(6, 148);
    this.m_ModifyPlantHeightCheckBox.Name = "m_ModifyPlantHeightCheckBox";
    this.m_ModifyPlantHeightCheckBox.Size = new Size(118, 17);
    this.m_ModifyPlantHeightCheckBox.TabIndex = 10;
    this.m_ModifyPlantHeightCheckBox.Text = "Mo&dify Plant Height";
    this.m_ModifyPlantHeightCheckBox.UseVisualStyleBackColor = true;
    this.m_ModifyPlantHeightCheckBox.CheckStateChanged += new EventHandler(this.OnModifyPlantHeightCheckBoxChecked);
    this.m_ModifyPlantWidthCheckBox.AutoSize = true;
    this.m_ModifyPlantWidthCheckBox.Location = new Point(9, 97);
    this.m_ModifyPlantWidthCheckBox.Name = "m_ModifyPlantWidthCheckBox";
    this.m_ModifyPlantWidthCheckBox.Size = new Size(115, 17);
    this.m_ModifyPlantWidthCheckBox.TabIndex = 7;
    this.m_ModifyPlantWidthCheckBox.Text = "M&odify Plant Width";
    this.m_ModifyPlantWidthCheckBox.UseVisualStyleBackColor = true;
    this.m_ModifyPlantWidthCheckBox.CheckStateChanged += new EventHandler(this.OnModifyPlantWidthCheckBoxChecked);
    this.m_PlantHeightTextBox.Enabled = false;
    this.m_PlantHeightTextBox.Location = new Point(124, 167);
    this.m_PlantHeightTextBox.Name = "m_PlantHeightTextBox";
    this.m_PlantHeightTextBox.Size = new Size(100, 20);
    this.m_PlantHeightTextBox.TabIndex = 12;
    this.m_PlantHeightTextBox.KeyDown += new KeyEventHandler(this.OnPlantHeightTextBoxKeyDown);
    this.m_PlantHeightTextBox.Leave += new EventHandler(this.OnPlantHeightTextBoxLeave);
    this.m_PlantHeightLabel.AutoSize = true;
    this.m_PlantHeightLabel.Enabled = false;
    this.m_PlantHeightLabel.Location = new Point(24, 170);
    this.m_PlantHeightLabel.Name = "m_PlantHeightLabel";
    this.m_PlantHeightLabel.Size = new Size(68, 13);
    this.m_PlantHeightLabel.TabIndex = 11;
    this.m_PlantHeightLabel.Text = "Plant &Height:";
    this.m_PlantWidthTextBox.Enabled = false;
    this.m_PlantWidthTextBox.Location = new Point(124, 120);
    this.m_PlantWidthTextBox.Name = "m_PlantWidthTextBox";
    this.m_PlantWidthTextBox.Size = new Size(100, 20);
    this.m_PlantWidthTextBox.TabIndex = 9;
    this.m_PlantWidthTextBox.KeyDown += new KeyEventHandler(this.OnPlantWidthTextBoxKeyDown);
    this.m_PlantWidthTextBox.Leave += new EventHandler(this.OnPlantWidthTextBoxLeave);
    this.m_PlantWidthLabel.AutoSize = true;
    this.m_PlantWidthLabel.Enabled = false;
    this.m_PlantWidthLabel.Location = new Point(24, 123);
    this.m_PlantWidthLabel.Name = "m_PlantWidthLabel";
    this.m_PlantWidthLabel.Size = new Size(65, 13);
    this.m_PlantWidthLabel.TabIndex = 8;
    this.m_PlantWidthLabel.Text = "Plant &Width:";
    this.m_SearchButton.Enabled = false;
    this.m_SearchButton.Location = new Point(372, 69);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(75, 23);
    this.m_SearchButton.TabIndex = 6;
    this.m_SearchButton.Text = "Sea&rch";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButtonClick);
    this.m_PlantNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantNameComboBox.Enabled = false;
    this.m_PlantNameComboBox.FormattingEnabled = true;
    this.m_PlantNameComboBox.Location = new Point(124, 70);
    this.m_PlantNameComboBox.Name = "m_PlantNameComboBox";
    this.m_PlantNameComboBox.Size = new Size(242, 21);
    this.m_PlantNameComboBox.TabIndex = 5;
    this.m_PlantNameLabel.AutoSize = true;
    this.m_PlantNameLabel.Enabled = false;
    this.m_PlantNameLabel.Location = new Point(24, 74);
    this.m_PlantNameLabel.Name = "m_PlantNameLabel";
    this.m_PlantNameLabel.Size = new Size(65, 13);
    this.m_PlantNameLabel.TabIndex = 4;
    this.m_PlantNameLabel.Text = "Plant &Name:";
    this.m_PlantFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantFamilyComboBox.Enabled = false;
    this.m_PlantFamilyComboBox.FormattingEnabled = true;
    this.m_PlantFamilyComboBox.Location = new Point(124, 43);
    this.m_PlantFamilyComboBox.Name = "m_PlantFamilyComboBox";
    this.m_PlantFamilyComboBox.Size = new Size(242, 21);
    this.m_PlantFamilyComboBox.TabIndex = 2;
    this.m_PlantFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnPlantFamilyComboBoxSelectedIndexChanged);
    this.m_PlantFamilyLabel.AutoSize = true;
    this.m_PlantFamilyLabel.Enabled = false;
    this.m_PlantFamilyLabel.Location = new Point(24, 46);
    this.m_PlantFamilyLabel.Name = "m_PlantFamilyLabel";
    this.m_PlantFamilyLabel.Size = new Size(66, 13);
    this.m_PlantFamilyLabel.TabIndex = 1;
    this.m_PlantFamilyLabel.Text = "Plant &Family:";
    this.m_AllInstancesRadioButton.AutoSize = true;
    this.m_AllInstancesRadioButton.Location = new Point(308, 19);
    this.m_AllInstancesRadioButton.Name = "m_AllInstancesRadioButton";
    this.m_AllInstancesRadioButton.Size = new Size(85, 17);
    this.m_AllInstancesRadioButton.TabIndex = 2;
    this.m_AllInstancesRadioButton.TabStop = true;
    this.m_AllInstancesRadioButton.Text = "All &Instances";
    this.m_AllInstancesRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionMethodsGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_AllInstancesRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_WindowSelectRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_SelectionSetRadioButton);
    this.m_SelectionMethodsGroupBox.Location = new Point(12, 304);
    this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
    this.m_SelectionMethodsGroupBox.Size = new Size(453, 43);
    this.m_SelectionMethodsGroupBox.TabIndex = 2;
    this.m_SelectionMethodsGroupBox.TabStop = false;
    this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
    this.m_WindowSelectRadioButton.AutoSize = true;
    this.m_WindowSelectRadioButton.Location = new Point(152, 19);
    this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
    this.m_WindowSelectRadioButton.Size = new Size(97, 17);
    this.m_WindowSelectRadioButton.TabIndex = 1;
    this.m_WindowSelectRadioButton.TabStop = true;
    this.m_WindowSelectRadioButton.Text = "Window S&elect";
    this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionSetRadioButton.AutoSize = true;
    this.m_SelectionSetRadioButton.Location = new Point(6, 19);
    this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
    this.m_SelectionSetRadioButton.Size = new Size(88, 17);
    this.m_SelectionSetRadioButton.TabIndex = 0;
    this.m_SelectionSetRadioButton.TabStop = true;
    this.m_SelectionSetRadioButton.Text = "&Selection Set";
    this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
    this.m_ApplyButton.Location = new Point(309, 353);
    this.m_ApplyButton.Name = "m_ApplyButton";
    this.m_ApplyButton.Size = new Size(75, 23);
    this.m_ApplyButton.TabIndex = 3;
    this.m_ApplyButton.Text = "&Apply";
    this.m_ApplyButton.UseVisualStyleBackColor = true;
    this.m_ApplyButton.Click += new EventHandler(this.OnApplyButtonClick);
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(390, 353);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(477, 388);
    this.Controls.Add((Control) this.m_ApplyButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_SelectionMethodsGroupBox);
    this.Controls.Add((Control) this.m_ModifyPlantGroupBox);
    this.Controls.Add((Control) this.m_ExistingGroupBox);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ModifyPlantForm);
    this.Text = "Modify Plants";
    this.FormClosing += new FormClosingEventHandler(this.OnModifyPlantFormClosing);
    this.m_ExistingGroupBox.ResumeLayout(false);
    this.m_ExistingGroupBox.PerformLayout();
    this.m_ModifyPlantGroupBox.ResumeLayout(false);
    this.m_ModifyPlantGroupBox.PerformLayout();
    this.m_SelectionMethodsGroupBox.ResumeLayout(false);
    this.m_SelectionMethodsGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ApplyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
