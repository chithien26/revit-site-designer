﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.WarningOptionsForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using SITES.Sites_Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class WarningOptionsForm : Form
{
  private string m_strSettingAppName;
  private string m_strSettingName;
  private List<RadioButton> m_WarningOptions;
  private int m_nDefaultOption;
  private bool m_bDisplayDoNotShow;
  private int m_nDoNotShowOptionIndex;
  private bool m_bUseSettingAppName;
  private string m_contextualHelpID = "HID_SDaaa";
  private IContainer components;
  private Button m_OKButton;
  private Button m_CancelButton;
  private CheckBox m_DoNotShowMessageAgainCheckBox;
  private TextBox m_WarningMessageTextBox;

  public WarningOptionsForm(
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions)
  {
    this.SetupForm(EPShared.LocalRM.GetString("WarningDialog"), string.Empty, _strSettingName, _strWarningText, _WarningOptions, -1, true, true, -1, false);
  }

  public WarningOptionsForm(
    string _strSettingAppName,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions)
  {
    this.SetupForm(EPShared.LocalRM.GetString("WarningDialog"), _strSettingAppName, _strSettingName, _strWarningText, _WarningOptions, -1, true, true, -1, true);
  }

  public WarningOptionsForm(
    string _strSettingAppName,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions,
    int _nDefaultOption)
  {
    this.SetupForm(EPShared.LocalRM.GetString("WarningDialog"), _strSettingAppName, _strSettingName, _strWarningText, _WarningOptions, _nDefaultOption, true, true, -1, true);
  }

  public WarningOptionsForm(
    string _strFormTitle,
    string _strSettingAppName,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions,
    int _nDefaultOption,
    bool _bDisplayOKCancel)
  {
    this.SetupForm(_strFormTitle, _strSettingAppName, _strSettingName, _strWarningText, _WarningOptions, _nDefaultOption, _bDisplayOKCancel, true, -1, true);
  }

  public WarningOptionsForm(
    string _strFormTitle,
    string _strSettingAppName,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions,
    int _nDefaultOption,
    bool _bDisplayOKCancel,
    bool _bDisplayDoNotShow)
  {
    this.SetupForm(_strFormTitle, _strSettingAppName, _strSettingName, _strWarningText, _WarningOptions, _nDefaultOption, _bDisplayOKCancel, _bDisplayDoNotShow, -1, true);
  }

  public WarningOptionsForm(
    string _strFormTitle,
    string _strSettingAppName,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions,
    int _nDefaultOption,
    bool _bDisplayOKCancel,
    bool _bDisplayDoNotShow,
    int _nDoNotShowOptionIndex)
  {
    this.SetupForm(_strFormTitle, _strSettingAppName, _strSettingName, _strWarningText, _WarningOptions, _nDefaultOption, _bDisplayOKCancel, _bDisplayDoNotShow, _nDoNotShowOptionIndex, true);
  }

  public WarningOptionsForm(
    string _strFormTitle,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions,
    int _nDefaultOption,
    bool _bDisplayOKCancel,
    bool _bDisplayDoNotShow,
    int _nDoNotShowOptionIndex)
  {
    this.SetupForm(_strFormTitle, string.Empty, _strSettingName, _strWarningText, _WarningOptions, _nDefaultOption, _bDisplayOKCancel, _bDisplayDoNotShow, _nDoNotShowOptionIndex, false);
  }

  private void SetupForm(
    string _strFormTitle,
    string _strSettingAppName,
    string _strSettingName,
    string _strWarningText,
    List<string> _WarningOptions,
    int _nDefaultOption,
    bool _bDisplayOKCancel,
    bool _bDisplayDoNotShow,
    int _nDoNotShowOptionIndex,
    bool _bUseSettingAppName)
  {
    this.InitializeComponent();
    if (string.Compare(_strWarningText, EPShared.LocalRM.GetString("PickViewOptionForMassMessage"), true) == 0)
      this.m_contextualHelpID = "HID_SDshowMassMode";
    if (string.Compare(_strWarningText, EPShared.LocalRM.GetString("SoftTerrainFamilyNotLoadedMessage"), true) == 0 || string.Compare(_strWarningText, EPShared.LocalRM.GetString("SideWalkFamilyNotLoadedMessage"), true) == 0 || string.Compare(_strWarningText, EPShared.LocalRM.GetString("RetainingWallFamilyNotLoadedMessage"), true) == 0 || string.Compare(_strWarningText, EPShared.LocalRM.GetString("StreetFamilyNotLoadedMessage"), true) == 0 || string.Compare(_strWarningText, EPShared.LocalRM.GetString("CurbFamilyNotLoadedMessage"), true) == 0 || string.Compare(_strWarningText, EPShared.LocalRM.GetString("ParkingLotFamilyNotLoadedMessage"), true) == 0)
      this.m_contextualHelpID = "HID_SDnoFamilyLoaded";
    this.Text = _strFormTitle;
    if (ApplicationUtility.StringTable != null)
      this.m_DoNotShowMessageAgainCheckBox.Text = EPShared.LocalRM.GetString("AMP_DoNotShowMessageDialog");
    if (_bDisplayOKCancel)
    {
      if (ApplicationUtility.StringTable != null)
      {
        this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
        this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
      }
    }
    else
    {
      if (ApplicationUtility.StringTable != null)
        this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
      this.m_CancelButton.Visible = false;
    }
    this.m_WarningMessageTextBox.Text = _strWarningText;
    this.m_strSettingAppName = _strSettingAppName;
    this.m_strSettingName = _strSettingName;
    this.m_nDefaultOption = _nDefaultOption;
    this.m_bDisplayDoNotShow = _bDisplayDoNotShow;
    this.m_nDoNotShowOptionIndex = _nDoNotShowOptionIndex;
    this.m_bUseSettingAppName = _bUseSettingAppName;
    this.m_WarningOptions = new List<RadioButton>();
    Point location1 = this.m_DoNotShowMessageAgainCheckBox.Location;
    int num1 = 0;
    int num2 = 0;
    int index;
    Size size1;
    for (index = 0; index < _WarningOptions.Count; ++index)
    {
      RadioButton radioButton = new RadioButton();
      radioButton.AutoSize = true;
      radioButton.Location = location1;
      radioButton.Name = "m_WarningOptions" + index.ToString();
      radioButton.Size = new Size(60, 17);
      radioButton.TabIndex = this.m_DoNotShowMessageAgainCheckBox.TabIndex + index;
      radioButton.TabStop = true;
      radioButton.Text = _WarningOptions[index];
      radioButton.UseVisualStyleBackColor = true;
      this.Controls.Add((Control) radioButton);
      this.m_WarningOptions.Add(radioButton);
      num2 += 23;
      location1.Y += 23;
      size1 = radioButton.Size;
      if (size1.Width > num1)
      {
        size1 = radioButton.Size;
        num1 = size1.Width;
      }
    }
    int num3 = num1;
    size1 = this.Size;
    int num4 = size1.Width + 24;
    if (num3 > num4)
    {
      int width1 = num1 + 24;
      size1 = this.Size;
      int height1 = size1.Height;
      this.Size = new Size(width1, height1);
      TextBox warningMessageTextBox = this.m_WarningMessageTextBox;
      int width2 = num1;
      size1 = this.m_WarningMessageTextBox.Size;
      int height2 = size1.Height;
      Size size2 = new Size(width2, height2);
      warningMessageTextBox.Size = size2;
    }
    if (this.m_nDefaultOption >= 0 && this.m_nDefaultOption < this.m_WarningOptions.Count)
      this.m_WarningOptions[this.m_nDefaultOption].Checked = true;
    if (_bDisplayDoNotShow)
    {
      this.m_DoNotShowMessageAgainCheckBox.TabIndex += index;
      this.m_DoNotShowMessageAgainCheckBox.Location = location1;
    }
    else
    {
      this.m_DoNotShowMessageAgainCheckBox.Visible = false;
      --index;
    }
    Point point = !_bDisplayOKCancel ? this.m_CancelButton.Location : this.m_OKButton.Location;
    point.Y += num2;
    this.m_OKButton.TabIndex += index;
    this.m_OKButton.Location = point;
    Point location2 = this.m_CancelButton.Location;
    location2.Y += num2;
    this.m_CancelButton.TabIndex += index;
    this.m_CancelButton.Location = location2;
    Size size3 = this.Size;
    size3.Height += num2;
    this.Size = size3;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    bool flag = false;
    if ((this.m_bUseSettingAppName && ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingAppName, this.m_strSettingName + "WarningOption", ref _nReturnValue) || !this.m_bUseSettingAppName && ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingName + "WarningOption", ref _nReturnValue)) && _nReturnValue >= 0 && _nReturnValue < this.m_WarningOptions.Count)
    {
      this.m_WarningOptions[_nReturnValue].Checked = true;
      if (this.m_nDoNotShowOptionIndex == _nReturnValue)
        flag = true;
    }
    if (!this.m_bDisplayDoNotShow && !flag)
      return;
    this.m_DoNotShowMessageAgainCheckBox.Checked = false;
    if ((!this.m_bUseSettingAppName || !ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingAppName, this.m_strSettingName + "DoNotShowAgainOption", ref _nReturnValue)) && (this.m_bUseSettingAppName || !ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingName + "DoNotShowAgainOption", ref _nReturnValue)))
      return;
    this.m_DoNotShowMessageAgainCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
  }

  private void SaveSettings()
  {
    bool flag = false;
    for (int index = 0; index < this.m_WarningOptions.Count; ++index)
    {
      if (this.m_WarningOptions[index].Checked)
      {
        if (this.m_nDoNotShowOptionIndex != -1 || this.m_bUseSettingAppName)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingAppName, this.m_strSettingName + "WarningOption", index);
        else
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingName + "WarningOption", index);
        if (this.m_nDoNotShowOptionIndex == index)
        {
          flag = true;
          break;
        }
        break;
      }
    }
    if (this.m_bDisplayDoNotShow)
    {
      if (this.m_bUseSettingAppName)
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingAppName, this.m_strSettingName + "DoNotShowAgainOption", Convert.ToInt32(this.m_DoNotShowMessageAgainCheckBox.Checked));
      else
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingName + "DoNotShowAgainOption", Convert.ToInt32(this.m_DoNotShowMessageAgainCheckBox.Checked));
    }
    else
    {
      if (!flag)
        return;
      if (this.m_bUseSettingAppName)
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingAppName, this.m_strSettingName + "DoNotShowAgainOption", 1);
      else
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingName + "DoNotShowAgainOption", 1);
    }
  }

  private void ivokeHelp() => RevitUtility.ShowHelpInRevit(this.m_contextualHelpID);

  private void OnHelpButtonClicked(object sender, CancelEventArgs e)
  {
    e.Cancel = true;
    this.ivokeHelp();
  }

  private void WarningOptionsForm_HelpRequested(object sender, HelpEventArgs hlpevent)
  {
    this.ivokeHelp();
    hlpevent.Handled = true;
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnWarningOptionsFormLoad(object sender, EventArgs e)
  {
    this.m_OKButton.Focus();
    if (!this.m_DoNotShowMessageAgainCheckBox.Checked)
      return;
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  public void SetDoNotShowOptionIndex(int _nIndex) => this.m_nDoNotShowOptionIndex = _nIndex;

  public string WarningOption
  {
    get
    {
      for (int index = 0; index < this.m_WarningOptions.Count; ++index)
      {
        if (this.m_WarningOptions[index].Checked)
          return this.m_WarningOptions[index].Text;
      }
      return string.Empty;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_DoNotShowMessageAgainCheckBox = new CheckBox();
    this.m_WarningMessageTextBox = new TextBox();
    this.SuspendLayout();
    this.m_OKButton.Location = new Point(180, 91);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 2;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(261, 91);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 3;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_DoNotShowMessageAgainCheckBox.AutoSize = true;
    this.m_DoNotShowMessageAgainCheckBox.Location = new Point(12, 69);
    this.m_DoNotShowMessageAgainCheckBox.Name = "m_DoNotShowMessageAgainCheckBox";
    this.m_DoNotShowMessageAgainCheckBox.Size = new Size(160 /*0xA0*/, 17);
    this.m_DoNotShowMessageAgainCheckBox.TabIndex = 1;
    this.m_DoNotShowMessageAgainCheckBox.Text = "&Do not show message again";
    this.m_DoNotShowMessageAgainCheckBox.UseVisualStyleBackColor = true;
    this.m_WarningMessageTextBox.BackColor = SystemColors.Control;
    this.m_WarningMessageTextBox.BorderStyle = BorderStyle.None;
    this.m_WarningMessageTextBox.Location = new Point(12, 12);
    this.m_WarningMessageTextBox.Multiline = true;
    this.m_WarningMessageTextBox.Name = "m_WarningMessageTextBox";
    this.m_WarningMessageTextBox.Size = new Size(324, 51);
    this.m_WarningMessageTextBox.TabIndex = 0;
    this.m_WarningMessageTextBox.TabStop = false;
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
    this.ClientSize = new Size(349, (int) sbyte.MaxValue);
    this.Controls.Add((Control) this.m_WarningMessageTextBox);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_DoNotShowMessageAgainCheckBox);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = Resources.Siteworks;
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = nameof (WarningOptionsForm);
    this.ShowInTaskbar = false;
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = nameof (WarningOptionsForm);
    this.HelpButtonClicked += new CancelEventHandler(this.OnHelpButtonClicked);
    this.Load += new EventHandler(this.OnWarningOptionsFormLoad);
    this.HelpRequested += new HelpEventHandler(this.WarningOptionsForm_HelpRequested);
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
