﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RevitMessageBox
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.UI;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class RevitMessageBox
{
  public static DialogResult Show(string _strText, string _strCaption)
  {
    return RevitMessageBox.Show(_strText, _strCaption, MessageBoxIcon.None);
  }

  public static DialogResult Show(string _strText, string _strCaption, MessageBoxIcon _Icon)
  {
    return RevitMessageBox.Show(_strText, _strCaption, MessageBoxButtons.OK, _Icon);
  }

  public static DialogResult Show(
    string _strText,
    string _strCaption,
    MessageBoxButtons _Buttons,
    MessageBoxIcon _Icon)
  {
    TaskDialogCommonButtons dialogCommonButtons = (TaskDialogCommonButtons) 0;
    TaskDialogResult taskDialogResult1 = (TaskDialogResult) 0;
    switch (_Buttons)
    {
      case MessageBoxButtons.OK:
        taskDialogResult1 = (TaskDialogResult) 1;
        dialogCommonButtons = (TaskDialogCommonButtons) 1;
        break;
      case MessageBoxButtons.OKCancel:
        taskDialogResult1 = (TaskDialogResult) 1;
        dialogCommonButtons = (TaskDialogCommonButtons) 9;
        break;
      case MessageBoxButtons.AbortRetryIgnore:
        return RevitMessageBox.MessageBoxShow(_strText, _strCaption, _Buttons, _Icon);
      case MessageBoxButtons.YesNoCancel:
        taskDialogResult1 = (TaskDialogResult) 6;
        dialogCommonButtons = (TaskDialogCommonButtons) 14;
        break;
      case MessageBoxButtons.YesNo:
        taskDialogResult1 = (TaskDialogResult) 6;
        dialogCommonButtons = (TaskDialogCommonButtons) 6;
        break;
      case MessageBoxButtons.RetryCancel:
        taskDialogResult1 = (TaskDialogResult) 4;
        dialogCommonButtons = (TaskDialogCommonButtons) 24;
        break;
    }
    TaskDialogIcon taskDialogIcon = (TaskDialogIcon) 0;
    if (_Icon == MessageBoxIcon.Hand || _Icon == MessageBoxIcon.Exclamation || _Icon == MessageBoxIcon.Asterisk)
      taskDialogIcon = (TaskDialogIcon) (int) ushort.MaxValue;
    TaskDialogResult taskDialogResult2 = new TaskDialog(_strCaption)
    {
      MainIcon = taskDialogIcon,
      MainInstruction = _strText,
      AllowCancellation = true,
      TitleAutoPrefix = false,
      CommonButtons = dialogCommonButtons,
      DefaultButton = taskDialogResult1
    }.Show();
    DialogResult dialogResult = DialogResult.None;
    switch (taskDialogResult2 - 1)
    {
      case 0:
        dialogResult = DialogResult.OK;
        break;
      case 1:
        dialogResult = DialogResult.Cancel;
        break;
      case 3:
        dialogResult = DialogResult.Retry;
        break;
      case 5:
        dialogResult = DialogResult.Yes;
        break;
      case 6:
        dialogResult = DialogResult.No;
        break;
    }
    return dialogResult;
  }

  private static DialogResult MessageBoxShow(
    string _strText,
    string _strCaption,
    MessageBoxButtons _Buttons,
    MessageBoxIcon _Icon)
  {
    return ApplicationUtility.RevitWindowWrapper != null ? MessageBox.Show((IWin32Window) ApplicationUtility.RevitWindowWrapper, _strText, _strCaption, _Buttons, _Icon) : MessageBox.Show(_strText, _strCaption, _Buttons, _Icon);
  }
}
