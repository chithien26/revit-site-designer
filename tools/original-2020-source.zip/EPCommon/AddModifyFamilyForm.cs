﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.AddModifyFamilyForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Sites_Core;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class AddModifyFamilyForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private DisplayUnit m_DisplayUnitSystem;
  private FormatOptions m_FormatOptions;
  private FormatOptions m_SlopeFormatOptions;
  private FormatOptions m_AngularOptions;
  private UnitSymbolType m_UnitSymbolType;
  private UnitSymbolType m_SlopeUnitSymbolType;
  private UnitSymbolType m_AngularSymbolType;
  private List<FamilyTypeContainer> m_FamilyTypeContainerList;
  private int m_nSeletedIndex = -1;
  private List<FamilyParameterTypeWrapper> m_ParameterList;
  private QuantumListView m_ParameterListView;
  private LandcaddID m_FamilyType = LandcaddID.Street;
  private List<Material> m_AllMaterialList = new List<Material>();
  private QuantumListView m_GlobalListView;
  private bool m_bPreview = true;
  private PictureBox m_PreviewBox;
  private string m_strLinearIncrement = "5";
  private string m_strCircularIncrement;
  private string m_strFamilyName = string.Empty;
  private List<string> m_SlopeDisplayUnits = new List<string>();
  private List<DisplayUnitType> m_SlopeUnits = new List<DisplayUnitType>();
  private DisplayUnitType m_CurrentSlopeDisplayUnitType;
  private DisplayUnitType m_PreviousSlopeDisplayUnitType;
  private DecimalSymbol m_DecimalSymbolType;
  private double m_dAngularRounding;
  private double m_dCurrentSlopeAccuracy;
  private AddModifyFamilyForm.FormForAddOrModify m_AddOrModify;
  private IContainer components;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;
  private Label m_UnitLabel;
  private TabControl m_StreetTabControl;
  private ComboBox m_SlopeComboBox;

  public AddModifyFamilyForm(
    List<FamilyParameterTypeWrapper> _ParameterList,
    ref List<FamilyTypeContainer> _FamilyTypeContainerList,
    Units _Units,
    DisplayUnit _UnitType,
    FormatOptions _FormatOption,
    UnitSymbolType _UnitSymbolType,
    FormatOptions _SlopeFormatOption,
    UnitSymbolType _SlopeUnitSymbolType,
    FormatOptions _AngleFormatOption,
    UnitSymbolType _AngleUnitSymbolType,
    DecimalSymbol _DecimalSymbolType,
    int _nSelectedIndex,
    LandcaddID _LandCaddID,
    string _strFamilyName)
  {
    this.InitializeComponent();
    this.m_ParameterList = new List<FamilyParameterTypeWrapper>((IEnumerable<FamilyParameterTypeWrapper>) _ParameterList);
    int index1 = this.m_ParameterList.FindIndex(new Predicate<FamilyParameterTypeWrapper>(AddModifyFamilyForm.FindSiteworksIDParameterInList));
    if (index1 > -1)
      this.m_ParameterList.RemoveAt(index1);
    int index2 = this.m_ParameterList.FindIndex(new Predicate<FamilyParameterTypeWrapper>(AddModifyFamilyForm.FindSideWalkLocationLineParameterInList));
    if (index2 > -1)
      this.m_ParameterList.RemoveAt(index2);
    this.m_FamilyTypeContainerList = _FamilyTypeContainerList;
    this.m_Units = _Units;
    this.m_DisplayUnitSystem = _UnitType;
    this.m_FormatOptions = _FormatOption;
    this.m_UnitSymbolType = _UnitSymbolType;
    this.m_SlopeFormatOptions = _SlopeFormatOption;
    this.m_SlopeUnitSymbolType = _SlopeUnitSymbolType;
    this.m_nSeletedIndex = _nSelectedIndex;
    this.m_FamilyType = _LandCaddID;
    this.m_AngularOptions = _AngleFormatOption;
    this.m_AngularSymbolType = _AngleUnitSymbolType;
    this.m_DecimalSymbolType = _DecimalSymbolType;
    this.m_strFamilyName = _strFamilyName;
    try
    {
      this.m_dAngularRounding = this.m_AngularOptions.Accuracy;
    }
    catch (InvalidOperationException ex)
    {
      this.m_dAngularRounding = 1.0;
    }
    this.m_strCircularIncrement = ValueConversion.ToString(Math.PI / 20.0);
    this.m_ParameterListView.TabIndex = 0;
    this.m_ButtonOk.TabIndex = 1;
    this.m_ButtonCancel.TabIndex = 2;
    this.InitializeData();
    this.GetDialogPosition();
    if (this.m_FamilyType != LandcaddID.Street)
      this.m_ParameterListView.OnListViewItemChanged += new ListViewItemChanged(this.ParameterListViewOnListViewItemChanged);
    this.FormClosing += new FormClosingEventHandler(this.AddModifyFamilyFormClosing);
    this.ResizeBegin += new EventHandler(this.FormResizeBegin);
  }

  public AddModifyFamilyForm(
    List<FamilyParameterTypeWrapper> _ParameterList,
    ref List<FamilyTypeContainer> _FamilyTypeContainerList,
    Units _Units,
    DisplayUnit _UnitType,
    FormatOptions _FormatOption,
    UnitSymbolType _UnitSymbolType,
    FormatOptions _SlopeFormatOption,
    UnitSymbolType _SlopeUnitSymbolType,
    FormatOptions _AngleFormatOption,
    UnitSymbolType _AngleUnitSymbolType,
    List<Material> _MaterialList,
    DecimalSymbol _DecimalSymbolType,
    int _nSelectedIndex,
    LandcaddID _LandCaddID,
    string _strFamilyName)
  {
    this.InitializeComponent();
    this.m_ParameterList = new List<FamilyParameterTypeWrapper>((IEnumerable<FamilyParameterTypeWrapper>) _ParameterList);
    int index1 = this.m_ParameterList.FindIndex(new Predicate<FamilyParameterTypeWrapper>(AddModifyFamilyForm.FindSiteworksIDParameterInList));
    if (index1 > -1)
      this.m_ParameterList.RemoveAt(index1);
    int index2 = this.m_ParameterList.FindIndex(new Predicate<FamilyParameterTypeWrapper>(AddModifyFamilyForm.FindSideWalkLocationLineParameterInList));
    if (index2 > -1)
      this.m_ParameterList.RemoveAt(index2);
    this.m_FamilyTypeContainerList = _FamilyTypeContainerList;
    this.m_Units = _Units;
    this.m_DisplayUnitSystem = _UnitType;
    this.m_FormatOptions = _FormatOption;
    this.m_UnitSymbolType = _UnitSymbolType;
    this.m_SlopeFormatOptions = _SlopeFormatOption;
    this.m_SlopeUnitSymbolType = _SlopeUnitSymbolType;
    this.m_nSeletedIndex = _nSelectedIndex;
    this.m_FamilyType = _LandCaddID;
    this.m_AllMaterialList = _MaterialList;
    this.m_AngularOptions = _AngleFormatOption;
    this.m_AngularSymbolType = _AngleUnitSymbolType;
    this.m_DecimalSymbolType = _DecimalSymbolType;
    this.m_strFamilyName = _strFamilyName;
    try
    {
      this.m_dAngularRounding = this.m_AngularOptions.Accuracy;
    }
    catch (InvalidOperationException ex)
    {
      this.m_dAngularRounding = 1.0;
    }
    this.m_strCircularIncrement = ValueConversion.ToString(Math.PI / 20.0);
    this.InitializeData();
    this.GetDialogPosition();
    if (this.m_FamilyType != LandcaddID.Street)
      this.m_ParameterListView.OnListViewItemChanged += new ListViewItemChanged(this.ParameterListViewOnListViewItemChanged);
    this.FormClosing += new FormClosingEventHandler(this.AddModifyFamilyFormClosing);
    this.ResizeBegin += new EventHandler(this.FormResizeBegin);
  }

  private static bool FindSiteworksIDParameterInList(FamilyParameterTypeWrapper _FindParameter)
  {
    return string.Compare(_FindParameter.ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0;
  }

  private static bool FindSideWalkLocationLineParameterInList(
    FamilyParameterTypeWrapper _FindParameter)
  {
    return string.Compare(_FindParameter.ParameterName, RevitParameters.SideWalkLocationLineParameter, true) == 0;
  }

  private void AddModifyFamilyFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void FormResizeBegin(object sender, EventArgs e)
  {
    if (this.m_ParameterListView == null)
      return;
    this.m_ParameterListView.SetAnchor();
  }

  private void ParameterListViewOnListViewItemChanged(int _nChangedIndex)
  {
    if (this.HandleSlopes(_nChangedIndex))
      return;
    switch (this.m_FamilyType)
    {
      case LandcaddID.PlantMix:
      case LandcaddID.PatioWalk:
        this.HandlePlantMixPatio(_nChangedIndex);
        break;
      case LandcaddID.SoftTerrain:
        this.HandleSoftTerrain(_nChangedIndex);
        break;
      case LandcaddID.Street:
        this.HandleStreet(_nChangedIndex);
        break;
      case LandcaddID.Curb:
        this.HandleCurb(_nChangedIndex);
        break;
      case LandcaddID.Sidewalk:
        this.HandleSideWalk(_nChangedIndex);
        break;
      case LandcaddID.RetainingWall:
        this.HandleRetainingWall(_nChangedIndex);
        break;
      case LandcaddID.Steps:
        this.HandleSteps(_nChangedIndex);
        break;
      case LandcaddID.ParkingLot:
        this.HandleParkingLots(_nChangedIndex);
        break;
    }
  }

  private bool HandleSlopes(int _nChangedIndex)
  {
    bool flag = false;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(text1, EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("SideWalkCutSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("SideWalkFillSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("RetainingWallCutSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("RetainingWallFillSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("StreetCutSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("StreetFillSlopeParameter"), true) == 0)
    {
      try
      {
        double _dReturnedDouble = 0.0;
        string _strInput = text2.Trim(new char[32 /*0x20*/]);
        string _strToDisplay = _strInput;
        if (RevitGeometry.Units_ConvertStringToDouble(_strInput, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
        {
          if (_dReturnedDouble < 0.0001)
          {
            RevitGeometry.Units_ConvertDoubleToString(0.0001, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, (UnitSymbolType) 0, this.m_Units, ref _strToDisplay);
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidCutFillSlopeValue") + _strToDisplay, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            _dReturnedDouble = 0.0001;
          }
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, (UnitSymbolType) 0, this.m_Units, ref _strToDisplay);
        }
        string str = this.AppendSlopeSymbol(_strToDisplay);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = str;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSlopeValue"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
      flag = true;
    }
    else if (string.Compare(text1, EPShared.LocalRM.GetString("StreetGutterSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("StreetCrossSlopeParameter"), true) == 0 || string.Compare(text1, EPShared.LocalRM.GetString("CurbGutterSlopeParameter"), true) == 0)
    {
      try
      {
        double _dReturnedDouble = 0.0;
        string _strInput = text2.Trim(new char[32 /*0x20*/]);
        string _strToDisplay = _strInput;
        if (RevitGeometry.Units_ConvertStringToDouble(_strInput, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, (UnitSymbolType) 0, this.m_Units, ref _strToDisplay);
        string str = this.AppendSlopeSymbol(_strToDisplay);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = str;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSlopeValue"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
      flag = true;
    }
    return flag;
  }

  private string AppendSlopeSymbol(string _strParameterValue)
  {
    if (this.m_SlopeUnitSymbolType == null)
      return _strParameterValue;
    string str = string.Empty;
    DisplayUnitType slopeDisplayUnitType = this.m_CurrentSlopeDisplayUnitType;
    if (slopeDisplayUnitType != 19)
    {
      switch (slopeDisplayUnitType - 158)
      {
        case 0:
          str = ":10";
          break;
        case 1:
          str = ":12";
          break;
        case 2:
          str = "°";
          break;
        case 3:
          str = "/ 12\"";
          break;
        case 4:
          str = "/ 1' - 0\"";
          break;
        case 5:
          str = "/ 1000";
          break;
      }
    }
    else
      str = "%";
    if (_strParameterValue.IndexOf(":12") > 0 || _strParameterValue.IndexOf(":10") > 0 || _strParameterValue.IndexOf("/ 12\"") > 0 || _strParameterValue.IndexOf("/ 1' - 0\"") > 0 || _strParameterValue.IndexOf("/ 1000") > 0 || _strParameterValue.IndexOf("°") > 0 || _strParameterValue.IndexOf("%") > 0)
      return _strParameterValue;
    _strParameterValue += str;
    return _strParameterValue;
  }

  private void HandleStreet(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
    {
      if (!this.CheckForSpecialCharacter(text2))
        return;
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
      this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
      this.m_ParameterListView.SetFocus(_nChangedIndex);
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetNumberOfLanesParameter"), text1, true) == 0)
    {
      try
      {
        if (Convert.ToInt32(text2) > 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidNumberOfLanesMessage"), EPShared.LocalRM.GetString("Error"));
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidNumberOfLanesMessage"), EPShared.LocalRM.GetString("Error"));
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetLaneWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        if (_dReturnedDouble2 < 1.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetLaneWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetPavementDepthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (RevitDefines.LT(_dReturnedDouble3, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetPavementDepthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetBaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble4 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
        if (_dReturnedDouble4 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetBaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble4 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble5 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble5);
        if (_dReturnedDouble5 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble5 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetGutterWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble6 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble6);
        if (RevitDefines.LT(_dReturnedDouble6, 0.0833333))
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetGutterWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble6, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble7 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble7);
        if (_dReturnedDouble7 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetCurbOffsetParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble7, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetCurbWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble8 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble8);
        if (RevitDefines.LT(_dReturnedDouble8, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetCurbWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble8, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetCurbHeightParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble9 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble9);
        if (RevitDefines.LT(_dReturnedDouble9, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetCurbHeightParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble9, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetBoulevardWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble10 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble10);
        if (_dReturnedDouble10 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetBoulevardWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble10, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StreetCurbMaterialParameter"), text1, true) == 0)
        return;
      if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
      {
        try
        {
          if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          }
          else if (_dReturnedDouble1 >= 0.0)
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
          else
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
      {
        try
        {
          double _dReturnedDouble11 = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble11);
          if (RevitDefines.LT(_dReturnedDouble11, 0.0833333))
          {
            string empty = string.Empty;
            RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
            int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
          }
          else
          {
            RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble11, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          }
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else
      {
        if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
          return;
        try
        {
          double num1 = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
          if (RevitDefines.LT(num1, Math.PI / 180.0))
          {
            int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            num1 = Math.PI / 20.0;
          }
          RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, num1, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
    }
  }

  private void HandleSoftTerrain(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
    {
      if (!this.CheckForSpecialCharacter(text2))
        return;
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
      this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
      this.m_ParameterListView.SetFocus(_nChangedIndex);
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"), text1, true) == 0)
    {
      string _strInput = text2.Trim(new char[32 /*0x20*/]);
      string _strToDisplay = _strInput;
      if (RevitGeometry.Units_ConvertStringToDouble(_strInput, this.m_Units, (UnitType) 59, ref _dReturnedDouble1))
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble1, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref _strToDisplay);
      string str = _strToDisplay;
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = str;
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainLeftOffsetWidthParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SoftTerrainRightOffsetWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        if (_dReturnedDouble2 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidOffsetMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
        else if (_dReturnedDouble1 >= 0.0)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
        else
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (RevitDefines.LT(_dReturnedDouble3, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
        return;
      try
      {
        double num1 = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
        if (RevitDefines.LT(num1, Math.PI / 180.0))
        {
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          num1 = Math.PI / 20.0;
        }
        RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, num1, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void HandlePlantMixPatio(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (this.m_FamilyType == LandcaddID.PlantMix)
    {
      if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
      {
        if (!this.CheckForSpecialCharacter(text2))
          return;
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
      else
      {
        if (string.Compare(EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("PlantSizePlantMixFamilyParameter"), text1, true) == 0)
          return;
        if (string.Compare(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), text1, true) == 0)
        {
          if (string.Compare(text2, EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"), true) == 0)
          {
            this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text = EPShared.LocalRM.GetString("NotAvailableString");
          }
          else
          {
            if (string.Compare(this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0 && !(this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text == string.Empty))
              return;
            string empty = string.Empty;
            RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
            this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text = empty;
          }
        }
        else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
        {
          try
          {
            if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
            }
            else if (_dReturnedDouble1 >= 0.0)
              this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
            else
              this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
          }
          catch (Exception ex)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
          }
        }
        else if (string.Compare(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), text1, true) == 0)
        {
          try
          {
            if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1) || _dReturnedDouble1 <= 0.0 || _dReturnedDouble1 > 100.0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = "1";
            }
            else
              this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          }
          catch (Exception ex)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage") + EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
          }
        }
        else
        {
          if (string.Compare(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), text1, true) != 0)
            return;
          try
          {
            double _dReturnedDouble2 = 0.0;
            RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
            RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          }
          catch (Exception ex)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
          }
        }
      }
    }
    else
    {
      if (this.m_FamilyType != LandcaddID.PatioWalk)
        return;
      if (string.Compare(EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), text1, true) == 0)
      {
        try
        {
          double _dReturnedDouble3 = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else
      {
        if (string.Compare(EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), text1, true) != 0)
          return;
        try
        {
          double _dReturnedDouble4 = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
          if (_dReturnedDouble4 < 3.0)
          {
            RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          }
          else
          {
            RevitGeometry.Units_ConvertDoubleToString(3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
            int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("ValidEdgeWidth")} {text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
          }
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
    }
  }

  private void HandleCurb(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("CurbTypeManagerString"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("CurbMaterialParameter"), text1, true) == 0)
      return;
    if (string.Compare(EPShared.LocalRM.GetString("StreetCurbHeightParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        if (RevitDefines.LT(_dReturnedDouble2, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetCurbHeightParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CurbGutterHeightParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (RevitDefines.LT(_dReturnedDouble3, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("CurbGutterHeightParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CurbBaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble4 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
        if (_dReturnedDouble4 < 0.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("CurbBaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble4 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CurbSubbaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble5 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble5);
        if (_dReturnedDouble5 < 0.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("CurbSubbaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble5 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble6 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble6);
        if (_dReturnedDouble6 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetCurbOffsetParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble6, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetCurbWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble7 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble7);
        if (RevitDefines.LT(_dReturnedDouble7, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetCurbWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble7, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StreetGutterWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble8 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble8);
        if (_dReturnedDouble8 < 0.0)
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetGutterWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble8, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
        else if (_dReturnedDouble1 >= 0.0)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
        else
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble9 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble9);
        if (RevitDefines.LT(_dReturnedDouble9, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble9, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
        return;
      try
      {
        double num1 = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
        if (RevitDefines.LT(num1, Math.PI / 180.0))
        {
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          num1 = Math.PI / 20.0;
        }
        RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, num1, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void HandleSideWalk(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
    {
      if (!this.CheckForSpecialCharacter(text2))
        return;
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
      this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
      this.m_ParameterListView.SetFocus(_nChangedIndex);
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SideWalkPavementDepthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        if (RevitDefines.LT(_dReturnedDouble2, 0.0833333))
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("SideWalkPavementDepthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble2 = 0.0833333;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SideWalkBaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (_dReturnedDouble3 < 0.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("SideWalkBaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble3 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SideWalkSubbaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble4 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
        if (_dReturnedDouble4 < 0.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("SideWalkSubbaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble4 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SideWalkWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble5 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble5);
        if (RevitDefines.LT(_dReturnedDouble5, 0.0833333))
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("SideWalkWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble5 = 0.0833333;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
        else if (_dReturnedDouble1 >= 0.0)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
        else
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble6 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble6);
        if (RevitDefines.LT(_dReturnedDouble6, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble6, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
        return;
      try
      {
        double num1 = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
        if (RevitDefines.LT(num1, Math.PI / 180.0))
        {
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          num1 = Math.PI / 180.0;
        }
        RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, num1, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void HandleRetainingWall(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
    {
      if (!this.CheckForSpecialCharacter(text2))
        return;
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
      this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
      this.m_ParameterListView.SetFocus(_nChangedIndex);
    }
    else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallHeightParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        if (RevitDefines.LT(_dReturnedDouble2, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("RetainingWallHeightParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble2 = 0.0833333;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallBaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (_dReturnedDouble3 < 0.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("RetainingWallBaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          _dReturnedDouble3 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallSubbaseSurfaceParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble4 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
        if (_dReturnedDouble4 < 0.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("RetainingWallSubbaseSurfaceParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
          _dReturnedDouble4 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble5 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble5);
        if (RevitDefines.LT(_dReturnedDouble5, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("RetainingWallWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble5 = 0.0833333;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
        else if (_dReturnedDouble1 >= 0.0)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
        else
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble6 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble6);
        if (RevitDefines.LT(_dReturnedDouble6, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble6, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
        return;
      try
      {
        double _dAngle = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
        if (_dAngle < Math.PI / 180.0)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dAngle = Math.PI / 180.0;
        }
        RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void HandleSteps(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
    {
      if (!this.CheckForSpecialCharacter(text2))
        return;
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
      this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
      this.m_ParameterListView.SetFocus(_nChangedIndex);
    }
    else if (string.Compare(EPShared.LocalRM.GetString("StepsHeightParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StepsTreadParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StepsWidthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
        else if (_dReturnedDouble1 >= 0.0)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
        else
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (RevitDefines.LT(_dReturnedDouble3, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
        return;
      try
      {
        double _dAngle = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
        if (_dAngle <= 0.0)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dAngle = Math.PI / 20.0;
        }
        RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void HandleParkingLots(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0)
    {
      if (!this.CheckForSpecialCharacter(text2))
        return;
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("InvalidTypeNameMessage_")}\n\":{{}}[]|;<>?`~\n{EPShared.LocalRM.GetString("_InvalidTypeNameMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
      this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
      this.m_ParameterListView.SetFocus(_nChangedIndex);
    }
    else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotPavementDepthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble2 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
        if (RevitDefines.LT(_dReturnedDouble2, 0.0833333))
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("ParkingLotPavementDepthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble2 = 0.0833333;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotParkingBaseDepthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        if (RevitDefines.LT(_dReturnedDouble3, 0.0))
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("ParkingLotParkingBaseDepthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble3 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotParkingSubBaseDepthParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble4 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
        if (RevitDefines.LT(_dReturnedDouble4, 0.0))
        {
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("ParkingLotParkingSubBaseDepthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dReturnedDouble4 = 0.0;
        }
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
        else if (_dReturnedDouble1 >= 0.0)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
        else
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble5 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble5);
        if (RevitDefines.LT(_dReturnedDouble5, 0.0833333))
        {
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(0.0833333, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LinearIncrementParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), text1, true) != 0)
        return;
      try
      {
        double _dAngle = RevitGeometry.eplGeoE_ConvertAngleToRadians(text2);
        if (_dAngle < Math.PI / 180.0)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _dAngle = Math.PI / 180.0;
        }
        RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private bool CheckForSpecialCharacter(string _strStringToCheck)
  {
    if (_strStringToCheck.StartsWith(string.Empty))
      return false;
    string str = "\":{}[]|;<>?`~";
    return _strStringToCheck.IndexOfAny(str.ToCharArray()) >= 0;
  }

  private void InitializeData()
  {
    if (this.m_FamilyType != LandcaddID.Street)
      this.SetupDlg(out int _, out int _, out int _);
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_UnitLabel.Text = EPShared.LocalRM.GetString("CurrentSlopeUnitString");
    string empty = string.Empty;
    int num = -1;
    DisplayUnitType displayUnits = this.m_SlopeFormatOptions.DisplayUnits;
    if (displayUnits != 19)
    {
      switch (displayUnits - 158)
      {
        case 0:
          empty = EPShared.LocalRM.GetString("SlopeUnitRatio10");
          num = 0;
          break;
        case 1:
          empty = EPShared.LocalRM.GetString("SlopeUnitRatio12");
          num = 1;
          break;
        case 2:
          empty = EPShared.LocalRM.GetString("SlopeUnitDegrees");
          num = 5;
          break;
        case 3:
          empty = EPShared.LocalRM.GetString("SlopeUnitRiseInches");
          num = 3;
          break;
        case 4:
          empty = EPShared.LocalRM.GetString("SlopeUnitRiseFeet");
          num = 2;
          break;
        case 5:
          empty = EPShared.LocalRM.GetString("SlopeUnitRiseMM");
          num = 4;
          break;
      }
    }
    else
    {
      empty = EPShared.LocalRM.GetString("SlopeUnitPercentage");
      num = 6;
    }
    this.m_SlopeUnits.Add((DisplayUnitType) 158);
    this.m_SlopeUnits.Add((DisplayUnitType) 159);
    this.m_SlopeUnits.Add((DisplayUnitType) 162);
    this.m_SlopeUnits.Add((DisplayUnitType) 161);
    this.m_SlopeUnits.Add((DisplayUnitType) 163);
    this.m_SlopeUnits.Add((DisplayUnitType) 160 /*0xA0*/);
    this.m_SlopeUnits.Add((DisplayUnitType) 19);
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitRatio10"));
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitRatio12"));
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitRiseFeet"));
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitRiseInches"));
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitRiseMM"));
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitDegrees"));
    this.m_SlopeDisplayUnits.Add(EPShared.LocalRM.GetString("SlopeUnitPercentage"));
    for (int index = 0; index < this.m_SlopeDisplayUnits.Count; ++index)
      this.m_SlopeComboBox.Items.Add((object) this.m_SlopeDisplayUnits[index]);
    this.m_CurrentSlopeDisplayUnitType = this.m_SlopeFormatOptions.DisplayUnits;
    this.m_PreviousSlopeDisplayUnitType = this.m_CurrentSlopeDisplayUnitType;
    this.m_dCurrentSlopeAccuracy = RevitGeometry.GetSlopeAccuracy(this.m_CurrentSlopeDisplayUnitType);
    this.m_SlopeComboBox.SelectedIndex = num;
    this.m_SlopeComboBox.SelectedIndexChanged += new EventHandler(this.OnSlopeUnitsChanged);
    if (this.m_nSeletedIndex < 0)
    {
      this.Text = EPShared.LocalRM.GetString("AddDialog");
      FamilyTypeContainer familyTypeContainer = new FamilyTypeContainer();
      switch (this.m_FamilyType)
      {
        case LandcaddID.SoftTerrain:
          this.Controls.AddRange(new Control[3]
          {
            (Control) this.m_ParameterListView,
            (Control) this.m_ButtonOk,
            (Control) this.m_ButtonCancel
          });
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.SetupSoftTerrainViewInfo();
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("SoftTerrainManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          this.ContextualHelpID = "HID_SDtypeSoftTerrainAdd";
          break;
        case LandcaddID.Street:
          this.m_GlobalListView = new QuantumListView();
          this.SetupGlobalListViewInfoForAdd();
          this.m_SlopeComboBox.SelectedItem = (object) empty;
          this.m_StreetTabControl.SelectedIndex = 0;
          this.m_StreetTabControl.TabIndex = 0;
          this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("StreetInfoTabString"));
          this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("CurbGutterTabString"));
          this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("SlopeProjectionTabString"));
          this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("GeneralParametersTabString"));
          this.m_AddOrModify = AddModifyFamilyForm.FormForAddOrModify.Add;
          this.SetupStreetViewInfo(this.m_StreetTabControl.TabPages[0].Text);
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("StreetTypeManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          this.ContextualHelpID = "HID_SDtypeStreetAddInfo";
          break;
        case LandcaddID.Curb:
          this.Controls.AddRange(new Control[3]
          {
            (Control) this.m_ParameterListView,
            (Control) this.m_ButtonOk,
            (Control) this.m_ButtonCancel
          });
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.SetupCurbViewInfo();
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("CurbTypeManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          this.ContextualHelpID = "HID_SDtypeCurbAdd";
          break;
        case LandcaddID.Sidewalk:
          this.Controls.AddRange(new Control[3]
          {
            (Control) this.m_ParameterListView,
            (Control) this.m_ButtonOk,
            (Control) this.m_ButtonCancel
          });
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("CenterString"));
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("SideString"));
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.SetupSideWalkViewInfo();
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("SidewalkTypeManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          this.ContextualHelpID = "HID_SDtypeSidewalkAdd";
          break;
        case LandcaddID.RetainingWall:
          this.Controls.AddRange(new Control[3]
          {
            (Control) this.m_ParameterListView,
            (Control) this.m_ButtonOk,
            (Control) this.m_ButtonCancel
          });
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("NoString"));
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("YesString"));
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.SetupRetainingWallsViewInfo();
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("RetainingWallManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          this.ContextualHelpID = "HID_SDtypeRetainingWallAdd";
          break;
        case LandcaddID.Steps:
          this.Controls.AddRange(new Control[3]
          {
            (Control) this.m_ParameterListView,
            (Control) this.m_ButtonOk,
            (Control) this.m_ButtonCancel
          });
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.SetupStepsViewInfo();
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("StepsManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          break;
        case LandcaddID.ParkingLot:
          this.Controls.AddRange(new Control[3]
          {
            (Control) this.m_ParameterListView,
            (Control) this.m_ButtonOk,
            (Control) this.m_ButtonCancel
          });
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.SetupParkingLotViewInfo();
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("ParkingLotManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          this.ContextualHelpID = "HID_SDtypeParkinglotAdd";
          break;
      }
    }
    else
    {
      ListViewItem listViewItem1 = new ListViewItem();
      this.Text = EPShared.LocalRM.GetString("ModifyDialog");
      switch (this.m_FamilyType)
      {
        case LandcaddID.PlantMix:
          this.Text += " ";
          break;
        case LandcaddID.PatioWalk:
          this.Text += " ";
          break;
        case LandcaddID.SoftTerrain:
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("SoftTerrainManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.ContextualHelpID = "HID_SDtypeSoftTerrainModify";
          break;
        case LandcaddID.Street:
          this.ContextualHelpID = "HID_SDtypeStreetModifyInfo";
          break;
        case LandcaddID.Curb:
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("CurbTypeManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.ContextualHelpID = "HID_SDtypeCurbModify";
          break;
        case LandcaddID.Sidewalk:
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("CenterString"));
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("SideString"));
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("SidewalkTypeManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.ContextualHelpID = "HID_SDtypeSidewalkModify";
          break;
        case LandcaddID.RetainingWall:
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("NoString"));
          this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("YesString"));
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("RetainingWallManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.ContextualHelpID = "HID_SDtypeRetainingWallModify";
          break;
        case LandcaddID.Steps:
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("StepsManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          using (List<Material>.Enumerator enumerator = this.m_AllMaterialList.GetEnumerator())
          {
            while (enumerator.MoveNext())
              this.m_ParameterListView.MaterialCmbBox.Items.Add((object) ((Element) enumerator.Current).Name);
            break;
          }
        case LandcaddID.ParkingLot:
          this.Text = $"{this.Text} {EPShared.LocalRM.GetString("ParkingLotManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
          foreach (Element allMaterial in this.m_AllMaterialList)
            this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
          this.ContextualHelpID = "HID_SDtypeParkinglotModify";
          break;
      }
      if (this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.FindIndex(new Predicate<FamilyParameterWrapper>(AddModifyFamilyForm.CheckTypeNameParameter)) < 0)
        this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Insert(0, new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName, (StorageType) 3));
      if (this.m_FamilyType != LandcaddID.Street)
      {
        for (int index = 0; index < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index)
        {
          string text = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].DisplayName;
          string str1 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName;
          string str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
          if (string.Compare(str1, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(str1, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(str1, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
          {
            if (this.m_FamilyType == LandcaddID.PlantMix)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
              {
                double _dConvertedDouble = 1.0;
                if (str1 != string.Empty && str2 != null)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
              {
                str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
                if (str2 == string.Empty || str2 == null)
                  str2 = EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular");
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
              {
                if (str2 == null)
                  str2 = "1.0";
                else if (str2 != null && str2 == string.Empty)
                  str2 = "1.0";
              }
            }
            else if (this.m_FamilyType == LandcaddID.PatioWalk)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
              {
                double _dConvertedDouble = 1.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
              {
                str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
                if (str2 == string.Empty || str2 == null)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
                  str2 = EPShared.LocalRM.GetString("YesString");
              }
            }
            else if (this.m_FamilyType == LandcaddID.SoftTerrain)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SoftTerrainLeftOffsetWidthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SoftTerrainRightOffsetWidthParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SoftTerrainCutSlopeParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SoftTerrainFillSlopeParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                try
                {
                  if (!string.IsNullOrEmpty(str2))
                    _dConvertedDouble = ValueConversion.ToDouble(str2);
                }
                catch (Exception ex)
                {
                  _dConvertedDouble = 0.0;
                }
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
              }
            }
            else if (this.m_FamilyType == LandcaddID.Street)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetBoulevardWidthParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0833333;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbDisplayParameter, true) == 0)
              {
                str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
                if (str2 == string.Empty || str2 == null)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
                  str2 = EPShared.LocalRM.GetString("YesString");
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCrossSlopeParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCutSlopeParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetFillSlopeParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                try
                {
                  if (!string.IsNullOrEmpty(str2))
                    _dConvertedDouble = ValueConversion.ToDouble(str2);
                }
                catch (Exception ex)
                {
                  _dConvertedDouble = 0.0;
                }
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbDisplayParameter, true) == 0)
              {
                str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
                if (str2 == string.Empty || str2 == null)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
                  str2 = EPShared.LocalRM.GetString("YesString");
              }
              else if ((string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetPavementSurfaceParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0) && str2 != string.Empty)
              {
                string strStringToFind = str2;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
              }
            }
            else if (this.m_FamilyType == LandcaddID.Curb)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.CurbGutterHeightParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.CurbBaseSurfaceParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.CurbSubbaseSurfaceParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                try
                {
                  if (!string.IsNullOrEmpty(str2))
                    _dConvertedDouble = ValueConversion.ToDouble(str2);
                }
                catch (Exception ex)
                {
                  _dConvertedDouble = 0.0;
                }
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0 && str2 != string.Empty)
              {
                string strStringToFind = str2;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
              }
            }
            else if (this.m_FamilyType == LandcaddID.Sidewalk)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkWidthParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) != 0)
              {
                if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkPavementDepthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkBaseSurfaceParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkSubbaseSurfaceParameter, true) == 0)
                {
                  double _dConvertedDouble = 0.0;
                  try
                  {
                    if (str1 != string.Empty)
                    {
                      if (str2 != null)
                      {
                        if (str2 != string.Empty)
                          _dConvertedDouble = ValueConversion.ToDouble(str2);
                      }
                    }
                  }
                  catch (Exception ex)
                  {
                    _dConvertedDouble = 0.0;
                  }
                  RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
                }
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkCutSlopeParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkFillSlopeParameter, true) == 0)
                {
                  double _dConvertedDouble = 0.0;
                  try
                  {
                    if (!string.IsNullOrEmpty(str2))
                      _dConvertedDouble = ValueConversion.ToDouble(str2);
                  }
                  catch (Exception ex)
                  {
                    _dConvertedDouble = 0.0;
                  }
                  RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
                }
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) == 0)
                {
                  str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
                  if (str2 == string.Empty || str2 == null)
                    str2 = EPShared.LocalRM.GetString("CenterString");
                  else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
                    str2 = EPShared.LocalRM.GetString("CenterString");
                  else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
                    str2 = EPShared.LocalRM.GetString("SideString");
                }
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SideWalkPavementSurfaceParameter, true) == 0 && str2 != string.Empty)
                {
                  string strStringToFind = str2;
                  List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                  str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
                }
              }
              else
                continue;
            }
            else if (this.m_FamilyType == LandcaddID.RetainingWall)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallWidthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallHeightParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallBaseSurfaceParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallSubbaseSurfaceParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallCutSlopeParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallFillSlopeParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                try
                {
                  if (!string.IsNullOrEmpty(str2))
                    _dConvertedDouble = ValueConversion.ToDouble(str2);
                }
                catch (Exception ex)
                {
                  _dConvertedDouble = 0.0;
                }
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallSlopeProjectionParameter, true) == 0)
              {
                str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
                if (str2 == string.Empty || str2 == null)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
                  str2 = EPShared.LocalRM.GetString("NoString");
                else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
                  str2 = EPShared.LocalRM.GetString("YesString");
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.RetainingWallMaterialParameter, true) == 0 && str2 != string.Empty)
              {
                string strStringToFind = str2;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
              }
            }
            else if (this.m_FamilyType == LandcaddID.Steps)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StepsHeightParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StepsTreadParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StepsWidthParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.StepsMaterialParameter, true) == 0 && str2 != string.Empty)
              {
                string strStringToFind = str2;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
              }
            }
            else if (this.m_FamilyType == LandcaddID.ParkingLot)
            {
              if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.ParkingLotPavementDepthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.ParkingLotParkingBaseDepthParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.ParkingLotParkingSubBaseDepthParameter, true) == 0)
              {
                double _dConvertedDouble = 0.0;
                if (str1 != string.Empty && str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.ParkingLotParkingPavementSurfaceParameter, true) == 0 && str2 != string.Empty)
              {
                string strStringToFind = str2;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
              }
            }
            if (string.Compare(str1, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              string str3 = str1;
              str1 = RevitParameters.Slope_ + str3;
              string str4 = text;
              text = EPShared.LocalRM.GetString("Slope_") + str4;
              try
              {
                double _dConvertedDouble = 0.0;
                if (str2 != null && str2 != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str2);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
              }
              catch (Exception ex)
              {
                str2 = this.m_strLinearIncrement;
              }
            }
            else if (string.Compare(str1, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              string str5 = str1;
              str1 = RevitParameters.Slope_ + str5;
              string str6 = text;
              text = EPShared.LocalRM.GetString("Slope_") + str6;
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str2))
                  _dAngle = ValueConversion.ToDouble(str2);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str2);
              }
              catch (Exception ex)
              {
                str2 = this.m_strCircularIncrement;
              }
            }
            ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(str1, text, string.Empty);
            if (str2 == null)
              str2 = string.Empty;
            listViewItem2.SubItems.Add(str2);
            listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str2;
          }
        }
      }
      else
      {
        this.m_GlobalListView = new QuantumListView();
        this.SetupGlobalListViewInfoForModify();
        this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("StreetInfoTabString"));
        this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("CurbGutterTabString"));
        this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("SlopeProjectionTabString"));
        this.m_StreetTabControl.TabPages.Add(EPShared.LocalRM.GetString("GeneralParametersTabString"));
        this.Text = $"{this.Text} {EPShared.LocalRM.GetString("StreetTypeManagerString")}{EPShared.LocalRM.GetString("_TypeString")}";
        this.m_AddOrModify = AddModifyFamilyForm.FormForAddOrModify.Modify;
        this.SetupStreetViewInfo(this.m_StreetTabControl.TabPages[0].Text);
      }
    }
  }

  private void OnSlopeUnitsChanged(object sender, EventArgs e)
  {
    this.m_CurrentSlopeDisplayUnitType = this.m_SlopeUnits[this.m_SlopeComboBox.SelectedIndex];
    this.m_dCurrentSlopeAccuracy = RevitGeometry.GetSlopeAccuracy(this.m_CurrentSlopeDisplayUnitType);
    this.FindIndexInListView();
    this.m_PreviousSlopeDisplayUnitType = this.m_CurrentSlopeDisplayUnitType;
  }

  private void FindIndexInListView()
  {
    List<string> stringList = new List<string>();
    switch (this.m_FamilyType)
    {
      case LandcaddID.SoftTerrain:
        stringList.Add(EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"));
        stringList.Add(EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"));
        break;
      case LandcaddID.Street:
        stringList.Add(EPShared.LocalRM.GetString("StreetCrossSlopeParameter"));
        stringList.Add(EPShared.LocalRM.GetString("StreetCutSlopeParameter"));
        stringList.Add(EPShared.LocalRM.GetString("StreetFillSlopeParameter"));
        stringList.Add(EPShared.LocalRM.GetString("StreetGutterSlopeParameter"));
        break;
      case LandcaddID.Curb:
        stringList.Add(EPShared.LocalRM.GetString("StreetGutterSlopeParameter"));
        break;
      case LandcaddID.Sidewalk:
        stringList.Add(EPShared.LocalRM.GetString("SideWalkCutSlopeParameter"));
        stringList.Add(EPShared.LocalRM.GetString("SideWalkFillSlopeParameter"));
        break;
      case LandcaddID.RetainingWall:
        stringList.Add(EPShared.LocalRM.GetString("RetainingWallCutSlopeParameter"));
        stringList.Add(EPShared.LocalRM.GetString("RetainingWallFillSlopeParameter"));
        break;
    }
    foreach (string strB in stringList)
    {
      for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
      {
        string text1 = this.m_ParameterListView.Items[index].SubItems[0].Text;
        string text2 = this.m_ParameterListView.Items[index].SubItems[1].Text;
        if (string.Compare(text1, strB, true) == 0)
          this.HandleSlopes(index);
      }
    }
  }

  private void SetupDlg(
    out int nListViewColumnWidth,
    out int nTotalListViewHeight,
    out int nTotalDlgHeight)
  {
    int num1 = 21;
    int num2 = 15;
    int num3 = 17;
    int num4 = 23;
    nListViewColumnWidth = 215;
    int count = this.m_ParameterList.Count;
    int x1 = 10;
    int y1 = 10;
    if (Environment.OSVersion.Version.Major == 5)
    {
      num2 = 15;
      num3 = 17;
    }
    else if (Environment.OSVersion.Version.Major == 6)
    {
      if (Environment.OSVersion.Version.Minor == 0)
      {
        num2 = 18;
        num3 = 24;
      }
      else
      {
        num2 = 21;
        num3 = 24;
      }
    }
    nTotalListViewHeight = num3 + num2 * count;
    nTotalDlgHeight = num3 + nTotalListViewHeight + num4 + num1 * 3;
    if (this.m_bPreview)
    {
      Image image = (Image) null;
      switch (this.m_FamilyType)
      {
        case LandcaddID.SoftTerrain:
          image = (Image) Resources.SoftTerrainInfo;
          break;
        case LandcaddID.Street:
          image = (Image) Resources.StreetInfo;
          break;
        case LandcaddID.Curb:
          image = (Image) Resources.CurbInfo;
          break;
        case LandcaddID.Sidewalk:
          image = (Image) Resources.SidewalkInfo;
          break;
        case LandcaddID.RetainingWall:
          image = (Image) Resources.RetainingWallInfo;
          break;
        case LandcaddID.Steps:
          image = (Image) Resources.StreetInfo;
          break;
        case LandcaddID.ParkingLot:
          image = (Image) Resources.ParkingLotInfo;
          break;
      }
      this.m_PreviewBox = new PictureBox();
      this.m_PreviewBox.Location = new Point(x1, y1);
      this.m_PreviewBox.Width = nListViewColumnWidth;
      this.m_PreviewBox.SizeMode = PictureBoxSizeMode.AutoSize;
      this.m_PreviewBox.Image = image;
      this.m_PreviewBox.BorderStyle = BorderStyle.Fixed3D;
      this.m_PreviewBox.BackColor = Color.White;
      this.m_PreviewBox.Anchor = AnchorStyles.Top | AnchorStyles.Left;
      this.Controls.AddRange(new Control[1]
      {
        (Control) this.m_PreviewBox
      });
      if (nTotalListViewHeight < this.m_PreviewBox.Height)
        nTotalListViewHeight = this.m_PreviewBox.Height;
      this.m_ParameterListView = new QuantumListView(nListViewColumnWidth * 2, nTotalListViewHeight);
      this.m_ParameterListView.Location = new Point(this.m_PreviewBox.Width + 2 * x1, y1);
      this.m_ParameterListView.View = View.Details;
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
      this.m_ParameterListView.Columns[0].Width = nListViewColumnWidth - 1;
      this.m_ParameterListView.Columns[1].Width = nListViewColumnWidth - 1;
      this.m_PreviewBox.Height = this.m_ParameterListView.Height;
      Label unitLabel = this.m_UnitLabel;
      Point location = this.m_PreviewBox.Location;
      Point point1 = new Point(location.X, y1 + this.m_ParameterListView.Height + 7);
      unitLabel.Location = point1;
      this.m_ButtonOk.Location = new Point(this.m_PreviewBox.Width + x1 * 2 + 260, y1 + this.m_ParameterListView.Height + 7);
      this.m_ButtonCancel.Location = new Point(this.m_PreviewBox.Width + x1 * 2 + 340, y1 + this.m_ParameterListView.Height + 7);
      this.m_UnitLabel.Height = this.m_ButtonOk.Height;
      this.m_UnitLabel.Width = 150;
      ComboBox slopeComboBox = this.m_SlopeComboBox;
      location = this.m_UnitLabel.Location;
      int x2 = location.X + this.m_UnitLabel.Width + 5;
      location = this.m_UnitLabel.Location;
      int y2 = location.Y;
      Point point2 = new Point(x2, y2);
      slopeComboBox.Location = point2;
      this.m_SlopeComboBox.Height = this.m_UnitLabel.Height;
      this.m_SlopeComboBox.Width = this.m_UnitLabel.Width;
      nTotalDlgHeight = this.m_ParameterListView.Height + this.m_ButtonCancel.Height + num1 * 3;
      this.Height = nTotalDlgHeight;
      this.Width = this.m_PreviewBox.Width + 3 * x1 + nListViewColumnWidth * 2;
      this.Size = new Size(this.m_PreviewBox.Width + 3 * x1 + nListViewColumnWidth * 2, nTotalDlgHeight);
      this.MinimumSize = new Size(this.Width, this.Height);
      this.Refresh();
    }
    else
    {
      this.m_ParameterListView = new QuantumListView(nListViewColumnWidth * 2, nTotalListViewHeight);
      this.m_ParameterListView.View = View.Details;
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
      this.m_ParameterListView.Columns[0].Width = nListViewColumnWidth - 1;
      this.m_ParameterListView.Columns[1].Width = nListViewColumnWidth - 1;
      this.m_UnitLabel.Location = new Point(this.m_PreviewBox.Location.X, this.m_ParameterListView.Height + num1);
      this.m_ButtonOk.Location = new Point(this.m_ParameterListView.Width - this.m_ButtonOk.Width - x1 - this.m_ButtonCancel.Width, this.m_ParameterListView.Height + num1);
      this.m_ButtonCancel.Location = new Point(this.m_ParameterListView.Width - this.m_ButtonCancel.Width, this.m_ParameterListView.Height + num1);
      this.m_UnitLabel.Height = this.m_ButtonOk.Height;
      this.m_UnitLabel.Width = 150;
      this.m_SlopeComboBox.Location = new Point(this.m_UnitLabel.Location.X + this.m_UnitLabel.Width + 5, this.m_UnitLabel.Location.Y);
      this.m_SlopeComboBox.Height = this.m_UnitLabel.Height;
      this.m_SlopeComboBox.Width = this.m_UnitLabel.Width;
      nTotalDlgHeight = this.m_ParameterListView.Height + this.m_ButtonCancel.Height + num1 * 3;
      this.Height = nTotalDlgHeight;
      this.Width = nListViewColumnWidth * 2 + num1;
      this.MinimumSize = new Size(this.Width, this.Height);
    }
    this.Controls.AddRange(new Control[5]
    {
      (Control) this.m_ParameterListView,
      (Control) this.m_UnitLabel,
      (Control) this.m_ButtonOk,
      (Control) this.m_ButtonCancel,
      (Control) this.m_SlopeComboBox
    });
  }

  private void SetupStreetDlg(
    out int nListViewColumnWidth,
    out int nListViewTotalHeight,
    out int nTotalDlgHeight)
  {
    int num1 = 21;
    int num2 = 15;
    int num3 = 17;
    int num4 = 23;
    nListViewColumnWidth = 215;
    int num5 = 10;
    int x = 10;
    int y = 10;
    if (Environment.OSVersion.Version.Major == 5)
    {
      num2 = 15;
      num3 = 17;
      num5 = 12;
    }
    else if (Environment.OSVersion.Version.Major == 6)
    {
      if (Environment.OSVersion.Version.Minor == 0)
      {
        num2 = 18;
        num3 = 24;
      }
      else
      {
        num2 = 21;
        num3 = 24;
      }
    }
    nListViewTotalHeight = num3 + num2 * num5;
    nTotalDlgHeight = num3 + nListViewTotalHeight + num4 + num1 * 3;
    if (this.m_bPreview)
    {
      Image streetInfo = (Image) Resources.StreetInfo;
      this.m_PreviewBox = new PictureBox();
      this.m_PreviewBox.Location = new Point(x, y);
      this.m_PreviewBox.Width = nListViewColumnWidth;
      this.m_PreviewBox.SizeMode = PictureBoxSizeMode.AutoSize;
      this.m_PreviewBox.Image = streetInfo;
      this.m_PreviewBox.BorderStyle = BorderStyle.Fixed3D;
      this.m_PreviewBox.BackColor = Color.White;
      this.m_PreviewBox.Anchor = AnchorStyles.Top | AnchorStyles.Left;
      this.Controls.AddRange(new Control[1]
      {
        (Control) this.m_PreviewBox
      });
      this.m_ParameterListView = new QuantumListView(nListViewColumnWidth * 2, nListViewTotalHeight);
      this.m_ParameterListView.View = View.Details;
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
      this.m_ParameterListView.Columns[0].Width = nListViewColumnWidth - 1;
      this.m_ParameterListView.Columns[1].Width = nListViewColumnWidth - 1;
      this.m_StreetTabControl.Location = new Point(this.m_PreviewBox.Width + 2 * x, y);
      this.m_StreetTabControl.Size = new Size(nListViewColumnWidth * 2 + 30, this.m_ParameterListView.Height + 40);
      this.m_PreviewBox.Height = this.m_StreetTabControl.Height - 2;
      this.m_UnitLabel.Location = new Point(this.m_PreviewBox.Location.X, y + this.m_StreetTabControl.Height + 7);
      this.m_ButtonOk.Location = new Point(this.m_PreviewBox.Width + x * 2 + 300, y + this.m_StreetTabControl.Height + 7);
      this.m_ButtonCancel.Location = new Point(this.m_PreviewBox.Width + x * 2 + 381, y + this.m_StreetTabControl.Height + 7);
      this.m_UnitLabel.Height = this.m_ButtonOk.Height;
      this.m_UnitLabel.Width = 150;
      this.m_SlopeComboBox.Location = new Point(this.m_UnitLabel.Location.X + this.m_UnitLabel.Width + 5, this.m_UnitLabel.Location.Y);
      this.m_SlopeComboBox.Height = this.m_UnitLabel.Height;
      this.m_SlopeComboBox.Width = this.m_UnitLabel.Width;
      nTotalDlgHeight = this.m_StreetTabControl.Height + this.m_ButtonCancel.Height + num1 * 3;
      this.Height = nTotalDlgHeight;
      this.Width = this.m_PreviewBox.Width + 2 * x + nListViewColumnWidth * 2 + 43;
      this.MinimumSize = new Size(this.Width, this.Height);
    }
    else
    {
      this.m_ParameterListView = new QuantumListView(nListViewColumnWidth * 2, nListViewTotalHeight);
      this.m_ParameterListView.View = View.Details;
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
      this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
      this.m_ParameterListView.Columns[0].Width = nListViewColumnWidth - 1;
      this.m_ParameterListView.Columns[1].Width = nListViewColumnWidth - 1;
      this.m_StreetTabControl.Location = new Point(3, 3);
      this.m_StreetTabControl.Size = new Size(nListViewColumnWidth * 2 + 30, this.m_ParameterListView.Height + 40);
      this.m_UnitLabel.Location = new Point(this.m_StreetTabControl.Location.X, this.m_StreetTabControl.Height + num1);
      this.m_ButtonOk.Location = new Point(299, this.m_StreetTabControl.Height + num1);
      this.m_ButtonCancel.Location = new Point(380, this.m_StreetTabControl.Height + num1);
      this.m_UnitLabel.Height = this.m_ButtonOk.Height;
      this.m_UnitLabel.Width = 150;
      this.m_SlopeComboBox.Location = new Point(this.m_UnitLabel.Location.X + this.m_UnitLabel.Width + 5, this.m_UnitLabel.Location.Y);
      this.m_SlopeComboBox.Height = this.m_UnitLabel.Height;
      this.m_SlopeComboBox.Width = this.m_UnitLabel.Width;
      nTotalDlgHeight = this.m_StreetTabControl.Height + this.m_ButtonCancel.Height + num1 * 3;
      this.Height = nTotalDlgHeight;
      this.Width = nListViewColumnWidth * 2 + 43;
      this.MinimumSize = new Size(this.Width, this.Height);
    }
    this.Controls.AddRange(new Control[5]
    {
      (Control) this.m_StreetTabControl,
      (Control) this.m_UnitLabel,
      (Control) this.m_ButtonOk,
      (Control) this.m_ButtonCancel,
      (Control) this.m_SlopeComboBox
    });
  }

  private void StreetTabControlTabIndexChanged(object sender, EventArgs e)
  {
    this.SetupStreetViewInfo(this.m_StreetTabControl.SelectedTab.Text);
    this.UpdateCurrentTabListView();
    this.FindIndexInListView();
  }

  private static bool CheckTypeNameParameter(FamilyParameterWrapper _CurrParameter)
  {
    return string.Compare(_CurrParameter.ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0;
  }

  private void SetupGlobalListViewInfoForAdd()
  {
    string empty = string.Empty;
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string text = this.m_ParameterList[index].ParameterDisplayName;
      string key = this.m_ParameterList[index].ParameterName;
      string str1 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          str1 = EPShared.LocalRM.GetString("NewStreet");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetNumberOfLanesParameter, true) == 0)
          str1 = 2.ToString();
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetLaneWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(15.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetPavementDepthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetBaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0 / 3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetSubbaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.03, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCrossSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.02, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetFillSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.333, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetPavementSurfaceParameter, true) == 0)
        {
          str1 = "Default";
          string strStringToFind = str1;
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
          str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
        {
          str1 = "Default";
          string strStringToFind = str1;
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
          str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbDisplayParameter, true) == 0)
          str1 = "No";
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
          str1 = "";
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetBoulevardWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(7.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0 / 12.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(5.0 / 12.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          double _dConvertedDouble = 0.0;
          str1 = this.m_strLinearIncrement;
          if (str1 != null && str1 != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(str1);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str1 = this.m_strCircularIncrement;
          RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, Math.PI / 20.0, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str2 = key;
          key = RevitParameters.Slope_ + str2;
          string str3 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str3;
        }
        ListViewItem listViewItem2 = this.m_GlobalListView.Items.Add(key, text, string.Empty);
        listViewItem2.SubItems.Add(str1);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
      }
    }
  }

  private void SetupGlobalListViewInfoForModify()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    for (int index = 0; index < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index)
    {
      string text = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].DisplayName;
      string str1 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName;
      string str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
      if (string.Compare(str1, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(str1, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(str1, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(str1, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetLaneWidthParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetPavementDepthParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetCurbWidthParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetBoulevardWidthParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetBaseSurfaceParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetSubbaseSurfaceParameter, true) == 0)
        {
          double _dConvertedDouble = 0.0;
          if (str1 != string.Empty && str2 != null && str2 != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(str2);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
        }
        else if (string.Compare(str1, RevitParameters.StreetCrossSlopeParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetGutterSlopeParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetCutSlopeParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetFillSlopeParameter, true) == 0)
        {
          double _dConvertedDouble = 0.0;
          try
          {
            if (!string.IsNullOrEmpty(str2))
              _dConvertedDouble = ValueConversion.ToDouble(str2);
          }
          catch (Exception ex)
          {
            _dConvertedDouble = 0.0;
          }
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
        }
        else if (string.Compare(str1, RevitParameters.StreetPavementSurfaceParameter, true) == 0 || string.Compare(str1, RevitParameters.StreetCurbMaterialParameter, true) == 0)
        {
          if (str2 != string.Empty)
          {
            string strStringToFind = str2;
            List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
            str2 = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
          }
        }
        else if (string.Compare(str1, RevitParameters.StreetCurbDisplayParameter, true) == 0)
        {
          str2 = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
          if (str2 == string.Empty || str2 == null)
            str2 = EPShared.LocalRM.GetString("NoString");
          else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
            str2 = EPShared.LocalRM.GetString("NoString");
          else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
            str2 = EPShared.LocalRM.GetString("YesString");
        }
        else if (string.Compare(str1, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          string str3 = str1;
          str1 = RevitParameters.Slope_ + str3;
          string str4 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str4;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str2 != null && str2 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str2);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
          }
          catch (Exception ex)
          {
            str2 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(str1, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str5 = str1;
          str1 = RevitParameters.Slope_ + str5;
          string str6 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str6;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str2))
              _dAngle = ValueConversion.ToDouble(str2);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str2);
          }
          catch (Exception ex)
          {
            str2 = this.m_strCircularIncrement;
          }
        }
        ListViewItem listViewItem2 = this.m_GlobalListView.Items.Add(str1, text, string.Empty);
        if (str2 == null)
          str2 = string.Empty;
        listViewItem2.SubItems.Add(str2);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str2;
      }
    }
  }

  private void SetupStreetViewInfo(string _strCurrentTabText)
  {
    this.UpdateGlobalListView();
    if (this.m_StreetTabControl.SelectedTab.Controls.Count > 0)
      this.m_StreetTabControl.SelectedTab.Controls.RemoveAt(0);
    this.m_ParameterList.Clear();
    if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("StreetInfoTabString"), true) == 0)
    {
      switch (this.m_AddOrModify)
      {
        case AddModifyFamilyForm.FormForAddOrModify.Add:
          this.ContextualHelpID = "HID_SDtypeStreetAddInfo";
          break;
        case AddModifyFamilyForm.FormForAddOrModify.Modify:
          this.ContextualHelpID = "HID_SDtypeStreetModifyInfo";
          break;
      }
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetNumberOfLanesParameter"), RevitParameters.StreetNumberOfLanesParameter, (ParameterType) 2));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetLaneWidthParameter"), RevitParameters.StreetLaneWidthParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetPavementDepthParameter"), RevitParameters.StreetPavementDepthParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCrossSlopeParameter"), RevitParameters.StreetCrossSlopeParameter, (ParameterType) 159));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), RevitParameters.StreetPavementSurfaceParameter, (ParameterType) 2));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbDisplayParameter"), RevitParameters.StreetCurbDisplayParameter, (ParameterType) 10));
    }
    else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("CurbGutterTabString"), true) == 0)
    {
      switch (this.m_AddOrModify)
      {
        case AddModifyFamilyForm.FormForAddOrModify.Add:
          this.ContextualHelpID = "HID_SDtypeStreetAddCurbGutter";
          break;
        case AddModifyFamilyForm.FormForAddOrModify.Modify:
          this.ContextualHelpID = "HID_SDtypeStreetModifyCurbGutter";
          break;
      }
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetGutterWidthParameter"), RevitParameters.StreetGutterWidthParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetGutterSlopeParameter"), RevitParameters.StreetGutterSlopeParameter, (ParameterType) 159));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), RevitParameters.StreetCurbOffsetParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbWidthParameter"), RevitParameters.StreetCurbWidthParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbHeightParameter"), RevitParameters.StreetCurbHeightParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbMaterialParameter"), RevitParameters.StreetCurbMaterialParameter, (ParameterType) 2));
    }
    else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("SlopeProjectionTabString"), true) == 0)
    {
      switch (this.m_AddOrModify)
      {
        case AddModifyFamilyForm.FormForAddOrModify.Add:
          this.ContextualHelpID = "HID_SDtypeStreetAddSlope";
          break;
        case AddModifyFamilyForm.FormForAddOrModify.Modify:
          this.ContextualHelpID = "HID_SDtypeStreetModifySlope";
          break;
      }
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetBoulevardWidthParameter"), RevitParameters.StreetBoulevardWidthParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCutSlopeParameter"), RevitParameters.StreetCutSlopeParameter, (ParameterType) 159));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetFillSlopeParameter"), RevitParameters.StreetFillSlopeParameter, (ParameterType) 159));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, (ParameterType) 7));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetBaseSurfaceParameter"), RevitParameters.StreetBaseSurfaceParameter, (ParameterType) 4));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter"), RevitParameters.StreetSubbaseSurfaceParameter, (ParameterType) 4));
    }
    else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("GeneralParametersTabString"), true) == 0)
    {
      switch (this.m_AddOrModify)
      {
        case AddModifyFamilyForm.FormForAddOrModify.Add:
          this.ContextualHelpID = "HID_SDtypeStreetAddGeneralParams";
          break;
        case AddModifyFamilyForm.FormForAddOrModify.Modify:
          this.ContextualHelpID = "HID_SDtypeStreetModifyGeneralParams";
          break;
      }
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), RevitParameters.KeynoteGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1140422));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), RevitParameters.ModelGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010109));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), RevitParameters.ManufacturerGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010108));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), RevitParameters.TypeCommentsGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010105));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), RevitParameters.URLGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010104));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), RevitParameters.DescriptionGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010103));
      this.m_ParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), RevitParameters.CostGenericFamilyParameter, (ParameterType) 172, (BuiltInParameter) -1001205));
    }
    this.SetupStreetDlg(out int _, out int _, out int _);
    this.m_ParameterListView.OnListViewItemChanged += new ListViewItemChanged(this.ParameterListViewOnListViewItemChanged);
    foreach (Element allMaterial in this.m_AllMaterialList)
      this.m_ParameterListView.MaterialCmbBox.Items.Add((object) allMaterial.Name);
    this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("NoString"));
    this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("YesString"));
    string empty1 = string.Empty;
    ListViewItem listViewItem1 = new ListViewItem();
    if (this.m_nSeletedIndex < 0)
    {
      for (int index = 0; index < this.m_ParameterList.Count; ++index)
      {
        string text = this.m_ParameterList[index].ParameterDisplayName;
        string key = this.m_ParameterList[index].ParameterName;
        string str1 = "";
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
        {
          if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
            str1 = EPShared.LocalRM.GetString("NewStreet");
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetNumberOfLanesParameter, true) == 0)
            str1 = 2.ToString();
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetLaneWidthParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(15.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetPavementDepthParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(0.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetBaseSurfaceParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(2.0 / 3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetSubbaseSurfaceParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(0.03, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCrossSlopeParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(0.02, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetFillSlopeParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(0.333, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbDisplayParameter, true) == 0)
            str1 = "Yes";
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetPavementSurfaceParameter, true) == 0)
          {
            string strStringToFind = "Default";
            List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
            str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
          }
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
          {
            string strStringToFind = "Default";
            List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
            str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
          }
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
            str1 = "";
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(0.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetBoulevardWidthParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(7.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(2.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(5.0 / 12.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(1.0 / 12.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
          {
            str1 = this.m_strLinearIncrement;
            try
            {
              double _dConvertedDouble = 0.0;
              if (str1 != null && str1 != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str1);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
            }
            catch (Exception ex)
            {
              str1 = this.m_strLinearIncrement;
            }
          }
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
          {
            str1 = this.m_strCircularIncrement;
            try
            {
              RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, Math.PI / 20.0, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
            }
            catch (Exception ex)
            {
              str1 = this.m_strCircularIncrement;
            }
          }
          if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
          {
            string str2 = key;
            key = RevitParameters.Slope_ + str2;
            string str3 = text;
            text = EPShared.LocalRM.GetString("Slope_") + str3;
          }
          ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(key, text, string.Empty);
          listViewItem2.SubItems.Add(str1);
          listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
        }
      }
    }
    else
    {
      for (int index1 = 0; index1 < this.m_ParameterList.Count; ++index1)
      {
        string str4 = this.m_ParameterList[index1].ParameterDisplayName;
        string key = this.m_ParameterList[index1].ParameterName;
        string text1 = "";
        if (string.Compare(this.m_ParameterList[index1].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index1].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str5 = key;
          key = RevitParameters.Slope_ + str5;
          string str6 = str4;
          str4 = EPShared.LocalRM.GetString("Slope_") + str6;
        }
        if (string.Compare(this.m_ParameterList[index1].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
        {
          string empty2 = string.Empty;
          string empty3 = string.Empty;
          for (int index2 = 0; index2 < this.m_GlobalListView.Items.Count; ++index2)
          {
            string text2 = this.m_GlobalListView.Items[index2].SubItems[0].Text;
            string text3 = this.m_GlobalListView.Items[index2].SubItems[1].Text;
            if (string.Compare(text2, str4, false) == 0)
            {
              text1 = text3;
              break;
            }
          }
          ListViewItem listViewItem3 = this.m_ParameterListView.Items.Add(key, str4, string.Empty);
          listViewItem3.SubItems.Add(text1);
          listViewItem3.SubItems[listViewItem3.SubItems.Count - 1].Text = text1;
        }
      }
    }
    this.m_StreetTabControl.SelectedTab.Controls.AddRange(new Control[1]
    {
      (Control) this.m_ParameterListView
    });
  }

  private void UpdateGlobalListView()
  {
    if (this.m_ParameterListView == null)
      return;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index1 = 0; index1 < this.m_ParameterListView.Items.Count; ++index1)
    {
      string text1 = this.m_ParameterListView.Items[index1].SubItems[0].Text;
      string text2 = this.m_ParameterListView.Items[index1].SubItems[1].Text;
      for (int index2 = 0; index2 < this.m_GlobalListView.Items.Count; ++index2)
      {
        if (string.Compare(this.m_GlobalListView.Items[index2].SubItems[0].Text, text1, false) == 0)
        {
          this.m_GlobalListView.Items[index2].SubItems[1].Text = text2;
          break;
        }
      }
    }
  }

  private void UpdateCurrentTabListView()
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index1 = 0; index1 < this.m_GlobalListView.Items.Count; ++index1)
    {
      string text1 = this.m_GlobalListView.Items[index1].SubItems[0].Text;
      string text2 = this.m_GlobalListView.Items[index1].SubItems[1].Text;
      for (int index2 = 0; index2 < this.m_ParameterListView.Items.Count; ++index2)
      {
        if (string.Compare(this.m_ParameterListView.Items[index2].SubItems[0].Text, text1, false) == 0)
        {
          this.m_ParameterListView.Items[index2].SubItems[1].Text = text2;
          break;
        }
      }
    }
  }

  private void SetupCurbViewInfo()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string text = this.m_ParameterList[index].ParameterDisplayName;
      string key = this.m_ParameterList[index].ParameterName;
      string str1 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          str1 = EPShared.LocalRM.GetString("NewCurb");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(5.0 / 12.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0 / 12.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurbGutterHeightParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurbBaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0 / 6.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurbSubbaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.03, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
        {
          str1 = "Default";
          string strStringToFind = str1;
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
          str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          str1 = this.m_strLinearIncrement;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str1 != null && str1 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str1);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str1 = this.m_strCircularIncrement;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str1))
              _dAngle = ValueConversion.ToDouble(str1);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strCircularIncrement;
          }
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str2 = key;
          key = RevitParameters.Slope_ + str2;
          string str3 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str3;
        }
        ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(key, text, string.Empty);
        listViewItem2.SubItems.Add(str1);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
      }
    }
  }

  private void SetupSideWalkViewInfo()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string text = this.m_ParameterList[index].ParameterDisplayName;
      string key = this.m_ParameterList[index].ParameterName;
      string str1 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          str1 = EPShared.LocalRM.GetString("NewSidewalk");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) == 0)
          str1 = EPShared.LocalRM.GetString("CenterString");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(4.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkPavementDepthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.25, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkBaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0 / 6.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkSubbaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkFillSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.01, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkPavementSurfaceParameter, true) == 0)
        {
          str1 = "Default";
          string strStringToFind = str1;
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
          str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          str1 = this.m_strLinearIncrement;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str1 != null && str1 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str1);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str1 = this.m_strCircularIncrement;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str1))
              _dAngle = ValueConversion.ToDouble(str1);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strCircularIncrement;
          }
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str2 = key;
          key = RevitParameters.Slope_ + str2;
          string str3 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str3;
        }
        ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(key, text, string.Empty);
        listViewItem2.SubItems.Add(str1);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
      }
    }
  }

  private void SetupRetainingWallsViewInfo()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string text = this.m_ParameterList[index].ParameterDisplayName;
      string key = this.m_ParameterList[index].ParameterName;
      string str1 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          str1 = EPShared.LocalRM.GetString("NewRetainingWall");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0 / 3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallFillSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.01, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallHeightParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(10.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallBaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0 / 3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallSubbaseSurfaceParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallMaterialParameter, true) == 0)
        {
          str1 = "Default";
          string strStringToFind = str1;
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
          str1 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RetainingWallSlopeProjectionParameter, true) == 0)
          str1 = "No";
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          str1 = this.m_strLinearIncrement;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str1 != null && str1 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str1);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str1 = this.m_strCircularIncrement;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str1))
              _dAngle = ValueConversion.ToDouble(str1);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strCircularIncrement;
          }
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str2 = key;
          key = RevitParameters.Slope_ + str2;
          string str3 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str3;
        }
        ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(key, text, string.Empty);
        listViewItem2.SubItems.Add(str1);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
      }
    }
  }

  private void SetupStepsViewInfo()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string text = this.m_ParameterList[index].ParameterDisplayName;
      string key = this.m_ParameterList[index].ParameterName;
      string str1 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StepsHeightParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StepsTreadParameter, true) == 0)
        {
          str1 = "0.66";
          double _dConvertedDouble = 0.66;
          if (str1 != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(str1);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StepsWidthParameter, true) == 0)
        {
          str1 = "4.0";
          double _dConvertedDouble = 4.0;
          if (str1 != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(str1);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.StepsMaterialParameter, true) == 0)
          str1 = "Default";
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          str1 = this.m_strLinearIncrement;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str1 != null && str1 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str1);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str1 = this.m_strCircularIncrement;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str1))
              _dAngle = ValueConversion.ToDouble(str1);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strCircularIncrement;
          }
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str2 = key;
          key = RevitParameters.Slope_ + str2;
          string str3 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str3;
        }
        ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(key, text, string.Empty);
        listViewItem2.SubItems.Add(str1);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
      }
    }
  }

  private void SetupParkingLotViewInfo()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string text = this.m_ParameterList[index].ParameterDisplayName;
      string key = this.m_ParameterList[index].ParameterName;
      string str1 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          str1 = EPShared.LocalRM.GetString("NewParkingLot");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.ParkingLotPavementDepthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(0.5, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.ParkingLotParkingBaseDepthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0 / 3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.ParkingLotParkingSubBaseDepthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.ParkingLotParkingPavementSurfaceParameter, true) == 0)
          str1 = "Default";
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          str1 = this.m_strLinearIncrement;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str1 != null && str1 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str1);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str1 = this.m_strCircularIncrement;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str1))
              _dAngle = ValueConversion.ToDouble(str1);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str1);
          }
          catch (Exception ex)
          {
            str1 = this.m_strCircularIncrement;
          }
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str2 = key;
          key = RevitParameters.Slope_ + str2;
          string str3 = text;
          text = EPShared.LocalRM.GetString("Slope_") + str3;
        }
        ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(key, text, string.Empty);
        listViewItem2.SubItems.Add(str1);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str1;
      }
    }
  }

  private void SetupSoftTerrainViewInfo()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string parameterDisplayName = this.m_ParameterList[index].ParameterDisplayName;
      string str1 = this.m_ParameterList[index].ParameterName;
      string str2 = "";
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          str2 = EPShared.LocalRM.GetString("NewSoftTerrain");
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SoftTerrainLeftOffsetWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SoftTerrainRightOffsetWidthParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(2.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SoftTerrainCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SoftTerrainFillSlopeParameter, true) == 0)
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_CurrentSlopeDisplayUnitType, this.m_dCurrentSlopeAccuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref str2);
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
        {
          str2 = this.m_strLinearIncrement;
          try
          {
            double _dConvertedDouble = 0.0;
            if (str2 != null && str2 != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(str2);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
          }
          catch (Exception ex)
          {
            str2 = this.m_strLinearIncrement;
          }
        }
        else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          str2 = this.m_strCircularIncrement;
          try
          {
            double _dAngle = 0.0;
            if (!string.IsNullOrEmpty(str2))
              _dAngle = ValueConversion.ToDouble(str2);
            RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str2);
          }
          catch (Exception ex)
          {
            str2 = this.m_strCircularIncrement;
          }
        }
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
        {
          string str3 = str1;
          str1 = RevitParameters.Slope_ + str3;
          string str4 = parameterDisplayName;
          string str5 = EPShared.LocalRM.GetString("Slope_") + str4;
        }
        ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(str1, str1, string.Empty);
        listViewItem2.SubItems.Add(str2);
        listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = str2;
      }
    }
  }

  private void OnButtonOkClicked(object sender, EventArgs e)
  {
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    string _strFamilyTypeName1 = string.Empty;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string str1 = string.Empty;
    string str2 = string.Empty;
    if (this.m_FamilyType == LandcaddID.PlantMix)
    {
      for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
      {
        string text1 = this.m_ParameterListView.Items[index].SubItems[0].Text;
        string text2 = this.m_ParameterListView.Items[index].SubItems[1].Text;
        if (string.Compare(text1, EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), true) == 0)
        {
          if (!string.IsNullOrEmpty(text2))
          {
            flag1 = true;
            str2 = text2;
            if (flag2)
              break;
          }
        }
        else if (string.Compare(text1, EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), true) == 0 && !string.IsNullOrEmpty(text2))
        {
          flag2 = true;
          str1 = text2;
          if (flag1)
            break;
        }
      }
      if (!flag1 && !flag2)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeCommonOrScientificName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
      {
        string text3 = this.m_ParameterListView.Items[index].SubItems[0].Text;
        string text4 = this.m_ParameterListView.Items[index].SubItems[1].Text;
        if (string.Compare(text3, EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), true) == 0)
        {
          if (text4 != string.Empty)
            flag3 = true;
        }
        else if (string.Compare(text3, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), true) == 0 && text4 != string.Empty)
          flag4 = true;
      }
      if (!flag3 && !flag4)
      {
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter")} {EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter")}{EPShared.LocalRM.GetString("_And_")}{EPShared.LocalRM.GetString("ValidFields")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag3)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag4)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (this.m_nSeletedIndex < 0)
      {
        FamilyTypeContainer _Container = new FamilyTypeContainer();
        _Container.FamilyParameterList = new List<FamilyParameterWrapper>();
        string _strFamilyTypeName2 = string.Empty;
        string empty3 = string.Empty;
        string empty4 = string.Empty;
        if ((flag2 || flag1) && _strFamilyTypeName2 == string.Empty)
        {
          if (flag2 && flag1)
            _strFamilyTypeName2 = $"{str1}/{str2}";
          else if (flag2)
            _strFamilyTypeName2 = str1;
          else if (flag1)
            _strFamilyTypeName2 = str2;
          if (_Container.FamilyTypeWrapper == null)
            _Container.FamilyTypeWrapper = new FamilyTypeWrapper(_strFamilyTypeName2);
          else
            _Container.FamilyTypeWrapper.FamilyTypeName = _strFamilyTypeName2;
        }
        for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
        {
          StorageType _StorageType = (StorageType) 3;
          string name = this.m_ParameterListView.Items[index].SubItems[0].Name;
          string text = this.m_ParameterListView.Items[index].SubItems[0].Text;
          string _strParameterValue = this.m_ParameterListView.Items[index].SubItems[1].Text;
          if (string.Compare(text, EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), true) == 0)
          {
            string str3 = this.m_ParameterListView.Items[index].SubItems[1].Text;
            if (string.Compare(str3, EPShared.LocalRM.GetString("NotAvailableString"), true) == 0)
              str3 = "0.0";
            _StorageType = (StorageType) 2;
            if (string.Compare(text, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), true) == 0)
            {
              double _dReturnedDouble = 0.0;
              RevitGeometry.Units_ConvertStringToDouble(str3, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              _strParameterValue = ValueConversion.ToString(_dReturnedDouble);
            }
            else
              _strParameterValue = str3;
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("CostGenericFamilyParameter"), true) == 0)
          {
            _StorageType = (StorageType) 2;
            _strParameterValue = this.m_ParameterListView.Items[index].SubItems[1].Text;
          }
          if (string.Compare(text, EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), true) == 0)
            _strParameterValue = string.Empty;
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(text, name, _strParameterValue, _StorageType);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.RegionNameGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.UniqueIDGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.SiteworksIDFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), RevitParameters.SiteworksIDFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        this.m_FamilyTypeContainerList.Add(_Container);
      }
      else
      {
        string str4 = string.Empty;
        if ((flag2 || flag1) && str4 == string.Empty)
        {
          if (flag2 && flag1)
            str4 = $"{str1}/{str2}";
          else if (flag2)
            str4 = str1;
          else if (flag1)
            str4 = str2;
          this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName = str4;
        }
        for (int index1 = 0; index1 < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index1)
        {
          string displayName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].DisplayName;
          string parameterName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].ParameterName;
          if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
          {
            string empty5 = string.Empty;
            this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].Value = empty5;
          }
          else
          {
            for (int index2 = 0; index2 < this.m_ParameterListView.Items.Count; ++index2)
            {
              if (string.Compare(displayName, this.m_ParameterListView.Items[index2].SubItems[0].Text, true) == 0)
              {
                string str5 = this.m_ParameterListView.Items[index2].SubItems[1].Text;
                if (string.Compare(parameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
                {
                  double _dReturnedDouble = 0.0;
                  if (str5 != null && str5 != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), str5, true) == 0)
                    _dReturnedDouble = 0.0;
                  else if (str5 != null && str5 != string.Empty)
                    RevitGeometry.Units_ConvertStringToDouble(str5, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
                  str5 = ValueConversion.ToString(_dReturnedDouble);
                }
                if (str5 == null)
                  str5 = string.Empty;
                this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].Value = str5;
                break;
              }
            }
          }
        }
      }
    }
    else if (this.m_FamilyType == LandcaddID.PatioWalk)
    {
      bool flag5 = false;
      if (this.m_nSeletedIndex < 0)
        flag5 = this.IsDuplicateEdiging();
      bool flag6 = false;
      bool flag7 = false;
      bool flag8 = false;
      bool flag9 = false;
      int index3 = -1;
      for (int index4 = 0; index4 < this.m_ParameterListView.Items.Count; ++index4)
      {
        string text5 = this.m_ParameterListView.Items[index4].SubItems[0].Text;
        string text6 = this.m_ParameterListView.Items[index4].SubItems[1].Text;
        if (string.Compare(text5, EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty)
          {
            _strFamilyTypeName1 = text6;
            flag9 = true;
          }
        }
        else if (string.Compare(text5, EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty && string.Compare(text6, EPShared.LocalRM.GetString("YesString"), true) == 0)
            flag6 = true;
        }
        else if (string.Compare(text5, EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty && string.Compare(text6, EPShared.LocalRM.GetString("YesString"), true) == 0)
            flag7 = true;
        }
        else if (string.Compare(text5, EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty)
          {
            try
            {
              double _dReturnedDouble = 0.0;
              if (RevitGeometry.Units_ConvertStringToDouble(text6, this.m_Units, (UnitType) 0, ref _dReturnedDouble) && _dReturnedDouble > 0.0)
              {
                empty2 = ValueConversion.ToString(_dReturnedDouble);
                flag8 = true;
              }
              index3 = index4;
            }
            catch (Exception ex)
            {
              flag8 = false;
              index3 = index4;
            }
          }
        }
      }
      if (!flag9)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidTypeName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (flag6 && flag7 && !flag8)
      {
        string empty6 = string.Empty;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidEdgeWidth"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty6);
        this.m_ParameterListView.Items[index3].SubItems[1].Text = empty6;
        return;
      }
      if (!flag6 && !flag7 && flag8)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedEdgeMowingYes"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag6 && flag7)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoEdgingYesMowingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (flag6 && !flag7 && flag8)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedEdgeMowingYes"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag6 && flag7 && flag8)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoEdgingYesMowingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (flag6 && flag5)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateEdgeString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (this.m_nSeletedIndex < 0)
      {
        FamilyTypeContainer _Container = new FamilyTypeContainer();
        _Container.FamilyParameterList = new List<FamilyParameterWrapper>();
        string empty7 = string.Empty;
        string empty8 = string.Empty;
        string empty9 = string.Empty;
        for (int index5 = 0; index5 < this.m_ParameterListView.Items.Count; ++index5)
        {
          StorageType _StorageType = (StorageType) 3;
          string name = this.m_ParameterListView.Items[index5].SubItems[0].Name;
          string text = this.m_ParameterListView.Items[index5].SubItems[0].Text;
          string str6 = this.m_ParameterListView.Items[index5].SubItems[1].Text;
          if (string.Compare(text, EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), true) == 0)
            _Container.FamilyTypeWrapper = new FamilyTypeWrapper(_strFamilyTypeName1);
          else if (string.Compare(text, EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), true) == 0)
          {
            _StorageType = (StorageType) 2;
            double _dReturnedDouble = 0.0;
            if (str6 != null && str6 != string.Empty)
              RevitGeometry.Units_ConvertStringToDouble(str6, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
            str6 = ValueConversion.ToString(_dReturnedDouble);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), true) == 0)
          {
            _StorageType = (StorageType) 1;
            if (string.Compare(str6, EPShared.LocalRM.GetString("YesString"), true) == 0)
              str6 = "1";
            else if (string.Compare(str6, EPShared.LocalRM.GetString("NoString"), true) == 0)
              str6 = "0";
          }
          if (string.Compare(text, EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), true) == 0)
            str6 = string.Empty;
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(text, name, str6, _StorageType);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), RevitParameters.SiteworksIDFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        this.m_FamilyTypeContainerList.Add(_Container);
      }
      else
      {
        for (int index6 = 0; index6 < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index6)
        {
          string displayName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].DisplayName;
          string parameterName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].ParameterName;
          for (int index7 = 0; index7 < this.m_ParameterListView.Items.Count; ++index7)
          {
            if (string.Compare(displayName, this.m_ParameterListView.Items[index7].SubItems[0].Text, true) == 0)
            {
              string str7 = this.m_ParameterListView.Items[index7].SubItems[1].Text;
              if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0)
              {
                string empty10 = string.Empty;
                this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].Value = empty10;
              }
              else
              {
                if (string.Compare(parameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
                {
                  double _dReturnedDouble = 1.0;
                  if (str7 != null && str7 != string.Empty)
                    RevitGeometry.Units_ConvertStringToDouble(str7, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
                  str7 = ValueConversion.ToString(_dReturnedDouble);
                }
                if (string.Compare(parameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
                {
                  if (string.Compare(str7, EPShared.LocalRM.GetString("YesString"), true) == 0)
                    str7 = "1";
                  else if (string.Compare(str7, EPShared.LocalRM.GetString("NoString"), true) == 0)
                    str7 = "0";
                }
                if (str7 == null)
                  str7 = string.Empty;
                if (string.Compare(parameterName, RevitParameters.MaterialPathWalkFamilyParameter, true) == 0 && str7 != string.Empty)
                  this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName = str7;
                this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].Value = str7;
                break;
              }
            }
          }
        }
      }
    }
    else
    {
      QuantumListView quantumListView;
      if (this.m_FamilyType == LandcaddID.Street)
      {
        this.UpdateGlobalListView();
        quantumListView = this.m_GlobalListView;
      }
      else
        quantumListView = this.m_ParameterListView;
      string str8 = string.Empty;
      for (int index = 0; index < quantumListView.Items.Count; ++index)
      {
        string text7 = quantumListView.Items[index].SubItems[0].Text;
        string text8 = quantumListView.Items[index].SubItems[1].Text;
        if (string.Compare(text7, EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), true) == 0)
        {
          if (string.IsNullOrEmpty(text8))
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("TypeNameMissing"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
          str8 = text8;
          break;
        }
      }
      FamilyTypeContainer _Container = new FamilyTypeContainer();
      _Container.FamilyParameterList = new List<FamilyParameterWrapper>();
      bool flag10 = true;
      if (this.IsFamilyAndTypeNameSame(str8))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SameTypeNameAsFamilyNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (this.m_nSeletedIndex < 0)
      {
        _Container.FamilyParameterList = new List<FamilyParameterWrapper>();
        _Container.FamilyTypeWrapper = (FamilyTypeWrapper) null;
      }
      else
      {
        _Container.FamilyTypeWrapper = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyTypeWrapper;
        _Container.FamilyParameterList = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList;
      }
      if (_Container.FamilyTypeWrapper != null && string.Compare(_Container.FamilyTypeWrapper.FamilyTypeName, str8, true) == 0)
        flag10 = false;
      if (flag10 && this.CheckForDuplicateTypeName(str8))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateTypeNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (_Container.FamilyTypeWrapper == null)
        _Container.FamilyTypeWrapper = new FamilyTypeWrapper(str8);
      else
        _Container.FamilyTypeWrapper.FamilyTypeName = str8;
      string strValue = string.Empty;
      string empty11 = string.Empty;
      string empty12 = string.Empty;
      for (int index8 = 0; index8 < quantumListView.Items.Count; ++index8)
      {
        StorageType _StorageType = (StorageType) 3;
        string str9 = quantumListView.Items[index8].SubItems[0].Name;
        string text = quantumListView.Items[index8].SubItems[0].Text;
        strValue = quantumListView.Items[index8].SubItems[1].Text;
        if (string.Compare(text, EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), true) != 0)
        {
          if (string.Compare(text, EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("LinearIncrementParameter"), false) == 0)
          {
            str9 = RevitParameters.LinearIncrementParameter;
            text = EPShared.LocalRM.GetString("LinearIncrementParameter");
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("Slope_") + EPShared.LocalRM.GetString("CurveIncrementParameter"), false) == 0)
          {
            str9 = RevitParameters.CurveIncrementParameter;
            text = EPShared.LocalRM.GetString("CurveIncrementParameter");
          }
          if (string.Compare(text, EPShared.LocalRM.GetString("LinearIncrementParameter"), true) == 0)
          {
            _StorageType = (StorageType) 2;
            double _dReturnedDouble = 0.0;
            if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
              _dReturnedDouble = 0.0;
            else if (strValue != null && strValue != string.Empty)
              RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
            strValue = ValueConversion.ToString(_dReturnedDouble);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("CurveIncrementParameter"), true) == 0)
          {
            _StorageType = (StorageType) 2;
            double _dValue = 0.0;
            if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
              _dValue = 0.0;
            else if (strValue != null && strValue != string.Empty)
              _dValue = RevitGeometry.eplGeoE_ConvertAngleToRadians(strValue);
            strValue = ValueConversion.ToString(_dValue);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("CostGenericFamilyParameter"), true) == 0)
            _StorageType = (StorageType) 2;
          else if (string.Compare(text, EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), true) == 0)
          {
            strValue = this.m_FamilyType.ToString("000");
            _StorageType = (StorageType) 3;
          }
          KeyValuePair<int, Material> keyValuePair;
          if (this.m_FamilyType == LandcaddID.Street)
          {
            if (string.Compare(text, EPShared.LocalRM.GetString("StreetNumberOfLanesParameter"), true) == 0)
              _StorageType = (StorageType) 1;
            else if (string.Compare(text, EPShared.LocalRM.GetString("StreetCurbDisplayParameter"), true) == 0)
            {
              _StorageType = (StorageType) 1;
              if (string.Compare(strValue, EPShared.LocalRM.GetString("YesString"), true) == 0)
                strValue = "1";
              else if (string.Compare(strValue, EPShared.LocalRM.GetString("NoString"), true) == 0)
                strValue = "0";
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCurbMaterialParameter"), true) == 0)
            {
              _StorageType = (StorageType) 1;
              Dictionary<int, Material> dictionary = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strValue, false) == 0)).ToDictionary<Material, int>((Func<Material, int>) (p => ((Element) p).Id.IntegerValue));
              if (dictionary.Count >= 1)
              {
                keyValuePair = dictionary.ElementAt<KeyValuePair<int, Material>>(0);
                strValue = ((Element) keyValuePair.Value).Id.IntegerValue.ToString();
              }
              else
                strValue = "00000";
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("StreetCrossSlopeParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetGutterSlopeParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCutSlopeParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetFillSlopeParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && !RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
                _dReturnedDouble = 0.0;
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("StreetLaneWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetPavementDepthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetGutterWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCurbWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCurbHeightParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetBoulevardWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetBaseSurfaceParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
                _dReturnedDouble = 0.0;
              else if (strValue != null && strValue != string.Empty)
                RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
          }
          else if (this.m_FamilyType == LandcaddID.SoftTerrain)
          {
            if (string.Compare(text, EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && !RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
                _dReturnedDouble = 0.0;
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("SoftTerrainLeftOffsetWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SoftTerrainRightOffsetWidthParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
                _dReturnedDouble = 0.0;
              else if (strValue != null && strValue != string.Empty)
                RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
          }
          else if (this.m_FamilyType == LandcaddID.Curb)
          {
            if (string.Compare(text, EPShared.LocalRM.GetString("StreetGutterSlopeParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && !RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
                _dReturnedDouble = 0.0;
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("StreetCurbHeightParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("CurbGutterHeightParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetCurbWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("StreetGutterWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("CurbBaseSurfaceParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("CurbSubbaseSurfaceParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
                _dReturnedDouble = 0.0;
              else if (strValue != null && strValue != string.Empty)
                RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("StreetCurbMaterialParameter"), true) == 0)
            {
              _StorageType = (StorageType) 1;
              Dictionary<int, Material> dictionary = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strValue, false) == 0)).ToDictionary<Material, int>((Func<Material, int>) (p => ((Element) p).Id.IntegerValue));
              if (dictionary.Count >= 1)
              {
                keyValuePair = dictionary.ElementAt<KeyValuePair<int, Material>>(0);
                strValue = ((Element) keyValuePair.Value).Id.IntegerValue.ToString();
              }
              else
                strValue = "00000";
            }
          }
          else if (this.m_FamilyType == LandcaddID.Sidewalk)
          {
            if (string.Compare(text, EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), true) != 0 && string.Compare(text, EPShared.LocalRM.GetString("SideWalkLocationLineParameter"), true) != 0)
            {
              if (string.Compare(text, EPShared.LocalRM.GetString("SideWalkLocationLineParameter"), true) == 0)
              {
                _StorageType = (StorageType) 1;
                if (string.Compare(strValue, EPShared.LocalRM.GetString("SideString"), true) == 0)
                  strValue = "1";
                else if (string.Compare(strValue, EPShared.LocalRM.GetString("CenterString"), true) == 0)
                  strValue = "0";
              }
              else if (string.Compare(text, EPShared.LocalRM.GetString("SideWalkPavementSurfaceParameter"), true) == 0)
              {
                _StorageType = (StorageType) 1;
                Dictionary<int, Material> dictionary = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strValue, false) == 0)).ToDictionary<Material, int>((Func<Material, int>) (p => ((Element) p).Id.IntegerValue));
                if (dictionary.Count >= 1)
                {
                  keyValuePair = dictionary.ElementAt<KeyValuePair<int, Material>>(0);
                  strValue = ((Element) keyValuePair.Value).Id.IntegerValue.ToString();
                }
                else
                  strValue = "00000";
              }
              else if (string.Compare(text, EPShared.LocalRM.GetString("SideWalkPavementDepthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SideWalkBaseSurfaceParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SideWalkSubbaseSurfaceParameter"), true) == 0)
              {
                _StorageType = (StorageType) 2;
                double _dReturnedDouble = 0.0;
                if (strValue != null && strValue != string.Empty)
                  RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
                strValue = ValueConversion.ToString(_dReturnedDouble);
              }
              else if (string.Compare(text, EPShared.LocalRM.GetString("SideWalkWidthParameter"), true) == 0)
              {
                _StorageType = (StorageType) 2;
                double _dReturnedDouble = 0.0;
                if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
                  _dReturnedDouble = 0.0;
                else if (strValue != null && strValue != string.Empty)
                  RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
                strValue = ValueConversion.ToString(_dReturnedDouble);
              }
              else if (string.Compare(text, EPShared.LocalRM.GetString("SideWalkCutSlopeParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SideWalkFillSlopeParameter"), true) == 0)
              {
                _StorageType = (StorageType) 2;
                double _dReturnedDouble = 0.0;
                if (strValue != null && strValue != string.Empty && !RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
                  _dReturnedDouble = 0.0;
                strValue = ValueConversion.ToString(_dReturnedDouble);
              }
            }
            else
              continue;
          }
          else if (this.m_FamilyType == LandcaddID.RetainingWall)
          {
            if (string.Compare(text, EPShared.LocalRM.GetString("RetainingWallSlopeProjectionParameter"), true) == 0)
            {
              _StorageType = (StorageType) 1;
              if (string.Compare(strValue, EPShared.LocalRM.GetString("YesString"), true) == 0)
                strValue = "1";
              else if (string.Compare(strValue, EPShared.LocalRM.GetString("NoString"), true) == 0)
                strValue = "0";
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("RetainingWallMaterialParameter"), true) == 0)
            {
              _StorageType = (StorageType) 1;
              Dictionary<int, Material> dictionary = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strValue, false) == 0)).ToDictionary<Material, int>((Func<Material, int>) (p => ((Element) p).Id.IntegerValue));
              if (dictionary.Count >= 1)
              {
                keyValuePair = dictionary.ElementAt<KeyValuePair<int, Material>>(0);
                strValue = ((Element) keyValuePair.Value).Id.IntegerValue.ToString();
              }
              else
                strValue = "00000";
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("RetainingWallCutSlopeParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("RetainingWallFillSlopeParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && !RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
                _dReturnedDouble = 0.0;
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("RetainingWallWidthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("RetainingWallHeightParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("RetainingWallBaseSurfaceParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("RetainingWallSubbaseSurfaceParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
                _dReturnedDouble = 0.0;
              else if (strValue != null && strValue != string.Empty)
                RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
          }
          else if (this.m_FamilyType == LandcaddID.ParkingLot)
          {
            if (string.Compare(text, EPShared.LocalRM.GetString("ParkingLotParkingPavementSurfaceParameter"), true) == 0)
            {
              _StorageType = (StorageType) 1;
              Dictionary<int, Material> dictionary = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strValue, false) == 0)).ToDictionary<Material, int>((Func<Material, int>) (p => ((Element) p).Id.IntegerValue));
              if (dictionary.Count >= 1)
              {
                keyValuePair = dictionary.ElementAt<KeyValuePair<int, Material>>(0);
                strValue = ((Element) keyValuePair.Value).Id.IntegerValue.ToString();
              }
              else
                strValue = "00000";
            }
            else if (string.Compare(text, EPShared.LocalRM.GetString("ParkingLotPavementDepthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("ParkingLotParkingBaseDepthParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("ParkingLotParkingSubBaseDepthParameter"), true) == 0)
            {
              _StorageType = (StorageType) 2;
              double _dReturnedDouble = 0.0;
              if (strValue != null && strValue != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), strValue, true) == 0)
                _dReturnedDouble = 0.0;
              else if (strValue != null && strValue != string.Empty)
                RevitGeometry.Units_ConvertStringToDouble(strValue, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              strValue = ValueConversion.ToString(_dReturnedDouble);
            }
          }
          if (this.m_nSeletedIndex < 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(text, str9, strValue, _StorageType);
            _Container.FamilyParameterList.Add(parameterWrapper);
          }
          else
          {
            for (int index9 = 0; index9 < _Container.FamilyParameterList.Count; ++index9)
            {
              if (string.Compare(_Container.FamilyParameterList[index9].ParameterName, str9, true) == 0)
              {
                _Container.FamilyParameterList[index9].Value = strValue;
                break;
              }
            }
          }
        }
      }
      if (this.m_nSeletedIndex < 0)
      {
        if (!this.FindParameter(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), RevitParameters.SiteworksIDFamilyParameter, Convert.ToInt32((object) this.m_FamilyType).ToString("000"), (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        this.m_FamilyTypeContainerList.Add(_Container);
      }
    }
    this.DialogResult = DialogResult.OK;
  }

  private bool IsFamilyAndTypeNameSame(string _strTypeName)
  {
    return string.Compare(_strTypeName, this.m_strFamilyName, false) == 0;
  }

  private bool CheckForDuplicateTypeName(string _strTypeName)
  {
    int num = 0;
    foreach (FamilyTypeContainer familyTypeContainer in this.m_FamilyTypeContainerList)
    {
      if (string.Compare(_strTypeName, familyTypeContainer.FamilyTypeWrapper.FamilyTypeName, true) == 0)
      {
        if (this.m_nSeletedIndex < 0 || num != this.m_nSeletedIndex)
          return true;
        ++num;
      }
      else
        ++num;
    }
    return false;
  }

  private bool IsDuplicateEdiging()
  {
    for (int index1 = 0; index1 < this.m_FamilyTypeContainerList.Count; ++index1)
    {
      int count = this.m_FamilyTypeContainerList[index1].FamilyParameterList.Count;
      for (int index2 = 0; index2 < count; ++index2)
      {
        if (string.Compare(this.m_FamilyTypeContainerList[index1].FamilyParameterList[index2].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 && string.Compare(this.m_FamilyTypeContainerList[index1].FamilyParameterList[index2].Value, "1", true) == 0)
          return true;
      }
    }
    return false;
  }

  private void OnButtonCancelClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private bool FindParameter(string _strValue, FamilyTypeContainer _Container)
  {
    string empty = string.Empty;
    for (int index = 0; index < _Container.FamilyParameterList.Count; ++index)
    {
      if (string.Compare(_Container.FamilyParameterList[index].ParameterName, _strValue, true) == 0)
        return true;
    }
    return false;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.m_UnitLabel = new Label();
    this.m_StreetTabControl = new TabControl();
    this.m_SlopeComboBox = new ComboBox();
    this.SuspendLayout();
    this.m_ButtonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ButtonOk.Location = new Point(299, 344);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 0;
    this.m_ButtonOk.Text = "&OK";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnButtonOkClicked);
    this.m_ButtonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ButtonCancel.Location = new Point(380, 344);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 1;
    this.m_ButtonCancel.Text = "&Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnButtonCancelClicked);
    this.m_UnitLabel.Location = new Point(0, 0);
    this.m_UnitLabel.Name = "m_UnitLabel";
    this.m_UnitLabel.Size = new Size(100, 23);
    this.m_UnitLabel.TabIndex = 0;
    this.m_SlopeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_SlopeComboBox.FormattingEnabled = true;
    this.m_SlopeComboBox.Location = new Point(190, 53);
    this.m_SlopeComboBox.Name = "m_PhaseComboBox";
    this.m_SlopeComboBox.Size = new Size(129, 21);
    this.m_SlopeComboBox.TabIndex = 4;
    this.m_StreetTabControl.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_StreetTabControl.Location = new Point(0, 0);
    this.m_StreetTabControl.Name = "m_StreetTabControl";
    this.m_StreetTabControl.SelectedIndex = 0;
    this.m_StreetTabControl.Size = new Size(200, 100);
    this.m_StreetTabControl.TabIndex = 0;
    this.m_StreetTabControl.SelectedIndexChanged += new EventHandler(this.StreetTabControlTabIndexChanged);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(456, 379);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (AddModifyFamilyForm);
    this.Text = "AddModifyFamily";
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }

  private enum FormForAddOrModify
  {
    Add,
    Modify,
  }
}
