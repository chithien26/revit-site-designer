﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.CopyFamilyForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class CopyFamilyForm : EPForm
{
  private FamilyBinder m_CurrentFamilyBinder;
  private Document m_CurrentDocument;
  private LandcaddID m_CurrentFamilyType = LandcaddID.Street;
  private string m_strNewPath = string.Empty;
  private IContainer components;
  private GroupBox m_AddFamilyGroupBox;
  private Button m_FileBtn;
  private Label m_PathLbl;
  private TextBox m_FileTxt;
  private Button m_CancelButton;
  private Button m_OkButton;
  private Label m_CurrentFamilyTextLbl;
  private Label m_CurrentFamilyNameLbl;

  public CopyFamilyForm(
    FamilyBinder _CurrentFamily,
    Document _CurDocument,
    LandcaddID _CurrentFamilyType)
  {
    this.InitializeComponent();
    this.m_CurrentFamilyBinder = _CurrentFamily;
    this.m_CurrentDocument = _CurDocument;
    this.m_CurrentFamilyType = _CurrentFamilyType;
    this.m_OkButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    string empty = string.Empty;
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.PlantMix:
        empty = ApplicationUtility.GetString("");
        break;
      case LandcaddID.PatioWalk:
        empty = ApplicationUtility.GetString("");
        break;
      case LandcaddID.SoftTerrain:
        empty = EPShared.LocalRM.GetString("SoftTerrainManagerString");
        this.ContextualHelpID = "HID_SDfamilyCopySoftTerrain";
        break;
      case LandcaddID.Street:
        empty = EPShared.LocalRM.GetString("StreetTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyCopyStreet";
        break;
      case LandcaddID.Curb:
        empty = EPShared.LocalRM.GetString("CurbTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyCopyCurb";
        break;
      case LandcaddID.Sidewalk:
        empty = EPShared.LocalRM.GetString("SidewalkTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyCopySidewalk";
        break;
      case LandcaddID.RetainingWall:
        empty = EPShared.LocalRM.GetString("RetainingWallManagerString");
        this.ContextualHelpID = "HID_SDfamilyCopyRetainingWall";
        break;
      case LandcaddID.Steps:
        empty = EPShared.LocalRM.GetString("StepsManagerString");
        break;
      case LandcaddID.ParkingLot:
        empty = EPShared.LocalRM.GetString("ParkingLotManagerString");
        this.ContextualHelpID = "HID_SDfamilyCopyParkinglot";
        break;
    }
    this.Text = $"{EPShared.LocalRM.GetString("Copy_")}{empty} {EPShared.LocalRM.GetString("FamilyString")}";
    this.m_AddFamilyGroupBox.Text = EPShared.LocalRM.GetString("Copy_") + empty + EPShared.LocalRM.GetString("_Family_");
    this.m_PathLbl.Text = EPShared.LocalRM.GetString("Family_AMP_Name_CopyFamilyDialog");
    this.m_CurrentFamilyNameLbl.Text = EPShared.LocalRM.GetString("CurrentFamilyNameString");
    this.m_CurrentFamilyTextLbl.Text = _CurrentFamily.FamilyName;
    this.m_FileTxt.Text = this.GetPathString(_CurrentFamily.FamilyPath);
    this.GetDialogPosition();
  }

  private string GetPathString(string _strPath)
  {
    string pathString = _strPath;
    if (pathString != string.Empty)
    {
      string fileName = Path.GetFileName(_strPath);
      pathString = $"{Path.GetDirectoryName(_strPath)}\\Copy of {fileName}";
    }
    return pathString;
  }

  private void OkButtonClicked(object sender, EventArgs e)
  {
    if (this.VerifyFileNameAndPath())
    {
      if (this.m_FileTxt.Text.LastIndexOf("\\") < 0)
      {
        string empty = string.Empty;
        RevitUtility.GetFullFamilyFilenameIfExist(string.Empty, ref empty);
        string text = this.m_FileTxt.Text;
        this.m_FileTxt.Text = empty + text;
      }
      string str = this.m_FileTxt.Text.Substring(this.m_FileTxt.Text.LastIndexOf("\\") + 1);
      str.Substring(0, str.LastIndexOf('.'));
      this.m_strNewPath = this.m_FileTxt.Text;
    }
    this.DialogResult = DialogResult.OK;
  }

  private bool VerifyFileNameAndPath()
  {
    if (string.IsNullOrEmpty(this.m_FileTxt.Text))
      return false;
    if (string.IsNullOrEmpty(this.m_FileTxt.Text))
    {
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Source")} {EPShared.LocalRM.GetString("NoRFAExtension")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (new FileInfo(this.m_FileTxt.Text).Extension == string.Empty)
      this.m_FileTxt.Text += ".rfa";
    return true;
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnFileBtnClicked(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_FileTxt.Text = saveFileDialog.FileName;
    string str = this.m_FileTxt.Text.Substring(this.m_FileTxt.Text.LastIndexOf("\\") + 1);
    str.Substring(0, str.LastIndexOf('.'));
  }

  private void OnFocusLost(object sender, EventArgs e)
  {
    if (!this.VerifyFileNameAndPath())
      return;
    this.m_strNewPath = this.m_FileTxt.Text;
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  public string NewPath => this.m_strNewPath;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_AddFamilyGroupBox = new GroupBox();
    this.m_CurrentFamilyTextLbl = new Label();
    this.m_CurrentFamilyNameLbl = new Label();
    this.m_FileBtn = new Button();
    this.m_PathLbl = new Label();
    this.m_FileTxt = new TextBox();
    this.m_CancelButton = new Button();
    this.m_OkButton = new Button();
    this.m_AddFamilyGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_AddFamilyGroupBox.Controls.Add((Control) this.m_CurrentFamilyTextLbl);
    this.m_AddFamilyGroupBox.Controls.Add((Control) this.m_CurrentFamilyNameLbl);
    this.m_AddFamilyGroupBox.Controls.Add((Control) this.m_FileBtn);
    this.m_AddFamilyGroupBox.Controls.Add((Control) this.m_PathLbl);
    this.m_AddFamilyGroupBox.Controls.Add((Control) this.m_FileTxt);
    this.m_AddFamilyGroupBox.Location = new Point(12, 12);
    this.m_AddFamilyGroupBox.Name = "m_AddFamilyGroupBox";
    this.m_AddFamilyGroupBox.Size = new Size(476, 71);
    this.m_AddFamilyGroupBox.TabIndex = 0;
    this.m_AddFamilyGroupBox.TabStop = false;
    this.m_AddFamilyGroupBox.Text = "Copy Family";
    this.m_CurrentFamilyTextLbl.AutoSize = true;
    this.m_CurrentFamilyTextLbl.Location = new Point(137, 25);
    this.m_CurrentFamilyTextLbl.Name = "m_CurrentFamilyTextLbl";
    this.m_CurrentFamilyTextLbl.Size = new Size(35, 13);
    this.m_CurrentFamilyTextLbl.TabIndex = 1;
    this.m_CurrentFamilyTextLbl.Text = "label2";
    this.m_CurrentFamilyNameLbl.AutoSize = true;
    this.m_CurrentFamilyNameLbl.Location = new Point(6, 25);
    this.m_CurrentFamilyNameLbl.Name = "m_CurrentFamilyNameLbl";
    this.m_CurrentFamilyNameLbl.Size = new Size(104, 13);
    this.m_CurrentFamilyNameLbl.TabIndex = 0;
    this.m_CurrentFamilyNameLbl.Text = "Current Family Name";
    this.m_FileBtn.Location = new Point(446, 45);
    this.m_FileBtn.Name = "m_FileBtn";
    this.m_FileBtn.Size = new Size(24, 20);
    this.m_FileBtn.TabIndex = 4;
    this.m_FileBtn.Text = "...";
    this.m_FileBtn.UseVisualStyleBackColor = true;
    this.m_FileBtn.Click += new EventHandler(this.OnFileBtnClicked);
    this.m_PathLbl.AutoSize = true;
    this.m_PathLbl.Location = new Point(6, 48 /*0x30*/);
    this.m_PathLbl.Name = "m_PathLbl";
    this.m_PathLbl.Size = new Size(92, 13);
    this.m_PathLbl.TabIndex = 2;
    this.m_PathLbl.Text = "New Family Name";
    this.m_FileTxt.Location = new Point(140, 45);
    this.m_FileTxt.Name = "m_FileTxt";
    this.m_FileTxt.Size = new Size(300, 20);
    this.m_FileTxt.TabIndex = 3;
    this.m_FileTxt.Leave += new EventHandler(this.OnFocusLost);
    this.m_CancelButton.Location = new Point(413, 89);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 2;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClicked);
    this.m_OkButton.Location = new Point(332, 89);
    this.m_OkButton.Name = "m_OkButton";
    this.m_OkButton.Size = new Size(75, 23);
    this.m_OkButton.TabIndex = 1;
    this.m_OkButton.Text = "Ok";
    this.m_OkButton.UseVisualStyleBackColor = true;
    this.m_OkButton.Click += new EventHandler(this.OkButtonClicked);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(502, 120);
    this.Controls.Add((Control) this.m_AddFamilyGroupBox);
    this.Controls.Add((Control) this.m_OkButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (CopyFamilyForm);
    this.Text = nameof (CopyFamilyForm);
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.m_AddFamilyGroupBox.ResumeLayout(false);
    this.m_AddFamilyGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_OkButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
