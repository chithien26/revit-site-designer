﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilySymbolContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class FamilySymbolContainer
{
  private FamilySymbol m_FamilySymbol;
  private string m_ServiceLife;
  private string m_MaxHeight;
  private string m_MaxWidth;

  public FamilySymbolContainer()
  {
    this.m_ServiceLife = EPShared.LocalRM.GetString("NotAvailableString");
    this.m_MaxWidth = EPShared.LocalRM.GetString("NotAvailableString");
    this.m_MaxWidth = EPShared.LocalRM.GetString("NotAvailableString");
  }

  public FamilySymbol FamilySymbol
  {
    get => this.m_FamilySymbol;
    set => this.m_FamilySymbol = value;
  }

  public string ServiceLife
  {
    get => this.m_ServiceLife;
    set => this.m_ServiceLife = value;
  }

  public string MaxHeight
  {
    get => this.m_MaxHeight;
    set => this.m_MaxHeight = value;
  }

  public string MaxWidth
  {
    get => this.m_MaxWidth;
    set => this.m_MaxWidth = value;
  }
}
