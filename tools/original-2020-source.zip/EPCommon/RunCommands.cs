﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RunCommands
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Automation;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class RunCommands
{
  private AutomationElement m_RootElement;
  private Dictionary<int, string> m_CatalogForPinnacle = new Dictionary<int, string>();
  private Dictionary<int, string> m_CatalogForRevit = new Dictionary<int, string>();
  private RunCommands.PinnacleCallBack m_PinnacleExecuteCommandDelegate;
  private RunCommands.ApplicationInstalled m_ApplicationInstalled = RunCommands.ApplicationInstalled.NONE;
  private bool m_bUseTimer;
  private Timer m_WaitTimer = new Timer();
  private int m_nCommandID = -1;
  private IntPtr m_PinnacleClientHandle = IntPtr.Zero;
  private bool m_bPinnacleInstalled;
  private string m_strPreviousPath = string.Empty;

  public void epl_SetRevitVersion(RevitVersion _RevitVersion, bool _bIs64BitInstall)
  {
    if (Process.GetCurrentProcess().MainModule.FileName.IndexOf("Architecture") > 0 || Process.GetCurrentProcess().MainModule.FileName.IndexOf("Structure") > 0 || Process.GetCurrentProcess().MainModule.FileName.IndexOf("MEP") > 0)
      this.m_ApplicationInstalled = RunCommands.ApplicationInstalled.REVIT_INSTALLED;
    else if (Process.GetCurrentProcess().MainModule.FileName.IndexOf("Revit") > 0)
      this.m_ApplicationInstalled = RunCommands.ApplicationInstalled.REVIT_INSTALLED;
    this.m_CatalogForRevit.Clear();
    this.m_CatalogForPinnacle.Clear();
    this.GetRootElement();
    this.ParseCatalogFile(_bIs64BitInstall);
    this.m_PinnacleExecuteCommandDelegate = new RunCommands.PinnacleCallBack(this.InvokePinnacleCmd);
    if (this.m_bPinnacleInstalled)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string _strDisplay = $"Sitesworks for Revit {ApplicationUtility.RevitVersion}";
      string _strClientCode = $"EGPTSWREVIT{ApplicationUtility.RevitVersion}";
      try
      {
        if (!_bIs64BitInstall)
        {
          this.m_PinnacleClientHandle = RunCommands.Externalx86.Pinnacle_RegisterClient(_strDisplay, _strClientCode, this.m_PinnacleExecuteCommandDelegate);
          foreach (KeyValuePair<int, string> keyValuePair in this.m_CatalogForPinnacle)
            RunCommands.Externalx86.Pinnacle_AddCommand(this.m_PinnacleClientHandle, keyValuePair.Value, keyValuePair.Key);
        }
        else
        {
          this.m_PinnacleClientHandle = RunCommands.Externalx64.Pinnacle_RegisterClient(_strDisplay, _strClientCode, this.m_PinnacleExecuteCommandDelegate);
          foreach (KeyValuePair<int, string> keyValuePair in this.m_CatalogForPinnacle)
            RunCommands.Externalx64.Pinnacle_AddCommand(this.m_PinnacleClientHandle, keyValuePair.Value, keyValuePair.Key);
        }
      }
      catch (Exception ex)
      {
      }
    }
    this.m_WaitTimer.Interval = 2000;
    this.m_WaitTimer.Tick += new EventHandler(this.WaitTimerCallBack);
  }

  private void WaitTimerCallBack(object sender, EventArgs e)
  {
    this.m_WaitTimer.Stop();
    this.m_bUseTimer = false;
    this.InvokePinnacleCmd(this.m_nCommandID);
    this.m_nCommandID = -1;
  }

  private void ParseCatalogFile(bool _bIs64BitInstall)
  {
    try
    {
      this.m_strPreviousPath = Environment.GetEnvironmentVariable("PATH");
      string empty1 = string.Empty;
      RegistryKey registryKey1 = Registry.CurrentUser.OpenSubKey("Software\\Eagle Point Software\\Pinnacle Series\\Pinnacle", false);
      switch (registryKey1)
      {
        case null:
        case null:
          if (empty1 == string.Empty)
          {
            RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("Software\\Eagle Point Software\\Pinnacle Series", false);
            if (registryKey2 != null)
            {
              object obj = registryKey2.GetValue("InstallLocation");
              if (obj != null)
                empty1 = obj.ToString();
              registryKey2.Close();
            }
          }
          if (empty1 != string.Empty)
          {
            if (!empty1.EndsWith("\\"))
              empty1 += "\\";
            Environment.SetEnvironmentVariable("PATH", $"{this.m_strPreviousPath};{empty1}");
            this.IsPinnacleInstalled(_bIs64BitInstall, empty1);
          }
          string empty2 = string.Empty;
          string empty3 = string.Empty;
          if (this.m_ApplicationInstalled == RunCommands.ApplicationInstalled.REVIT_INSTALLED)
            EPShared.eplFilP_GetSupportPath("SiteDesignerForRevit.clg", ref empty3);
          if (!File.Exists(empty3))
            break;
          using (StreamReader streamReader = new StreamReader(empty3))
          {
            string str1;
            while ((str1 = streamReader.ReadLine()) != null)
            {
              if (!str1.StartsWith("#") && !(str1 == string.Empty))
              {
                string[] strArray = str1.Split(';');
                if (strArray.Length > 2)
                {
                  this.m_CatalogForPinnacle.Add((int) Convert.ToInt16(strArray[0]), strArray[1]);
                  string str2 = strArray[2];
                  if (str2.IndexOf("FlyoutButtonExecute") > 0)
                    str2.Replace("FlyoutButtonExecute", "DropDownButtonBuddy");
                  this.m_CatalogForRevit.Add((int) Convert.ToInt16(strArray[0]), str2);
                }
              }
            }
            break;
          }
        default:
          object obj1 = registryKey1.GetValue("ProgramPath");
          if (obj1 != null)
            empty1 = obj1.ToString();
          registryKey1.Close();
          goto case null;
      }
    }
    catch (Exception ex)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("CatalogFilesMissing"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
  }

  private void IsPinnacleInstalled(bool _bIs64BitInstall, string _strPinnacleLocation)
  {
    string str1 = _strPinnacleLocation;
    if (!File.Exists(_bIs64BitInstall ? str1 + "PSAPICLIENTx64.dll" : str1 + "PSAPICLIENTx86.dll"))
      return;
    string str2 = Environment.GetFolderPath(Environment.SpecialFolder.System) + "\\uiautomationcore.dll";
    if (!File.Exists(str2) || FileVersionInfo.GetVersionInfo(str2).FileMajorPart < 7)
      return;
    this.m_bPinnacleInstalled = true;
  }

  private void GetRootElement()
  {
    this.m_RootElement = this.FindElementByProcessId(Process.GetCurrentProcess().Id);
  }

  private int InvokePinnacleCmd(int _nCommandID)
  {
    if (this.m_CatalogForPinnacle.ContainsKey(_nCommandID))
    {
      this.InvokeCommand(this.m_CatalogForRevit[_nCommandID]);
      if (this.m_bUseTimer)
      {
        this.m_nCommandID = _nCommandID;
        this.m_WaitTimer.Start();
      }
    }
    return 0;
  }

  private void InvokeCommand(string _strElementName)
  {
    if (!(_strElementName != string.Empty))
      return;
    string[] strArray = _strElementName.Split('+');
    int index = 0;
    string empty = string.Empty;
    if (this.m_RootElement == (AutomationElement) null)
      return;
    while (index < strArray.Length)
    {
      string str1 = strArray[index];
      AutomationElement first1 = this.m_RootElement.FindFirst(TreeScope.Descendants, (Condition) new PropertyCondition(AutomationElement.AutomationIdProperty, (object) str1));
      if (first1 == (AutomationElement) null)
      {
        if (index > 1)
          this.m_bUseTimer = true;
        ++index;
      }
      else
      {
        if (first1 != (AutomationElement) null)
        {
          AutomationPattern[] supportedPatterns = first1.GetSupportedPatterns();
          bool flag1 = false;
          bool flag2 = false;
          bool flag3 = false;
          foreach (AutomationPattern pattern in supportedPatterns)
          {
            string str2 = first1.GetCurrentPattern(pattern).ToString();
            if (str2.IndexOf("TogglePattern") > 0)
            {
              flag1 = true;
            }
            else
            {
              if (str2.IndexOf("InvokePattern") > 0)
              {
                flag2 = true;
                break;
              }
              if (str2.IndexOf("SelectionItemPattern") > 0)
              {
                flag3 = true;
                break;
              }
            }
          }
          try
          {
            if (flag2)
            {
              if (first1.GetCurrentPattern(InvokePattern.Pattern) is InvokePattern currentPattern1)
                currentPattern1.Invoke();
            }
            else if (flag1)
            {
              if (first1.GetCurrentPattern(TogglePattern.Pattern) is TogglePattern currentPattern2)
                currentPattern2.Toggle();
            }
            else if (flag3)
            {
              if (first1.GetCurrentPattern(SelectionItemPattern.Pattern) is SelectionItemPattern currentPattern3)
              {
                currentPattern3.Select();
                AutomationElement first2 = this.m_RootElement.FindFirst(TreeScope.Subtree, (Condition) new AndCondition(new Condition[2]
                {
                  (Condition) new PropertyCondition(AutomationElement.AutomationIdProperty, (object) str1),
                  (Condition) new PropertyCondition(AutomationElement.ControlTypeProperty, (object) ControlType.Button)
                }));
                if (first2 != (AutomationElement) null)
                  (first2.GetCurrentPattern(InvokePattern.Pattern) as InvokePattern).Invoke();
              }
            }
          }
          catch (Exception ex)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("CommandInvokeFailed"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
          }
        }
        ++index;
      }
    }
  }

  private AutomationElement FindElementByProcessId(int pid)
  {
    AutomationElement elementByProcessId = (AutomationElement) null;
    PropertyCondition[] propertyConditionArray = new PropertyCondition[2]
    {
      new PropertyCondition(AutomationElement.ProcessIdProperty, (object) pid),
      new PropertyCondition(AutomationElement.IsKeyboardFocusableProperty, (object) true)
    };
    AndCondition andCondition = new AndCondition((Condition[]) propertyConditionArray);
    AutomationElementCollection all = AutomationElement.RootElement.FindAll(TreeScope.Children, (Condition) propertyConditionArray[0]);
    if (all.Count == 0)
      return (AutomationElement) null;
    if (all.Count == 1)
      return all[0];
    foreach (AutomationElement automationElement in all)
    {
      if (automationElement.Current.Name.Contains("Revit"))
        elementByProcessId = automationElement;
    }
    if (elementByProcessId == (AutomationElement) null)
      elementByProcessId = all[0];
    return elementByProcessId;
  }

  public void epl_UnloadHelper(bool _bIs64BitInstall)
  {
    if (this.m_bPinnacleInstalled)
    {
      if (!_bIs64BitInstall)
        RunCommands.Externalx86.Pinnacle_UnregisterClient(this.m_PinnacleClientHandle);
      else
        RunCommands.Externalx64.Pinnacle_UnregisterClient(this.m_PinnacleClientHandle);
    }
    EPShared.epl_UnloadHelper(_bIs64BitInstall);
    Environment.SetEnvironmentVariable("PATH", this.m_strPreviousPath);
  }

  public delegate int PinnacleCallBack(int _nCommandID);

  public enum ApplicationInstalled
  {
    NONE = -1, // 0xFFFFFFFF
    REVIT_INSTALLED = 1,
  }

  private class Externalx86
  {
    [DllImport("PSAPICLIENTx86.DLL", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
    public static extern IntPtr Pinnacle_RegisterClient(
      [MarshalAs(UnmanagedType.LPWStr)] string _strDisplay,
      [MarshalAs(UnmanagedType.LPWStr)] string _strClientCode,
      RunCommands.PinnacleCallBack _ExecutePinnacleCommand);

    [DllImport("PSAPICLIENTx86.DLL", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
    public static extern int Pinnacle_AddCommand(IntPtr _Handle, [MarshalAs(UnmanagedType.LPWStr)] string _strCmdName, int nCmdID);

    [DllImport("PSAPICLIENTx86.DLL", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
    public static extern void Pinnacle_UnregisterClient(IntPtr _Handle);
  }

  private class Externalx64
  {
    [DllImport("PSAPICLIENTx64.DLL", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
    public static extern IntPtr Pinnacle_RegisterClient(
      [MarshalAs(UnmanagedType.LPWStr)] string _strDisplay,
      [MarshalAs(UnmanagedType.LPWStr)] string _strClientCode,
      RunCommands.PinnacleCallBack _ExecutePinnacleCommand);

    [DllImport("PSAPICLIENTx64.DLL", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
    public static extern int Pinnacle_AddCommand(IntPtr _Handle, [MarshalAs(UnmanagedType.LPWStr)] string _strCmdName, int nCmdID);

    [DllImport("PSAPICLIENTx64.DLL", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
    public static extern void Pinnacle_UnregisterClient(IntPtr _Handle);
  }
}
