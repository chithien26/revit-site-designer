﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyInstanceComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class FamilyInstanceComparer : IComparer<FamilyInstance>
{
  private XYZ m_ProximityPoint;
  private bool m_bSortByProximity;

  public FamilyInstanceComparer(XYZ _ProximityPoint)
  {
    this.m_ProximityPoint = _ProximityPoint;
    this.m_bSortByProximity = true;
  }

  int IComparer<FamilyInstance>.Compare(FamilyInstance first, FamilyInstance second)
  {
    int num = 0;
    if (this.m_bSortByProximity)
    {
      if (first != null && ((Element) first).Location != null)
      {
        if (second != null && ((Element) second).Location != null)
        {
          LocationPoint location1 = ((Element) first).Location as LocationPoint;
          LocationPoint location2 = ((Element) second).Location as LocationPoint;
          num = Math.Sqrt(Math.Pow(this.m_ProximityPoint.X - location1.Point.X, 2.0) + Math.Pow(this.m_ProximityPoint.Y - location1.Point.Y, 2.0)).CompareTo(Math.Sqrt(Math.Pow(this.m_ProximityPoint.X - location2.Point.X, 2.0) + Math.Pow(this.m_ProximityPoint.Y - location2.Point.Y, 2.0)));
        }
        else
          num = -1;
      }
      else if (second != null && ((Element) second).Location != null)
        num = 1;
    }
    return num;
  }
}
