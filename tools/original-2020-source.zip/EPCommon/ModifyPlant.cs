﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ModifyPlant
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ModifyPlant
{
  private Application m_CurApplication;
  private Document m_Document;
  private ModifyPlantForm m_DisplayForm;
  private List<FamilyContainer> m_PlantFamilyList;
  private List<FamilyContainer> m_ExistingPlantFamilyList;
  private EPTransactionContainer m_TransactionContainer;

  public ModifyPlant(Document _CurDocument)
  {
    this.m_CurApplication = _CurDocument.Application;
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_PlantFamilyList = new List<FamilyContainer>();
    this.m_ExistingPlantFamilyList = new List<FamilyContainer>();
    this.InitializeListData();
  }

  public void PopulateFamilyAndSymbolLists() => this.PopulateFamilyAndSymbolLists(false);

  private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
  {
    this.m_PlantFamilyList.Clear();
    FilteredElementIterator elementIterator = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001360).GetElementIterator();
    List<Element> list = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements().ToList<Element>();
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
    Eps_Point _SecondCheckPnt = new Eps_Point();
    elementIterator.Reset();
    while (elementIterator.MoveNext())
    {
      if (elementIterator.Current is FamilySymbol current && ((Element) current).Category != null && ((Element) current).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
      {
        List<Eps_Point> _PointList = (List<Eps_Point>) null;
        foreach (Element element in list)
        {
          if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) current).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
          {
            if (_PointList == null)
              _PointList = new List<Eps_Point>();
            Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
            if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
              _PointList.Add(_FindPoint);
          }
        }
        if (_PointList != null && _PointList.Count > 0)
        {
          bool flag = true;
          while (flag)
          {
            flag = false;
            for (int index = 0; index < _PointList.Count; ++index)
            {
              if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index], _SecondCheckPnt))
              {
                ++_SecondCheckPnt.z;
                flag = true;
                break;
              }
            }
          }
        }
        bool flag1 = false;
        for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
        {
          if (string.Compare(this.m_PlantFamilyList[index].FamilyName, ((Element) current.Family).Name, true) == 0)
          {
            this.m_PlantFamilyList[index].FamilySymbolList.Add(current);
            flag1 = true;
            break;
          }
        }
        if (!flag1)
          this.m_PlantFamilyList.Add(new FamilyContainer(((Element) current.Family).Name)
          {
            FamilySymbolList = {
              current
            }
          });
      }
    }
    this.m_TransactionContainer.Rollback();
    string empty = string.Empty;
    if (_bCheckForFamily && this.m_PlantFamilyList.Count == 0)
    {
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(this.m_Document.PathName, "ModifyPlants", EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("LoadDefaultFamilyOption"),
        EPShared.LocalRM.GetString("ContinueWOLoadFamilyOption")
      });
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamilyOption"), true) == 0)
      {
        Family _Family = (Family) null;
        if (RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Conifer", "LC Conifers.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
              {
                bool flag = false;
                for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
                {
                  if (string.Compare(this.m_PlantFamilyList[index].FamilyName, ((Element) element.Family).Name, true) == 0)
                  {
                    this.m_PlantFamilyList[index].FamilySymbolList.Add(element);
                    flag = true;
                    break;
                  }
                }
                if (!flag)
                  this.m_PlantFamilyList.Add(new FamilyContainer(((Element) element.Family).Name)
                  {
                    FamilySymbolList = {
                      element
                    }
                  });
              }
            }
          }
        }
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
      this.m_PlantFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  private void InitializeListData()
  {
    this.PopulateFamilyAndSymbolLists(true);
    this.PopulateExistingPlantList();
  }

  private void PopulateExistingPlantList()
  {
    bool flag1 = false;
    bool flag2 = false;
    this.m_ExistingPlantFamilyList.Clear();
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements())
    {
      if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
      {
        for (int index1 = 0; index1 < this.m_ExistingPlantFamilyList.Count; ++index1)
        {
          if (string.Compare(this.m_ExistingPlantFamilyList[index1].FamilyName, ((Element) familyInstance.Symbol.Family).Name, true) == 0)
          {
            for (int index2 = 0; index2 < this.m_ExistingPlantFamilyList[index1].FamilySymbolList.Count; ++index2)
            {
              if (string.Compare(((Element) this.m_ExistingPlantFamilyList[index1].FamilySymbolList[index2]).Name, ((Element) familyInstance.Symbol).Name, true) == 0)
              {
                flag2 = true;
                break;
              }
            }
            if (!flag2)
              this.m_ExistingPlantFamilyList[index1].FamilySymbolList.Add(familyInstance.Symbol);
            else
              flag2 = false;
            flag1 = true;
            break;
          }
        }
        if (!flag1)
          this.m_ExistingPlantFamilyList.Add(new FamilyContainer(((Element) familyInstance.Symbol.Family).Name)
          {
            FamilySymbolList = {
              familyInstance.Symbol
            }
          });
        else
          flag1 = false;
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index = 0; index < this.m_ExistingPlantFamilyList.Count; ++index)
      this.m_ExistingPlantFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    if (this.m_ExistingPlantFamilyList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ModifyPlantNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_DisplayForm = new ModifyPlantForm(this))
    {
      while (_DialogResult != DialogResult.Cancel)
      {
        flag = this.ShowDialog(ref _DialogResult);
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    return flag;
  }

  private bool GetFindSymbol()
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantMessage"), ref _Elements, true) || _Elements == null)
      return false;
    foreach (Element element in _Elements)
    {
      if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
      {
        this.m_DisplayForm.SetExistingPlantFamilyComboBox(((Element) familyInstance.Symbol.Family).Name);
        this.m_DisplayForm.SetExistingPlantNameComboBox(((Element) familyInstance.Symbol).Name);
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    return true;
  }

  private bool GetSinglePoint(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
      return false;
    this.m_Document.Regenerate();
    foreach (Element element in _Elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
      }
      else
      {
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    return true;
  }

  private bool GetWindowPoints(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
      return false;
    this.m_Document.Regenerate();
    foreach (Element element in _Elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
      }
    }
    return true;
  }

  private bool GetAllPointsWithType(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    IList<Element> elements = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements();
    if (elements == null || elements.Count == 0)
      return false;
    foreach (Element element in (IEnumerable<Element>) elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && this.m_DisplayForm.ExistingType != null && string.Compare(((Element) familyInstance.Symbol).Name, ((Element) this.m_DisplayForm.ExistingType).Name, true) == 0 && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
      }
    }
    return true;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    int num = (int) this.m_DisplayForm.ShowDialog();
    _DialogResult = this.m_DisplayForm.DialogResult;
    if (_DialogResult == DialogResult.Cancel)
      return false;
    if (_DialogResult == DialogResult.Retry)
      return this.GetFindSymbol();
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ModifyPlantsTransaction"));
    ElementSet _InstanceSet = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    if (this.m_DisplayForm.SelectionSetChecked)
    {
      if (!this.GetSinglePoint(ref _InstanceSet, ref _PointList))
        return false;
    }
    else if (this.m_DisplayForm.WindowSelectChecked)
    {
      if (!this.GetWindowPoints(ref _InstanceSet, ref _PointList))
        return false;
    }
    else if (this.m_DisplayForm.AllInstancesChecked && !this.GetAllPointsWithType(ref _InstanceSet, ref _PointList))
      return false;
    bool flag1 = true;
    bool flag2 = true;
    List<string> _PlacementIDList = new List<string>();
    string str = string.Empty;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _InstanceSet.Size;
    if (_InstanceSet.Size <= 0)
      progressBarForm.MaxValue = 1000;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSavingModifiedPlantsMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    this.m_TransactionContainer.BeginTransaction();
    foreach (Element element in _InstanceSet)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      if (this.m_DisplayForm.ModifyPlantTypeChecked)
      {
        Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
        if (parameter1 != null && parameter1.AsString() != string.Empty)
        {
          str = parameter1.AsString();
          if (!_PlacementIDList.Contains(str))
            _PlacementIDList.Add(str);
        }
        familyInstance.Symbol = this.m_DisplayForm.Type;
        Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
        if (parameter2 != null && str != string.Empty)
          parameter2.Set(str);
        str = string.Empty;
      }
      if (this.m_DisplayForm.ModifyPlantHeightChecked && Math.Abs(this.m_DisplayForm.PlantHeight) > 0.0 && flag1)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
        if (parameter != null)
          parameter.Set(this.m_DisplayForm.PlantHeight);
        else
          flag1 = false;
      }
      if (this.m_DisplayForm.ModifyPlantWidthChecked && Math.Abs(this.m_DisplayForm.PlantWidth) > 0.0 && flag2)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
        if (parameter != null)
          parameter.Set(this.m_DisplayForm.PlantWidth);
        else
          flag2 = false;
      }
      progressBarForm.UpdateProgressBar(1);
    }
    if (_PlacementIDList != null && _PlacementIDList.Count > 0)
      this.UpdatePlacementFamilyInstances(_PlacementIDList, ((Element) this.m_DisplayForm.Type).UniqueId);
    this.m_TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    this.PopulateExistingPlantList();
    return true;
  }

  private void UpdatePlacementFamilyInstances(List<string> _PlacementIDList, string _strSymbolID)
  {
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151);
    Parameter LandcaddIDParameter = (Parameter) null;
    FindFamilyInstance = (FamilyInstance) null;
    List<Element> list;
    try
    {
      list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (LandcaddIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    }
    catch (ApplicationException ex)
    {
      return;
    }
    LandcaddIDParameter = (Parameter) null;
    foreach (Element element in list)
    {
      if (element is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        LandcaddIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (LandcaddIDParameter != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0 && ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)
        {
          for (int index = 0; index < _PlacementIDList.Count; ++index)
          {
            if (string.Compare(((Element) familyInstance).UniqueId, _PlacementIDList[index], true) == 0)
            {
              Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
              if (parameter != null && !((APIObject) parameter).IsReadOnly)
                parameter.Set(_strSymbolID);
              _PlacementIDList.RemoveAt(index);
              break;
            }
          }
          if (_PlacementIDList.Count == 0)
            break;
        }
      }
    }
  }

  public ReadOnlyCollection<FamilyContainer> PlantFamilyList
  {
    get => new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_PlantFamilyList);
  }

  public ReadOnlyCollection<FamilyContainer> ExistingPlantFamilyList
  {
    get
    {
      return new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_ExistingPlantFamilyList);
    }
  }

  public Document Document => this.m_Document;

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }
}
