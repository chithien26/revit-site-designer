using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class GrowthSimulationForm : EPForm
{
	private Units m_Units;

	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private int m_nMixtListViewSortColumn = -1;

	private GrowthSimulation m_dataBuffer;

	private List<FamilySymbolContainer> m_LocalList = new List<FamilySymbolContainer>();

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Button m_PlantGrowthApply;

	private Button m_CancelButton;

	private Button m_ModifyButton;

	private GroupBox m_DynGroupBox;

	private ListView m_TypeListView;

	private Label m_SimulationAge;

	private GroupBox m_PlantGrowthAgeGroupBox;

	private TextBox m_AgeTextBox;

	private RadioButton m_AllInstancesRadioButton;

	private GroupBox m_SelectionMethodsGroupBox;

	private RadioButton m_WindowSelectRadioButton;

	private RadioButton m_SelectionSetRadioButton;

	public bool SelectionSetChecked => m_SelectionSetRadioButton.Checked;

	public bool WindowSelectChecked => m_WindowSelectRadioButton.Checked;

	public bool AllInstancesChecked => m_AllInstancesRadioButton.Checked;

	public List<FamilySymbolContainer> FamilySymbolLocalList
	{
		get
		{
			List<FamilySymbolContainer> list = new List<FamilySymbolContainer>();
			if (m_TypeListView.SelectedItems.Count >= 1)
			{
				for (int i = 0; i < m_TypeListView.SelectedIndices.Count; i++)
				{
					list.Add(m_LocalList[m_TypeListView.SelectedIndices[i]]);
				}
			}
			else
			{
				MessageBox.Show(ApplicationUtility.RevitWindowWrapper, EPShared.LocalRM.GetString("NoPlantSymbolSelectedMessage"), EPShared.LocalRM.GetString("Revit"));
			}
			return list;
		}
	}

	public double Age
	{
		get
		{
			double _dReturnedDouble = 0.0;
			RevitGeometry.StrE_GetValidRealNumber(m_AgeTextBox.Text, ref _dReturnedDouble);
			return _dReturnedDouble;
		}
	}

	public GrowthSimulationForm(GrowthSimulation _dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("PlantGrowthSimulationDialog");
		m_DynGroupBox.Text = EPShared.LocalRM.GetString("PlantGrowthDialog");
		m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
		m_PlantGrowthAgeGroupBox.Text = EPShared.LocalRM.GetString("PlantGrowthAgeDialog");
		m_SimulationAge.Text = EPShared.LocalRM.GetString("A_AMP_geDialog");
		m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
		m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
		m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
		m_AllInstancesRadioButton.Text = EPShared.LocalRM.GetString("All_AMP_InstancesDialog");
		m_PlantGrowthApply.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_dataBuffer = _dataBuffer;
		m_FormatOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_dataBuffer.Document.DisplayUnitSystem;
		m_Units = m_dataBuffer.Document.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_dataBuffer.Document.GetUnits().DecimalSymbol;
		InitializeControls();
		ManagePlants.VerifySharedParameters(m_dataBuffer.Document, m_dataBuffer.TransactionContainer);
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		GetDialogPosition();
		m_SelectionSetRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("GrowthSimulationSelectMethodOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_SelectionSetRadioButton.Checked = true;
				break;
			case 1:
				m_WindowSelectRadioButton.Checked = true;
				break;
			default:
				m_AllInstancesRadioButton.Checked = true;
				break;
			}
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("GrowthSimulationAge", ref _nReturnValue))
		{
			_nReturnValue = 0;
		}
		m_AgeTextBox.Text = _nReturnValue.ToString();
		SetupListView();
	}

	private void SetupListView()
	{
		m_LocalList = m_dataBuffer.ExistingPlantSymbolList;
		m_TypeListView.View = System.Windows.Forms.View.Details;
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("FamilyString"));
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"));
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"));
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"));
		m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"));
		int num = (m_TypeListView.Width - 5) / m_TypeListView.Columns.Count;
		for (int i = 0; i < m_TypeListView.Columns.Count; i++)
		{
			m_TypeListView.Columns[i].Width = num;
		}
		ListViewItem listViewItem = new ListViewItem();
		string empty = string.Empty;
		for (int j = 0; j < m_LocalList.Count; j++)
		{
			empty = EPShared.LocalRM.GetString("NotAvailableString");
			listViewItem = m_TypeListView.Items.Insert(j, m_LocalList[j].FamilySymbol.Family.Name, m_LocalList[j].FamilySymbol.Family.Name, string.Empty);
			listViewItem.Tag = m_LocalList[j].FamilySymbol.Family.Name;
			if (string.Compare(m_LocalList[j].FamilySymbol.Name, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
			{
				empty = m_LocalList[j].FamilySymbol.Name;
			}
			listViewItem.SubItems.Add(empty);
			empty = EPShared.LocalRM.GetString("NotAvailableString");
			if (string.Compare(m_LocalList[j].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
			{
				empty = m_LocalList[j].ServiceLife;
			}
			listViewItem.SubItems.Add(empty);
			empty = EPShared.LocalRM.GetString("NotAvailableString");
			if (string.Compare(m_LocalList[j].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
			{
				RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(m_LocalList[j].MaxHeight), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
			}
			listViewItem.SubItems.Add(empty);
			empty = EPShared.LocalRM.GetString("NotAvailableString");
			if (string.Compare(m_LocalList[j].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
			{
				RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(m_LocalList[j].MaxWidth), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
			}
			listViewItem.SubItems.Add(empty);
		}
	}

	private void OnApplyPlantGrowthButtonClicked(object sender, EventArgs e)
	{
		if (ValueConversion.ToDouble(m_AgeTextBox.Text) <= 0.0 || m_AgeTextBox.Text == string.Empty)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidAgeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		List<FamilySymbolContainer> list = new List<FamilySymbolContainer>();
		if (m_TypeListView.SelectedItems.Count >= 1)
		{
			for (int i = 0; i < m_TypeListView.SelectedItems.Count; i++)
			{
				if (string.Compare(m_TypeListView.SelectedItems[i].SubItems[2].Text, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) == 0)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidServiceLifeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return;
				}
			}
		}
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void CancelButtonClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	private void OnGrowthSimulationFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void SaveSettings()
	{
		int num = 0;
		num = ((!m_SelectionSetRadioButton.Checked) ? (m_WindowSelectRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("GrowthSimulationSelectMethodOption", num);
		if (m_AgeTextBox.Text != string.Empty)
		{
			int _nReturnedInt = 0;
			RevitGeometry.StrE_GetValidWholeNumber(m_AgeTextBox.Text, ref _nReturnedInt);
			ApplicationUtility.Settings.eplSetE_SetSetting("GrowthSimulationAge", _nReturnedInt);
		}
	}

	private void OnModifyButtonClicked(object sender, EventArgs e)
	{
		if (m_TypeListView.Items.Count > 0)
		{
			Modify();
		}
	}

	private void Modify()
	{
		if (m_TypeListView.SelectedItems.Count >= 1)
		{
			using (PlantGrowthModify plantGrowthModify = new PlantGrowthModify(ref m_LocalList, m_dataBuffer.Document.GetUnits(), m_DisplayUnitSystem, m_FormatOptions, m_UnitSymbolType, m_DecimalSymbolType, m_TypeListView.SelectedIndices[0]))
			{
				plantGrowthModify.ShowDialog();
				if (plantGrowthModify.DialogResult == DialogResult.OK)
				{
					int num = m_TypeListView.SelectedIndices[0];
					if (num >= 0 && num < m_TypeListView.Items.Count)
					{
						UpdateList(num);
						m_TypeListView.Items[num].Selected = true;
					}
				}
				return;
			}
		}
		RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantSymbolSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
	}

	private void MixListViewDoubleClicked(object sender, EventArgs e)
	{
		Modify();
	}

	private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column != m_nMixtListViewSortColumn)
		{
			m_nMixtListViewSortColumn = e.Column;
			m_TypeListView.Sorting = SortOrder.Ascending;
		}
		else if (m_TypeListView.Sorting == SortOrder.Ascending)
		{
			m_TypeListView.Sorting = SortOrder.Descending;
		}
		else
		{
			m_TypeListView.Sorting = SortOrder.Ascending;
		}
		m_TypeListView.Sort();
		m_TypeListView.ListViewItemSorter = new ListViewItemComparer(e.Column, m_TypeListView.Sorting);
	}

	private void UpdateList(int _nSelectedListIndex)
	{
		m_TypeListView.Items.RemoveAt(_nSelectedListIndex);
		ListViewItem listViewItem = null;
		string text = EPShared.LocalRM.GetString("NotAvailableString");
		listViewItem = new ListViewItem();
		listViewItem = m_TypeListView.Items.Insert(_nSelectedListIndex, m_LocalList[_nSelectedListIndex].FamilySymbol.Family.Name, m_LocalList[_nSelectedListIndex].FamilySymbol.Family.Name, string.Empty);
		if (string.Compare(m_LocalList[_nSelectedListIndex].FamilySymbol.Name, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			text = m_LocalList[_nSelectedListIndex].FamilySymbol.Name;
		}
		listViewItem.SubItems.Add(text);
		text = EPShared.LocalRM.GetString("NotAvailableString");
		if (string.Compare(m_LocalList[_nSelectedListIndex].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			text = m_LocalList[_nSelectedListIndex].ServiceLife;
		}
		listViewItem.SubItems.Add(text);
		text = EPShared.LocalRM.GetString("NotAvailableString");
		if (string.Compare(m_LocalList[_nSelectedListIndex].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(m_LocalList[_nSelectedListIndex].MaxHeight), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref text);
		}
		listViewItem.SubItems.Add(text);
		text = EPShared.LocalRM.GetString("NotAvailableString");
		if (string.Compare(m_LocalList[_nSelectedListIndex].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(m_LocalList[_nSelectedListIndex].MaxWidth), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref text);
		}
		listViewItem.SubItems.Add(text);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_PlantGrowthApply = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_ModifyButton = new System.Windows.Forms.Button();
		this.m_DynGroupBox = new System.Windows.Forms.GroupBox();
		this.m_TypeListView = new System.Windows.Forms.ListView();
		this.m_SimulationAge = new System.Windows.Forms.Label();
		this.m_PlantGrowthAgeGroupBox = new System.Windows.Forms.GroupBox();
		this.m_AgeTextBox = new System.Windows.Forms.TextBox();
		this.m_AllInstancesRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionMethodsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_WindowSelectRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionSetRadioButton = new System.Windows.Forms.RadioButton();
		this.m_DynGroupBox.SuspendLayout();
		this.m_PlantGrowthAgeGroupBox.SuspendLayout();
		this.m_SelectionMethodsGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_PlantGrowthApply.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_PlantGrowthApply.Location = new System.Drawing.Point(320, 377);
		this.m_PlantGrowthApply.Name = "m_PlantGrowthApply";
		this.m_PlantGrowthApply.Size = new System.Drawing.Size(77, 23);
		this.m_PlantGrowthApply.TabIndex = 3;
		this.m_PlantGrowthApply.Text = "&Apply";
		this.m_PlantGrowthApply.UseVisualStyleBackColor = true;
		this.m_PlantGrowthApply.Click += new System.EventHandler(this.OnApplyPlantGrowthButtonClicked);
		this.m_CancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CancelButton.Location = new System.Drawing.Point(403, 377);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.CancelButtonClicked);
		this.m_ModifyButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ModifyButton.Location = new System.Drawing.Point(385, 15);
		this.m_ModifyButton.Name = "m_ModifyButton";
		this.m_ModifyButton.Size = new System.Drawing.Size(75, 23);
		this.m_ModifyButton.TabIndex = 1;
		this.m_ModifyButton.Text = "Modify";
		this.m_ModifyButton.UseVisualStyleBackColor = true;
		this.m_ModifyButton.Click += new System.EventHandler(this.OnModifyButtonClicked);
		this.m_DynGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DynGroupBox.Controls.Add(this.m_ModifyButton);
		this.m_DynGroupBox.Controls.Add(this.m_TypeListView);
		this.m_DynGroupBox.Location = new System.Drawing.Point(12, 11);
		this.m_DynGroupBox.Name = "m_DynGroupBox";
		this.m_DynGroupBox.Size = new System.Drawing.Size(466, 255);
		this.m_DynGroupBox.TabIndex = 0;
		this.m_DynGroupBox.TabStop = false;
		this.m_DynGroupBox.Text = "Plant Growth";
		this.m_TypeListView.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_TypeListView.FullRowSelect = true;
		this.m_TypeListView.HideSelection = false;
		this.m_TypeListView.Location = new System.Drawing.Point(7, 15);
		this.m_TypeListView.Name = "m_TypeListView";
		this.m_TypeListView.Size = new System.Drawing.Size(372, 235);
		this.m_TypeListView.TabIndex = 0;
		this.m_TypeListView.UseCompatibleStateImageBehavior = false;
		this.m_TypeListView.DoubleClick += new System.EventHandler(this.MixListViewDoubleClicked);
		this.m_TypeListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.OnMixListViewColumnClick);
		this.m_SimulationAge.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_SimulationAge.AutoSize = true;
		this.m_SimulationAge.Location = new System.Drawing.Point(6, 23);
		this.m_SimulationAge.Name = "m_SimulationAge";
		this.m_SimulationAge.Size = new System.Drawing.Size(26, 13);
		this.m_SimulationAge.TabIndex = 0;
		this.m_SimulationAge.Text = "Age";
		this.m_PlantGrowthAgeGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_PlantGrowthAgeGroupBox.Controls.Add(this.m_AgeTextBox);
		this.m_PlantGrowthAgeGroupBox.Controls.Add(this.m_SimulationAge);
		this.m_PlantGrowthAgeGroupBox.Location = new System.Drawing.Point(12, 272);
		this.m_PlantGrowthAgeGroupBox.Name = "m_PlantGrowthAgeGroupBox";
		this.m_PlantGrowthAgeGroupBox.Size = new System.Drawing.Size(466, 50);
		this.m_PlantGrowthAgeGroupBox.TabIndex = 1;
		this.m_PlantGrowthAgeGroupBox.TabStop = false;
		this.m_PlantGrowthAgeGroupBox.Text = "Plant Growth Age";
		this.m_AgeTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_AgeTextBox.Location = new System.Drawing.Point(38, 19);
		this.m_AgeTextBox.Name = "m_AgeTextBox";
		this.m_AgeTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_AgeTextBox.TabIndex = 1;
		this.m_AllInstancesRadioButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_AllInstancesRadioButton.AutoSize = true;
		this.m_AllInstancesRadioButton.Location = new System.Drawing.Point(308, 19);
		this.m_AllInstancesRadioButton.Name = "m_AllInstancesRadioButton";
		this.m_AllInstancesRadioButton.Size = new System.Drawing.Size(85, 17);
		this.m_AllInstancesRadioButton.TabIndex = 2;
		this.m_AllInstancesRadioButton.TabStop = true;
		this.m_AllInstancesRadioButton.Text = "All &Instances";
		this.m_AllInstancesRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionMethodsGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_AllInstancesRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_WindowSelectRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_SelectionSetRadioButton);
		this.m_SelectionMethodsGroupBox.Location = new System.Drawing.Point(12, 328);
		this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
		this.m_SelectionMethodsGroupBox.Size = new System.Drawing.Size(466, 43);
		this.m_SelectionMethodsGroupBox.TabIndex = 2;
		this.m_SelectionMethodsGroupBox.TabStop = false;
		this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
		this.m_WindowSelectRadioButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_WindowSelectRadioButton.AutoSize = true;
		this.m_WindowSelectRadioButton.Location = new System.Drawing.Point(159, 19);
		this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
		this.m_WindowSelectRadioButton.Size = new System.Drawing.Size(97, 17);
		this.m_WindowSelectRadioButton.TabIndex = 1;
		this.m_WindowSelectRadioButton.TabStop = true;
		this.m_WindowSelectRadioButton.Text = "Window S&elect";
		this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionSetRadioButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_SelectionSetRadioButton.AutoSize = true;
		this.m_SelectionSetRadioButton.Location = new System.Drawing.Point(6, 19);
		this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
		this.m_SelectionSetRadioButton.Size = new System.Drawing.Size(88, 17);
		this.m_SelectionSetRadioButton.TabIndex = 0;
		this.m_SelectionSetRadioButton.TabStop = true;
		this.m_SelectionSetRadioButton.Text = "&Selection Set";
		this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(490, 419);
		base.Controls.Add(this.m_SelectionMethodsGroupBox);
		base.Controls.Add(this.m_PlantGrowthAgeGroupBox);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_PlantGrowthApply);
		base.Controls.Add(this.m_DynGroupBox);
		this.MinimumSize = new System.Drawing.Size(498, 446);
		base.Name = "GrowthSimulationForm";
		this.Text = "Plant Growth Simulation";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnGrowthSimulationFormClosing);
		this.m_DynGroupBox.ResumeLayout(false);
		this.m_PlantGrowthAgeGroupBox.ResumeLayout(false);
		this.m_PlantGrowthAgeGroupBox.PerformLayout();
		this.m_SelectionMethodsGroupBox.ResumeLayout(false);
		this.m_SelectionMethodsGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.AcceptButton = this.m_PlantGrowthApply;
		base.CancelButton = this.m_CancelButton;
	}
}
