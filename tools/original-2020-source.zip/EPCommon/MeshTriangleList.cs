﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.MeshTriangleList
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace EPCommon;

public class MeshTriangleList
{
  private List<MeshTriangleContainer> m_TriangleList;
  private Eps_Leg m_Leg;

  public MeshTriangleList(GeometryObject _GeoElement)
  {
    this.m_Leg = (Eps_Leg) null;
    this.m_TriangleList = new List<MeshTriangleContainer>();
    this.AddGeoElement(_GeoElement);
  }

  private void AddGeoElement(GeometryObject _Object)
  {
    GeometryElement source = _Object as GeometryElement;
    if (GeometryObject.op_Equality((GeometryObject) source, (GeometryObject) null))
      return;
    this.AddGeometryObjects(((IEnumerable<GeometryObject>) source).ToArray<GeometryObject>());
  }

  private void AddGeometryObjects(GeometryObject[] _Objects)
  {
    foreach (GeometryObject _Object in _Objects)
    {
      string strA = _Object.GetType().Name;
      if (strA.StartsWith("Geometry"))
        strA = strA.Remove(0, 8);
      if (string.Compare(strA, "Mesh", true) == 0)
        this.AddMesh(_Object);
    }
  }

  public VerticeContainer FindVerticeInVerticeList(
    uint _VerticeNumber,
    List<VerticeContainer> _VerticeList)
  {
    for (int index = 0; index < _VerticeList.Count; ++index)
    {
      if ((int) _VerticeNumber == (int) _VerticeList[index].VerticeNumber)
        return _VerticeList[index];
    }
    return (VerticeContainer) null;
  }

  private void AddMesh(GeometryObject _Object)
  {
    Mesh mesh = _Object as Mesh;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) mesh))
      return;
    List<MeshTriangleContainer> triangleContainerList = new List<MeshTriangleContainer>();
    uint _nLineStartNumber = 0;
    List<VerticeContainer> _VerticeList = new List<VerticeContainer>();
    for (int _nTriangleNumber = 0; _nTriangleNumber < mesh.NumTriangles; ++_nTriangleNumber)
    {
      MeshTriangle meshTriangle = mesh[_nTriangleNumber];
      try
      {
        MeshTriangleContainer triangleContainer = new MeshTriangleContainer();
        for (int index = 0; index < 3; ++index)
        {
          uint num = meshTriangle[index];
          if (this.FindVerticeInVerticeList(num, _VerticeList) == null)
            _VerticeList.Add(new VerticeContainer(num, new Eps_Point(meshTriangle[index])));
          if (index > 0)
          {
            MeshTriangleLine meshTriangleLine = new MeshTriangleLine(_nTriangleNumber, _nLineStartNumber, num);
            triangleContainer.TriangleLines.Add(meshTriangleLine);
          }
          _nLineStartNumber = num;
        }
        uint lineStartNumber = triangleContainer.TriangleLines[0].LineStartNumber;
        MeshTriangleLine meshTriangleLine1 = new MeshTriangleLine(_nTriangleNumber, _nLineStartNumber, lineStartNumber);
        triangleContainer.TriangleLines.Add(meshTriangleLine1);
        triangleContainerList.Add(triangleContainer);
      }
      catch
      {
      }
    }
    bool flag1 = false;
    bool flag2 = false;
    for (int index1 = 0; index1 < triangleContainerList.Count; ++index1)
    {
      for (int index2 = index1 + 1; index2 < triangleContainerList.Count; ++index2)
      {
        for (int index3 = 0; index3 < triangleContainerList[index1].TriangleLines.Count; ++index3)
        {
          MeshTriangleLine triangleLine1 = triangleContainerList[index1].TriangleLines[index3];
          for (int index4 = 0; index4 < triangleContainerList[index2].TriangleLines.Count; ++index4)
          {
            MeshTriangleLine triangleLine2 = triangleContainerList[index2].TriangleLines[index4];
            if (triangleLine1.IsEqual(triangleLine2))
            {
              triangleContainerList[index1].TriangleLines.RemoveAt(index3);
              --index3;
              triangleContainerList[index2].TriangleLines.RemoveAt(index4);
              --index4;
              if (triangleContainerList[index1].TriangleLines.Count == 0 || triangleContainerList[index2].TriangleLines.Count == 0)
              {
                if (triangleContainerList[index1].TriangleLines.Count == 0)
                {
                  flag2 = true;
                  triangleContainerList.RemoveAt(index1);
                  --index1;
                  --index2;
                }
                if (triangleContainerList[index2].TriangleLines.Count == 0)
                {
                  flag1 = true;
                  triangleContainerList.RemoveAt(index2);
                  --index2;
                  break;
                }
                break;
              }
            }
          }
          if (flag2 || flag1)
          {
            if (flag1)
            {
              flag1 = false;
              break;
            }
            break;
          }
        }
        if (flag2)
        {
          flag2 = false;
          break;
        }
      }
    }
    List<MeshTriangleLine> meshTriangleLineList = new List<MeshTriangleLine>();
    for (int index5 = 0; index5 < triangleContainerList.Count; ++index5)
    {
      for (int index6 = 0; index6 < triangleContainerList[index5].TriangleLines.Count; ++index6)
        meshTriangleLineList.Add(triangleContainerList[index5].TriangleLines[index6]);
    }
    MeshTriangleLineComparer triangleLineComparer = new MeshTriangleLineComparer();
    meshTriangleLineList.Sort((IComparer<MeshTriangleLine>) triangleLineComparer);
    for (int index = 0; index < meshTriangleLineList.Count; ++index)
    {
      Eps_Leg epsLeg = new Eps_Leg();
      epsLeg.Line = new Eps_Line();
      VerticeContainer verticeInVerticeList1 = this.FindVerticeInVerticeList(meshTriangleLineList[index].LineStartNumber, _VerticeList);
      if (verticeInVerticeList1 != null)
        epsLeg.Line.StartPnt = verticeInVerticeList1.VerticePoint;
      VerticeContainer verticeInVerticeList2 = this.FindVerticeInVerticeList(meshTriangleLineList[index].LineEndNumber, _VerticeList);
      if (verticeInVerticeList2 != null)
        epsLeg.Line.EndPnt = verticeInVerticeList2.VerticePoint;
      if (this.m_Leg == null)
        this.m_Leg = epsLeg;
      else
        this.m_Leg.Last.Next = epsLeg;
    }
  }

  public double Area()
  {
    List<Eps_Point> Vertices = new List<Eps_Point>();
    if (this.m_Leg != null)
    {
      for (Eps_Leg epsLeg = this.m_Leg; epsLeg != null; epsLeg = epsLeg.Next)
      {
        if (epsLeg.Line != null)
          Vertices.Add(epsLeg.Line.StartPnt);
      }
    }
    return RevitGeometry.eplGeoE_CalcPolygonArea(Vertices);
  }

  public double OffsetArea(double _dOffsetDistance)
  {
    Eps_Leg epsLeg1 = this.OffsetLeg(_dOffsetDistance);
    List<Eps_Point> Vertices = new List<Eps_Point>();
    if (epsLeg1 != null)
    {
      for (Eps_Leg epsLeg2 = epsLeg1; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
      {
        if (epsLeg2.Line != null)
          Vertices.Add(epsLeg2.Line.StartPnt);
      }
    }
    return RevitGeometry.eplGeoE_CalcPolygonArea(Vertices);
  }

  public Eps_Leg OffsetLeg(double _dOffsetDistance)
  {
    Eps_Leg ppOffsetLegList = new Eps_Leg();
    int Direction = 0;
    if (this.m_Leg == null)
      return (Eps_Leg) null;
    RevitGeometry.eplGeoE_CalcLegDirection(this.m_Leg, ref Direction, 1E-05);
    int OffsetDir = Direction != 1 ? 1 : 2;
    RevitGeometry.OffsetLegList(this.m_Leg, _dOffsetDistance, OffsetDir, ref ppOffsetLegList, true);
    return ppOffsetLegList;
  }

  public List<MeshTriangleContainer> TriangleList => this.m_TriangleList;

  public Eps_Leg Leg => this.m_Leg;
}
