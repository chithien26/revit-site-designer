using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace EPCommon;

public static class RuntimePaths
{
    private static IntPtr nativeModule;
    public static string AssemblyDirectory => Path.GetDirectoryName(typeof(RuntimePaths).Assembly.Location);
    public static string FindDataRoot(string version)
    {
        var candidates = new[]
        {
            AssemblyDirectory,
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Autodesk", "Site Designer for Revit " + version),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Autodesk", "Site Designer for Revit 2020")
        };
        foreach (var path in candidates)
            if (File.Exists(Path.Combine(path, "Data", "Support", "SITEDESIGNER_enu.xml"))) return path;
        throw new FileNotFoundException("Site Designer content is missing. Copy the licensed 2020 Data folder beside SiteDesigner.dll or supply -ContentRoot to Install.ps1.");
    }
    public static string SettingsFile(string version, string name, string dataRoot)
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SiteDesigner", version);
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, name);
        if (!File.Exists(path))
        {
            // Seed supported defaults; machine-specific 2020 family-template paths are not portable.
            var defaults = Path.Combine(AssemblyDirectory, "Defaults", name);
            if (File.Exists(defaults)) File.Copy(defaults, path);
            else File.WriteAllText(path, "[Setting]" + Environment.NewLine);
        }
        return path;
    }
    public static void LoadNativeLibrary()
    {
        if (nativeModule != IntPtr.Zero) return;
        var candidates = new[]
        {
            Path.Combine(AssemblyDirectory, "SitesDLLWrapper.dll"),
            Path.Combine(AssemblyDirectory, "native", "SitesDLLWrapper.dll"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Autodesk", "Revit Site Designer Extension 2020", "SitesDLLWrapper.dll")
        };
        foreach (var path in candidates)
        {
            if (!File.Exists(path)) continue;
            nativeModule = LoadLibraryEx(path, IntPtr.Zero, 0x00000100 | 0x00001000);
            if (nativeModule == IntPtr.Zero) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(), "Cannot load " + path);
            RuntimeDiagnostics.Write("Native geometry library: " + path);
            return;
        }
        throw new DllNotFoundException("SitesDLLWrapper.dll is required. Supply the licensed x64 library beside SiteDesigner.dll.");
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr LoadLibraryEx(string path, IntPtr file, uint flags);
}
