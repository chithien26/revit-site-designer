﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.UnitAbbrContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class UnitAbbrContainer
{
  private string m_strAbbreviation;
  private double m_dEnglishFactor;
  private double m_dMetricFactor;

  public UnitAbbrContainer(string _strAbbreviation, double _dEnglishFactor, double _dMetricFactor)
  {
    this.m_strAbbreviation = _strAbbreviation;
    this.m_dEnglishFactor = _dEnglishFactor;
    this.m_dMetricFactor = _dMetricFactor;
  }

  public string Abbreviation => this.m_strAbbreviation;

  public double EnglishFactor => this.m_dEnglishFactor;

  public double MetricFactor => this.m_dMetricFactor;
}
