﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.AboutForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using SITES.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class AboutForm : EPForm
{
  private IContainer components;
  private Label m_ProductForRevitLabel;
  private Label m_VersionLabel;
  private Label m_CopyrightLabel;
  private PictureBox pictureBox1;
  private RichTextBox richTextBox1;

  public AboutForm()
  {
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDabout";
    this.Text = EPShared.LocalRM.GetString("AboutSiteDesignerForRevitDialog");
    this.m_ProductForRevitLabel.Text = this.GetAssemblyDescription();
    object[] customAttributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof (AssemblyCopyrightAttribute), false);
    if (customAttributes.Length != 0)
      this.m_CopyrightLabel.Text = ((AssemblyCopyrightAttribute) customAttributes[0]).Copyright;
    else
      this.m_CopyrightLabel.Text = string.Format(EPShared.LocalRM.GetString("CopyrightDialog"), (object) DateTime.Now.Year);
    this.m_VersionLabel.Text = $"{EPShared.LocalRM.GetString("VersionDialog")} {Assembly.GetExecutingAssembly().GetName().Version.ToString()}";
    this.GetDialogPosition();
  }

  private void OnCloseButtton(object sender, EventArgs e)
  {
    this.SetDialogPosition();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCheckForUpdatesLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
  {
    ApplicationUtility.VerifyProductVersion(false);
  }

  private string GetAssemblyDescription()
  {
    foreach (Attribute customAttribute in Attribute.GetCustomAttributes(this.GetType().Assembly))
    {
      if (customAttribute.GetType() == typeof (AssemblyDescriptionAttribute))
        return (customAttribute as AssemblyDescriptionAttribute).Description;
    }
    return string.Empty;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (AboutForm));
    this.m_ProductForRevitLabel = new Label();
    this.m_VersionLabel = new Label();
    this.m_CopyrightLabel = new Label();
    this.pictureBox1 = new PictureBox();
    this.richTextBox1 = new RichTextBox();
    ((ISupportInitialize) this.pictureBox1).BeginInit();
    this.SuspendLayout();
    this.m_ProductForRevitLabel.Font = new Font("Microsoft Sans Serif", 12f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
    this.m_ProductForRevitLabel.Location = new Point(17, 12);
    this.m_ProductForRevitLabel.Name = "m_ProductForRevitLabel";
    this.m_ProductForRevitLabel.Size = new Size(240 /*0xF0*/, 60);
    this.m_ProductForRevitLabel.TabIndex = 0;
    this.m_ProductForRevitLabel.Text = "Product Label";
    this.m_VersionLabel.AutoSize = true;
    this.m_VersionLabel.Location = new Point(14, 96 /*0x60*/);
    this.m_VersionLabel.Name = "m_VersionLabel";
    this.m_VersionLabel.Size = new Size(42, 13);
    this.m_VersionLabel.TabIndex = 1;
    this.m_VersionLabel.Text = "Version";
    this.m_CopyrightLabel.AutoSize = true;
    this.m_CopyrightLabel.Location = new Point(14, 119);
    this.m_CopyrightLabel.Name = "m_CopyrightLabel";
    this.m_CopyrightLabel.Size = new Size(51, 13);
    this.m_CopyrightLabel.TabIndex = 2;
    this.m_CopyrightLabel.Text = "Copyright";
    this.pictureBox1.Image = (Image) Resources.AutodeskLogo;
    this.pictureBox1.Location = new Point(291, 94);
    this.pictureBox1.Name = "pictureBox1";
    this.pictureBox1.Size = new Size(119, 20);
    this.pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
    this.pictureBox1.TabIndex = 3;
    this.pictureBox1.TabStop = false;
    this.richTextBox1.Location = new Point(12, 139);
    this.richTextBox1.Name = "richTextBox1";
    this.richTextBox1.Size = new Size(394, 175);
    this.richTextBox1.TabIndex = 5;
    this.richTextBox1.Text = componentResourceManager.GetString("richTextBox1.Text");
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(419, 326);
    this.Controls.Add((Control) this.richTextBox1);
    this.Controls.Add((Control) this.pictureBox1);
    this.Controls.Add((Control) this.m_CopyrightLabel);
    this.Controls.Add((Control) this.m_VersionLabel);
    this.Controls.Add((Control) this.m_ProductForRevitLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.HelpButton = false;
    this.Margin = new Padding(4, 5, 4, 5);
    this.Name = nameof (AboutForm);
    this.Text = "About LANDCADD for Revit";
    ((ISupportInitialize) this.pictureBox1).EndInit();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
