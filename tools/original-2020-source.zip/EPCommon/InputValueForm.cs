﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.InputValueForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class InputValueForm : Form
{
  private IContainer components;
  private Button m_OKButton;
  private Button m_CancelButton;
  private TextBox m_WarningMessageTextBox;
  private Label m_FieldLabel;
  private TextBox m_FieldTextBox;

  public InputValueForm(string _strFormTitle, string _strWarningText, string _strFieldLabel)
  {
    this.InitializeComponent();
    this.Text = _strFormTitle;
    this.m_WarningMessageTextBox.Text = _strWarningText;
    this.m_FieldLabel.Text = _strFieldLabel;
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  public string FieldValue
  {
    get => this.m_FieldTextBox.Text;
    set => this.m_FieldTextBox.Text = value;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (InputValueForm));
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_WarningMessageTextBox = new TextBox();
    this.m_FieldLabel = new Label();
    this.m_FieldTextBox = new TextBox();
    this.SuspendLayout();
    this.m_OKButton.Location = new Point(181, 95);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 3;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(262, 95);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_WarningMessageTextBox.BackColor = SystemColors.Control;
    this.m_WarningMessageTextBox.BorderStyle = BorderStyle.None;
    this.m_WarningMessageTextBox.Location = new Point(12, 12);
    this.m_WarningMessageTextBox.Multiline = true;
    this.m_WarningMessageTextBox.Name = "m_WarningMessageTextBox";
    this.m_WarningMessageTextBox.Size = new Size(324, 51);
    this.m_WarningMessageTextBox.TabIndex = 0;
    this.m_WarningMessageTextBox.TabStop = false;
    this.m_FieldLabel.AutoSize = true;
    this.m_FieldLabel.Location = new Point(12, 72);
    this.m_FieldLabel.Name = "m_FieldLabel";
    this.m_FieldLabel.Size = new Size(38, 13);
    this.m_FieldLabel.TabIndex = 1;
    this.m_FieldLabel.Text = "Name:";
    this.m_FieldTextBox.Location = new Point(117, 69);
    this.m_FieldTextBox.Name = "m_FieldTextBox";
    this.m_FieldTextBox.Size = new Size(220, 20);
    this.m_FieldTextBox.TabIndex = 2;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(349, 130);
    this.Controls.Add((Control) this.m_FieldLabel);
    this.Controls.Add((Control) this.m_FieldTextBox);
    this.Controls.Add((Control) this.m_WarningMessageTextBox);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.Name = nameof (InputValueForm);
    this.ShowInTaskbar = false;
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = nameof (InputValueForm);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
