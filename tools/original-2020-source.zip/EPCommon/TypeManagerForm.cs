﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.TypeManagerForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class TypeManagerForm : EPForm
{
  private Units m_Units;
  private string m_strSourceFile = string.Empty;
  private Document m_CurDocument;
  private List<FamilyParameterTypeWrapper> m_ParameterList;
  private FormatOptions m_FormatOptions;
  private FormatOptions m_SlopeOptions;
  private FormatOptions m_AngularOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private UnitSymbolType m_SlopeSymbolType;
  private UnitSymbolType m_AngularSymbolType;
  private int m_nMixtListViewSortColumn = -1;
  private EPTransactionContainer m_TransactionContainer;
  private LandcaddID m_CurrentFamilyType = LandcaddID.Street;
  private FamilyBinder m_SelectedFamily;
  private List<Material> m_AllMaterialList;
  private List<Material> m_MaterialList;
  private DecimalSymbol m_DecimalSymbolType;
  private double m_dAngularRounding;
  private DisplayUnitType m_SlopeDisplayUnitType;
  private double m_SlopeAccuracy;
  private IContainer components;
  private GroupBox m_DynGroupBox;
  private ListView m_TypeListView;
  private Button m_DeleteButton;
  private Button m_AddButton;
  private Button m_SearchButton;
  private Button m_ModifyButton;
  private Button m_SaveFamilyButton;
  private Button m_CancelButton;
  private Button m_EqualButton;

  public TypeManagerForm(
    ref FamilyBinder SelectedFamily,
    Document _CurDocument,
    LandcaddID _CurrentFamilyType,
    Document _ActiveDocument)
  {
    this.InitializeComponent();
    this.m_SearchButton.Visible = false;
    this.m_EqualButton.Visible = false;
    this.m_CurDocument = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_CurDocument);
    this.m_FormatOptions = _ActiveDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_SlopeOptions = _ActiveDocument.GetUnits().GetFormatOptions((UnitType) 59);
    this.m_SlopeDisplayUnitType = this.m_SlopeOptions.DisplayUnits;
    this.m_SlopeAccuracy = RevitGeometry.GetSlopeAccuracy(this.m_SlopeDisplayUnitType);
    this.m_AngularOptions = _ActiveDocument.GetUnits().GetFormatOptions((UnitType) 3);
    this.m_DisplayUnitSystem = _ActiveDocument.DisplayUnitSystem;
    this.m_Units = _ActiveDocument.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_SlopeSymbolType = this.m_SlopeOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_SlopeSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_AngularSymbolType = this.m_AngularOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_AngularSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_dAngularRounding = this.m_AngularOptions.Accuracy;
    }
    catch (InvalidOperationException ex)
    {
      this.m_dAngularRounding = 1.0;
    }
    this.m_DecimalSymbolType = _ActiveDocument.GetUnits().DecimalSymbol;
    this.m_SelectedFamily = SelectedFamily;
    this.m_CurrentFamilyType = _CurrentFamilyType;
    this.m_MaterialList = new List<Material>();
    this.m_AllMaterialList = new List<Material>();
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(_ActiveDocument).OfClass(typeof (Material)).OfCategory((BuiltInCategory) -2000700).ToElements())
    {
      if (element != null && element is Material material)
      {
        this.m_AllMaterialList.Add(material);
        this.m_MaterialList.Add(material);
      }
    }
    this.SetStringValues();
    this.SetDefaultValues();
  }

  private void SetStringValues()
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.PlantMix:
        this.m_ParameterList = ManagePlants.PlantMixParamenterList();
        empty2 = EPShared.LocalRM.GetString("");
        break;
      case LandcaddID.PatioWalk:
        this.m_ParameterList = ManagePlants.PatioWalkParamenterList();
        empty2 = EPShared.LocalRM.GetString("");
        break;
      case LandcaddID.SoftTerrain:
        this.m_ParameterList = ManageFamily.SoftTerrainParameterList();
        empty2 = EPShared.LocalRM.GetString("SoftTerrainManagerString");
        this.ContextualHelpID = "HID_SDfamilyModifySoftTerrain";
        break;
      case LandcaddID.Street:
        this.m_ParameterList = ManageFamily.StreetParamenterList();
        empty2 = EPShared.LocalRM.GetString("StreetTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyModifyStreet";
        break;
      case LandcaddID.Curb:
        this.m_ParameterList = ManageFamily.CurbParameterList();
        empty2 = EPShared.LocalRM.GetString("CurbTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyModifyCurb";
        break;
      case LandcaddID.Sidewalk:
        this.m_ParameterList = ManageFamily.SideWalkParamterList();
        empty2 = EPShared.LocalRM.GetString("SidewalkTypeManagerString");
        this.ContextualHelpID = "HID_SDfamilyModifySidewalk";
        break;
      case LandcaddID.RetainingWall:
        this.m_ParameterList = ManageFamily.RetainingWallParameterList();
        empty2 = EPShared.LocalRM.GetString("RetainingWallManagerString");
        this.ContextualHelpID = "HID_SDfamilyModifyRetainingWall";
        break;
      case LandcaddID.Steps:
        this.m_ParameterList = ManageFamily.StepsParameterList();
        empty2 = EPShared.LocalRM.GetString("StepsManagerString");
        break;
      case LandcaddID.ParkingLot:
        this.m_ParameterList = ManageFamily.ParkingLotParameterList();
        empty2 = EPShared.LocalRM.GetString("ParkingLotManagerString");
        this.ContextualHelpID = "HID_SDfamilyModifyParkinglot";
        break;
    }
    string str1 = $"{empty2} {EPShared.LocalRM.GetString("FamilyTypeString")}";
    this.Text = $"{empty2} {EPShared.LocalRM.GetString("TypeManagerDialog")}";
    this.m_SearchButton.Visible = false;
    this.m_EqualButton.Visible = false;
    this.m_TypeListView.View = View.Details;
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) != 0)
      {
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
          this.m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("Slope_") + this.m_ParameterList[index].ParameterDisplayName);
        else
          this.m_TypeListView.Columns.Add(this.m_ParameterList[index].ParameterDisplayName);
      }
    }
    string empty3 = string.Empty;
    if (this.m_SelectedFamily.FamilyTypeList == null)
      this.m_SelectedFamily.FamilyTypeList = new List<FamilyTypeContainer>();
    for (int index1 = 0; index1 < this.m_SelectedFamily.FamilyTypeList.Count; ++index1)
    {
      FamilyTypeContainer familyType = this.m_SelectedFamily.FamilyTypeList[index1];
      if (familyType != null)
      {
        ListViewItem listViewItem = new ListViewItem();
        for (int index2 = 0; index2 < this.m_ParameterList.Count; ++index2)
        {
          if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            switch (this.m_CurrentFamilyType)
            {
              case LandcaddID.PlantMix:
                string str2 = string.Empty;
                this.FindParamenterValue(this.m_CurDocument.FamilyManager, familyType.FamilyTypeWrapper.FamilyType, this.m_ParameterList[index2].ParameterName, ref str2);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
                {
                  double _dConvertedDouble = 1.0;
                  if (str2 != string.Empty)
                    _dConvertedDouble = ValueConversion.ToDouble(str2);
                  RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
                {
                  if (str2 == null || str2 == string.Empty)
                    str2 = "1.0";
                }
                else if (str2 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str2 = familyType.FamilyTypeWrapper.FamilyTypeName;
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str2, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str2);
                continue;
              case LandcaddID.PatioWalk:
                string str3 = string.Empty;
                this.FindParamenterValue(this.m_CurDocument.FamilyManager, familyType.FamilyTypeWrapper.FamilyType, this.m_ParameterList[index2].ParameterName, ref str3);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
                {
                  double _dConvertedDouble = 0.0;
                  if (str3 != string.Empty)
                    _dConvertedDouble = ValueConversion.ToDouble(str3);
                  RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str3);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
                  str3 = string.Compare(str3, "1", true) != 0 ? (string.Compare(str3, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
                else if (str3 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str3 = familyType.FamilyTypeWrapper.FamilyTypeName;
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str3, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str3);
                continue;
              case LandcaddID.SoftTerrain:
                string str4 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str4);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SoftTerrainLeftOffsetWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SoftTerrainRightOffsetWidthParameter, true) == 0)
                {
                  double _dConvertedDouble = 0.0;
                  if (str4 != string.Empty)
                    _dConvertedDouble = ValueConversion.ToDouble(str4);
                  RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str4);
                }
                else if (str4 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str4 = familyType.FamilyTypeWrapper.FamilyTypeName;
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SoftTerrainCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SoftTerrainFillSlopeParameter, true) == 0)
                {
                  if (str4 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str4), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str4);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dConvertedDouble = 0.0;
                    if (str4 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str4);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str4);
                  }
                  catch (Exception ex)
                  {
                    str4 = "";
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dAngle = 0.0;
                    if (!string.IsNullOrEmpty(str4))
                      _dAngle = ValueConversion.ToDouble(str4);
                    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str4);
                  }
                  catch (Exception ex)
                  {
                    str4 = "";
                  }
                }
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str4, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str4);
                continue;
              case LandcaddID.Street:
                string str5 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str5);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetLaneWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetPavementDepthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetBoulevardWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetBaseSurfaceParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetSubbaseSurfaceParameter, true) == 0)
                {
                  if (str5 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str5), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str5);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbDisplayParameter, true) == 0)
                  str5 = string.Compare(str5, "1", true) != 0 ? (string.Compare(str5, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCrossSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetFillSlopeParameter, true) == 0)
                {
                  if (str5 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str5), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str5);
                }
                else if (str5 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str5 = familyType.FamilyTypeWrapper.FamilyTypeName;
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetPavementSurfaceParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
                {
                  if (str5 != string.Empty)
                  {
                    string strStringToFind = str5;
                    List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                    str5 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dConvertedDouble = 0.0;
                    if (str5 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str5);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str5);
                  }
                  catch (Exception ex)
                  {
                    str5 = "";
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dAngle = 0.0;
                    if (!string.IsNullOrEmpty(str5))
                      _dAngle = ValueConversion.ToDouble(str5);
                    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str5);
                  }
                  catch (Exception ex)
                  {
                    str5 = "";
                  }
                }
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str5, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str5);
                continue;
              case LandcaddID.Curb:
                string str6 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str6);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurbGutterHeightParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetPavementDepthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetLaneWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurbBaseSurfaceParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurbSubbaseSurfaceParameter, true) == 0)
                {
                  if (str6 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str6), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str6);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0)
                {
                  if (str6 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str6), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str6);
                }
                else if (str6 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str6 = familyType.FamilyTypeWrapper.FamilyTypeName;
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
                {
                  if (str6 != string.Empty)
                  {
                    string strStringToFind = str6;
                    List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                    str6 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dConvertedDouble = 0.0;
                    if (str6 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str6);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str6);
                  }
                  catch (Exception ex)
                  {
                    str6 = "";
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dAngle = 0.0;
                    if (!string.IsNullOrEmpty(str6))
                      _dAngle = ValueConversion.ToDouble(str6);
                    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str6);
                  }
                  catch (Exception ex)
                  {
                    str6 = "";
                  }
                }
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str6, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str6);
                continue;
              case LandcaddID.Sidewalk:
                string str7 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str7);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkWidthParameter, true) == 0)
                {
                  if (str7 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str7), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str7);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkPavementDepthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkBaseSurfaceParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkSubbaseSurfaceParameter, true) == 0)
                {
                  if (str7 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str7), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str7);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkFillSlopeParameter, true) == 0)
                {
                  if (str7 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str7), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str7);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) != 0)
                {
                  if (str7 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                    str7 = familyType.FamilyTypeWrapper.FamilyTypeName;
                  else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.SideWalkPavementSurfaceParameter, true) == 0)
                  {
                    if (str7 != string.Empty)
                    {
                      string strStringToFind = str7;
                      List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                      str7 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                    }
                  }
                  else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                  {
                    try
                    {
                      double _dConvertedDouble = 0.0;
                      if (str7 != string.Empty)
                        _dConvertedDouble = ValueConversion.ToDouble(str7);
                      RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str7);
                    }
                    catch (Exception ex)
                    {
                      str7 = "";
                    }
                  }
                  else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                  {
                    try
                    {
                      double _dAngle = 0.0;
                      if (!string.IsNullOrEmpty(str7))
                        _dAngle = ValueConversion.ToDouble(str7);
                      RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str7);
                    }
                    catch (Exception ex)
                    {
                      str7 = "";
                    }
                  }
                }
                else
                  continue;
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str7, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str7);
                continue;
              case LandcaddID.RetainingWall:
                string str8 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str8);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallWidthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallHeightParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallBaseSurfaceParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallSubbaseSurfaceParameter, true) == 0)
                {
                  if (str8 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str8), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str8);
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallSlopeProjectionParameter, true) == 0)
                  str8 = string.Compare(str8, "1", true) != 0 ? (string.Compare(str8, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallCutSlopeParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallFillSlopeParameter, true) == 0)
                {
                  if (str8 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str8), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str8);
                }
                else if (str8 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str8 = familyType.FamilyTypeWrapper.FamilyTypeName;
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.RetainingWallMaterialParameter, true) == 0)
                {
                  if (str8 != string.Empty)
                  {
                    string strStringToFind = str8;
                    List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                    str8 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dConvertedDouble = 0.0;
                    if (str8 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str8);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str8);
                  }
                  catch (Exception ex)
                  {
                    str8 = "";
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dAngle = 0.0;
                    if (!string.IsNullOrEmpty(str8))
                      _dAngle = ValueConversion.ToDouble(str8);
                    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str8);
                  }
                  catch (Exception ex)
                  {
                    str8 = "";
                  }
                }
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str8, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str8);
                continue;
              case LandcaddID.Steps:
                string str9 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str9);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StepsHeightParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StepsTreadParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StepsWidthParameter, true) == 0)
                {
                  if (str9 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str9), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str9);
                }
                else if (str9 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str9 = familyType.FamilyTypeWrapper.FamilyTypeName;
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.StepsMaterialParameter, true) == 0)
                {
                  if (str9 != string.Empty)
                  {
                    string strStringToFind = str9;
                    List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                    str9 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dConvertedDouble = 0.0;
                    if (str9 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str9);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str9);
                  }
                  catch (Exception ex)
                  {
                    str9 = "";
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dAngle = 0.0;
                    if (!string.IsNullOrEmpty(str9))
                      _dAngle = ValueConversion.ToDouble(str9);
                    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str9);
                  }
                  catch (Exception ex)
                  {
                    str9 = "";
                  }
                }
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str9, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str9);
                continue;
              case LandcaddID.ParkingLot:
                string str10 = string.Empty;
                this.FindParameterValue(this.m_ParameterList[index2].ParameterName, familyType.FamilyParameterList, ref str10);
                if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.ParkingLotPavementDepthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.ParkingLotParkingBaseDepthParameter, true) == 0 || string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.ParkingLotParkingSubBaseDepthParameter, true) == 0)
                {
                  if (str10 != string.Empty)
                    RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str10), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str10);
                }
                else if (str10 == string.Empty && string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                  str10 = familyType.FamilyTypeWrapper.FamilyTypeName;
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.ParkingLotParkingPavementSurfaceParameter, true) == 0)
                {
                  if (str10 != string.Empty)
                  {
                    string strStringToFind = str10;
                    List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                    str10 = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dConvertedDouble = 0.0;
                    if (str10 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str10);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str10);
                  }
                  catch (Exception ex)
                  {
                    str10 = "";
                  }
                }
                else if (string.Compare(this.m_ParameterList[index2].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
                {
                  try
                  {
                    double _dAngle = 0.0;
                    if (!string.IsNullOrEmpty(str10))
                      _dAngle = ValueConversion.ToDouble(str10);
                    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str10);
                  }
                  catch (Exception ex)
                  {
                    str10 = "";
                  }
                }
                if (index2 == 0)
                {
                  listViewItem = this.m_TypeListView.Items.Add(familyType.FamilyTypeWrapper.FamilyTypeName, str10, string.Empty);
                  listViewItem.Tag = (object) familyType.FamilyTypeWrapper.FamilyTypeName;
                  continue;
                }
                listViewItem.SubItems.Add(str10);
                continue;
              default:
                continue;
            }
          }
        }
      }
    }
    if (this.m_TypeListView.Items.Count > 0)
      this.m_TypeListView.Items[0].Selected = true;
    this.m_DynGroupBox.Text = str1;
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("AMP_SearchDialog");
    this.m_AddButton.Text = EPShared.LocalRM.GetString("AMP_New_NewFamilyDialog");
    this.m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
    this.m_DeleteButton.Text = EPShared.LocalRM.GetString("AMP_DeleteDialog");
    this.m_EqualButton.Text = EPShared.LocalRM.GetString("AMP_EqualDialog");
    this.m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
  }

  private void SetDefaultValues()
  {
    string empty = string.Empty;
    this.GetDialogPosition();
  }

  private void FindParameterValue(
    string _strParameterName,
    List<FamilyParameterWrapper> _FamilyParameterList,
    ref string _strValue)
  {
    _strValue = string.Empty;
    IEnumerable<FamilyParameterWrapper> source = _FamilyParameterList.Where<FamilyParameterWrapper>((Func<FamilyParameterWrapper, bool>) (CurrentParameter => string.Compare(CurrentParameter.ParameterName, _strParameterName, false) == 0));
    if (source == null)
      return;
    List<FamilyParameterWrapper> list = source.ToList<FamilyParameterWrapper>();
    if (list.Count <= 0)
      return;
    _strValue = list[0].Value;
  }

  private bool FindParamenterValue(
    FamilyManager FamilyManager,
    FamilyType type,
    string _strParamter,
    ref string _strValue)
  {
    bool paramenterValue = false;
    _strValue = string.Empty;
    FamilyParameter familyParameter = FamilyManager[_strParamter];
    if (familyParameter != null && type.HasValue(familyParameter))
    {
      switch (familyParameter.StorageType - 1)
      {
        case 0:
          if ((ValueType) type.AsInteger(familyParameter) is int)
          {
            paramenterValue = true;
            _strValue = Convert.ToString((object) type.AsInteger(familyParameter));
            break;
          }
          break;
        case 1:
          if ((ValueType) type.AsDouble(familyParameter) is double)
          {
            paramenterValue = true;
            _strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
            break;
          }
          break;
        case 2:
          if (type.AsString(familyParameter) != null)
          {
            paramenterValue = true;
            _strValue = type.AsString(familyParameter);
            break;
          }
          break;
      }
    }
    return paramenterValue;
  }

  private void OnUpdateFamilyButtonClicked(object sender, EventArgs e)
  {
    if (this.m_SelectedFamily.FamilyTypeList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.UpdateFamilyDocument(this.m_SelectedFamily.FamilyDocument, this.m_SelectedFamily.FamilyTypeList, this.m_CurrentFamilyType);
      this.DialogResult = DialogResult.OK;
    }
  }

  private void CancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnSearchButtonClicked(object sender, EventArgs e)
  {
  }

  private void CheckForDuplicates(
    List<FamilyTypeContainer> _PlantListFamilyTypeList,
    List<string> _TypeNames)
  {
  }

  private void OnTypeManagerFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void SaveSettings()
  {
  }

  private void OnAddButtonClicked(object sender, EventArgs e)
  {
    int _nSelectedIndex = -1;
    if (this.m_SelectedFamily.FamilyTypeList == null)
      this.m_SelectedFamily.FamilyTypeList = new List<FamilyTypeContainer>();
    List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
    List<FamilyTypeContainer> familyTypeList = this.m_SelectedFamily.FamilyTypeList;
    using (AddModifyFamilyForm modifyFamilyForm = new AddModifyFamilyForm(this.m_ParameterList, ref familyTypeList, this.m_Units, this.m_DisplayUnitSystem, this.m_FormatOptions, this.m_UnitSymbolType, this.m_SlopeOptions, this.m_SlopeSymbolType, this.m_AngularOptions, this.m_AngularSymbolType, this.m_AllMaterialList, this.m_DecimalSymbolType, _nSelectedIndex, this.m_CurrentFamilyType, this.m_SelectedFamily.FamilyName))
    {
      int num = (int) modifyFamilyForm.ShowDialog();
      if (modifyFamilyForm.DialogResult != DialogResult.OK)
        return;
      this.m_SelectedFamily.IsModified = true;
      this.m_SelectedFamily.FamilyTypeList = familyTypeList;
      this.UpdateList(this.m_TypeListView.Items.Count, this.m_SelectedFamily.FamilyTypeList.Count, false);
    }
  }

  private void OnModifyButtonClicked(object sender, EventArgs e)
  {
    if (this.m_TypeListView.Items.Count <= 0)
      return;
    this.Modify();
  }

  private void Modify()
  {
    int index = -1;
    if (this.m_TypeListView.SelectedItems.Count >= 1)
    {
      int num1;
      for (num1 = 0; num1 < this.m_SelectedFamily.FamilyTypeList.Count; ++num1)
      {
        if (this.m_SelectedFamily.FamilyTypeList[num1].Status != FamilyParameterWrapperStatus.Excluded)
        {
          index = this.m_TypeListView.SelectedItems.IndexOfKey(this.m_SelectedFamily.FamilyTypeList[num1].FamilyTypeWrapper.FamilyTypeName);
          if (index >= 0)
            break;
        }
      }
      if (this.m_SelectedFamily.FamilyTypeList == null)
        this.m_SelectedFamily.FamilyTypeList = new List<FamilyTypeContainer>();
      List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
      List<FamilyTypeContainer> familyTypeList = this.m_SelectedFamily.FamilyTypeList;
      using (AddModifyFamilyForm modifyFamilyForm = new AddModifyFamilyForm(this.m_ParameterList, ref familyTypeList, this.m_Units, this.m_DisplayUnitSystem, this.m_FormatOptions, this.m_UnitSymbolType, this.m_SlopeOptions, this.m_SlopeSymbolType, this.m_AngularOptions, this.m_AngularSymbolType, this.m_AllMaterialList, this.m_DecimalSymbolType, num1, this.m_CurrentFamilyType, this.m_SelectedFamily.FamilyName))
      {
        int num2 = (int) modifyFamilyForm.ShowDialog();
        if (modifyFamilyForm.DialogResult != DialogResult.OK)
          return;
        this.m_SelectedFamily.FamilyTypeList = familyTypeList;
        this.m_SelectedFamily.IsModified = true;
        this.UpdateList(this.m_TypeListView.SelectedIndices[index], num1, true);
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoTypeSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void OnDeleteButtonClicked(object sender, EventArgs e)
  {
    if (this.m_TypeListView.SelectedItems.Count >= 1)
    {
      for (int index1 = this.m_SelectedFamily.FamilyTypeList.Count - 1; index1 >= 0; --index1)
      {
        int index2 = this.m_TypeListView.SelectedItems.IndexOfKey(this.m_SelectedFamily.FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
        if (index2 >= 0)
        {
          this.m_SelectedFamily.FamilyTypeList.RemoveAt(index1);
          this.m_SelectedFamily.IsModified = true;
          this.m_TypeListView.SelectedItems[index2].Remove();
          if (this.m_TypeListView.SelectedItems.Count == 0)
            break;
        }
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoTypeSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void CleanMix()
  {
  }

  private void UpdateList(int _nSelectedListIndex, int _nFamilyTypeListIndex, bool _bModify)
  {
    if (_bModify)
      this.m_TypeListView.Items.RemoveAt(_nSelectedListIndex);
    else
      --_nFamilyTypeListIndex;
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList = new List<FamilyParameterTypeWrapper>();
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.PlantMix:
      case LandcaddID.PatioWalk:
        parameterTypeWrapperList = ManagePlants.PlantMixParamenterList();
        break;
      case LandcaddID.SoftTerrain:
        parameterTypeWrapperList = ManageFamily.SoftTerrainParameterList();
        break;
      case LandcaddID.Street:
        parameterTypeWrapperList = ManageFamily.StreetParamenterList();
        break;
      case LandcaddID.Curb:
        parameterTypeWrapperList = ManageFamily.CurbParameterList();
        break;
      case LandcaddID.Sidewalk:
        parameterTypeWrapperList = ManageFamily.SideWalkParamterList();
        break;
      case LandcaddID.RetainingWall:
        parameterTypeWrapperList = ManageFamily.RetainingWallParameterList();
        break;
      case LandcaddID.Steps:
        parameterTypeWrapperList = ManageFamily.StepsParameterList();
        break;
      case LandcaddID.ParkingLot:
        parameterTypeWrapperList = ManageFamily.ParkingLotParameterList();
        break;
    }
    List<FamilyParameterWrapper> parameterWrapperList = new List<FamilyParameterWrapper>();
    if (!_bModify)
    {
      bool flag1 = false;
      for (int index1 = 0; index1 < parameterTypeWrapperList.Count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList.Count; ++index2)
        {
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList[index2].ParameterName, true) == 0)
          {
            parameterWrapperList.Add(this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList[index2]);
            flag1 = true;
            break;
          }
        }
        if (!flag1)
        {
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index1].ParameterDisplayName, parameterTypeWrapperList[index1].ParameterName, this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
            continue;
          }
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index1].ParameterDisplayName, parameterTypeWrapperList[index1].ParameterName, "", (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
            continue;
          }
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index1].ParameterDisplayName, parameterTypeWrapperList[index1].ParameterName, Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000"), (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
            continue;
          }
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index1].ParameterDisplayName, parameterTypeWrapperList[index1].ParameterName, "", (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
            continue;
          }
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index1].ParameterDisplayName, parameterTypeWrapperList[index1].ParameterName, RevitParameters.PlantMixSpacingMethodTriangular, (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
            continue;
          }
          if (string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList[index1].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index1].ParameterDisplayName, parameterTypeWrapperList[index1].ParameterName, "0.0", (StorageType) 2);
            parameterWrapperList.Add(parameterWrapper);
            continue;
          }
        }
        flag1 = false;
      }
      bool flag2 = false;
      string empty = string.Empty;
      for (int index3 = 0; index3 < parameterTypeWrapperList.Count; ++index3)
      {
        for (int index4 = 0; index4 < parameterWrapperList.Count; ++index4)
        {
          if (string.Compare(parameterTypeWrapperList[index3].ParameterName, parameterWrapperList[index4].ParameterName, true) == 0)
          {
            flag2 = true;
            break;
          }
        }
        if (!flag2)
        {
          StorageType _StorageType = (StorageType) 3;
          string _strParameterValue = "";
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList[index3].ParameterDisplayName, parameterTypeWrapperList[index3].ParameterName, _strParameterValue, _StorageType);
          parameterWrapperList.Insert(index3, parameterWrapper);
        }
        flag2 = false;
      }
    }
    else
      parameterWrapperList = this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList;
    string str = string.Empty;
    ListViewItem listViewItem = new ListViewItem();
    listViewItem.Tag = (object) this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
    for (int index = 0; index < parameterWrapperList.Count; ++index)
    {
      switch (this.m_CurrentFamilyType)
      {
        case LandcaddID.PlantMix:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
          {
            if (str == null)
              str = string.Empty;
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
            {
              double _dConvertedDouble = 1.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
            {
              double _dValue = 1.0;
              if (str != string.Empty)
                _dValue = ValueConversion.ToDouble(str);
              str = ValueConversion.ToString(_dValue);
              goto default;
            }
            goto default;
          }
          break;
        case LandcaddID.PatioWalk:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
            {
              double _dConvertedDouble = 1.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
            {
              str = string.Compare(str, "1", true) != 0 ? (string.Compare(str, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
              goto default;
            }
            if (str == string.Empty && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.MaterialPathWalkFamilyParameter, true) == 0)
            {
              str = this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
              goto default;
            }
            goto default;
          }
          break;
        case LandcaddID.SoftTerrain:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SoftTerrainLeftOffsetWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SoftTerrainRightOffsetWidthParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SoftTerrainCutSlopeParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SoftTerrainFillSlopeParameter, true) == 0)
            {
              RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              try
              {
                double _dConvertedDouble = 0.0;
                if (str != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str))
                  _dAngle = ValueConversion.ToDouble(str);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else
              goto default;
          }
          else
            break;
        case LandcaddID.Street:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetBoulevardWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetLaneWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetPavementDepthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetBaseSurfaceParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetSubbaseSurfaceParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbDisplayParameter, true) == 0)
            {
              str = string.Compare(str, "1", true) != 0 ? (string.Compare(str, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCrossSlopeParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCutSlopeParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetFillSlopeParameter, true) == 0)
            {
              RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetPavementSurfaceParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
            {
              if (str != string.Empty)
              {
                string strStringToFind = str;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                goto default;
              }
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              try
              {
                double _dConvertedDouble = 0.0;
                if (str != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str))
                  _dAngle = ValueConversion.ToDouble(str);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else
              goto default;
          }
          else
            break;
        case LandcaddID.Curb:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbHeightParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbOffsetParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurbGutterHeightParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetGutterWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurbBaseSurfaceParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurbSubbaseSurfaceParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetGutterSlopeParameter, true) == 0)
            {
              RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StreetCurbMaterialParameter, true) == 0)
            {
              if (str != string.Empty)
              {
                string strStringToFind = str;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                goto default;
              }
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              try
              {
                double _dConvertedDouble = 0.0;
                if (str != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str))
                  _dAngle = ValueConversion.ToDouble(str);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else
              goto default;
          }
          else
            break;
        case LandcaddID.Sidewalk:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkWidthParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkPavementDepthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkBaseSurfaceParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkSubbaseSurfaceParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkCutSlopeParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkFillSlopeParameter, true) == 0)
            {
              RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkPavementSurfaceParameter, true) == 0)
            {
              if (str != string.Empty)
              {
                string strStringToFind = str;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                goto default;
              }
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SideWalkLocationLineParameter, true) != 0)
            {
              if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
              {
                try
                {
                  double _dConvertedDouble = 0.0;
                  if (str != string.Empty)
                    _dConvertedDouble = ValueConversion.ToDouble(str);
                  RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                  goto default;
                }
                catch (Exception ex)
                {
                  str = "";
                  goto default;
                }
              }
              else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
              {
                try
                {
                  double _dAngle = 0.0;
                  if (!string.IsNullOrEmpty(str))
                    _dAngle = ValueConversion.ToDouble(str);
                  RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                  goto default;
                }
                catch (Exception ex)
                {
                  str = "";
                  goto default;
                }
              }
              else
                goto default;
            }
            else
              break;
          }
          else
            break;
        case LandcaddID.RetainingWall:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallWidthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallHeightParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallBaseSurfaceParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallSubbaseSurfaceParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallCutSlopeParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallFillSlopeParameter, true) == 0)
            {
              RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(str), this.m_SlopeDisplayUnitType, this.m_SlopeAccuracy, this.m_SlopeSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallMaterialParameter, true) == 0)
            {
              if (str != string.Empty)
              {
                string strStringToFind = str;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                goto default;
              }
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RetainingWallSlopeProjectionParameter, true) == 0)
            {
              str = string.Compare(str, "1", true) != 0 ? (string.Compare(str, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              try
              {
                double _dConvertedDouble = 0.0;
                if (str != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str))
                  _dAngle = ValueConversion.ToDouble(str);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else
              goto default;
          }
          else
            break;
        case LandcaddID.Steps:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StepsHeightParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StepsTreadParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StepsWidthParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.StepsMaterialParameter, true) == 0)
            {
              if (str != string.Empty)
              {
                string strStringToFind = str;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                goto default;
              }
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              try
              {
                double _dConvertedDouble = 0.0;
                if (str != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str))
                  _dAngle = ValueConversion.ToDouble(str);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else
              goto default;
          }
          else
            break;
        case LandcaddID.ParkingLot:
          str = parameterWrapperList[index].Value;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlacementIDFamilyParameter, true) != 0)
          {
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.ParkingLotPavementDepthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.ParkingLotParkingBaseDepthParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.ParkingLotParkingSubBaseDepthParameter, true) == 0)
            {
              double _dConvertedDouble = 0.0;
              if (str != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(str);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.ParkingLotParkingPavementSurfaceParameter, true) == 0)
            {
              if (str != string.Empty)
              {
                string strStringToFind = str;
                List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == Convert.ToInt32(strStringToFind))).ToList<Material>();
                str = list.Count < 1 ? "" : ((Element) list.ElementAt<Material>(0)).Name;
                goto default;
              }
              goto default;
            }
            if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LinearIncrementParameter, true) == 0)
            {
              try
              {
                double _dConvertedDouble = 0.0;
                if (str != string.Empty)
                  _dConvertedDouble = ValueConversion.ToDouble(str);
                RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.CurveIncrementParameter, true) == 0)
            {
              try
              {
                double _dAngle = 0.0;
                if (!string.IsNullOrEmpty(str))
                  _dAngle = ValueConversion.ToDouble(str);
                RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dAngle, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref str);
                goto default;
              }
              catch (Exception ex)
              {
                str = "";
                goto default;
              }
            }
            else
              goto default;
          }
          else
            break;
        default:
          if (index == 0)
          {
            listViewItem = !_bModify ? this.m_TypeListView.Items.Add(this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, string.Empty) : this.m_TypeListView.Items.Insert(_nSelectedListIndex, this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, string.Empty);
            listViewItem.Tag = (object) this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
            break;
          }
          listViewItem.SubItems.Add(str);
          break;
      }
    }
    int index5 = parameterWrapperList.FindIndex(new Predicate<FamilyParameterWrapper>(TypeManagerForm.FindTypeName));
    if (index5 >= 0)
      parameterWrapperList.RemoveAt(index5);
    this.m_SelectedFamily.FamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList = parameterWrapperList;
    if (this.m_TypeListView.Items.Count <= 0)
      return;
    if (_bModify)
      this.m_TypeListView.Items[_nSelectedListIndex].Selected = true;
    else
      this.m_TypeListView.Items[this.m_TypeListView.Items.Count - 1].Selected = true;
  }

  private static bool FindTypeName(FamilyParameterWrapper _CurrParameter)
  {
    return string.Compare(_CurrParameter.ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0;
  }

  private void OnEqualButtonClick(object sender, EventArgs e)
  {
  }

  private void RefreshListView()
  {
  }

  private bool CheckPercentage() => true;

  private void MixListViewDoubleClicked(object sender, EventArgs e) => this.Modify();

  private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nMixtListViewSortColumn)
    {
      this.m_nMixtListViewSortColumn = e.Column;
      this.m_TypeListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_TypeListView.Sorting = this.m_TypeListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_TypeListView.Sort();
    this.m_TypeListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_TypeListView.Sorting);
  }

  private bool CreateParameterList(
    Document _ActiveDocument,
    LandcaddID _Type,
    ref Document _CurDocument,
    ref EPTransactionContainer _TransactionContainer,
    ref List<FamilyParameter> _NewFamilyParameterList)
  {
    _CurDocument = _ActiveDocument;
    _TransactionContainer = new EPTransactionContainer(_CurDocument);
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList = new List<FamilyParameterTypeWrapper>();
    string empty = string.Empty;
    switch (_Type)
    {
      case LandcaddID.PlantMix:
        parameterTypeWrapperList = ManagePlants.PlantMixParamenterList();
        _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePlantMixFamilyTransaction"));
        break;
      case LandcaddID.PatioWalk:
        parameterTypeWrapperList = ManagePlants.PatioWalkParamenterList();
        _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePatioWalkFamilyTransaction"));
        break;
      case LandcaddID.SoftTerrain:
        parameterTypeWrapperList = ManageFamily.SoftTerrainParameterList();
        string _strTransactionName1 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("SoftTerrainManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName1);
        break;
      case LandcaddID.Street:
        parameterTypeWrapperList = ManageFamily.StreetParamenterList();
        string _strTransactionName2 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("StreetTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName2);
        break;
      case LandcaddID.Curb:
        parameterTypeWrapperList = ManageFamily.CurbParameterList();
        string _strTransactionName3 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("CurbTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName3);
        break;
      case LandcaddID.Sidewalk:
        parameterTypeWrapperList = ManageFamily.SideWalkParamterList();
        string _strTransactionName4 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("SidewalkTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName4);
        break;
      case LandcaddID.RetainingWall:
        parameterTypeWrapperList = ManageFamily.RetainingWallParameterList();
        string _strTransactionName5 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("RetainingWallManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName5);
        break;
      case LandcaddID.Steps:
        parameterTypeWrapperList = ManageFamily.StepsParameterList();
        string _strTransactionName6 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("StepsManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName6);
        break;
      case LandcaddID.ParkingLot:
        parameterTypeWrapperList = ManageFamily.ParkingLotParameterList();
        string _strTransactionName7 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("ParkingLotManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName7);
        break;
    }
    _TransactionContainer.BeginTransaction();
    BuiltInParameterGroup inParameterGroup = (BuiltInParameterGroup) -1;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = parameterTypeWrapperList.Count;
    if (parameterTypeWrapperList.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSettingParametersMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    for (int index = 0; index < parameterTypeWrapperList.Count; ++index)
    {
      if (string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) != 0)
      {
        FamilyParameter familyParameter = (FamilyParameter) null;
        if (parameterTypeWrapperList[index].BuiltInParameter != -1)
          familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList[index].BuiltInParameter];
        if (familyParameter == null)
          familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList[index].ParameterName];
        if (familyParameter != null)
        {
          _NewFamilyParameterList.Add(familyParameter);
        }
        else
        {
          if (parameterTypeWrapperList[index].ParameterType == 3 || parameterTypeWrapperList[index].ParameterType == 2 || parameterTypeWrapperList[index].ParameterType == 4)
            inParameterGroup = (BuiltInParameterGroup) -5000101;
          else if (parameterTypeWrapperList[index].ParameterType == 1 || parameterTypeWrapperList[index].ParameterType == 17 || parameterTypeWrapperList[index].ParameterType == 172)
            inParameterGroup = (BuiltInParameterGroup) -5000100;
          if (string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0)
            _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList[index].ParameterName, inParameterGroup, parameterTypeWrapperList[index].ParameterType, true));
          else
            _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList[index].ParameterName, inParameterGroup, parameterTypeWrapperList[index].ParameterType, false));
        }
        progressBarForm.UpdateProgressBar(1);
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  public bool UpdateFamilyDocument(
    Document _ActiveDocument,
    List<FamilyTypeContainer> _FamilyTypeList,
    LandcaddID _Type)
  {
    double _dValue = 0.0;
    string empty1 = string.Empty;
    int _nValue = 0;
    ElementId elementId = (ElementId) null;
    Document _CurDocument = _ActiveDocument;
    EPTransactionContainer _TransactionContainer = (EPTransactionContainer) null;
    List<FamilyParameter> _NewFamilyParameterList = new List<FamilyParameter>();
    if (!this.CreateParameterList(_ActiveDocument, _Type, ref _CurDocument, ref _TransactionContainer, ref _NewFamilyParameterList))
      return false;
    bool flag = false;
    string empty2 = string.Empty;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _FamilyTypeList.Count;
    if (_FamilyTypeList.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarCreatingFamilyMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    List<FamilyType> familyTypeList = ManageFamily.RemoveTypesFromDocument(_CurDocument.FamilyManager.Types, _FamilyTypeList);
    for (int index1 = 0; index1 < _FamilyTypeList.Count; ++index1)
    {
      if (!this.CheckForSiteworksIDParameter(_FamilyTypeList[index1].FamilyParameterList))
      {
        FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), RevitParameters.SiteworksIDFamilyParameter, "", (StorageType) 3);
        _FamilyTypeList[index1].FamilyParameterList.Add(parameterWrapper);
      }
      FamilyType _SelectedType = (FamilyType) null;
      if (_FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName != string.Empty)
      {
        FamilyType familyType = ManageFamily.FindTypeNames(_CurDocument.FamilyManager.Types, _FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName, ref _SelectedType) ? _SelectedType : _CurDocument.FamilyManager.NewType(_FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
        _CurDocument.FamilyManager.CurrentType = familyType;
        progressBarForm.Message = $"{EPShared.LocalRM.GetString("CreatingFamilyTypeMessage")} {familyType.Name}";
        progressBarForm.ResetValue();
        progressBarForm.MinValue = 0;
        progressBarForm.MaxValue = _NewFamilyParameterList.Count * 2;
label_60:
        for (int index2 = 0; index2 < _NewFamilyParameterList.Count; ++index2)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter1 = _NewFamilyParameterList[index2];
          if (familyParameter1 != null)
          {
            for (int index3 = 0; index3 < _FamilyTypeList[index1].FamilyParameterList.Count; ++index3)
            {
              FamilyParameterWrapper familyParameter2 = _FamilyTypeList[index1].FamilyParameterList[index3];
              if (familyParameter2 != null && (familyParameter2.FamilyParameter != null && familyParameter2.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter2.FamilyParameter.Id, familyParameter1.Id) || string.Compare(familyParameter2.ParameterName, familyParameter1.Definition.Name, true) == 0) && familyParameter2.StorageType == familyParameter1.StorageType)
              {
                string formula = familyParameter1.Formula;
                if (formula == null || formula == string.Empty)
                {
                  if (_FamilyTypeList[index1].HasValue(index3))
                  {
                    switch (familyParameter2.StorageType - 1)
                    {
                      case 0:
                        if (_FamilyTypeList[index1].GetIntegerValue(index3, ref _nValue))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, _nValue);
                          goto label_60;
                        }
                        goto label_60;
                      case 1:
                        if (_FamilyTypeList[index1].GetDoubleValue(index3, ref _dValue))
                        {
                          try
                          {
                            if (familyParameter1.DisplayUnitType != 158 && familyParameter1.DisplayUnitType != 159 && familyParameter1.DisplayUnitType != 161 && familyParameter1.DisplayUnitType != 162 && familyParameter1.DisplayUnitType != 163)
                            {
                              if (familyParameter1.DisplayUnitType != 160 /*0xA0*/)
                                goto label_21;
                            }
                            FormatOptions formatOptions = _CurDocument.GetUnits().GetFormatOptions((UnitType) 59);
                            if (formatOptions.DisplayUnits != 19)
                              formatOptions.DisplayUnits = (DisplayUnitType) 19;
                          }
                          catch (InvalidOperationException ex)
                          {
                          }
label_21:
                          _CurDocument.FamilyManager.Set(familyParameter1, _dValue);
                          goto label_60;
                        }
                        goto label_60;
                      case 2:
                        if (_FamilyTypeList[index1].GetStringValue(index3, ref empty1))
                        {
                          if (string.Compare(_FamilyTypeList[index1].FamilyParameterList[index3].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0)
                          {
                            switch (_Type)
                            {
                              case LandcaddID.PlantMix:
                                empty1 = Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
                                break;
                              case LandcaddID.PatioWalk:
                                empty1 = Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000");
                                break;
                              case LandcaddID.SoftTerrain:
                                empty1 = Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000");
                                break;
                              case LandcaddID.Street:
                                empty1 = Convert.ToInt32((object) LandcaddID.Street).ToString("000");
                                break;
                              case LandcaddID.Curb:
                                empty1 = Convert.ToInt32((object) LandcaddID.Curb).ToString("000");
                                break;
                              case LandcaddID.Sidewalk:
                                empty1 = Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000");
                                break;
                              case LandcaddID.RetainingWall:
                                empty1 = Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000");
                                break;
                              case LandcaddID.Steps:
                                empty1 = Convert.ToInt32((object) LandcaddID.Steps).ToString("000");
                                break;
                              case LandcaddID.ParkingLot:
                                empty1 = Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000");
                                break;
                            }
                          }
                          _CurDocument.FamilyManager.Set(familyParameter1, empty1);
                          goto label_60;
                        }
                        goto label_60;
                      case 3:
                        if (_FamilyTypeList[index1].GetElementIdValue(index3, ref elementId))
                        {
                          try
                          {
                            _CurDocument.FamilyManager.Set(familyParameter1, elementId);
                            goto label_60;
                          }
                          catch (ArgumentOutOfRangeException ex)
                          {
                            if (ex.Message.StartsWith(EPShared.LocalRM.GetString("OutOfRangeArgumentMessage")))
                            {
                              flag = true;
                              goto label_60;
                            }
                            goto label_60;
                          }
                        }
                        else
                          goto label_60;
                      default:
                        goto label_60;
                    }
                  }
                  else
                  {
                    if (string.Compare(_FamilyTypeList[index1].FamilyParameterList[index3].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0)
                    {
                      switch (_Type)
                      {
                        case LandcaddID.PlantMix:
                          empty1 = Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
                          break;
                        case LandcaddID.PatioWalk:
                          empty1 = Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000");
                          break;
                        case LandcaddID.SoftTerrain:
                          empty1 = Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000");
                          break;
                        case LandcaddID.Street:
                          empty1 = Convert.ToInt32((object) LandcaddID.Street).ToString("000");
                          break;
                        case LandcaddID.Curb:
                          empty1 = Convert.ToInt32((object) LandcaddID.Curb).ToString("000");
                          break;
                        case LandcaddID.Sidewalk:
                          empty1 = Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000");
                          break;
                        case LandcaddID.RetainingWall:
                          empty1 = Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000");
                          break;
                        case LandcaddID.Steps:
                          empty1 = Convert.ToInt32((object) LandcaddID.Steps).ToString("000");
                          break;
                        case LandcaddID.ParkingLot:
                          empty1 = Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000");
                          break;
                      }
                      _CurDocument.FamilyManager.Set(familyParameter1, empty1);
                      break;
                    }
                    switch (familyParameter1.StorageType - 1)
                    {
                      case 0:
                        _CurDocument.FamilyManager.Set(familyParameter1, 0);
                        goto label_60;
                      case 1:
                        _CurDocument.FamilyManager.Set(familyParameter1, 0.0);
                        goto label_60;
                      case 2:
                        _CurDocument.FamilyManager.Set(familyParameter1, string.Empty);
                        goto label_60;
                      default:
                        goto label_60;
                    }
                  }
                }
              }
            }
          }
        }
        for (int index4 = 0; index4 < _NewFamilyParameterList.Count; ++index4)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter3 = _NewFamilyParameterList[index4];
          if (familyParameter3 != null)
          {
            for (int index5 = 0; index5 < _FamilyTypeList[index1].FamilyParameterList.Count; ++index5)
            {
              FamilyParameterWrapper familyParameter4 = _FamilyTypeList[index1].FamilyParameterList[index5];
              if (familyParameter4 != null && (familyParameter4.FamilyParameter != null && familyParameter4.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter4.FamilyParameter.Id, familyParameter3.Id) || string.Compare(familyParameter4.ParameterName, familyParameter3.Definition.Name, true) == 0) && familyParameter4.StorageType == familyParameter3.StorageType)
              {
                string formula = familyParameter3.Formula;
                if (formula != null && formula != string.Empty)
                {
                  if (_FamilyTypeList[index1].HasValue(index5))
                    _CurDocument.FamilyManager.SetFormula(familyParameter3, formula);
                  _FamilyTypeList[index1].FamilyParameterList.RemoveAt(index5);
                  _NewFamilyParameterList.RemoveAt(index4);
                  --index4;
                  break;
                }
              }
            }
          }
        }
      }
    }
    foreach (FamilyType familyType in familyTypeList)
    {
      _CurDocument.FamilyManager.CurrentType = familyType;
      _CurDocument.FamilyManager.DeleteCurrentType();
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    _TransactionContainer.EndTransaction();
    _TransactionContainer.Commit();
    if (flag)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("GetNewRevitVersionMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    return true;
  }

  private bool CheckForSiteworksIDParameter(List<FamilyParameterWrapper> _ParameterWrapperList)
  {
    foreach (FamilyParameterWrapper parameterWrapper in _ParameterWrapperList)
    {
      if (string.Compare(parameterWrapper.ParameterName, RevitParameters.SiteworksIDFamilyParameter, false) == 0)
        return true;
    }
    return false;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_DynGroupBox = new GroupBox();
    this.m_ModifyButton = new Button();
    this.m_EqualButton = new Button();
    this.m_DeleteButton = new Button();
    this.m_AddButton = new Button();
    this.m_SearchButton = new Button();
    this.m_TypeListView = new ListView();
    this.m_SaveFamilyButton = new Button();
    this.m_CancelButton = new Button();
    this.m_DynGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_DynGroupBox.Controls.Add((Control) this.m_ModifyButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_EqualButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_DeleteButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_AddButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_SearchButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_TypeListView);
    this.m_DynGroupBox.Location = new Point(12, 12);
    this.m_DynGroupBox.Name = "m_DynGroupBox";
    this.m_DynGroupBox.Size = new Size(573, 281);
    this.m_DynGroupBox.TabIndex = 0;
    this.m_DynGroupBox.TabStop = false;
    this.m_DynGroupBox.Text = "PlantMix";
    this.m_ModifyButton.Location = new Point(491, 41);
    this.m_ModifyButton.Name = "m_ModifyButton";
    this.m_ModifyButton.Size = new Size(75, 23);
    this.m_ModifyButton.TabIndex = 2;
    this.m_ModifyButton.Text = "Modify";
    this.m_ModifyButton.UseVisualStyleBackColor = true;
    this.m_ModifyButton.Click += new EventHandler(this.OnModifyButtonClicked);
    this.m_EqualButton.Location = new Point(491, 100);
    this.m_EqualButton.Name = "m_EqualButton";
    this.m_EqualButton.Size = new Size(75, 23);
    this.m_EqualButton.TabIndex = 4;
    this.m_EqualButton.Text = "Equal";
    this.m_EqualButton.UseVisualStyleBackColor = true;
    this.m_EqualButton.Click += new EventHandler(this.OnEqualButtonClick);
    this.m_DeleteButton.Location = new Point(492, 70);
    this.m_DeleteButton.Name = "m_DeleteButton";
    this.m_DeleteButton.Size = new Size(75, 24);
    this.m_DeleteButton.TabIndex = 3;
    this.m_DeleteButton.Text = "Delete";
    this.m_DeleteButton.UseVisualStyleBackColor = true;
    this.m_DeleteButton.Click += new EventHandler(this.OnDeleteButtonClicked);
    this.m_AddButton.Location = new Point(491, 12);
    this.m_AddButton.Name = "m_AddButton";
    this.m_AddButton.Size = new Size(75, 23);
    this.m_AddButton.TabIndex = 1;
    this.m_AddButton.Text = "Add";
    this.m_AddButton.UseVisualStyleBackColor = true;
    this.m_AddButton.Click += new EventHandler(this.OnAddButtonClicked);
    this.m_SearchButton.Location = new Point(491, 129);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(75, 23);
    this.m_SearchButton.TabIndex = 5;
    this.m_SearchButton.Text = "Search";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButtonClicked);
    this.m_TypeListView.FullRowSelect = true;
    this.m_TypeListView.HideSelection = false;
    this.m_TypeListView.Location = new Point(4, 14);
    this.m_TypeListView.Name = "m_TypeListView";
    this.m_TypeListView.Size = new Size(481, 261);
    this.m_TypeListView.TabIndex = 0;
    this.m_TypeListView.UseCompatibleStateImageBehavior = false;
    this.m_TypeListView.DoubleClick += new EventHandler(this.MixListViewDoubleClicked);
    this.m_TypeListView.ColumnClick += new ColumnClickEventHandler(this.OnMixListViewColumnClick);
    this.m_SaveFamilyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_SaveFamilyButton.Location = new Point(429, 299);
    this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
    this.m_SaveFamilyButton.Size = new Size(75, 23);
    this.m_SaveFamilyButton.TabIndex = 1;
    this.m_SaveFamilyButton.Text = "OK";
    this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
    this.m_SaveFamilyButton.Click += new EventHandler(this.OnUpdateFamilyButtonClicked);
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.Location = new Point(510, 299);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 2;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.CancelButtonClicked);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(599, 334);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_SaveFamilyButton);
    this.Controls.Add((Control) this.m_DynGroupBox);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(598, 359);
    this.Name = nameof (TypeManagerForm);
    this.Text = "TypeManager";
    this.FormClosing += new FormClosingEventHandler(this.OnTypeManagerFormClosing);
    this.m_DynGroupBox.ResumeLayout(false);
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_SaveFamilyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
