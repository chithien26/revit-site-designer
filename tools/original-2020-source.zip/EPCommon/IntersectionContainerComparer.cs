﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.IntersectionContainerComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class IntersectionContainerComparer : IComparer<IntersectionContainer>
{
  private bool m_bDecendingValues;
  private bool m_bCompareFirstStations = true;

  public IntersectionContainerComparer(bool _bCompareFirstStations)
  {
    this.m_bCompareFirstStations = _bCompareFirstStations;
  }

  int IComparer<IntersectionContainer>.Compare(
    IntersectionContainer first,
    IntersectionContainer second)
  {
    int num = 0;
    if (first != null && first.Profiles != null && first.Profiles.Count > 0)
      num = second == null || second.Profiles == null || second.Profiles.Count <= 0 ? -1 : (!this.m_bCompareFirstStations ? first.Profiles[first.Profiles.Count - 1].Station.CompareTo(second.Profiles[second.Profiles.Count - 1].Station) : first.Profiles[0].Station.CompareTo(second.Profiles[0].Station));
    else if (second != null && second.Profiles != null && second.Profiles.Count > 0)
      num = 1;
    if (this.m_bDecendingValues)
      num = -num;
    return num;
  }
}
