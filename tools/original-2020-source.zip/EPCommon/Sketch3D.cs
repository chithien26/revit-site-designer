﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Sketch3D
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;

#nullable disable
namespace EPCommon;

public class Sketch3D
{
  private const float MarginRatio = 0.1f;
  private const float MoveDistance = 2f;
  private const float ZoomRatio = 0.05f;
  private List<PointF[]> m_curve3Ds = new List<PointF[]>();
  private Graphics3DData m_data3D;
  private Matrix m_transform3D;
  private RectangleF m_displayBBox = new RectangleF(0.0f, 0.0f, 10f, 10f);

  public RectangleF DisplayBBox
  {
    get => this.m_displayBBox;
    set
    {
      this.m_displayBBox = value;
      this.Calculate3DTransform();
      this.UpdateDataAndEvent();
      if (this.UpdateViewEvent == null)
        return;
      this.UpdateViewEvent();
    }
  }

  public Graphics3DData Data3D
  {
    get => this.m_data3D;
    set
    {
      this.m_data3D = value;
      this.UpdateDataAndEvent();
      if (this.UpdateViewEvent == null)
        return;
      this.UpdateViewEvent();
    }
  }

  public event UpdateViewDelegate UpdateViewEvent;

  public Sketch3D(Graphics3DData data3D)
  {
    this.m_data3D = data3D;
    this.Calculate3DTransform();
    this.UpdateDataAndEvent();
  }

  public void Draw(Graphics graphics)
  {
    if (this.m_data3D.NumPoints == 0)
    {
      graphics.Clear(Color.LightGray);
    }
    else
    {
      graphics.Clear(Color.White);
      this.DrawCurves(graphics, this.m_curve3Ds, this.m_transform3D, new Pen(Color.DarkGreen));
    }
  }

  public void Zoom(bool zoomIn)
  {
    if (zoomIn)
      this.m_transform3D.Scale(0.95f, 0.95f, MatrixOrder.Append);
    else
      this.m_transform3D.Scale(1.05f, 1.05f, MatrixOrder.Append);
    if (this.UpdateViewEvent == null)
      return;
    this.UpdateViewEvent();
  }

  public void MoveX(bool left)
  {
    if (left)
      this.m_transform3D.Translate(-2f, 0.0f, MatrixOrder.Append);
    else
      this.m_transform3D.Translate(2f, 0.0f, MatrixOrder.Append);
    if (this.UpdateViewEvent == null)
      return;
    this.UpdateViewEvent();
  }

  public void MoveY(bool up)
  {
    if (up)
      this.m_transform3D.Translate(0.0f, 2f, MatrixOrder.Append);
    else
      this.m_transform3D.Translate(0.0f, -2f, MatrixOrder.Append);
    if (this.UpdateViewEvent == null)
      return;
    this.UpdateViewEvent();
  }

  private void UpdateDataAndEvent()
  {
    this.Initialize3DData();
    this.m_data3D.UpdateViewEvent += new UpdateViewDelegate(this.DataUpdateViewEvent);
  }

  private void Initialize3DData()
  {
    this.m_curve3Ds.Clear();
    foreach (List<Vector> constCurve in this.m_data3D.ConstCurves)
    {
      PointF[] pointFArray = new PointF[constCurve.Count];
      this.m_curve3Ds.Add(pointFArray);
      for (int index = 0; index < constCurve.Count; ++index)
        pointFArray[index] = new PointF((float) constCurve[index].X, (float) constCurve[index].Y);
    }
  }

  private void DrawCurves(Graphics graphics, List<PointF[]> curves, Matrix transform, Pen pen)
  {
    foreach (PointF[] curve in curves)
    {
      GraphicsPath path = new GraphicsPath();
      if (curve.Length == 0)
        break;
      if (curve.Length == 1)
        path.AddArc(new RectangleF(curve[0], new SizeF(0.5f, 0.5f)), 0.0f, 3.14159274f);
      else
        path.AddLines(curve);
      path.Transform(transform);
      graphics.DrawPath(pen, path);
    }
  }

  private void DataUpdateViewEvent()
  {
    this.Initialize3DData();
    if (this.UpdateViewEvent == null)
      return;
    this.UpdateViewEvent();
  }

  private void Calculate3DTransform()
  {
    float width = this.m_displayBBox.Width;
    float height = this.m_displayBBox.Height;
    RectangleF boundingBox2D = this.ToBoundingBox2D(this.m_data3D.BoundingBox);
    PointF[] canvasRegion = this.CalculateCanvasRegion(width, height, boundingBox2D);
    this.m_transform3D = new Matrix(this.PreTreatBBox(boundingBox2D), canvasRegion);
  }

  private RectangleF PreTreatBBox(RectangleF bbox)
  {
    if ((double) bbox.Height < 1.0 / 1000.0)
      bbox.Height = 1f / 1000f;
    if ((double) bbox.Width < 1.0 / 1000.0)
      bbox.Width = 1f / 1000f;
    return bbox;
  }

  private PointF[] CalculateCanvasRegion(float previewWidth, float previewHeigh, RectangleF bbox)
  {
    float num1 = previewWidth * 0.8f;
    float num2 = previewHeigh * 0.8f;
    float x = previewWidth * 0.1f;
    float y = previewHeigh * 0.1f;
    float num3 = bbox.Width / bbox.Height;
    float num4 = num1 / num2;
    if ((double) num3 > (double) num4)
    {
      float num5 = num1 / num3;
      y += (float) (((double) num2 - (double) num5) / 2.0);
      num2 = num5;
    }
    else
    {
      float num6 = num2 * num3;
      x += (float) (((double) num1 - (double) num6) / 2.0);
      num1 = num6;
    }
    return new PointF[3]
    {
      new PointF(x, num2 + y),
      new PointF(num1 + x, num2 + y),
      new PointF(x, y)
    };
  }

  private RectangleF ToBoundingBox2D(BoundingBoxXYZ bbox3D)
  {
    float x1 = (float) bbox3D.Min.X;
    float y1 = (float) bbox3D.Min.Y;
    float x2 = (float) bbox3D.Max.X;
    float y2 = (float) bbox3D.Max.Y;
    return new RectangleF(x1, y1, x2 - x1, y2 - y1);
  }
}
