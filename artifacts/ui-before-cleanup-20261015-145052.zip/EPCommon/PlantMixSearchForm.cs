using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;

namespace EPCommon;

public class PlantMixSearchForm : EPForm
{
	private Units m_Units;

	private Document m_CurDocument;

	private List<FamilyTypeContainer> m_PlantListFamilyTypeList;

	private List<FamilyTypeContainer> m_SelectedPlantListFamilyTypeList;

	private string m_strSourceDirectory = string.Empty;

	private string m_strSourceFile = string.Empty;

	private List<Document> m_OpenDocumentList;

	private List<KeyValuePair<string, string>> m_RecenFilesList;

	private List<ParameterColumn> m_ParameterList;

	private int m_nPlantListViewSortColumn = -1;

	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private string m_strCurrentDir = string.Empty;

	private string m_strRFAFileName = string.Empty;

	private string m_strCSVFileName = string.Empty;

	private string m_strTABFileName = string.Empty;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Button m_CancelButton;

	private Button m_SaveFamilyButton;

	private GroupBox m_SourceGroupBox;

	private TextBox m_SingleFileTextBox;

	private Label m_SingleFileLabel;

	private GroupBox m_CollectionGroupBox;

	private Button m_ColumnDisplayButton;

	private Button m_SearchButton;

	private ListView m_PlantListView;

	private RadioButton m_DirectoryRadioButton;

	private RadioButton m_SingleFileRadioButton;

	private GroupBox m_SingleFileGroupBox;

	private RadioButton m_TabSingleFileRadioButton;

	private RadioButton m_CommaSingleFileRadioButton;

	private RadioButton m_RFASingleFileRadioButton;

	private Button m_SingleFileButton;

	private Button m_ShowAllFamiliesButton;

	public List<FamilyTypeContainer> SelectedPlantListFamilyTypeList => m_SelectedPlantListFamilyTypeList;

	public PlantMixSearchForm(Document _CurDocument)
	{
		InitializeComponent();
		m_CurDocument = _CurDocument;
		m_FormatOptions = m_CurDocument.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_CurDocument.DisplayUnitSystem;
		m_Units = m_CurDocument.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_CurDocument.GetUnits().DecimalSymbol;
		InitializeControls();
		m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
		m_PlantListView.View = System.Windows.Forms.View.Details;
		m_SelectedPlantListFamilyTypeList = new List<FamilyTypeContainer>();
	}

	private void SetupString()
	{
		m_SourceGroupBox.Text = EPShared.LocalRM.GetString("SourceDialog");
		m_SingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleFileDialog");
		m_DirectoryRadioButton.Text = EPShared.LocalRM.GetString("AMP_DirectoryMultipleFilesDialog");
		m_SingleFileGroupBox.Text = EPShared.LocalRM.GetString("SingleFileDialog");
		m_RFASingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_RFAFileDialog");
		m_CommaSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
		m_TabSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
		m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_CollectionGroupBox.Text = EPShared.LocalRM.GetString("PlantDialog") + " " + EPShared.LocalRM.GetString("CollectionDialog");
		m_SearchButton.Text = EPShared.LocalRM.GetString("Searc_AMP_hDialog");
		m_ColumnDisplayButton.Text = EPShared.LocalRM.GetString("Column_AMP_DisplayDialog");
		m_ShowAllFamiliesButton.Text = EPShared.LocalRM.GetString("Sho_AMP_wAllDialog");
		m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("AMP_AddToFamilyDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		Text = EPShared.LocalRM.GetString("PlantSearchDialog") + "  " + EPShared.LocalRM.GetString("ManagerDialog");
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		m_strSourceDirectory = string.Empty;
		m_strSourceFile = string.Empty;
		GetDialogPosition();
		m_SingleFileRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchSourceOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_SingleFileRadioButton.Checked = true;
			}
			else
			{
				m_DirectoryRadioButton.Checked = true;
			}
		}
		m_RFASingleFileRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchSingleFileOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_RFASingleFileRadioButton.Checked = true;
				break;
			case 1:
				m_CommaSingleFileRadioButton.Checked = true;
				break;
			default:
				m_TabSingleFileRadioButton.Checked = true;
				break;
			}
		}
		if (m_SingleFileRadioButton.Checked)
		{
			if (m_RFASingleFileRadioButton.Checked)
			{
				ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchRFASingleFileName", ref _strReturnValue);
			}
			else if (m_CommaSingleFileRadioButton.Checked)
			{
				ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchCSVSingleFileName", ref _strReturnValue);
			}
			else if (m_TabSingleFileRadioButton.Checked)
			{
				ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchTABSingleFileName", ref _strReturnValue);
			}
			m_SingleFileTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixSearchDirectory", ref _strReturnValue))
		{
			m_strCurrentDir = _strReturnValue;
			if (m_DirectoryRadioButton.Checked)
			{
				m_SingleFileTextBox.Text = _strReturnValue;
			}
		}
		LoadColumnSettings();
	}

	private void LoadColumnSettings()
	{
		m_ParameterList = ManagePlants.GetParameterList("PlantMixSearch");
		m_PlantListView.Columns.Clear();
		string empty = string.Empty;
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			empty = ManagePlants.GetPlantParamenterName(m_ParameterList[i].PlantField);
			m_PlantListView.Columns.Add(empty, empty.Length * 10, HorizontalAlignment.Left);
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		num = Convert.ToInt32(!m_SingleFileRadioButton.Checked);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchSourceOption", num);
		num = ((!m_RFASingleFileRadioButton.Checked) ? (m_CommaSingleFileRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchSingleFileOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchCreateSymbolFromDWGCheck", num);
		if (m_SingleFileTextBox.Text != string.Empty && m_SingleFileRadioButton.Checked)
		{
			if (m_RFASingleFileRadioButton.Checked)
			{
				ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchRFASingleFileName", m_strRFAFileName);
			}
			else if (m_CommaSingleFileRadioButton.Checked)
			{
				ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchCSVSingleFileName", m_strCSVFileName);
			}
			else if (m_TabSingleFileRadioButton.Checked)
			{
				ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchTABSingleFileName", m_strTABFileName);
			}
		}
		else if (m_SingleFileTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearchDirectory", m_strCurrentDir);
		}
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixSearch" + m_ParameterList[i].PlantField.ToString() + "ColumnOrder", m_ParameterList[i].Order);
		}
	}

	private List<FamilyTypeContainer> PopulateFamilyTypeSetList(FamilyManager _FamilyManager, List<ExternalDefinitionContainer> _ExternalDefinitionList)
	{
		List<FamilyTypeContainer> list = null;
		string empty = string.Empty;
		string empty2 = string.Empty;
		bool flag = false;
		foreach (FamilyType type in _FamilyManager.Types)
		{
			empty2 = type.Name.Trim();
			if (!(empty2 != string.Empty))
			{
				continue;
			}
			foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
			{
				if (string.Compare(empty2, plantListFamilyType.FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Tag = empty2;
				for (int i = 0; i < m_ParameterList.Count; i++)
				{
					empty = string.Empty;
					FindParamenterValue(_FamilyManager, type, ManagePlants.GetPlantParamenterName(m_ParameterList[i].PlantField), ref empty);
					if (m_ParameterList[i].PlantField == PlantField.Height || m_ParameterList[i].PlantField == PlantField.PlantHeight || m_ParameterList[i].PlantField == PlantField.PlantWidth || m_ParameterList[i].PlantField == PlantField.CharacteristicsFoliageSize || m_ParameterList[i].PlantField == PlantField.PlantSpacing)
					{
						double dConvertedDouble = 0.0;
						if (empty != string.Empty)
						{
							dConvertedDouble = ValueConversion.ToDouble(empty);
						}
						RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
					}
					if (i == 0)
					{
						listViewItem.Text = empty;
					}
					else
					{
						listViewItem.SubItems.Add(empty);
					}
				}
				m_PlantListView.Items.Add(listViewItem);
				if (list == null)
				{
					list = new List<FamilyTypeContainer>();
				}
				list.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetFamilyParameterSetForType(type, _FamilyManager, _ExternalDefinitionList)));
			}
			else
			{
				flag = false;
			}
		}
		return list;
	}

	private bool FindParamenterValue(FamilyManager FamilyManager, FamilyType type, string _strParamter, ref string _strValue)
	{
		PlantField plantField = PlantField.None;
		bool result = false;
		FamilyParameter familyParameter = FamilyManager.get_Parameter(_strParamter);
		if (familyParameter != null && ManagePlants.GetPlantFieldFromParamenter(familyParameter.Definition.Name) != PlantField.None && type.HasValue(familyParameter))
		{
			switch (familyParameter.StorageType)
			{
			case StorageType.Double:
				if (type.AsDouble(familyParameter) is double)
				{
					result = true;
					_strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
				}
				break;
			case StorageType.Integer:
				if (type.AsInteger(familyParameter) is int)
				{
					result = true;
					_strValue = Convert.ToString(type.AsInteger(familyParameter));
				}
				break;
			case StorageType.String:
				if (type.AsString(familyParameter) != null)
				{
					result = true;
					_strValue = type.AsString(familyParameter);
				}
				break;
			}
		}
		return result;
	}

	private void EnableDisableDialogFields(bool _bApplyToListButtons)
	{
		bool enabled = false;
		if (m_PlantListView.Items.Count > 0)
		{
			enabled = true;
		}
		m_PlantListView.Enabled = enabled;
		if (_bApplyToListButtons)
		{
			m_SearchButton.Enabled = enabled;
			m_ColumnDisplayButton.Enabled = enabled;
		}
		m_SaveFamilyButton.Enabled = enabled;
	}

	private void OnSearchButton(object sender, EventArgs e)
	{
		SetSelectedPlantList();
		if (!ManagePlants.FindFamilyTypes(EPShared.LocalRM.GetString("PlantMixPlantSearchTitle"), m_CurDocument, ref m_PlantListFamilyTypeList))
		{
			return;
		}
		int num = -1;
		for (num = 0; num < m_PlantListView.Items.Count; num++)
		{
			if (!m_PlantListView.SelectedIndices.Contains(num))
			{
				m_PlantListView.Items.RemoveAt(num);
				num--;
			}
		}
		m_nPlantListViewSortColumn = -1;
		m_PlantListView.Sorting = SortOrder.None;
		string empty = string.Empty;
		foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
		{
			if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
			{
				PopulatePlantListView(plantListFamilyType);
			}
		}
	}

	private bool ValidateFields()
	{
		string text = "";
		if (!File.Exists(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ExistingSymbolFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return false;
		}
		FileInfo fileInfo = new FileInfo(text);
		if (string.Compare(fileInfo.Extension, ".rfa", ignoreCase: true) != 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SymbolNoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return false;
		}
		return true;
	}

	private void SetSelectedPlantList()
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		if ((num = m_PlantListView.SelectedItems.Count) < 1)
		{
			return;
		}
		for (num2 = 0; num2 < num; num2++)
		{
			for (num3 = 0; num3 < m_PlantListFamilyTypeList.Count; num3++)
			{
				if (m_PlantListFamilyTypeList[num3].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string)m_PlantListView.SelectedItems[num2].Tag, m_PlantListFamilyTypeList[num3].FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
				{
					m_PlantListFamilyTypeList[num3].Status = FamilyParameterWrapperStatus.Selected;
					break;
				}
			}
		}
	}

	private bool FindSelectedPlantList(ref List<FamilyTypeContainer> _SelectedPlantList)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		bool flag = false;
		string empty = string.Empty;
		string empty2 = string.Empty;
		bool flag2 = false;
		bool flag3 = false;
		int num4 = -1;
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		if ((num = m_PlantListView.SelectedItems.Count) >= 1)
		{
			for (num2 = 0; num2 < num; num2++)
			{
				for (num3 = 0; num3 < m_PlantListFamilyTypeList.Count; num3++)
				{
					if (m_PlantListFamilyTypeList[num3].Status == FamilyParameterWrapperStatus.Excluded || string.Compare((string)m_PlantListView.SelectedItems[num2].Tag, m_PlantListFamilyTypeList[num3].FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) != 0)
					{
						continue;
					}
					for (int i = 0; i < m_PlantListFamilyTypeList[num3].FamilyParameterList.Count; i++)
					{
						empty = m_PlantListFamilyTypeList[num3].FamilyParameterList[i].ParameterName;
						empty2 = m_PlantListFamilyTypeList[num3].FamilyParameterList[i].Value;
						if (string.Compare(empty, RevitParameters.ScientificNamePlantMixFamilyParameter, ignoreCase: true) == 0)
						{
							if (empty2 != null && empty2 != string.Empty)
							{
								flag2 = true;
								text = empty2;
							}
						}
						else if (string.Compare(empty, RevitParameters.CommonNamePlantMixFamilyParameter, ignoreCase: true) == 0)
						{
							if (empty2 != null && empty2 != string.Empty)
							{
								flag3 = true;
								text2 = empty2;
							}
						}
						else if (string.Compare(empty, EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), ignoreCase: true) == 0)
						{
							num4 = i;
							if (empty2 != null && empty2 != string.Empty)
							{
								flag = true;
								text3 = empty2;
								break;
							}
						}
					}
					if (!flag && (!flag2 || !flag3))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeCommonOrScientificName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						continue;
					}
					if (!flag && flag2 && flag3)
					{
						if (num4 != -1 && text != string.Empty && text2 != string.Empty)
						{
							m_PlantListFamilyTypeList[num3].FamilyParameterList[num4].Value = text + "/" + text2;
						}
					}
					else if (flag && text3 == null && flag2 && flag3 && num4 != -1 && text != string.Empty && text2 != string.Empty)
					{
						m_PlantListFamilyTypeList[num3].FamilyParameterList[num4].Value = text + "/" + text2;
					}
					_SelectedPlantList.Add(m_PlantListFamilyTypeList[num3]);
					break;
				}
			}
			return true;
		}
		RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		return false;
	}

	private void FindRecentFileList()
	{
		m_RecenFilesList = Settings.eplSetE_GetSectionValuesAsList("Recent File List", ApplicationUtility.RevitIniFilename);
	}

	private void ResetRecentFileList()
	{
		if (m_RecenFilesList == null || m_RecenFilesList.Count <= 0 || !Settings.eplSetE_DeleteSection("Recent File List", ApplicationUtility.RevitIniFilename))
		{
			return;
		}
		foreach (KeyValuePair<string, string> recenFiles in m_RecenFilesList)
		{
			Settings.eplSetE_SetSetting("Recent File List", recenFiles.Key, recenFiles.Value, ApplicationUtility.RevitIniFilename);
		}
	}

	private void CloseOpenDocuments()
	{
		if (m_OpenDocumentList != null && m_OpenDocumentList.Count > 0)
		{
			for (int num = m_OpenDocumentList.Count - 1; num >= 0; num--)
			{
				m_OpenDocumentList[num].Close(saveModified: false);
				m_OpenDocumentList.RemoveAt(num);
			}
		}
		ResetRecentFileList();
	}

	private void PopulatePlantListView(FamilyTypeContainer _CurFamilyTypeContainer)
	{
		bool flag = false;
		string empty = string.Empty;
		ListViewItem listViewItem = new ListViewItem();
		listViewItem.Tag = _CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName;
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			empty = ManagePlants.GetPlantParamenterName(m_ParameterList[i].PlantField);
			for (int j = 0; j < _CurFamilyTypeContainer.FamilyParameterList.Count; j++)
			{
				if (string.Compare(empty, _CurFamilyTypeContainer.FamilyParameterList[j].ParameterName, ignoreCase: true) != 0)
				{
					continue;
				}
				flag = true;
				string _strToDisplay = _CurFamilyTypeContainer.FamilyParameterList[j].Value;
				if (m_ParameterList[i].PlantField == PlantField.Height || m_ParameterList[i].PlantField == PlantField.PlantHeight || m_ParameterList[i].PlantField == PlantField.PlantWidth || m_ParameterList[i].PlantField == PlantField.CharacteristicsFoliageSize || m_ParameterList[i].PlantField == PlantField.PlantSpacing)
				{
					double dConvertedDouble = 0.0;
					if (_strToDisplay != null && _strToDisplay != string.Empty)
					{
						dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
					}
					RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				}
				if (i == 0)
				{
					listViewItem.Text = _strToDisplay;
				}
				else
				{
					listViewItem.SubItems.Add(_strToDisplay);
				}
				break;
			}
			if (!flag)
			{
				if (i == 0)
				{
					listViewItem.Text = string.Empty;
				}
				else
				{
					listViewItem.SubItems.Add(string.Empty);
				}
			}
			else
			{
				flag = false;
			}
		}
		m_PlantListView.Items.Add(listViewItem);
	}

	private void VerifyFileAndPopulateFamilyTypeSetList(FileInfo _CurrentFile)
	{
		Document CurDocument = null;
		List<FamilyTypeContainer> list = null;
		string text = _CurrentFile.Name.Substring(0, _CurrentFile.Name.Length - _CurrentFile.Extension.Length);
		int num = text.LastIndexOf('.');
		if (num >= 0 && text.Length - 1 == num + 4)
		{
			int result = -1;
			if (int.TryParse(text.Substring(num + 1), out result))
			{
				return;
			}
		}
		bool flag = ManagePlants.IsDocumentOpen(m_CurDocument.Application, _CurrentFile.FullName, ref CurDocument);
		if (!flag)
		{
			CurDocument = m_CurDocument.Application.OpenDocumentFile(_CurrentFile.FullName);
		}
		EPTransactionContainer ePTransactionContainer = new EPTransactionContainer(CurDocument);
		ePTransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
		ePTransactionContainer.BeginTransaction();
		list = PopulateFamilyTypeSetList(CurDocument.FamilyManager, ManagePlants.PopulateExternalDefinitionList(ManagePlants.GetAllCurPlantingSharedParameters(m_CurDocument.Application)));
		ePTransactionContainer.EndTransaction();
		ePTransactionContainer.Rollback();
		if (list != null)
		{
			if (m_OpenDocumentList == null)
			{
				m_OpenDocumentList = new List<Document>();
			}
			if (!flag)
			{
				m_OpenDocumentList.Add(CurDocument);
			}
			{
				foreach (FamilyTypeContainer item in list)
				{
					m_PlantListFamilyTypeList.Add(item);
				}
				return;
			}
		}
		if (!flag)
		{
			CurDocument.Close(saveModified: false);
		}
	}

	private void OnPlantListViewColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column != m_nPlantListViewSortColumn)
		{
			m_nPlantListViewSortColumn = e.Column;
			m_PlantListView.Sorting = SortOrder.Ascending;
		}
		else if (m_PlantListView.Sorting == SortOrder.Ascending)
		{
			m_PlantListView.Sorting = SortOrder.Descending;
		}
		else
		{
			m_PlantListView.Sorting = SortOrder.Ascending;
		}
		m_PlantListView.Sort();
		m_PlantListView.ListViewItemSorter = new ListViewItemComparer(e.Column, m_PlantListView.Sorting);
	}

	private void OnDeleteFamiliesButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		if ((num = m_PlantListView.SelectedItems.Count) >= 1)
		{
			for (num2 = num - 1; num2 >= 0; num2--)
			{
				for (num3 = 0; num3 < m_PlantListFamilyTypeList.Count; num3++)
				{
					if (m_PlantListFamilyTypeList[num3].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string)m_PlantListView.SelectedItems[num2].Tag, m_PlantListFamilyTypeList[num3].FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
					{
						m_PlantListFamilyTypeList[num3].Status = FamilyParameterWrapperStatus.Excluded;
						m_PlantListView.SelectedItems[num2].Remove();
						break;
					}
				}
			}
		}
		else
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		}
	}

	private void OnSearchButtonClicked(object sender, EventArgs e)
	{
		SetSelectedPlantList();
		if (ManagePlants.FindFamilyTypes(EPShared.LocalRM.GetString("PlantSearchDialog"), m_CurDocument, ref m_PlantListFamilyTypeList))
		{
			int num = -1;
			int nPlantListViewSortColumn = m_nPlantListViewSortColumn;
			SortOrder sorting = m_PlantListView.Sorting;
			for (num = 0; num < m_PlantListView.Items.Count; num++)
			{
				if (!m_PlantListView.SelectedIndices.Contains(num))
				{
					m_PlantListView.Items.RemoveAt(num);
					num--;
				}
			}
			m_nPlantListViewSortColumn = -1;
			m_PlantListView.Sorting = SortOrder.None;
			string empty = string.Empty;
			foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
			{
				if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
				{
					PopulatePlantListView(plantListFamilyType);
				}
			}
			if (sorting != SortOrder.None)
			{
				m_nPlantListViewSortColumn = nPlantListViewSortColumn;
				m_PlantListView.Sorting = sorting;
				m_PlantListView.Sort();
				m_PlantListView.ListViewItemSorter = new ListViewItemComparer(m_nPlantListViewSortColumn, m_PlantListView.Sorting);
			}
		}
		EnableDisableDialogFields(_bApplyToListButtons: false);
	}

	private void OnColumnDisplayButtonClicked(object sender, EventArgs e)
	{
		using PlantFieldsForm plantFieldsForm = new PlantFieldsForm(_bIsDisplayFields: true, "PlantMixSearch");
		if (plantFieldsForm.ShowDialog() == DialogResult.Cancel)
		{
			return;
		}
		LoadColumnSettings();
		m_PlantListView.Items.Clear();
		foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
		{
			if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
			{
				plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
				PopulatePlantListView(plantListFamilyType);
			}
		}
	}

	private void OnSaveFamilyButton(object sender, EventArgs e)
	{
		if (FindSelectedPlantList(ref m_SelectedPlantListFamilyTypeList))
		{
			SaveSettings();
			DialogResult = DialogResult.OK;
		}
	}

	private void OnCancelButtonClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	private void OnSingleFileDirectoryChecked(object sender, EventArgs e)
	{
		if (m_SingleFileRadioButton.Checked)
		{
			m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		}
		else
		{
			m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_DirectoryDialog");
		}
		m_RFASingleFileRadioButton.Enabled = m_SingleFileRadioButton.Checked;
		m_CommaSingleFileRadioButton.Enabled = m_SingleFileRadioButton.Checked;
		m_TabSingleFileRadioButton.Enabled = m_SingleFileRadioButton.Checked;
		SetValues();
	}

	private void SetValues()
	{
		if (m_DirectoryRadioButton.Checked)
		{
			m_SingleFileTextBox.Text = m_strCurrentDir;
		}
		else if (m_SingleFileRadioButton.Checked)
		{
			if (m_RFASingleFileRadioButton.Checked)
			{
				m_SingleFileTextBox.Text = m_strRFAFileName;
			}
			else if (m_CommaSingleFileRadioButton.Checked)
			{
				m_SingleFileTextBox.Text = m_strCSVFileName;
			}
			else if (m_TabSingleFileRadioButton.Checked)
			{
				m_SingleFileTextBox.Text = m_strTABFileName;
			}
		}
	}

	private void SingleFileDirectoryButtonClick(object sender, EventArgs e)
	{
		if (m_SingleFileRadioButton.Checked)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			if (m_RFASingleFileRadioButton.Checked)
			{
				openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
			}
			else if (m_CommaSingleFileRadioButton.Checked)
			{
				openFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
			}
			else
			{
				openFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
			}
			openFileDialog.FilterIndex = 1;
			openFileDialog.RestoreDirectory = true;
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				m_SingleFileTextBox.Text = openFileDialog.FileName;
				if (m_RFASingleFileRadioButton.Checked)
				{
					m_strRFAFileName = openFileDialog.FileName;
				}
				else if (m_CommaSingleFileRadioButton.Checked)
				{
					m_strCSVFileName = openFileDialog.FileName;
				}
				else if (m_TabSingleFileRadioButton.Checked)
				{
					m_strTABFileName = openFileDialog.FileName;
				}
				LoadData();
			}
		}
		else if (m_DirectoryRadioButton.Checked)
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			folderBrowserDialog.Description = EPShared.LocalRM.GetString("SelectRFADir");
			folderBrowserDialog.ShowNewFolderButton = false;
			if (m_SingleFileTextBox.Text != string.Empty)
			{
				folderBrowserDialog.SelectedPath = Path.GetDirectoryName(m_SingleFileTextBox.Text);
			}
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				m_SingleFileTextBox.Text = folderBrowserDialog.SelectedPath;
				m_strCurrentDir = folderBrowserDialog.SelectedPath;
				LoadData();
			}
		}
	}

	private void SetValuesFromText()
	{
		if (m_SingleFileRadioButton.Checked)
		{
			if (m_RFASingleFileRadioButton.Checked)
			{
				m_strRFAFileName = m_SingleFileTextBox.Text;
			}
			else if (m_CommaSingleFileRadioButton.Checked)
			{
				m_strCSVFileName = m_SingleFileTextBox.Text;
			}
			else if (m_TabSingleFileRadioButton.Checked)
			{
				m_strTABFileName = m_SingleFileTextBox.Text;
			}
		}
		else
		{
			m_strCurrentDir = m_SingleFileTextBox.Text;
		}
	}

	private void OnSingleFileDirectoryTextBoxLeaveFocus(object sender, EventArgs e)
	{
		SetValuesFromText();
		LoadData();
	}

	private void OnSingleFileDirectoryTextBoxEnter(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			SetValuesFromText();
			LoadData();
		}
	}

	private void LoadData()
	{
		if (m_DirectoryRadioButton.Checked)
		{
			if (RevitUtility.CompareDirectoryNames(m_strSourceDirectory, m_SingleFileTextBox.Text) == 0)
			{
				return;
			}
			CloseOpenDocuments();
			FindRecentFileList();
			m_strSourceDirectory = m_SingleFileTextBox.Text;
			m_PlantListView.Items.Clear();
			m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
			if (m_OpenDocumentList != null)
			{
				m_OpenDocumentList.Clear();
			}
			if (string.IsNullOrEmpty(m_strSourceDirectory))
			{
				return;
			}
			DirectoryInfo directoryInfo = new DirectoryInfo(m_strSourceDirectory);
			if (Directory.Exists(m_strSourceDirectory))
			{
				FileInfo[] files = directoryInfo.GetFiles("*.rfa");
				FileInfo[] array = files;
				foreach (FileInfo currentFile in array)
				{
					VerifyFileAndPopulateFamilyTypeSetList(currentFile);
				}
			}
		}
		else
		{
			if (!m_SingleFileRadioButton.Checked || RevitUtility.CompareFileNames(m_strSourceFile, m_SingleFileTextBox.Text) == 0)
			{
				return;
			}
			CloseOpenDocuments();
			FindRecentFileList();
			m_strSourceFile = m_SingleFileTextBox.Text;
			m_PlantListView.Items.Clear();
			m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
			if (m_OpenDocumentList != null)
			{
				m_OpenDocumentList.Clear();
			}
			if (!string.IsNullOrEmpty(m_strSourceFile))
			{
				FileInfo fileInfo = new FileInfo(m_strSourceFile);
				if (File.Exists(m_strSourceFile))
				{
					if (m_RFASingleFileRadioButton.Checked)
					{
						if (string.Compare(fileInfo.Extension, ".rfa", ignoreCase: true) != 0)
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return;
						}
						VerifyFileAndPopulateFamilyTypeSetList(fileInfo);
					}
					else
					{
						if (string.Compare(fileInfo.Extension, ".txt", ignoreCase: true) != 0 && string.Compare(fileInfo.Extension, ".csv", ignoreCase: true) != 0)
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("NoCSVTXT"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return;
						}
						string strSeparator = string.Empty;
						if (m_CommaSingleFileRadioButton.Checked)
						{
							strSeparator = ",";
						}
						else if (m_TabSingleFileRadioButton.Checked)
						{
							strSeparator = "\t";
						}
						List<FamilyTypeContainer> list = new List<FamilyTypeContainer>();
						ImportExport.ImportFileWithSeparator(m_CurDocument, m_strSourceFile, strSeparator, ref m_PlantListFamilyTypeList);
						foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
						{
							PopulatePlantListView(plantListFamilyType);
						}
					}
				}
			}
			if (m_PlantListView.Items.Count > 0)
			{
				EnableDisableDialogFields(_bApplyToListButtons: true);
			}
		}
	}

	private void OnPlantMixSearchFormClosing(object sender, FormClosingEventArgs e)
	{
		CloseOpenDocuments();
		SetDialogPosition();
	}

	private void OnShowAllFamiliesButtonClicked(object sender, EventArgs e)
	{
		int num = -1;
		SetSelectedPlantList();
		for (num = 0; num < m_PlantListView.Items.Count; num++)
		{
			if (!m_PlantListView.SelectedIndices.Contains(num))
			{
				m_PlantListView.Items.RemoveAt(num);
				num--;
			}
		}
		string empty = string.Empty;
		foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
		{
			if (plantListFamilyType.Status != FamilyParameterWrapperStatus.Selected)
			{
				plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
				PopulatePlantListView(plantListFamilyType);
			}
		}
		EnableDisableDialogFields(_bApplyToListButtons: false);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_SaveFamilyButton = new System.Windows.Forms.Button();
		this.m_SourceGroupBox = new System.Windows.Forms.GroupBox();
		this.m_SingleFileGroupBox = new System.Windows.Forms.GroupBox();
		this.m_TabSingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CommaSingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_RFASingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_DirectoryRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SingleFileTextBox = new System.Windows.Forms.TextBox();
		this.m_SingleFileLabel = new System.Windows.Forms.Label();
		this.m_SingleFileButton = new System.Windows.Forms.Button();
		this.m_CollectionGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ShowAllFamiliesButton = new System.Windows.Forms.Button();
		this.m_ColumnDisplayButton = new System.Windows.Forms.Button();
		this.m_SearchButton = new System.Windows.Forms.Button();
		this.m_PlantListView = new System.Windows.Forms.ListView();
		this.m_SourceGroupBox.SuspendLayout();
		this.m_SingleFileGroupBox.SuspendLayout();
		this.m_CollectionGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_CancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(526, 385);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(77, 23);
		this.m_CancelButton.TabIndex = 3;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClicked);
		this.m_SaveFamilyButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_SaveFamilyButton.Location = new System.Drawing.Point(435, 385);
		this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
		this.m_SaveFamilyButton.Size = new System.Drawing.Size(85, 23);
		this.m_SaveFamilyButton.TabIndex = 2;
		this.m_SaveFamilyButton.Text = "&Add to Family";
		this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
		this.m_SaveFamilyButton.Click += new System.EventHandler(this.OnSaveFamilyButton);
		this.m_SourceGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileGroupBox);
		this.m_SourceGroupBox.Controls.Add(this.m_DirectoryRadioButton);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileRadioButton);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileTextBox);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileLabel);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileButton);
		this.m_SourceGroupBox.Location = new System.Drawing.Point(12, 5);
		this.m_SourceGroupBox.Name = "m_SourceGroupBox";
		this.m_SourceGroupBox.Size = new System.Drawing.Size(591, 128);
		this.m_SourceGroupBox.TabIndex = 0;
		this.m_SourceGroupBox.TabStop = false;
		this.m_SourceGroupBox.Text = "Source";
		this.m_SingleFileGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SingleFileGroupBox.Controls.Add(this.m_TabSingleFileRadioButton);
		this.m_SingleFileGroupBox.Controls.Add(this.m_CommaSingleFileRadioButton);
		this.m_SingleFileGroupBox.Controls.Add(this.m_RFASingleFileRadioButton);
		this.m_SingleFileGroupBox.Location = new System.Drawing.Point(6, 37);
		this.m_SingleFileGroupBox.Name = "m_SingleFileGroupBox";
		this.m_SingleFileGroupBox.Size = new System.Drawing.Size(574, 56);
		this.m_SingleFileGroupBox.TabIndex = 2;
		this.m_SingleFileGroupBox.TabStop = false;
		this.m_SingleFileGroupBox.Text = "Single File";
		this.m_TabSingleFileRadioButton.AutoSize = true;
		this.m_TabSingleFileRadioButton.Location = new System.Drawing.Point(362, 23);
		this.m_TabSingleFileRadioButton.Name = "m_TabSingleFileRadioButton";
		this.m_TabSingleFileRadioButton.Size = new System.Drawing.Size(139, 17);
		this.m_TabSingleFileRadioButton.TabIndex = 2;
		this.m_TabSingleFileRadioButton.TabStop = true;
		this.m_TabSingleFileRadioButton.Text = "&Tab Delimited (Text File)";
		this.m_TabSingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_CommaSingleFileRadioButton.AutoSize = true;
		this.m_CommaSingleFileRadioButton.Location = new System.Drawing.Point(158, 23);
		this.m_CommaSingleFileRadioButton.Name = "m_CommaSingleFileRadioButton";
		this.m_CommaSingleFileRadioButton.Size = new System.Drawing.Size(155, 17);
		this.m_CommaSingleFileRadioButton.TabIndex = 1;
		this.m_CommaSingleFileRadioButton.TabStop = true;
		this.m_CommaSingleFileRadioButton.Text = "&Comma Delimited (CSV File)";
		this.m_CommaSingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_RFASingleFileRadioButton.AutoSize = true;
		this.m_RFASingleFileRadioButton.Location = new System.Drawing.Point(6, 25);
		this.m_RFASingleFileRadioButton.Name = "m_RFASingleFileRadioButton";
		this.m_RFASingleFileRadioButton.Size = new System.Drawing.Size(103, 17);
		this.m_RFASingleFileRadioButton.TabIndex = 0;
		this.m_RFASingleFileRadioButton.TabStop = true;
		this.m_RFASingleFileRadioButton.Text = "&RFA (Family File)";
		this.m_RFASingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_DirectoryRadioButton.AutoSize = true;
		this.m_DirectoryRadioButton.Location = new System.Drawing.Point(164, 15);
		this.m_DirectoryRadioButton.Name = "m_DirectoryRadioButton";
		this.m_DirectoryRadioButton.Size = new System.Drawing.Size(168, 17);
		this.m_DirectoryRadioButton.TabIndex = 1;
		this.m_DirectoryRadioButton.TabStop = true;
		this.m_DirectoryRadioButton.Text = "&Directory (Multiple Family Files)";
		this.m_DirectoryRadioButton.UseVisualStyleBackColor = true;
		this.m_DirectoryRadioButton.CheckedChanged += new System.EventHandler(this.OnSingleFileDirectoryChecked);
		this.m_SingleFileRadioButton.AutoSize = true;
		this.m_SingleFileRadioButton.Location = new System.Drawing.Point(12, 15);
		this.m_SingleFileRadioButton.Name = "m_SingleFileRadioButton";
		this.m_SingleFileRadioButton.Size = new System.Drawing.Size(73, 17);
		this.m_SingleFileRadioButton.TabIndex = 0;
		this.m_SingleFileRadioButton.TabStop = true;
		this.m_SingleFileRadioButton.Text = "&Single File";
		this.m_SingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_SingleFileRadioButton.CheckedChanged += new System.EventHandler(this.OnSingleFileDirectoryChecked);
		this.m_SingleFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SingleFileTextBox.Location = new System.Drawing.Point(79, 99);
		this.m_SingleFileTextBox.Name = "m_SingleFileTextBox";
		this.m_SingleFileTextBox.Size = new System.Drawing.Size(472, 20);
		this.m_SingleFileTextBox.TabIndex = 4;
		this.m_SingleFileTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnSingleFileDirectoryTextBoxEnter);
		this.m_SingleFileTextBox.Leave += new System.EventHandler(this.OnSingleFileDirectoryTextBoxLeaveFocus);
		this.m_SingleFileLabel.AutoSize = true;
		this.m_SingleFileLabel.Location = new System.Drawing.Point(9, 103);
		this.m_SingleFileLabel.Name = "m_SingleFileLabel";
		this.m_SingleFileLabel.Size = new System.Drawing.Size(26, 13);
		this.m_SingleFileLabel.TabIndex = 3;
		this.m_SingleFileLabel.Text = "&File:";
		this.m_SingleFileButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_SingleFileButton.Location = new System.Drawing.Point(557, 99);
		this.m_SingleFileButton.Name = "m_SingleFileButton";
		this.m_SingleFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_SingleFileButton.TabIndex = 5;
		this.m_SingleFileButton.TabStop = false;
		this.m_SingleFileButton.Text = "...";
		this.m_SingleFileButton.UseVisualStyleBackColor = true;
		this.m_SingleFileButton.Click += new System.EventHandler(this.SingleFileDirectoryButtonClick);
		this.m_CollectionGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_CollectionGroupBox.Controls.Add(this.m_ShowAllFamiliesButton);
		this.m_CollectionGroupBox.Controls.Add(this.m_ColumnDisplayButton);
		this.m_CollectionGroupBox.Controls.Add(this.m_SearchButton);
		this.m_CollectionGroupBox.Controls.Add(this.m_PlantListView);
		this.m_CollectionGroupBox.Location = new System.Drawing.Point(13, 140);
		this.m_CollectionGroupBox.Name = "m_CollectionGroupBox";
		this.m_CollectionGroupBox.Size = new System.Drawing.Size(590, 239);
		this.m_CollectionGroupBox.TabIndex = 1;
		this.m_CollectionGroupBox.TabStop = false;
		this.m_CollectionGroupBox.Text = "Plant Collection";
		this.m_ShowAllFamiliesButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ShowAllFamiliesButton.Location = new System.Drawing.Point(480, 71);
		this.m_ShowAllFamiliesButton.Name = "m_ShowAllFamiliesButton";
		this.m_ShowAllFamiliesButton.Size = new System.Drawing.Size(100, 23);
		this.m_ShowAllFamiliesButton.TabIndex = 3;
		this.m_ShowAllFamiliesButton.Text = "Show &All";
		this.m_ShowAllFamiliesButton.UseVisualStyleBackColor = true;
		this.m_ShowAllFamiliesButton.Click += new System.EventHandler(this.OnShowAllFamiliesButtonClicked);
		this.m_ColumnDisplayButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ColumnDisplayButton.Location = new System.Drawing.Point(479, 42);
		this.m_ColumnDisplayButton.Name = "m_ColumnDisplayButton";
		this.m_ColumnDisplayButton.Size = new System.Drawing.Size(100, 23);
		this.m_ColumnDisplayButton.TabIndex = 2;
		this.m_ColumnDisplayButton.Text = "Colu&mn Display";
		this.m_ColumnDisplayButton.UseVisualStyleBackColor = true;
		this.m_ColumnDisplayButton.Click += new System.EventHandler(this.OnColumnDisplayButtonClicked);
		this.m_SearchButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_SearchButton.Location = new System.Drawing.Point(479, 13);
		this.m_SearchButton.Name = "m_SearchButton";
		this.m_SearchButton.Size = new System.Drawing.Size(101, 23);
		this.m_SearchButton.TabIndex = 1;
		this.m_SearchButton.Text = "Searc&h";
		this.m_SearchButton.UseVisualStyleBackColor = true;
		this.m_SearchButton.Click += new System.EventHandler(this.OnSearchButtonClicked);
		this.m_PlantListView.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_PlantListView.FullRowSelect = true;
		this.m_PlantListView.HideSelection = false;
		this.m_PlantListView.Location = new System.Drawing.Point(6, 13);
		this.m_PlantListView.Name = "m_PlantListView";
		this.m_PlantListView.Size = new System.Drawing.Size(465, 220);
		this.m_PlantListView.TabIndex = 0;
		this.m_PlantListView.UseCompatibleStateImageBehavior = false;
		this.m_PlantListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.OnPlantListViewColumnClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(613, 420);
		base.Controls.Add(this.m_CollectionGroupBox);
		base.Controls.Add(this.m_SourceGroupBox);
		base.Controls.Add(this.m_SaveFamilyButton);
		base.Controls.Add(this.m_CancelButton);
		this.MinimumSize = new System.Drawing.Size(621, 447);
		base.Name = "PlantMixSearchForm";
		this.Text = "Plant Search Manager";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantMixSearchFormClosing);
		this.m_SourceGroupBox.ResumeLayout(false);
		this.m_SourceGroupBox.PerformLayout();
		this.m_SingleFileGroupBox.ResumeLayout(false);
		this.m_SingleFileGroupBox.PerformLayout();
		this.m_CollectionGroupBox.ResumeLayout(false);
		base.ResumeLayout(false);
		base.AcceptButton = this.m_SaveFamilyButton;
		base.CancelButton = this.m_CancelButton;
	}
}
