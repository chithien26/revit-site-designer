using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class LocateFenceForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private FenceCreation m_dataBuffer;

	private Autodesk.Revit.DB.View m_CurView;

	private FamilySymbol m_CurType;

	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Label m_FenceFamilyLabel;

	private ComboBox m_FenceFamilyComboBox;

	private ComboBox m_LevelComboBox;

	private Label m_LevelLabel;

	private Label m_FenceNameLabel;

	private ComboBox m_FenceNameComboBox;

	private Label m_SetbackLabel;

	private TextBox m_SetbackTextBox;

	private Label m_FenceHeightLabel;

	private TextBox m_FenceHeightTextBox;

	private Label m_FenceSpanLabel;

	private TextBox m_FenceSpanTextBox;

	private Button m_LoadFamilyButton;

	private CheckBox m_ExistingElementCheckBox;

	private System.Windows.Forms.Panel m_MoveablePanel;

	private CheckBox m_DeleteExistingCheckBox;

	private Button m_CancelButton;

	private Button m_InsertButton;

	private RadioButton m_ChainRadioButton;

	private RadioButton m_SegmentRadioButton;

	private Label m_StartingDistanceLabel;

	private TextBox m_StartingDistanceTextBox;

	private System.Windows.Forms.Panel m_ToposurfacePane;

	private ComboBox m_SurfaceList;

	private Label m_SelectedSurfaceLabel;

	private CheckBox m_ToposurfaceCheckBox;

	public bool ExistingElementChecked => m_ExistingElementCheckBox.Checked;

	public bool DeleteExistingChecked
	{
		get
		{
			if (!m_ExistingElementCheckBox.Checked)
			{
				return false;
			}
			return m_DeleteExistingCheckBox.Checked;
		}
	}

	public double StartingDistance
	{
		get
		{
			if (!m_ExistingElementCheckBox.Checked)
			{
				return 0.0;
			}
			double _dReturnedDouble = 0.0;
			if (m_StartingDistanceTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public Level Level => m_CurView.GenLevel;

	public Autodesk.Revit.DB.View View => m_CurView;

	public FamilySymbol Type => m_CurType;

	public TopographySurfaceContainer Surface
	{
		get
		{
			TopographySurfaceContainer result = null;
			if (m_SurfaceList.SelectedItem is ToposurfaceItem toposurfaceItem)
			{
				result = toposurfaceItem.Value;
			}
			return result;
		}
	}

	public double SetbackSpacing
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_SetbackTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double FenceSpan
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_FenceSpanTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_FenceSpanTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double FenceHeight
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_FenceHeightTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_FenceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool SegmentChecked => m_SegmentRadioButton.Checked;

	public bool ChainChecked => m_ChainRadioButton.Checked;

	public bool PickToposurface => m_ToposurfaceCheckBox.Checked;

	public LocateFenceForm(FenceCreation dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("LocateFenceDialog");
		m_FenceFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FenceFamilyDialog");
		m_FenceNameLabel.Text = EPShared.LocalRM.GetString("F_AMP_enceNameDialog");
		m_FenceHeightLabel.Text = EPShared.LocalRM.GetString("Fence_AMP_HeightDialog");
		m_FenceSpanLabel.Text = EPShared.LocalRM.GetString("FenceS_AMP_panDialog");
		m_SetbackLabel.Text = EPShared.LocalRM.GetString("Set_AMP_backDialog");
		m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
		m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
		m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
		m_ExistingElementCheckBox.Text = EPShared.LocalRM.GetString("ExistingEle_AMP_mentDialog");
		m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
		m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
		m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
		m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
		EPToolTip.SetToolTip(m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		m_ToposurfaceCheckBox.Checked = false;
		m_SurfaceList.Enabled = false;
		m_dataBuffer = dataBuffer;
		m_FormatOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_dataBuffer.Document.DisplayUnitSystem;
		m_Units = m_dataBuffer.Document.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_dataBuffer.Document.GetUnits().DecimalSymbol;
		InitializeControls();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		double _dReturnValue = 0.0;
		string _strToDisplay = string.Empty;
		GetDialogPosition();
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceSetback", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
		m_SetbackTextBox.Text = _strToDisplay;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceHeight", ref _dReturnValue))
		{
			_dReturnValue = 4.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
		m_FenceHeightTextBox.Text = _strToDisplay;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceSpan", ref _dReturnValue))
		{
			_dReturnValue = 6.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
		m_FenceSpanTextBox.Text = _strToDisplay;
		m_ExistingElementCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceExistingElement", ref _nReturnValue))
		{
			m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_DeleteExistingCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceDeleteExisting", ref _nReturnValue))
		{
			m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_ToposurfaceCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFencePickToposurface", ref _nReturnValue))
		{
			m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceStartingDistance", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
		m_StartingDistanceTextBox.Text = _strToDisplay;
		m_FenceFamilyComboBox.DataSource = m_dataBuffer.FamilyList;
		m_FenceFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateFenceFamilyName", ref _strToDisplay))
		{
			FamilyContainer familyContainer = null;
			for (int i = 0; i < m_FenceFamilyComboBox.Items.Count; i++)
			{
				if (m_FenceFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strToDisplay, ignoreCase: true) == 0)
				{
					m_FenceFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateFencePlantName", ref _strToDisplay))
		{
			FamilySymbol familySymbol = null;
			for (int j = 0; j < m_FenceNameComboBox.Items.Count; j++)
			{
				if (m_FenceNameComboBox.Items[j] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strToDisplay, ignoreCase: true) == 0)
				{
					m_FenceNameComboBox.SelectedIndex = j;
					break;
				}
			}
		}
		m_LevelComboBox.DataSource = m_dataBuffer.Views;
		m_LevelComboBox.DisplayMember = EPShared.LocalRM.GetString("ViewNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateFenceViewName", ref _strToDisplay))
		{
			Autodesk.Revit.DB.View view = null;
			for (int k = 0; k < m_LevelComboBox.Items.Count; k++)
			{
				if (m_LevelComboBox.Items[k] is Autodesk.Revit.DB.View view2 && string.Compare(view2.Name, _strToDisplay, ignoreCase: true) == 0)
				{
					m_LevelComboBox.SelectedIndex = k;
					break;
				}
			}
		}
		Parameter parameter = null;
		string text = string.Empty;
		if (m_dataBuffer.SurfaceList.Count > 0)
		{
			int num = 1;
			foreach (TopographySurfaceContainer surface in m_dataBuffer.SurfaceList)
			{
				parameter = ((Element)surface.TopographySurface).get_Parameter(BuiltInParameter.ROOM_NAME);
				if (parameter != null)
				{
					text = parameter.AsString();
				}
				if (text == null || text == string.Empty)
				{
					text = "<" + EPShared.LocalRM.GetString("UnnamedSurfaceDialog") + " " + Convert.ToString(num) + ">";
					num++;
				}
				m_SurfaceList.Items.Add(new ToposurfaceItem(text, surface));
			}
		}
		else
		{
			m_ToposurfaceCheckBox.Checked = false;
			m_ToposurfaceCheckBox.Enabled = false;
			m_SurfaceList.Enabled = false;
		}
		parameter = null;
		text = string.Empty;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateFenceSurfaceName", ref _strToDisplay))
		{
			for (int l = 0; l < m_SurfaceList.Items.Count; l++)
			{
				if (m_SurfaceList.Items[l] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, _strToDisplay, ignoreCase: true) == 0)
				{
					m_SurfaceList.SelectedIndex = l;
					break;
				}
			}
		}
		if (m_SurfaceList.Items.Count > 0 && m_SurfaceList.SelectedIndex == -1)
		{
			m_SurfaceList.SelectedIndex = 0;
		}
		m_SegmentRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceSegmentChainOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_SegmentRadioButton.Checked = true;
			}
			else
			{
				m_ChainRadioButton.Checked = true;
			}
		}
	}

	private void SaveSettings()
	{
		m_CurView = m_LevelComboBox.SelectedItem as Autodesk.Revit.DB.View;
		if (m_CurView == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		m_CurType = m_FenceNameComboBox.SelectedItem as FamilySymbol;
		if (m_CurType == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceSetback", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_FenceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceHeight", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_FenceSpanTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceSpan", _dReturnedDouble);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceExistingElement", Convert.ToInt32(m_ExistingElementCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceDeleteExisting", Convert.ToInt32(m_DeleteExistingCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateFencePickToposurface", Convert.ToInt32(m_ToposurfaceCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceStartingDistance", _dReturnedDouble);
		}
		if (m_FenceFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateFenceFamilyName", familyContainer.FamilyName);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateFencePlantName", m_CurType.Name);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateFenceViewName", Convert.ToString(m_LevelComboBox.SelectedItem));
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateFenceSurfaceName", Convert.ToString(m_SurfaceList.SelectedItem));
		int num = 0;
		num = ((!m_SegmentRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceSegmentChainOption", num);
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		if (ValidateFields())
		{
			SaveSettings();
			DialogResult = DialogResult.OK;
			Close();
		}
	}

	private bool ValidateFields()
	{
		double _dReturnedDouble = 0.0;
		if (!RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
			return false;
		}
		if (_dReturnedDouble < 0.0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
			return false;
		}
		if (!RevitGeometry.Units_ConvertStringToDouble(m_FenceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFenceHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FenceHeightTextBox);
			return false;
		}
		if (_dReturnedDouble <= 0.0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidFenceHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FenceHeightTextBox);
			return false;
		}
		if (!RevitGeometry.Units_ConvertStringToDouble(m_FenceSpanTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFenceSpanMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FenceSpanTextBox);
			return false;
		}
		if (_dReturnedDouble <= 0.0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSpenceSpanMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FenceSpanTextBox);
			return false;
		}
		return true;
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void FormatSetbackValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_SetbackTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
		}
	}

	private void OnSetbackTextBoxLeave(object sender, EventArgs e)
	{
		FormatSetbackValue();
	}

	private void OnSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatSetbackValue();
		}
	}

	private void OnComponentNameComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
	}

	private void OnComponentFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_FenceFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_FenceNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_FenceNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void FormatFenceSpanValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_FenceSpanTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_FenceSpanTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_FenceSpanTextBox);
		}
	}

	private void FormatFenceHeightValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_FenceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_FenceHeightTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_FenceHeightTextBox);
		}
	}

	private void OnFenceHeightKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyData == Keys.Return)
		{
			FormatFenceHeightValue();
		}
	}

	private void OnFenceSpanTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyData == Keys.Return)
		{
			FormatFenceSpanValue();
		}
	}

	private void OnFenceHeightTextBoxLeave(object sender, EventArgs e)
	{
		FormatFenceHeightValue();
	}

	private void OnFenceSpanTextBoxLeave(object sender, EventArgs e)
	{
		FormatFenceSpanValue();
	}

	private void OnLocateFenceFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnLoadFamilyButtonClick(object sender, EventArgs e)
	{
		int count = m_FenceFamilyComboBox.Items.Count;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		FamilyContainer familyContainer = null;
		Family _Family = null;
		openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectFenceFamilyFileMessage");
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				try
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadFenceFamilyTransaction") + openFileDialog.SafeFileName);
					EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
					flag = RevitUtility.LoadFamily(m_dataBuffer.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
					m_dataBuffer.TransactionContainer = _TransactionContainer;
					m_dataBuffer.TransactionContainer.Commit();
				}
				catch (SEHException)
				{
					m_dataBuffer.TransactionContainer.Rollback();
					flag = false;
					RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceFamilyCantBeLoadedMessage") + Convert.ToInt32(LandcaddID.Fence).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					continue;
				}
				break;
			}
		}
		if (!flag)
		{
			if (count == 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceFamilyNotLoadedWithIDMessage") + Convert.ToInt32(LandcaddID.Fence).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_dataBuffer.PopulateFamilyAndSymbolLists();
		m_FenceFamilyComboBox.DataSource = m_dataBuffer.FamilyList;
		m_FenceFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (_Family != null)
		{
			for (int i = 0; i < m_FenceFamilyComboBox.Items.Count; i++)
			{
				if (m_FenceFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _Family.Name, ignoreCase: true) == 0)
				{
					m_FenceFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (m_FenceFamilyComboBox.Items.Count == count)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotFenceMessage") + Convert.ToInt32(LandcaddID.Fence).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
	{
		m_DeleteExistingCheckBox.Enabled = m_ExistingElementCheckBox.Checked;
		m_StartingDistanceLabel.Enabled = m_ExistingElementCheckBox.Checked;
		m_StartingDistanceTextBox.Enabled = m_ExistingElementCheckBox.Checked;
	}

	private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyData == Keys.Return)
		{
			FormatStartingDistanceValue();
		}
	}

	private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
	{
		FormatStartingDistanceValue();
	}

	private void FormatStartingDistanceValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_StartingDistanceTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_StartingDistanceTextBox);
		}
	}

	private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
	{
		m_SurfaceList.Enabled = m_ToposurfaceCheckBox.Checked;
		m_SelectedSurfaceLabel.Enabled = m_ToposurfaceCheckBox.Checked;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_FenceFamilyLabel = new System.Windows.Forms.Label();
		this.m_FenceFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelLabel = new System.Windows.Forms.Label();
		this.m_FenceNameLabel = new System.Windows.Forms.Label();
		this.m_FenceNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_SetbackLabel = new System.Windows.Forms.Label();
		this.m_SetbackTextBox = new System.Windows.Forms.TextBox();
		this.m_FenceHeightLabel = new System.Windows.Forms.Label();
		this.m_FenceHeightTextBox = new System.Windows.Forms.TextBox();
		this.m_FenceSpanLabel = new System.Windows.Forms.Label();
		this.m_FenceSpanTextBox = new System.Windows.Forms.TextBox();
		this.m_LoadFamilyButton = new System.Windows.Forms.Button();
		this.m_ExistingElementCheckBox = new System.Windows.Forms.CheckBox();
		this.m_MoveablePanel = new System.Windows.Forms.Panel();
		this.m_StartingDistanceLabel = new System.Windows.Forms.Label();
		this.m_StartingDistanceTextBox = new System.Windows.Forms.TextBox();
		this.m_DeleteExistingCheckBox = new System.Windows.Forms.CheckBox();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_InsertButton = new System.Windows.Forms.Button();
		this.m_ChainRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SegmentRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ToposurfacePane = new System.Windows.Forms.Panel();
		this.m_SurfaceList = new System.Windows.Forms.ComboBox();
		this.m_SelectedSurfaceLabel = new System.Windows.Forms.Label();
		this.m_ToposurfaceCheckBox = new System.Windows.Forms.CheckBox();
		this.m_MoveablePanel.SuspendLayout();
		this.m_ToposurfacePane.SuspendLayout();
		base.SuspendLayout();
		this.m_FenceFamilyLabel.AutoSize = true;
		this.m_FenceFamilyLabel.Location = new System.Drawing.Point(9, 15);
		this.m_FenceFamilyLabel.Name = "m_FenceFamilyLabel";
		this.m_FenceFamilyLabel.Size = new System.Drawing.Size(72, 13);
		this.m_FenceFamilyLabel.TabIndex = 0;
		this.m_FenceFamilyLabel.Text = "&Fence Family:";
		this.m_FenceFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_FenceFamilyComboBox.FormattingEnabled = true;
		this.m_FenceFamilyComboBox.Location = new System.Drawing.Point(130, 12);
		this.m_FenceFamilyComboBox.Name = "m_FenceFamilyComboBox";
		this.m_FenceFamilyComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_FenceFamilyComboBox.TabIndex = 1;
		this.m_FenceFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnComponentFamilyComboBoxSelectedIndexChanged);
		this.m_LevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LevelComboBox.FormattingEnabled = true;
		this.m_LevelComboBox.Location = new System.Drawing.Point(130, 144);
		this.m_LevelComboBox.Name = "m_LevelComboBox";
		this.m_LevelComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_LevelComboBox.TabIndex = 12;
		this.m_LevelLabel.AutoSize = true;
		this.m_LevelLabel.Location = new System.Drawing.Point(9, 147);
		this.m_LevelLabel.Name = "m_LevelLabel";
		this.m_LevelLabel.Size = new System.Drawing.Size(36, 13);
		this.m_LevelLabel.TabIndex = 11;
		this.m_LevelLabel.Text = "&Level:";
		this.m_FenceNameLabel.AutoSize = true;
		this.m_FenceNameLabel.Location = new System.Drawing.Point(9, 42);
		this.m_FenceNameLabel.Name = "m_FenceNameLabel";
		this.m_FenceNameLabel.Size = new System.Drawing.Size(68, 13);
		this.m_FenceNameLabel.TabIndex = 3;
		this.m_FenceNameLabel.Text = "F&ence Name";
		this.m_FenceNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_FenceNameComboBox.FormattingEnabled = true;
		this.m_FenceNameComboBox.Location = new System.Drawing.Point(130, 39);
		this.m_FenceNameComboBox.Name = "m_FenceNameComboBox";
		this.m_FenceNameComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_FenceNameComboBox.TabIndex = 4;
		this.m_FenceNameComboBox.SelectedIndexChanged += new System.EventHandler(this.OnComponentNameComboBoxSelectedIndexChanged);
		this.m_SetbackLabel.AutoSize = true;
		this.m_SetbackLabel.Location = new System.Drawing.Point(9, 121);
		this.m_SetbackLabel.Name = "m_SetbackLabel";
		this.m_SetbackLabel.Size = new System.Drawing.Size(50, 13);
		this.m_SetbackLabel.TabIndex = 9;
		this.m_SetbackLabel.Text = "Set&back:";
		this.m_SetbackTextBox.Location = new System.Drawing.Point(130, 118);
		this.m_SetbackTextBox.Name = "m_SetbackTextBox";
		this.m_SetbackTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_SetbackTextBox.TabIndex = 10;
		this.m_SetbackTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnSetbackTextBoxKeyDown);
		this.m_SetbackTextBox.Leave += new System.EventHandler(this.OnSetbackTextBoxLeave);
		this.m_FenceHeightLabel.AutoSize = true;
		this.m_FenceHeightLabel.Location = new System.Drawing.Point(9, 69);
		this.m_FenceHeightLabel.Name = "m_FenceHeightLabel";
		this.m_FenceHeightLabel.Size = new System.Drawing.Size(74, 13);
		this.m_FenceHeightLabel.TabIndex = 5;
		this.m_FenceHeightLabel.Text = "Fence &Height:";
		this.m_FenceHeightTextBox.Location = new System.Drawing.Point(130, 66);
		this.m_FenceHeightTextBox.Name = "m_FenceHeightTextBox";
		this.m_FenceHeightTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_FenceHeightTextBox.TabIndex = 6;
		this.m_FenceHeightTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnFenceHeightKeyDown);
		this.m_FenceHeightTextBox.Leave += new System.EventHandler(this.OnFenceHeightTextBoxLeave);
		this.m_FenceSpanLabel.AutoSize = true;
		this.m_FenceSpanLabel.Location = new System.Drawing.Point(9, 95);
		this.m_FenceSpanLabel.Name = "m_FenceSpanLabel";
		this.m_FenceSpanLabel.Size = new System.Drawing.Size(68, 13);
		this.m_FenceSpanLabel.TabIndex = 7;
		this.m_FenceSpanLabel.Text = "Fence &Span:";
		this.m_FenceSpanTextBox.Location = new System.Drawing.Point(130, 92);
		this.m_FenceSpanTextBox.Name = "m_FenceSpanTextBox";
		this.m_FenceSpanTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_FenceSpanTextBox.TabIndex = 8;
		this.m_FenceSpanTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnFenceSpanTextBoxKeyDown);
		this.m_FenceSpanTextBox.Leave += new System.EventHandler(this.OnFenceSpanTextBoxLeave);
		this.m_LoadFamilyButton.Location = new System.Drawing.Point(351, 13);
		this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
		this.m_LoadFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadFamilyButton.TabIndex = 2;
		this.m_LoadFamilyButton.TabStop = false;
		this.m_LoadFamilyButton.Text = "...";
		this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Click += new System.EventHandler(this.OnLoadFamilyButtonClick);
		this.m_ExistingElementCheckBox.AutoSize = true;
		this.m_ExistingElementCheckBox.Location = new System.Drawing.Point(12, 244);
		this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
		this.m_ExistingElementCheckBox.Size = new System.Drawing.Size(103, 17);
		this.m_ExistingElementCheckBox.TabIndex = 16;
		this.m_ExistingElementCheckBox.Text = "Existing Ele&ment";
		this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
		this.m_ExistingElementCheckBox.CheckedChanged += new System.EventHandler(this.OnExistingElementCheckBoxChecked);
		this.m_MoveablePanel.Controls.Add(this.m_StartingDistanceLabel);
		this.m_MoveablePanel.Controls.Add(this.m_StartingDistanceTextBox);
		this.m_MoveablePanel.Controls.Add(this.m_DeleteExistingCheckBox);
		this.m_MoveablePanel.Controls.Add(this.m_CancelButton);
		this.m_MoveablePanel.Controls.Add(this.m_InsertButton);
		this.m_MoveablePanel.Location = new System.Drawing.Point(12, 268);
		this.m_MoveablePanel.Name = "m_MoveablePanel";
		this.m_MoveablePanel.Size = new System.Drawing.Size(363, 72);
		this.m_MoveablePanel.TabIndex = 17;
		this.m_StartingDistanceLabel.AutoSize = true;
		this.m_StartingDistanceLabel.Enabled = false;
		this.m_StartingDistanceLabel.Location = new System.Drawing.Point(20, 26);
		this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
		this.m_StartingDistanceLabel.Size = new System.Drawing.Size(91, 13);
		this.m_StartingDistanceLabel.TabIndex = 1;
		this.m_StartingDistanceLabel.Text = "Starting Distance:";
		this.m_StartingDistanceTextBox.Enabled = false;
		this.m_StartingDistanceTextBox.Location = new System.Drawing.Point(118, 23);
		this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
		this.m_StartingDistanceTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_StartingDistanceTextBox.TabIndex = 2;
		this.m_StartingDistanceTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
		this.m_StartingDistanceTextBox.Leave += new System.EventHandler(this.OnStartingDistanceTextBoxLeave);
		this.m_DeleteExistingCheckBox.AutoSize = true;
		this.m_DeleteExistingCheckBox.Enabled = false;
		this.m_DeleteExistingCheckBox.Location = new System.Drawing.Point(20, 0);
		this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
		this.m_DeleteExistingCheckBox.Size = new System.Drawing.Size(137, 17);
		this.m_DeleteExistingCheckBox.TabIndex = 0;
		this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
		this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(287, 49);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(76, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_InsertButton.Location = new System.Drawing.Point(206, 49);
		this.m_InsertButton.Name = "m_InsertButton";
		this.m_InsertButton.Size = new System.Drawing.Size(75, 23);
		this.m_InsertButton.TabIndex = 3;
		this.m_InsertButton.Text = "&Insert";
		this.m_InsertButton.UseVisualStyleBackColor = true;
		this.m_InsertButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_ChainRadioButton.AutoSize = true;
		this.m_ChainRadioButton.Location = new System.Drawing.Point(130, 221);
		this.m_ChainRadioButton.Name = "m_ChainRadioButton";
		this.m_ChainRadioButton.Size = new System.Drawing.Size(52, 17);
		this.m_ChainRadioButton.TabIndex = 15;
		this.m_ChainRadioButton.Text = "&Chain";
		this.m_ChainRadioButton.UseVisualStyleBackColor = true;
		this.m_SegmentRadioButton.AutoSize = true;
		this.m_SegmentRadioButton.Checked = true;
		this.m_SegmentRadioButton.Location = new System.Drawing.Point(12, 221);
		this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
		this.m_SegmentRadioButton.Size = new System.Drawing.Size(67, 17);
		this.m_SegmentRadioButton.TabIndex = 14;
		this.m_SegmentRadioButton.TabStop = true;
		this.m_SegmentRadioButton.Text = "&Segment";
		this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
		this.m_ToposurfacePane.Controls.Add(this.m_SurfaceList);
		this.m_ToposurfacePane.Controls.Add(this.m_SelectedSurfaceLabel);
		this.m_ToposurfacePane.Controls.Add(this.m_ToposurfaceCheckBox);
		this.m_ToposurfacePane.Location = new System.Drawing.Point(12, 171);
		this.m_ToposurfacePane.Name = "m_ToposurfacePane";
		this.m_ToposurfacePane.Size = new System.Drawing.Size(363, 44);
		this.m_ToposurfacePane.TabIndex = 13;
		this.m_SurfaceList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_SurfaceList.Enabled = false;
		this.m_SurfaceList.FormattingEnabled = true;
		this.m_SurfaceList.Location = new System.Drawing.Point(118, 23);
		this.m_SurfaceList.Name = "m_SurfaceList";
		this.m_SurfaceList.Size = new System.Drawing.Size(215, 21);
		this.m_SurfaceList.TabIndex = 2;
		this.m_SelectedSurfaceLabel.AutoSize = true;
		this.m_SelectedSurfaceLabel.Enabled = false;
		this.m_SelectedSurfaceLabel.Location = new System.Drawing.Point(0, 26);
		this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
		this.m_SelectedSurfaceLabel.Size = new System.Drawing.Size(44, 13);
		this.m_SelectedSurfaceLabel.TabIndex = 1;
		this.m_SelectedSurfaceLabel.Text = "Surface";
		this.m_ToposurfaceCheckBox.AutoSize = true;
		this.m_ToposurfaceCheckBox.Location = new System.Drawing.Point(0, 0);
		this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
		this.m_ToposurfaceCheckBox.Size = new System.Drawing.Size(86, 17);
		this.m_ToposurfaceCheckBox.TabIndex = 0;
		this.m_ToposurfaceCheckBox.Text = "Toposurface";
		this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
		this.m_ToposurfaceCheckBox.CheckStateChanged += new System.EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(387, 352);
		base.Controls.Add(this.m_ToposurfacePane);
		base.Controls.Add(this.m_ChainRadioButton);
		base.Controls.Add(this.m_SegmentRadioButton);
		base.Controls.Add(this.m_MoveablePanel);
		base.Controls.Add(this.m_ExistingElementCheckBox);
		base.Controls.Add(this.m_LoadFamilyButton);
		base.Controls.Add(this.m_FenceSpanLabel);
		base.Controls.Add(this.m_FenceSpanTextBox);
		base.Controls.Add(this.m_FenceHeightLabel);
		base.Controls.Add(this.m_FenceHeightTextBox);
		base.Controls.Add(this.m_SetbackLabel);
		base.Controls.Add(this.m_SetbackTextBox);
		base.Controls.Add(this.m_FenceNameComboBox);
		base.Controls.Add(this.m_FenceNameLabel);
		base.Controls.Add(this.m_LevelComboBox);
		base.Controls.Add(this.m_LevelLabel);
		base.Controls.Add(this.m_FenceFamilyComboBox);
		base.Controls.Add(this.m_FenceFamilyLabel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "LocateFenceForm";
		this.Text = "Locate Fence";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnLocateFenceFormClosing);
		this.m_MoveablePanel.ResumeLayout(false);
		this.m_MoveablePanel.PerformLayout();
		this.m_ToposurfacePane.ResumeLayout(false);
		this.m_ToposurfacePane.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_InsertButton;
		base.CancelButton = this.m_CancelButton;
	}
}
