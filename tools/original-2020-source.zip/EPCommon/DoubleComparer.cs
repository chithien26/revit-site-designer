﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.DoubleComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class DoubleComparer : IComparer<double>
{
  int IComparer<double>.Compare(double first, double second) => first.CompareTo(second);
}
