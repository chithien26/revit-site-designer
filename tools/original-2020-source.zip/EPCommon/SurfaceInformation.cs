﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SurfaceInformation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class SurfaceInformation : EPForm
{
  private LandXMLSurface m_SelectedSurface;
  private Document m_CurrentDocument;
  private List<TopographySurface> m_ExistingTopoSurfaces = new List<TopographySurface>();
  private List<Phase> m_PhaseList = new List<Phase>();
  private EPTransactionContainer m_TransactionConatiner;
  private const string m_strNummericSeperator = " - ";
  private string m_strOverwriteSurfaceID = string.Empty;
  private IContainer components;
  private GroupBox m_SurfaceInfoGroupBox;
  private Button m_ButtonCancel;
  private Button m_ButtonOk;
  private Panel panel1;
  private RadioButton m_NewSurfaceRadio;
  private ComboBox m_ExistingSurfaceCombo;
  private Label m_ExistingSurfaceLbl;
  private RadioButton m_OverwriteSurfaceRadio;
  private ComboBox m_PhaseComboBox;
  private Label m_PhaseLbl;
  private Label m_NameLbl;
  private TextBox m_NameTextBox;
  private Label m_NumberPntValueLbl;
  private Label m_NumberPntLbl;

  public SurfaceInformation(Document _CurrentDocument, EPTransactionContainer _TransactionConatiner)
  {
    this.m_CurrentDocument = _CurrentDocument;
    this.m_TransactionConatiner = _TransactionConatiner;
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDimportLandXMLinfo";
    this.LoadExistingSurface();
    this.SetupStrings();
    this.GetDialogPosition();
  }

  private void LoadExistingSurface()
  {
    FilteredElementCollector elementCollector = new FilteredElementCollector(this.m_CurrentDocument);
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
      this.m_ExistingTopoSurfaces.Add(element as TopographySurface);
    foreach (Phase phase in this.m_CurrentDocument.Phases)
      this.m_PhaseList.Add(phase);
  }

  private void SetupStrings()
  {
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    string empty = string.Empty;
    string str = $"{EPShared.LocalRM.GetString("ToposurfaceString")} {EPShared.LocalRM.GetString("InformationString")}";
    this.Text = str;
    this.m_SurfaceInfoGroupBox.Text = str;
    this.m_NewSurfaceRadio.Text = EPShared.LocalRM.GetString("Add_AMP_NewSurfaceSurfaceInfoDialog");
    this.m_NameLbl.Text = EPShared.LocalRM.GetString("Toposurface_AMP_NameSurfaceInfoDialog");
    this.m_PhaseLbl.Text = EPShared.LocalRM.GetString("AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog");
    this.m_OverwriteSurfaceRadio.Text = EPShared.LocalRM.GetString("AMP_OverwriteExistingSurfaceSurfaceInfoDialog");
    this.m_ExistingSurfaceLbl.Text = EPShared.LocalRM.GetString("AMP_ToposurfaceToOverwriteSurfaceInfoDialog");
    this.m_NumberPntLbl.Text = EPShared.LocalRM.GetString("NumberOfPntsString");
    this.m_PhaseComboBox.DataSource = (object) this.m_PhaseList;
    this.m_PhaseComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
    if (this.m_PhaseComboBox.Items.Count > 0)
      this.m_PhaseComboBox.SelectedIndex = 0;
    int num = 1;
    foreach (Element existingTopoSurface in this.m_ExistingTopoSurfaces)
    {
      Parameter parameter = existingTopoSurface[(BuiltInParameter) -1006900];
      if (parameter != null && parameter.AsString() != null && parameter.AsString() != string.Empty)
      {
        this.m_ExistingSurfaceCombo.Items.Add((object) parameter.AsString());
      }
      else
      {
        this.m_ExistingSurfaceCombo.Items.Add((object) $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>");
        ++num;
      }
    }
    if (this.m_ExistingSurfaceCombo.Items.Count > 0)
      this.m_ExistingSurfaceCombo.SelectedIndex = 0;
    this.m_NewSurfaceRadio.Checked = true;
  }

  private void NewSurfaceRadioCheckedChanged(object sender, EventArgs e)
  {
    if (this.m_NewSurfaceRadio.Checked)
    {
      this.m_NameTextBox.Enabled = true;
      this.m_PhaseComboBox.Enabled = true;
      this.m_ExistingSurfaceCombo.Enabled = false;
    }
    else
    {
      if (!this.m_OverwriteSurfaceRadio.Checked)
        return;
      if (this.m_ExistingTopoSurfaces.Count <= 0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoExistingSurfacesString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_NewSurfaceRadio.Checked = true;
      }
      else
      {
        this.m_NameTextBox.Enabled = false;
        this.m_PhaseComboBox.Enabled = false;
        this.m_ExistingSurfaceCombo.Enabled = true;
      }
    }
  }

  private void OnOkButtonClicked(object sender, EventArgs e)
  {
    if (this.m_NewSurfaceRadio.Checked)
    {
      bool flag = false;
      if (this.m_NameTextBox.Text == string.Empty)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSurfaceNameString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      Phase selectedItem = this.m_PhaseComboBox.SelectedItem as Phase;
      int nBeginningIndex = 0;
      TopographySurface startingNumberName = this.FindTopographySurfaceStartingNumberName(this.m_NameTextBox.Text, selectedItem, ref nBeginningIndex);
      if (startingNumberName != null)
      {
        WarningOptionsForm warningOptionsForm = new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), this.m_CurrentDocument.PathName, "ImportLandXML", EPShared.LocalRM.GetString("ToposurfaceSameNameAndPhaseMessage"), new List<string>()
        {
          EPShared.LocalRM.GetString("OverwriteToposurfaceOption"),
          EPShared.LocalRM.GetString("CreateNewToposurfaceOption")
        }, 0, true, false);
        int num = (int) warningOptionsForm.ShowDialog();
        if (warningOptionsForm.DialogResult != DialogResult.OK)
          return;
        if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("OverwriteToposurfaceOption"), true) == 0)
          flag = true;
        else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("CreateNewToposurfaceOption"), true) == 0)
          this.m_SelectedSurface.SurfaceName = $"{this.GetNameWithoutSeperator(this.m_NameTextBox.Text)} - {Convert.ToString(nBeginningIndex)}";
      }
      else
        this.m_SelectedSurface.SurfaceName = this.m_NameTextBox.Text;
      this.m_TransactionConatiner.BeginTransaction();
      if (startingNumberName != null && flag)
      {
        this.m_strOverwriteSurfaceID = ((Element) startingNumberName).UniqueId;
        this.m_CurrentDocument.Delete(((Element) startingNumberName).Id);
      }
      this.m_TransactionConatiner.EndTransaction();
    }
    else if (this.m_OverwriteSurfaceRadio.Checked)
    {
      this.m_TransactionConatiner.BeginTransaction();
      Element element = (Element) null;
      int num = 1;
      foreach (TopographySurface existingTopoSurface in this.m_ExistingTopoSurfaces)
      {
        Parameter parameter = ((Element) existingTopoSurface)[(BuiltInParameter) -1006900];
        if (parameter != null && parameter.AsString() != null && parameter.AsString() != string.Empty)
        {
          if (string.Compare(parameter.AsString(), this.m_ExistingSurfaceCombo.SelectedItem.ToString(), true) == 0)
          {
            element = (Element) existingTopoSurface;
            break;
          }
        }
        else
        {
          if (string.Compare($"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>", this.m_ExistingSurfaceCombo.SelectedItem.ToString(), true) == 0)
          {
            element = (Element) existingTopoSurface;
            break;
          }
          ++num;
        }
      }
      if (element != null)
      {
        this.m_strOverwriteSurfaceID = element.UniqueId;
        this.m_CurrentDocument.Delete(element.Id);
      }
      this.m_TransactionConatiner.EndTransaction();
    }
    this.DialogResult = DialogResult.OK;
  }

  public string GetNameWithoutSeperator(string _strValue)
  {
    int num = _strValue.LastIndexOf(" - ");
    if (num >= 0 && num < _strValue.Length)
    {
      string str = _strValue.Substring(num);
      if (str.StartsWith(" - ") && str.Length > " - ".Length)
      {
        bool flag = true;
        foreach (char c in str.Substring(" - ".Length))
        {
          if (!char.IsDigit(c))
          {
            flag = false;
            break;
          }
        }
        if (flag)
          _strValue = _strValue.Substring(0, num);
      }
    }
    return _strValue;
  }

  public TopographySurface FindTopographySurfaceStartingNumberName(
    string _strFindName,
    Phase SelectedPhase,
    ref int nBeginningIndex)
  {
    TopographySurface startingNumberName = (TopographySurface) null;
    List<Element> list = ((IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340)).ToList<Element>();
    nBeginningIndex = 0;
    bool flag = true;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    string withoutSeperator = this.GetNameWithoutSeperator(_strFindName);
    int num = 1;
    foreach (Element element in list)
    {
      if (element is TopographySurface topographySurface)
      {
        Parameter parameter1 = ((Element) topographySurface)[(BuiltInParameter) -1012100];
        if (parameter1 != null && ElementId.op_Equality(parameter1.AsElementId(), ((Element) SelectedPhase).Id))
        {
          Parameter parameter2 = ((Element) topographySurface)[(BuiltInParameter) -1006900];
          empty3 = string.Empty;
          string strA;
          if (parameter2 != null && parameter2.AsString() != null && parameter2.AsString() != string.Empty)
          {
            strA = parameter2.AsString();
          }
          else
          {
            strA = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
            ++num;
          }
          if (strA != string.Empty && strA.ToUpper().StartsWith(withoutSeperator.ToUpper()))
          {
            int startIndex = strA.LastIndexOf(" - ");
            if (startIndex >= 0 && startIndex < strA.Length)
            {
              string str1 = strA.Substring(startIndex);
              if (str1.StartsWith(" - ") && str1.Length > " - ".Length)
              {
                string str2 = str1.Substring(" - ".Length);
                for (int index = 0; index < str2.Length; ++index)
                {
                  if (!char.IsDigit(str2[index]))
                  {
                    flag = false;
                    break;
                  }
                }
                if (flag)
                {
                  int int32 = Convert.ToInt32(str2);
                  if (int32 > nBeginningIndex)
                    nBeginningIndex = int32;
                }
                else
                  flag = true;
              }
            }
            else if (string.Compare(strA, _strFindName, true) == 0)
              startingNumberName = topographySurface;
          }
        }
      }
    }
    ++nBeginningIndex;
    return startingNumberName;
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnSurfaceInformationClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void UpdateSurfaceDisplayInformation()
  {
    this.m_NumberPntValueLbl.Text = this.m_SelectedSurface.SurfacePointCount.ToString();
    this.m_NameTextBox.Text = this.m_SelectedSurface.SurfaceName;
  }

  public void SetCurrentSurface(LandXMLSurface _SelectedSurface)
  {
    this.m_SelectedSurface = _SelectedSurface;
    this.UpdateSurfaceDisplayInformation();
  }

  public string SurfaceName => this.m_SelectedSurface.SurfaceName;

  public Phase Phase => this.m_PhaseComboBox.SelectedItem as Phase;

  public string OverwriteSurfaceID => this.m_strOverwriteSurfaceID;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_SurfaceInfoGroupBox = new GroupBox();
    this.m_NumberPntValueLbl = new Label();
    this.m_NumberPntLbl = new Label();
    this.m_ButtonCancel = new Button();
    this.m_ButtonOk = new Button();
    this.panel1 = new Panel();
    this.m_ExistingSurfaceCombo = new ComboBox();
    this.m_ExistingSurfaceLbl = new Label();
    this.m_OverwriteSurfaceRadio = new RadioButton();
    this.m_PhaseComboBox = new ComboBox();
    this.m_PhaseLbl = new Label();
    this.m_NameLbl = new Label();
    this.m_NameTextBox = new TextBox();
    this.m_NewSurfaceRadio = new RadioButton();
    this.m_SurfaceInfoGroupBox.SuspendLayout();
    this.panel1.SuspendLayout();
    this.SuspendLayout();
    this.m_SurfaceInfoGroupBox.Controls.Add((Control) this.m_NumberPntValueLbl);
    this.m_SurfaceInfoGroupBox.Controls.Add((Control) this.m_NumberPntLbl);
    this.m_SurfaceInfoGroupBox.Location = new Point(13, 8);
    this.m_SurfaceInfoGroupBox.Name = "m_SurfaceInfoGroupBox";
    this.m_SurfaceInfoGroupBox.Size = new Size(455, 49);
    this.m_SurfaceInfoGroupBox.TabIndex = 0;
    this.m_SurfaceInfoGroupBox.TabStop = false;
    this.m_SurfaceInfoGroupBox.Text = "groupBox1";
    this.m_NumberPntValueLbl.AutoSize = true;
    this.m_NumberPntValueLbl.Location = new Point(120, 20);
    this.m_NumberPntValueLbl.Name = "m_NumberPntValueLbl";
    this.m_NumberPntValueLbl.Size = new Size(35, 13);
    this.m_NumberPntValueLbl.TabIndex = 1;
    this.m_NumberPntValueLbl.Text = "label3";
    this.m_NumberPntLbl.AutoSize = true;
    this.m_NumberPntLbl.Location = new Point(6, 20);
    this.m_NumberPntLbl.Name = "m_NumberPntLbl";
    this.m_NumberPntLbl.Size = new Size(88, 13);
    this.m_NumberPntLbl.TabIndex = 0;
    this.m_NumberPntLbl.Text = "Number of Points";
    this.m_ButtonCancel.Location = new Point(395, 224 /*0xE0*/);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 2;
    this.m_ButtonCancel.Text = "Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnCancelButtonClicked);
    this.m_ButtonOk.Location = new Point(314, 224 /*0xE0*/);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 1;
    this.m_ButtonOk.Text = "Ok";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnOkButtonClicked);
    this.panel1.Controls.Add((Control) this.m_ExistingSurfaceCombo);
    this.panel1.Controls.Add((Control) this.m_ExistingSurfaceLbl);
    this.panel1.Controls.Add((Control) this.m_OverwriteSurfaceRadio);
    this.panel1.Controls.Add((Control) this.m_PhaseComboBox);
    this.panel1.Controls.Add((Control) this.m_PhaseLbl);
    this.panel1.Controls.Add((Control) this.m_NameLbl);
    this.panel1.Controls.Add((Control) this.m_NameTextBox);
    this.panel1.Controls.Add((Control) this.m_NewSurfaceRadio);
    this.panel1.Location = new Point(14, 63 /*0x3F*/);
    this.panel1.Name = "panel1";
    this.panel1.Size = new Size(454, 155);
    this.panel1.TabIndex = 1;
    this.m_ExistingSurfaceCombo.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ExistingSurfaceCombo.FormattingEnabled = true;
    this.m_ExistingSurfaceCombo.Location = new Point(190, 120);
    this.m_ExistingSurfaceCombo.Name = "m_ExistingSurfaceCombo";
    this.m_ExistingSurfaceCombo.Size = new Size(129, 21);
    this.m_ExistingSurfaceCombo.TabIndex = 7;
    this.m_ExistingSurfaceLbl.AutoSize = true;
    this.m_ExistingSurfaceLbl.Location = new Point(20, 123);
    this.m_ExistingSurfaceLbl.Name = "m_ExistingSurfaceLbl";
    this.m_ExistingSurfaceLbl.Size = new Size(160 /*0xA0*/, 13);
    this.m_ExistingSurfaceLbl.TabIndex = 6;
    this.m_ExistingSurfaceLbl.Text = "Select Toposurface to Overwrite";
    this.m_OverwriteSurfaceRadio.AutoSize = true;
    this.m_OverwriteSurfaceRadio.Location = new Point(4, 97);
    this.m_OverwriteSurfaceRadio.Name = "m_OverwriteSurfaceRadio";
    this.m_OverwriteSurfaceRadio.Size = new Size(149, 17);
    this.m_OverwriteSurfaceRadio.TabIndex = 5;
    this.m_OverwriteSurfaceRadio.TabStop = true;
    this.m_OverwriteSurfaceRadio.Text = "Overwrite Existing Surface";
    this.m_OverwriteSurfaceRadio.UseVisualStyleBackColor = true;
    this.m_PhaseComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PhaseComboBox.FormattingEnabled = true;
    this.m_PhaseComboBox.Location = new Point(190, 53);
    this.m_PhaseComboBox.Name = "m_PhaseComboBox";
    this.m_PhaseComboBox.Size = new Size(129, 21);
    this.m_PhaseComboBox.TabIndex = 4;
    this.m_PhaseLbl.AutoSize = true;
    this.m_PhaseLbl.Location = new Point(20, 56);
    this.m_PhaseLbl.Name = "m_PhaseLbl";
    this.m_PhaseLbl.Size = new Size(37, 13);
    this.m_PhaseLbl.TabIndex = 3;
    this.m_PhaseLbl.Text = "Phase";
    this.m_NameLbl.AutoSize = true;
    this.m_NameLbl.Location = new Point(20, 29);
    this.m_NameLbl.Name = "m_NameLbl";
    this.m_NameLbl.Size = new Size(35, 13);
    this.m_NameLbl.TabIndex = 1;
    this.m_NameLbl.Text = "Name";
    this.m_NameTextBox.Location = new Point(190, 26);
    this.m_NameTextBox.Name = "m_NameTextBox";
    this.m_NameTextBox.Size = new Size(261, 20);
    this.m_NameTextBox.TabIndex = 2;
    this.m_NewSurfaceRadio.AutoSize = true;
    this.m_NewSurfaceRadio.Location = new Point(4, 4);
    this.m_NewSurfaceRadio.Name = "m_NewSurfaceRadio";
    this.m_NewSurfaceRadio.Size = new Size(132, 17);
    this.m_NewSurfaceRadio.TabIndex = 0;
    this.m_NewSurfaceRadio.TabStop = true;
    this.m_NewSurfaceRadio.Text = "Add as a New Surface";
    this.m_NewSurfaceRadio.UseVisualStyleBackColor = true;
    this.m_NewSurfaceRadio.CheckedChanged += new EventHandler(this.NewSurfaceRadioCheckedChanged);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(484, 257);
    this.Controls.Add((Control) this.panel1);
    this.Controls.Add((Control) this.m_ButtonOk);
    this.Controls.Add((Control) this.m_ButtonCancel);
    this.Controls.Add((Control) this.m_SurfaceInfoGroupBox);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(490, 289);
    this.Name = nameof (SurfaceInformation);
    this.Text = nameof (SurfaceInformation);
    this.FormClosing += new FormClosingEventHandler(this.OnSurfaceInformationClosing);
    this.m_SurfaceInfoGroupBox.ResumeLayout(false);
    this.m_SurfaceInfoGroupBox.PerformLayout();
    this.panel1.ResumeLayout(false);
    this.panel1.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
