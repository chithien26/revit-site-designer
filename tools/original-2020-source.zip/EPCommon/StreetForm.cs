﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.StreetForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class StreetForm : BaseForm
{
  private double m_dSlope;
  private double m_dSubgradeDepth;
  private double m_dWidth;
  private FamilySymbol m_StreetFamilySymbol;
  private CurbForm m_LeftCurbForm;
  private CurbForm m_RightCurbForm;

  public StreetForm(FamilySymbol _FamilySymbol, Eps_Leg _CurrentLeg)
    : base(_CurrentLeg)
  {
    this.m_LeftCurbForm = (CurbForm) null;
    this.m_RightCurbForm = (CurbForm) null;
    this.m_dSlope = 0.0;
    this.m_dSubgradeDepth = 0.0;
    this.m_dWidth = 24.0;
    double num = 12.0;
    this.m_StreetFamilySymbol = _FamilySymbol;
    if (_FamilySymbol == null)
      return;
    Parameter parameter1 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
    if (parameter1 != null)
      num = parameter1.AsDouble();
    Parameter parameter2 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
    if (parameter2 != null)
      this.m_dWidth = num * (double) parameter2.AsInteger();
    Parameter parameter3 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
    if (parameter3 != null)
      this.m_dSlope = parameter3.AsDouble();
    Parameter parameter4 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetPavementDepthParameter);
    if (parameter4 != null)
      this.m_dSubgradeDepth = parameter4.AsDouble();
    Parameter parameter5 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
    if (parameter5 == null || parameter5.AsInteger() == 0)
      return;
    this.m_LeftCurbForm = new CurbForm(_FamilySymbol, _CurrentLeg, true, true);
    this.m_RightCurbForm = new CurbForm(_FamilySymbol, _CurrentLeg, true, false);
  }

  private List<Form> CreateLoftForm(
    ref List<Form> _LeftCurbLoftFormList,
    ref List<Form> _RightCurbLoftFormList)
  {
    List<Form> loftForm = new List<Form>();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingStreetMassMessage");
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 0;
    List<ReferenceArrayArray> _LeftCurbArrayArrayList = new List<ReferenceArrayArray>();
    List<ReferenceArrayArray> _RightCurbArrayArrayList = new List<ReferenceArrayArray>();
    List<ReferenceArrayArray> referenceArrayArray = this.GetReferenceArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList);
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = referenceArrayArray.Count + _LeftCurbArrayArrayList.Count + _RightCurbArrayArrayList.Count;
    string empty = string.Empty;
    for (int index = 0; index < referenceArrayArray.Count; ++index)
    {
      if (referenceArrayArray[index] != null && referenceArrayArray[index].Size > 0)
      {
        Form form = this.NewStreetLoftForm(referenceArrayArray[index], index, ref empty);
        if (form == null)
        {
          this.m_TransactionContainer.AbortTransaction();
          this.m_TransactionContainer.BeginTransaction();
          if (this.m_AdditionalTransactionContainer != null)
          {
            this.m_AdditionalTransactionContainer.AbortTransaction();
            this.m_AdditionalTransactionContainer.BeginTransaction();
          }
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          loftForm.Clear();
          _LeftCurbLoftFormList.Clear();
          _RightCurbLoftFormList.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return loftForm;
        }
        loftForm.Add(form);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    for (int index = 0; index < _LeftCurbArrayArrayList.Count; ++index)
    {
      if (_LeftCurbArrayArrayList[index] != null && _LeftCurbArrayArrayList[index].Size > 0)
      {
        Form form = this.NewCurbLoftForm(_LeftCurbArrayArrayList[index], index, true, ref empty);
        if (form == null)
        {
          this.m_TransactionContainer.AbortTransaction();
          this.m_TransactionContainer.BeginTransaction();
          if (this.m_AdditionalTransactionContainer != null)
          {
            this.m_AdditionalTransactionContainer.AbortTransaction();
            this.m_AdditionalTransactionContainer.BeginTransaction();
          }
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          loftForm.Clear();
          _LeftCurbLoftFormList.Clear();
          _RightCurbLoftFormList.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return loftForm;
        }
        _LeftCurbLoftFormList.Add(form);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    for (int index = 0; index < _RightCurbArrayArrayList.Count; ++index)
    {
      if (_RightCurbArrayArrayList[index] != null && _RightCurbArrayArrayList[index].Size > 0)
      {
        Form form = this.NewCurbLoftForm(_RightCurbArrayArrayList[index], index, false, ref empty);
        if (form == null)
        {
          this.m_TransactionContainer.AbortTransaction();
          this.m_TransactionContainer.BeginTransaction();
          if (this.m_AdditionalTransactionContainer != null)
          {
            this.m_AdditionalTransactionContainer.AbortTransaction();
            this.m_AdditionalTransactionContainer.BeginTransaction();
          }
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          loftForm.Clear();
          _LeftCurbLoftFormList.Clear();
          _RightCurbLoftFormList.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return loftForm;
        }
        _RightCurbLoftFormList.Add(form);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return loftForm;
  }

  private List<Solid> CreateBlends(
    ref List<Solid> _LeftCurbLoftFormList,
    ref List<Solid> _RightCurbLoftFormList)
  {
    List<Solid> blends = new List<Solid>();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingStreetMassMessage");
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 0;
    List<List<CurveLoop>> _LeftCurbArrayArrayList = new List<List<CurveLoop>>();
    List<List<CurveLoop>> _RightCurbArrayArrayList = new List<List<CurveLoop>>();
    List<List<CurveLoop>> curveLoopArrayArray = this.GetCurveLoopArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList);
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = curveLoopArrayArray.Count + _LeftCurbArrayArrayList.Count + _RightCurbArrayArrayList.Count;
    string empty = string.Empty;
    for (int index = 0; index < curveLoopArrayArray.Count; ++index)
    {
      if (curveLoopArrayArray[index] != null && curveLoopArrayArray[index].Count > 0)
      {
        Solid solid = this.NewStreetBlend(curveLoopArrayArray[index], index, ref empty);
        if (GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          blends.Clear();
          _LeftCurbLoftFormList.Clear();
          _RightCurbLoftFormList.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return blends;
        }
        blends.Add(solid);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    for (int index = 0; index < _LeftCurbArrayArrayList.Count; ++index)
    {
      if (_LeftCurbArrayArrayList[index] != null && _LeftCurbArrayArrayList[index].Count > 0)
      {
        Solid solid = this.NewCurbBlend(_LeftCurbArrayArrayList[index], index, true, ref empty);
        if (GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          blends.Clear();
          _LeftCurbLoftFormList.Clear();
          _RightCurbLoftFormList.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return blends;
        }
        _LeftCurbLoftFormList.Add(solid);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    for (int index = 0; index < _RightCurbArrayArrayList.Count; ++index)
    {
      if (_RightCurbArrayArrayList[index] != null && _RightCurbArrayArrayList[index].Count > 0)
      {
        Solid solid = this.NewCurbBlend(_RightCurbArrayArrayList[index], index, false, ref empty);
        if (GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          blends.Clear();
          _LeftCurbLoftFormList.Clear();
          _RightCurbLoftFormList.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return blends;
        }
        _RightCurbLoftFormList.Add(solid);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return blends;
  }

  private Solid NewStreetBlend(
    List<CurveLoop> streetCurveLoopArray,
    int _nProcessLegSegment,
    ref string _strErrorMessage)
  {
    Solid solid = (Solid) null;
    try
    {
      SolidOptions solidOptions = (SolidOptions) null;
      Parameter parameter = ((Element) this.StreetFamilySymbol).LookupParameter(RevitParameters.StreetPavementSurfaceParameter);
      if (parameter != null)
        solidOptions = new SolidOptions(new ElementId(parameter.AsInteger()), ElementId.InvalidElementId);
      solid = GeometryCreationUtilities.CreateLoftGeometry((IList<CurveLoop>) streetCurveLoopArray, solidOptions);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (Exception ex)
    {
      if (string.Compare(ex.Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("StreetTemplateNotMassTypeMessage");
        return (Solid) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<List<CurveLoop>> _LeftCurbArrayArrayList = new List<List<CurveLoop>>();
        List<List<CurveLoop>> _RightCurbArrayArrayList = new List<List<CurveLoop>>();
        List<List<CurveLoop>> curveLoopArrayArray = this.GetCurveLoopArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList, _nProcessLegSegment);
        if (curveLoopArrayArray.Count > 0)
          solid = this.NewStreetBlend(curveLoopArrayArray[0], _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCeateBlendGeometry");
    }
    return solid;
  }

  private Form NewStreetLoftForm(
    ReferenceArrayArray _StreetReferenceArrayArray,
    int _nProcessLegSegment,
    ref string _strErrorMessage)
  {
    Form form = (Form) null;
    try
    {
      form = this.m_MassDocument.FamilyCreate.NewLoftForm(true, _StreetReferenceArrayArray);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (InvalidOperationException ex)
    {
      if (string.Compare(((Exception) ex).Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("StreetTemplateNotMassTypeMessage");
        return (Form) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<ReferenceArrayArray> _LeftCurbArrayArrayList = new List<ReferenceArrayArray>();
        List<ReferenceArrayArray> _RightCurbArrayArrayList = new List<ReferenceArrayArray>();
        List<ReferenceArrayArray> referenceArrayArray = this.GetReferenceArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList, _nProcessLegSegment);
        if (referenceArrayArray.Count > 0)
          form = this.NewStreetLoftForm(referenceArrayArray[0], _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCreateMassMessage");
    }
    return form;
  }

  private Form NewCurbLoftForm(
    ReferenceArrayArray _CurbReferenceArrayArray,
    int _nProcessLegSegment,
    bool _bIsLeftCurb,
    ref string _strErrorMessage)
  {
    Form form = (Form) null;
    try
    {
      form = this.m_AdditionalMassDocument.FamilyCreate.NewLoftForm(true, _CurbReferenceArrayArray);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (InvalidOperationException ex)
    {
      if (string.Compare(((Exception) ex).Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("CurbTemplateNotMassTypeMessage");
        return (Form) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<ReferenceArrayArray> _LeftCurbArrayArrayList = new List<ReferenceArrayArray>();
        List<ReferenceArrayArray> _RightCurbArrayArrayList = new List<ReferenceArrayArray>();
        this.GetReferenceArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList, _nProcessLegSegment);
        if (_bIsLeftCurb)
        {
          if (_LeftCurbArrayArrayList.Count > 0)
            form = this.NewStreetLoftForm(_LeftCurbArrayArrayList[0], _nProcessLegSegment, ref _strErrorMessage);
        }
        else if (_RightCurbArrayArrayList.Count > 0)
          form = this.NewStreetLoftForm(_RightCurbArrayArrayList[0], _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCreateMassMessage");
    }
    return form;
  }

  private Solid NewCurbBlend(
    List<CurveLoop> curbCurveLoopArray,
    int _nProcessLegSegment,
    bool _bIsLeftCurb,
    ref string _strErrorMessage)
  {
    Solid solid = (Solid) null;
    try
    {
      SolidOptions solidOptions = (SolidOptions) null;
      Parameter parameter = ((Element) this.StreetFamilySymbol).LookupParameter(RevitParameters.StreetCurbMaterialParameter);
      if (parameter != null)
        solidOptions = new SolidOptions(new ElementId(parameter.AsInteger()), ElementId.InvalidElementId);
      solid = GeometryCreationUtilities.CreateLoftGeometry((IList<CurveLoop>) curbCurveLoopArray, solidOptions);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (Exception ex)
    {
      if (string.Compare(ex.Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("CurbTemplateNotMassTypeMessage");
        return (Solid) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<List<CurveLoop>> _LeftCurbArrayArrayList = new List<List<CurveLoop>>();
        List<List<CurveLoop>> _RightCurbArrayArrayList = new List<List<CurveLoop>>();
        this.GetCurveLoopArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList, _nProcessLegSegment);
        if (_bIsLeftCurb)
        {
          if (_LeftCurbArrayArrayList.Count > 0)
            solid = this.NewStreetBlend(_LeftCurbArrayArrayList[0], _nProcessLegSegment, ref _strErrorMessage);
        }
        else if (_RightCurbArrayArrayList.Count > 0)
          solid = this.NewStreetBlend(_RightCurbArrayArrayList[0], _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCeateBlendGeometry");
    }
    return solid;
  }

  public override string CreateElement(
    Document doc,
    ref string _strAdditionalLoftID,
    string _strSiteComponentName,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseInternalPoint)
  {
    List<Solid> _LeftCurbLoftFormList = new List<Solid>();
    List<Solid> _RightCurbLoftFormList = new List<Solid>();
    List<Solid> blends = this.CreateBlends(ref _LeftCurbLoftFormList, ref _RightCurbLoftFormList);
    if (blends == null || blends.Count == 0)
      return string.Empty;
    List<GeometryObject> geometryObjectList = new List<GeometryObject>();
    foreach (Solid solid in blends)
      geometryObjectList.Add((GeometryObject) solid);
    if (geometryObjectList.Count == 0)
      return string.Empty;
    Guid guid = doc.Application.ActiveAddInId.GetGUID();
    DirectShape element1 = DirectShape.CreateElement(doc, new ElementId((BuiltInCategory) -2001220));
    element1.ApplicationId = guid.ToString();
    element1.SetShape((IList<GeometryObject>) geometryObjectList);
    string uniqueId = ((Element) element1).UniqueId;
    ElementTransformUtils.MoveElement(doc, ((Element) element1).Id, this.m_LegInsertPoint.XYZ);
    ((Element) element1).Name = _strSiteComponentName;
    geometryObjectList.Clear();
    foreach (Solid solid in _LeftCurbLoftFormList)
      geometryObjectList.Add((GeometryObject) solid);
    foreach (Solid solid in _RightCurbLoftFormList)
      geometryObjectList.Add((GeometryObject) solid);
    if (geometryObjectList.Count != 0)
    {
      DirectShape element2 = DirectShape.CreateElement(doc, new ElementId((BuiltInCategory) -2001220));
      element2.ApplicationId = guid.ToString();
      element2.SetShape((IList<GeometryObject>) geometryObjectList);
      _strAdditionalLoftID = ((Element) element2).UniqueId;
      ElementTransformUtils.MoveElement(doc, ((Element) element2).Id, this.m_LegInsertPoint.XYZ);
      ((Element) element2).Name = $"{_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}";
    }
    return uniqueId;
  }

  public List<Form> CreateLoftFormWithParameters()
  {
    List<Form> _LeftCurbLoftFormList = new List<Form>();
    List<Form> _RightCurbLoftFormList = new List<Form>();
    List<Form> loftForm = this.CreateLoftForm(ref _LeftCurbLoftFormList, ref _RightCurbLoftFormList);
    if (loftForm == null || loftForm.Count == 0)
      return loftForm;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    Category category1 = (Category) null;
    Category category2 = (Category) null;
    Category familyCategory = this.m_MassDocument.OwnerFamily.FamilyCategory;
    if (familyCategory != null && familyCategory.SubCategories != null && familyCategory.SubCategories.Size > 0)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("StreetMassSubCategoryName", ref empty1) && !ApplicationUtility.Settings.eplSetE_GetSetting("StreetMassSubCatergoryName", ref empty1))
      {
        empty1 = EPShared.LocalRM.GetString("SWStreetLineNameString");
        ApplicationUtility.Settings.eplSetE_SetSetting("StreetMassSubCategoryName", empty1);
      }
      if (familyCategory.SubCategories.Contains(empty1))
        category1 = familyCategory.SubCategories[empty1];
    }
    Category category3 = (Category) null;
    if (this.m_AdditionalMassDocument != null)
      category3 = this.m_AdditionalMassDocument.OwnerFamily.FamilyCategory;
    if (category3 != null && category3.SubCategories != null && category3.SubCategories.Size > 0)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("CurbMassSubCategoryName", ref empty2) && !ApplicationUtility.Settings.eplSetE_GetSetting("CurbMassSubCatergoryName", ref empty2))
      {
        empty2 = EPShared.LocalRM.GetString("SWCurbLineNameString");
        ApplicationUtility.Settings.eplSetE_SetSetting("CurbMassSubCategoryName", empty2);
      }
      if (category3.SubCategories.Contains(empty2))
        category2 = category3.SubCategories[empty2];
    }
    FamilyParameter familyParameter1 = (FamilyParameter) null;
    if (loftForm != null && loftForm.Count > 0)
    {
      if (category1 == null)
        category1 = this.m_MassDocument.Settings.Categories.NewSubcategory(familyCategory, empty1);
      for (int index = 0; index < loftForm.Count; ++index)
      {
        if (familyParameter1 == null)
          familyParameter1 = this.m_MassDocument.FamilyManager.AddParameter(RevitParameters.StreetPavementSurfaceParameter, (BuiltInParameterGroup) -5000105, (ParameterType) 9, true);
        try
        {
          Parameter parameter = ((Element) loftForm[index])[(BuiltInParameter) -1002107];
          if (parameter != null)
            this.m_MassDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter1);
          if (category1 != null)
            ((GenericForm) loftForm[index]).Subcategory = category1;
        }
        catch (InvalidOperationException ex)
        {
        }
      }
    }
    FamilyParameter familyParameter2 = (FamilyParameter) null;
    if (_LeftCurbLoftFormList != null && _LeftCurbLoftFormList.Count > 0)
    {
      if (this.m_AdditionalMassDocument != null && category2 == null)
        category2 = this.m_AdditionalMassDocument.Settings.Categories.NewSubcategory(familyCategory, empty2);
      for (int index = 0; index < _LeftCurbLoftFormList.Count; ++index)
      {
        if (familyParameter2 == null)
          familyParameter2 = this.m_AdditionalMassDocument.FamilyManager.AddParameter(RevitParameters.StreetCurbMaterialParameter, (BuiltInParameterGroup) -5000105, (ParameterType) 9, true);
        try
        {
          Parameter parameter = ((Element) _LeftCurbLoftFormList[index])[(BuiltInParameter) -1002107];
          if (parameter != null)
            this.m_AdditionalMassDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter2);
          if (category2 != null)
            ((GenericForm) _LeftCurbLoftFormList[index]).Subcategory = category2;
        }
        catch (InvalidOperationException ex)
        {
        }
      }
    }
    if (_RightCurbLoftFormList != null && _RightCurbLoftFormList.Count > 0)
    {
      if (this.m_AdditionalMassDocument != null && category2 == null)
        category2 = this.m_AdditionalMassDocument.Settings.Categories.NewSubcategory(familyCategory, empty2);
      for (int index = 0; index < _RightCurbLoftFormList.Count; ++index)
      {
        if (familyParameter2 == null)
          familyParameter2 = this.m_AdditionalMassDocument.FamilyManager.AddParameter(RevitParameters.StreetCurbMaterialParameter, (BuiltInParameterGroup) -5000105, (ParameterType) 9, true);
        try
        {
          Parameter parameter = ((Element) _RightCurbLoftFormList[index])[(BuiltInParameter) -1002107];
          if (parameter != null)
            this.m_AdditionalMassDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter2);
          if (category2 != null)
            ((GenericForm) _RightCurbLoftFormList[index]).Subcategory = category2;
        }
        catch (InvalidOperationException ex)
        {
        }
      }
    }
    return loftForm;
  }

  private List<ReferenceArrayArray> GetReferenceArrayArray(
    ref List<ReferenceArrayArray> _LeftCurbArrayArrayList,
    ref List<ReferenceArrayArray> _RightCurbArrayArrayList)
  {
    return this.GetReferenceArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList, -1);
  }

  private List<ReferenceArrayArray> GetReferenceArrayArray(
    ref List<ReferenceArrayArray> _LeftCurbArrayArrayList,
    ref List<ReferenceArrayArray> _RightCurbArrayArrayList,
    int _nProcessLegSegment)
  {
    List<ReferenceArrayArray> referenceArrayArray1 = new List<ReferenceArrayArray>();
    ReferenceArrayArray referenceArrayArray2 = (ReferenceArrayArray) null;
    ReferenceArrayArray referenceArrayArray3 = (ReferenceArrayArray) null;
    ReferenceArrayArray referenceArrayArray4 = (ReferenceArrayArray) null;
    ReferenceArray referenceArray1 = (ReferenceArray) null;
    ReferenceArray _LeftCurbReferenceArray = (ReferenceArray) null;
    ReferenceArray _RightCurbReferenceArray = (ReferenceArray) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point Pnt = new Eps_Point();
    double _dStation1 = 0.0;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    double _dX = 0.0;
    double num1 = 0.0;
    double num2 = 0.0;
    double _dAdjustDistance = 0.0;
    double _dStation2 = 0.0;
    double _dOffset1 = 0.0;
    bool flag1 = false;
    int _nDocIndex = 0;
    int index1 = 0;
    int index2 = 0;
    bool flag2 = true;
    bool flag3 = true;
    bool flag4 = true;
    if (this.m_MassLeg != null)
    {
      if (this.m_IntersectionContainers != null && this.m_IntersectionContainers.Count > 0)
      {
        if (this.m_IntersectionContainers[0].ProfileUsage == ProfileUsage.EntireProfile)
          flag2 = this.m_IntersectionContainers[0].StartingIntersection;
        else if (this.m_IntersectionContainers[0].ProfileUsage == ProfileUsage.LeftOnly)
        {
          flag3 = this.m_IntersectionContainers[0].StartingIntersection;
          if (this.m_IntersectionContainers.Count > 1 && this.m_IntersectionContainers[1].ProfileUsage == ProfileUsage.RightOnly)
            flag4 = this.m_IntersectionContainers[1].StartingIntersection;
        }
        else if (this.m_IntersectionContainers[0].ProfileUsage == ProfileUsage.RightOnly)
        {
          flag4 = this.m_IntersectionContainers[0].StartingIntersection;
          if (this.m_IntersectionContainers.Count > 1 && this.m_IntersectionContainers[1].ProfileUsage == ProfileUsage.LeftOnly)
            flag3 = this.m_IntersectionContainers[1].StartingIntersection;
        }
      }
      for (Eps_Leg _Leg = this.m_MassLeg; _Leg != null; _Leg = _Leg.Next)
      {
        if (_nProcessLegSegment > -1)
        {
          if (_nDocIndex <= _nProcessLegSegment)
          {
            if (_nDocIndex < _nProcessLegSegment)
            {
              ++_nDocIndex;
              continue;
            }
          }
          else
            break;
        }
        if (_nDocIndex == 0 || flag2)
        {
          referenceArrayArray2 = new ReferenceArrayArray();
          if (_nDocIndex == 0 || flag3)
            referenceArrayArray3 = new ReferenceArrayArray();
          if (_nDocIndex == 0 || flag4)
            referenceArrayArray4 = new ReferenceArrayArray();
        }
        double num3 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
        if (_Leg.Arc != null)
        {
          Arc arc = _Leg.Arc.RevitArc(this.m_MassDocument);
          double _dStation3 = 0.0;
          double _dOffset2 = 0.0;
          int num4 = 0;
          List<XYZ> list = ((Curve) arc).Tessellate().ToList<XYZ>();
          int count = list.Count;
          foreach (XYZ _XYZPoint in list)
          {
            Eps_Point _Point = new Eps_Point(_XYZPoint);
            if (num4 % 5 != 0 && num4 != 1 && num4 != count - 1)
            {
              ++num4;
            }
            else
            {
              EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation3, ref _dOffset2);
              if (_nDocIndex > 0 && num4 == 0)
                _dStation3 += dOffsetAdjust;
              if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null && num4 == count - 1)
                _dStation3 -= dOffsetAdjust;
              ReferenceArray profileAtStation;
              if (num4 == count - 1 && _Leg.Next != null && _Leg.Next.Line != null)
              {
                EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Arc, ref _dX);
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                int ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Next.Line.EndPnt);
                if (!RevitDefines.EQ(_dX, num2))
                {
                  double num5 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                  double SweepAngle = 0.0;
                  RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                  num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                  if (!RevitDefines.EQ(_dX, num1))
                  {
                    flag1 = true;
                    _dAdjustDistance = Math.Abs(Math.Cos(num5 / 2.0));
                    profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation3, true, num1, _dAdjustDistance, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
                  }
                  else
                    profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation3, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
                }
                else
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation3, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
              }
              else if (flag1)
              {
                profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
                flag1 = false;
              }
              else
                profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation3, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
              if (profileAtStation != null && profileAtStation.Size > 0)
              {
                referenceArrayArray2.Append(profileAtStation);
                referenceArray1 = (ReferenceArray) null;
              }
              if (_LeftCurbReferenceArray != null && _LeftCurbReferenceArray.Size > 0)
              {
                referenceArrayArray3.Append(_LeftCurbReferenceArray);
                _LeftCurbReferenceArray = (ReferenceArray) null;
              }
              if (_RightCurbReferenceArray != null && _RightCurbReferenceArray.Size > 0)
              {
                referenceArrayArray4.Append(_RightCurbReferenceArray);
                _RightCurbReferenceArray = (ReferenceArray) null;
              }
              ++num4;
            }
          }
          _dStation1 += num3;
        }
        else
        {
          if (flag2)
          {
            ReferenceArray profileAtStation;
            if (_nDocIndex == 0)
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
            else if (flag1)
            {
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
              flag1 = false;
            }
            else
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
            if (profileAtStation != null && profileAtStation.Size > 0)
            {
              referenceArrayArray2.Append(profileAtStation);
              referenceArray1 = (ReferenceArray) null;
            }
            if (flag3 && _LeftCurbReferenceArray != null && _LeftCurbReferenceArray.Size > 0)
            {
              referenceArrayArray3.Append(_LeftCurbReferenceArray);
              _LeftCurbReferenceArray = (ReferenceArray) null;
            }
            if (flag4 && _RightCurbReferenceArray != null && _RightCurbReferenceArray.Size > 0)
            {
              referenceArrayArray4.Append(_RightCurbReferenceArray);
              _RightCurbReferenceArray = (ReferenceArray) null;
            }
          }
          if (this.m_IntersectionContainers != null)
          {
            while (index1 < this.m_IntersectionContainers.Count && index2 < this.m_IntersectionContainers[index1].Profiles.Count && this.m_IntersectionContainers[index1].Profiles[index2].Station <= _dStation1 + num3)
            {
              if (this.m_IntersectionContainers[index1].Profiles[index2].Station >= _dStation1)
              {
                if (this.m_IntersectionContainers[index1].ProfileUsage == ProfileUsage.EntireProfile)
                {
                  if (flag2 && this.m_IntersectionContainers[index1].StartingIntersection && index2 == 0 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 6)
                  {
                    Eps_Point point1 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                    Eps_Point point2 = this.m_IntersectionContainers[index1].Profiles[index2].Points[4];
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
                    _dX = EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI / 2.0);
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point2, point1, ref num2);
                    ReferenceArray profileAtStation;
                    if (!RevitDefines.EQ(_dX, num2))
                    {
                      _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                      profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust, true, num2, _dAdjustDistance);
                    }
                    else
                      profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust);
                    if (profileAtStation != null && profileAtStation.Size > 0)
                    {
                      referenceArrayArray2.Append(profileAtStation);
                      referenceArray1 = (ReferenceArray) null;
                    }
                    if (referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
                    {
                      referenceArrayArray1.Add(referenceArrayArray2);
                      referenceArrayArray2 = new ReferenceArrayArray();
                    }
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point1, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                    {
                      Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                      _LeftCurbReferenceArray = this.FindCurbReferenceArrayProfileAtStation(true, _dStation2 - dOffsetAdjust, point1.z - Pnt.z);
                      if (_LeftCurbReferenceArray != null && _LeftCurbReferenceArray.Size > 0)
                      {
                        referenceArrayArray3.Append(_LeftCurbReferenceArray);
                        _LeftCurbReferenceArray = (ReferenceArray) null;
                      }
                      if (referenceArrayArray3 != null && referenceArrayArray3.Size > 0)
                      {
                        _LeftCurbArrayArrayList.Add(referenceArrayArray3);
                        referenceArrayArray3 = new ReferenceArrayArray();
                      }
                    }
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point2, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                    {
                      Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                      _RightCurbReferenceArray = this.FindCurbReferenceArrayProfileAtStation(false, _dStation2 - dOffsetAdjust, point2.z - Pnt.z);
                      if (_RightCurbReferenceArray != null && _RightCurbReferenceArray.Size > 0)
                      {
                        referenceArrayArray4.Append(_RightCurbReferenceArray);
                        _RightCurbReferenceArray = (ReferenceArray) null;
                      }
                      if (referenceArrayArray4 != null && referenceArrayArray4.Size > 0)
                      {
                        _RightCurbArrayArrayList.Add(referenceArrayArray4);
                        referenceArrayArray4 = new ReferenceArrayArray();
                      }
                    }
                  }
                  ReferenceArray referenceArray2 = this.ApplyReferenceArrayProfile(this.m_IntersectionContainers[index1].Profiles[index2].Points);
                  if (referenceArray2 != null && referenceArray2.Size > 0)
                  {
                    referenceArrayArray2.Append(referenceArray2);
                    referenceArray1 = (ReferenceArray) null;
                  }
                  if (this.m_IntersectionContainers[index1].StartingIntersection)
                  {
                    if (index2 == 0)
                    {
                      flag2 = false;
                      referenceArrayArray3.Clear();
                      List<ReferenceArrayArray> referenceArrayArray5 = this.GetCurbReferenceArrayArray(true, this.m_IntersectionContainers[index1].LeftOffsetLeg);
                      if (referenceArrayArray5 != null && referenceArrayArray5.Count > 0)
                        _LeftCurbArrayArrayList.AddRange((IEnumerable<ReferenceArrayArray>) referenceArrayArray5);
                      referenceArrayArray4.Clear();
                      List<ReferenceArrayArray> referenceArrayArray6 = this.GetCurbReferenceArrayArray(false, this.m_IntersectionContainers[index1].RightOffsetLeg);
                      if (referenceArrayArray6 != null && referenceArrayArray6.Count > 0)
                        _RightCurbArrayArrayList.AddRange((IEnumerable<ReferenceArrayArray>) referenceArrayArray6);
                    }
                    else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1 && referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
                    {
                      referenceArrayArray1.Add(referenceArrayArray2);
                      referenceArrayArray2 = new ReferenceArrayArray();
                    }
                  }
                  else if (index2 == 0)
                  {
                    List<ReferenceArrayArray> referenceArrayArray7 = this.GetCurbReferenceArrayArray(true, this.m_IntersectionContainers[index1].LeftOffsetLeg);
                    if (referenceArrayArray7 != null && referenceArrayArray7.Count > 0)
                      _LeftCurbArrayArrayList.AddRange((IEnumerable<ReferenceArrayArray>) referenceArrayArray7);
                    List<ReferenceArrayArray> referenceArrayArray8 = this.GetCurbReferenceArrayArray(false, this.m_IntersectionContainers[index1].RightOffsetLeg);
                    if (referenceArrayArray8 != null && referenceArrayArray8.Count > 0)
                      _RightCurbArrayArrayList.AddRange((IEnumerable<ReferenceArrayArray>) referenceArrayArray8);
                  }
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                  {
                    flag2 = true;
                    if (referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
                    {
                      referenceArrayArray1.Add(referenceArrayArray2);
                      referenceArrayArray2 = new ReferenceArrayArray();
                    }
                    if (this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust < _dStation1 + num3 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 6)
                    {
                      Eps_Point point3 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                      Eps_Point point4 = this.m_IntersectionContainers[index1].Profiles[index2].Points[4];
                      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.EndPnt, _Leg.Line.StartPnt, ref _dX);
                      _dX = EPShared.eplGeoE_NormalizeRadians(_dX - Math.PI / 2.0);
                      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point4, point3, ref num2);
                      ReferenceArray profileAtStation;
                      if (!RevitDefines.EQ(_dX, num2))
                      {
                        _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                        profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust, true, num2, _dAdjustDistance);
                      }
                      else
                        profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust);
                      if (profileAtStation != null && profileAtStation.Size > 0)
                      {
                        referenceArrayArray2.Append(profileAtStation);
                        referenceArray1 = (ReferenceArray) null;
                      }
                      if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point3, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                      {
                        Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                        _LeftCurbReferenceArray = this.FindCurbReferenceArrayProfileAtStation(true, _dStation2 + dOffsetAdjust, point3.z - Pnt.z);
                        if (_LeftCurbReferenceArray != null && _LeftCurbReferenceArray.Size > 0)
                        {
                          referenceArrayArray3.Append(_LeftCurbReferenceArray);
                          _LeftCurbReferenceArray = (ReferenceArray) null;
                        }
                      }
                      if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point4, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                      {
                        Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                        _RightCurbReferenceArray = this.FindCurbReferenceArrayProfileAtStation(false, _dStation2 + dOffsetAdjust, point4.z - Pnt.z);
                        if (_RightCurbReferenceArray != null && _RightCurbReferenceArray.Size > 0)
                        {
                          referenceArrayArray4.Append(_RightCurbReferenceArray);
                          _RightCurbReferenceArray = (ReferenceArray) null;
                        }
                      }
                    }
                  }
                }
                else if (this.m_IntersectionContainers[index1].ProfileUsage == ProfileUsage.LeftOnly)
                {
                  _LeftCurbReferenceArray = this.FindCurbReferenceArrayProfileAtStation(true, this.m_IntersectionContainers[index1].Profiles[index2].Station);
                  if (_LeftCurbReferenceArray != null && _LeftCurbReferenceArray.Size > 0)
                  {
                    referenceArrayArray3.Append(_LeftCurbReferenceArray);
                    _LeftCurbReferenceArray = (ReferenceArray) null;
                  }
                  if (this.m_IntersectionContainers[index1].StartingIntersection)
                  {
                    if (index2 == 0)
                    {
                      flag3 = false;
                      if (referenceArrayArray3 != null && referenceArrayArray3.Size > 0)
                      {
                        _LeftCurbArrayArrayList.Add(referenceArrayArray3);
                        referenceArrayArray3 = new ReferenceArrayArray();
                      }
                    }
                  }
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                    flag3 = true;
                }
                else if (this.m_IntersectionContainers[index1].ProfileUsage == ProfileUsage.RightOnly)
                {
                  _RightCurbReferenceArray = this.FindCurbReferenceArrayProfileAtStation(false, this.m_IntersectionContainers[index1].Profiles[index2].Station);
                  if (_RightCurbReferenceArray != null && _RightCurbReferenceArray.Size > 0)
                  {
                    referenceArrayArray4.Append(_RightCurbReferenceArray);
                    _RightCurbReferenceArray = (ReferenceArray) null;
                  }
                  if (this.m_IntersectionContainers[index1].StartingIntersection)
                  {
                    if (index2 == 0)
                    {
                      flag4 = false;
                      if (referenceArrayArray4 != null && referenceArrayArray4.Size > 0)
                      {
                        _RightCurbArrayArrayList.Add(referenceArrayArray4);
                        referenceArrayArray4 = new ReferenceArrayArray();
                      }
                    }
                  }
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                    flag4 = true;
                }
              }
              ++index2;
              if (index2 >= this.m_IntersectionContainers[index1].Profiles.Count)
              {
                index2 = 0;
                ++index1;
              }
              flag1 = false;
            }
          }
          _dStation1 += num3;
          if (flag2)
          {
            if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null)
              _dStation1 -= dOffsetAdjust;
            ReferenceArray profileAtStation;
            if (_Leg.Next != null)
            {
              int ArcDir = 0;
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
              if (_Leg.Next.Line != null)
              {
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Line.EndPnt);
              }
              else if (_Leg.Next.Arc != null)
              {
                EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Next.Arc, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Arc.EndPnt);
              }
              if (!RevitDefines.EQ(_dX, num2))
              {
                double num6 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                double SweepAngle = 0.0;
                RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                if (!RevitDefines.EQ(_dX, num1))
                {
                  flag1 = true;
                  _dAdjustDistance = Math.Abs(Math.Cos(num6 / 2.0));
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, true, num1, _dAdjustDistance, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
                }
                else
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
              }
              else
                profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
            }
            else
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
            if (profileAtStation != null && profileAtStation.Size > 0)
            {
              referenceArrayArray2.Append(profileAtStation);
              referenceArray1 = (ReferenceArray) null;
            }
            if (flag3 && _LeftCurbReferenceArray != null && _LeftCurbReferenceArray.Size > 0)
            {
              referenceArrayArray3.Append(_LeftCurbReferenceArray);
              _LeftCurbReferenceArray = (ReferenceArray) null;
            }
            if (flag4 && _RightCurbReferenceArray != null && _RightCurbReferenceArray.Size > 0)
            {
              referenceArrayArray4.Append(_RightCurbReferenceArray);
              _RightCurbReferenceArray = (ReferenceArray) null;
            }
          }
        }
        if (flag2 && referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
        {
          referenceArrayArray1.Add(referenceArrayArray2);
          if (flag3 && referenceArrayArray3 != null && referenceArrayArray3.Size > 0)
            _LeftCurbArrayArrayList.Add(referenceArrayArray3);
          if (flag4 && referenceArrayArray4 != null && referenceArrayArray4.Size > 0)
            _RightCurbArrayArrayList.Add(referenceArrayArray4);
        }
        ++_nDocIndex;
      }
    }
    return referenceArrayArray1;
  }

  private List<List<CurveLoop>> GetCurveLoopArrayArray(
    ref List<List<CurveLoop>> _LeftCurbArrayArrayList,
    ref List<List<CurveLoop>> _RightCurbArrayArrayList)
  {
    return this.GetCurveLoopArrayArray(ref _LeftCurbArrayArrayList, ref _RightCurbArrayArrayList, -1);
  }

  private List<List<CurveLoop>> GetCurveLoopArrayArray(
    ref List<List<CurveLoop>> _LeftCurbArrayArrayList,
    ref List<List<CurveLoop>> _RightCurbArrayArrayList,
    int _nProcessLegSegment)
  {
    List<List<CurveLoop>> curveLoopArrayArray = new List<List<CurveLoop>>();
    List<CurveLoop> curveLoopList1 = (List<CurveLoop>) null;
    List<CurveLoop> curveLoopList2 = (List<CurveLoop>) null;
    List<CurveLoop> curveLoopList3 = (List<CurveLoop>) null;
    CurveLoop curveLoop1 = (CurveLoop) null;
    CurveLoop _LeftCurbCurveLoop = (CurveLoop) null;
    CurveLoop _RightCurbCurveLoop = (CurveLoop) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point Pnt = new Eps_Point();
    double _dStation1 = 0.0;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    double _dX = 0.0;
    double num1 = 0.0;
    double num2 = 0.0;
    double _dAdjustDistance = 0.0;
    double _dStation2 = 0.0;
    double _dOffset1 = 0.0;
    bool flag1 = false;
    int _nDocIndex = 0;
    int index1 = 0;
    int index2 = 0;
    bool flag2 = true;
    bool flag3 = true;
    bool flag4 = true;
    if (this.m_MassLeg != null)
    {
      if (this.m_IntersectionContainers != null && this.m_IntersectionContainers.Count > 0)
      {
        if (this.m_IntersectionContainers[0].ProfileUsage == ProfileUsage.EntireProfile)
          flag2 = this.m_IntersectionContainers[0].StartingIntersection;
        else if (this.m_IntersectionContainers[0].ProfileUsage == ProfileUsage.LeftOnly)
        {
          flag3 = this.m_IntersectionContainers[0].StartingIntersection;
          if (this.m_IntersectionContainers.Count > 1 && this.m_IntersectionContainers[1].ProfileUsage == ProfileUsage.RightOnly)
            flag4 = this.m_IntersectionContainers[1].StartingIntersection;
        }
        else if (this.m_IntersectionContainers[0].ProfileUsage == ProfileUsage.RightOnly)
        {
          flag4 = this.m_IntersectionContainers[0].StartingIntersection;
          if (this.m_IntersectionContainers.Count > 1 && this.m_IntersectionContainers[1].ProfileUsage == ProfileUsage.LeftOnly)
            flag3 = this.m_IntersectionContainers[1].StartingIntersection;
        }
      }
      for (Eps_Leg _Leg = this.m_MassLeg; _Leg != null; _Leg = _Leg.Next)
      {
        if (_nProcessLegSegment > -1)
        {
          if (_nDocIndex <= _nProcessLegSegment)
          {
            if (_nDocIndex < _nProcessLegSegment)
            {
              ++_nDocIndex;
              continue;
            }
          }
          else
            break;
        }
        if (_nDocIndex == 0 || _nDocIndex == _nProcessLegSegment || flag2)
        {
          curveLoopList1 = new List<CurveLoop>();
          if (_nDocIndex == 0 || _nDocIndex == _nProcessLegSegment || flag3)
            curveLoopList2 = new List<CurveLoop>();
          if (_nDocIndex == 0 || _nDocIndex == _nProcessLegSegment || flag4)
            curveLoopList3 = new List<CurveLoop>();
        }
        double num3 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
        if (_Leg.Arc != null)
        {
          Arc arc = _Leg.Arc.RevitArc(this.m_MassDocument);
          double _dStation3 = 0.0;
          double _dOffset2 = 0.0;
          int num4 = 0;
          List<XYZ> list = ((Curve) arc).Tessellate().ToList<XYZ>();
          int count = list.Count;
          foreach (XYZ _XYZPoint in list)
          {
            Eps_Point _Point = new Eps_Point(_XYZPoint);
            if (num4 % 5 != 0 && num4 != 1 && num4 != count - 1)
            {
              ++num4;
            }
            else
            {
              EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation3, ref _dOffset2);
              if (_nDocIndex > 0 && num4 == 0)
                _dStation3 += dOffsetAdjust;
              if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null && num4 == count - 1)
                _dStation3 -= dOffsetAdjust;
              CurveLoop profileAtStation;
              if (num4 == count - 1 && _Leg.Next != null && _Leg.Next.Line != null)
              {
                EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Arc, ref _dX);
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                int ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Next.Line.EndPnt);
                if (!RevitDefines.EQ(_dX, num2))
                {
                  double num5 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                  double SweepAngle = 0.0;
                  RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                  num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                  if (!RevitDefines.EQ(_dX, num1))
                  {
                    flag1 = true;
                    _dAdjustDistance = Math.Abs(Math.Cos(num5 / 2.0));
                    profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation3, true, num1, _dAdjustDistance, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
                  }
                  else
                    profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation3, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
                }
                else
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation3, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
              }
              else if (flag1)
              {
                profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
                flag1 = false;
              }
              else
                profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation3, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
              if (profileAtStation != null)
              {
                curveLoopList1.Add(profileAtStation);
                curveLoop1 = (CurveLoop) null;
              }
              if (_LeftCurbCurveLoop != null)
              {
                curveLoopList2.Add(_LeftCurbCurveLoop);
                _LeftCurbCurveLoop = (CurveLoop) null;
              }
              if (_RightCurbCurveLoop != null)
              {
                curveLoopList3.Add(_RightCurbCurveLoop);
                _RightCurbCurveLoop = (CurveLoop) null;
              }
              ++num4;
            }
          }
          _dStation1 += num3;
        }
        else
        {
          if (flag2)
          {
            CurveLoop profileAtStation;
            if (_nDocIndex == 0)
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
            else if (flag1)
            {
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
              flag1 = false;
            }
            else
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
            if (profileAtStation != null)
            {
              curveLoopList1.Add(profileAtStation);
              curveLoop1 = (CurveLoop) null;
            }
            if (flag3 && _LeftCurbCurveLoop != null)
            {
              curveLoopList2.Add(_LeftCurbCurveLoop);
              _LeftCurbCurveLoop = (CurveLoop) null;
            }
            if (flag4 && _RightCurbCurveLoop != null)
            {
              curveLoopList3.Add(_RightCurbCurveLoop);
              _RightCurbCurveLoop = (CurveLoop) null;
            }
          }
          if (this.m_IntersectionContainers != null)
          {
            while (index1 < this.m_IntersectionContainers.Count && index2 < this.m_IntersectionContainers[index1].Profiles.Count && this.m_IntersectionContainers[index1].Profiles[index2].Station <= _dStation1 + num3)
            {
              if (this.m_IntersectionContainers[index1].Profiles[index2].Station >= _dStation1)
              {
                if (this.m_IntersectionContainers[index1].ProfileUsage == ProfileUsage.EntireProfile)
                {
                  if (flag2 && this.m_IntersectionContainers[index1].StartingIntersection && index2 == 0 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 6)
                  {
                    Eps_Point point1 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                    Eps_Point point2 = this.m_IntersectionContainers[index1].Profiles[index2].Points[4];
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
                    _dX = EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI / 2.0);
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point2, point1, ref num2);
                    CurveLoop profileAtStation;
                    if (!RevitDefines.EQ(_dX, num2))
                    {
                      _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                      profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust, true, num2, _dAdjustDistance);
                    }
                    else
                      profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust);
                    if (profileAtStation != null)
                    {
                      curveLoopList1.Add(profileAtStation);
                      curveLoop1 = (CurveLoop) null;
                    }
                    if (curveLoopList1 != null && curveLoopList1.Count > 0)
                    {
                      curveLoopArrayArray.Add(curveLoopList1);
                      curveLoopList1 = new List<CurveLoop>();
                    }
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point1, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                    {
                      Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                      _LeftCurbCurveLoop = this.FindCurbCurveLoopProfileAtStation(true, _dStation2 - dOffsetAdjust, point1.z - Pnt.z);
                      if (_LeftCurbCurveLoop != null)
                      {
                        curveLoopList2.Add(_LeftCurbCurveLoop);
                        _LeftCurbCurveLoop = (CurveLoop) null;
                      }
                      if (curveLoopList2 != null)
                      {
                        _LeftCurbArrayArrayList.Add(curveLoopList2);
                        curveLoopList2 = new List<CurveLoop>();
                      }
                    }
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point2, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                    {
                      Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                      _RightCurbCurveLoop = this.FindCurbCurveLoopProfileAtStation(false, _dStation2 - dOffsetAdjust, point2.z - Pnt.z);
                      if (_RightCurbCurveLoop != null)
                      {
                        curveLoopList3.Add(_RightCurbCurveLoop);
                        _RightCurbCurveLoop = (CurveLoop) null;
                      }
                      if (curveLoopList3 != null)
                      {
                        _RightCurbArrayArrayList.Add(curveLoopList3);
                        curveLoopList3 = new List<CurveLoop>();
                      }
                    }
                  }
                  CurveLoop curveLoop2 = this.ApplyCurveLoopProfile(this.m_IntersectionContainers[index1].Profiles[index2].Points);
                  if (curveLoop2 != null)
                  {
                    curveLoopList1.Add(curveLoop2);
                    curveLoop1 = (CurveLoop) null;
                  }
                  if (this.m_IntersectionContainers[index1].StartingIntersection)
                  {
                    if (index2 == 0)
                    {
                      flag2 = false;
                      curveLoopList2.Clear();
                      List<List<CurveLoop>> curbCurveLoopArray1 = this.GetCurbCurveLoopArray(true, this.m_IntersectionContainers[index1].LeftOffsetLeg);
                      if (curbCurveLoopArray1 != null && curbCurveLoopArray1.Count > 0)
                        _LeftCurbArrayArrayList.AddRange((IEnumerable<List<CurveLoop>>) curbCurveLoopArray1);
                      curveLoopList3.Clear();
                      List<List<CurveLoop>> curbCurveLoopArray2 = this.GetCurbCurveLoopArray(false, this.m_IntersectionContainers[index1].RightOffsetLeg);
                      if (curbCurveLoopArray2 != null && curbCurveLoopArray2.Count > 0)
                        _RightCurbArrayArrayList.AddRange((IEnumerable<List<CurveLoop>>) curbCurveLoopArray2);
                    }
                    else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1 && curveLoopList1 != null && curveLoopList1.Count > 0)
                    {
                      curveLoopArrayArray.Add(curveLoopList1);
                      curveLoopList1 = new List<CurveLoop>();
                    }
                  }
                  else if (index2 == 0)
                  {
                    List<List<CurveLoop>> curbCurveLoopArray3 = this.GetCurbCurveLoopArray(true, this.m_IntersectionContainers[index1].LeftOffsetLeg);
                    if (curbCurveLoopArray3 != null && curbCurveLoopArray3.Count > 0)
                      _LeftCurbArrayArrayList.AddRange((IEnumerable<List<CurveLoop>>) curbCurveLoopArray3);
                    List<List<CurveLoop>> curbCurveLoopArray4 = this.GetCurbCurveLoopArray(false, this.m_IntersectionContainers[index1].RightOffsetLeg);
                    if (curbCurveLoopArray4 != null && curbCurveLoopArray4.Count > 0)
                      _RightCurbArrayArrayList.AddRange((IEnumerable<List<CurveLoop>>) curbCurveLoopArray4);
                  }
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                  {
                    flag2 = true;
                    if (curveLoopList1 != null && curveLoopList1.Count > 0)
                    {
                      curveLoopArrayArray.Add(curveLoopList1);
                      curveLoopList1 = new List<CurveLoop>();
                    }
                    if (this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust < _dStation1 + num3 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 6)
                    {
                      Eps_Point point3 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                      Eps_Point point4 = this.m_IntersectionContainers[index1].Profiles[index2].Points[4];
                      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.EndPnt, _Leg.Line.StartPnt, ref _dX);
                      _dX = EPShared.eplGeoE_NormalizeRadians(_dX - Math.PI / 2.0);
                      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point4, point3, ref num2);
                      CurveLoop profileAtStation;
                      if (!RevitDefines.EQ(_dX, num2))
                      {
                        _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                        profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust, true, num2, _dAdjustDistance);
                      }
                      else
                        profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust);
                      if (profileAtStation != null)
                      {
                        curveLoopList1.Add(profileAtStation);
                        curveLoop1 = (CurveLoop) null;
                      }
                      if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point3, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                      {
                        Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                        _LeftCurbCurveLoop = this.FindCurbCurveLoopProfileAtStation(true, _dStation2 + dOffsetAdjust, point3.z - Pnt.z);
                        if (_LeftCurbCurveLoop != null)
                        {
                          curveLoopList2.Add(_LeftCurbCurveLoop);
                          _LeftCurbCurveLoop = (CurveLoop) null;
                        }
                      }
                      if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(point4, this.m_MassLeg, ref _dStation2, ref _dOffset1) == 1700 && _dStation2 > 0.0 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation2 - dOffsetAdjust, _dOffset1, ref Pnt) == 0)
                      {
                        Pnt.z -= this.m_dWidth / 2.0 * this.m_dSlope;
                        _RightCurbCurveLoop = this.FindCurbCurveLoopProfileAtStation(false, _dStation2 + dOffsetAdjust, point4.z - Pnt.z);
                        if (_RightCurbCurveLoop != null)
                        {
                          curveLoopList3.Add(_RightCurbCurveLoop);
                          _RightCurbCurveLoop = (CurveLoop) null;
                        }
                      }
                    }
                  }
                }
                else if (this.m_IntersectionContainers[index1].ProfileUsage == ProfileUsage.LeftOnly)
                {
                  _LeftCurbCurveLoop = this.FindCurbCurveLoopProfileAtStation(true, this.m_IntersectionContainers[index1].Profiles[index2].Station);
                  if (_LeftCurbCurveLoop != null)
                  {
                    curveLoopList2.Add(_LeftCurbCurveLoop);
                    _LeftCurbCurveLoop = (CurveLoop) null;
                  }
                  if (this.m_IntersectionContainers[index1].StartingIntersection)
                  {
                    if (index2 == 0)
                    {
                      flag3 = false;
                      if (curveLoopList2 != null && curveLoopList2.Count > 0)
                      {
                        _LeftCurbArrayArrayList.Add(curveLoopList2);
                        curveLoopList2 = new List<CurveLoop>();
                      }
                    }
                  }
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                    flag3 = true;
                }
                else if (this.m_IntersectionContainers[index1].ProfileUsage == ProfileUsage.RightOnly)
                {
                  _RightCurbCurveLoop = this.FindCurbCurveLoopProfileAtStation(false, this.m_IntersectionContainers[index1].Profiles[index2].Station);
                  if (_RightCurbCurveLoop != null)
                  {
                    curveLoopList3.Add(_RightCurbCurveLoop);
                    _RightCurbCurveLoop = (CurveLoop) null;
                  }
                  if (this.m_IntersectionContainers[index1].StartingIntersection)
                  {
                    if (index2 == 0)
                    {
                      flag4 = false;
                      if (curveLoopList3 != null && curveLoopList3.Count > 0)
                      {
                        _RightCurbArrayArrayList.Add(curveLoopList3);
                        curveLoopList3 = new List<CurveLoop>();
                      }
                    }
                  }
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                    flag4 = true;
                }
              }
              ++index2;
              if (index2 >= this.m_IntersectionContainers[index1].Profiles.Count)
              {
                index2 = 0;
                ++index1;
              }
              flag1 = false;
            }
          }
          _dStation1 += num3;
          if (flag2)
          {
            if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null)
              _dStation1 -= dOffsetAdjust;
            CurveLoop profileAtStation;
            if (_Leg.Next != null)
            {
              int ArcDir = 0;
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
              if (_Leg.Next.Line != null)
              {
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Line.EndPnt);
              }
              else if (_Leg.Next.Arc != null)
              {
                EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Next.Arc, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Arc.EndPnt);
              }
              if (!RevitDefines.EQ(_dX, num2))
              {
                double num6 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                double SweepAngle = 0.0;
                RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                if (!RevitDefines.EQ(_dX, num1))
                {
                  flag1 = true;
                  _dAdjustDistance = Math.Abs(Math.Cos(num6 / 2.0));
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, true, num1, _dAdjustDistance, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
                }
                else
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
              }
              else
                profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
            }
            else
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
            if (profileAtStation != null)
            {
              curveLoopList1.Add(profileAtStation);
              curveLoop1 = (CurveLoop) null;
            }
            if (flag3 && _LeftCurbCurveLoop != null)
            {
              curveLoopList2.Add(_LeftCurbCurveLoop);
              _LeftCurbCurveLoop = (CurveLoop) null;
            }
            if (flag4 && _RightCurbCurveLoop != null)
            {
              curveLoopList3.Add(_RightCurbCurveLoop);
              _RightCurbCurveLoop = (CurveLoop) null;
            }
          }
        }
        if (flag2 && curveLoopList1 != null && curveLoopList1.Count > 0)
        {
          curveLoopArrayArray.Add(curveLoopList1);
          if (flag3 && curveLoopList2 != null && curveLoopList2.Count > 0)
            _LeftCurbArrayArrayList.Add(curveLoopList2);
          if (flag4 && curveLoopList3 != null && curveLoopList3.Count > 0)
            _RightCurbArrayArrayList.Add(curveLoopList3);
        }
        ++_nDocIndex;
      }
    }
    return curveLoopArrayArray;
  }

  private List<ReferenceArrayArray> GetCurbReferenceArrayArray(
    bool _bIsLeftCurb,
    Eps_Leg _OffsetLeg)
  {
    List<ReferenceArrayArray> referenceArrayArray = new List<ReferenceArrayArray>();
    if (_OffsetLeg != null)
    {
      if (_bIsLeftCurb)
      {
        if (this.m_LeftCurbForm != null)
        {
          this.m_LeftCurbForm.MassLeg = _OffsetLeg;
          this.m_LeftCurbForm.MassDocument = this.m_AdditionalMassDocument;
          referenceArrayArray = this.m_LeftCurbForm.GetReferenceArrayArray(0.0, 0.0);
        }
      }
      else if (this.m_RightCurbForm != null)
      {
        this.m_RightCurbForm.MassLeg = _OffsetLeg;
        this.m_RightCurbForm.MassDocument = this.m_AdditionalMassDocument;
        referenceArrayArray = this.m_RightCurbForm.GetReferenceArrayArray(0.0, 0.0);
      }
    }
    return referenceArrayArray;
  }

  private List<List<CurveLoop>> GetCurbCurveLoopArray(bool _bIsLeftCurb, Eps_Leg _OffsetLeg)
  {
    List<List<CurveLoop>> curbCurveLoopArray = (List<List<CurveLoop>>) null;
    if (_OffsetLeg != null)
    {
      if (_bIsLeftCurb)
      {
        if (this.m_LeftCurbForm != null)
        {
          this.m_LeftCurbForm.MassLeg = _OffsetLeg;
          this.m_LeftCurbForm.MassDocument = this.m_AdditionalMassDocument;
          curbCurveLoopArray = this.m_LeftCurbForm.GetCurveLoopArray(0.0, 0.0);
        }
      }
      else if (this.m_RightCurbForm != null)
      {
        this.m_RightCurbForm.MassLeg = _OffsetLeg;
        this.m_RightCurbForm.MassDocument = this.m_AdditionalMassDocument;
        curbCurveLoopArray = this.m_RightCurbForm.GetCurveLoopArray(0.0, 0.0);
      }
    }
    return curbCurveLoopArray;
  }

  private ReferenceArray FindCurbReferenceArrayProfileAtStation(bool _bIsLeftCurb, double _dStation)
  {
    return this.FindCurbReferenceArrayProfileAtStation(_bIsLeftCurb, _dStation, 0.0);
  }

  private CurveLoop FindCurbCurveLoopProfileAtStation(bool _bIsLeftCurb, double _dStation)
  {
    return this.FindCurbCurveLoopProfileAtStation(_bIsLeftCurb, _dStation, 0.0);
  }

  private ReferenceArray FindCurbReferenceArrayProfileAtStation(
    bool _bIsLeftCurb,
    double _dStation,
    double _dAdjustElevation)
  {
    ReferenceArray profileAtStation = new ReferenceArray();
    double dOffsetAdjust = this.m_dOffsetAdjust;
    if (_bIsLeftCurb)
    {
      if (this.m_LeftCurbForm != null)
      {
        Eps_Leg ppOffsetLegList = new Eps_Leg();
        RevitGeometry.OffsetLegList(this.m_MassLeg, (this.m_dWidth + dOffsetAdjust) / 2.0, 2, ref ppOffsetLegList, true);
        this.m_LeftCurbForm.MassLeg = ppOffsetLegList;
        this.m_LeftCurbForm.MassDocument = this.m_AdditionalMassDocument;
        profileAtStation = this.m_LeftCurbForm.FindReferenceArrayProfileAtStation(0, _dStation, 0.0, -(this.m_dWidth / 2.0 * this.m_dSlope) + _dAdjustElevation, false, 0.0, 1.0);
      }
    }
    else if (this.m_RightCurbForm != null)
    {
      Eps_Leg ppOffsetLegList = new Eps_Leg();
      RevitGeometry.OffsetLegList(this.m_MassLeg, (this.m_dWidth + dOffsetAdjust) / 2.0, 1, ref ppOffsetLegList, true);
      this.m_RightCurbForm.MassLeg = ppOffsetLegList;
      this.m_RightCurbForm.MassDocument = this.m_AdditionalMassDocument;
      profileAtStation = this.m_RightCurbForm.FindReferenceArrayProfileAtStation(0, _dStation, 0.0, -(this.m_dWidth / 2.0 * this.m_dSlope) + _dAdjustElevation, false, 0.0, 1.0);
    }
    return profileAtStation;
  }

  private CurveLoop FindCurbCurveLoopProfileAtStation(
    bool _bIsLeftCurb,
    double _dStation,
    double _dAdjustElevation)
  {
    CurveLoop profileAtStation = (CurveLoop) null;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    if (_bIsLeftCurb)
    {
      if (this.m_LeftCurbForm != null)
      {
        Eps_Leg ppOffsetLegList = new Eps_Leg();
        RevitGeometry.OffsetLegList(this.m_MassLeg, (this.m_dWidth + dOffsetAdjust) / 2.0, 2, ref ppOffsetLegList, true);
        this.m_LeftCurbForm.MassLeg = ppOffsetLegList;
        this.m_LeftCurbForm.MassDocument = this.m_AdditionalMassDocument;
        profileAtStation = this.m_LeftCurbForm.FindCurveLoopProfileAtStation(0, _dStation, 0.0, -(this.m_dWidth / 2.0 * this.m_dSlope) + _dAdjustElevation, false, 0.0, 1.0);
      }
    }
    else if (this.m_RightCurbForm != null)
    {
      Eps_Leg ppOffsetLegList = new Eps_Leg();
      RevitGeometry.OffsetLegList(this.m_MassLeg, (this.m_dWidth + dOffsetAdjust) / 2.0, 1, ref ppOffsetLegList, true);
      this.m_RightCurbForm.MassLeg = ppOffsetLegList;
      this.m_RightCurbForm.MassDocument = this.m_AdditionalMassDocument;
      profileAtStation = this.m_RightCurbForm.FindCurveLoopProfileAtStation(0, _dStation, 0.0, -(this.m_dWidth / 2.0 * this.m_dSlope) + _dAdjustElevation, false, 0.0, 1.0);
    }
    return profileAtStation;
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    ref CurveLoop _LeftCurbCurveLoop,
    ref CurveLoop _RightCurbCurveLoop)
  {
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, false, 0.0, 1.0, true, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
  }

  private CurveLoop FindCurveLoopProfileAtStation(int _nDocIndex, double _dStation)
  {
    CurveLoop _LeftCurbCurveLoop = (CurveLoop) null;
    CurveLoop _RightCurbCurveLoop = (CurveLoop) null;
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, false, 0.0, 1.0, false, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    CurveLoop _LeftCurbCurveLoop = (CurveLoop) null;
    CurveLoop _RightCurbCurveLoop = (CurveLoop) null;
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, _bUseDirection, _dDirection, _dAdjustDistance, false, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance,
    ref CurveLoop _LeftCurbCurveLoop,
    ref CurveLoop _RightCurbCurveLoop)
  {
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, _bUseDirection, _dDirection, _dAdjustDistance, true, ref _LeftCurbCurveLoop, ref _RightCurbCurveLoop);
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance,
    bool _bGetCurbReferenceArrayProfile,
    ref CurveLoop _LeftCurbCurveLoop,
    ref CurveLoop _RightCurbCurveLoop)
  {
    double dOffsetAdjust = this.m_dOffsetAdjust;
    CurveLoop profileAtStation = new CurveLoop();
    CurveArray curveArray = new CurveArray();
    try
    {
      Eps_Point epsPoint1 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.LeftEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint2 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.RightEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint3 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.CrownEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint4 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.SubgradeCrownEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint5 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.LeftSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint6 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.RightSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, epsPoint5, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint1.XYZ, epsPoint5.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint5, epsPoint4, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint5.XYZ, epsPoint4.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint4, epsPoint6, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint4.XYZ, epsPoint6.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint6, epsPoint2, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint6.XYZ, epsPoint2.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint2, epsPoint3, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint2.XYZ, epsPoint3.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint3, epsPoint1, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint3.XYZ, epsPoint1.XYZ, true);
        curveArray.Append((Curve) line);
      }
      foreach (Curve curve in curveArray)
        profileAtStation.Append(curve);
      if (_bGetCurbReferenceArrayProfile)
      {
        if (this.m_LeftCurbForm != null)
        {
          this.m_LeftCurbForm.MassLeg = this.m_MassLeg;
          this.m_LeftCurbForm.MassDocument = this.m_AdditionalMassDocument;
          _LeftCurbCurveLoop = this.m_LeftCurbForm.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, -(this.m_dWidth + dOffsetAdjust) / 2.0, -(this.m_dWidth / 2.0 * this.m_dSlope), _bUseDirection, _dDirection, _dAdjustDistance);
        }
        if (this.m_RightCurbForm != null)
        {
          this.m_RightCurbForm.MassLeg = this.m_MassLeg;
          this.m_RightCurbForm.MassDocument = this.m_AdditionalMassDocument;
          _RightCurbCurveLoop = this.m_RightCurbForm.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, (this.m_dWidth + dOffsetAdjust) / 2.0, -(this.m_dWidth / 2.0 * this.m_dSlope), _bUseDirection, _dDirection, _dAdjustDistance);
        }
      }
    }
    catch (Exception ex)
    {
    }
    return profileAtStation;
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    ref ReferenceArray _LeftCurbReferenceArray,
    ref ReferenceArray _RightCurbReferenceArray)
  {
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, false, 0.0, 1.0, true, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(int _nDocIndex, double _dStation)
  {
    ReferenceArray _LeftCurbReferenceArray = (ReferenceArray) null;
    ReferenceArray _RightCurbReferenceArray = (ReferenceArray) null;
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, false, 0.0, 1.0, false, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    ReferenceArray _LeftCurbReferenceArray = (ReferenceArray) null;
    ReferenceArray _RightCurbReferenceArray = (ReferenceArray) null;
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, _bUseDirection, _dDirection, _dAdjustDistance, false, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance,
    ref ReferenceArray _LeftCurbReferenceArray,
    ref ReferenceArray _RightCurbReferenceArray)
  {
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, _bUseDirection, _dDirection, _dAdjustDistance, true, ref _LeftCurbReferenceArray, ref _RightCurbReferenceArray);
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance,
    bool _bGetCurbReferenceArrayProfile,
    ref ReferenceArray _LeftCurbReferenceArray,
    ref ReferenceArray _RightCurbReferenceArray)
  {
    double dOffsetAdjust = this.m_dOffsetAdjust;
    ReferenceArray profileAtStation = new ReferenceArray();
    CurveArray curveArray = new CurveArray();
    try
    {
      Eps_Point epsPoint1 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.LeftEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint2 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.RightEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint3 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.CrownEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint4 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.SubgradeCrownEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint5 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.LeftSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint6 = this.CalcTemplateOffsets(StreetForm.StreetOffsetPoint.RightSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, epsPoint5, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint1.XYZ, epsPoint5.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint5, epsPoint4, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint5.XYZ, epsPoint4.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint4, epsPoint6, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint4.XYZ, epsPoint6.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint6, epsPoint2, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint6.XYZ, epsPoint2.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint2, epsPoint3, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint2.XYZ, epsPoint3.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint3, epsPoint1, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint3.XYZ, epsPoint1.XYZ, true);
        curveArray.Append((Curve) line);
      }
      CurveLoop curveLoop = new CurveLoop();
      foreach (Curve curve in curveArray)
        curveLoop.Append(curve);
      SketchPlane sketchPlane = SketchPlane.Create(this.m_MassDocument, curveLoop.GetPlane());
      foreach (Curve curve in curveArray)
      {
        ModelCurve modelCurve = ((ItemFactoryBase) this.m_MassDocument.FamilyCreate).NewModelCurve(curve, sketchPlane);
        profileAtStation.Append(((CurveElement) modelCurve).GeometryCurve.Reference);
      }
      if (_bGetCurbReferenceArrayProfile)
      {
        if (this.m_LeftCurbForm != null)
        {
          this.m_LeftCurbForm.MassLeg = this.m_MassLeg;
          this.m_LeftCurbForm.MassDocument = this.m_AdditionalMassDocument;
          _LeftCurbReferenceArray = this.m_LeftCurbForm.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, -(this.m_dWidth + dOffsetAdjust) / 2.0, -(this.m_dWidth / 2.0 * this.m_dSlope), _bUseDirection, _dDirection, _dAdjustDistance);
        }
        if (this.m_RightCurbForm != null)
        {
          this.m_RightCurbForm.MassLeg = this.m_MassLeg;
          this.m_RightCurbForm.MassDocument = this.m_AdditionalMassDocument;
          _RightCurbReferenceArray = this.m_RightCurbForm.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, (this.m_dWidth + dOffsetAdjust) / 2.0, -(this.m_dWidth / 2.0 * this.m_dSlope), _bUseDirection, _dDirection, _dAdjustDistance);
        }
      }
    }
    catch (Exception ex)
    {
    }
    return profileAtStation;
  }

  private Eps_Point CalcTemplateOffsets(
    StreetForm.StreetOffsetPoint _StreetOffsetPoint,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    Eps_Point epsPoint = new Eps_Point();
    double num1 = this.m_dWidth / _dAdjustDistance;
    double num2 = 0.0;
    double num3 = 0.0;
    switch (_StreetOffsetPoint)
    {
      case StreetForm.StreetOffsetPoint.LeftEdge:
        num2 = -num1 / 2.0;
        num3 = -(this.m_dWidth / 2.0 * this.m_dSlope);
        break;
      case StreetForm.StreetOffsetPoint.LeftSubgradeEdge:
        num2 = -num1 / 2.0;
        num3 = -(this.m_dSubgradeDepth + this.m_dWidth / 2.0 * this.m_dSlope);
        break;
      case StreetForm.StreetOffsetPoint.CrownEdge:
        num2 = 0.0;
        num3 = 0.0;
        break;
      case StreetForm.StreetOffsetPoint.SubgradeCrownEdge:
        num2 = 0.0;
        num3 = -this.m_dSubgradeDepth;
        break;
      case StreetForm.StreetOffsetPoint.RightEdge:
        num2 = num1 / 2.0;
        num3 = -(this.m_dWidth / 2.0 * this.m_dSlope);
        break;
      case StreetForm.StreetOffsetPoint.RightSubgradeEdge:
        num2 = num1 / 2.0;
        num3 = -(this.m_dSubgradeDepth + this.m_dWidth / 2.0 * this.m_dSlope);
        break;
    }
    if (!_bUseDirection)
    {
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation, num2, ref epsPoint);
    }
    else
    {
      Eps_Point Pnt = new Eps_Point();
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation, 0.0, ref Pnt);
      if (num2 < 0.0)
      {
        num2 = Math.Abs(num2);
        _dDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI);
      }
      EPShared.eplGeoE_CalcPolarToXY(Pnt, _dDirection, num2, ref epsPoint);
    }
    epsPoint.z += num3;
    return epsPoint;
  }

  public FamilySymbol StreetFamilySymbol => this.m_StreetFamilySymbol;

  private enum StreetOffsetPoint
  {
    LeftEdge,
    LeftSubgradeEdge,
    CrownEdge,
    SubgradeCrownEdge,
    RightEdge,
    RightSubgradeEdge,
  }
}
