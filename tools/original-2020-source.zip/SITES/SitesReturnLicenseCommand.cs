﻿// Decompiled with JetBrains decompiler
// Type: SITES.SitesReturnLicenseCommand
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using EPCommon;
using System;
using System.Windows.Forms;

#nullable disable
namespace SITES;

[Transaction]
[Regeneration]
[Journaling]
public class SitesReturnLicenseCommand : IExternalCommand
{
  public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
  {
    Result result = (Result) 0;
    try
    {
      if (!EPShared.eplLicM_IsNodeLicense())
      {
        if (EPShared.eplLicM_ReturnBorrowedLicense())
        {
          int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("LicenseReturnedToNetworkMessage"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
        }
        else
        {
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SiteworksNetworkLicenseBorrowError"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
        }
      }
      else
      {
        int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SiteworksNetworkLicenseError"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
      }
    }
    catch (Exception ex)
    {
      int num = (int) RevitMessageBox.Show(ex.Message, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    return result;
  }
}
