﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LocateSiteParkingLotComponentForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LocateSiteParkingLotComponentForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private SiteComponentCreation m_dataBuffer;
  private FamilySymbol m_CurType;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_LoadFamilyButton;
  private ComboBox m_TypeNameComboBox;
  private Label m_TypeNameLabel;
  private ComboBox m_FamilyComboBox;
  private Label m_FamilyLabel;
  private Panel m_MoveablePanel;
  private Button m_CloseButton;
  private Button m_InsertButton;
  private Label m_RadiusLabel;
  private TextBox m_RadiusTextBox;
  private Label m_NameLabel;
  private TextBox m_NameTextBox;
  private Panel m_HostLineSelectionPanel;
  private RadioButton m_UseExistingHostLineRadioButton;
  private RadioButton m_DrawHostLineRadioButton;
  private CheckBox m_CreateCopyCheckBox;

  public LocateSiteParkingLotComponentForm(SiteComponentCreation dataBuffer)
  {
    this.InitializeComponent();
    this.SetStrings();
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.ContextualHelpID = "HID_SDparkinglotCreate";
    this.m_dataBuffer = dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
  }

  private void SetStrings()
  {
    this.Text = EPShared.LocalRM.GetString("LocateParkingLotDialog");
    this.m_FamilyLabel.Text = EPShared.LocalRM.GetString("AMP_ParkingLotFamilyDialog");
    this.m_TypeNameLabel.Text = EPShared.LocalRM.GetString("Par_AMP_kingLotTypeDialog");
    this.m_NameLabel.Text = EPShared.LocalRM.GetString("Parki_AMP_ngLotNameDialog");
    this.m_CreateCopyCheckBox.Text = EPShared.LocalRM.GetString("Create_AMP_ACopyDialog");
    this.m_UseExistingHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_UseExistingHostLineDialog");
    this.m_DrawHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_DrawHostLineDialog");
    this.m_RadiusLabel.Text = EPShared.LocalRM.GetString("AMP_RadiusDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
  }

  private void InitializeControls()
  {
    int num = 0;
    double _dReturnValue = 0.0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_UseExistingHostLineRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateParkingLotHostLineSelectionOption", ref num))
    {
      if (num == 0)
        this.m_UseExistingHostLineRadioButton.Checked = true;
      else
        this.m_DrawHostLineRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateParkingLotRadius", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
    this.m_RadiusTextBox.Text = empty;
    this.m_CreateCopyCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateParkingLotCreateVisibleCopy", ref num))
      this.m_CreateCopyCheckBox.Checked = Convert.ToBoolean(num);
    this.m_FamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
    this.m_FamilyComboBox.DisplayMember = ApplicationUtility.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateParkingLotFamilyName", ref empty))
    {
      for (int index = 0; index < this.m_FamilyComboBox.Items.Count; ++index)
      {
        if (this.m_FamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty, true) == 0)
        {
          this.m_FamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateParkingLotTypeName", ref empty))
    {
      for (int index = 0; index < this.m_TypeNameComboBox.Items.Count; ++index)
      {
        if (this.m_TypeNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty, true) == 0)
        {
          this.m_TypeNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    string _strReturnValue = string.Empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateParkingLotName", ref _strReturnValue) && this.m_FamilyComboBox.SelectedItem is FamilyContainer selectedItem && selectedItem.FamilyName != string.Empty)
      _strReturnValue = selectedItem.FamilyName;
    if (this.m_dataBuffer.FindPlacementStartingNumberName(_strReturnValue, ref num))
      this.m_NameTextBox.Text = _strReturnValue + this.m_dataBuffer.NUMMERIC_SEPERATOR + Convert.ToString(num);
    else
      this.m_NameTextBox.Text = _strReturnValue;
  }

  private void SaveSettings()
  {
    this.m_CurType = this.m_TypeNameComboBox.SelectedItem as FamilySymbol;
    double _dReturnedDouble = 0.0;
    ApplicationUtility.Settings.eplSetE_SetSetting("LocateParkingLotHostLineSelectionOption", !this.m_UseExistingHostLineRadioButton.Checked ? 1 : 0);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateParkingLotRadius", _dReturnedDouble);
    if (this.m_FamilyComboBox.SelectedItem is FamilyContainer selectedItem)
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateParkingLotFamilyName", selectedItem.FamilyName);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateParkingLotTypeName", ((Element) this.m_CurType).Name);
    ApplicationUtility.Settings.eplSetE_SetSetting("LocateParkingLotCreateVisibleCopy", Convert.ToInt32(this.m_CreateCopyCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateParkingLotName", this.m_dataBuffer.GetSitePlacementNameWithoutSeperator(this.m_NameTextBox.Text));
  }

  private void OnFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_FamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_TypeNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_TypeNameComboBox.DisplayMember = ApplicationUtility.GetString("NameString");
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_FamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectParkingLotFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag1 = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingLotFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag1 = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            string _strFindName = string.Empty;
            if (_Family != null)
            {
              this.m_dataBuffer.TransactionContainer.Commit();
              _strFindName = ((Element) _Family).Name;
            }
            else
            {
              this.m_dataBuffer.TransactionContainer.Rollback();
              bool flag2 = false;
              int num = 0;
              foreach (FamilyContainer family in this.m_dataBuffer.FamilyList)
              {
                Document document = this.m_dataBuffer.Document.EditFamily(family.FamilySymbolList[0].Family);
                if (document != null && string.Compare(document.PathName, openFileDialog.FileName, true) == 0)
                {
                  _strFindName = family.FamilyName;
                  flag2 = true;
                  break;
                }
                ++num;
              }
              if (flag2)
                this.m_FamilyComboBox.SelectedIndex = num;
            }
            int nBeginningIndex = 0;
            if (this.m_dataBuffer.FindPlacementStartingNumberName(_strFindName, ref nBeginningIndex))
            {
              this.m_NameTextBox.Text = _strFindName + this.m_dataBuffer.NUMMERIC_SEPERATOR + Convert.ToString(nBeginningIndex);
              break;
            }
            this.m_NameTextBox.Text = _strFindName;
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag1 = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSelectionMadeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag1)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSelectionMadeMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_FamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
        this.m_FamilyComboBox.DisplayMember = ApplicationUtility.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_FamilyComboBox.Items.Count; ++index)
          {
            if (this.m_FamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_FamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_FamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSelectionMadeMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCloseButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnHostLineSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_RadiusLabel.Enabled = this.m_DrawHostLineRadioButton.Checked;
    this.m_RadiusTextBox.Enabled = this.m_DrawHostLineRadioButton.Checked;
  }

  private bool ValidateFields()
  {
    if (this.m_TypeNameComboBox.SelectedItem == null)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (string.IsNullOrEmpty(this.m_NameTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("Specify_Message") + EPShared.LocalRM.GetString("ParkingLotString") + EPShared.LocalRM.GetString("NameString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_NameTextBox.Focus();
      return false;
    }
    if (this.m_NameTextBox.Text.StartsWith(" ") || this.m_NameTextBox.Text.EndsWith(" "))
    {
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("ParkingLotString")} {EPShared.LocalRM.GetString("NameString")}{EPShared.LocalRM.GetString("_LeadingAndTrailingSpacesMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_NameTextBox.Focus();
      return false;
    }
    if (!this.m_dataBuffer.FindPlacementName(this.m_NameTextBox.Text))
      return true;
    int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("MassingFamilyNameAlreadyUsedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    this.m_NameTextBox.Focus();
    return false;
  }

  private void FormatRadiusValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      if (_dReturnedDouble < 0.0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusValueString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_RadiusTextBox.Text = string.Empty;
      }
      else
      {
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
        this.m_RadiusTextBox.Text = empty;
      }
    }
    else
      this.m_RadiusTextBox.Focus();
  }

  private void OnRadiusKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatRadiusValue();
  }

  private void OnRadiusTextBoxLeave(object sender, EventArgs e) => this.FormatRadiusValue();

  private void OnLocateSiteComponentClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public void ResetSiteComponentName()
  {
    string withoutSeperator = this.m_dataBuffer.GetSitePlacementNameWithoutSeperator(this.m_NameTextBox.Text);
    int nBeginningIndex = 0;
    if (this.m_dataBuffer.FindPlacementStartingNumberName(withoutSeperator, ref nBeginningIndex))
      this.m_NameTextBox.Text = withoutSeperator + this.m_dataBuffer.NUMMERIC_SEPERATOR + Convert.ToString(nBeginningIndex);
    else
      this.m_NameTextBox.Text = withoutSeperator;
  }

  public bool ExistingHostLineChecked => this.m_UseExistingHostLineRadioButton.Checked;

  public double Radius
  {
    get
    {
      if (this.m_UseExistingHostLineRadioButton.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_RadiusTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool CreateCopyChecked => this.m_CreateCopyCheckBox.Checked;

  public FamilySymbol Type => this.m_CurType;

  public string SitePlacementName => this.m_NameTextBox.Text;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_LoadFamilyButton = new Button();
    this.m_TypeNameComboBox = new ComboBox();
    this.m_TypeNameLabel = new Label();
    this.m_FamilyComboBox = new ComboBox();
    this.m_FamilyLabel = new Label();
    this.m_MoveablePanel = new Panel();
    this.m_CloseButton = new Button();
    this.m_InsertButton = new Button();
    this.m_RadiusLabel = new Label();
    this.m_RadiusTextBox = new TextBox();
    this.m_NameLabel = new Label();
    this.m_NameTextBox = new TextBox();
    this.m_HostLineSelectionPanel = new Panel();
    this.m_UseExistingHostLineRadioButton = new RadioButton();
    this.m_DrawHostLineRadioButton = new RadioButton();
    this.m_CreateCopyCheckBox = new CheckBox();
    this.m_MoveablePanel.SuspendLayout();
    this.m_HostLineSelectionPanel.SuspendLayout();
    this.SuspendLayout();
    this.m_LoadFamilyButton.Location = new Point(464, 11);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_TypeNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_TypeNameComboBox.FormattingEnabled = true;
    this.m_TypeNameComboBox.Location = new Point(219, 39);
    this.m_TypeNameComboBox.Name = "m_TypeNameComboBox";
    this.m_TypeNameComboBox.Size = new Size(239, 21);
    this.m_TypeNameComboBox.TabIndex = 4;
    this.m_TypeNameLabel.AutoSize = true;
    this.m_TypeNameLabel.Location = new Point(12, 42);
    this.m_TypeNameLabel.Name = "m_TypeNameLabel";
    this.m_TypeNameLabel.Size = new Size(91, 13);
    this.m_TypeNameLabel.TabIndex = 3;
    this.m_TypeNameLabel.Text = "Parking Lot Type:";
    this.m_FamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_FamilyComboBox.FormattingEnabled = true;
    this.m_FamilyComboBox.Location = new Point(219, 12);
    this.m_FamilyComboBox.Name = "m_FamilyComboBox";
    this.m_FamilyComboBox.Size = new Size(239, 21);
    this.m_FamilyComboBox.TabIndex = 1;
    this.m_FamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnFamilyComboBoxSelectedIndexChanged);
    this.m_FamilyLabel.AutoSize = true;
    this.m_FamilyLabel.Location = new Point(12, 17);
    this.m_FamilyLabel.Name = "m_FamilyLabel";
    this.m_FamilyLabel.Size = new Size(96 /*0x60*/, 13);
    this.m_FamilyLabel.TabIndex = 0;
    this.m_FamilyLabel.Text = "&Parking Lot Family:";
    this.m_MoveablePanel.Controls.Add((Control) this.m_CloseButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Location = new Point(12, 187);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(476, 23);
    this.m_MoveablePanel.TabIndex = 11;
    this.m_CloseButton.DialogResult = DialogResult.Cancel;
    this.m_CloseButton.Location = new Point(400, 0);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 1;
    this.m_CloseButton.Text = "&Cancel";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClick);
    this.m_InsertButton.Location = new Point(319, 0);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 0;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_RadiusLabel.AutoSize = true;
    this.m_RadiusLabel.Enabled = false;
    this.m_RadiusLabel.Location = new Point(30, 164);
    this.m_RadiusLabel.Name = "m_RadiusLabel";
    this.m_RadiusLabel.Size = new Size(43, 13);
    this.m_RadiusLabel.TabIndex = 9;
    this.m_RadiusLabel.Text = "Radius:";
    this.m_RadiusTextBox.Enabled = false;
    this.m_RadiusTextBox.Location = new Point(219, 161);
    this.m_RadiusTextBox.Name = "m_RadiusTextBox";
    this.m_RadiusTextBox.Size = new Size(100, 20);
    this.m_RadiusTextBox.TabIndex = 10;
    this.m_RadiusTextBox.KeyDown += new KeyEventHandler(this.OnRadiusKeyDown);
    this.m_RadiusTextBox.Leave += new EventHandler(this.OnRadiusTextBoxLeave);
    this.m_NameLabel.AutoSize = true;
    this.m_NameLabel.Location = new Point(12, 69);
    this.m_NameLabel.Name = "m_NameLabel";
    this.m_NameLabel.Size = new Size(95, 13);
    this.m_NameLabel.TabIndex = 5;
    this.m_NameLabel.Text = "Parking Lot &Name:";
    this.m_NameTextBox.Location = new Point(219, 66);
    this.m_NameTextBox.Name = "m_NameTextBox";
    this.m_NameTextBox.Size = new Size(239, 20);
    this.m_NameTextBox.TabIndex = 6;
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_UseExistingHostLineRadioButton);
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_DrawHostLineRadioButton);
    this.m_HostLineSelectionPanel.Location = new Point(15, 115);
    this.m_HostLineSelectionPanel.Name = "m_HostLineSelectionPanel";
    this.m_HostLineSelectionPanel.Size = new Size(476, 41);
    this.m_HostLineSelectionPanel.TabIndex = 8;
    this.m_UseExistingHostLineRadioButton.AutoSize = true;
    this.m_UseExistingHostLineRadioButton.Location = new Point(0, 0);
    this.m_UseExistingHostLineRadioButton.Name = "m_UseExistingHostLineRadioButton";
    this.m_UseExistingHostLineRadioButton.Size = new Size(146, 17);
    this.m_UseExistingHostLineRadioButton.TabIndex = 0;
    this.m_UseExistingHostLineRadioButton.Text = "&Use an Existing Host Line";
    this.m_UseExistingHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_UseExistingHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_DrawHostLineRadioButton.AutoSize = true;
    this.m_DrawHostLineRadioButton.Location = new Point(0, 23);
    this.m_DrawHostLineRadioButton.Name = "m_DrawHostLineRadioButton";
    this.m_DrawHostLineRadioButton.Size = new Size(228, 17);
    this.m_DrawHostLineRadioButton.TabIndex = 1;
    this.m_DrawHostLineRadioButton.Text = "&Draw Host Line (Click Escape to Complete)";
    this.m_DrawHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_DrawHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_CreateCopyCheckBox.AutoSize = true;
    this.m_CreateCopyCheckBox.Location = new Point(15, 92);
    this.m_CreateCopyCheckBox.Name = "m_CreateCopyCheckBox";
    this.m_CreateCopyCheckBox.Size = new Size(94, 17);
    this.m_CreateCopyCheckBox.TabIndex = 7;
    this.m_CreateCopyCheckBox.Text = "Create A Copy";
    this.m_CreateCopyCheckBox.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(493, 222);
    this.Controls.Add((Control) this.m_CreateCopyCheckBox);
    this.Controls.Add((Control) this.m_HostLineSelectionPanel);
    this.Controls.Add((Control) this.m_NameLabel);
    this.Controls.Add((Control) this.m_NameTextBox);
    this.Controls.Add((Control) this.m_RadiusLabel);
    this.Controls.Add((Control) this.m_RadiusTextBox);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_TypeNameComboBox);
    this.Controls.Add((Control) this.m_TypeNameLabel);
    this.Controls.Add((Control) this.m_FamilyComboBox);
    this.Controls.Add((Control) this.m_FamilyLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (LocateSiteParkingLotComponentForm);
    this.Text = "Locate Parking Lot";
    this.FormClosing += new FormClosingEventHandler(this.OnLocateSiteComponentClosing);
    this.m_MoveablePanel.ResumeLayout(false);
    this.m_HostLineSelectionPanel.ResumeLayout(false);
    this.m_HostLineSelectionPanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
