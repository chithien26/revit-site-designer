﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ModifySiteComponent
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ModifySiteComponent
{
  private Document m_Document;
  private EPTransactionContainer m_TransactionContainer;
  private TopographySurfaceContainer m_BaseSurface;
  private TopographySurfaceContainer m_ProposedSurface;
  private List<FamilyInstanceComponentWrapper> m_SiteCategoryComponentList;
  private List<FamilyInstanceComponentWrapper> m_AllSiteComponentList;
  private List<FamilyInstanceComponentWrapper> m_ParkingLotCurbSiteCompList;
  private LandcaddID m_CurrentFamilyType;
  private FamilyInstanceComponentWrapper m_FamilyInstanceComponentWrapper;
  private ElementSet m_LineElementSet;
  private ElementSet m_SiteCategoryLineElementSet;
  private ModifySiteComponentForm m_DisplayForm;
  private ModifySiteParkingLotComponentForm m_ParkingLotDisplayForm;
  private ModifySitePointWipeoutComponentForm m_PointWipeoutDisplayForm;
  private bool m_ModifyStatus;
  private FamilyInstance m_TopoPlacementFamilyInstance;
  private ElementSet m_AnnotationElevationTextSet;
  private ElementSet m_AnnotationGradeTextSet;
  private double m_dMarkerHeight;
  private bool m_bHasElevationAnnotation = true;
  private bool m_bHasGradeAnnotation = true;
  private bool m_bDeleteSiteComponent;
  private bool m_bRetainingWallUseRightLeg = true;
  private bool m_bResetLineVisibilityCategory;
  private bool m_bFindIntersectionStations;
  private bool m_bDoesMassLineSubCategoryExist;
  private double m_dArcPointInterval;
  private Category m_MassLineSubCategory;
  private string m_strParentTopoSurfaceID = string.Empty;

  public ModifySiteComponent(Document _CurDocument, LandcaddID _CurrType)
  {
    this.m_Document = _CurDocument;
    this.m_CurrentFamilyType = _CurrType;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_BaseSurface = (TopographySurfaceContainer) null;
    this.m_ProposedSurface = (TopographySurfaceContainer) null;
    this.m_TopoPlacementFamilyInstance = (FamilyInstance) null;
    this.m_SiteCategoryComponentList = new List<FamilyInstanceComponentWrapper>();
    this.m_AllSiteComponentList = new List<FamilyInstanceComponentWrapper>();
    this.m_ParkingLotCurbSiteCompList = (List<FamilyInstanceComponentWrapper>) null;
    this.m_LineElementSet = new ElementSet();
    this.m_SiteCategoryLineElementSet = new ElementSet();
    this.m_DisplayForm = (ModifySiteComponentForm) null;
    this.m_ParkingLotDisplayForm = (ModifySiteParkingLotComponentForm) null;
    this.m_PointWipeoutDisplayForm = (ModifySitePointWipeoutComponentForm) null;
    this.m_ModifyStatus = false;
    this.m_AnnotationElevationTextSet = (ElementSet) null;
    this.m_AnnotationGradeTextSet = (ElementSet) null;
    this.m_dMarkerHeight = 0.0;
    this.m_dArcPointInterval = 0.0;
    this.m_MassLineSubCategory = (Category) null;
    this.InitializeData();
  }

  public void Run()
  {
    int _nReturnValue = 0;
    if ((this.m_CurrentFamilyType == LandcaddID.SoftTerrain || this.m_CurrentFamilyType == LandcaddID.ParkingLot || this.m_CurrentFamilyType == LandcaddID.FeatureLine || this.m_CurrentFamilyType == LandcaddID.PointWipeout) && ApplicationUtility.Settings.eplSetE_GetSetting("MassCreationOnlyMode", ref _nReturnValue) && _nReturnValue != 0)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("MassCreationOnlyModeOnMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    else
    {
      this.m_TransactionContainer.StartTransactionGroup(EPShared.LocalRM.GetString("ModifySiteComponentTransaction"));
      this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ModifySiteComponentTransaction"));
      this.m_TransactionContainer.FailureHandlingOptions(new List<FailureDefinitionId>()
      {
        BuiltInFailures.InaccurateFailures.InaccurateLine,
        BuiltInFailures.MassFailures.TooManyGeometries
      });
      if (this.m_BaseSurface == null || this.m_ProposedSurface == null)
      {
        if (RevitUtility.RemoveAllSiteComponents(this.m_Document, this.m_TransactionContainer))
        {
          this.m_TransactionContainer.Commit();
          this.m_TransactionContainer.AssimilateTransactionGroup();
        }
        else
        {
          this.m_TransactionContainer.Rollback();
          this.m_TransactionContainer.RollbackTransactionGroup();
        }
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoToposurfaceCanBeModifiedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("TopographySurfaceArcPointInterval", ref this.m_dArcPointInterval))
        {
          this.m_dArcPointInterval = 1.0;
          ApplicationUtility.Settings.eplSetE_SetSetting("TopographySurfaceArcPointInterval", this.m_dArcPointInterval);
        }
        if (this.PromptPick())
        {
          bool flag = this.DisplayUI();
          if (this.m_LineElementSet != null)
          {
            if (this.m_LineElementSet.Size > 0)
            {
              try
              {
                this.m_TransactionContainer.BeginTransaction();
                this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_LineElementSet));
                this.m_TransactionContainer.EndTransaction();
              }
              catch
              {
              }
            }
          }
          if (this.m_bResetLineVisibilityCategory)
          {
            Category category = this.m_Document.Settings.Categories[(BuiltInCategory) -2000051];
            if (category != null && category[this.m_Document.ActiveView])
              category[this.m_Document.ActiveView] = false;
          }
          if (flag)
          {
            if (this.m_AnnotationElevationTextSet != null)
            {
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
              this.m_AnnotationElevationTextSet = (ElementSet) null;
            }
            if (this.m_AnnotationGradeTextSet != null)
            {
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
              this.m_AnnotationGradeTextSet = (ElementSet) null;
            }
            if (this.m_bHasElevationAnnotation || this.m_bHasGradeAnnotation)
              RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, this.m_bHasElevationAnnotation, this.m_bHasGradeAnnotation, false, (TextNoteType) null, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet, true);
            this.m_TransactionContainer.Commit();
            this.m_TransactionContainer.AssimilateTransactionGroup();
          }
          else
          {
            this.m_TransactionContainer.Rollback();
            this.m_TransactionContainer.RollbackTransactionGroup();
          }
        }
        else if (this.m_bDeleteSiteComponent)
        {
          if (this.m_AnnotationElevationTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
            this.m_AnnotationElevationTextSet = (ElementSet) null;
          }
          if (this.m_AnnotationGradeTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
            this.m_AnnotationGradeTextSet = (ElementSet) null;
          }
          this.m_TransactionContainer.Commit();
          this.m_TransactionContainer.AssimilateTransactionGroup();
        }
        else
        {
          this.m_TransactionContainer.Rollback();
          this.m_TransactionContainer.RollbackTransactionGroup();
        }
      }
    }
  }

  private bool DisplayUI()
  {
    bool flag = false;
    DialogResult _DialogResult = DialogResult.Retry;
    if (this.m_CurrentFamilyType == LandcaddID.ParkingLot)
    {
      using (this.m_ParkingLotDisplayForm = new ModifySiteParkingLotComponentForm())
      {
        while (_DialogResult == DialogResult.Retry)
          flag = this.ShowDialog(ref _DialogResult);
      }
    }
    else if (this.m_CurrentFamilyType == LandcaddID.PointWipeout)
    {
      using (this.m_PointWipeoutDisplayForm = new ModifySitePointWipeoutComponentForm())
      {
        while (_DialogResult == DialogResult.Retry)
          flag = this.ShowDialog(ref _DialogResult);
      }
    }
    else
    {
      using (this.m_DisplayForm = new ModifySiteComponentForm(this.m_CurrentFamilyType))
      {
        while (_DialogResult == DialogResult.Retry)
          flag = this.ShowDialog(ref _DialogResult);
      }
    }
    return flag;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    bool flag = false;
    if (this.m_CurrentFamilyType == LandcaddID.ParkingLot)
    {
      int num = (int) this.m_ParkingLotDisplayForm.ShowDialog();
      _DialogResult = this.m_ParkingLotDisplayForm.DialogResult;
    }
    else if (this.m_CurrentFamilyType == LandcaddID.PointWipeout)
    {
      int num = (int) this.m_PointWipeoutDisplayForm.ShowDialog();
      _DialogResult = this.m_PointWipeoutDisplayForm.DialogResult;
    }
    else
    {
      int num = (int) this.m_DisplayForm.ShowDialog();
      _DialogResult = this.m_DisplayForm.DialogResult;
    }
    if (_DialogResult == DialogResult.OK)
    {
      if (this.m_ModifyStatus)
        flag = this.ApplySiteAlignmentElementUpdate();
    }
    else if (_DialogResult == DialogResult.Cancel)
      flag = false;
    else if (_DialogResult == DialogResult.Retry)
    {
      if (this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol != null)
      {
        switch (this.m_CurrentFamilyType)
        {
          case LandcaddID.SoftTerrain:
            Parameter parameter1 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.SoftTerrainLeftOffsetWidthParameter);
            if (parameter1 != null)
              this.m_dMarkerHeight = parameter1.AsDouble();
            Parameter parameter2 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.SoftTerrainRightOffsetWidthParameter);
            if (parameter2 != null)
              this.m_dMarkerHeight += parameter2.AsDouble();
            this.m_dMarkerHeight *= 2.0;
            break;
          case LandcaddID.Street:
            double num1 = 0.0;
            Parameter parameter3 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
            if (parameter3 != null)
              num1 = parameter3.AsDouble();
            Parameter parameter4 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
            if (parameter4 != null)
              this.m_dMarkerHeight = num1 * (double) parameter4.AsInteger();
            this.m_dMarkerHeight *= 2.0;
            break;
          case LandcaddID.Curb:
            double num2 = 0.0;
            Parameter parameter5 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
            if (parameter5 != null)
              num2 = parameter5.AsDouble();
            Parameter parameter6 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
            if (parameter6 != null)
              this.m_dMarkerHeight = num2 * (double) parameter6.AsInteger();
            this.m_dMarkerHeight *= 2.0;
            break;
          case LandcaddID.Sidewalk:
            Parameter parameter7 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
            if (parameter7 != null)
              this.m_dMarkerHeight = parameter7.AsDouble();
            this.m_dMarkerHeight *= 2.0;
            break;
          case LandcaddID.RetainingWall:
            Parameter parameter8 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.RetainingWallHeightParameter);
            if (parameter8 != null)
              this.m_dMarkerHeight = parameter8.AsDouble();
            this.m_dMarkerHeight *= 2.0;
            break;
        }
      }
      if (RevitDefines.EQ(this.m_dMarkerHeight, 0.0))
        this.m_dMarkerHeight = 10.0;
      switch (this.m_CurrentFamilyType != LandcaddID.ParkingLot ? (this.m_CurrentFamilyType != LandcaddID.PointWipeout ? (int) this.m_DisplayForm.PerformAction : (int) this.m_PointWipeoutDisplayForm.PerformAction) : (int) this.m_ParkingLotDisplayForm.PerformAction)
      {
        case 0:
          flag = this.MoveSiteAlignmentElement();
          if (flag)
          {
            this.m_bFindIntersectionStations = true;
            TopographySurfaceManagement.RemoveAllIntersectionStationsForCommonSiteComponents(ref this.m_AllSiteComponentList);
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 1:
          flag = this.RotateSiteAlignmentElement();
          if (flag)
          {
            this.m_bFindIntersectionStations = true;
            TopographySurfaceManagement.RemoveAllIntersectionStationsForCommonSiteComponents(ref this.m_AllSiteComponentList);
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 2:
          flag = this.ChangeGradeAndElevationSiteAlignmentElement();
          if (flag)
          {
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 3:
          flag = this.AddVertexSiteAlignmentElement();
          if (flag)
          {
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 4:
          flag = this.DeleteVertexSiteAlignmentElement();
          if (flag)
          {
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 5:
          flag = this.DeleteSiteAlignmentElement();
          if (flag)
          {
            this.m_ModifyStatus = true;
            this.ApplySiteAlignmentElementUpdate();
            _DialogResult = DialogResult.OK;
            break;
          }
          break;
        case 6:
          flag = this.ChangeTypeSiteAlignmentElement();
          if (flag)
          {
            this.m_bFindIntersectionStations = true;
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 7:
          flag = this.AddBreaklinesToSiteAlignmentElement();
          if (this.m_LineElementSet != null && this.m_LineElementSet.Size > 0)
          {
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_LineElementSet));
            this.m_TransactionContainer.EndTransaction();
          }
          this.m_Document.Regenerate();
          if (flag)
          {
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 8:
          flag = this.DeleteBreaklinesFromSiteAlignmentElement();
          if (flag)
          {
            this.m_ModifyStatus = true;
            break;
          }
          break;
        case 9:
          flag = this.ChangeViewScale();
          if (flag)
          {
            this.m_ModifyStatus = true;
            break;
          }
          break;
      }
    }
    return flag;
  }

  private bool PromptPick()
  {
    Category category = this.m_Document.Settings.Categories[(BuiltInCategory) -2000051];
    if (category != null && !category[this.m_Document.ActiveView])
    {
      this.m_TransactionContainer.BeginTransaction();
      category[this.m_Document.ActiveView] = true;
      this.m_TransactionContainer.EndTransaction();
      this.m_bResetLineVisibilityCategory = true;
    }
    if (this.m_LineElementSet != null && this.m_LineElementSet.Size > 0)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_LineElementSet));
      this.m_TransactionContainer.EndTransaction();
    }
    if (this.m_SiteCategoryComponentList != null && this.m_SiteCategoryComponentList.Count > 0 || this.m_SiteCategoryLineElementSet != null && this.m_SiteCategoryLineElementSet.Size > 0)
    {
      this.DisplaySiteAlignmentLines();
      this.m_Document.Regenerate();
      if (!this.PickSiteAlignmentElement())
        return false;
      this.m_Document.Regenerate();
      if (this.m_FamilyInstanceComponentWrapper != null && this.m_FamilyInstanceComponentWrapper.ProposedElementSet != null)
        return true;
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PickSiteComponentLineMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      return false;
    }
    string str = EPShared.LocalRM.GetString("ThereAreNoString_");
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.SoftTerrain:
        str += EPShared.LocalRM.GetString("ModifySoftTerrainRibbonButton");
        break;
      case LandcaddID.Street:
        str += EPShared.LocalRM.GetString("StreetFamilyManagerRibbonButton");
        break;
      case LandcaddID.Curb:
        str += EPShared.LocalRM.GetString("CurbFamilyManagerRibbonButton");
        break;
      case LandcaddID.Sidewalk:
        str += EPShared.LocalRM.GetString("LocateSidewalkRibbonButton");
        break;
      case LandcaddID.RetainingWall:
        str += EPShared.LocalRM.GetString("LocateRetainingWallRibbonButton");
        break;
      case LandcaddID.Steps:
        str += EPShared.LocalRM.GetString("");
        break;
      case LandcaddID.ParkingLot:
        str += EPShared.LocalRM.GetString("ParkingLotFamilyManagerRibbonButton");
        break;
      case LandcaddID.FeatureLine:
        str += EPShared.LocalRM.GetString("FeatureLineRibbonButton");
        break;
      case LandcaddID.PointWipeout:
        str += EPShared.LocalRM.GetString("PointWipeoutRibbonButton");
        break;
    }
    int num1 = (int) RevitMessageBox.Show(str + EPShared.LocalRM.GetString("_FeaturesInThisModelString"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    return false;
  }

  private void InitializeData()
  {
    FamilyInstance _BasePlacementFamilyInstance = (FamilyInstance) null;
    TopographySurfaceManagement.FindBaseLandcaddTopographySurface(this.m_Document, ref this.m_BaseSurface, ref _BasePlacementFamilyInstance, ref this.m_ProposedSurface, ref this.m_TopoPlacementFamilyInstance);
    if (this.m_BaseSurface == null || this.m_ProposedSurface == null)
      return;
    EPTransactionContainer transactionContainer = new EPTransactionContainer(this.m_Document);
    transactionContainer.Start(EPShared.LocalRM.GetString("CreateLineSubCategoriesTransaction"));
    this.GetMassAndLineElements(true);
    if (!this.m_bDoesMassLineSubCategoryExist)
      transactionContainer.Commit();
    else
      transactionContainer.Rollback();
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051);
    List<Element> list = ((IEnumerable<Element>) source).ToList<Element>();
    for (int index = 0; index < list.Count; ++index)
    {
      Element element = list[index];
      if (element != null && element.Category != null && element.Category.Id.IntegerValue == ((BuiltInCategory) -2000051).GetHashCode() && !element.IsHidden(this.m_Document.ActiveView))
        this.m_LineElementSet.Insert(element);
    }
  }

  private void PopulateSiteComponentLists(
    List<KeyValuePair<string, Category>> MassLineSubCategoryList,
    List<Element> LineElementList)
  {
    List<Element> elementList = new List<Element>();
    FindFamilyInstance = (FamilyInstance) null;
    List<KeyValuePair<string, FamilyInstanceComponentContainer>> keyValuePairList = new List<KeyValuePair<string, FamilyInstanceComponentContainer>>();
    Parameter SiteworksIDParameter = (Parameter) null;
    Parameter LocateTypeParameter = (Parameter) null;
    bool flag = false;
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && (LocateTypeParameter = ((Element) FindFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter)) != null && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = list.Count;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarObtainingSiteComponentsMessage");
    foreach (Element element in list)
    {
      if (element is FamilyInstance _FamilyInstance && ((Element) _FamilyInstance).Category != null)
      {
        int integerValue1 = ((Element) _FamilyInstance).Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001260;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1)
        {
          Parameter parameter1 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter1 != null)
          {
            LocateTypeParameter = ((Element) _FamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (LocateTypeParameter != null)
            {
              Parameter parameter2 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
              if (parameter2 != null && parameter2.AsString() != string.Empty)
              {
                for (int index1 = 0; index1 < LineElementList.Count; ++index1)
                {
                  Element lineElement = LineElementList[index1];
                  if (lineElement != null && lineElement.Category != null)
                  {
                    int integerValue2 = lineElement.Category.Id.IntegerValue;
                    builtInCategory = (BuiltInCategory) -2000051;
                    int hashCode2 = builtInCategory.GetHashCode();
                    if (integerValue2 == hashCode2 && string.Compare(parameter1.AsString(), lineElement.UniqueId, true) == 0)
                    {
                      if (MassLineSubCategoryList != null && !this.m_bDoesMassLineSubCategoryExist)
                      {
                        for (int index2 = 0; index2 < MassLineSubCategoryList.Count; ++index2)
                        {
                          if (string.Compare(MassLineSubCategoryList[index2].Key, LocateTypeParameter.AsString(), true) == 0)
                          {
                            if (MassLineSubCategoryList[index2].Value != null && lineElement is ModelCurve modelCurve)
                            {
                              GraphicsStyle graphicsStyle = MassLineSubCategoryList[index2].Value.GetGraphicsStyle((GraphicsStyleType) 1);
                              ((CurveElement) modelCurve).LineStyle = (Element) graphicsStyle;
                              break;
                            }
                            break;
                          }
                        }
                      }
                      Parameter parameter3 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.IsBreaklineFamilyParameter);
                      if (parameter3 != null && parameter3.AsInteger() == 1)
                      {
                        keyValuePairList.Add(new KeyValuePair<string, FamilyInstanceComponentContainer>(parameter2.AsString(), new FamilyInstanceComponentContainer(lineElement, _FamilyInstance)));
                      }
                      else
                      {
                        int int32;
                        for (int index3 = 0; index3 < this.m_AllSiteComponentList.Count; ++index3)
                        {
                          if (string.Compare(parameter2.AsString(), this.m_AllSiteComponentList[index3].ChainID, true) == 0)
                          {
                            flag = true;
                            string strA = LocateTypeParameter.AsString();
                            int32 = Convert.ToInt32((object) this.m_CurrentFamilyType);
                            string strB = int32.ToString("000");
                            if (string.Compare(strA, strB, true) == 0)
                            {
                              for (int index4 = 0; index4 < this.m_SiteCategoryComponentList.Count; ++index4)
                              {
                                if (string.Compare(parameter2.AsString(), this.m_SiteCategoryComponentList[index4].ChainID, true) == 0)
                                  this.m_SiteCategoryComponentList[index4].FamilyContainerList.Add(new FamilyInstanceComponentContainer(lineElement, _FamilyInstance));
                              }
                            }
                            this.m_AllSiteComponentList[index3].FamilyContainerList.Add(new FamilyInstanceComponentContainer(lineElement, _FamilyInstance));
                            break;
                          }
                        }
                        if (!flag)
                        {
                          int _nDrawOrder = 0;
                          Parameter parameter4 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
                          if (parameter4 != null)
                            _nDrawOrder = parameter4.AsInteger();
                          string strA = LocateTypeParameter.AsString();
                          int32 = Convert.ToInt32((object) this.m_CurrentFamilyType);
                          string strB = int32.ToString("000");
                          if (string.Compare(strA, strB, true) == 0)
                            this.m_SiteCategoryComponentList.Add(new FamilyInstanceComponentWrapper(parameter2.AsString(), new List<FamilyInstanceComponentContainer>()
                            {
                              new FamilyInstanceComponentContainer(lineElement, _FamilyInstance)
                            }, _nDrawOrder));
                          this.m_AllSiteComponentList.Add(new FamilyInstanceComponentWrapper(parameter2.AsString(), new List<FamilyInstanceComponentContainer>()
                          {
                            new FamilyInstanceComponentContainer(lineElement, _FamilyInstance)
                          }, _nDrawOrder));
                        }
                        else
                          flag = false;
                      }
                      LineElementList.RemoveAt(index1);
                      break;
                    }
                  }
                }
                if (LineElementList.Count == 0)
                  break;
              }
            }
            else
              continue;
          }
          else
            continue;
        }
      }
      progressBarForm.UpdateProgressBar(1);
    }
    for (int index5 = 0; index5 < keyValuePairList.Count; ++index5)
    {
      KeyValuePair<string, FamilyInstanceComponentContainer> keyValuePair;
      for (int index6 = 0; index6 < this.m_SiteCategoryComponentList.Count; ++index6)
      {
        keyValuePair = keyValuePairList[index5];
        if (string.Compare(keyValuePair.Key, this.m_SiteCategoryComponentList[index6].ChainID, true) == 0)
        {
          List<Element> breaklineElementList = this.m_SiteCategoryComponentList[index6].ParkingLotBreaklineElementList;
          keyValuePair = keyValuePairList[index5];
          Element element = keyValuePair.Value.Element;
          breaklineElementList.Add(element);
          List<FamilyInstance> familyInstanceList = this.m_SiteCategoryComponentList[index6].ParkingLotBreaklineFamilyInstanceList;
          keyValuePair = keyValuePairList[index5];
          FamilyInstance familyInstance = keyValuePair.Value.FamilyInstance;
          familyInstanceList.Add(familyInstance);
          break;
        }
      }
      for (int index7 = 0; index7 < this.m_AllSiteComponentList.Count; ++index7)
      {
        keyValuePair = keyValuePairList[index5];
        if (string.Compare(keyValuePair.Key, this.m_AllSiteComponentList[index7].ChainID, true) == 0)
        {
          List<Element> breaklineElementList = this.m_AllSiteComponentList[index7].ParkingLotBreaklineElementList;
          keyValuePair = keyValuePairList[index5];
          Element element = keyValuePair.Value.Element;
          breaklineElementList.Add(element);
          List<FamilyInstance> familyInstanceList = this.m_AllSiteComponentList[index7].ParkingLotBreaklineFamilyInstanceList;
          keyValuePair = keyValuePairList[index5];
          FamilyInstance familyInstance = keyValuePair.Value.FamilyInstance;
          familyInstanceList.Add(familyInstance);
          break;
        }
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  private void GetMassAndLineElements(bool _bOnlyFindSelSiteComponent)
  {
    FilteredElementCollector source1 = new FilteredElementCollector(this.m_Document);
    source1.OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051);
    source1.WhereElementIsViewIndependent();
    List<KeyValuePair<string, Category>> MassLineSubCategoryList = new List<KeyValuePair<string, Category>>();
    if (_bOnlyFindSelSiteComponent && this.m_CurrentFamilyType != LandcaddID.ParkingLot)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(this.m_Document, this.m_CurrentFamilyType, ref this.m_bDoesMassLineSubCategoryExist);
      if (componentLineSubCategory != null)
        MassLineSubCategoryList.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000"), componentLineSubCategory));
    }
    else
      MassLineSubCategoryList = this.m_CurrentFamilyType != LandcaddID.ParkingLot ? RevitUtility.GetAllMassLineSubCategories(this.m_Document, ref this.m_bDoesMassLineSubCategoryExist, Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000")) : RevitUtility.GetAllMassLineSubCategories(this.m_Document, ref this.m_bDoesMassLineSubCategoryExist);
    List<Element> LineElementList = (List<Element>) null;
    if (MassLineSubCategoryList != null && MassLineSubCategoryList.Count > 0)
    {
      for (int nIndex = 0; nIndex < MassLineSubCategoryList.Count; nIndex++)
      {
        if (MassLineSubCategoryList[nIndex].Value != null)
        {
          if (this.m_bDoesMassLineSubCategoryExist)
          {
            Parameter LineStyleParameter = (Parameter) null;
            FindCurveElement = (CurveElement) null;
            IEnumerable<Element> source2 = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is CurveElement FindCurveElement && (LineStyleParameter = ((Element) FindCurveElement)[(BuiltInParameter) -1006210]) != null && ElementId.op_Equality(LineStyleParameter.AsElementId(), ((Element) MassLineSubCategoryList[nIndex].Value.GetGraphicsStyle((GraphicsStyleType) 1)).Id)));
            if (nIndex == 0)
              LineElementList = source2.ToList<Element>();
            else
              LineElementList.AddRange((IEnumerable<Element>) source2.ToList<Element>());
          }
          if (string.Compare(MassLineSubCategoryList[nIndex].Key, Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000"), true) == 0)
          {
            this.m_MassLineSubCategory = MassLineSubCategoryList[nIndex].Value;
            if (!this.m_bDoesMassLineSubCategoryExist)
              break;
          }
        }
      }
    }
    if (!this.m_bDoesMassLineSubCategoryExist)
    {
      List<Element> list = ((IEnumerable<Element>) source1).ToList<Element>();
      this.PopulateSiteComponentLists(MassLineSubCategoryList, list);
    }
    else if (this.m_CurrentFamilyType == LandcaddID.ParkingLot || !_bOnlyFindSelSiteComponent)
    {
      foreach (Element categoryLineElement in this.m_SiteCategoryLineElementSet)
        LineElementList.Add(categoryLineElement);
      this.PopulateSiteComponentLists(MassLineSubCategoryList, LineElementList);
    }
    else
    {
      for (int index = 0; index < LineElementList.Count; ++index)
        this.m_SiteCategoryLineElementSet.Insert(LineElementList[index]);
    }
  }

  private List<Element> FindSiteFamilyList(string _strID, bool _bIsChainID)
  {
    Parameter IDParameter = (Parameter) null;
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    return !_bIsChainID ? ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (IDParameter = CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter)) != null && string.Compare(IDParameter.AsString(), _strID, true) == 0)).ToList<Element>() : ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (IDParameter = CurrentElement.LookupParameter(RevitParameters.ChainIDGenericFamilyParameter)) != null && string.Compare(IDParameter.AsString(), _strID, true) == 0)).ToList<Element>();
  }

  private void FindFamilyInstanceComponentWrapper(Element _CurElement)
  {
    foreach (Element siteFamily1 in this.FindSiteFamilyList(_CurElement.UniqueId, false))
    {
      if (siteFamily1 is FamilyInstance _FamilyInstance1 && ((Element) _FamilyInstance1).Category != null && ((Element) _FamilyInstance1).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
      {
        Parameter parameter1 = ((Element) _FamilyInstance1.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (parameter1 != null && string.Compare(parameter1.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && ((Element) _FamilyInstance1).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter) != null)
        {
          Parameter parameter2 = ((Element) _FamilyInstance1).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
          if (parameter2 != null && parameter2.AsString() != string.Empty)
          {
            int _nDrawOrder = 0;
            Parameter parameter3 = ((Element) _FamilyInstance1).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
            if (parameter3 != null)
              _nDrawOrder = parameter3.AsInteger();
            List<FamilyInstanceComponentContainer> _FamilyContainerList = new List<FamilyInstanceComponentContainer>();
            foreach (Element siteFamily2 in this.FindSiteFamilyList(parameter2.AsString(), true))
            {
              if (siteFamily2 is FamilyInstance _FamilyInstance && ((Element) _FamilyInstance).Category != null && ((Element) _FamilyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
              {
                Parameter parameter4 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
                if (parameter4 != null && string.Compare(parameter4.AsString(), _CurElement.UniqueId, true) != 0)
                {
                  Parameter parameter5 = ((Element) _FamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
                  if (parameter5 != null && string.Compare(parameter5.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && ((Element) _FamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter) != null)
                  {
                    foreach (Element categoryLineElement in this.m_SiteCategoryLineElementSet)
                    {
                      if (string.Compare(parameter4.AsString(), categoryLineElement.UniqueId, true) == 0)
                      {
                        _FamilyContainerList.Add(new FamilyInstanceComponentContainer(categoryLineElement, _FamilyInstance));
                        break;
                      }
                    }
                  }
                }
              }
            }
            _FamilyContainerList.Add(new FamilyInstanceComponentContainer(_CurElement, _FamilyInstance1));
            this.m_FamilyInstanceComponentWrapper = new FamilyInstanceComponentWrapper(parameter2.AsString(), _FamilyContainerList, _nDrawOrder);
            this.m_FamilyInstanceComponentWrapper.CreateProposedLeg(this.m_ProposedSurface);
          }
        }
      }
    }
  }

  private void HideSiteAlignmentLines()
  {
    if (this.m_SiteCategoryComponentList != null && this.m_SiteCategoryComponentList.Count > 0)
    {
      ElementSet elm_set = new ElementSet();
      for (int index = 0; index < this.m_SiteCategoryComponentList.Count; ++index)
      {
        foreach (Element originalElement in this.m_SiteCategoryComponentList[index].GetOriginalElementSet())
          elm_set.Insert(originalElement);
      }
      if (elm_set.Size <= 0)
        return;
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
    }
    else
    {
      if (this.m_SiteCategoryLineElementSet == null || this.m_SiteCategoryLineElementSet.Size <= 0)
        return;
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_SiteCategoryLineElementSet));
      this.m_TransactionContainer.EndTransaction();
    }
  }

  private void DisplaySiteAlignmentLines()
  {
    if (this.m_SiteCategoryComponentList != null && this.m_SiteCategoryComponentList.Count > 0)
    {
      ElementSet elm_set = new ElementSet();
      for (int index = 0; index < this.m_SiteCategoryComponentList.Count; ++index)
      {
        TopographySurfaceContainer _Surface = (TopographySurfaceContainer) null;
        if (this.m_CurrentFamilyType == LandcaddID.ParkingLot)
        {
          ElementSet instanceElementSet = this.m_SiteCategoryComponentList[index].GetFamilyInstanceElementSet();
          if (instanceElementSet != null && instanceElementSet.Size > 0)
          {
            string _strFormUniqueId = string.Empty;
            foreach (Element element in instanceElementSet)
            {
              Parameter parameter = element.LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
              if (parameter != null && parameter.AsString() != string.Empty)
              {
                _strFormUniqueId = parameter.AsString();
                break;
              }
            }
            TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _strFormUniqueId);
            if (topoSurfaceInstance != null)
              _Surface = new TopographySurfaceContainer(this.m_Document.Application, topoSurfaceInstance, true);
          }
          this.m_SiteCategoryComponentList[index].ParkingLotTopographySurface = _Surface;
        }
        if (_Surface == null)
          _Surface = this.m_ProposedSurface;
        this.m_SiteCategoryComponentList[index].CreateProposedLeg(_Surface);
        foreach (Element originalElement in this.m_SiteCategoryComponentList[index].GetOriginalElementSet())
          elm_set.Insert(originalElement);
      }
      if (elm_set.Size <= 0)
        return;
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
    }
    else
    {
      if (this.m_SiteCategoryLineElementSet == null || this.m_SiteCategoryLineElementSet.Size <= 0)
        return;
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_SiteCategoryLineElementSet));
      this.m_TransactionContainer.EndTransaction();
    }
  }

  private bool PickSiteAlignmentElement()
  {
    bool flag = false;
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
    {
      this.HideSiteAlignmentLines();
      return false;
    }
    List<string> _AnnotationListID = new List<string>();
    foreach (Element _CurElement in _Elements)
    {
      if (this.m_SiteCategoryComponentList != null && this.m_SiteCategoryComponentList.Count > 0)
      {
        for (int index = 0; index < this.m_SiteCategoryComponentList.Count; ++index)
        {
          if (this.m_SiteCategoryComponentList[index].IndexOfOriginalElementID(_CurElement.Id) >= 0)
          {
            this.m_FamilyInstanceComponentWrapper = this.m_SiteCategoryComponentList[index];
            break;
          }
        }
      }
      else if (this.m_SiteCategoryLineElementSet != null && this.m_SiteCategoryLineElementSet.Size > 0)
      {
        foreach (Element categoryLineElement in this.m_SiteCategoryLineElementSet)
        {
          if (ElementId.op_Equality(categoryLineElement.Id, _CurElement.Id))
          {
            this.FindFamilyInstanceComponentWrapper(_CurElement);
            break;
          }
        }
      }
    }
    if (this.m_FamilyInstanceComponentWrapper != null)
    {
      bool _bFamilySymbolPresent = false;
      this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol = this.SetInitialProposedFamilySymbol(this.m_FamilyInstanceComponentWrapper, ref _bFamilySymbolPresent);
      if (this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol == null && this.m_CurrentFamilyType != LandcaddID.FeatureLine && this.m_CurrentFamilyType != LandcaddID.PointWipeout)
      {
        if (_bFamilySymbolPresent)
        {
          List<string> _WarningOptions = new List<string>();
          _WarningOptions.Add(EPShared.LocalRM.GetString("SetFamilyTypeForSiteComponentOption"));
          _WarningOptions.Add(EPShared.LocalRM.GetString("DeleteSiteComponentOption"));
          string _strWarningText = EPShared.LocalRM.GetString("The_String") + this.GetCurrentTypeString(this.m_CurrentFamilyType) + EPShared.LocalRM.GetString("_FamilyTypeNotFoundMessage");
          WarningOptionsForm warningOptionsForm = new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), this.m_Document.PathName, nameof (ModifySiteComponent), _strWarningText, _WarningOptions, 0, true, false);
          int num = (int) warningOptionsForm.ShowDialog();
          if (warningOptionsForm.DialogResult == DialogResult.OK)
          {
            if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("SetFamilyTypeForSiteComponentOption"), true) == 0)
            {
              if (!this.ChangeTypeSiteAlignmentElement())
                return false;
              this.m_ModifyStatus = true;
            }
            else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("DeleteSiteComponentOption"), true) == 0 && this.DeleteSiteAlignmentElement())
            {
              this.m_ModifyStatus = true;
              this.ApplySiteAlignmentElementUpdate();
              this.m_bDeleteSiteComponent = true;
              return false;
            }
          }
        }
        else
        {
          string empty = string.Empty;
          if (RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NoString") + " "}{this.GetCurrentTypeString(this.m_CurrentFamilyType)} " + EPShared.LocalRM.GetString("_FamilyTypeNotFoundDeleteMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes && this.DeleteSiteAlignmentElement())
          {
            this.m_ModifyStatus = true;
            this.ApplySiteAlignmentElementUpdate();
            this.m_bDeleteSiteComponent = true;
          }
          return false;
        }
      }
      flag = true;
      this.HideSiteAlignmentLines();
      if (this.m_FamilyInstanceComponentWrapper.ProposedLeg != null)
        this.m_FamilyInstanceComponentWrapper.CreateNewProposedElementSet(this.m_Document, this.m_TransactionContainer);
      ElementSet instanceElementSet = this.m_FamilyInstanceComponentWrapper.GetFamilyInstanceElementSet();
      if (instanceElementSet != null && instanceElementSet.Size > 0)
      {
        List<IntersectionStationContainer> _LeftIntersectionStations = (List<IntersectionStationContainer>) null;
        List<IntersectionStationContainer> _RightIntersectionStations = (List<IntersectionStationContainer>) null;
        List<FamilyInstance> _SiteFamilyInstanceList = (List<FamilyInstance>) null;
        foreach (Element element in instanceElementSet)
        {
          if (this.m_CurrentFamilyType == LandcaddID.Street || this.m_CurrentFamilyType == LandcaddID.Sidewalk)
            TopographySurfaceManagement.GetIntersections(this.m_Document, element.UniqueId, ref _SiteFamilyInstanceList, ref _LeftIntersectionStations, ref _RightIntersectionStations);
          if (_SiteFamilyInstanceList != null && _SiteFamilyInstanceList.Count > 0)
          {
            this.m_FamilyInstanceComponentWrapper.AddIntersectionFamilyInstances(_SiteFamilyInstanceList);
            this.m_FamilyInstanceComponentWrapper.IntersectionFamilySymbol = _SiteFamilyInstanceList[0].Symbol;
          }
          if (_LeftIntersectionStations != null && _LeftIntersectionStations.Count > 0)
            this.m_FamilyInstanceComponentWrapper.LeftIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
          if (_RightIntersectionStations != null && _RightIntersectionStations.Count > 0)
            this.m_FamilyInstanceComponentWrapper.RightIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
          Parameter parameter1 = element.LookupParameter(RevitParameters.SiteComponentHasElevationAnnotationParameter);
          if (parameter1 != null)
            this.m_bHasElevationAnnotation = parameter1.AsInteger() == 1;
          Parameter parameter2 = element.LookupParameter(RevitParameters.SiteComponentHasGradeAnnotationParameter);
          if (parameter2 != null)
            this.m_bHasGradeAnnotation = parameter2.AsInteger() == 1;
          Parameter parameter3 = element.LookupParameter(RevitParameters.SiteComponentAnnotationGradeIDParameter);
          if (parameter3 != null && parameter3.AsString() != string.Empty)
          {
            string str = parameter3.AsString();
            if (str != string.Empty)
              _AnnotationListID.Add(str);
          }
          Parameter parameter4 = element.LookupParameter(RevitParameters.SiteComponentAnnotationBeginElevationIDParameter);
          if (parameter4 != null)
          {
            string str = parameter4.AsString();
            if (str != string.Empty)
              _AnnotationListID.Add(str);
          }
          Parameter parameter5 = element.LookupParameter(RevitParameters.SiteComponentAnnotationEndElevationIDParameter);
          if (parameter5 != null)
          {
            string str = parameter5.AsString();
            if (str != string.Empty)
              _AnnotationListID.Add(str);
          }
        }
        if (_AnnotationListID.Count > 0)
          this.RemoveAnnotationText(_AnnotationListID);
      }
      RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
      if (this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Count > 0)
      {
        this.m_FamilyInstanceComponentWrapper.CreateParkingLotBreaklineLegs(this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface);
        this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet));
      }
    }
    if (!flag)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NotSiteComponentMessage_") + this.GetCurrentTypeString(this.m_CurrentFamilyType) + EPShared.LocalRM.GetString("_HostLineString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return this.PickSiteAlignmentElement();
    }
    if (this.m_FamilyInstanceComponentWrapper != null && this.m_FamilyInstanceComponentWrapper.IntersectionFamilySymbol != null)
    {
      for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
        this.m_AllSiteComponentList[index].IntersectionFamilySymbol = this.m_FamilyInstanceComponentWrapper.IntersectionFamilySymbol;
    }
    if (this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface != null)
    {
      for (int index = this.m_AllSiteComponentList.Count - 1; index >= 0; --index)
      {
        ElementSet instanceElementSet = this.m_AllSiteComponentList[index].GetFamilyInstanceElementSet();
        if (instanceElementSet != null && instanceElementSet.Size > 0)
        {
          IEnumerator enumerator = instanceElementSet.GetEnumerator();
          try
          {
            if (enumerator.MoveNext())
            {
              Parameter parameter = ((Element) enumerator.Current).LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
              if (parameter != null)
              {
                if (parameter.AsString() != string.Empty)
                {
                  string strA = parameter.AsString();
                  this.m_strParentTopoSurfaceID = strA;
                  if (string.Compare(strA, ((Element) this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface.TopographySurface).UniqueId, true) == 0)
                  {
                    if (this.m_ParkingLotCurbSiteCompList == null)
                      this.m_ParkingLotCurbSiteCompList = new List<FamilyInstanceComponentWrapper>();
                    this.m_ParkingLotCurbSiteCompList.Insert(0, this.m_AllSiteComponentList[index]);
                    this.m_AllSiteComponentList.RemoveAt(index);
                    this.m_ParkingLotCurbSiteCompList[0].CreateProposedLeg(this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface);
                    if (this.m_ParkingLotCurbSiteCompList[0].ProposedLeg != null)
                      this.m_ParkingLotCurbSiteCompList[0].CreateNewProposedElementSet(this.m_Document, this.m_TransactionContainer);
                    bool _bFamilySymbolPresent = false;
                    this.m_ParkingLotCurbSiteCompList[0].ProposedFamilySymbol = this.SetInitialProposedFamilySymbol(this.m_ParkingLotCurbSiteCompList[0], ref _bFamilySymbolPresent);
                  }
                }
              }
            }
          }
          finally
          {
            if (enumerator is IDisposable disposable)
              disposable.Dispose();
          }
        }
      }
    }
    return true;
  }

  private string GetCurrentTypeString(LandcaddID _Id)
  {
    string empty = string.Empty;
    switch (_Id)
    {
      case LandcaddID.SoftTerrain:
        empty = EPShared.LocalRM.GetString("SoftTerrainString");
        break;
      case LandcaddID.Street:
        empty = EPShared.LocalRM.GetString("StreetString");
        break;
      case LandcaddID.Curb:
        empty = EPShared.LocalRM.GetString("CurbString");
        break;
      case LandcaddID.Sidewalk:
        empty = EPShared.LocalRM.GetString("SidewalkString");
        break;
      case LandcaddID.RetainingWall:
        empty = EPShared.LocalRM.GetString("RetainingWallString");
        break;
      case LandcaddID.ParkingLot:
        empty = EPShared.LocalRM.GetString("ParkingLotString");
        break;
      case LandcaddID.FeatureLine:
        empty = EPShared.LocalRM.GetString("FeatureLineString");
        break;
      case LandcaddID.PointWipeout:
        empty = EPShared.LocalRM.GetString("PointWipeoutString");
        break;
    }
    return empty;
  }

  private void RemoveAnnotationText(List<string> _AnnotationListID)
  {
    ElementSet elm_set = new ElementSet();
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (TextNote)).OfCategory((BuiltInCategory) -2000300);
    foreach (Element element in ((IEnumerable<Element>) source).ToList<Element>())
    {
      foreach (string strB in _AnnotationListID)
      {
        if (string.Compare(element.UniqueId, strB, false) == 0)
        {
          elm_set.Insert(element);
          break;
        }
      }
    }
    this.m_TransactionContainer.BeginTransaction();
    if (!elm_set.IsEmpty)
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
    this.m_TransactionContainer.EndTransaction();
  }

  private bool MoveSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    string _strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
    bool flag1 = false;
    ElementSet elm_set = new ElementSet();
    Eps_Point _Point = (Eps_Point) null;
    Eps_Point _FirstPnt = (Eps_Point) null;
    bool flag2 = true;
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    while (flag2)
    {
      flag2 = RevitUtility.GetPointFromProject(this.m_Document, _strPrompt, ref _Point, false);
      if (flag2)
      {
        if (_FirstPnt != null)
        {
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, _Point, ref _dDistance);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, _Point, ref _dDirection);
          flag1 = true;
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ProposedElementSet));
          if (elm_set.Size > 0)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
            elm_set.Clear();
          }
          this.m_FamilyInstanceComponentWrapper.ProposedLeg = this.m_FamilyInstanceComponentWrapper.ProposedLeg.MoveLeg(_dDirection, _dDistance);
          this.m_FamilyInstanceComponentWrapper.CreateNewProposedElementSet(this.m_Document);
          if (this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Count > 0)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet));
            this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Clear();
            for (int index = 0; index < this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList.Count; ++index)
            {
              Eps_Leg _Leg = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList[index].MoveLeg(_dDirection, _dDistance);
              this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList[index] = _Leg;
              foreach (ModelCurve newModelCurve in RevitUtility.NewModelCurveArray(this.m_Document, _Leg))
              {
                if (this.m_MassLineSubCategory != null)
                  ((CurveElement) newModelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Add((Element) newModelCurve);
              }
            }
          }
          if (this.m_ParkingLotCurbSiteCompList != null)
          {
            for (int index = 0; index < this.m_ParkingLotCurbSiteCompList.Count; ++index)
            {
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_ParkingLotCurbSiteCompList[index].ProposedElementSet));
              this.m_ParkingLotCurbSiteCompList[index].ProposedLeg = this.m_ParkingLotCurbSiteCompList[index].ProposedLeg.MoveLeg(_dDirection, _dDistance);
              this.m_ParkingLotCurbSiteCompList[index].CreateNewProposedElementSet(this.m_Document);
            }
          }
          this.m_TransactionContainer.EndTransaction();
          if (this.m_AnnotationElevationTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
            this.m_AnnotationElevationTextSet = (ElementSet) null;
          }
          if (this.m_AnnotationGradeTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
            this.m_AnnotationGradeTextSet = (ElementSet) null;
          }
          RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
          _strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
          _FirstPnt = (Eps_Point) null;
        }
        else
        {
          this.m_TransactionContainer.BeginTransaction();
          Eps_Line _Line = new Eps_Line();
          _Line.StartPnt = new Eps_Point(_Point.x + this.m_dMarkerHeight / 2.0, _Point.y, 0.0);
          _Line.EndPnt = new Eps_Point(_Point.x - this.m_dMarkerHeight / 2.0, _Point.y, 0.0);
          ModelCurve modelCurve1 = RevitUtility.NewModelCurve(this.m_Document, _Line);
          elm_set.Insert((Element) modelCurve1);
          _Line.StartPnt = new Eps_Point(_Point.x, _Point.y + this.m_dMarkerHeight / 2.0, 0.0);
          _Line.EndPnt = new Eps_Point(_Point.x, _Point.y - this.m_dMarkerHeight / 2.0, 0.0);
          ModelCurve modelCurve2 = RevitUtility.NewModelCurve(this.m_Document, _Line);
          elm_set.Insert((Element) modelCurve2);
          this.m_TransactionContainer.EndTransaction();
          _strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
          _FirstPnt = _Point;
        }
      }
      this.m_Document.Regenerate();
    }
    if (elm_set.Size > 0)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
    }
    return flag1;
  }

  private bool RotateSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    string _strPrompt = EPShared.LocalRM.GetString("PickRotationPointPrompt");
    bool flag1 = false;
    ElementSet elm_set = new ElementSet();
    Eps_Point _Point = (Eps_Point) null;
    Eps_Point epsPoint = (Eps_Point) null;
    Eps_Point _SecondPnt = (Eps_Point) null;
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    bool flag2 = true;
    while (flag2)
    {
      flag2 = RevitUtility.GetPointFromProject(this.m_Document, _strPrompt, ref _Point, false);
      if (flag2)
      {
        if (_SecondPnt != null)
        {
          flag1 = true;
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsPoint, _SecondPnt, ref _dDirection1);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsPoint, _Point, ref _dDirection2);
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ProposedElementSet));
          if (elm_set.Size > 0)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
            elm_set.Clear();
          }
          this.m_FamilyInstanceComponentWrapper.ProposedLeg = this.m_FamilyInstanceComponentWrapper.ProposedLeg.RotateLeg(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection2 - _dDirection1));
          this.m_FamilyInstanceComponentWrapper.CreateNewProposedElementSet(this.m_Document);
          if (this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Count > 0)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet));
            this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Clear();
            for (int index = 0; index < this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList.Count; ++index)
            {
              Eps_Leg _Leg = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList[index].RotateLeg(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection2 - _dDirection1));
              this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList[index] = _Leg;
              foreach (ModelCurve newModelCurve in RevitUtility.NewModelCurveArray(this.m_Document, _Leg))
              {
                if (this.m_MassLineSubCategory != null)
                  ((CurveElement) newModelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Add((Element) newModelCurve);
              }
            }
          }
          if (this.m_ParkingLotCurbSiteCompList != null)
          {
            for (int index = 0; index < this.m_ParkingLotCurbSiteCompList.Count; ++index)
            {
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_ParkingLotCurbSiteCompList[index].ProposedElementSet));
              this.m_ParkingLotCurbSiteCompList[index].ProposedLeg = this.m_ParkingLotCurbSiteCompList[index].ProposedLeg.RotateLeg(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection2 - _dDirection1));
              this.m_ParkingLotCurbSiteCompList[index].CreateNewProposedElementSet(this.m_Document);
            }
          }
          this.m_TransactionContainer.EndTransaction();
          if (this.m_AnnotationElevationTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
            this.m_AnnotationElevationTextSet = (ElementSet) null;
          }
          if (this.m_AnnotationGradeTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
            this.m_AnnotationGradeTextSet = (ElementSet) null;
          }
          RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
          _strPrompt = EPShared.LocalRM.GetString("PickRotationPointPrompt");
          epsPoint = (Eps_Point) null;
          _SecondPnt = (Eps_Point) null;
        }
        else if (epsPoint != null)
        {
          this.m_TransactionContainer.BeginTransaction();
          Eps_Line _Line = new Eps_Line();
          _Line.StartPnt = new Eps_Point(epsPoint);
          _Line.EndPnt = new Eps_Point(_Point);
          ModelCurve modelCurve = RevitUtility.NewModelCurve(this.m_Document, _Line);
          elm_set.Insert((Element) modelCurve);
          this.m_TransactionContainer.EndTransaction();
          _strPrompt = EPShared.LocalRM.GetString("PickSecondPointForRotationPrompt");
          _SecondPnt = _Point;
        }
        else
        {
          this.m_TransactionContainer.BeginTransaction();
          Eps_Line _Line = new Eps_Line();
          _Line.StartPnt = new Eps_Point(_Point.x + this.m_dMarkerHeight / 2.0, _Point.y, 0.0);
          _Line.EndPnt = new Eps_Point(_Point.x - this.m_dMarkerHeight / 2.0, _Point.y, 0.0);
          ModelCurve modelCurve1 = RevitUtility.NewModelCurve(this.m_Document, _Line);
          elm_set.Insert((Element) modelCurve1);
          _Line.StartPnt = new Eps_Point(_Point.x, _Point.y + this.m_dMarkerHeight / 2.0, 0.0);
          _Line.EndPnt = new Eps_Point(_Point.x, _Point.y - this.m_dMarkerHeight / 2.0, 0.0);
          ModelCurve modelCurve2 = RevitUtility.NewModelCurve(this.m_Document, _Line);
          elm_set.Insert((Element) modelCurve2);
          this.m_TransactionContainer.EndTransaction();
          _strPrompt = EPShared.LocalRM.GetString("PickFirstPointForRotationPrompt");
          epsPoint = _Point;
        }
      }
      this.m_Document.Regenerate();
    }
    if (elm_set.Size > 0)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
    }
    return flag1;
  }

  private bool ChangeGradeAndElevationSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    int _nReturnValue = 0;
    bool flag1 = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_Document.PathName, "UseSharedElevation", ref _nReturnValue))
      flag1 = Convert.ToBoolean(_nReturnValue);
    double num1 = 0.0;
    if (flag1)
      num1 = this.m_Document.ActiveProjectLocation.GetProjectPosition(new XYZ()).Elevation;
    List<Eps_Point> _GradeAndElevationPnts = new List<Eps_Point>();
    TopographySurfaceManagement.FindAllGradeAndElevationPointsInIntersection(this.m_Document, this.m_ProposedSurface, this.m_TransactionContainer, this.m_bFindIntersectionStations, this.m_FamilyInstanceComponentWrapper, this.m_AllSiteComponentList, ref _GradeAndElevationPnts);
    string _strPrompt = EPShared.LocalRM.GetString("PickElevationGradePointPrompt");
    Eps_Leg _CompleteLeg = (Eps_Leg) null;
    bool flag2 = false;
    Eps_Point _PickedPoint = (Eps_Point) null;
    bool flag3 = true;
    bool flag4 = false;
    bool _bPickFirstLeg = false;
    while (flag3)
    {
      flag4 = false;
      bool _bPickMiddleSegment = false;
      Eps_Leg _FirstLeg = (Eps_Leg) null;
      Eps_Leg _SecondLeg = (Eps_Leg) null;
      flag3 = RevitUtility.BreakApartLeg(this.m_Document, this.m_TransactionContainer, this.m_dMarkerHeight, this.m_FamilyInstanceComponentWrapper.ProposedLeg, ref _FirstLeg, ref _SecondLeg, ref _bPickFirstLeg, ref _bPickMiddleSegment, ref _PickedPoint, _strPrompt, _GradeAndElevationPnts);
      this.m_Document.Regenerate();
      if (flag3)
      {
        if (!_bPickMiddleSegment)
        {
          ChangeValueForm changeValueForm = new ChangeValueForm(this.m_Document, EPShared.LocalRM.GetString("ChangeElevationDialog"), EPShared.LocalRM.GetString("CurrentElevationDialog"), EPShared.LocalRM.GetString("AMP_NewElevationDialog"), _PickedPoint.z + num1, (UnitType) 0, "HID_SDchangeElevation");
          int num2 = (int) changeValueForm.ShowDialog();
          if (changeValueForm.DialogResult == DialogResult.OK)
          {
            double num3 = changeValueForm.NewUnitFieldValue - num1;
            this.m_FamilyInstanceComponentWrapper.ProposedLeg = (Eps_Leg) null;
            flag2 = true;
            if (_FirstLeg != null)
            {
              bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(_FirstLeg.LegStartPnt, _FirstLeg.LegEndPnt);
              if (_FirstLeg.Last.Line != null)
                _FirstLeg.Last.Line.EndPnt.z = num3;
              else if (_FirstLeg.Last.Arc != null)
              {
                _FirstLeg.Last.Arc.EndPnt.z = num3;
                _FirstLeg.Last.Arc.RadiusPnt.z = (_FirstLeg.Last.Arc.StartPnt.z + _FirstLeg.Last.Arc.EndPnt.z) / 2.0;
              }
              if (_SecondLeg == null && flag5)
              {
                if (_FirstLeg.Line != null)
                  _FirstLeg.Line.StartPnt.z = num3;
                else if (_FirstLeg.Arc != null)
                {
                  _FirstLeg.Arc.StartPnt.z = num3;
                  _FirstLeg.Arc.RadiusPnt.z = (_FirstLeg.Arc.StartPnt.z + _FirstLeg.Arc.EndPnt.z) / 2.0;
                }
              }
              this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.CopyLeg(_FirstLeg);
            }
            if (_SecondLeg != null)
            {
              bool flag6 = EPShared.eplGeoE_ArePntsDuplicates2D(_SecondLeg.LegStartPnt, _SecondLeg.LegEndPnt);
              if (_SecondLeg.Line != null)
                _SecondLeg.Line.StartPnt.z = num3;
              else if (_SecondLeg.Arc != null)
              {
                _SecondLeg.Arc.StartPnt.z = num3;
                _SecondLeg.Arc.RadiusPnt.z = (_SecondLeg.Arc.StartPnt.z + _SecondLeg.Arc.EndPnt.z) / 2.0;
              }
              if (_FirstLeg == null && flag6)
              {
                if (_SecondLeg.Last.Line != null)
                  _SecondLeg.Last.Line.EndPnt.z = num3;
                else if (_SecondLeg.Last.Arc != null)
                {
                  _SecondLeg.Last.Arc.EndPnt.z = num3;
                  _SecondLeg.Last.Arc.RadiusPnt.z = (_SecondLeg.Last.Arc.StartPnt.z + _SecondLeg.Last.Arc.EndPnt.z) / 2.0;
                }
              }
              for (_CompleteLeg = _SecondLeg; _CompleteLeg != null; _CompleteLeg = _CompleteLeg.Next)
              {
                if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.SingleLeg(_CompleteLeg);
                else
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
              }
            }
          }
        }
        else
        {
          double _dDistance = 0.0;
          double num4 = 0.0;
          double _dCurrentValue;
          if (_bPickFirstLeg)
          {
            if (_FirstLeg.Last.Line != null)
            {
              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstLeg.Last.Line.StartPnt, _SecondLeg.Line.EndPnt, ref _dDistance);
              num4 = _FirstLeg.Last.Line.StartPnt.z - _SecondLeg.Line.EndPnt.z;
            }
            else if (_FirstLeg.Last.Arc != null)
            {
              _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_FirstLeg.Last.Arc.Radius, 2.0 * _FirstLeg.Last.Arc.Delta);
              num4 = _FirstLeg.Last.Arc.StartPnt.z - _SecondLeg.Arc.EndPnt.z;
            }
            _dCurrentValue = num4 / _dDistance;
          }
          else
          {
            if (_SecondLeg.Line != null)
            {
              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstLeg.Last.Line.StartPnt, _SecondLeg.Line.EndPnt, ref _dDistance);
              num4 = _SecondLeg.Line.EndPnt.z - _FirstLeg.Last.Line.StartPnt.z;
            }
            else if (_SecondLeg.Arc != null)
            {
              _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_SecondLeg.Arc.Radius, 2.0 * _SecondLeg.Arc.Delta);
              num4 = _SecondLeg.Arc.EndPnt.z - _FirstLeg.Last.Arc.StartPnt.z;
            }
            _dCurrentValue = num4 / _dDistance;
          }
          ChangeValueForm changeValueForm = new ChangeValueForm(this.m_Document, EPShared.LocalRM.GetString("ChangeGradeDialog"), EPShared.LocalRM.GetString("CurrentGradeDialog"), EPShared.LocalRM.GetString("AMP_NewGradeDialog"), _dCurrentValue, (UnitType) 59, "HID_SDchangeGrade");
          int num5 = (int) changeValueForm.ShowDialog();
          if (changeValueForm.DialogResult == DialogResult.OK)
          {
            double newUnitFieldValue = changeValueForm.NewUnitFieldValue;
            this.m_FamilyInstanceComponentWrapper.ProposedLeg = (Eps_Leg) null;
            flag2 = true;
            double num6 = newUnitFieldValue * _dDistance;
            Eps_Point epsPoint1 = new Eps_Point();
            Eps_Point epsPoint2 = new Eps_Point();
            if (_FirstLeg != null)
            {
              for (_CompleteLeg = _FirstLeg; _CompleteLeg.Next != null; _CompleteLeg = _CompleteLeg.Next)
              {
                if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.SingleLeg(_CompleteLeg);
                else
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
              }
              if (_CompleteLeg.Line != null)
              {
                if (_bPickFirstLeg)
                {
                  epsPoint1.x = _CompleteLeg.Line.StartPnt.x;
                  epsPoint1.y = _CompleteLeg.Line.StartPnt.y;
                  epsPoint1.z = _SecondLeg.Line.EndPnt.z + num6;
                }
                else
                  epsPoint1 = new Eps_Point(_CompleteLeg.Line.StartPnt);
              }
              else if (_CompleteLeg.Arc != null)
              {
                if (_bPickFirstLeg)
                {
                  epsPoint1.x = _CompleteLeg.Arc.StartPnt.x;
                  epsPoint1.y = _CompleteLeg.Arc.StartPnt.y;
                  epsPoint1.z = _SecondLeg.Arc.EndPnt.z + num6;
                }
                else
                  epsPoint1 = new Eps_Point(_CompleteLeg.Arc.StartPnt);
              }
              if (_bPickFirstLeg && this.m_FamilyInstanceComponentWrapper.ProposedLeg != null && this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last != null)
              {
                if (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Line != null)
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Line.EndPnt = epsPoint1;
                else if (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc != null)
                {
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.EndPnt = epsPoint1;
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.RadiusPnt.z = (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.StartPnt.z + this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.EndPnt.z) / 2.0;
                }
              }
            }
            if (_SecondLeg != null)
            {
              if (_SecondLeg.Line != null)
              {
                if (!_bPickFirstLeg)
                {
                  epsPoint2.x = _SecondLeg.Line.EndPnt.x;
                  epsPoint2.y = _SecondLeg.Line.EndPnt.y;
                  epsPoint2.z = num6 + _CompleteLeg.Line.StartPnt.z;
                }
                else
                  epsPoint2 = new Eps_Point(_SecondLeg.Line.EndPnt);
                _CompleteLeg = new Eps_Leg();
                _CompleteLeg.Line = new Eps_Line();
                _CompleteLeg.Line.StartPnt = epsPoint1;
                _CompleteLeg.Line.EndPnt = epsPoint2;
              }
              else if (_SecondLeg.Arc != null)
              {
                if (!_bPickFirstLeg)
                {
                  epsPoint2.x = _SecondLeg.Arc.EndPnt.x;
                  epsPoint2.y = _SecondLeg.Arc.EndPnt.y;
                  epsPoint2.z = num6 + _CompleteLeg.Arc.StartPnt.z;
                }
                else
                  epsPoint2 = new Eps_Point(_SecondLeg.Arc.EndPnt);
                _CompleteLeg = new Eps_Leg();
                _CompleteLeg.Arc = new Eps_Arc(_SecondLeg.Arc);
                _CompleteLeg.Arc.Delta *= 2.0;
                _CompleteLeg.Arc.StartPnt = epsPoint1;
                _CompleteLeg.Arc.EndPnt = epsPoint2;
                _CompleteLeg.Arc.RadiusPnt.z = (_CompleteLeg.Arc.StartPnt.z + _CompleteLeg.Arc.EndPnt.z) / 2.0;
              }
              if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
                this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.SingleLeg(_CompleteLeg);
              else
                this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
              if (!_bPickFirstLeg && _SecondLeg.Next != null)
              {
                if (_SecondLeg.Next.Line != null)
                  _SecondLeg.Next.Line.StartPnt = epsPoint2;
                else if (_SecondLeg.Next.Arc != null)
                {
                  _SecondLeg.Next.Arc.StartPnt = epsPoint2;
                  _SecondLeg.Next.Arc.RadiusPnt.z = (_SecondLeg.Next.Arc.StartPnt.z + _SecondLeg.Next.Arc.EndPnt.z) / 2.0;
                }
              }
              for (_CompleteLeg = _SecondLeg.Next; _CompleteLeg != null; _CompleteLeg = _CompleteLeg.Next)
              {
                if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.SingleLeg(_CompleteLeg);
                else
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
              }
            }
            if (this.m_FamilyInstanceComponentWrapper.ProposedLeg != null && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegStartPnt, this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegEndPnt) && !EPShared.eplGeoE_ArePntsDuplicates3D(this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegStartPnt, this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegEndPnt))
            {
              if (_bPickFirstLeg)
              {
                if (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Line != null)
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Line.EndPnt.z = this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegStartPnt.z;
                else if (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc != null)
                {
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.EndPnt.z = this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegStartPnt.z;
                  this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.RadiusPnt.z = (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.StartPnt.z + this.m_FamilyInstanceComponentWrapper.ProposedLeg.Last.Arc.EndPnt.z) / 2.0;
                }
              }
              else if (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Line != null)
                this.m_FamilyInstanceComponentWrapper.ProposedLeg.Line.StartPnt.z = this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegEndPnt.z;
              else if (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Arc != null)
              {
                this.m_FamilyInstanceComponentWrapper.ProposedLeg.Arc.StartPnt.z = this.m_FamilyInstanceComponentWrapper.ProposedLeg.LegEndPnt.z;
                this.m_FamilyInstanceComponentWrapper.ProposedLeg.Arc.RadiusPnt.z = (this.m_FamilyInstanceComponentWrapper.ProposedLeg.Arc.StartPnt.z + this.m_FamilyInstanceComponentWrapper.ProposedLeg.Arc.EndPnt.z) / 2.0;
              }
            }
          }
        }
        if (this.m_AnnotationElevationTextSet != null)
        {
          this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
          this.m_AnnotationElevationTextSet = (ElementSet) null;
        }
        if (this.m_AnnotationGradeTextSet != null)
        {
          this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
          this.m_AnnotationGradeTextSet = (ElementSet) null;
        }
        RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
      }
    }
    return flag2;
  }

  private bool AddVertexSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    string _strPrompt = EPShared.LocalRM.GetString("PickAddVertexPointPrompt");
    bool flag1 = false;
    Eps_Point _Point = (Eps_Point) null;
    Eps_Leg _NewLegList = (Eps_Leg) null;
    bool flag2 = true;
    while (flag2)
    {
      flag2 = RevitUtility.GetPointFromProject(this.m_Document, _strPrompt, ref _Point, false);
      if (flag2)
      {
        if (RevitGeometry.AddVertexToLegList(this.m_FamilyInstanceComponentWrapper.ProposedLeg, _Point, ref _NewLegList) != 1)
        {
          flag1 = true;
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ProposedElementSet));
          this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.CopyLeg(_NewLegList);
          this.m_FamilyInstanceComponentWrapper.CreateNewProposedElementSet(this.m_Document);
          if (this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Count > 0)
          {
            ElementSet elm_set = new ElementSet();
            List<Eps_Point> epsPointList = new List<Eps_Point>();
            for (int index = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList.Count - 1; index >= 0; --index)
            {
              List<Eps_Point> pointsAtIntervals = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList[index].GetPointsAtIntervals(1.0, 1.0);
              int count = pointsAtIntervals.Count;
              RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
              if (pointsAtIntervals.Count < count)
              {
                ElementSet elementSet = this.m_FamilyInstanceComponentWrapper.RemoveBreaklineAndElementsFromList(index);
                if (elementSet != null)
                {
                  foreach (Element element in elementSet)
                    elm_set.Insert(element);
                }
              }
              pointsAtIntervals.Clear();
            }
            if (elm_set.Size > 0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BreaklinesNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
            }
          }
          this.m_TransactionContainer.EndTransaction();
          if (this.m_AnnotationElevationTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
            this.m_AnnotationElevationTextSet = (ElementSet) null;
          }
          if (this.m_AnnotationGradeTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
            this.m_AnnotationGradeTextSet = (ElementSet) null;
          }
          RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
          _NewLegList = (Eps_Leg) null;
        }
        else
          continue;
      }
      this.m_Document.Regenerate();
    }
    return flag1;
  }

  private bool DeleteVertexSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    string _strPrompt = EPShared.LocalRM.GetString("PickDeleteVertexPointPrompt");
    bool flag1 = false;
    Eps_Leg _ReturnLeg = (Eps_Leg) null;
    bool flag2 = true;
    while (flag2)
    {
      flag2 = RevitUtility.RemoveLegFromLegList(this.m_Document, this.m_TransactionContainer, this.m_dMarkerHeight, this.m_FamilyInstanceComponentWrapper.ProposedLeg, ref _ReturnLeg, false, _strPrompt);
      if (flag2)
      {
        if (_ReturnLeg != null && _ReturnLeg.LegCount > 0)
        {
          flag1 = true;
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ProposedElementSet));
          this.m_FamilyInstanceComponentWrapper.ProposedLeg = Eps_Leg.CopyLeg(_ReturnLeg);
          this.m_FamilyInstanceComponentWrapper.CreateNewProposedElementSet(this.m_Document);
          if (this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.Count > 0)
          {
            ElementSet elm_set = new ElementSet();
            List<Eps_Point> epsPointList = new List<Eps_Point>();
            for (int index = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList.Count - 1; index >= 0; --index)
            {
              List<Eps_Point> pointsAtIntervals = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList[index].GetPointsAtIntervals(1.0, 1.0);
              int count = pointsAtIntervals.Count;
              RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
              if (pointsAtIntervals.Count < count)
              {
                ElementSet elementSet = this.m_FamilyInstanceComponentWrapper.RemoveBreaklineAndElementsFromList(index);
                if (elementSet != null)
                {
                  foreach (Element element in elementSet)
                    elm_set.Insert(element);
                }
              }
              pointsAtIntervals.Clear();
            }
            if (elm_set.Size > 0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BreaklinesNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
            }
          }
          this.m_TransactionContainer.EndTransaction();
          if (this.m_AnnotationElevationTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
            this.m_AnnotationElevationTextSet = (ElementSet) null;
          }
          if (this.m_AnnotationGradeTextSet != null)
          {
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
            this.m_AnnotationGradeTextSet = (ElementSet) null;
          }
          RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
          _ReturnLeg = (Eps_Leg) null;
        }
        else if (this.DeleteSiteAlignmentElement())
        {
          flag1 = true;
          flag2 = false;
        }
        this.m_Document.Regenerate();
      }
      this.m_Document.Regenerate();
    }
    return flag1;
  }

  private bool DeleteSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    bool flag = false;
    if (RevitMessageBox.Show(EPShared.LocalRM.GetString("DeleteSiteComponentLineMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.ProposedElementSet));
      this.m_TransactionContainer.EndTransaction();
      this.m_FamilyInstanceComponentWrapper.ProposedLeg = (Eps_Leg) null;
      this.m_FamilyInstanceComponentWrapper.ProposedElementSet = (ElementSet) null;
      if (this.m_AnnotationElevationTextSet != null)
      {
        this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
        this.m_AnnotationElevationTextSet = (ElementSet) null;
      }
      if (this.m_AnnotationGradeTextSet != null)
      {
        this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
        this.m_AnnotationGradeTextSet = (ElementSet) null;
      }
      flag = true;
    }
    return flag;
  }

  private bool ChangeTypeSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    FamilyInstance existingFamilyInstance = this.m_FamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance == null)
      return false;
    bool flag1 = false;
    if (this.m_CurrentFamilyType != LandcaddID.FeatureLine && this.m_CurrentFamilyType != LandcaddID.PointWipeout)
    {
      FamilySymbol proposedFamilySymbol = this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol;
      string _strCurrentTypeValue = string.Empty;
      string _strCurrentFamilyValue = string.Empty;
      if (proposedFamilySymbol != null)
      {
        _strCurrentTypeValue = ((Element) proposedFamilySymbol).Name;
        if (proposedFamilySymbol.Family != null)
          _strCurrentFamilyValue = ((Element) proposedFamilySymbol.Family).Name;
      }
      ChangeFamilyTypeForm changeFamilyTypeForm = new ChangeFamilyTypeForm(this.m_Document, this.m_TransactionContainer, _strCurrentFamilyValue, _strCurrentTypeValue, this.m_CurrentFamilyType);
      int num = (int) changeFamilyTypeForm.ShowDialog();
      if (changeFamilyTypeForm.DialogResult == DialogResult.OK && changeFamilyTypeForm.NewTypeValue != null)
      {
        bool flag2 = false;
        if (this.m_CurrentFamilyType == LandcaddID.RetainingWall)
        {
          Parameter parameter = ((Element) changeFamilyTypeForm.NewTypeValue).LookupParameter(RevitParameters.RetainingWallSlopeProjectionParameter);
          if (parameter != null)
            flag2 = parameter.AsInteger() == 1;
          if (flag2)
          {
            if (!RevitUtility.PickSideLeg(this.m_Document, this.m_FamilyInstanceComponentWrapper.ProposedLeg, ref this.m_bRetainingWallUseRightLeg, EPShared.LocalRM.GetString("PickSideForGradeToPlaceMessage")))
              return false;
          }
        }
        this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol = changeFamilyTypeForm.NewTypeValue;
        flag1 = true;
      }
    }
    else
    {
      Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LinearPointIntervalParameter);
      if (parameter != null)
      {
        ChangeValueForm changeValueForm = new ChangeValueForm(this.m_Document, EPShared.LocalRM.GetString("ChangeLinearIntervalDialog"), EPShared.LocalRM.GetString("CurrentLinearDialog"), EPShared.LocalRM.GetString("AMP_NewLinearDialog"), parameter.AsDouble(), (UnitType) 0, "HID_SDaaa");
        int num = (int) changeValueForm.ShowDialog();
        if (changeValueForm.DialogResult == DialogResult.OK)
        {
          ElementSet instanceElementSet = this.m_FamilyInstanceComponentWrapper.GetFamilyInstanceElementSet();
          if (instanceElementSet != null && instanceElementSet.Size > 0)
          {
            foreach (Element element in instanceElementSet)
              element.LookupParameter(RevitParameters.LinearPointIntervalParameter)?.Set(changeValueForm.NewUnitFieldValue);
            flag1 = true;
          }
        }
      }
    }
    this.m_Document.Regenerate();
    return flag1;
  }

  private bool AddBreaklinesToSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null)
      return false;
    Eps_Leg _EvalLeg = (Eps_Leg) null;
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    string empty = string.Empty;
    bool alignmentElement = false;
    DialogResult dialogResult = DialogResult.Retry;
    AddBreaklineForm addBreaklineForm = new AddBreaklineForm(this.m_Document);
    while (dialogResult == DialogResult.Retry)
    {
      int num1 = (int) addBreaklineForm.ShowDialog();
      dialogResult = addBreaklineForm.DialogResult;
      if (dialogResult == DialogResult.Retry)
      {
        string _strText = EPShared.LocalRM.GetString("PointNotInParkingLotBoundaryMessage");
        TopographySurfaceContainer surfaceContainer = this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface;
        if (surfaceContainer == null)
        {
          _strText = EPShared.LocalRM.GetString("PointNotInProposedBoundaryMessage");
          surfaceContainer = this.m_ProposedSurface;
        }
        Eps_Point _Point = new Eps_Point();
        RevitUtility.GetPointFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPointPrompt"), ref _Point, false);
        double _dElevation = 0.0;
        if (surfaceContainer.GetSurfaceContainingPoint(_Point, ref _dElevation) != null)
        {
          addBreaklineForm.SetFocusedElevation(_dElevation);
        }
        else
        {
          int num2 = (int) RevitMessageBox.Show(_strText, EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
      }
      else if (dialogResult == DialogResult.OK)
      {
        List<Element> collection = new List<Element>();
        if (!addBreaklineForm.ExistingHostLineChecked)
        {
          string _strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
          Eps_Leg _CompleteLeg1 = (Eps_Leg) null;
          Eps_Point _Point = (Eps_Point) null;
          Eps_Point epsPoint = (Eps_Point) null;
          bool flag = true;
          while (flag)
          {
            flag = RevitUtility.GetPointFromProject(this.m_Document, _strPrompt, ref _Point, false);
            if (flag)
            {
              if (epsPoint != null)
              {
                _CompleteLeg1 = new Eps_Leg();
                Eps_Leg epsLeg;
                if (_EvalLeg == null)
                {
                  _CompleteLeg1.Line = new Eps_Line();
                  _CompleteLeg1.Line.StartPnt = epsPoint;
                  _CompleteLeg1.Line.EndPnt = _Point;
                  epsLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
                  _EvalLeg = Eps_Leg.SingleLeg(epsLeg);
                }
                else
                {
                  Eps_Line _pOut = new Eps_Line();
                  _pOut.StartPnt = epsPoint;
                  _pOut.EndPnt = _Point;
                  double radius = addBreaklineForm.Radius;
                  Eps_Arc _pArc = new Eps_Arc();
                  if (RevitGeometry.SolveArcFromTangentLines(_EvalLeg.Last.Line, _pOut, radius, ref _pArc, true) == 0)
                  {
                    _CompleteLeg1.Line = new Eps_Line();
                    _CompleteLeg1.Line.StartPnt = new Eps_Point(_EvalLeg.Last.Line.StartPnt);
                    _CompleteLeg1.Line.EndPnt = new Eps_Point(_pArc.StartPnt);
                    epsLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
                    epsLeg.Last.Next = Eps_Leg.SingleLeg(new Eps_Leg()
                    {
                      Arc = new Eps_Arc(_pArc)
                    });
                    _CompleteLeg1 = new Eps_Leg();
                    _CompleteLeg1.Line = new Eps_Line();
                    _CompleteLeg1.Line.StartPnt = new Eps_Point(_pArc.EndPnt);
                    _CompleteLeg1.Line.EndPnt = _Point;
                    epsLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
                    Eps_Leg _CompleteLeg2 = Eps_Leg.CopyLeg(_EvalLeg);
                    _EvalLeg = (Eps_Leg) null;
                    for (; _CompleteLeg2.Next != null; _CompleteLeg2 = _CompleteLeg2.Next)
                    {
                      if (_EvalLeg == null)
                        _EvalLeg = Eps_Leg.SingleLeg(_CompleteLeg2);
                      else
                        _EvalLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
                    }
                    if (_EvalLeg == null)
                      _EvalLeg = Eps_Leg.CopyLeg(epsLeg);
                    else
                      _EvalLeg.Last.Next = Eps_Leg.CopyLeg(epsLeg);
                  }
                  else
                  {
                    _CompleteLeg1.Line = _pOut;
                    epsLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
                    _EvalLeg.Last.Next = Eps_Leg.SingleLeg(epsLeg);
                  }
                  if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLeg.LegStartPnt, _EvalLeg.LegEndPnt))
                    flag = false;
                }
                this.m_TransactionContainer.BeginTransaction();
                if (epsLeg.LegCount > 1 && collection.Count > 0)
                {
                  this.m_Document.Delete(collection[collection.Count - 1].Id);
                  collection.RemoveAt(collection.Count - 1);
                }
                foreach (ModelCurve newModelCurve in RevitUtility.NewModelCurveArray(this.m_Document, epsLeg))
                {
                  if (this.m_MassLineSubCategory != null)
                    ((CurveElement) newModelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                  collection.Add((Element) newModelCurve);
                }
                this.m_Document.Regenerate();
                this.m_TransactionContainer.EndTransaction();
                if (addBreaklineForm.SegmentChecked)
                  flag = false;
              }
              else
                _strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
              epsPoint = _Point;
            }
          }
          if (_EvalLeg != null && _EvalLeg.IsLegClosed())
          {
            Eps_Arc _pArc = new Eps_Arc();
            double radius = addBreaklineForm.Radius;
            if (RevitGeometry.SolveArcFromTangentLines(_EvalLeg.Last.Line, _EvalLeg.Line, radius, ref _pArc, true) == 0)
            {
              _CompleteLeg1.Line = new Eps_Line();
              _CompleteLeg1.Line.StartPnt = new Eps_Point(_EvalLeg.Last.Line.StartPnt);
              _CompleteLeg1.Line.EndPnt = new Eps_Point(_pArc.StartPnt);
              Eps_Leg _CompleteLeg3 = Eps_Leg.SingleLeg(_CompleteLeg1);
              _CompleteLeg3.Last.Next = Eps_Leg.SingleLeg(new Eps_Leg()
              {
                Arc = new Eps_Arc(_pArc)
              });
              Eps_Leg _CompleteLeg4 = Eps_Leg.CopyLeg(_EvalLeg);
              _EvalLeg = (Eps_Leg) null;
              for (; _CompleteLeg4.Next != null; _CompleteLeg4 = _CompleteLeg4.Next)
              {
                if (_EvalLeg == null)
                {
                  Eps_Leg _CompleteLeg5 = new Eps_Leg();
                  _CompleteLeg5.Line = new Eps_Line();
                  _CompleteLeg5.Line.StartPnt = new Eps_Point(_pArc.EndPnt);
                  _CompleteLeg5.Line.EndPnt = new Eps_Point(_CompleteLeg4.Line.EndPnt);
                  _EvalLeg = Eps_Leg.SingleLeg(_CompleteLeg5);
                }
                else
                  _EvalLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg4);
              }
              if (_EvalLeg == null)
                _EvalLeg = Eps_Leg.CopyLeg(_CompleteLeg3);
              else
                _EvalLeg.Last.Next = Eps_Leg.CopyLeg(_CompleteLeg3);
              foreach (Element element in collection)
                this.m_Document.Delete(element.Id);
              collection.Clear();
              foreach (ModelCurve newModelCurve in RevitUtility.NewModelCurveArray(this.m_Document, _EvalLeg, this.m_Document.ActiveView, false))
              {
                if (this.m_MassLineSubCategory != null)
                  ((CurveElement) newModelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                collection.Add((Element) newModelCurve);
              }
            }
          }
          List<Eps_Point> pointsAtIntervals = _EvalLeg.GetPointsAtIntervals(1.0, 1.0);
          int count = pointsAtIntervals.Count;
          RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
          if (pointsAtIntervals.Count < count)
          {
            int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PointsNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
            foreach (Element element in collection)
              this.m_Document.Delete(element.Id);
            return false;
          }
        }
        else
        {
          if (this.m_LineElementSet != null && this.m_LineElementSet.Size > 0)
          {
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_LineElementSet));
            this.m_TransactionContainer.EndTransaction();
          }
          this.m_Document.Regenerate();
          ElementSet elm_set = new ElementSet();
          ElementSet _Elements = (ElementSet) null;
          if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
            return false;
          foreach (Element _LocationElement in _Elements)
          {
            if (_LocationElement.Location is LocationCurve location)
            {
              Curve curve = location.Curve;
              if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
              {
                if (addBreaklineForm.ChainChecked)
                  _EvalLeg = RevitGeometry.GetLegFromElementList((Eps_Leg) null, _LocationElement);
                if (_EvalLeg != null)
                {
                  List<Eps_Point> pointsAtIntervals = _EvalLeg.GetPointsAtIntervals(1.0, 1.0);
                  int count = pointsAtIntervals.Count;
                  RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
                  if (pointsAtIntervals.Count < count)
                  {
                    int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PointsNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
                    return false;
                  }
                  if (!addBreaklineForm.RelativeElevationChecked && !RevitDefines.EQ(addBreaklineForm.GetGrade(RevitGeometry.eplGeoE_CalcLegListLength(_EvalLeg)), 0.0) && !RevitUtility.EvaluateLeg(this.m_Document, this.m_TransactionContainer, 20.0, ref _EvalLeg))
                    return false;
                  elm_set = _EvalLeg.ElementSet;
                  foreach (ModelCurve newModelCurve in RevitUtility.NewModelCurveArray(this.m_Document, _EvalLeg, this.m_Document.ActiveView, false))
                  {
                    if (this.m_MassLineSubCategory != null)
                      ((CurveElement) newModelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                    collection.Add((Element) newModelCurve);
                  }
                }
                else
                {
                  switch (curve)
                  {
                    case Arc _:
                      Eps_Arc _EvalArc = new Eps_Arc((Arc) curve);
                      double _dLegListLength = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_EvalArc.Radius, _EvalArc.Delta);
                      if (!addBreaklineForm.RelativeElevationChecked && !RevitDefines.EQ(addBreaklineForm.GetGrade(_dLegListLength), 0.0) && !RevitUtility.EvaluateArc(this.m_Document, this.m_TransactionContainer, 20.0, ref _EvalArc))
                        return false;
                      _EvalLeg = new Eps_Leg();
                      _EvalLeg.Arc = new Eps_Arc(_EvalArc);
                      List<Eps_Point> pointsAtIntervals1 = _EvalLeg.GetPointsAtIntervals(1.0, 1.0);
                      int count1 = pointsAtIntervals1.Count;
                      RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals1, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
                      if (pointsAtIntervals1.Count < count1)
                      {
                        int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PointsNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
                        return false;
                      }
                      elm_set.Insert(_LocationElement);
                      ModelCurve modelCurve1 = RevitUtility.NewModelCurve(this.m_Document, _EvalArc);
                      if (this.m_MassLineSubCategory != null)
                        ((CurveElement) modelCurve1).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                      collection.Add((Element) modelCurve1);
                      break;
                    case Line _:
                      Eps_Line _EvalLine = new Eps_Line((Line) curve);
                      double _dDistance = 0.0;
                      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLine.EndPnt, _EvalLine.StartPnt, ref _dDistance);
                      if (!addBreaklineForm.RelativeElevationChecked && !RevitDefines.EQ(addBreaklineForm.GetGrade(_dDistance), 0.0) && !RevitUtility.EvaluateLine(this.m_Document, this.m_TransactionContainer, 20.0, ref _EvalLine))
                        return false;
                      _EvalLeg = new Eps_Leg();
                      _EvalLeg.Line = new Eps_Line(_EvalLine);
                      List<Eps_Point> pointsAtIntervals2 = _EvalLeg.GetPointsAtIntervals(1.0, 1.0);
                      int count2 = pointsAtIntervals2.Count;
                      RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals2, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
                      if (pointsAtIntervals2.Count < count2)
                      {
                        int num6 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PointsNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
                        return false;
                      }
                      elm_set.Insert(_LocationElement);
                      ModelCurve modelCurve2 = RevitUtility.NewModelCurve(this.m_Document, _EvalLine);
                      if (this.m_MassLineSubCategory != null)
                        ((CurveElement) modelCurve2).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
                      collection.Add((Element) modelCurve2);
                      break;
                    default:
                      int num7 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                      return false;
                  }
                }
                List<Eps_Point> pointsAtIntervals3 = _EvalLeg.GetPointsAtIntervals(1.0, 1.0);
                int count3 = pointsAtIntervals3.Count;
                RevitGeometry.GetAllPointsInBoundary(ref pointsAtIntervals3, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
                if (pointsAtIntervals3.Count < count3)
                {
                  int num8 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PointsNotInParkingLotBoundaryMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
                  return false;
                }
                if (elm_set.Size > 0)
                {
                  foreach (Element element in elm_set)
                  {
                    if (this.m_LineElementSet != null && this.m_LineElementSet.Size > 0 && this.m_LineElementSet.Contains(element))
                      this.m_LineElementSet.Erase(element);
                  }
                  this.m_TransactionContainer.BeginTransaction();
                  this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
                  this.m_TransactionContainer.EndTransaction();
                }
              }
              else
              {
                int num9 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
            }
          }
        }
        if (_EvalLeg != null)
        {
          _EvalLeg = !addBreaklineForm.RelativeElevationChecked ? _EvalLeg.ApplyElevationsToLeg(addBreaklineForm.BeginningElevation, addBreaklineForm.GetGrade(RevitGeometry.eplGeoE_CalcLegListLength(_EvalLeg))) : _EvalLeg.ApplyElevationsToLeg(this.m_FamilyInstanceComponentWrapper.ParkingLotTopographySurface, true, false, addBreaklineForm.BeginningElevation);
          this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList.Add(_EvalLeg);
          if (collection.Count > 0)
          {
            this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList.AddRange((IEnumerable<Element>) collection);
            for (int index = 0; index < collection.Count; ++index)
              this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineLinearPointIntervals.Add(addBreaklineForm.LinearInterval);
          }
          alignmentElement = true;
        }
      }
    }
    return alignmentElement;
  }

  private bool DeleteBreaklinesFromSiteAlignmentElement()
  {
    if (this.m_FamilyInstanceComponentWrapper.ProposedLeg == null || this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet == null || this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet.Size == 0)
      return false;
    bool flag = false;
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
      return false;
    foreach (Element element in _Elements)
    {
      foreach (Element breaklineElement in this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList)
      {
        if (string.Compare(element.UniqueId, breaklineElement.UniqueId, true) == 0)
        {
          int indexFromElementId = this.m_FamilyInstanceComponentWrapper.FindBreaklineIndexFromElementId(breaklineElement);
          if (indexFromElementId >= 0)
          {
            flag = true;
            ElementSet elm_set = this.m_FamilyInstanceComponentWrapper.RemoveBreaklineAndElementsFromList(indexFromElementId);
            if (elm_set != null)
            {
              if (elm_set.Size > 0)
              {
                this.m_TransactionContainer.BeginTransaction();
                this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
                this.m_TransactionContainer.EndTransaction();
                break;
              }
              break;
            }
            break;
          }
          break;
        }
      }
    }
    this.m_Document.Regenerate();
    return flag;
  }

  private bool ChangeViewScale()
  {
    bool flag = false;
    ChangeValueForm changeValueForm = new ChangeValueForm(this.m_Document, EPShared.LocalRM.GetString("ChangeViewScaleDialog"), EPShared.LocalRM.GetString("CurrentViewScaleDialog"), EPShared.LocalRM.GetString("AMP_NewViewScaleDialog"), this.m_Document.ActiveView.Scale, true, "HID_SDchangeViewScale");
    int num = (int) changeValueForm.ShowDialog();
    if (changeValueForm.DialogResult == DialogResult.OK && this.m_Document.ActiveView.Scale != changeValueForm.NewIntegerFieldValue)
    {
      flag = true;
      this.m_Document.ActiveView.Scale = changeValueForm.NewIntegerFieldValue;
      if (this.m_AnnotationElevationTextSet != null)
      {
        this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationElevationTextSet));
        this.m_AnnotationElevationTextSet = (ElementSet) null;
      }
      if (this.m_AnnotationGradeTextSet != null)
      {
        this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AnnotationGradeTextSet));
        this.m_AnnotationGradeTextSet = (ElementSet) null;
      }
      RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper, false, ref this.m_AnnotationElevationTextSet, ref this.m_AnnotationGradeTextSet);
      this.m_Document.Regenerate();
    }
    return flag;
  }

  private bool ApplySiteAlignmentElementUpdate()
  {
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = true;
    string strA = string.Empty;
    string _strFormUniqueId1 = string.Empty;
    string _strFormUniqueId2 = string.Empty;
    string _strFormUniqueId3 = string.Empty;
    string _strFormUniqueId4 = string.Empty;
    Eps_Leg epsLeg = (Eps_Leg) null;
    TopographySurfaceContainer _ParkingLotSurface = (TopographySurfaceContainer) null;
    List<Eps_Point> epsPointList = (List<Eps_Point>) null;
    if (this.m_FamilyInstanceComponentWrapper != null)
    {
      List<Element> _ElementList = new List<Element>();
      List<FamilyInstanceComponentContainer> familyContainerList = this.m_FamilyInstanceComponentWrapper.FamilyContainerList;
      for (int index = 0; index < familyContainerList.Count; ++index)
      {
        _ElementList.Insert(0, familyContainerList[index].Element);
        _ElementList.Add((Element) familyContainerList[index].FamilyInstance);
        if (_strFormUniqueId1 == string.Empty)
        {
          Parameter parameter = ((Element) familyContainerList[index].FamilyInstance).LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
          if (parameter != null && parameter.AsString() != string.Empty)
            _strFormUniqueId1 = parameter.AsString();
        }
        if (_strFormUniqueId2 == string.Empty)
        {
          Parameter parameter = ((Element) familyContainerList[index].FamilyInstance).LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
          if (parameter != null && parameter.AsString() != string.Empty)
            _strFormUniqueId2 = parameter.AsString();
        }
        if (_strFormUniqueId3 == string.Empty)
        {
          Parameter parameter = ((Element) familyContainerList[index].FamilyInstance).LookupParameter(RevitParameters.IslandSurfaceIdFamilyParameter);
          if (parameter != null && parameter.AsString() != string.Empty)
            _strFormUniqueId3 = parameter.AsString();
        }
        if (_strFormUniqueId4 == string.Empty)
        {
          Parameter parameter = ((Element) familyContainerList[index].FamilyInstance).LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
          if (parameter != null && parameter.AsString() != string.Empty)
            _strFormUniqueId4 = parameter.AsString();
        }
        if (index == familyContainerList.Count - 1)
          _ElementList.Add((Element) RevitUtility.FindFamilyTypeSymbol(this.m_Document, familyContainerList[index].FamilyInstance, this.m_CurrentFamilyType));
      }
      if (this.m_FamilyInstanceComponentWrapper.IntersectionFamilySymbol != null)
        _ElementList.Add((Element) this.m_FamilyInstanceComponentWrapper.IntersectionFamilySymbol);
      if (_strFormUniqueId1 != string.Empty)
      {
        DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, _strFormUniqueId1);
        if (directShape != null)
        {
          _ElementList.Add((Element) directShape);
        }
        else
        {
          FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, _strFormUniqueId1);
          if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
            _ElementList.Add((Element) massFamilyInstance.Symbol.Family);
        }
      }
      if (_strFormUniqueId2 != string.Empty)
      {
        DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, _strFormUniqueId2);
        if (directShape != null)
        {
          _ElementList.Add((Element) directShape);
        }
        else
        {
          FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, _strFormUniqueId2);
          if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
            _ElementList.Add((Element) massFamilyInstance.Symbol.Family);
        }
      }
      if (_strFormUniqueId3 != string.Empty)
      {
        TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _strFormUniqueId3);
        if (topoSurfaceInstance != null)
          _ElementList.Add((Element) topoSurfaceInstance);
      }
      if (_strFormUniqueId4 != string.Empty)
      {
        TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _strFormUniqueId4);
        if (topoSurfaceInstance != null)
          _ElementList.Add((Element) topoSurfaceInstance);
      }
      for (int index = 0; index < this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineFamilyInstanceList.Count; ++index)
        _ElementList.Add((Element) this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineFamilyInstanceList[index]);
      for (int index = 0; index < this.m_FamilyInstanceComponentWrapper.IntersectionFamilyInstanceList.Count; ++index)
        _ElementList.Add((Element) this.m_FamilyInstanceComponentWrapper.IntersectionFamilyInstanceList[index]);
      if (this.m_ProposedSurface.TopographySurface != null)
        _ElementList.Insert(0, (Element) this.m_ProposedSurface.TopographySurface);
      if (_ElementList != null && _ElementList.Count > 0 && !TopographySurfaceManagement.VerifyUserCanManipulateElements(this.m_Document, _ElementList))
        return false;
    }
    if (this.m_bDoesMassLineSubCategoryExist && this.m_CurrentFamilyType != LandcaddID.ParkingLot)
      this.GetMassAndLineElements(false);
    if (this.m_FamilyInstanceComponentWrapper != null && this.m_AllSiteComponentList != null)
    {
      if (this.m_CurrentFamilyType == LandcaddID.PointWipeout && this.m_PointWipeoutDisplayForm.ShowAffectedPointsChecked && this.m_FamilyInstanceComponentWrapper.ProposedLeg != null)
      {
        List<Eps_Point> allVertices = this.m_ProposedSurface.GetAllVertices();
        RevitGeometry.GetAllPointsInBoundary(ref allVertices, this.m_FamilyInstanceComponentWrapper.ProposedLeg, (List<Eps_Leg>) null);
        if (allVertices.Count > 0)
        {
          ElementSet elm_set = new ElementSet();
          this.m_TransactionContainer.BeginTransaction();
          for (int index = 0; index < allVertices.Count; ++index)
          {
            Eps_Line _Line = new Eps_Line();
            _Line.StartPnt = new Eps_Point(allVertices[index].x + 5.0, allVertices[index].y, 0.0);
            _Line.EndPnt = new Eps_Point(allVertices[index].x - 5.0, allVertices[index].y, 0.0);
            ModelCurve modelCurve1 = RevitUtility.NewModelCurve(this.m_Document, _Line);
            if (this.m_MassLineSubCategory != null)
              ((CurveElement) modelCurve1).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
            elm_set.Insert((Element) modelCurve1);
            _Line.StartPnt = new Eps_Point(allVertices[index].x, allVertices[index].y + 5.0, 0.0);
            _Line.EndPnt = new Eps_Point(allVertices[index].x, allVertices[index].y - 5.0, 0.0);
            ModelCurve modelCurve2 = RevitUtility.NewModelCurve(this.m_Document, _Line);
            if (this.m_MassLineSubCategory != null)
              ((CurveElement) modelCurve2).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
            elm_set.Insert((Element) modelCurve2);
          }
          this.m_Document.Regenerate();
          this.m_TransactionContainer.EndTransaction();
          if (RevitMessageBox.Show(EPShared.LocalRM.GetString("PointsInBoundaryWillBeRemovedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
            return false;
          if (elm_set.Size > 0)
          {
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
            this.m_TransactionContainer.EndTransaction();
          }
        }
      }
      SitePlacementSettings _PlacementSettings = new SitePlacementSettings();
      FamilyInstanceComponentWrapperComparer componentWrapperComparer = new FamilyInstanceComponentWrapperComparer();
      if (this.m_AllSiteComponentList != null && this.m_AllSiteComponentList.Count > 0)
        this.m_AllSiteComponentList.Sort((IComparer<FamilyInstanceComponentWrapper>) componentWrapperComparer);
      List<Eps_Point> _TopoPointList = new List<Eps_Point>();
      List<Eps_Point> _CrownPointList = new List<Eps_Point>();
      TopographySurfaceManagement.SetupAllIntersectionStationsForSelectedSiteComponent(this.m_Document, this.m_ProposedSurface, this.m_TransactionContainer, this.m_bFindIntersectionStations, ref this.m_FamilyInstanceComponentWrapper, ref this.m_AllSiteComponentList);
      TopographySurfaceManagement.SetupAllIntersectionStationsForAllSiteComponents(this.m_Document, this.m_ProposedSurface, this.m_TransactionContainer, this.m_FamilyInstanceComponentWrapper.ChainID, ref this.m_AllSiteComponentList);
      TopographySurfaceContainer selectedCurbComponent = TopographySurfaceManagement.FindParentSurfaceAndRemovePointsForSelectedCurbComponent(this.m_Document, this.m_ProposedSurface, this.m_FamilyInstanceComponentWrapper, ref _TopoPointList);
      TopographySurfaceContainer _ProposedSurface;
      if (selectedCurbComponent != null && selectedCurbComponent.TopographySurface != null && string.Compare(((Element) this.m_ProposedSurface.TopographySurface).UniqueId, ((Element) selectedCurbComponent.TopographySurface).UniqueId, true) != 0)
      {
        _ProposedSurface = selectedCurbComponent;
        flag3 = false;
      }
      else
      {
        _ProposedSurface = this.m_ProposedSurface;
        _TopoPointList = this.m_BaseSurface.GetAllVertices();
      }
      ProgressBarForm progressBarForm1 = new ProgressBarForm();
      progressBarForm1.ShowForm();
      progressBarForm1.Refresh();
      progressBarForm1.MinValue = 0;
      progressBarForm1.MaxValue = this.m_AllSiteComponentList.Count;
      progressBarForm1.Message = EPShared.LocalRM.GetString("ProgressBarGradingToposurfaceMessage");
      for (int index1 = 0; index1 < this.m_AllSiteComponentList.Count; ++index1)
      {
        ElementSet instanceElementSet = this.m_AllSiteComponentList[index1].GetFamilyInstanceElementSet();
        if (instanceElementSet != null && instanceElementSet.Size != 0)
        {
          FamilyInstance existingFamilyInstance1 = this.m_AllSiteComponentList[index1].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance1 != null && existingFamilyInstance1.Symbol != null)
          {
            _PlacementSettings.PlacementSymbol = existingFamilyInstance1.Symbol;
            Parameter parameter1 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.ProjectInnerSlopesFamilyParameter);
            if (parameter1 != null)
              _PlacementSettings.ProjectInnerSlopes = parameter1.AsInteger();
            Parameter parameter2 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
            if (parameter2 != null && parameter2.AsString() != string.Empty)
              _PlacementSettings.Name = parameter2.AsString();
            Parameter parameter3 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (parameter3 != null && parameter3.AsString() != string.Empty)
            {
              foreach (int num in Enum.GetValues(typeof (LandcaddID)))
              {
                if (string.Compare(parameter3.AsString(), num.ToString("000"), true) == 0)
                {
                  _PlacementSettings.LocateType = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
                  break;
                }
              }
            }
            Parameter parameter4 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.ElevationFamilyParameter);
            if (parameter4 != null)
              _PlacementSettings.Elevation = parameter4.AsDouble();
            Parameter parameter5 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.SiteComponentIsRelativeElevationParameter);
            if (parameter5 != null)
            {
              _PlacementSettings.IsRelativeElevation = false;
              if (parameter5.AsInteger() == 1)
                _PlacementSettings.IsRelativeElevation = true;
            }
            _PlacementSettings.Type = RevitUtility.FindFamilyTypeSymbol(this.m_Document, existingFamilyInstance1, _PlacementSettings.LocateType);
            Parameter parameter6 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
            if (parameter6 != null && !((APIObject) parameter6).IsReadOnly)
              _PlacementSettings.UseRightSide = parameter6.AsInteger() == 1;
            Parameter parameter7 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.LinearPointIntervalParameter);
            if (parameter7 != null)
              _PlacementSettings.LinearPointInterval = parameter7.AsDouble();
            if (this.m_CurrentFamilyType == LandcaddID.RetainingWall)
              _PlacementSettings.UseRightSide = this.m_bRetainingWallUseRightLeg;
            foreach (Element element in instanceElementSet)
            {
              Parameter parameter8 = element.LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
              if (parameter8 != null && parameter8.AsString() != string.Empty)
                _PlacementSettings.LoftFormID = parameter8.AsString();
              Parameter parameter9 = element.LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
              if (parameter9 != null && parameter9.AsString() != string.Empty)
                _PlacementSettings.AdditionalLoftFormID = parameter9.AsString();
              Parameter parameter10 = element.LookupParameter(RevitParameters.IslandSurfaceIdFamilyParameter);
              if (parameter10 != null && parameter10.AsString() != string.Empty)
                _PlacementSettings.IslandSurfaceID = parameter10.AsString();
              Parameter parameter11 = element.LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
              if (parameter11 != null && parameter11.AsString() != string.Empty)
                _PlacementSettings.ParkingLotSurfaceID = parameter11.AsString();
              Parameter parameter12 = element.LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
              if (parameter12 != null && parameter12.AsString() != string.Empty)
                _PlacementSettings.ParentTopoSurfaceID = parameter12.AsString();
            }
            Parameter parameter13 = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
            if (parameter13 != null)
              _PlacementSettings.TopoDrawOrder = parameter13.AsInteger();
          }
          _PlacementSettings.Level = this.m_Document.ActiveView.GenLevel;
          _PlacementSettings.TransactionContainer = this.m_TransactionContainer;
          List<Element> _ElementList = new List<Element>();
          bool flag4 = false;
          List<IntersectionStationContainer> intersectionStations1;
          List<IntersectionStationContainer> intersectionStations2;
          List<IntersectionStationContainer> intersectionStations3;
          List<IntersectionContainer> intersectionContainerList;
          if (string.Compare(this.m_AllSiteComponentList[index1].ChainID, this.m_FamilyInstanceComponentWrapper.ChainID, true) == 0)
          {
            this.m_AllSiteComponentList[index1].ParkingLotBreaklineList = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineList;
            this.m_AllSiteComponentList[index1].ParkingLotBreaklineElementList = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementList;
            this.m_AllSiteComponentList[index1].ParkingLotBreaklineLinearPointIntervals = this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineLinearPointIntervals;
            flag2 = true;
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.GetOriginalElementSet()));
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_FamilyInstanceComponentWrapper.GetFamilyInstanceElementSet()));
            this.m_FamilyInstanceComponentWrapper.FamilyContainerList.Clear();
            if (this.m_FamilyInstanceComponentWrapper.ProposedLeg != null && this.m_FamilyInstanceComponentWrapper.ProposedElementSet != null)
            {
              RevitUtility.HideElementsInAllViews(this.m_Document, this.m_FamilyInstanceComponentWrapper.ProposedElementSet);
            }
            else
            {
              this.m_AllSiteComponentList.RemoveAt(index1);
              --index1;
              flag1 = true;
            }
            if (_PlacementSettings.LoftFormID != string.Empty)
            {
              DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, _PlacementSettings.LoftFormID);
              if (directShape != null)
              {
                this.m_Document.Delete(((Element) directShape).Id);
              }
              else
              {
                FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, _PlacementSettings.LoftFormID);
                if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                  this.m_Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
              }
            }
            if (_PlacementSettings.AdditionalLoftFormID != string.Empty)
            {
              DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, _PlacementSettings.AdditionalLoftFormID);
              if (directShape != null)
              {
                this.m_Document.Delete(((Element) directShape).Id);
              }
              else
              {
                FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, _PlacementSettings.AdditionalLoftFormID);
                if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                  this.m_Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
              }
            }
            if (_PlacementSettings.IslandSurfaceID != string.Empty)
            {
              TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _PlacementSettings.IslandSurfaceID);
              if (topoSurfaceInstance != null)
                this.m_Document.Delete(((Element) topoSurfaceInstance).Id);
            }
            if (_PlacementSettings.ParkingLotSurfaceID != string.Empty)
            {
              TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _PlacementSettings.ParkingLotSurfaceID);
              if (topoSurfaceInstance != null)
                this.m_Document.Delete(((Element) topoSurfaceInstance).Id);
            }
            if (_PlacementSettings.ParentTopoSurfaceID != string.Empty)
              strA = _PlacementSettings.ParentTopoSurfaceID;
            if (this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet != null && this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet.Size > 0)
              RevitUtility.HideElementsInAllViews(this.m_Document, this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineElementSet);
            for (int index2 = 0; index2 < this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineFamilyInstanceList.Count; ++index2)
              this.m_Document.Delete(((Element) this.m_FamilyInstanceComponentWrapper.ParkingLotBreaklineFamilyInstanceList[index2]).Id);
            for (int index3 = 0; index3 < this.m_FamilyInstanceComponentWrapper.IntersectionFamilyInstanceList.Count; ++index3)
              this.m_Document.Delete(((Element) this.m_FamilyInstanceComponentWrapper.IntersectionFamilyInstanceList[index3]).Id);
            this.m_TransactionContainer.EndTransaction();
            if (this.m_FamilyInstanceComponentWrapper.ProposedLeg != null && this.m_FamilyInstanceComponentWrapper.ProposedElementSet != null)
            {
              epsLeg = Eps_Leg.CopyLeg(this.m_FamilyInstanceComponentWrapper.ProposedLeg);
              foreach (Element proposedElement in this.m_FamilyInstanceComponentWrapper.ProposedElementSet)
                _ElementList.Add(proposedElement);
              if (this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol != null)
                _PlacementSettings.Type = this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol;
              flag4 = true;
            }
            _PlacementSettings.IntersectionPlacementSymbol = this.m_FamilyInstanceComponentWrapper.IntersectionFamilySymbol;
            intersectionStations1 = this.m_FamilyInstanceComponentWrapper.LeftIntersectionStations;
            intersectionStations2 = this.m_FamilyInstanceComponentWrapper.CenterIntersectionStations;
            intersectionStations3 = this.m_FamilyInstanceComponentWrapper.RightIntersectionStations;
            intersectionContainerList = this.m_FamilyInstanceComponentWrapper.IntersectionContainerList;
          }
          else
          {
            if (_PlacementSettings.LocateType == LandcaddID.Curb && _PlacementSettings.ParentTopoSurfaceID != string.Empty && string.Compare(_PlacementSettings.ParentTopoSurfaceID, ((Element) _ProposedSurface.TopographySurface).UniqueId, true) != 0)
            {
              _PlacementSettings.LoftFormID = string.Empty;
              _PlacementSettings.IslandSurfaceID = string.Empty;
              _PlacementSettings.ParkingLotSurfaceID = string.Empty;
              continue;
            }
            if (this.m_AllSiteComponentList[index1].OriginalLeg == null && this.m_AllSiteComponentList[index1].ProposedLeg == null)
              this.m_AllSiteComponentList[index1].CreateOriginalLeg(this.m_ProposedSurface);
            if (this.m_AllSiteComponentList[index1].OriginalLeg != null || this.m_AllSiteComponentList[index1].ProposedLeg != null)
            {
              if (flag1)
              {
                --this.m_AllSiteComponentList[index1].DrawOrder;
                foreach (Element familyInstanceElement in this.m_AllSiteComponentList[index1].GetFamilyInstanceElementSet())
                  familyInstanceElement.LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter)?.Set(this.m_AllSiteComponentList[index1].DrawOrder);
              }
              if (this.m_AllSiteComponentList[index1].ProposedFamilySymbol == null)
                this.m_AllSiteComponentList[index1].ProposedFamilySymbol = _PlacementSettings.Type;
              if (this.m_AllSiteComponentList[index1].ProposedLeg != null)
                epsLeg = Eps_Leg.CopyLeg(this.m_AllSiteComponentList[index1].ProposedLeg);
              else if (this.m_AllSiteComponentList[index1].OriginalLeg != null)
                epsLeg = Eps_Leg.CopyLeg(this.m_AllSiteComponentList[index1].OriginalLeg);
            }
            _PlacementSettings.IntersectionPlacementSymbol = this.m_AllSiteComponentList[index1].IntersectionFamilySymbol;
            intersectionStations1 = this.m_AllSiteComponentList[index1].LeftIntersectionStations;
            intersectionStations2 = this.m_AllSiteComponentList[index1].CenterIntersectionStations;
            intersectionStations3 = this.m_AllSiteComponentList[index1].RightIntersectionStations;
            intersectionContainerList = this.m_AllSiteComponentList[index1].IntersectionContainerList;
            flag4 = this.m_AllSiteComponentList[index1].RedrawForm;
            if (flag4)
            {
              foreach (Element originalElement in this.m_AllSiteComponentList[index1].GetOriginalElementSet())
                _ElementList.Add(originalElement);
              if (this.m_AllSiteComponentList[index1].ProposedFamilySymbol != null)
                _PlacementSettings.Type = this.m_AllSiteComponentList[index1].ProposedFamilySymbol;
              this.m_TransactionContainer.BeginTransaction();
              foreach (Element familyInstanceElement in this.m_AllSiteComponentList[index1].GetFamilyInstanceElementSet())
              {
                Parameter parameter14 = familyInstanceElement.LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
                if (parameter14 != null && parameter14.AsString() != string.Empty)
                {
                  DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, parameter14.AsString());
                  if (directShape != null)
                  {
                    this.m_Document.Delete(((Element) directShape).Id);
                  }
                  else
                  {
                    FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, parameter14.AsString());
                    if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                      this.m_Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
                  }
                }
                Parameter parameter15 = familyInstanceElement.LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
                if (parameter15 != null && parameter15.AsString() != string.Empty)
                {
                  DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, parameter15.AsString());
                  if (directShape != null)
                  {
                    this.m_Document.Delete(((Element) directShape).Id);
                  }
                  else
                  {
                    FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, parameter15.AsString());
                    if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                      this.m_Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
                  }
                }
              }
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AllSiteComponentList[index1].GetFamilyInstanceElementSet()));
              this.m_TransactionContainer.EndTransaction();
              if (intersectionStations1 != null && intersectionStations1.Count > 0 && intersectionStations3 != null && intersectionStations3.Count > 0)
              {
                FamilyInstance existingFamilyInstance2 = this.m_FamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
                if (existingFamilyInstance2 != null)
                {
                  for (int index4 = 0; index4 < intersectionStations1.Count; ++index4)
                    intersectionStations1[index4].PrimaryPlacementId = ((Element) existingFamilyInstance2).UniqueId;
                  for (int index5 = 0; index5 < intersectionStations3.Count; ++index5)
                    intersectionStations3[index5].PrimaryPlacementId = ((Element) existingFamilyInstance2).UniqueId;
                }
              }
            }
          }
          if (this.m_CurrentFamilyType == LandcaddID.Curb)
          {
            if (epsLeg != null && epsLeg.IsLegClosed())
            {
              double num1 = 0.0;
              double num2 = 0.0;
              Parameter parameter16 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
              if (parameter16 != null)
                num2 = parameter16.AsDouble();
              Parameter parameter17 = ((Element) this.m_FamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
              if (parameter17 != null)
                num1 = parameter17.AsDouble();
              double num3 = num2;
              double num4 = num1;
              Eps_Leg ppOffsetLegList1 = new Eps_Leg();
              RevitGeometry.OffsetLegList(epsLeg, num3 + num4, 1, ref ppOffsetLegList1, true);
              Eps_Leg ppOffsetLegList2 = new Eps_Leg();
              RevitGeometry.OffsetLegList(epsLeg, num3 + num4, 2, ref ppOffsetLegList2, true);
              if (RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2) < RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1))
                epsLeg = epsLeg.Reverse();
            }
            if (!flag3 && !flag4)
            {
              _PlacementSettings.LoftFormID = string.Empty;
              _PlacementSettings.IslandSurfaceID = string.Empty;
              _PlacementSettings.ParkingLotSurfaceID = string.Empty;
              continue;
            }
          }
          if (epsLeg != null && epsLeg.LegCount > 0)
          {
            if (!flag4)
            {
              if (!TopographySurfaceManagement.RebuildProposedTopographySurface(this.m_Document, _PlacementSettings, this.m_dArcPointInterval, epsLeg, _ProposedSurface, _ElementList, flag4, this.m_AllSiteComponentList[index1].ParkingLotBreaklineList, this.m_AllSiteComponentList[index1].ParkingLotBreaklineElementList, this.m_AllSiteComponentList[index1].ParkingLotBreaklineLinearPointIntervals, intersectionStations1, intersectionStations2, intersectionStations3, intersectionContainerList, ref _TopoPointList, ref _CrownPointList))
                return false;
            }
            else
            {
              progressBarForm1.Close();
              List<FamilyInstance> _FamilyInstanceList = (List<FamilyInstance>) null;
              if (!TopographySurfaceManagement.RebuildProposedTopographySurface(this.m_Document, _PlacementSettings, this.m_dArcPointInterval, epsLeg, _ProposedSurface, _ElementList, flag4, this.m_AllSiteComponentList[index1].ParkingLotBreaklineList, this.m_AllSiteComponentList[index1].ParkingLotBreaklineElementList, this.m_AllSiteComponentList[index1].ParkingLotBreaklineLinearPointIntervals, intersectionStations1, intersectionStations2, intersectionStations3, intersectionContainerList, ref _TopoPointList, ref _CrownPointList, ref _ParkingLotSurface, ref epsPointList, ref _FamilyInstanceList))
                return false;
              progressBarForm1 = new ProgressBarForm();
              progressBarForm1.ShowForm();
              progressBarForm1.Refresh();
              progressBarForm1.MinValue = 0;
              progressBarForm1.MaxValue = this.m_AllSiteComponentList.Count;
              progressBarForm1.Message = EPShared.LocalRM.GetString("ProgressBarGradingToposurfaceMessage");
              progressBarForm1.UpdateProgressBar(index1);
              if (string.Compare(this.m_AllSiteComponentList[index1].ChainID, this.m_FamilyInstanceComponentWrapper.ChainID, true) == 0)
              {
                this.m_FamilyInstanceComponentWrapper.FamilyContainerList.Clear();
                this.m_AllSiteComponentList[index1].FamilyContainerList.Clear();
                if (_FamilyInstanceList != null && _FamilyInstanceList.Count > 0 && _FamilyInstanceList.Count == _ElementList.Count)
                {
                  int index6 = 0;
                  foreach (Element _Element in _ElementList)
                  {
                    this.m_FamilyInstanceComponentWrapper.FamilyContainerList.Add(new FamilyInstanceComponentContainer(_Element, _FamilyInstanceList[index6]));
                    this.m_AllSiteComponentList[index1].FamilyContainerList.Add(new FamilyInstanceComponentContainer(_Element, _FamilyInstanceList[index6]));
                    ++index6;
                  }
                }
              }
              else if (this.m_FamilyInstanceComponentWrapper.LeftIntersectionStations != null && this.m_FamilyInstanceComponentWrapper.LeftIntersectionStations.Count > 0 && this.m_FamilyInstanceComponentWrapper.RightIntersectionStations != null && this.m_FamilyInstanceComponentWrapper.RightIntersectionStations.Count > 0 && _FamilyInstanceList != null && _FamilyInstanceList.Count > 0)
              {
                for (int index7 = 0; index7 < this.m_FamilyInstanceComponentWrapper.LeftIntersectionStations.Count; ++index7)
                  this.m_FamilyInstanceComponentWrapper.LeftIntersectionStations[index7].PrimaryPlacementId = ((Element) _FamilyInstanceList[0]).UniqueId;
                for (int index8 = 0; index8 < this.m_FamilyInstanceComponentWrapper.RightIntersectionStations.Count; ++index8)
                  this.m_FamilyInstanceComponentWrapper.RightIntersectionStations[index8].PrimaryPlacementId = ((Element) _FamilyInstanceList[0]).UniqueId;
              }
            }
            epsLeg = (Eps_Leg) null;
          }
          _PlacementSettings.LoftFormID = string.Empty;
          _PlacementSettings.IslandSurfaceID = string.Empty;
          _PlacementSettings.ParkingLotSurfaceID = string.Empty;
          progressBarForm1.UpdateProgressBar(1);
        }
      }
      progressBarForm1.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm1.Close();
      if (_CrownPointList != null && _CrownPointList.Count > 0)
        _TopoPointList.AddRange((IEnumerable<Eps_Point>) _CrownPointList);
      ProgressBarForm progressBarForm2 = new ProgressBarForm();
      progressBarForm2.ShowForm();
      progressBarForm2.Refresh();
      progressBarForm2.Message = EPShared.LocalRM.GetString("ProgressBarUpdatingModelMessage");
      progressBarForm2.MinValue = 0;
      progressBarForm2.MaxValue = 12;
      List<XYZ> xyzList1 = new List<XYZ>();
      List<XYZ> xyzList2 = new List<XYZ>();
      double _dOffset = 0.0;
      double _dStation = 0.0;
      bool flag5 = false;
      bool flag6 = false;
      for (int index9 = 0; index9 < _TopoPointList.Count; ++index9)
      {
        if (_TopoPointList[index9] != null)
        {
          for (int index10 = 0; index10 < _ProposedSurface.SubregionBuildingPadList.Count; ++index10)
          {
            if (_ProposedSurface.SubregionBuildingPadList[index10] != null)
            {
              if (_ProposedSurface.SubregionBuildingPadList[index10].BoundaryLeg != null && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_TopoPointList[index9], _ProposedSurface.SubregionBuildingPadList[index10].BoundaryLeg, ref _dStation, ref _dOffset) == 1700 && Math.Abs(_dOffset) <= 0.001)
              {
                flag6 = true;
                break;
              }
              if (_ProposedSurface.SubregionBuildingPadList[index10].GetSurfaceContainerContainingPoint(_TopoPointList[index9]) != null)
              {
                if (_ProposedSurface.SubregionBuildingPadList[index10].TopographySurfaceType == TopographySurfaceType.Subregion)
                {
                  flag5 = true;
                  break;
                }
                flag6 = true;
                break;
              }
            }
          }
          if (flag5)
            xyzList2.Add(_TopoPointList[index9].XYZ);
          else if (!flag6)
            xyzList1.Add(_TopoPointList[index9].XYZ);
        }
        flag6 = false;
        flag5 = false;
      }
      progressBarForm2.UpdateProgressBar(1);
      if (xyzList1.Count > 0)
      {
        List<XYZ> removePointList = new List<XYZ>();
        removePointList.AddRange((IEnumerable<XYZ>) _ProposedSurface.TopographySurface.GetBoundaryPoints().ToList<XYZ>());
        TopographySurfaceManagement.RemoveDuplicateXY(ref xyzList1);
        TopographySurfaceManagement.RemoveOriginalTopoPoints(removePointList, ref xyzList1);
        string name = this.m_TransactionContainer.GetName();
        this.m_TransactionContainer.Commit();
        IList<XYZ> interiorPoints = _ProposedSurface.TopographySurface.GetInteriorPoints();
        this.m_TransactionContainer.StartTopographyEditScope(name, ((Element) _ProposedSurface.TopographySurface).Id);
        SDTimer sdTimer1 = new SDTimer("Point_Update_Modify", this.m_Document.Application);
        sdTimer1.Start();
        SDTimer sdTimer2 = new SDTimer("Traverse_Point_Modify", this.m_Document.Application);
        sdTimer2.Start();
        HashSet<XYZ> xyzSet = new HashSet<XYZ>((IEnumerable<XYZ>) interiorPoints, (IEqualityComparer<XYZ>) new XYZEqualityComparer());
        for (int index = xyzList1.Count - 1; index >= 0; --index)
        {
          if (xyzSet.Contains(xyzList1[index]))
          {
            xyzSet.Remove(xyzList1[index]);
            xyzList1.RemoveAt(index);
          }
        }
        sdTimer2.Stop();
        this.m_TransactionContainer.Start("Update Topo Points");
        if (xyzSet.Count <= xyzList1.Count)
        {
          int index = 0;
          foreach (XYZ xyz in xyzSet)
          {
            _ProposedSurface.TopographySurface.MovePoint(xyz, xyzList1[index]);
            ++index;
          }
          List<XYZ> xyzList3 = new List<XYZ>();
          for (; index < xyzList1.Count; ++index)
            xyzList3.Add(xyzList1[index]);
          if (xyzList3.Count > 0)
            _ProposedSurface.TopographySurface.AddPoints((IList<XYZ>) xyzList3);
        }
        else
        {
          int index = 0;
          int count = xyzList1.Count;
          List<XYZ> xyzList4 = new List<XYZ>();
          foreach (XYZ xyz in xyzSet)
          {
            if (index < count)
              _ProposedSurface.TopographySurface.MovePoint(xyz, xyzList1[index]);
            else
              xyzList4.Add(xyz);
            ++index;
          }
          if (xyzList4.Count > 0)
            _ProposedSurface.TopographySurface.DeletePoints((IList<XYZ>) xyzList4);
        }
        this.m_TransactionContainer.Commit();
        sdTimer1.Stop();
        TopographyEditFailuresPreprocessor failuresPreprocessor = new TopographyEditFailuresPreprocessor();
        this.m_TransactionContainer.CommitTopographyEditScope(ref failuresPreprocessor);
        this.m_TransactionContainer.Start(name);
        _ProposedSurface.Refresh();
        this.m_Document.Regenerate();
        progressBarForm2.UpdateProgressBar(7);
        if (_ProposedSurface.SubregionBuildingPadList != null && _ProposedSurface.SubregionBuildingPadList.Count > 0)
        {
          Eps_Point toposurfaceAdjustmentPoint = TopographySurfaceManagement.FindToposurfaceAdjustmentPoint(this.m_ProposedSurface, TopographySurfaceManagement.FindAllMainSurfaces(this.m_Document, true));
          ElementTransformUtils.MoveElement(this.m_Document, ((Element) this.m_ProposedSurface.TopographySurface).Id, toposurfaceAdjustmentPoint.XY);
          List<TopographySurfaceContainer> _SubregionList = new List<TopographySurfaceContainer>();
          List<ElementId> elementIdList = new List<ElementId>();
          for (int index = 0; index < _ProposedSurface.SubregionBuildingPadList.Count; ++index)
          {
            if (_ProposedSurface.SubregionBuildingPadList[index] != null)
            {
              if (_ProposedSurface.SubregionBuildingPadList[index].TopographySurface != null)
              {
                elementIdList.Add(((Element) _ProposedSurface.SubregionBuildingPadList[index].TopographySurface).Id);
                if (_ProposedSurface.SubregionBuildingPadList[index].TopographySurfaceType == TopographySurfaceType.Subregion)
                  _SubregionList.Add(_ProposedSurface.SubregionBuildingPadList[index]);
              }
              else if (_ProposedSurface.SubregionBuildingPadList[index].BuildingPad != null)
                elementIdList.Add(((Element) _ProposedSurface.SubregionBuildingPadList[index].BuildingPad).Id);
            }
          }
          List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>> genericModelList = TopographySurfaceManagement.FindPlantMixGenericModelList(this.m_Document, _SubregionList);
          List<ElementId> _NewElementIds = (List<ElementId>) null;
          try
          {
            _NewElementIds = LinearArray.ArrayElementsWithoutAssociation(this.m_Document, this.m_Document.ActiveView, (ICollection<ElementId>) elementIdList.ToArray(), 2, toposurfaceAdjustmentPoint.XY, (ArrayAnchorMember) 0).ToList<ElementId>();
          }
          catch (Exception ex)
          {
            switch (ex)
            {
              case AccessViolationException _:
              case InvalidOperationException _:
                progressBarForm2.SetMaxValue();
                Thread.Sleep(300);
                progressBarForm2.Close();
                int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SubregionBuildingPadBoundaryErrorMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
            }
          }
          ElementTransformUtils.MoveElement(this.m_Document, ((Element) this.m_ProposedSurface.TopographySurface).Id, new XYZ(-toposurfaceAdjustmentPoint.x, -toposurfaceAdjustmentPoint.y, 0.0));
          if (xyzList2.Count > 0)
            this.m_ProposedSurface.TopographySurface.AddPoints((IList<XYZ>) xyzList2);
          List<TopographySurfaceContainer> surfaceContainers = TopographySurfaceManagement.FindNewTopographySurfaceContainers(this.m_Document, _NewElementIds);
          TopographySurfaceManagement.UpdatePlantMixGenericModelList(genericModelList, surfaceContainers);
          if (surfaceContainers != null && surfaceContainers.Count > 0)
            this.m_ProposedSurface.SubregionBuildingPadList.AddRange((IEnumerable<TopographySurfaceContainer>) surfaceContainers);
        }
        progressBarForm2.UpdateProgressBar(3);
        TopographySurfaceContainer proposedSurface = this.m_ProposedSurface;
        if (flag3 && this.m_TopoPlacementFamilyInstance != null)
        {
          Parameter parameter = ((Element) this.m_TopoPlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter != null && !((APIObject) parameter).IsReadOnly)
            parameter.Set(((Element) this.m_ProposedSurface.TopographySurface).UniqueId);
        }
        if (this.m_CurrentFamilyType == LandcaddID.Curb && strA != string.Empty)
        {
          LandcaddID landcaddId = LandcaddID.Curb;
          for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
          {
            ElementSet instanceElementSet = this.m_AllSiteComponentList[index].GetFamilyInstanceElementSet();
            if (instanceElementSet != null && instanceElementSet.Size != 0)
            {
              FamilyInstance existingFamilyInstance = this.m_AllSiteComponentList[index].GetFirstExistingFamilyInstance();
              if (existingFamilyInstance != null)
              {
                Parameter parameter18 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
                if (parameter18 != null && parameter18.AsString() != string.Empty)
                {
                  foreach (int num in Enum.GetValues(typeof (LandcaddID)))
                  {
                    if (string.Compare(parameter18.AsString(), num.ToString("000"), true) == 0)
                    {
                      landcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
                      break;
                    }
                  }
                  if (landcaddId == LandcaddID.Curb)
                  {
                    foreach (Element element in instanceElementSet)
                    {
                      Parameter parameter19 = element.LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
                      if (parameter19 != null && !((APIObject) parameter19).IsReadOnly && string.Compare(strA, parameter19.AsString(), true) == 0)
                        parameter19.Set(((Element) this.m_ProposedSurface.TopographySurface).UniqueId);
                    }
                  }
                }
              }
            }
          }
        }
      }
      progressBarForm2.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm2.Close();
      if (this.m_ParkingLotCurbSiteCompList != null)
      {
        for (int index = 0; index < this.m_ParkingLotCurbSiteCompList.Count; ++index)
        {
          ElementSet instanceElementSet = this.m_ParkingLotCurbSiteCompList[index].GetFamilyInstanceElementSet();
          if (instanceElementSet != null && instanceElementSet.Size != 0)
          {
            FamilyInstance existingFamilyInstance = this.m_ParkingLotCurbSiteCompList[index].GetFirstExistingFamilyInstance();
            if (existingFamilyInstance.Symbol != null)
            {
              _PlacementSettings.PlacementSymbol = existingFamilyInstance.Symbol;
              Parameter parameter20 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.ProjectInnerSlopesFamilyParameter);
              if (parameter20 != null)
                _PlacementSettings.ProjectInnerSlopes = parameter20.AsInteger();
              Parameter parameter21 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
              if (parameter21 != null && parameter21.AsString() != string.Empty)
                _PlacementSettings.Name = parameter21.AsString();
              Parameter parameter22 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
              if (parameter22 != null && parameter22.AsString() != string.Empty)
              {
                foreach (int num in Enum.GetValues(typeof (LandcaddID)))
                {
                  if (string.Compare(parameter22.AsString(), num.ToString("000"), true) == 0)
                  {
                    _PlacementSettings.LocateType = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
                    break;
                  }
                }
              }
              Parameter parameter23 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.ElevationFamilyParameter);
              if (parameter23 != null)
                _PlacementSettings.Elevation = parameter23.AsDouble();
              Parameter parameter24 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentIsRelativeElevationParameter);
              if (parameter24 != null)
              {
                _PlacementSettings.IsRelativeElevation = false;
                if (parameter24.AsInteger() == 1)
                  _PlacementSettings.IsRelativeElevation = true;
              }
              _PlacementSettings.Type = RevitUtility.FindFamilyTypeSymbol(this.m_Document, existingFamilyInstance, _PlacementSettings.LocateType);
              Parameter parameter25 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
              if (parameter25 != null)
                _PlacementSettings.UseRightSide = parameter25.AsInteger() == 1;
              foreach (Element element in instanceElementSet)
              {
                Parameter parameter26 = element.LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
                if (parameter26 != null && parameter26.AsString() != string.Empty)
                  _PlacementSettings.LoftFormID = parameter26.AsString();
                Parameter parameter27 = element.LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
                if (parameter27 != null && parameter27.AsString() != string.Empty)
                  _PlacementSettings.AdditionalLoftFormID = parameter27.AsString();
                Parameter parameter28 = element.LookupParameter(RevitParameters.IslandSurfaceIdFamilyParameter);
                if (parameter28 != null && parameter28.AsString() != string.Empty)
                  _PlacementSettings.IslandSurfaceID = parameter28.AsString();
              }
              Parameter parameter29 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
              if (parameter29 != null)
                _PlacementSettings.TopoDrawOrder = parameter29.AsInteger();
            }
            _PlacementSettings.Level = this.m_Document.ActiveView.GenLevel;
            _PlacementSettings.TransactionContainer = this.m_TransactionContainer;
            List<Element> _ElementList = new List<Element>();
            bool _bDrawForm = false;
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_ParkingLotCurbSiteCompList[index].GetOriginalElementSet()));
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_ParkingLotCurbSiteCompList[index].GetFamilyInstanceElementSet()));
            if (this.m_ParkingLotCurbSiteCompList[index].ProposedLeg != null && this.m_ParkingLotCurbSiteCompList[index].ProposedElementSet != null)
            {
              RevitUtility.HideElementsInAllViews(this.m_Document, this.m_FamilyInstanceComponentWrapper.ProposedElementSet);
            }
            else
            {
              this.m_ParkingLotCurbSiteCompList.RemoveAt(index);
              --index;
            }
            if (_PlacementSettings.LoftFormID != string.Empty)
            {
              DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, _PlacementSettings.LoftFormID);
              if (directShape != null)
              {
                this.m_Document.Delete(((Element) directShape).Id);
              }
              else
              {
                FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, _PlacementSettings.LoftFormID);
                if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                  this.m_Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
              }
            }
            if (_PlacementSettings.AdditionalLoftFormID != string.Empty)
            {
              DirectShape directShape = RevitUtility.FindDirectShape(this.m_Document, _PlacementSettings.AdditionalLoftFormID);
              if (directShape != null)
              {
                this.m_Document.Delete(((Element) directShape).Id);
              }
              else
              {
                FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(this.m_Document, _PlacementSettings.AdditionalLoftFormID);
                if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                  this.m_Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
              }
            }
            if (_PlacementSettings.IslandSurfaceID != string.Empty)
            {
              TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _PlacementSettings.IslandSurfaceID);
              if (topoSurfaceInstance != null)
                this.m_Document.Delete(((Element) topoSurfaceInstance).Id);
            }
            this.m_TransactionContainer.EndTransaction();
            if (this.m_ParkingLotCurbSiteCompList[index].ProposedLeg != null && this.m_ParkingLotCurbSiteCompList[index].ProposedElementSet != null)
            {
              epsLeg = Eps_Leg.CopyLeg(this.m_ParkingLotCurbSiteCompList[index].ProposedLeg);
              foreach (Element proposedElement in this.m_ParkingLotCurbSiteCompList[index].ProposedElementSet)
                _ElementList.Add(proposedElement);
              if (this.m_ParkingLotCurbSiteCompList[index].ProposedFamilySymbol != null)
                _PlacementSettings.Type = this.m_ParkingLotCurbSiteCompList[index].ProposedFamilySymbol;
              _bDrawForm = true;
            }
            if (epsLeg != null && epsLeg.IsLegClosed())
            {
              double num5 = 0.0;
              double num6 = 0.0;
              Parameter parameter30 = ((Element) this.m_ParkingLotCurbSiteCompList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
              if (parameter30 != null)
                num6 = parameter30.AsDouble();
              Parameter parameter31 = ((Element) this.m_ParkingLotCurbSiteCompList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
              if (parameter31 != null)
                num5 = parameter31.AsDouble();
              double num7 = num6;
              double num8 = num5;
              Eps_Leg ppOffsetLegList3 = new Eps_Leg();
              RevitGeometry.OffsetLegList(epsLeg, num7 + num8, 1, ref ppOffsetLegList3, true);
              Eps_Leg ppOffsetLegList4 = new Eps_Leg();
              RevitGeometry.OffsetLegList(epsLeg, num7 + num8, 2, ref ppOffsetLegList4, true);
              if (RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList4) < RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList3))
                epsLeg = epsLeg.Reverse();
            }
            if (epsLeg != null && epsLeg.LegCount > 0)
            {
              if (!TopographySurfaceManagement.RebuildProposedTopographySurface(this.m_Document, _PlacementSettings, this.m_dArcPointInterval, epsLeg, _ParkingLotSurface, _ElementList, _bDrawForm, (List<Eps_Leg>) null, (List<Element>) null, (List<double>) null, (List<IntersectionStationContainer>) null, (List<IntersectionStationContainer>) null, (List<IntersectionStationContainer>) null, (List<IntersectionContainer>) null, ref epsPointList))
                return false;
              epsLeg = (Eps_Leg) null;
            }
            _PlacementSettings.LoftFormID = string.Empty;
            _PlacementSettings.IslandSurfaceID = string.Empty;
            _PlacementSettings.ParkingLotSurfaceID = string.Empty;
          }
        }
        ProgressBarForm progressBarForm3 = new ProgressBarForm();
        progressBarForm3.ShowForm();
        progressBarForm3.Refresh();
        progressBarForm3.Message = EPShared.LocalRM.GetString("ProgressBarUpdatingModelMessage");
        progressBarForm3.MinValue = 0;
        progressBarForm3.MaxValue = 12;
        xyzList1.Clear();
        for (int index = 0; index < epsPointList.Count; ++index)
          xyzList1.Add(epsPointList[index].XYZ);
        progressBarForm3.UpdateProgressBar(1);
        if (xyzList1.Count > 0)
        {
          TopographySurfaceManagement.RemoveDuplicateXY(ref xyzList1);
          TopographySurface topographySurface = TopographySurface.Create(this.m_Document, (IList<XYZ>) xyzList1);
          this.m_Document.Regenerate();
          progressBarForm3.UpdateProgressBar(7);
          Parameter parameter32 = ((Element) topographySurface)[(BuiltInParameter) -1002107];
          if (parameter32 != null)
          {
            ElementId elementId = (ElementId) null;
            int _nReturnValue = -1;
            if (this.m_CurrentFamilyType == LandcaddID.Curb && ApplicationUtility.Settings.eplSetE_GetSetting(this.m_Document.PathName, "ParkingLotIslandToposurfaceMaterialParameter", ref _nReturnValue))
            {
              elementId = new ElementId(_nReturnValue);
              bool flag7 = false;
              foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (Material)).OfCategory((BuiltInCategory) -2000700).ToElements())
              {
                if (ElementId.op_Equality(element.Id, elementId))
                {
                  flag7 = true;
                  break;
                }
              }
              if (!flag7)
                _nReturnValue = -1;
            }
            if (_nReturnValue == -1)
            {
              Parameter parameter33 = ((Element) _ParkingLotSurface.TopographySurface)[(BuiltInParameter) -1002107];
              if (parameter33 != null)
              {
                elementId = parameter33.AsElementId();
                _nReturnValue = elementId.IntegerValue;
              }
            }
            if (_nReturnValue != -1)
              parameter32.Set(elementId);
          }
          Parameter parameter34 = ((Element) _ParkingLotSurface.TopographySurface)[(BuiltInParameter) -1012100];
          if (parameter34 != null && ElementId.op_Inequality(parameter34.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter34.AsElementId(), ElementId.InvalidElementId))
          {
            Parameter parameter35 = ((Element) topographySurface)[(BuiltInParameter) -1012100];
            if (parameter35 != null && !((APIObject) parameter35).IsReadOnly)
            {
              ElementId elementId = parameter34.AsElementId();
              parameter35.Set(elementId);
            }
          }
          Parameter parameter36 = ((Element) _ParkingLotSurface.TopographySurface)[(BuiltInParameter) -1012101];
          if (parameter36 != null && ElementId.op_Inequality(parameter36.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter36.AsElementId(), ElementId.InvalidElementId))
          {
            Parameter parameter37 = ((Element) topographySurface)[(BuiltInParameter) -1012101];
            if (parameter37 != null && !((APIObject) parameter37).IsReadOnly)
            {
              ElementId elementId = parameter36.AsElementId();
              parameter37.Set(elementId);
            }
          }
          Parameter parameter38 = ((Element) _ParkingLotSurface.TopographySurface)[(BuiltInParameter) -1006900];
          if (parameter38 != null && parameter38.AsString() != null && parameter38.AsString() != string.Empty)
          {
            Parameter parameter39 = ((Element) topographySurface)[(BuiltInParameter) -1006900];
            if (parameter39 != null && !((APIObject) parameter39).IsReadOnly)
              parameter39.Set(parameter38.AsString());
          }
          ElementSet instanceElementSet = this.m_FamilyInstanceComponentWrapper.GetFamilyInstanceElementSet();
          if (instanceElementSet != null && instanceElementSet.Size > 0)
          {
            foreach (Element element in instanceElementSet)
            {
              Parameter parameter40 = element.LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
              if (parameter40 != null && !((APIObject) parameter40).IsReadOnly && string.Compare(parameter40.AsString(), ((Element) _ParkingLotSurface.TopographySurface).UniqueId, true) == 0)
                parameter40.Set(((Element) topographySurface).UniqueId);
            }
          }
          this.m_Document.Delete(((Element) _ParkingLotSurface.TopographySurface).Id);
          progressBarForm3.UpdateProgressBar(3);
        }
        progressBarForm3.SetMaxValue();
        Thread.Sleep(300);
        progressBarForm3.Close();
      }
    }
    return flag2;
  }

  private FamilySymbol SetInitialProposedFamilySymbol(
    FamilyInstanceComponentWrapper _FamilyInstanceComponentWrapper,
    ref bool _bFamilySymbolPresent)
  {
    FamilyInstance existingFamilyInstance = _FamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance == null)
      return (FamilySymbol) null;
    LandcaddID _LocateType = LandcaddID.SoftTerrain;
    Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
    if (parameter != null && parameter.AsString() != string.Empty)
    {
      foreach (int num in Enum.GetValues(typeof (LandcaddID)))
      {
        if (string.Compare(parameter.AsString(), num.ToString("000"), true) == 0)
        {
          _LocateType = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
          break;
        }
      }
    }
    FamilySymbol familySymbol = (FamilySymbol) null;
    if (_FamilyInstanceComponentWrapper.ProposedFamilySymbol == null)
      familySymbol = RevitUtility.FindFamilyTypeSymbol(this.m_Document, existingFamilyInstance, _LocateType, ref _bFamilySymbolPresent);
    return familySymbol;
  }
}
