﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ProductUpdateForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ProductUpdateForm : EPForm
{
  private bool m_bDailyVersionCheck;
  private IContainer components;
  private TextBox m_InstructionTextBox;
  private TextBox m_MessageTextBox;
  private Button m_CloseButton;
  private Button m_DownloadNowButton;
  private CheckBox m_DoNotShowMessageAgainCheckBox;

  public ProductUpdateForm(bool _bDailyVersionCheck)
  {
    this.InitializeComponent();
    this.m_bDailyVersionCheck = _bDailyVersionCheck;
    this.Text = EPShared.LocalRM.GetString("ProductUpdateAvailableTitle");
    this.m_MessageTextBox.Text = EPShared.LocalRM.GetString("NewerVersionAvailableForDownloadDialog");
    this.m_InstructionTextBox.Text = EPShared.LocalRM.GetString("ProductDownloadIntructionsDialog");
    this.m_DoNotShowMessageAgainCheckBox.Text = EPShared.LocalRM.GetString("AMP_DoNotShowMessageDialog");
    this.m_DownloadNowButton.Text = EPShared.LocalRM.GetString("AMP_DownloadNow");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
    if (!this.m_bDailyVersionCheck)
    {
      Point location1 = this.m_DownloadNowButton.Location;
      ref Point local1 = ref location1;
      int y1 = local1.Y;
      Size size1 = this.m_DoNotShowMessageAgainCheckBox.Size;
      int num1 = size1.Height + 5;
      local1.Y = y1 - num1;
      --this.m_DownloadNowButton.TabIndex;
      this.m_DownloadNowButton.Location = location1;
      Point location2 = this.m_CloseButton.Location;
      ref Point local2 = ref location2;
      int y2 = local2.Y;
      size1 = this.m_DoNotShowMessageAgainCheckBox.Size;
      int num2 = size1.Height + 5;
      local2.Y = y2 - num2;
      --this.m_CloseButton.TabIndex;
      this.m_CloseButton.Location = location2;
      Size size2 = this.Size;
      ref Size local3 = ref size2;
      int height = local3.Height;
      size1 = this.m_DoNotShowMessageAgainCheckBox.Size;
      int num3 = size1.Height + 5;
      local3.Height = height - num3;
      this.Size = size2;
    }
    this.m_DoNotShowMessageAgainCheckBox.Visible = this.m_bDailyVersionCheck;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    this.GetDialogPosition();
    this.m_DoNotShowMessageAgainCheckBox.Checked = false;
    if (!this.m_bDailyVersionCheck || !ApplicationUtility.Settings.eplSetE_GetSetting("CheckForUpdateNotificationDoNotShowAgainOption", ref _nReturnValue))
      return;
    this.m_DoNotShowMessageAgainCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
  }

  private void SaveSettings()
  {
    if (!this.m_bDailyVersionCheck)
      return;
    ApplicationUtility.Settings.eplSetE_SetSetting("CheckForUpdateNotificationDoNotShowAgainOption", Convert.ToInt32(this.m_DoNotShowMessageAgainCheckBox.Checked));
  }

  private void OnCancelButtton(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnDownloadNowButtton(object sender, EventArgs e)
  {
    ApplicationUtility.StartWebClient();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnProductUpdateClosing(object sender, FormClosingEventArgs e)
  {
    this.SaveSettings();
    this.SetDialogPosition();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_InstructionTextBox = new TextBox();
    this.m_MessageTextBox = new TextBox();
    this.m_CloseButton = new Button();
    this.m_DownloadNowButton = new Button();
    this.m_DoNotShowMessageAgainCheckBox = new CheckBox();
    this.SuspendLayout();
    this.m_InstructionTextBox.Location = new Point(12, 61);
    this.m_InstructionTextBox.Multiline = true;
    this.m_InstructionTextBox.Name = "m_InstructionTextBox";
    this.m_InstructionTextBox.ReadOnly = true;
    this.m_InstructionTextBox.ScrollBars = ScrollBars.Vertical;
    this.m_InstructionTextBox.Size = new Size(268, 179);
    this.m_InstructionTextBox.TabIndex = 1;
    this.m_MessageTextBox.BackColor = SystemColors.Control;
    this.m_MessageTextBox.BorderStyle = BorderStyle.None;
    this.m_MessageTextBox.Location = new Point(12, 12);
    this.m_MessageTextBox.Multiline = true;
    this.m_MessageTextBox.Name = "m_MessageTextBox";
    this.m_MessageTextBox.Size = new Size(268, 43);
    this.m_MessageTextBox.TabIndex = 0;
    this.m_MessageTextBox.TabStop = false;
    this.m_MessageTextBox.Text = "A newer version is available for download.  Please follow the instructions below and click the Download Now button to get the latest version. ";
    this.m_CloseButton.DialogResult = DialogResult.Cancel;
    this.m_CloseButton.Location = new Point(204, 269);
    this.m_CloseButton.Name = "m_CancelButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 4;
    this.m_CloseButton.Text = "&Cancel";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCancelButtton);
    this.m_DownloadNowButton.Location = new Point(83, 269);
    this.m_DownloadNowButton.Name = "m_DownloadNowButton";
    this.m_DownloadNowButton.Size = new Size(115, 23);
    this.m_DownloadNowButton.TabIndex = 3;
    this.m_DownloadNowButton.Text = "&Download Now";
    this.m_DownloadNowButton.UseVisualStyleBackColor = true;
    this.m_DownloadNowButton.Click += new EventHandler(this.OnDownloadNowButtton);
    this.m_DoNotShowMessageAgainCheckBox.AutoSize = true;
    this.m_DoNotShowMessageAgainCheckBox.Location = new Point(12, 246);
    this.m_DoNotShowMessageAgainCheckBox.Name = "m_DoNotShowMessageAgainCheckBox";
    this.m_DoNotShowMessageAgainCheckBox.Size = new Size(160 /*0xA0*/, 17);
    this.m_DoNotShowMessageAgainCheckBox.TabIndex = 2;
    this.m_DoNotShowMessageAgainCheckBox.Text = "&Do not show message again";
    this.m_DoNotShowMessageAgainCheckBox.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(292, 304);
    this.Controls.Add((Control) this.m_DoNotShowMessageAgainCheckBox);
    this.Controls.Add((Control) this.m_CloseButton);
    this.Controls.Add((Control) this.m_DownloadNowButton);
    this.Controls.Add((Control) this.m_MessageTextBox);
    this.Controls.Add((Control) this.m_InstructionTextBox);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ProductUpdateForm);
    this.Text = nameof (ProductUpdateForm);
    this.FormClosing += new FormClosingEventHandler(this.OnProductUpdateClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_DownloadNowButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
