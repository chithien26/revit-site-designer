﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.XmlElementInfo
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections;

#nullable disable
namespace EPCommon;

public class XmlElementInfo
{
  private string m_strName;
  private bool m_bComment;
  private ArrayList m_Attributes;
  private ArrayList m_Children;

  public string Name
  {
    get => this.m_strName;
    set => this.m_strName = value;
  }

  public bool IsComment
  {
    get => this.m_bComment;
    set => this.m_bComment = value;
  }

  public ArrayList Attributes => this.m_Attributes;

  public ArrayList Children => this.m_Children;

  public int ElementCount => this.m_Children != null ? this.m_Children.Count : 0;

  public XmlElementInfo(string _strName)
  {
    this.m_bComment = false;
    this.m_Attributes = (ArrayList) null;
    this.m_Children = (ArrayList) null;
    this.m_strName = _strName;
  }

  public XmlElementInfo()
  {
    this.m_bComment = false;
    this.m_Attributes = (ArrayList) null;
    this.m_Children = (ArrayList) null;
  }

  public void AddAttribute(XmlAttributeInfo _Attribute)
  {
    if (this.m_Attributes == null)
      this.m_Attributes = new ArrayList();
    this.m_Attributes.Add((object) _Attribute);
  }

  public void AddElement(XmlElementInfo _Element)
  {
    if (this.m_Children == null)
      this.m_Children = new ArrayList();
    this.m_Children.Add((object) _Element);
  }

  public XmlElementInfo GetElement(int _nElement)
  {
    return this.m_Children != null ? (XmlElementInfo) this.m_Children[_nElement] : (XmlElementInfo) null;
  }

  public string GetAttribute(string _strAttribute) => this.GetAttributeInfo(_strAttribute)?.Value;

  private XmlAttributeInfo GetAttributeInfo(string _strAttribute)
  {
    if (this.m_Attributes != null)
    {
      for (int index = 0; index < this.m_Attributes.Count; ++index)
      {
        if (string.Compare(((XmlAttributeInfo) this.m_Attributes[index]).Name, _strAttribute, true) == 0)
          return (XmlAttributeInfo) this.m_Attributes[index];
      }
    }
    return (XmlAttributeInfo) null;
  }
}
