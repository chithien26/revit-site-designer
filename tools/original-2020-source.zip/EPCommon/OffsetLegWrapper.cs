﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.OffsetLegWrapper
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class OffsetLegWrapper
{
  private bool m_bIsLeft;
  private double m_dEndingStation;
  private double m_dStation;
  private double m_dAdditionalOffsetWidth;
  private Eps_Leg m_OffsetLeg;
  private Eps_Leg m_OriginalLeg;

  public OffsetLegWrapper()
  {
    this.m_bIsLeft = false;
    this.m_dStation = 0.0;
    this.m_dEndingStation = 0.0;
    this.m_dAdditionalOffsetWidth = 0.0;
    this.m_OffsetLeg = (Eps_Leg) null;
    this.m_OriginalLeg = (Eps_Leg) null;
  }

  public bool IsLeft
  {
    get => this.m_bIsLeft;
    set => this.m_bIsLeft = value;
  }

  public double EndingStation
  {
    get => this.m_dEndingStation;
    set => this.m_dEndingStation = value;
  }

  public double Station
  {
    get => this.m_dStation;
    set => this.m_dStation = value;
  }

  public double AdditionalOffsetWidth
  {
    get => this.m_dAdditionalOffsetWidth;
    set => this.m_dAdditionalOffsetWidth = value;
  }

  public Eps_Leg OffsetLeg
  {
    get => this.m_OffsetLeg;
    set => this.m_OffsetLeg = value;
  }

  public Eps_Leg OriginalLeg
  {
    get => this.m_OriginalLeg;
    set => this.m_OriginalLeg = value;
  }
}
