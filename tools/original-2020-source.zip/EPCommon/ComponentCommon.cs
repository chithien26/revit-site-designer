﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ComponentCommon
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ComponentCommon
{
  public static bool PlaceLegList(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _CurrentLeg)
  {
    if (_PlacementSettings.PlacementType == PlacementType.GroveSquare || _PlacementSettings.PlacementType == PlacementType.GroveTrianglular)
    {
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt, 1E-05))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), ApplicationUtility.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
      List<Eps_Leg> _IslandList = new List<Eps_Leg>();
      ComponentCommon.PickIslandLegs(_Document, ref _IslandList);
      ComponentCommon.PlaceHedgeGrove(_Document, _PlacementSettings, _CurrentLeg, _IslandList);
      if (_PlacementSettings.DeleteExistingChecked)
      {
        _PlacementSettings.TransactionContainer.BeginTransaction();
        for (int index = 0; index < _IslandList.Count; ++index)
        {
          if (_IslandList[index].ElementSet != null && _IslandList[index].ElementSet.Size > 0)
            _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_IslandList[index].ElementSet));
        }
        _PlacementSettings.TransactionContainer.EndTransaction();
      }
    }
    else
    {
      if (_PlacementSettings.ExistingElementChecked && !RevitUtility.EvaluateLeg(_Document, _PlacementSettings.TransactionContainer, _PlacementSettings.PlantSpacing, ref _CurrentLeg))
        return false;
      _PlacementSettings.IsReverse = _CurrentLeg.IsReverse;
      if (_PlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        ComponentCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _CurrentLeg);
      else if (_PlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        ComponentCommon.PlaceAltRowOnLeg(_Document, _PlacementSettings, _CurrentLeg);
      }
      else
      {
        Eps_Leg ppOffsetLegList1 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 1, ref ppOffsetLegList1, true);
        Eps_Leg ppOffsetLegList2 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 2, ref ppOffsetLegList2, true);
        _PlacementSettings.TransactionContainer.BeginTransaction();
        ModelCurveArray modelCurveArray1 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList1);
        ModelCurveArray modelCurveArray2 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList2);
        _PlacementSettings.TransactionContainer.EndTransaction();
        _Document.Regenerate();
        bool _UseRightSide = true;
        bool flag = RevitUtility.PickSideLeg(_Document, _CurrentLeg, ref _UseRightSide);
        ElementSet elm_set = new ElementSet();
        foreach (ModelCurve modelCurve in modelCurveArray1)
          elm_set.Insert((Element) modelCurve);
        foreach (ModelCurve modelCurve in modelCurveArray2)
          elm_set.Insert((Element) modelCurve);
        _PlacementSettings.TransactionContainer.BeginTransaction();
        _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
        _PlacementSettings.TransactionContainer.EndTransaction();
        if (!flag)
          return false;
        _PlacementSettings.UseRightSide = _UseRightSide;
        if (_UseRightSide)
          ComponentCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, ppOffsetLegList1, _CurrentLeg.ElementList);
        else
          ComponentCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, ppOffsetLegList2, _CurrentLeg.ElementList);
      }
    }
    if (_PlacementSettings.DeleteExistingChecked && _CurrentLeg.ElementSet != null && _CurrentLeg.ElementSet.Size > 0)
    {
      _PlacementSettings.TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_CurrentLeg.ElementSet));
      _PlacementSettings.TransactionContainer.EndTransaction();
    }
    return true;
  }

  public static void PickIslandLegs(Document _Document, ref List<Eps_Leg> _IslandList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(_Document, ApplicationUtility.GetString("PickIslandsMessage"), ref _Elements, false, PickMethod.PickObjects))
      return;
    bool flag1 = false;
    bool flag2 = false;
    foreach (Element _LocationElement in _Elements)
    {
      if (_LocationElement.Location is LocationCurve location && GeometryObject.op_Inequality((GeometryObject) location.Curve, (GeometryObject) null))
      {
        flag2 = true;
        Eps_Leg legFromElementList = RevitGeometry.GetLegFromElementList((Eps_Leg) null, _LocationElement);
        if (legFromElementList != null)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates2D(legFromElementList.LegStartPnt, legFromElementList.LegEndPnt, 1E-05))
            _IslandList.Add(legFromElementList);
        }
        else
        {
          Curve curve = location.Curve;
          if (!curve.IsBound)
          {
            switch (curve)
            {
              case Arc _:
                Arc _Arc = (Arc) curve;
                _IslandList.Add(new Eps_Leg()
                {
                  Arc = new Eps_Arc(_Arc)
                });
                continue;
              case Ellipse _:
              case NurbSpline _:
              case HermiteSpline _:
                IList<XYZ> xyzList = curve.Tessellate();
                int count = xyzList.Count;
                if (count > 1)
                {
                  Eps_Point epsPoint1 = new Eps_Point();
                  Eps_Point epsPoint2 = new Eps_Point();
                  Eps_Leg epsLeg1 = (Eps_Leg) null;
                  int index;
                  for (index = 0; index < count; index += 2)
                  {
                    Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
                    if (index > 0)
                    {
                      Eps_Leg epsLeg2 = new Eps_Leg();
                      epsLeg2.Line = new Eps_Line();
                      epsLeg2.Line.StartPnt = epsPoint1;
                      epsLeg2.Line.EndPnt = epsPoint3;
                      if (epsLeg1 == null)
                      {
                        epsLeg1 = epsLeg2;
                        epsLeg1.Element = _LocationElement;
                      }
                      else
                      {
                        epsLeg1.Last.Next = epsLeg2;
                        epsLeg1.Last.Element = _LocationElement;
                      }
                    }
                    epsPoint1 = epsPoint3;
                  }
                  if (index == count)
                  {
                    Eps_Leg epsLeg3 = new Eps_Leg();
                    epsLeg3.Line = new Eps_Line();
                    epsLeg3.Line.StartPnt = epsPoint1;
                    epsLeg3.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
                    if (epsLeg1 == null)
                    {
                      epsLeg1 = epsLeg3;
                      epsLeg1.Element = _LocationElement;
                    }
                    else
                    {
                      epsLeg1.Last.Next = epsLeg3;
                      epsLeg1.Last.Element = _LocationElement;
                    }
                  }
                  _IslandList.Add(epsLeg1);
                  continue;
                }
                continue;
              default:
                continue;
            }
          }
          else if (!flag1 && curve is Ellipse)
          {
            int num = (int) RevitMessageBox.Show(ApplicationUtility.GetString("IslandEclipsePickMessage"), ApplicationUtility.GetString("Error"), MessageBoxIcon.Hand);
            flag1 = true;
          }
        }
      }
    }
    if (!flag2 || _IslandList != null && _IslandList.Count != 0)
      return;
    if (!flag1)
    {
      int num1 = (int) RevitMessageBox.Show(ApplicationUtility.GetString("IslandClosedChainMessage"), ApplicationUtility.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    ComponentCommon.PickIslandLegs(_Document, ref _IslandList);
  }

  public static void PlaceHedgeGrove(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _BoundaryLeg,
    List<Eps_Leg> _IslandList)
  {
    ComponentCommon.PlaceHedgeGrove(_Document, _PlacementSettings, _BoundaryLeg, _IslandList, (List<FamilyInstance>) null);
  }

  public static void PlaceHedgeGrove(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _BoundaryLeg,
    List<Eps_Leg> _IslandList,
    List<FamilyInstance> _ExistingPlantList)
  {
    List<Eps_Leg> _IslandList1 = new List<Eps_Leg>();
    for (int index = 0; index < _IslandList.Count; ++index)
      _IslandList1.Add(Eps_Leg.CopyLeg(_IslandList[index]));
    ComponentCommon.OffsetBoundaries(_PlacementSettings.SetbackSpacing, ref _BoundaryLeg, ref _IslandList1);
    if (_BoundaryLeg == null)
      return;
    ComponentCommon.DrawOrderedGrove(_Document, _PlacementSettings, _BoundaryLeg, _IslandList1, _ExistingPlantList);
  }

  private static void OffsetBoundaries(
    double dSetbackSpacing,
    ref Eps_Leg _BoundaryLeg,
    ref List<Eps_Leg> _IslandList)
  {
    double num = dSetbackSpacing;
    int OffsetDir1 = 1;
    Eps_Leg ppOffsetLegList = new Eps_Leg();
    if (!RevitDefines.GT(num, 0.0))
      return;
    int Direction = 0;
    if (_BoundaryLeg != null)
    {
      RevitGeometry.eplGeoE_CalcLegDirection(_BoundaryLeg, ref Direction, 1E-05);
      if (Direction == 1)
        OffsetDir1 = 2;
      RevitGeometry.OffsetLegList(_BoundaryLeg, num, OffsetDir1, ref ppOffsetLegList, true);
      _BoundaryLeg = ppOffsetLegList;
    }
    if (_IslandList == null)
      return;
    for (int index = 0; index < _IslandList.Count; ++index)
    {
      RevitGeometry.eplGeoE_CalcLegDirection(_IslandList[index], ref Direction, 1E-05);
      int OffsetDir2 = Direction != 1 ? 2 : 1;
      RevitGeometry.OffsetLegList(_IslandList[index], num, OffsetDir2, ref ppOffsetLegList, true);
      _IslandList[index] = ppOffsetLegList;
    }
  }

  private static void DrawOrderedGrove(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _BoundaryLeg,
    List<Eps_Leg> _IslandList,
    List<FamilyInstance> _ExistingComponentList)
  {
    if (_BoundaryLeg == null)
      return;
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    Eps_Point pMinPnt = new Eps_Point();
    Eps_Point pMaxPnt = new Eps_Point();
    RevitGeometry.eplGeoE_FindMinMaxOfLegList(_BoundaryLeg, ref pMinPnt, ref pMaxPnt);
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    bool flag3 = false;
    int index1 = 0;
    bool _bSpacingType = false;
    if (_PlacementSettings.PlacementType == PlacementType.GroveTrianglular)
      _bSpacingType = true;
    RevitGeometry.CreatePointListFromMinMaxOfArea(ref epsPointList, pMinPnt, pMaxPnt, _PlacementSettings.RotationAngle, _PlacementSettings.PlantSpacing, _bSpacingType);
    RevitGeometry.GetAllPointsInBoundary(ref epsPointList, _BoundaryLeg, _IslandList);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = epsPointList.Count;
    progressBarForm.Message = ApplicationUtility.GetString("ProgressBarPlacingComponentsMessage");
    bool _bUseFailureHandling = true;
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag3 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlacementSettings.GenericModelIDList;
    }
    for (int index2 = 0; index2 < epsPointList.Count; ++index2)
    {
      KeyValuePair<string, string> keyValuePair;
      if (_BoundaryLeg.Element != null && flag1 && !flag2)
      {
        if (flag3)
        {
          flag3 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            Guid _ChainID1 = Guid.NewGuid();
            keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _BoundaryLeg.ElementList, string.Empty, _ChainID1);
            if (keyValuePairList.Count > 0)
            {
              for (int index3 = 0; index3 < _IslandList.Count; ++index3)
              {
                Document _Document1 = _Document;
                PlacementSettings _PlacementSettings1 = _PlacementSettings;
                List<Element> elementList = _IslandList[index3].ElementList;
                keyValuePair = keyValuePairList[0];
                string _strBoundaryID = keyValuePair.Value;
                Guid _ChainID2 = _ChainID1;
                RevitUtility.CreatePlacementGenericModel(_Document1, _PlacementSettings1, elementList, _strBoundaryID, _ChainID2);
              }
            }
          }
          else
          {
            int num = (int) new WarningOptionsForm(ApplicationUtility.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", ApplicationUtility.GetString("PositionComponetsMessage") + ApplicationUtility.GetString("_PlacedWontUpdateWithHost_Message") + ApplicationUtility.GetString("PlacementIDFamilyParameter") + ApplicationUtility.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag1 = false;
          }
        }
        if (index1 < keyValuePairList.Count)
        {
          keyValuePair = keyValuePairList[index1];
          if (string.Compare(keyValuePair.Key, _BoundaryLeg.Element.UniqueId, true) == 0)
          {
            flag2 = true;
          }
          else
          {
            for (int index4 = 0; index4 < keyValuePairList.Count; ++index4)
            {
              keyValuePair = keyValuePairList[index4];
              if (string.Compare(keyValuePair.Key, _BoundaryLeg.Element.UniqueId, true) == 0)
              {
                index1 = index4;
                flag2 = true;
                break;
              }
            }
          }
        }
      }
      Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPointList[index2], _PlacementSettings.SurfaceList);
      FamilyInstance familyInstance;
      if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
      {
        familyInstance = _ExistingComponentList[0];
        if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPointList[index2], new Eps_Point(location.Point)))
        {
          XYZ xyz = new XYZ(epsPointList[index2].XYZ.X - location.Point.X, epsPointList[index2].XYZ.Y - location.Point.Y, 0.0);
          ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
        }
        _ExistingComponentList.RemoveAt(0);
      }
      else
      {
        EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
        familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPointList[index2].XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
        _PlacementSettings.TransactionContainer = transactionContainer;
      }
      if (_BoundaryLeg.Element != null && flag1 && flag2)
      {
        Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
        if (parameter1 != null)
        {
          Parameter parameter2 = parameter1;
          keyValuePair = keyValuePairList[index1];
          string str = keyValuePair.Value;
          parameter2.Set(str);
        }
        else
          flag1 = false;
      }
      progressBarForm.UpdateProgressBar(1);
      flag2 = false;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index5 = 0; index5 < _ExistingComponentList.Count; ++index5)
        _Document.Delete(((Element) _ExistingComponentList[index5]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line)
  {
    ComponentCommon.PlaceCenterRowOnLine(_Document, _PlacementSettings, _Element, _Line, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line,
    List<FamilyInstance> _ExistingComponentList)
  {
    Eps_Point _NewPnt = new Eps_Point();
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    double plantSpacing = _PlacementSettings.PlantSpacing;
    if (_Line == null)
      return;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDistance);
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(_dDistance - _PlacementSettings.StartingDistance);
    progressBarForm.Message = ApplicationUtility.GetString("ProgressBarPlacingComponentsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag2 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlacementSettings.GenericModelIDList[0];
    }
    double _dAngle = 0.0;
    for (double startingDistance = _PlacementSettings.StartingDistance; startingDistance <= _dDistance; startingDistance += plantSpacing)
    {
      EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, startingDistance, ref _NewPnt);
      if (!RevitUtility.IsPointInPointList(_NewPnt, _PointList))
      {
        if (_Element != null && flag1 && flag2)
        {
          flag2 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
          }
          else
          {
            int num = (int) new WarningOptionsForm(ApplicationUtility.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", ApplicationUtility.GetString("PositionComponetsMessage") + ApplicationUtility.GetString("_PlacedWontUpdateWithHost_Message") + ApplicationUtility.GetString("PlacementIDFamilyParameter") + ApplicationUtility.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag1 = false;
          }
        }
        _PointList.Add(_NewPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
        {
          familyInstance = _ExistingComponentList[0];
          if (((Element) familyInstance).Location is LocationPoint location)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates3D(_NewPnt, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_NewPnt.XYZ.X - location.Point.X, _NewPnt.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
            }
            if (_PlacementSettings.AlignTo)
              _dAngle = location.Rotation;
          }
          _ExistingComponentList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, _NewPnt.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
        }
        if (_PlacementSettings.AlignTo && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
        {
          XYZ xyz = new XYZ(_NewPnt.x, _NewPnt.y, _NewPnt.z + 1.0);
          Line bound = Line.CreateBound(_NewPnt.XYZ, xyz);
          ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
        }
        if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag1 = false;
        }
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
      _dAngle = 0.0;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index = 0; index < _ExistingComponentList.Count; ++index)
        _Document.Delete(((Element) _ExistingComponentList[index]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceAltRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line)
  {
    bool _bOffsetRight = true;
    ComponentCommon.PlaceAltRowOnLine(_Document, _PlacementSettings, _Element, _Line, ref _bOffsetRight, (List<FamilyInstance>) null);
  }

  public static void PlaceAltRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line,
    List<FamilyInstance> _ExistingPlantList)
  {
    bool _bOffsetRight = true;
    ComponentCommon.PlaceAltRowOnLine(_Document, _PlacementSettings, _Element, _Line, ref _bOffsetRight, _ExistingPlantList);
  }

  public static void PlaceAltRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line,
    ref bool _bOffsetRight,
    List<FamilyInstance> _ExistingComponentList)
  {
    Eps_Point _NewPnt = new Eps_Point();
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    double setbackSpacing = _PlacementSettings.SetbackSpacing;
    double plantSpacing = _PlacementSettings.PlantSpacing;
    if (_Line == null)
      return;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDistance);
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(_dDistance - _PlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingComponentsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag2 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlacementSettings.GenericModelIDList[0];
    }
    double _dAngle = 0.0;
    for (double startingDistance = _PlacementSettings.StartingDistance; startingDistance <= _dDistance; startingDistance += plantSpacing / 2.0)
    {
      EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, startingDistance, ref _NewPnt);
      if (_bOffsetRight)
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), setbackSpacing, ref _NewPnt);
      else
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), setbackSpacing, ref _NewPnt);
      _bOffsetRight = !_bOffsetRight;
      if (!RevitUtility.IsPointInPointList(_NewPnt, _PointList))
      {
        if (_Element != null && flag1 && flag2)
        {
          flag2 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
          }
          else
          {
            int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag1 = false;
          }
        }
        _PointList.Add(_NewPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
        {
          familyInstance = _ExistingComponentList[0];
          if (((Element) familyInstance).Location is LocationPoint location)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates3D(_NewPnt, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_NewPnt.XYZ.X - location.Point.X, _NewPnt.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
            }
            if (_PlacementSettings.AlignTo)
              _dAngle = location.Rotation;
          }
          _ExistingComponentList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, _NewPnt.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
        }
        if (_PlacementSettings.AlignTo && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
        {
          XYZ xyz = new XYZ(_NewPnt.x, _NewPnt.y, _NewPnt.z + 1.0);
          Line bound = Line.CreateBound(_NewPnt.XYZ, xyz);
          ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
        }
        if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag1 = false;
        }
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
      _dAngle = 0.0;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index = 0; index < _ExistingComponentList.Count; ++index)
        _Document.Delete(((Element) _ExistingComponentList[index]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceCenterRowOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _Arc)
  {
    ComponentCommon.PlaceCenterRowOnArc(_Document, _PlacementSettings, _Element, _Arc, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _Arc,
    List<FamilyInstance> _ExistingComponentList)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    double plantSpacing = _PlacementSettings.PlantSpacing;
    if (_Arc == null)
      return;
    double num1 = _Arc.Radius * _Arc.Delta;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(num1 - _PlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingComponentsMessage");
    bool _bUseFailureHandling = true;
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag2 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlacementSettings.GenericModelIDList[0];
    }
    double _dAngle = 0.0;
    for (double startingDistance = _PlacementSettings.StartingDistance; startingDistance <= num1; startingDistance += plantSpacing)
    {
      EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, startingDistance, 0.0, ref _StaOffPnt);
      if (!RevitUtility.IsPointInPointList(_StaOffPnt, _PointList))
      {
        if (_Element != null && flag1 && flag2)
        {
          flag2 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
          }
          else
          {
            int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag1 = false;
          }
        }
        _PointList.Add(_StaOffPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_StaOffPnt, _PlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
        {
          familyInstance = _ExistingComponentList[0];
          if (((Element) familyInstance).Location is LocationPoint location)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates3D(_StaOffPnt, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_StaOffPnt.XYZ.X - location.Point.X, _StaOffPnt.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
            }
            if (_PlacementSettings.AlignTo)
              _dAngle = location.Rotation;
          }
          _ExistingComponentList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, _StaOffPnt.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
        }
        if (_PlacementSettings.AlignTo)
        {
          double _dTangentDir = 0.0;
          EPShared.eplGeoE_CalcTangentDirOfArc(_StaOffPnt, _Arc.RadiusPnt, _Arc.Direction, ref _dTangentDir);
          if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dTangentDir), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
          {
            XYZ xyz = new XYZ(_StaOffPnt.x, _StaOffPnt.y, _StaOffPnt.z + 1.0);
            Line bound = Line.CreateBound(_StaOffPnt.XYZ, xyz);
            ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dTangentDir - _dAngle));
          }
        }
        if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag1 = false;
        }
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
      _dAngle = 0.0;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index = 0; index < _ExistingComponentList.Count; ++index)
        _Document.Delete(((Element) _ExistingComponentList[index]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceAltRowOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _Arc)
  {
    ComponentCommon.PlaceAltRowOnArc(_Document, _PlacementSettings, _Element, _Arc, (List<FamilyInstance>) null);
  }

  public static void PlaceAltRowOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _Arc,
    List<FamilyInstance> _ExistingComponentList)
  {
    Eps_Point epsPoint = new Eps_Point();
    double _dTangentDir = 0.0;
    bool flag1 = true;
    double setbackSpacing = _PlacementSettings.SetbackSpacing;
    double plantSpacing = _PlacementSettings.PlantSpacing;
    if (_Arc == null)
      return;
    double num1 = _Arc.Radius * _Arc.Delta;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag2 = !_PlacementSettings.DeleteExistingChecked;
    bool flag3 = false;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(num1 - _PlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingComponentsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag3 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlacementSettings.GenericModelIDList[0];
    }
    double _dAngle = 0.0;
    for (double startingDistance = _PlacementSettings.StartingDistance; startingDistance <= num1; startingDistance += plantSpacing / 2.0)
    {
      EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, startingDistance, 0.0, ref epsPoint);
      EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint, _Arc.RadiusPnt, _Arc.Direction, ref _dTangentDir);
      if (flag1)
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dTangentDir - Math.PI / 2.0), setbackSpacing, ref epsPoint);
      else
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dTangentDir + Math.PI / 2.0), setbackSpacing, ref epsPoint);
      flag1 = !flag1;
      if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
      {
        if (_Element != null && flag2 && flag3)
        {
          flag3 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
          }
          else
          {
            int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag2 = false;
          }
        }
        _PointList.Add(epsPoint);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
        {
          familyInstance = _ExistingComponentList[0];
          if (((Element) familyInstance).Location is LocationPoint location)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
            }
            if (_PlacementSettings.AlignTo)
              _dAngle = location.Rotation;
          }
          _ExistingComponentList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
        }
        if (_PlacementSettings.AlignTo && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dTangentDir), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
        {
          XYZ xyz = new XYZ(epsPoint.x, epsPoint.y, epsPoint.z + 1.0);
          Line bound = Line.CreateBound(epsPoint.XYZ, xyz);
          ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dTangentDir - _dAngle));
        }
        if (_Element != null && flag2 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag2 = false;
        }
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
      _dAngle = 0.0;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index = 0; index < _ExistingComponentList.Count; ++index)
        _Document.Delete(((Element) _ExistingComponentList[index]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg)
  {
    ComponentCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _Leg, _Leg.ElementList, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg,
    List<Element> _OrigLegElementSet)
  {
    ComponentCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _Leg, _OrigLegElementSet, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg,
    List<FamilyInstance> _MovePlantList)
  {
    ComponentCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _Leg, _Leg.ElementList, _MovePlantList);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg,
    List<Element> _OrigLegElementSet,
    List<FamilyInstance> _ExistingComponentList)
  {
    Eps_Point epsPoint = new Eps_Point();
    double _dDistance = 0.0;
    double num1 = 0.0;
    double num2 = _PlacementSettings.StartingDistance;
    double plantSpacing = _PlacementSettings.PlantSpacing;
    if (_Leg == null)
      return;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    bool flag3 = false;
    int index1 = 0;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(RevitGeometry.eplGeoE_CalcLegListLength(_Leg) - num2);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingComponentsMessage");
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag3 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlacementSettings.GenericModelIDList;
    }
    double _dAngle = 0.0;
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      KeyValuePair<string, string> keyValuePair;
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref num1);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
        if (num2 > _dDistance)
        {
          num2 -= _dDistance;
        }
        else
        {
          double _dPolarDistance;
          for (_dPolarDistance = num2; _dPolarDistance <= _dDistance; _dPolarDistance += plantSpacing)
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, num1, _dPolarDistance, ref epsPoint);
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag1 && !flag2)
              {
                if (flag3)
                {
                  flag3 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _OrigLegElementSet);
                  }
                  else
                  {
                    int num3 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag1 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag2 = true;
                  }
                  else
                  {
                    for (int index2 = 0; index2 < keyValuePairList.Count; ++index2)
                    {
                      keyValuePair = keyValuePairList[index2];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index2;
                        flag2 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
              {
                familyInstance = _ExistingComponentList[0];
                if (((Element) familyInstance).Location is LocationPoint location)
                {
                  if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                  {
                    XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                    ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                  }
                  if (_PlacementSettings.AlignTo)
                    _dAngle = location.Rotation;
                }
                _ExistingComponentList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlacementSettings.TransactionContainer = transactionContainer;
              }
              if (_PlacementSettings.AlignTo && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              {
                XYZ xyz = new XYZ(epsPoint.x, epsPoint.y, epsPoint.z + 1.0);
                Line bound = Line.CreateBound(epsPoint.XYZ, xyz);
                ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
              }
              if (epsLeg.Element != null && flag1 && flag2)
              {
                Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter1 != null)
                {
                  Parameter parameter2 = parameter1;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter2.Set(str);
                }
                else
                  flag1 = false;
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
            _dAngle = 0.0;
          }
          num2 = _dPolarDistance - _dDistance;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance = epsLeg.Arc.Radius * epsLeg.Arc.Delta;
        if (num2 > _dDistance)
        {
          num2 -= _dDistance;
        }
        else
        {
          double _dStation;
          for (_dStation = num2; _dStation <= _dDistance; _dStation += plantSpacing)
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dStation, 0.0, ref epsPoint);
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag1 && !flag2)
              {
                if (flag3)
                {
                  flag3 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _OrigLegElementSet);
                  }
                  else
                  {
                    int num4 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag1 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag2 = true;
                  }
                  else
                  {
                    for (int index3 = 0; index3 < keyValuePairList.Count; ++index3)
                    {
                      keyValuePair = keyValuePairList[index3];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index3;
                        flag2 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
              {
                familyInstance = _ExistingComponentList[0];
                if (((Element) familyInstance).Location is LocationPoint location)
                {
                  if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                  {
                    XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                    ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                  }
                  if (_PlacementSettings.AlignTo)
                    _dAngle = location.Rotation;
                }
                _ExistingComponentList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlacementSettings.TransactionContainer = transactionContainer;
              }
              if (_PlacementSettings.AlignTo)
              {
                EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Direction, ref num1);
                if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                {
                  XYZ xyz = new XYZ(epsPoint.x, epsPoint.y, epsPoint.z + 1.0);
                  Line bound = Line.CreateBound(epsPoint.XYZ, xyz);
                  ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
                }
              }
              if (epsLeg.Element != null && flag1 && flag2)
              {
                Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter3 != null)
                {
                  Parameter parameter4 = parameter3;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter4.Set(str);
                }
                else
                  flag1 = false;
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
            _dAngle = 0.0;
          }
          num2 = _dStation - _dDistance;
        }
      }
      flag2 = false;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index4 = 0; index4 < _ExistingComponentList.Count; ++index4)
        _Document.Delete(((Element) _ExistingComponentList[index4]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceAltRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg)
  {
    ComponentCommon.PlaceAltRowOnLeg(_Document, _PlacementSettings, _Leg, (List<FamilyInstance>) null);
  }

  public static void PlaceAltRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg,
    List<FamilyInstance> _ExistingComponentList)
  {
    Eps_Point epsPoint = new Eps_Point();
    double _dDistance = 0.0;
    double num1 = 0.0;
    double num2 = _PlacementSettings.StartingDistance;
    double setbackSpacing = _PlacementSettings.SetbackSpacing;
    double plantSpacing = _PlacementSettings.PlantSpacing;
    bool flag1 = true;
    if (_Leg == null)
      return;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag2 = !_PlacementSettings.DeleteExistingChecked;
    bool flag3 = false;
    bool flag4 = false;
    int index1 = 0;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(RevitGeometry.eplGeoE_CalcLegListLength(_Leg) - num2);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingComponentsMessage");
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag4 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlacementSettings.GenericModelIDList;
    }
    double _dAngle = 0.0;
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      KeyValuePair<string, string> keyValuePair;
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref num1);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
        if (num2 > _dDistance)
        {
          num2 -= _dDistance;
        }
        else
        {
          double _dPolarDistance;
          for (_dPolarDistance = num2; _dPolarDistance <= _dDistance; _dPolarDistance += plantSpacing / 2.0)
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, num1, _dPolarDistance, ref epsPoint);
            if (flag1)
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(num1 - Math.PI / 2.0), setbackSpacing, ref epsPoint);
            else
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI / 2.0), setbackSpacing, ref epsPoint);
            flag1 = !flag1;
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag2 && !flag3)
              {
                if (flag4)
                {
                  flag4 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Leg.ElementList);
                  }
                  else
                  {
                    int num3 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag2 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag3 = true;
                  }
                  else
                  {
                    for (int index2 = 0; index2 < keyValuePairList.Count; ++index2)
                    {
                      keyValuePair = keyValuePairList[index2];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index2;
                        flag3 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
              {
                familyInstance = _ExistingComponentList[0];
                if (((Element) familyInstance).Location is LocationPoint location)
                {
                  if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                  {
                    XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                    ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                  }
                  if (_PlacementSettings.AlignTo)
                    _dAngle = location.Rotation;
                }
                _ExistingComponentList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlacementSettings.TransactionContainer = transactionContainer;
              }
              if (_PlacementSettings.AlignTo && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              {
                XYZ xyz = new XYZ(epsPoint.x, epsPoint.y, epsPoint.z + 1.0);
                Line bound = Line.CreateBound(epsPoint.XYZ, xyz);
                ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
              }
              if (epsLeg.Element != null && flag2 && flag3)
              {
                Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter1 != null)
                {
                  Parameter parameter2 = parameter1;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter2.Set(str);
                }
                else
                  flag2 = false;
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
            _dAngle = 0.0;
          }
          num2 = _dPolarDistance - _dDistance;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance = epsLeg.Arc.Radius * epsLeg.Arc.Delta;
        if (num2 > _dDistance)
        {
          num2 -= _dDistance;
        }
        else
        {
          double _dStation;
          for (_dStation = num2; _dStation <= _dDistance; _dStation += plantSpacing / 2.0)
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dStation, 0.0, ref epsPoint);
            EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Direction, ref num1);
            if (flag1)
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(num1 - Math.PI / 2.0), setbackSpacing, ref epsPoint);
            else
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI / 2.0), setbackSpacing, ref epsPoint);
            flag1 = !flag1;
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag2 && !flag3)
              {
                if (flag4)
                {
                  flag4 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Leg.ElementList);
                  }
                  else
                  {
                    int num4 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateComponentsNoPositioning", EPShared.LocalRM.GetString("PositionComponetsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag2 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag3 = true;
                  }
                  else
                  {
                    for (int index3 = 0; index3 < keyValuePairList.Count; ++index3)
                    {
                      keyValuePair = keyValuePairList[index3];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index3;
                        flag3 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingComponentList != null && _ExistingComponentList.Count > 0)
              {
                familyInstance = _ExistingComponentList[0];
                if (((Element) familyInstance).Location is LocationPoint location)
                {
                  if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                  {
                    XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                    ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                  }
                  if (_PlacementSettings.AlignTo)
                    _dAngle = location.Rotation;
                }
                _ExistingComponentList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlacementSettings.TransactionContainer = transactionContainer;
              }
              if (_PlacementSettings.AlignTo && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              {
                XYZ xyz = new XYZ(epsPoint.x, epsPoint.y, epsPoint.z + 1.0);
                Line bound = Line.CreateBound(epsPoint.XYZ, xyz);
                ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
              }
              if (epsLeg.Element != null && flag2 && flag3)
              {
                Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter3 != null)
                {
                  Parameter parameter4 = parameter3;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter4.Set(str);
                }
                else
                  flag2 = false;
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
            _dAngle = 0.0;
          }
          num2 = _dStation - _dDistance;
        }
      }
      flag3 = false;
    }
    if (_ExistingComponentList != null && _ExistingComponentList.Count > 0)
    {
      for (int index4 = 0; index4 < _ExistingComponentList.Count; ++index4)
        _Document.Delete(((Element) _ExistingComponentList[index4]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }
}
