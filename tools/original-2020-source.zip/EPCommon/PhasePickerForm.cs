﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PhasePickerForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PhasePickerForm : EPForm
{
  private Document m_Document;
  private List<Phase> m_PhaseCreatedList = new List<Phase>();
  private IContainer components;
  private Button m_OkButton;
  private TextBox m_ToposurfaceNameTextBox;
  private ComboBox m_PhaseDemolishedCmbBox;
  private Label m_PhaseDemolishedLbl;
  private ComboBox m_PhaseCreatedCmbBox;
  private Label m_PhaseCreatedLbl;
  private Label m_ToposurfaceNameLabel;
  private CheckBox m_HideOriginalCheckBox;

  public PhasePickerForm(Document _CurrentDocument)
  {
    this.ContextualHelpID = "HID_SDselectSurfacePhase";
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("SelectSurfaceNameAndPhaseDialog");
    this.m_Document = _CurrentDocument;
    this.InitializeDlg();
    this.GetDialogPosition();
  }

  private void InitializeDlg()
  {
    int num1 = 0;
    int num2 = 0;
    foreach (Phase phase in this.m_Document.Phases)
    {
      int integerValue = ((Element) phase).Id.IntegerValue;
      if (this.m_Document.DisplayUnitSystem == 1 && integerValue == 118390 || this.m_Document.DisplayUnitSystem == null && integerValue == 86961 || string.Compare(((Element) phase).Name, EPShared.LocalRM.GetString("NewConstructionString"), true) == 0)
        num1 = num2;
      this.m_PhaseCreatedList.Add(phase);
      ++num2;
    }
    this.m_PhaseDemolishedLbl.Hide();
    this.m_PhaseDemolishedCmbBox.Hide();
    this.Text = EPShared.LocalRM.GetString("SelectSurfaceNameAndPhaseDialog");
    this.m_ToposurfaceNameLabel.Text = EPShared.LocalRM.GetString("AMP_ToposurfaceNameDialog");
    this.m_OkButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.m_PhaseCreatedLbl.Text = EPShared.LocalRM.GetString("AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog");
    this.m_PhaseDemolishedLbl.Text = EPShared.LocalRM.GetString("AMP_PhaseDemolishedFamilyParameterSurfaceInfoDialog");
    this.m_ToposurfaceNameTextBox.Text = EPShared.LocalRM.GetString("ProposedToposurfaceString");
    this.m_PhaseCreatedCmbBox.DataSource = (object) this.m_PhaseCreatedList;
    this.m_PhaseCreatedCmbBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
    if (this.m_PhaseCreatedCmbBox.Items.Count <= 0)
      return;
    this.m_PhaseCreatedCmbBox.SelectedIndex = num1;
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  private void OkButtonClicked(object sender, EventArgs e) => this.DialogResult = DialogResult.OK;

  public int CreatedPhaseId => ((Element) this.m_PhaseCreatedCmbBox.SelectedItem).Id.IntegerValue;

  public int DemolishedPhaseId => (int) this.m_PhaseDemolishedCmbBox.SelectedValue;

  public string ToposurfaceName => this.m_ToposurfaceNameTextBox.Text;

  public bool HideOriginalTopoSurface => this.m_HideOriginalCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_OkButton = new Button();
    this.m_ToposurfaceNameTextBox = new TextBox();
    this.m_PhaseDemolishedCmbBox = new ComboBox();
    this.m_PhaseDemolishedLbl = new Label();
    this.m_PhaseCreatedCmbBox = new ComboBox();
    this.m_PhaseCreatedLbl = new Label();
    this.m_ToposurfaceNameLabel = new Label();
    this.m_HideOriginalCheckBox = new CheckBox();
    this.SuspendLayout();
    this.m_OkButton.Location = new Point(307, 87);
    this.m_OkButton.Name = "m_OkButton";
    this.m_OkButton.Size = new Size(75, 23);
    this.m_OkButton.TabIndex = 6;
    this.m_OkButton.Text = "Ok";
    this.m_OkButton.UseVisualStyleBackColor = true;
    this.m_OkButton.Click += new EventHandler(this.OkButtonClicked);
    this.m_ToposurfaceNameTextBox.Location = new Point(146, 12);
    this.m_ToposurfaceNameTextBox.Name = "m_ToposurfaceNameTextBox";
    this.m_ToposurfaceNameTextBox.Size = new Size(236, 20);
    this.m_ToposurfaceNameTextBox.TabIndex = 1;
    this.m_PhaseDemolishedCmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PhaseDemolishedCmbBox.FormattingEnabled = true;
    this.m_PhaseDemolishedCmbBox.Location = new Point(146, 54);
    this.m_PhaseDemolishedCmbBox.Name = "m_PhaseDemolishedCmbBox";
    this.m_PhaseDemolishedCmbBox.Size = new Size(236, 21);
    this.m_PhaseDemolishedCmbBox.TabIndex = 5;
    this.m_PhaseDemolishedLbl.AutoSize = true;
    this.m_PhaseDemolishedLbl.Location = new Point(12, 57);
    this.m_PhaseDemolishedLbl.Name = "m_PhaseDemolishedLbl";
    this.m_PhaseDemolishedLbl.Size = new Size(95, 13);
    this.m_PhaseDemolishedLbl.TabIndex = 4;
    this.m_PhaseDemolishedLbl.Text = "Phase Demolished";
    this.m_PhaseCreatedCmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PhaseCreatedCmbBox.FormattingEnabled = true;
    this.m_PhaseCreatedCmbBox.Location = new Point(146, 38);
    this.m_PhaseCreatedCmbBox.Name = "m_PhaseCreatedCmbBox";
    this.m_PhaseCreatedCmbBox.Size = new Size(236, 21);
    this.m_PhaseCreatedCmbBox.TabIndex = 3;
    this.m_PhaseCreatedLbl.AutoSize = true;
    this.m_PhaseCreatedLbl.Location = new Point(12, 41);
    this.m_PhaseCreatedLbl.Name = "m_PhaseCreatedLbl";
    this.m_PhaseCreatedLbl.Size = new Size(77, 13);
    this.m_PhaseCreatedLbl.TabIndex = 2;
    this.m_PhaseCreatedLbl.Text = "Phase Created";
    this.m_ToposurfaceNameLabel.AutoSize = true;
    this.m_ToposurfaceNameLabel.Location = new Point(12, 15);
    this.m_ToposurfaceNameLabel.Name = "m_ToposurfaceNameLabel";
    this.m_ToposurfaceNameLabel.Size = new Size(101, 13);
    this.m_ToposurfaceNameLabel.TabIndex = 0;
    this.m_ToposurfaceNameLabel.Text = "Toposurface Name:";
    this.m_HideOriginalCheckBox.Location = new Point(15, 73);
    this.m_HideOriginalCheckBox.Name = "m_HideOriginalCheckBox";
    this.m_HideOriginalCheckBox.Size = new Size(98, 37);
    this.m_HideOriginalCheckBox.TabIndex = 8;
    this.m_HideOriginalCheckBox.Text = "Hide Original Toposurface";
    this.m_HideOriginalCheckBox.UseVisualStyleBackColor = true;
    this.AcceptButton = (IButtonControl) this.m_OkButton;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(394, 118);
    this.Controls.Add((Control) this.m_HideOriginalCheckBox);
    this.Controls.Add((Control) this.m_ToposurfaceNameLabel);
    this.Controls.Add((Control) this.m_PhaseDemolishedCmbBox);
    this.Controls.Add((Control) this.m_PhaseDemolishedLbl);
    this.Controls.Add((Control) this.m_PhaseCreatedCmbBox);
    this.Controls.Add((Control) this.m_PhaseCreatedLbl);
    this.Controls.Add((Control) this.m_ToposurfaceNameTextBox);
    this.Controls.Add((Control) this.m_OkButton);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (PhasePickerForm);
    this.Text = nameof (PhasePickerForm);
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
  }

  private class PhaseInformation
  {
    private string m_PhaseName;
    private int m_PhaseID;

    public PhaseInformation(string _strPhaseName, int _nPhaseValue)
    {
      this.m_PhaseName = _strPhaseName;
      this.m_PhaseID = _nPhaseValue;
    }

    public string PhaseName => this.m_PhaseName;

    public int PhaseID => this.m_PhaseID;
  }
}
