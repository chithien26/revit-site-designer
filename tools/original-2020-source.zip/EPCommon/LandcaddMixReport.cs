﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandcaddMixReport
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LandcaddMixReport : EPForm
{
  private Units m_Units;
  private LandcaddID m_CurrentReportType;
  private Application m_CurApplication;
  private Document m_CurrentDocument;
  private List<FamilyRegionContainer> m_FamilyRegionList;
  private FormatOptions m_LengthFormatOptions;
  private FormatOptions m_AreaFormatOptions;
  private FormatOptions m_VolumeFormatOptions;
  private UnitSymbolType m_LengthUnitSymbolType;
  private UnitSymbolType m_AreaUnitSymbolType;
  private UnitSymbolType m_VolumeUnitSymbolType;
  private List<FamilyParameterTypeWrapper> m_ListOfPlantParameters;
  private bool m_bExportToFile;
  private List<ExportReportLine> m_ReportLineList;
  private string m_strSettingsPrefix;
  private LandcaddMixReport.RegionEdgingWarning m_RegionEdgingWarning;
  private EPTransactionContainer m_TransactionContainer;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private GroupBox m_MixReportGroupBox;
  private Button m_CloseButton;
  private Button m_ExportButton;
  private TreeView m_ReportTreeView;
  private ListView m_ReportListView;
  private Button m_ExportFileButton;
  private GroupBox m_ExportOptionsGroupBox;
  private TextBox m_ExportFileTextBox;
  private Label m_ExportFileLabel;
  private CheckBox m_ExportFamilyCheckBox;
  private CheckBox m_ExportRegionCheckBox;
  private CheckBox m_ExportTypeCheckBox;
  private RadioButton m_TabExportRadioButton;
  private RadioButton m_CommaExportRadioButton;

  public LandcaddMixReport(LandcaddID _ReportType, Document _CurDocument, ref bool _bDlgStatus)
  {
    _bDlgStatus = true;
    this.InitializeComponent();
    this.EPToolTip.SetToolTip((Control) this.m_ExportFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
    this.m_CurApplication = _CurDocument.Application;
    this.m_CurrentDocument = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_CurrentDocument);
    this.m_LengthFormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_AreaFormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 1);
    this.m_VolumeFormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 2);
    this.m_Units = this.m_CurrentDocument.GetUnits();
    try
    {
      this.m_LengthUnitSymbolType = this.m_LengthFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_LengthUnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_AreaUnitSymbolType = this.m_AreaFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_AreaUnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_VolumeUnitSymbolType = this.m_VolumeFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_VolumeUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_CurrentDocument.GetUnits().DecimalSymbol;
    this.m_RegionEdgingWarning = LandcaddMixReport.RegionEdgingWarning.RegionEdgingNotFound;
    this.m_FamilyRegionList = new List<FamilyRegionContainer>();
    this.m_CurrentReportType = _ReportType;
    if (this.m_CurrentReportType == LandcaddID.PlantMix)
      this.Text = EPShared.LocalRM.GetString("PlantMixReportDialog");
    else
      this.Text = EPShared.LocalRM.GetString("PatioWalkReportDialog");
    this.m_MixReportGroupBox.Text = this.Text;
    this.m_ExportOptionsGroupBox.Text = EPShared.LocalRM.GetString("ExportOptionsDialog");
    this.m_ExportFamilyCheckBox.Text = EPShared.LocalRM.GetString("E_AMP_xportFamilyInformationDialog");
    this.m_ExportRegionCheckBox.Text = EPShared.LocalRM.GetString("Export_AMP_RegionInformationDialog");
    this.m_ExportTypeCheckBox.Text = EPShared.LocalRM.GetString("ExportType_AMP_InformationDialog");
    this.m_CommaExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
    this.m_TabExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
    this.m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_ExportButton.Text = EPShared.LocalRM.GetString("AMP_ExportDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
    this.m_strSettingsPrefix = this.Text.Replace(" ", "");
    this.InitializeControls();
    this.m_ReportListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"), this.m_ReportListView.Size.Width / 2 - 2, HorizontalAlignment.Left);
    this.m_ReportListView.Columns.Add(EPShared.LocalRM.GetString("Value"), this.m_ReportListView.Size.Width / 2 - 2, HorizontalAlignment.Left);
    this.m_ListOfPlantParameters = new List<FamilyParameterTypeWrapper>();
    this.m_ListOfPlantParameters = this.m_CurrentReportType != LandcaddID.PlantMix ? ManagePlants.PatioWalkParamenterList() : ManagePlants.PlantMixParamenterList();
    this.PopulateReportTree();
    if (this.m_FamilyRegionList.Count > 0)
      return;
    string _strText = EPShared.LocalRM.GetString("PlantMixReportNoFamilyMessage");
    if (this.m_CurrentReportType == LandcaddID.PatioWalk)
      _strText = EPShared.LocalRM.GetString("PatiowalkReportNoFamilyMessage");
    int num = (int) RevitMessageBox.Show(_strText, EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    _bDlgStatus = false;
  }

  private void PopulateReportTree()
  {
    List<Element> elementList = new List<Element>();
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
    {
      if (element != null && string.Compare(element.Name, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0)
        elementList.Add(element);
    }
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).WherePasses((ElementFilter) new ElementCategoryFilter((BuiltInCategory) -2002000)).ToElements())
    {
      if (element != null && string.Compare(element.Name, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), true) == 0)
        elementList.Add(element);
    }
    IList<Element> elements1 = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151).ToElements();
    IList<Element> elements2 = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151).ToElements();
    string empty = string.Empty;
    bool flag1 = false;
    foreach (Element element in (IEnumerable<Element>) elements2)
    {
      FamilySymbol familySymbol = element as FamilySymbol;
      for (int index = 0; index < this.m_FamilyRegionList.Count; ++index)
      {
        if (string.Compare(this.m_FamilyRegionList[index].FamilyName, ((Element) familySymbol.Family).Name, true) == 0)
        {
          this.m_FamilyRegionList[index].FamilySymbolList.Add(familySymbol);
          flag1 = true;
          break;
        }
      }
      if (!flag1)
        this.m_FamilyRegionList.Add(new FamilyRegionContainer(((Element) familySymbol.Family).Name, new List<FamilySymbol>()
        {
          familySymbol
        }));
      else
        flag1 = false;
    }
    string _strRegionName = string.Empty;
    Element _RegionElement = (Element) null;
    Options options = (Options) null;
    View3D _ReturnView3D = (View3D) null;
    bool flag2 = true;
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
    foreach (Element element1 in (IEnumerable<Element>) elements1)
    {
      if (element1 is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        Parameter parameter1 = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (parameter1 != null)
        {
          Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          bool flag3 = false;
          if (parameter2 != null)
          {
            foreach (Element element2 in elementList)
            {
              string uniqueId = element2.UniqueId;
              if (string.Compare(parameter2.AsString(), uniqueId, true) == 0)
              {
                _RegionElement = element2;
                flag3 = true;
                break;
              }
            }
          }
          if (string.Compare(parameter1.AsString(), Convert.ToInt32((object) this.m_CurrentReportType).ToString("000"), true) == 0)
          {
            for (int index = 0; index < this.m_FamilyRegionList.Count; ++index)
            {
              if (string.Compare(this.m_FamilyRegionList[index].FamilyName, ((Element) familyInstance.Symbol.Family).Name, true) == 0)
              {
                if (!flag3)
                {
                  this.m_TransactionContainer.BeginTransaction();
                  this.m_CurrentDocument.Delete(((Element) familyInstance).Id);
                  this.m_TransactionContainer.EndTransaction();
                  break;
                }
                if (_RegionElement != null)
                {
                  Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.RegionNameGenericModelFamilyParameter);
                  if (parameter3 != null)
                    _strRegionName = parameter3.AsString();
                  RegionContainer regionContainer = new RegionContainer(_strRegionName, _RegionElement);
                  if (string.Compare(_RegionElement.Name, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0)
                  {
                    if (options == null)
                    {
                      flag2 = RevitUtility.CreateTrue3DViewIfNotPresent(this.m_CurrentDocument, ref _ReturnView3D);
                      options = this.m_CurrentDocument.Application.Create.NewGeometryOptions();
                      options.View = _ReturnView3D == null ? this.m_CurrentDocument.ActiveView : (View) _ReturnView3D;
                      options.ComputeReferences = false;
                    }
                    regionContainer.MeshTriangleList = new MeshTriangleList((GeometryObject) _RegionElement[options]);
                  }
                  this.m_FamilyRegionList[index].RegionElementList.Add(regionContainer);
                  break;
                }
                break;
              }
            }
          }
        }
      }
    }
    if (_ReturnView3D != null && !flag2)
      this.m_CurrentDocument.Delete(((Element) _ReturnView3D).Id);
    this.m_TransactionContainer.Rollback();
    for (int index = this.m_FamilyRegionList.Count - 1; index >= 0; --index)
    {
      if (this.m_FamilyRegionList[index].RegionElementList == null || this.m_FamilyRegionList[index].RegionElementList.Count == 0)
        this.m_FamilyRegionList.RemoveAt(index);
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index1 = 0; index1 < this.m_FamilyRegionList.Count; ++index1)
    {
      TreeNode node1 = new TreeNode();
      node1.Text = this.m_FamilyRegionList[index1].FamilyName;
      for (int index2 = 0; index2 < this.m_FamilyRegionList[index1].RegionElementList.Count; ++index2)
      {
        TreeNode node2 = new TreeNode();
        node2.Text = this.m_FamilyRegionList[index1].RegionElementList[index2].RegionName;
        this.m_FamilyRegionList[index1].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
        if (this.m_CurrentReportType == LandcaddID.PatioWalk)
        {
          for (int index3 = 0; index3 < this.m_FamilyRegionList[index1].FamilySymbolList.Count; ++index3)
          {
            FamilySymbol familySymbol = this.m_FamilyRegionList[index1].FamilySymbolList[index3];
            Parameter parameter4 = ((Element) familySymbol).LookupParameter(RevitParameters.EdgePathWalkFamilyParameter);
            if (parameter4 != null && parameter4.AsInteger() == 1)
            {
              Parameter parameter5 = ((Element) familySymbol).LookupParameter(RevitParameters.MowingStripPathWalkFamilyParameter);
              if (parameter5 != null && parameter5.AsInteger() == 1)
              {
                if (index3 > 0)
                {
                  this.m_FamilyRegionList[index1].FamilySymbolList.RemoveAt(index3);
                  this.m_FamilyRegionList[index1].FamilySymbolList.Insert(0, familySymbol);
                  break;
                }
                break;
              }
            }
          }
        }
        for (int index4 = 0; index4 < this.m_FamilyRegionList[index1].FamilySymbolList.Count; ++index4)
          node2.Nodes.Add(new TreeNode()
          {
            Text = ((Element) this.m_FamilyRegionList[index1].FamilySymbolList[index4]).Name
          });
        node1.Nodes.Add(node2);
      }
      this.m_ReportTreeView.Nodes.Add(node1);
    }
  }

  private void OnExportButtonClicked(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    string str = string.Empty;
    if (this.m_ReportLineList == null)
      this.m_ReportLineList = new List<ExportReportLine>();
    this.m_bExportToFile = true;
    double _dTotalArea = 0.0;
    for (int index1 = 0; index1 < this.m_FamilyRegionList.Count; ++index1)
    {
      if (this.m_ExportFamilyCheckBox.Checked)
      {
        str = this.m_CurrentReportType != LandcaddID.PlantMix ? EPShared.LocalRM.GetString("PatioWalkString") : EPShared.LocalRM.GetString("PlantMixString");
        this.m_ReportLineList.Add(new ExportReportLine(this.Text, EPShared.LocalRM.GetString("Parameter"), EPShared.LocalRM.GetString("Value")));
        this.PopulateTotalAreaInList(this.m_FamilyRegionList[index1].RegionElementList, ref _dTotalArea, this.m_FamilyRegionList[index1].FamilyName);
        if (this.m_CurrentReportType == LandcaddID.PlantMix)
          this.PopulatePlantQuantityInList(this.m_FamilyRegionList[index1].FamilySymbolList, this.m_FamilyRegionList[index1].RegionElementList, _dTotalArea);
        else
          this.PopulatePathWalkVolumeInList(this.m_FamilyRegionList[index1].FamilySymbolList, this.m_FamilyRegionList[index1].RegionElementList, _dTotalArea);
        this.AddBlankLine();
        _dTotalArea = 0.0;
      }
      if (this.m_ExportRegionCheckBox.Checked)
      {
        this.m_ReportLineList.Add(new ExportReportLine(EPShared.LocalRM.GetString("RegionString"), EPShared.LocalRM.GetString("Parameter"), EPShared.LocalRM.GetString("Value")));
        for (int index2 = 0; index2 < this.m_FamilyRegionList[index1].RegionElementList.Count; ++index2)
        {
          this.PopulateTotalAreaInList(this.m_FamilyRegionList[index1].RegionElementList[index2], ref _dTotalArea, this.m_FamilyRegionList[index1].RegionElementList[index2].RegionName);
          if (this.m_CurrentReportType == LandcaddID.PlantMix)
            this.PopulatePlantQuantityInList(this.m_FamilyRegionList[index1].FamilySymbolList, this.m_FamilyRegionList[index1].RegionElementList[index2], _dTotalArea);
          else
            this.PopulatePathWalkVolumeInList(this.m_FamilyRegionList[index1].FamilySymbolList, this.m_FamilyRegionList[index1].RegionElementList[index2], _dTotalArea);
          this.AddBlankLine();
          _dTotalArea = 0.0;
        }
      }
      if (this.m_ExportTypeCheckBox.Checked)
      {
        this.m_ReportLineList.Add(new ExportReportLine(this.m_CurrentReportType != LandcaddID.PlantMix ? EPShared.LocalRM.GetString("MaterialString") : EPShared.LocalRM.GetString("Plant"), EPShared.LocalRM.GetString("Parameter"), EPShared.LocalRM.GetString("Value")));
        for (int index3 = 0; index3 < this.m_FamilyRegionList[index1].FamilySymbolList.Count; ++index3)
        {
          this.PopulatePlantParametersInList(this.m_FamilyRegionList[index1].FamilySymbolList[index3], ((Element) this.m_FamilyRegionList[index1].FamilySymbolList[index3]).Name);
          this.AddBlankLine();
        }
      }
    }
    string empty = string.Empty;
    ImportExport.ExportToFile(!this.m_CommaExportRadioButton.Checked ? "\t" : ",", this.m_ExportFileTextBox.Text, this.m_ReportLineList);
    this.m_ReportLineList.Clear();
    this.m_bExportToFile = false;
  }

  private void OnCloseButtonClicked(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
  }

  private int FindRootIndex(TreeNode _RootTreeNode)
  {
    for (int index = 0; index < this.m_FamilyRegionList.Count; ++index)
    {
      if (string.Compare(this.m_FamilyRegionList[index].FamilyName, _RootTreeNode.Text, true) == 0)
        return index;
    }
    return -1;
  }

  private int FindRegionIndex(int nRootIndex, TreeNode _RegionTreeNode)
  {
    if (nRootIndex >= 0 && nRootIndex < this.m_FamilyRegionList.Count)
    {
      for (int index = 0; index < this.m_FamilyRegionList[nRootIndex].RegionElementList.Count; ++index)
      {
        if (string.Compare(this.m_FamilyRegionList[nRootIndex].RegionElementList[index].RegionName, _RegionTreeNode.Text, true) == 0)
          return index;
      }
    }
    return -1;
  }

  private int FindPlantIndex(int nRootIndex, TreeNode _PlantTreeNode)
  {
    if (nRootIndex >= 0 && nRootIndex < this.m_FamilyRegionList.Count)
    {
      for (int index = 0; index < this.m_FamilyRegionList[nRootIndex].FamilySymbolList.Count; ++index)
      {
        if (string.Compare(((Element) this.m_FamilyRegionList[nRootIndex].FamilySymbolList[index]).Name, _PlantTreeNode.Text, true) == 0)
          return index;
      }
    }
    return -1;
  }

  private void ReportTreeViewAfterSelect(object sender, TreeViewEventArgs e)
  {
    this.m_ReportListView.Items.Clear();
    if (this.m_ReportTreeView.SelectedNode.Parent == null)
    {
      int rootIndex = this.FindRootIndex(this.m_ReportTreeView.SelectedNode);
      if (rootIndex != -1)
      {
        double _dTotalArea = 0.0;
        this.PopulateTotalAreaInList(this.m_FamilyRegionList[rootIndex].RegionElementList, ref _dTotalArea);
        if (this.m_CurrentReportType == LandcaddID.PlantMix)
          this.PopulatePlantQuantityInList(this.m_FamilyRegionList[rootIndex].FamilySymbolList, this.m_FamilyRegionList[rootIndex].RegionElementList, _dTotalArea);
        else
          this.PopulatePathWalkVolumeInList(this.m_FamilyRegionList[rootIndex].FamilySymbolList, this.m_FamilyRegionList[rootIndex].RegionElementList, _dTotalArea);
      }
    }
    else if (this.m_ReportTreeView.SelectedNode.Parent.Parent == null)
    {
      int rootIndex = this.FindRootIndex(this.m_ReportTreeView.SelectedNode.Parent);
      int regionIndex = this.FindRegionIndex(rootIndex, this.m_ReportTreeView.SelectedNode);
      if (regionIndex != -1)
      {
        double _dTotalArea = 0.0;
        this.PopulateTotalAreaInList(this.m_FamilyRegionList[rootIndex].RegionElementList[regionIndex], ref _dTotalArea);
        if (this.m_CurrentReportType == LandcaddID.PlantMix)
          this.PopulatePlantQuantityInList(this.m_FamilyRegionList[rootIndex].FamilySymbolList, this.m_FamilyRegionList[rootIndex].RegionElementList[regionIndex], _dTotalArea);
        else
          this.PopulatePathWalkVolumeInList(this.m_FamilyRegionList[rootIndex].FamilySymbolList, this.m_FamilyRegionList[rootIndex].RegionElementList[regionIndex], _dTotalArea);
      }
    }
    else
    {
      int rootIndex = this.FindRootIndex(this.m_ReportTreeView.SelectedNode.Parent.Parent);
      int plantIndex = this.FindPlantIndex(rootIndex, this.m_ReportTreeView.SelectedNode);
      if (plantIndex != -1)
        this.PopulatePlantParametersInList(this.m_FamilyRegionList[rootIndex].FamilySymbolList[plantIndex]);
    }
    if (this.m_RegionEdgingWarning != LandcaddMixReport.RegionEdgingWarning.IssueWarning)
      return;
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoLinearFootageMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    this.m_RegionEdgingWarning = LandcaddMixReport.RegionEdgingWarning.WarningDisplayed;
  }

  private void PopulatePlantParametersInList(FamilySymbol _PlantFamilySymbol)
  {
    this.PopulatePlantParametersInList(_PlantFamilySymbol, string.Empty);
  }

  private void PopulatePlantParametersInList(FamilySymbol _PlantFamilySymbol, string _strTitle)
  {
    string _strToDisplay = string.Empty;
    for (int index = 0; index < this.m_ListOfPlantParameters.Count; ++index)
    {
      if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
      {
        Parameter parameter = ((Element) _PlantFamilySymbol).LookupParameter(this.m_ListOfPlantParameters[index].ParameterName);
        if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.CostGenericFamilyParameter, true) == 0)
          _strToDisplay = ValueConversion.Format("{0:f2}", (object) parameter.AsDouble());
        else if (this.m_CurrentReportType == LandcaddID.PlantMix)
        {
          if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
          {
            double _dConvertedDouble = 0.0;
            if (parameter != null)
              _dConvertedDouble = parameter.AsDouble();
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref _strToDisplay);
          }
          else if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
            _strToDisplay = parameter == null ? EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular") : parameter.AsString();
          else if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
            _strToDisplay = parameter == null ? "0.0" : Convert.ToString(parameter.AsDouble());
          else if (parameter != null)
            _strToDisplay = parameter.AsString();
        }
        else if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
        {
          double _dConvertedDouble = 0.0;
          if (parameter != null)
            _dConvertedDouble = parameter.AsDouble();
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref _strToDisplay);
        }
        else if (string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ListOfPlantParameters[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
          _strToDisplay = parameter == null ? EPShared.LocalRM.GetString("NoString") : (parameter.AsInteger() != 0 ? EPShared.LocalRM.GetString("YesString") : EPShared.LocalRM.GetString("NoString"));
        else if (parameter != null)
          _strToDisplay = parameter.AsString();
        this.PopulateList(_strTitle, this.m_ListOfPlantParameters[index].ParameterName, _strToDisplay);
        if (_strTitle != string.Empty)
          _strTitle = string.Empty;
        _strToDisplay = string.Empty;
      }
    }
  }

  private void PopulateTotalAreaInList(RegionContainer _RegionContainer, ref double _dTotalArea)
  {
    this.PopulateTotalAreaInList(new List<RegionContainer>()
    {
      _RegionContainer
    }, ref _dTotalArea);
  }

  private void PopulateTotalAreaInList(List<RegionContainer> _ListOfRegions, ref double _dTotalArea)
  {
    this.PopulateTotalAreaInList(_ListOfRegions, ref _dTotalArea, string.Empty);
  }

  private void PopulateTotalAreaInList(
    RegionContainer _RegionContainer,
    ref double _dTotalArea,
    string _strTitle)
  {
    this.PopulateTotalAreaInList(new List<RegionContainer>()
    {
      _RegionContainer
    }, ref _dTotalArea, _strTitle);
  }

  private void PopulateTotalAreaInList(
    List<RegionContainer> _ListOfRegions,
    ref double _dTotalArea,
    string _strTitle)
  {
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index = 0; index < _ListOfRegions.Count; ++index)
    {
      if (string.Compare(_ListOfRegions[index].RegionElement.Name, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), true) == 0)
      {
        Parameter parameter = _ListOfRegions[index].RegionElement[(BuiltInParameter) -1012805];
        if (parameter != null)
          num1 += parameter.AsDouble();
      }
      else if (string.Compare(_ListOfRegions[index].RegionElement.Name, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0)
      {
        Parameter parameter1 = _ListOfRegions[index].RegionElement[(BuiltInParameter) -1012601];
        if (parameter1 != null)
          num3 += parameter1.AsDouble();
        Parameter parameter2 = _ListOfRegions[index].RegionElement[(BuiltInParameter) -1012610];
        if (parameter2 != null)
          num2 += parameter2.AsDouble();
      }
    }
    string _strParameter1 = $"{EPShared.LocalRM.GetString("RegionString")} {EPShared.LocalRM.GetString("AreaRegionParameter")}";
    if (RevitDefines.GT(num1, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num1, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strTitle, _strParameter1, empty1);
    string _strParameter2 = $"{EPShared.LocalRM.GetString("SubRegionString")} {EPShared.LocalRM.GetString("ProjectedAreaSubRegionParameter")}";
    if (RevitDefines.GT(num2, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num2, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter2, empty1);
    string _strParameter3 = $"{EPShared.LocalRM.GetString("SubRegionString")} {EPShared.LocalRM.GetString("SurfaceAreaSubRegionParameter")}";
    if (RevitDefines.GT(num3, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num3, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter3, empty1);
    _dTotalArea = num1 + num2;
  }

  private void PopulatePathWalkVolumeInList(
    List<FamilySymbol> _ListOfFamilies,
    RegionContainer _RegionContainer,
    double _dTotalArea)
  {
    this.PopulatePathWalkVolumeInList(_ListOfFamilies, new List<RegionContainer>()
    {
      _RegionContainer
    }, _dTotalArea);
  }

  private void PopulatePathWalkVolumeInList(
    List<FamilySymbol> _ListOfFamilies,
    List<RegionContainer> _ListOfRegions,
    double _dTotalArea)
  {
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    double num4 = 0.0;
    int num5 = 0;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index1 = 0; index1 < _ListOfFamilies.Count; ++index1)
    {
      FamilySymbol listOfFamily = _ListOfFamilies[index1];
      if (listOfFamily != null)
      {
        Parameter parameter1 = ((Element) listOfFamily).LookupParameter(RevitParameters.EdgePathWalkFamilyParameter);
        int num6 = parameter1 == null ? 0 : parameter1.AsInteger();
        Parameter parameter2 = ((Element) listOfFamily).LookupParameter(RevitParameters.ThicknessPathWalkFamilyParameter);
        double _dX = parameter2 == null ? 0.0 : parameter2.AsDouble();
        double num7 = _dTotalArea * _dX;
        if (num6 == 1)
        {
          Parameter parameter3 = ((Element) listOfFamily).LookupParameter(RevitParameters.MowingStripPathWalkFamilyParameter);
          if ((parameter3 == null ? 0 : parameter3.AsInteger()) == 1)
          {
            Parameter parameter4 = ((Element) listOfFamily).LookupParameter(RevitParameters.EdgeWidthPathWalkFamilyParameter);
            num2 = parameter4 == null ? 0.0 : parameter4.AsDouble();
          }
        }
        if (num6 == 1)
        {
          for (int index2 = 0; index2 < _ListOfRegions.Count; ++index2)
          {
            if (string.Compare(_ListOfRegions[index2].RegionElement.Name, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0)
            {
              double num8 = RevitGeometry.eplGeoE_CalcLegListLength(_ListOfRegions[index2].MeshTriangleList.Leg);
              num4 += num8;
              if (RevitDefines.GT(_dX, 0.0) && RevitDefines.GT(num2, 0.0))
              {
                double num9 = _ListOfRegions[index2].MeshTriangleList.Area();
                double num10 = _ListOfRegions[index2].MeshTriangleList.OffsetArea(num2);
                num3 += num9 - num10;
              }
            }
            else if (this.m_RegionEdgingWarning == LandcaddMixReport.RegionEdgingWarning.RegionEdgingNotFound)
              this.m_RegionEdgingWarning = LandcaddMixReport.RegionEdgingWarning.IssueWarning;
          }
          num1 = num3 * _dX;
          num7 -= num1;
        }
        num5 = 0;
        num2 = 0.0;
        string _strParameter = $"{((Element) listOfFamily).Name} {EPShared.LocalRM.GetString("VolumeString")}";
        if (RevitDefines.GT(num7, 0.0))
          RevitGeometry.Units_ConvertDoubleToString(num7, this.m_VolumeFormatOptions.DisplayUnits, this.m_VolumeFormatOptions.Accuracy, this.m_VolumeUnitSymbolType, this.m_Units, ref empty1);
        else
          empty1 = EPShared.LocalRM.GetString("NotAvailableString");
        this.PopulateList(_strParameter, empty1);
      }
    }
    if (RevitDefines.GT(num4, 0.0))
    {
      RevitGeometry.Units_ConvertDoubleToString(num4, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
      this.PopulateList($"{EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter")} {EPShared.LocalRM.GetString("LengthString")}", empty1);
    }
    if (RevitDefines.GT(num3, 0.0))
    {
      RevitGeometry.Units_ConvertDoubleToString(num3, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
      this.PopulateList($"{EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter")} {EPShared.LocalRM.GetString("AreaString")}", empty1);
    }
    if (!RevitDefines.GT(num1, 0.0))
      return;
    RevitGeometry.Units_ConvertDoubleToString(num1, this.m_VolumeFormatOptions.DisplayUnits, this.m_VolumeFormatOptions.Accuracy, this.m_VolumeUnitSymbolType, this.m_Units, ref empty1);
    this.PopulateList($"{EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter")} {EPShared.LocalRM.GetString("VolumeString")}", empty1);
  }

  private void PopulatePlantQuantityInList(
    List<FamilySymbol> _ListOfFamilies,
    RegionContainer _RegionContainer,
    double _dTotalArea)
  {
    this.PopulatePlantQuantityInList(_ListOfFamilies, new List<RegionContainer>()
    {
      _RegionContainer
    }, _dTotalArea);
  }

  private void PopulatePlantQuantityInList(
    List<FamilySymbol> _ListOfFamilies,
    List<RegionContainer> _ListOfRegions,
    double _dTotalArea)
  {
    string empty = string.Empty;
    for (int index = 0; index < _ListOfFamilies.Count; ++index)
    {
      FamilySymbol listOfFamily = _ListOfFamilies[index];
      if (listOfFamily != null)
      {
        Parameter parameter1 = ((Element) listOfFamily).LookupParameter(RevitParameters.PercentagePlantMixFamilyParameter);
        double _dPercent = parameter1 == null ? 0.0 : parameter1.AsDouble();
        Parameter parameter2 = ((Element) listOfFamily).LookupParameter(RevitParameters.PlantSpacingPlantMixFamilyParameter);
        double _dSpacing = parameter2 == null ? 0.0 : parameter2.AsDouble();
        Parameter parameter3 = ((Element) listOfFamily).LookupParameter(RevitParameters.SpacingMethodPlantMixFamilyParameter);
        int num = this.CalcPlantQuantity(parameter3 == null ? EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular") : parameter3.AsString(), _dSpacing, _dPercent, _dTotalArea);
        this.PopulateList($"{EPShared.LocalRM.GetString("QuantityOfString")} {((Element) listOfFamily).Name}", num.ToString("0"));
      }
    }
  }

  private int CalcPlantQuantity(
    string _strMethod,
    double _dSpacing,
    double _dPercent,
    double _dTotalArea)
  {
    int _dY = 1;
    if (string.Compare(_strMethod, EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular"), true) == 0)
      _dY = (int) (_dTotalArea / (_dSpacing * 0.87 * _dSpacing));
    else if (string.Compare(_strMethod, EPShared.LocalRM.GetString("PlantMixSpacingMethodSquare"), true) == 0)
      _dY = (int) (_dTotalArea / (_dSpacing * _dSpacing));
    else if (string.Compare(_strMethod, EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"), true) == 0)
    {
      double num = _dTotalArea;
      string empty = string.Empty;
      RevitGeometry.Units_ConvertDoubleToString(num, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, (UnitSymbolType) 0, this.m_Units, ref empty);
      if (empty != string.Empty)
        num = ValueConversion.ToDouble(empty);
      _dY = (int) num;
      if (RevitDefines.GT(num, (double) _dY))
        ++_dY;
    }
    int num1 = (int) ((double) _dY * _dPercent * 0.01);
    if (num1 < 1)
      num1 = 1;
    return num1;
  }

  private void OnExportFileButtonClick(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    if (this.m_CommaExportRadioButton.Checked)
      saveFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
    else
      saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_ExportFileTextBox.Text = saveFileDialog.FileName;
    this.m_ExportFileTextBox.Focus();
  }

  private void AddBlankLine()
  {
    if (!this.m_bExportToFile)
      return;
    this.m_ReportLineList.Add(new ExportReportLine());
  }

  private void PopulateList(string _strParameter, string _strValue)
  {
    this.PopulateList(string.Empty, _strParameter, _strValue);
  }

  private void PopulateList(string _strLevel, string _strParameter, string _strValue)
  {
    if (!this.m_bExportToFile)
    {
      ListViewItem listViewItem = this.m_ReportListView.Items.Add(_strParameter, _strParameter, string.Empty);
      listViewItem.Tag = (object) _strParameter;
      listViewItem.SubItems.Add(_strValue);
    }
    else
      this.m_ReportLineList.Add(new ExportReportLine(_strLevel, _strParameter, _strValue));
  }

  private bool ValidateFields()
  {
    if (string.IsNullOrEmpty(this.m_ExportFileTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFolderFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ExportFileTextBox.Focus();
      return false;
    }
    string empty = string.Empty;
    string str = !this.m_CommaExportRadioButton.Checked ? ".txt" : ".csv";
    if (this.m_ExportFileTextBox.Text.IndexOf(str) < 0)
    {
      if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
      {
        int length = -1;
        if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
        else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
        if (Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
        {
          this.m_ExportFileTextBox.Text += str;
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
    {
      int length = -1;
      if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
        length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
      else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
        length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
      if (!Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    return true;
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_CommaExportRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_CommaExportRadioButton.Checked = true;
      else
        this.m_TabExportRadioButton.Checked = true;
    }
    this.m_ExportFamilyCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportFamilyOption", ref _nReturnValue) && _nReturnValue == 1)
      this.m_ExportFamilyCheckBox.Checked = true;
    this.m_ExportTypeCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportTypeOption", ref _nReturnValue) && _nReturnValue == 1)
      this.m_ExportTypeCheckBox.Checked = true;
    this.m_ExportRegionCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportRegionOption", ref _nReturnValue) && _nReturnValue == 1)
      this.m_ExportRegionCheckBox.Checked = true;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportFileName", ref empty))
      return;
    this.m_ExportFileTextBox.Text = empty;
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportOption", !this.m_CommaExportRadioButton.Checked ? 1 : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportFamilyOption", Convert.ToInt32(this.m_ExportFamilyCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportTypeOption", Convert.ToInt32(this.m_ExportTypeCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportRegionOption", Convert.ToInt32(this.m_ExportRegionCheckBox.Checked));
    if (!(this.m_ExportFileTextBox.Text != string.Empty))
      return;
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportFileName", this.m_ExportFileTextBox.Text);
  }

  private void OnLandcaddMixReportClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_MixReportGroupBox = new GroupBox();
    this.m_ReportListView = new ListView();
    this.m_ReportTreeView = new TreeView();
    this.m_CloseButton = new Button();
    this.m_ExportButton = new Button();
    this.m_ExportFileButton = new Button();
    this.m_ExportOptionsGroupBox = new GroupBox();
    this.m_TabExportRadioButton = new RadioButton();
    this.m_CommaExportRadioButton = new RadioButton();
    this.m_ExportTypeCheckBox = new CheckBox();
    this.m_ExportRegionCheckBox = new CheckBox();
    this.m_ExportFamilyCheckBox = new CheckBox();
    this.m_ExportFileTextBox = new TextBox();
    this.m_ExportFileLabel = new Label();
    this.m_MixReportGroupBox.SuspendLayout();
    this.m_ExportOptionsGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_MixReportGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_MixReportGroupBox.Controls.Add((Control) this.m_ReportListView);
    this.m_MixReportGroupBox.Controls.Add((Control) this.m_ReportTreeView);
    this.m_MixReportGroupBox.Location = new Point(12, 5);
    this.m_MixReportGroupBox.Name = "m_MixReportGroupBox";
    this.m_MixReportGroupBox.Size = new Size(532, 311);
    this.m_MixReportGroupBox.TabIndex = 0;
    this.m_MixReportGroupBox.TabStop = false;
    this.m_MixReportGroupBox.Text = "Plant Mix Report";
    this.m_ReportListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ReportListView.Location = new Point(214, 16 /*0x10*/);
    this.m_ReportListView.MultiSelect = false;
    this.m_ReportListView.Name = "m_ReportListView";
    this.m_ReportListView.Size = new Size(312, 288);
    this.m_ReportListView.TabIndex = 1;
    this.m_ReportListView.UseCompatibleStateImageBehavior = false;
    this.m_ReportListView.View = View.Details;
    this.m_ReportTreeView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ReportTreeView.Location = new Point(6, 16 /*0x10*/);
    this.m_ReportTreeView.Name = "m_ReportTreeView";
    this.m_ReportTreeView.Size = new Size(202, 288);
    this.m_ReportTreeView.TabIndex = 0;
    this.m_ReportTreeView.AfterSelect += new TreeViewEventHandler(this.ReportTreeViewAfterSelect);
    this.m_CloseButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CloseButton.Location = new Point(468, 419);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 3;
    this.m_CloseButton.Text = "&Close";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClicked);
    this.m_ExportButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ExportButton.Location = new Point(386, 419);
    this.m_ExportButton.Name = "m_ExportButton";
    this.m_ExportButton.Size = new Size(76, 23);
    this.m_ExportButton.TabIndex = 2;
    this.m_ExportButton.Text = "&Export";
    this.m_ExportButton.UseVisualStyleBackColor = true;
    this.m_ExportButton.Click += new EventHandler(this.OnExportButtonClicked);
    this.m_ExportFileButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ExportFileButton.Location = new Point(502, 64 /*0x40*/);
    this.m_ExportFileButton.Name = "m_ExportFileButton";
    this.m_ExportFileButton.Size = new Size(24, 20);
    this.m_ExportFileButton.TabIndex = 7;
    this.m_ExportFileButton.TabStop = false;
    this.m_ExportFileButton.Text = "...";
    this.m_ExportFileButton.UseVisualStyleBackColor = true;
    this.m_ExportFileButton.Click += new EventHandler(this.OnExportFileButtonClick);
    this.m_ExportOptionsGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_TabExportRadioButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_CommaExportRadioButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportTypeCheckBox);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportRegionCheckBox);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFamilyCheckBox);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileTextBox);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileLabel);
    this.m_ExportOptionsGroupBox.Location = new Point(12, 320);
    this.m_ExportOptionsGroupBox.Name = "m_ExportOptionsGroupBox";
    this.m_ExportOptionsGroupBox.Size = new Size(532, 93);
    this.m_ExportOptionsGroupBox.TabIndex = 1;
    this.m_ExportOptionsGroupBox.TabStop = false;
    this.m_ExportOptionsGroupBox.Text = "Export Options";
    this.m_TabExportRadioButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_TabExportRadioButton.AutoSize = true;
    this.m_TabExportRadioButton.Location = new Point(181, 42);
    this.m_TabExportRadioButton.Name = "m_TabExportRadioButton";
    this.m_TabExportRadioButton.Size = new Size(139, 17);
    this.m_TabExportRadioButton.TabIndex = 4;
    this.m_TabExportRadioButton.TabStop = true;
    this.m_TabExportRadioButton.Text = "&Tab Delimited (Text File)";
    this.m_TabExportRadioButton.UseVisualStyleBackColor = true;
    this.m_CommaExportRadioButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_CommaExportRadioButton.AutoSize = true;
    this.m_CommaExportRadioButton.Location = new Point(6, 42);
    this.m_CommaExportRadioButton.Name = "m_CommaExportRadioButton";
    this.m_CommaExportRadioButton.Size = new Size(155, 17);
    this.m_CommaExportRadioButton.TabIndex = 3;
    this.m_CommaExportRadioButton.TabStop = true;
    this.m_CommaExportRadioButton.Text = "&Comma Delimited (Text File)";
    this.m_CommaExportRadioButton.UseVisualStyleBackColor = true;
    this.m_ExportTypeCheckBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ExportTypeCheckBox.AutoSize = true;
    this.m_ExportTypeCheckBox.Location = new Point(361, 19);
    this.m_ExportTypeCheckBox.Name = "m_ExportTypeCheckBox";
    this.m_ExportTypeCheckBox.Size = new Size(138, 17);
    this.m_ExportTypeCheckBox.TabIndex = 2;
    this.m_ExportTypeCheckBox.Text = "Export Type Information";
    this.m_ExportTypeCheckBox.UseVisualStyleBackColor = true;
    this.m_ExportRegionCheckBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ExportRegionCheckBox.AutoSize = true;
    this.m_ExportRegionCheckBox.Location = new Point(181, 19);
    this.m_ExportRegionCheckBox.Name = "m_ExportRegionCheckBox";
    this.m_ExportRegionCheckBox.Size = new Size(148, 17);
    this.m_ExportRegionCheckBox.TabIndex = 1;
    this.m_ExportRegionCheckBox.Text = "Export Region Information";
    this.m_ExportRegionCheckBox.UseVisualStyleBackColor = true;
    this.m_ExportFamilyCheckBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ExportFamilyCheckBox.AutoSize = true;
    this.m_ExportFamilyCheckBox.Location = new Point(6, 19);
    this.m_ExportFamilyCheckBox.Name = "m_ExportFamilyCheckBox";
    this.m_ExportFamilyCheckBox.Size = new Size(143, 17);
    this.m_ExportFamilyCheckBox.TabIndex = 0;
    this.m_ExportFamilyCheckBox.Text = "Export Family Information";
    this.m_ExportFamilyCheckBox.UseVisualStyleBackColor = true;
    this.m_ExportFileTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ExportFileTextBox.Location = new Point(58, 65);
    this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
    this.m_ExportFileTextBox.Size = new Size(438, 20);
    this.m_ExportFileTextBox.TabIndex = 6;
    this.m_ExportFileLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ExportFileLabel.AutoSize = true;
    this.m_ExportFileLabel.Location = new Point(6, 68);
    this.m_ExportFileLabel.Name = "m_ExportFileLabel";
    this.m_ExportFileLabel.Size = new Size(26, 13);
    this.m_ExportFileLabel.TabIndex = 5;
    this.m_ExportFileLabel.Text = "Fi&le:";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(556, 454);
    this.Controls.Add((Control) this.m_ExportOptionsGroupBox);
    this.Controls.Add((Control) this.m_ExportButton);
    this.Controls.Add((Control) this.m_CloseButton);
    this.Controls.Add((Control) this.m_MixReportGroupBox);
    this.MinimumSize = new Size(564, 481);
    this.Name = nameof (LandcaddMixReport);
    this.Text = "Plant Mix Report";
    this.FormClosing += new FormClosingEventHandler(this.OnLandcaddMixReportClosing);
    this.m_MixReportGroupBox.ResumeLayout(false);
    this.m_ExportOptionsGroupBox.ResumeLayout(false);
    this.m_ExportOptionsGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ExportButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }

  public enum RegionEdgingWarning
  {
    RegionEdgingNotFound,
    IssueWarning,
    WarningDisplayed,
  }
}
