﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantDWGCreatorForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantDWGCreatorForm : EPForm, IMessageFilter
{
  private ImportDWGData m_ImportData;
  private PlantDWGViewer m_Viewer;
  private Sketch3D m_CurrentSketch;
  private const int WM_KEYDOWN = 256 /*0x0100*/;
  private IContainer components;
  private PictureBox m_PreviewPictureBox;
  private GroupBox m_PreviewGroupBox;
  private ComboBox m_DetailLevelComboBox;
  private Label m_DetailLevelLabel;
  private Label m_PreviewLabel;
  private Button m_OKButton;
  private Button m_CloseButton;
  private Label m_ViewDirectionLabel;
  private ComboBox m_ViewDirectionComboBox;
  private Label m_DrawingFileLabel;
  private TextBox m_DrawingFileTextBox;
  private Label m_ImageTypeLabel;
  private ComboBox m_ImageTypeComboBox;
  private Label m_AutomaticallyPlaceLabel;
  private Label m_PlaceLevelLabel;
  private GroupBox m_ScalingGroupBox;
  private ComboBox m_UnitsComboBox;
  private TextBox m_ScaleTextBox;
  private Label m_ScaleFactorLabel;
  private Label m_UnitsLabel;
  private GroupBox m_ColorsGroupBox;
  private RadioButton m_InvertColorRadioButton;
  private RadioButton m_PreserveRadioButton;
  private RadioButton m_BlackWhiteRadioButton;
  private GroupBox m_PositioningGroupBox;
  private RadioButton m_Center2CenterRadioButton;
  private ComboBox m_LevelComboBox;
  private Label m_LayersLabel;
  private ComboBox m_LayersComboBox;
  private RadioButton m_Origin2OriginRadioButton;
  private TextBox m_FilenameTextBox;
  private Button m_FilePickerButton;
  private Label m_FileNameLabel;
  private Button m_DrawingFileBrowserButton;
  private Button m_ApplyButton;
  private Label m_PreviewWarningLabel;

  public PlantDWGCreatorForm(PlantDWGViewer _Viewer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("PlantDWGCreatorDialog");
    this.m_ImageTypeLabel.Text = EPShared.LocalRM.GetString("AMP_ImageTypeDialog");
    this.m_PreviewLabel.Text = EPShared.LocalRM.GetString("PreviewDialog");
    this.m_ColorsGroupBox.Text = EPShared.LocalRM.GetString("LayerLevelColorsDialog");
    this.m_BlackWhiteRadioButton.Text = EPShared.LocalRM.GetString("AMP_BlackAndWhiteDialog");
    this.m_PreserveRadioButton.Text = EPShared.LocalRM.GetString("AMP_PreserveColorsDialog");
    this.m_InvertColorRadioButton.Text = EPShared.LocalRM.GetString("I_AMP_nvertColorsDialog");
    this.m_LayersLabel.Text = EPShared.LocalRM.GetString("AMP_LayersDialog");
    this.m_PositioningGroupBox.Text = EPShared.LocalRM.GetString("PositioningDialog");
    this.m_AutomaticallyPlaceLabel.Text = EPShared.LocalRM.GetString("AutomaticallyPlaceDialog");
    this.m_Origin2OriginRadioButton.Text = EPShared.LocalRM.GetString("O_AMP_riginToOriginDialog");
    this.m_Center2CenterRadioButton.Text = EPShared.LocalRM.GetString("Cen_AMP_terToCenterDialog");
    this.m_PlaceLevelLabel.Text = EPShared.LocalRM.GetString("Plac_AMP_eAtLevelDialog");
    this.m_ScalingGroupBox.Text = EPShared.LocalRM.GetString("ScalingDialog");
    this.m_UnitsLabel.Text = EPShared.LocalRM.GetString("Import_AMP_UnitsDialog");
    this.m_ScaleFactorLabel.Text = EPShared.LocalRM.GetString("AMP_ScaleFactorDialog");
    this.m_PreviewWarningLabel.Text = EPShared.LocalRM.GetString("NotAllObjectsAppearDialog");
    this.m_PreviewGroupBox.Text = EPShared.LocalRM.GetString("PreviewDialog");
    this.m_DetailLevelLabel.Text = EPShared.LocalRM.GetString("AMP_DetailLevelDialog");
    this.m_ViewDirectionLabel.Text = EPShared.LocalRM.GetString("AMP_ViewDirectionDialog");
    this.m_FileNameLabel.Text = EPShared.LocalRM.GetString("NewFami_AMP_lySymbolDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
    this.m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.EPToolTip.SetToolTip((Control) this.m_DrawingFileBrowserButton, EPShared.LocalRM.GetString("LoadDrawingToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_FilePickerButton, EPShared.LocalRM.GetString("NewFamilyToolTip"));
    this.m_ImportData = new ImportDWGData(_Viewer.CurDocument);
    this.m_Viewer = _Viewer;
    this.m_CurrentSketch = _Viewer.CurrentSketch3D;
    this.InitializeControls();
    Application.AddMessageFilter((IMessageFilter) this);
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("TopViewDirection"));
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("FrontViewDirection"));
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("LeftViewDirection"));
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("RightViewDirection"));
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("BottomViewDirection"));
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("BackViewDirection"));
    this.m_ViewDirectionComboBox.Items.Add((object) EPShared.LocalRM.GetString("IsoMetricViewDirection"));
    this.m_ViewDirectionComboBox.SelectedIndex = 0;
    this.m_DetailLevelComboBox.Items.Add((object) EPShared.LocalRM.GetString("UndefinedDetailLevel"));
    this.m_DetailLevelComboBox.Items.Add((object) EPShared.LocalRM.GetString("CoarseDetailLevel"));
    this.m_DetailLevelComboBox.Items.Add((object) EPShared.LocalRM.GetString("MediumDetailLevel"));
    this.m_DetailLevelComboBox.Items.Add((object) EPShared.LocalRM.GetString("FineDetailLevel"));
    this.m_DetailLevelComboBox.SelectedIndex = 0;
    foreach (object dimensionType in this.m_ImportData.DimensionTypes)
      this.m_ImageTypeComboBox.Items.Add(dimensionType);
    this.m_ImageTypeComboBox.SelectedIndex = 0;
    foreach (object visibleLayersOnly in this.m_ImportData.VisibleLayersOnlyList)
      this.m_LayersComboBox.Items.Add(visibleLayersOnly);
    this.m_LayersComboBox.SelectedIndex = 0;
    foreach (object unit in this.m_ImportData.Units)
      this.m_UnitsComboBox.Items.Add(unit);
    this.m_UnitsComboBox.SelectedIndex = 0;
    foreach (Element view in this.m_ImportData.Views)
      this.m_LevelComboBox.Items.Add((object) view.Name);
    this.m_LevelComboBox.SelectedIndex = 0;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorFileSourceName", ref empty))
      this.m_DrawingFileTextBox.Text = empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorImageTypeOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < this.m_ImageTypeComboBox.Items.Count)
      this.m_ImageTypeComboBox.SelectedIndex = _nReturnValue;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorLayerColorOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_BlackWhiteRadioButton.Checked = true;
          break;
        case 1:
          this.m_PreserveRadioButton.Checked = true;
          break;
        default:
          this.m_InvertColorRadioButton.Checked = true;
          break;
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorLayersOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < this.m_LayersComboBox.Items.Count)
      this.m_LayersComboBox.SelectedIndex = _nReturnValue;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorPositioningOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_Origin2OriginRadioButton.Checked = true;
      else
        this.m_Center2CenterRadioButton.Checked = true;
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ImportData.CurDocument.PathName, "PlantDWGCreatorLevelOption", ref empty))
    {
      for (int index = 0; index < this.m_LevelComboBox.Items.Count; ++index)
      {
        if (string.Compare((string) this.m_LevelComboBox.Items[index], empty, true) == 0)
          this.m_LevelComboBox.SelectedIndex = index;
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorUnitsOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < this.m_UnitsComboBox.Items.Count)
      this.m_UnitsComboBox.SelectedIndex = _nReturnValue;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorScaleValue", ref empty))
      this.m_ScaleTextBox.Text = empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorFileName", ref empty))
      this.m_FilenameTextBox.Text = empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorViewDirectionOption", ref _nReturnValue) && _nReturnValue >= 0 && _nReturnValue < this.m_ViewDirectionComboBox.Items.Count)
      this.m_ViewDirectionComboBox.SelectedIndex = _nReturnValue;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlantDWGCreatorDetailLevelOption", ref _nReturnValue) || _nReturnValue < 0 || _nReturnValue >= this.m_DetailLevelComboBox.Items.Count)
      return;
    this.m_DetailLevelComboBox.SelectedIndex = _nReturnValue;
  }

  private void SaveSettings()
  {
    string empty = string.Empty;
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorFileSourceName", this.m_DrawingFileTextBox.Text);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorLayerColorOption", !this.m_BlackWhiteRadioButton.Checked ? (!this.m_PreserveRadioButton.Checked ? 2 : 1) : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorImageTypeOption", this.m_ImageTypeComboBox.SelectedIndex);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorLayersOption", this.m_LayersComboBox.SelectedIndex);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorPositioningOption", !this.m_Origin2OriginRadioButton.Checked ? 1 : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ImportData.CurDocument.PathName, "PlantDWGCreatorLevelOption", (string) this.m_LevelComboBox.SelectedItem);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorUnitsOption", this.m_UnitsComboBox.SelectedIndex);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorScaleValue", this.m_ScaleTextBox.Text);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorFileName", this.m_FilenameTextBox.Text);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorViewDirectionOption", this.m_ViewDirectionComboBox.SelectedIndex);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantDWGCreatorDetailLevelOption", this.m_DetailLevelComboBox.SelectedIndex);
  }

  public bool PreFilterMessage(ref Message _Message)
  {
    if (this.m_CurrentSketch == null || this.m_CurrentSketch.Data3D == null || _Message.Msg != 256 /*0x0100*/ || Cursor.Current != Cursors.Cross)
      return false;
    switch (new KeyEventArgs((Keys) (int) _Message.WParam).KeyCode)
    {
      case Keys.Escape:
        this.Close();
        break;
      case Keys.Prior:
        this.m_CurrentSketch.Data3D.RotateZ(true);
        break;
      case Keys.Next:
        this.m_CurrentSketch.Data3D.RotateZ(false);
        break;
      case Keys.End:
        this.m_CurrentSketch.Zoom(false);
        break;
      case Keys.Home:
        this.m_CurrentSketch.Zoom(true);
        break;
      case Keys.Left:
        this.m_CurrentSketch.Data3D.RotateY(true);
        break;
      case Keys.Up:
        this.m_CurrentSketch.Data3D.RotateX(true);
        break;
      case Keys.Right:
        this.m_CurrentSketch.Data3D.RotateY(false);
        break;
      case Keys.Down:
        this.m_CurrentSketch.Data3D.RotateX(false);
        break;
      case Keys.A:
        this.m_CurrentSketch.MoveX(true);
        break;
      case Keys.D:
        this.m_CurrentSketch.MoveX(false);
        break;
      case Keys.S:
        this.m_CurrentSketch.MoveY(true);
        break;
      case Keys.W:
        this.m_CurrentSketch.MoveY(false);
        break;
      default:
        return false;
    }
    return true;
  }

  private void OnPlantDWGCreatorFormClosed(object sender, FormClosedEventArgs e)
  {
    Application.RemoveMessageFilter((IMessageFilter) this);
  }

  private void OnPreviewBoxPaint(object sender, PaintEventArgs e)
  {
    if (this.m_CurrentSketch == null || this.m_CurrentSketch.Data3D == null)
      return;
    this.m_CurrentSketch.Draw(e.Graphics);
  }

  private void OnViewDirectionComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (this.m_ViewDirectionComboBox.SelectedIndex < 0 || this.m_ViewDirectionComboBox.SelectedIndex >= this.m_ViewDirectionComboBox.Items.Count || this.m_CurrentSketch == null || this.m_CurrentSketch.Data3D == null)
      return;
    this.m_CurrentSketch.Data3D.SetViewDirection((Graphics3DData.ViewDirections) this.m_ViewDirectionComboBox.SelectedIndex);
  }

  private void OnDetailLevelComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!this.m_DetailLevelComboBox.Focused)
      return;
    this.m_Viewer.DetailLevel = (ViewDetailLevel) this.m_DetailLevelComboBox.SelectedIndex;
  }

  private bool ValidateFileName()
  {
    string text1 = this.m_DrawingFileTextBox.Text;
    if (string.IsNullOrEmpty(text1))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySourceFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_DrawingFileTextBox.Focus();
      return false;
    }
    if (!File.Exists(text1))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySourceFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_DrawingFileTextBox.Focus();
      return false;
    }
    this.m_ImportData.ImportFileFullName = text1;
    string text2 = this.m_FilenameTextBox.Text;
    if (string.IsNullOrEmpty(text2))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FilenameTextBox.Focus();
      return false;
    }
    if (string.Compare(new FileInfo(text2).Extension, ".rfa", true) != 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FilenameTextBox.Focus();
      return false;
    }
    if (File.Exists(text2) && RevitUtility.CompareFileNames(this.m_ImportData.CurDocument.PathName, text2) != 0)
    {
      switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation))
      {
        case DialogResult.Cancel:
          return false;
        case DialogResult.Yes:
          Document CurDocument = (Document) null;
          if (ManagePlants.IsDocumentOpen(this.m_ImportData.CurDocument.Application, text2, ref CurDocument))
            CurDocument.Close(false);
          File.Delete(text2);
          break;
      }
    }
    this.m_ImportData.SaveAsFileName = text2;
    return true;
  }

  private void SetImportColorMode()
  {
    string str = !this.m_BlackWhiteRadioButton.Checked ? (!this.m_PreserveRadioButton.Checked ? this.m_InvertColorRadioButton.Text : this.m_PreserveRadioButton.Text) : this.m_BlackWhiteRadioButton.Text;
    int index1 = 0;
    for (int index2 = 0; index2 < this.m_ImportData.ColorModes.Count; ++index2)
    {
      if (str == this.m_ImportData.ColorModes[index2])
      {
        index1 = index2;
        break;
      }
    }
    this.m_ImportData.ImportColorMode = this.m_ImportData.EnumColorModes[index1];
  }

  private void SetImportPlacement()
  {
    string str = !this.m_Center2CenterRadioButton.Checked ? this.m_Origin2OriginRadioButton.Text : this.m_Center2CenterRadioButton.Text;
    int index1 = 0;
    for (int index2 = 0; index2 < this.m_ImportData.Placements.Count; ++index2)
    {
      if (str == this.m_ImportData.Placements[index2])
      {
        index1 = index2;
        break;
      }
    }
    this.m_ImportData.ImportPlacement = this.m_ImportData.EnumPlacements[index1];
  }

  private void SetImportViewsRelated()
  {
    string str = this.m_LevelComboBox.SelectedItem.ToString();
    foreach (View view in this.m_ImportData.Views)
    {
      if (str == ((Element) view).Name)
      {
        this.m_ImportData.ImportView = view;
        break;
      }
    }
    if (string.Compare(this.m_ImageTypeComboBox.SelectedItem.ToString(), EPShared.LocalRM.GetString("TwoDDWGSymbolDimensionType"), true) == 0)
      this.m_ImportData.ImportThisViewOnly = true;
    else
      this.m_ImportData.ImportThisViewOnly = false;
  }

  private void SetImportLayers()
  {
    this.m_ImportData.ImportVisibleLayersOnlyList = this.m_ImportData.EnumVisibleLayersOnlyList[this.m_LayersComboBox.SelectedIndex];
  }

  private void SetImportUnitsAndScaling()
  {
    if (this.m_UnitsComboBox.SelectedIndex == 7)
      this.m_ImportData.ImportCustomScale = ValueConversion.Parse(this.m_ScaleTextBox.Text);
    else
      this.m_ImportData.ImportUnit = this.m_ImportData.EnumUnits[this.m_UnitsComboBox.SelectedIndex];
  }

  private bool ImportDWGSymbol()
  {
    bool flag = false;
    if (this.ValidateFileName())
    {
      this.m_Viewer.TransactionContainer.Start(EPShared.LocalRM.GetString("ObtainDrawingImageTransaction"));
      this.m_Viewer.DeleteSelected();
      this.m_Viewer.TransactionContainer.Commit();
      this.SetImportColorMode();
      this.SetImportPlacement();
      this.SetImportViewsRelated();
      this.SetImportLayers();
      this.SetImportUnitsAndScaling();
      try
      {
        if (!this.m_ImportData.Import())
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("CannotImport_String") + Path.GetFileName(this.m_ImportData.ImportFileFullName) + EPShared.LocalRM.GetString("_InSettingString"), EPShared.LocalRM.GetString("ImportString"), MessageBoxIcon.Exclamation);
        }
        else
          flag = true;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(ex.ToString(), EPShared.LocalRM.GetString("ImportFailedString"), MessageBoxIcon.Hand);
      }
    }
    return flag;
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ImportDWGSymbol())
      return;
    this.SaveSettings();
    this.DialogResult = this.m_ImportData.CompleteTransaction();
    this.Close();
  }

  private void OnCloseButtonClick(object sender, EventArgs e)
  {
    this.m_Viewer.TransactionContainer.Start(EPShared.LocalRM.GetString("ObtainDrawingImageTransaction"));
    this.m_Viewer.DeleteSelected();
    this.m_Viewer.TransactionContainer.Commit();
    this.DialogResult = this.m_ImportData.CompleteTransaction();
    this.Close();
  }

  private void LoadFileSourceInformation()
  {
    if (!(this.m_DrawingFileTextBox.Text != string.Empty))
      return;
    if (this.m_Viewer.SetupPreview(this.m_DrawingFileTextBox.Text))
    {
      this.m_DetailLevelComboBox.SelectedIndex = (int) this.m_Viewer.DetailLevel;
      this.m_CurrentSketch = this.m_Viewer.CurrentSketch3D;
      this.m_CurrentSketch.DisplayBBox = new RectangleF(new PointF(0.0f, 0.0f), (SizeF) this.m_PreviewPictureBox.Size);
      this.m_CurrentSketch.UpdateViewEvent += (UpdateViewDelegate) (() => this.m_PreviewPictureBox.Invalidate());
      this.m_ViewDirectionComboBox.SelectedIndex = -1;
      this.ResetViewDirection();
    }
    else
    {
      this.m_CurrentSketch = this.m_Viewer.CurrentSketch3D;
      this.m_PreviewPictureBox.Invalidate();
    }
  }

  private void OnFileSourceLeaveFocus(object sender, EventArgs e)
  {
    this.LoadFileSourceInformation();
  }

  private void OnFileSourceTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.LoadFileSourceInformation();
  }

  private void OnBrowserButtonClick(object sender, EventArgs e)
  {
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      openFileDialog.Title = EPShared.LocalRM.GetString("ImportDWGTitle");
      openFileDialog.Filter = ApplicationUtility.GetString("DWGFilePickerFilter");
      openFileDialog.RestoreDirectory = true;
      if (openFileDialog.ShowDialog() == DialogResult.Cancel)
        return;
      this.m_DrawingFileTextBox.Text = openFileDialog.FileName;
      this.m_DrawingFileTextBox.Focus();
    }
  }

  private void OnComboBoxUnitsSelectedIndexChanged(object sender, EventArgs e)
  {
    this.m_ScaleTextBox.Enabled = this.m_UnitsComboBox.SelectedIndex == 7;
  }

  private void OnTextBoxScaleKeyPress(object sender, KeyPressEventArgs e)
  {
    if ((e.KeyChar < '.' || e.KeyChar > '9') && (e.KeyChar != '\b' || e.KeyChar == '/'))
      e.Handled = true;
    else
      e.Handled = false;
  }

  private void OnTextBoxScaleTextChanged(object sender, EventArgs e)
  {
    bool flag = false;
    string str = this.m_ScaleTextBox.Text.Trim();
    StringBuilder stringBuilder = new StringBuilder();
    for (int startIndex = 0; startIndex < str.Length; ++startIndex)
    {
      char c = char.Parse(str.Substring(startIndex, 1).ToString());
      if (!flag && c == '.')
      {
        stringBuilder.Append(c);
        flag = true;
      }
      else if (char.IsDigit(c))
        stringBuilder.Append(c);
    }
    this.m_ScaleTextBox.Text = stringBuilder.ToString();
  }

  private void OnComboBoxImageTypeSelectedIndexChanged(object sender, EventArgs e)
  {
    this.ResetViewDirection();
  }

  private void ResetViewDirection()
  {
    if (string.Compare(this.m_ImageTypeComboBox.SelectedItem.ToString(), EPShared.LocalRM.GetString("TwoDDWGSymbolDimensionType"), true) == 0)
      this.m_ViewDirectionComboBox.SelectedIndex = 0;
    else
      this.m_ViewDirectionComboBox.SelectedIndex = 1;
  }

  private void OnFilePickerButton(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_FilenameTextBox.Text = saveFileDialog.FileName;
    this.m_FilenameTextBox.Focus();
  }

  private void OnApplyButtonClick(object sender, EventArgs e) => this.ImportDWGSymbol();

  private void OnPlantDWGCreatorFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void AddExtensionToFilename()
  {
    if (string.IsNullOrEmpty(this.m_FilenameTextBox.Text) || !(new FileInfo(this.m_FilenameTextBox.Text).Extension == string.Empty))
      return;
    this.m_FilenameTextBox.Text += ".rfa";
  }

  private void OnFilenameTextBoxLeave(object sender, EventArgs e) => this.AddExtensionToFilename();

  private void OnFilenameTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.AddExtensionToFilename();
  }

  public string SaveAsFileName => this.m_FilenameTextBox.Text;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_PreviewPictureBox = new PictureBox();
    this.m_PreviewGroupBox = new GroupBox();
    this.m_ViewDirectionLabel = new Label();
    this.m_ViewDirectionComboBox = new ComboBox();
    this.m_DetailLevelLabel = new Label();
    this.m_DetailLevelComboBox = new ComboBox();
    this.m_PreviewLabel = new Label();
    this.m_OKButton = new Button();
    this.m_CloseButton = new Button();
    this.m_DrawingFileLabel = new Label();
    this.m_DrawingFileTextBox = new TextBox();
    this.m_ImageTypeLabel = new Label();
    this.m_ImageTypeComboBox = new ComboBox();
    this.m_AutomaticallyPlaceLabel = new Label();
    this.m_PlaceLevelLabel = new Label();
    this.m_ScalingGroupBox = new GroupBox();
    this.m_UnitsComboBox = new ComboBox();
    this.m_ScaleTextBox = new TextBox();
    this.m_ScaleFactorLabel = new Label();
    this.m_UnitsLabel = new Label();
    this.m_ColorsGroupBox = new GroupBox();
    this.m_InvertColorRadioButton = new RadioButton();
    this.m_PreserveRadioButton = new RadioButton();
    this.m_BlackWhiteRadioButton = new RadioButton();
    this.m_PositioningGroupBox = new GroupBox();
    this.m_Origin2OriginRadioButton = new RadioButton();
    this.m_Center2CenterRadioButton = new RadioButton();
    this.m_LevelComboBox = new ComboBox();
    this.m_LayersLabel = new Label();
    this.m_LayersComboBox = new ComboBox();
    this.m_FilenameTextBox = new TextBox();
    this.m_FilePickerButton = new Button();
    this.m_FileNameLabel = new Label();
    this.m_DrawingFileBrowserButton = new Button();
    this.m_ApplyButton = new Button();
    this.m_PreviewWarningLabel = new Label();
    ((ISupportInitialize) this.m_PreviewPictureBox).BeginInit();
    this.m_PreviewGroupBox.SuspendLayout();
    this.m_ScalingGroupBox.SuspendLayout();
    this.m_ColorsGroupBox.SuspendLayout();
    this.m_PositioningGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_PreviewPictureBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_PreviewPictureBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_PreviewPictureBox.Cursor = Cursors.Cross;
    this.m_PreviewPictureBox.Location = new Point(12, 57);
    this.m_PreviewPictureBox.Name = "m_PreviewPictureBox";
    this.m_PreviewPictureBox.Size = new Size(460, 377);
    this.m_PreviewPictureBox.TabIndex = 4;
    this.m_PreviewPictureBox.TabStop = false;
    this.m_PreviewPictureBox.Paint += new PaintEventHandler(this.OnPreviewBoxPaint);
    this.m_PreviewGroupBox.Controls.Add((Control) this.m_ViewDirectionLabel);
    this.m_PreviewGroupBox.Controls.Add((Control) this.m_ViewDirectionComboBox);
    this.m_PreviewGroupBox.Controls.Add((Control) this.m_DetailLevelLabel);
    this.m_PreviewGroupBox.Controls.Add((Control) this.m_DetailLevelComboBox);
    this.m_PreviewGroupBox.Location = new Point(12, 463);
    this.m_PreviewGroupBox.Name = "m_PreviewGroupBox";
    this.m_PreviewGroupBox.Size = new Size(460, 68);
    this.m_PreviewGroupBox.TabIndex = 12;
    this.m_PreviewGroupBox.TabStop = false;
    this.m_PreviewGroupBox.Text = "Preview";
    this.m_ViewDirectionLabel.AutoSize = true;
    this.m_ViewDirectionLabel.Location = new Point(233, 16 /*0x10*/);
    this.m_ViewDirectionLabel.Name = "m_ViewDirectionLabel";
    this.m_ViewDirectionLabel.Size = new Size(78, 13);
    this.m_ViewDirectionLabel.TabIndex = 2;
    this.m_ViewDirectionLabel.Text = "&View Direction:";
    this.m_ViewDirectionComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ViewDirectionComboBox.FormattingEnabled = true;
    this.m_ViewDirectionComboBox.Location = new Point(233, 33);
    this.m_ViewDirectionComboBox.Name = "m_ViewDirectionComboBox";
    this.m_ViewDirectionComboBox.Size = new Size(221, 21);
    this.m_ViewDirectionComboBox.TabIndex = 3;
    this.m_ViewDirectionComboBox.SelectedIndexChanged += new EventHandler(this.OnViewDirectionComboBoxSelectedIndexChanged);
    this.m_DetailLevelLabel.AutoSize = true;
    this.m_DetailLevelLabel.Location = new Point(6, 16 /*0x10*/);
    this.m_DetailLevelLabel.Name = "m_DetailLevelLabel";
    this.m_DetailLevelLabel.Size = new Size(66, 13);
    this.m_DetailLevelLabel.TabIndex = 0;
    this.m_DetailLevelLabel.Text = "&Detail Level:";
    this.m_DetailLevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_DetailLevelComboBox.FormattingEnabled = true;
    this.m_DetailLevelComboBox.Location = new Point(6, 33);
    this.m_DetailLevelComboBox.Name = "m_DetailLevelComboBox";
    this.m_DetailLevelComboBox.Size = new Size(221, 21);
    this.m_DetailLevelComboBox.TabIndex = 1;
    this.m_DetailLevelComboBox.SelectedIndexChanged += new EventHandler(this.OnDetailLevelComboBoxSelectedIndexChanged);
    this.m_PreviewLabel.AutoSize = true;
    this.m_PreviewLabel.Location = new Point(13, 40);
    this.m_PreviewLabel.Name = "m_PreviewLabel";
    this.m_PreviewLabel.Size = new Size(48 /*0x30*/, 13);
    this.m_PreviewLabel.TabIndex = 5;
    this.m_PreviewLabel.Text = "Preview:";
    this.m_OKButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_OKButton.Location = new Point(503, 564);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 16 /*0x10*/;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CloseButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CloseButton.DialogResult = DialogResult.Cancel;
    this.m_CloseButton.Location = new Point(584, 564);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(75, 23);
    this.m_CloseButton.TabIndex = 17;
    this.m_CloseButton.Text = "&Close";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClick);
    this.m_DrawingFileLabel.AutoSize = true;
    this.m_DrawingFileLabel.Location = new Point(12, 15);
    this.m_DrawingFileLabel.Name = "m_DrawingFileLabel";
    this.m_DrawingFileLabel.Size = new Size(68, 13);
    this.m_DrawingFileLabel.TabIndex = 0;
    this.m_DrawingFileLabel.Text = "&Drawing File:";
    this.m_DrawingFileTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DrawingFileTextBox.Location = new Point(142, 12);
    this.m_DrawingFileTextBox.Name = "m_DrawingFileTextBox";
    this.m_DrawingFileTextBox.Size = new Size(300, 20);
    this.m_DrawingFileTextBox.TabIndex = 1;
    this.m_DrawingFileTextBox.KeyDown += new KeyEventHandler(this.OnFileSourceTextBoxKeyDown);
    this.m_DrawingFileTextBox.Leave += new EventHandler(this.OnFileSourceLeaveFocus);
    this.m_ImageTypeLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ImageTypeLabel.AutoSize = true;
    this.m_ImageTypeLabel.Location = new Point(478, 16 /*0x10*/);
    this.m_ImageTypeLabel.Name = "m_ImageTypeLabel";
    this.m_ImageTypeLabel.Size = new Size(66, 13);
    this.m_ImageTypeLabel.TabIndex = 3;
    this.m_ImageTypeLabel.Text = "&Image Type:";
    this.m_ImageTypeComboBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ImageTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ImageTypeComboBox.FormattingEnabled = true;
    this.m_ImageTypeComboBox.Location = new Point(590, 12);
    this.m_ImageTypeComboBox.Name = "m_ImageTypeComboBox";
    this.m_ImageTypeComboBox.Size = new Size(150, 21);
    this.m_ImageTypeComboBox.TabIndex = 4;
    this.m_ImageTypeComboBox.SelectedIndexChanged += new EventHandler(this.OnComboBoxImageTypeSelectedIndexChanged);
    this.m_AutomaticallyPlaceLabel.AutoSize = true;
    this.m_AutomaticallyPlaceLabel.Location = new Point(15, 18);
    this.m_AutomaticallyPlaceLabel.Name = "m_AutomaticallyPlaceLabel";
    this.m_AutomaticallyPlaceLabel.Size = new Size(98, 13);
    this.m_AutomaticallyPlaceLabel.TabIndex = 0;
    this.m_AutomaticallyPlaceLabel.Text = "Automatically place";
    this.m_PlaceLevelLabel.AutoSize = true;
    this.m_PlaceLevelLabel.Location = new Point(14, 87);
    this.m_PlaceLevelLabel.Name = "m_PlaceLevelLabel";
    this.m_PlaceLevelLabel.Size = new Size(78, 13);
    this.m_PlaceLevelLabel.TabIndex = 3;
    this.m_PlaceLevelLabel.Text = "Plac&e at Level:";
    this.m_ScalingGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ScalingGroupBox.Controls.Add((Control) this.m_UnitsComboBox);
    this.m_ScalingGroupBox.Controls.Add((Control) this.m_ScaleTextBox);
    this.m_ScalingGroupBox.Controls.Add((Control) this.m_ScaleFactorLabel);
    this.m_ScalingGroupBox.Controls.Add((Control) this.m_UnitsLabel);
    this.m_ScalingGroupBox.Location = new Point(478, 305);
    this.m_ScalingGroupBox.Name = "m_ScalingGroupBox";
    this.m_ScalingGroupBox.Size = new Size(262, 74);
    this.m_ScalingGroupBox.TabIndex = 10;
    this.m_ScalingGroupBox.TabStop = false;
    this.m_ScalingGroupBox.Text = "Scaling";
    this.m_UnitsComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_UnitsComboBox.FormattingEnabled = true;
    this.m_UnitsComboBox.Location = new Point(135, 18);
    this.m_UnitsComboBox.Name = "m_UnitsComboBox";
    this.m_UnitsComboBox.Size = new Size(121, 21);
    this.m_UnitsComboBox.TabIndex = 1;
    this.m_UnitsComboBox.SelectedIndexChanged += new EventHandler(this.OnComboBoxUnitsSelectedIndexChanged);
    this.m_ScaleTextBox.Enabled = false;
    this.m_ScaleTextBox.Location = new Point(134, 45);
    this.m_ScaleTextBox.Name = "m_ScaleTextBox";
    this.m_ScaleTextBox.Size = new Size(122, 20);
    this.m_ScaleTextBox.TabIndex = 3;
    this.m_ScaleTextBox.Text = "1.000000";
    this.m_ScaleTextBox.TextChanged += new EventHandler(this.OnTextBoxScaleTextChanged);
    this.m_ScaleTextBox.KeyPress += new KeyPressEventHandler(this.OnTextBoxScaleKeyPress);
    this.m_ScaleFactorLabel.AutoSize = true;
    this.m_ScaleFactorLabel.Location = new Point(6, 48 /*0x30*/);
    this.m_ScaleFactorLabel.Name = "m_ScaleFactorLabel";
    this.m_ScaleFactorLabel.Size = new Size(70, 13);
    this.m_ScaleFactorLabel.TabIndex = 2;
    this.m_ScaleFactorLabel.Text = "&Scale Factor:";
    this.m_UnitsLabel.AutoSize = true;
    this.m_UnitsLabel.Location = new Point(7, 22);
    this.m_UnitsLabel.Name = "m_UnitsLabel";
    this.m_UnitsLabel.Size = new Size(66, 13);
    this.m_UnitsLabel.TabIndex = 0;
    this.m_UnitsLabel.Text = "Import &Units:";
    this.m_ColorsGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ColorsGroupBox.Controls.Add((Control) this.m_InvertColorRadioButton);
    this.m_ColorsGroupBox.Controls.Add((Control) this.m_PreserveRadioButton);
    this.m_ColorsGroupBox.Controls.Add((Control) this.m_BlackWhiteRadioButton);
    this.m_ColorsGroupBox.Location = new Point(478, 57);
    this.m_ColorsGroupBox.Name = "m_ColorsGroupBox";
    this.m_ColorsGroupBox.Size = new Size(262, 95);
    this.m_ColorsGroupBox.TabIndex = 6;
    this.m_ColorsGroupBox.TabStop = false;
    this.m_ColorsGroupBox.Text = "Layer/Level Colors";
    this.m_InvertColorRadioButton.AutoSize = true;
    this.m_InvertColorRadioButton.Checked = true;
    this.m_InvertColorRadioButton.Location = new Point(14, 66);
    this.m_InvertColorRadioButton.Name = "m_InvertColorRadioButton";
    this.m_InvertColorRadioButton.Size = new Size(84, 17);
    this.m_InvertColorRadioButton.TabIndex = 2;
    this.m_InvertColorRadioButton.TabStop = true;
    this.m_InvertColorRadioButton.Text = "I&nvert Colors";
    this.m_InvertColorRadioButton.UseVisualStyleBackColor = true;
    this.m_PreserveRadioButton.AutoSize = true;
    this.m_PreserveRadioButton.Location = new Point(14, 43);
    this.m_PreserveRadioButton.Name = "m_PreserveRadioButton";
    this.m_PreserveRadioButton.Size = new Size(99, 17);
    this.m_PreserveRadioButton.TabIndex = 1;
    this.m_PreserveRadioButton.Text = "&Preserve Colors";
    this.m_PreserveRadioButton.UseVisualStyleBackColor = true;
    this.m_BlackWhiteRadioButton.AutoSize = true;
    this.m_BlackWhiteRadioButton.Location = new Point(15, 20);
    this.m_BlackWhiteRadioButton.Name = "m_BlackWhiteRadioButton";
    this.m_BlackWhiteRadioButton.Size = new Size(104, 17);
    this.m_BlackWhiteRadioButton.TabIndex = 0;
    this.m_BlackWhiteRadioButton.Text = "&Black and White";
    this.m_BlackWhiteRadioButton.UseVisualStyleBackColor = true;
    this.m_PositioningGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_PositioningGroupBox.Controls.Add((Control) this.m_Origin2OriginRadioButton);
    this.m_PositioningGroupBox.Controls.Add((Control) this.m_AutomaticallyPlaceLabel);
    this.m_PositioningGroupBox.Controls.Add((Control) this.m_PlaceLevelLabel);
    this.m_PositioningGroupBox.Controls.Add((Control) this.m_Center2CenterRadioButton);
    this.m_PositioningGroupBox.Controls.Add((Control) this.m_LevelComboBox);
    this.m_PositioningGroupBox.Location = new Point(478, 185);
    this.m_PositioningGroupBox.Name = "m_PositioningGroupBox";
    this.m_PositioningGroupBox.Size = new Size(262, 114);
    this.m_PositioningGroupBox.TabIndex = 9;
    this.m_PositioningGroupBox.TabStop = false;
    this.m_PositioningGroupBox.Text = "Positioning";
    this.m_Origin2OriginRadioButton.AutoSize = true;
    this.m_Origin2OriginRadioButton.Checked = true;
    this.m_Origin2OriginRadioButton.Location = new Point(19, 37);
    this.m_Origin2OriginRadioButton.Name = "m_Origin2OriginRadioButton";
    this.m_Origin2OriginRadioButton.Size = new Size(94, 17);
    this.m_Origin2OriginRadioButton.TabIndex = 1;
    this.m_Origin2OriginRadioButton.TabStop = true;
    this.m_Origin2OriginRadioButton.Text = "O&rigin-to-Origin";
    this.m_Origin2OriginRadioButton.UseVisualStyleBackColor = true;
    this.m_Center2CenterRadioButton.AutoSize = true;
    this.m_Center2CenterRadioButton.Location = new Point(19, 60);
    this.m_Center2CenterRadioButton.Name = "m_Center2CenterRadioButton";
    this.m_Center2CenterRadioButton.Size = new Size(102, 17);
    this.m_Center2CenterRadioButton.TabIndex = 2;
    this.m_Center2CenterRadioButton.Text = "Cen&ter-to-Center";
    this.m_Center2CenterRadioButton.UseVisualStyleBackColor = true;
    this.m_LevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LevelComboBox.FormattingEnabled = true;
    this.m_LevelComboBox.Location = new Point(134, 84);
    this.m_LevelComboBox.Name = "m_LevelComboBox";
    this.m_LevelComboBox.Size = new Size(122, 21);
    this.m_LevelComboBox.TabIndex = 4;
    this.m_LayersLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_LayersLabel.AutoSize = true;
    this.m_LayersLabel.Location = new Point(482, 162);
    this.m_LayersLabel.Name = "m_LayersLabel";
    this.m_LayersLabel.Size = new Size(41, 13);
    this.m_LayersLabel.TabIndex = 7;
    this.m_LayersLabel.Text = "&Layers:";
    this.m_LayersComboBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_LayersComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LayersComboBox.FormattingEnabled = true;
    this.m_LayersComboBox.Location = new Point(590, 158);
    this.m_LayersComboBox.Name = "m_LayersComboBox";
    this.m_LayersComboBox.Size = new Size(150, 21);
    this.m_LayersComboBox.TabIndex = 8;
    this.m_FilenameTextBox.Location = new Point(142, 537);
    this.m_FilenameTextBox.Name = "m_FilenameTextBox";
    this.m_FilenameTextBox.Size = new Size(300, 20);
    this.m_FilenameTextBox.TabIndex = 14;
    this.m_FilenameTextBox.KeyDown += new KeyEventHandler(this.OnFilenameTextBoxKeyDown);
    this.m_FilenameTextBox.Leave += new EventHandler(this.OnFilenameTextBoxLeave);
    this.m_FilePickerButton.Location = new Point(448, 537);
    this.m_FilePickerButton.Name = "m_FilePickerButton";
    this.m_FilePickerButton.Size = new Size(24, 20);
    this.m_FilePickerButton.TabIndex = 15;
    this.m_FilePickerButton.TabStop = false;
    this.m_FilePickerButton.Text = "...";
    this.m_FilePickerButton.UseVisualStyleBackColor = true;
    this.m_FilePickerButton.Click += new EventHandler(this.OnFilePickerButton);
    this.m_FileNameLabel.AutoSize = true;
    this.m_FileNameLabel.Location = new Point(12, 540);
    this.m_FileNameLabel.Name = "m_FileNameLabel";
    this.m_FileNameLabel.Size = new Size(101, 13);
    this.m_FileNameLabel.TabIndex = 13;
    this.m_FileNameLabel.Text = "New Fami&ly Symbol:";
    this.m_DrawingFileBrowserButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_DrawingFileBrowserButton.Location = new Point(448, 12);
    this.m_DrawingFileBrowserButton.Name = "m_DrawingFileBrowserButton";
    this.m_DrawingFileBrowserButton.Size = new Size(24, 20);
    this.m_DrawingFileBrowserButton.TabIndex = 2;
    this.m_DrawingFileBrowserButton.TabStop = false;
    this.m_DrawingFileBrowserButton.Text = "...";
    this.m_DrawingFileBrowserButton.UseVisualStyleBackColor = true;
    this.m_DrawingFileBrowserButton.Click += new EventHandler(this.OnBrowserButtonClick);
    this.m_ApplyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ApplyButton.Location = new Point(665, 564);
    this.m_ApplyButton.Name = "m_ApplyButton";
    this.m_ApplyButton.Size = new Size(75, 23);
    this.m_ApplyButton.TabIndex = 18;
    this.m_ApplyButton.Text = "&Apply";
    this.m_ApplyButton.UseVisualStyleBackColor = true;
    this.m_ApplyButton.Click += new EventHandler(this.OnApplyButtonClick);
    this.m_PreviewWarningLabel.AutoSize = true;
    this.m_PreviewWarningLabel.Location = new Point(12, 440);
    this.m_PreviewWarningLabel.Name = "m_PreviewWarningLabel";
    this.m_PreviewWarningLabel.Size = new Size(208 /*0xD0*/, 13);
    this.m_PreviewWarningLabel.TabIndex = 11;
    this.m_PreviewWarningLabel.Text = "Not all objects may appear on the preview.";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
    this.ClientSize = new Size(752, 599);
    this.Controls.Add((Control) this.m_PreviewWarningLabel);
    this.Controls.Add((Control) this.m_ApplyButton);
    this.Controls.Add((Control) this.m_DrawingFileBrowserButton);
    this.Controls.Add((Control) this.m_FilenameTextBox);
    this.Controls.Add((Control) this.m_FilePickerButton);
    this.Controls.Add((Control) this.m_FileNameLabel);
    this.Controls.Add((Control) this.m_ScalingGroupBox);
    this.Controls.Add((Control) this.m_ColorsGroupBox);
    this.Controls.Add((Control) this.m_PositioningGroupBox);
    this.Controls.Add((Control) this.m_LayersLabel);
    this.Controls.Add((Control) this.m_LayersComboBox);
    this.Controls.Add((Control) this.m_ImageTypeLabel);
    this.Controls.Add((Control) this.m_ImageTypeComboBox);
    this.Controls.Add((Control) this.m_DrawingFileLabel);
    this.Controls.Add((Control) this.m_DrawingFileTextBox);
    this.Controls.Add((Control) this.m_CloseButton);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_PreviewLabel);
    this.Controls.Add((Control) this.m_PreviewGroupBox);
    this.Controls.Add((Control) this.m_PreviewPictureBox);
    this.MinimumSize = new Size(700, 626);
    this.Name = nameof (PlantDWGCreatorForm);
    this.Text = "Plant DWG Creator";
    this.FormClosed += new FormClosedEventHandler(this.OnPlantDWGCreatorFormClosed);
    this.FormClosing += new FormClosingEventHandler(this.OnPlantDWGCreatorFormClosing);
    ((ISupportInitialize) this.m_PreviewPictureBox).EndInit();
    this.m_PreviewGroupBox.ResumeLayout(false);
    this.m_PreviewGroupBox.PerformLayout();
    this.m_ScalingGroupBox.ResumeLayout(false);
    this.m_ScalingGroupBox.PerformLayout();
    this.m_ColorsGroupBox.ResumeLayout(false);
    this.m_ColorsGroupBox.PerformLayout();
    this.m_PositioningGroupBox.ResumeLayout(false);
    this.m_PositioningGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ApplyButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
