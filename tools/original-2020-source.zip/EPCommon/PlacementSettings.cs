﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlacementSettings
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class PlacementSettings
{
  private LocateType m_LocateType;
  private PlacementType m_PlacementType;
  private bool m_bDeleteExistingChecked;
  private bool m_bExistingElementChecked;
  private bool m_bPlaceGroupTagChecked;
  private bool m_bLeaderedTagChecked;
  private Level m_Level;
  private View m_View;
  private FamilySymbol m_Type;
  private List<TopographySurfaceContainer> m_SurfaceList;
  private double m_dSetbackSpacing;
  private double m_dHeight;
  private double m_dHeightVariance;
  private double m_dWidth;
  private double m_dWidthVariance;
  private double m_dPlantSpacing;
  private double m_dStartingDistance;
  private double m_dRotationAngle;
  private FamilySymbol m_PlacementSymbol;
  private List<KeyValuePair<string, string>> m_GenericModelIDList;
  private bool m_bUseRightSide;
  private bool m_bIsReverse;
  private EPTransactionContainer m_TransactionContainer;
  private bool m_bAlignTo;
  private ParkingPlacementSettings m_ParkingPlacementSettings;
  private string m_strFirstLegSegmentID;
  private string m_strFirstPlacementSegmentID;
  private string m_strLastLegSegmentID;

  public PlacementSettings()
  {
    this.m_LocateType = LocateType.Plant;
    this.m_PlacementType = PlacementType.HedgeRowCenter;
    this.m_bDeleteExistingChecked = false;
    this.m_bExistingElementChecked = true;
    this.m_bPlaceGroupTagChecked = false;
    this.m_Level = (Level) null;
    this.m_View = (View) null;
    this.m_Type = (FamilySymbol) null;
    this.m_SurfaceList = (List<TopographySurfaceContainer>) null;
    this.m_dSetbackSpacing = 0.0;
    this.m_dHeight = 0.0;
    this.m_dHeightVariance = 0.0;
    this.m_dWidth = 0.0;
    this.m_dWidthVariance = 0.0;
    this.m_dPlantSpacing = 0.0;
    this.m_dRotationAngle = 0.0;
    this.m_dStartingDistance = 0.0;
    this.m_PlacementSymbol = (FamilySymbol) null;
    this.m_GenericModelIDList = (List<KeyValuePair<string, string>>) null;
    this.m_bUseRightSide = false;
    this.m_bIsReverse = false;
    this.m_TransactionContainer = (EPTransactionContainer) null;
    this.m_bAlignTo = false;
    this.m_ParkingPlacementSettings = (ParkingPlacementSettings) null;
    this.m_strFirstLegSegmentID = string.Empty;
    this.m_strFirstPlacementSegmentID = string.Empty;
  }

  public PlacementSettings(
    LocateType _LocateType,
    PlacementType _PlantPlacementType,
    bool _bDeleteExistingChecked,
    bool _bExistingElementChecked,
    bool _bPlaceGroupTagChecked,
    Level _Level,
    View _View,
    FamilySymbol _Type,
    List<TopographySurfaceContainer> _SurfaceList,
    double _dSetbackSpacing,
    double _dHeight,
    double _dHeightVariance,
    double _dWidth,
    double _dWidthVariance,
    double _dPlantSpacing,
    double _dRotationAngle,
    double _dStartingDistance,
    FamilySymbol _PlacementSymbol,
    EPTransactionContainer _TransactionContainer)
  {
    this.m_LocateType = _LocateType;
    this.m_PlacementType = _PlantPlacementType;
    this.m_bDeleteExistingChecked = _bDeleteExistingChecked;
    this.m_bExistingElementChecked = _bExistingElementChecked;
    this.m_bPlaceGroupTagChecked = _bPlaceGroupTagChecked;
    this.m_Level = _Level;
    this.m_View = _View;
    this.m_Type = _Type;
    this.m_SurfaceList = _SurfaceList;
    this.m_dSetbackSpacing = _dSetbackSpacing;
    this.m_dHeight = _dHeight;
    this.m_dHeightVariance = _dHeightVariance;
    this.m_dWidth = _dWidth;
    this.m_dWidthVariance = _dWidthVariance;
    this.m_dPlantSpacing = _dPlantSpacing;
    this.m_dRotationAngle = _dRotationAngle;
    this.m_dStartingDistance = _dStartingDistance;
    this.m_PlacementSymbol = _PlacementSymbol;
    this.m_GenericModelIDList = (List<KeyValuePair<string, string>>) null;
    this.m_bUseRightSide = false;
    this.m_bIsReverse = false;
    this.m_TransactionContainer = _TransactionContainer;
    this.m_bAlignTo = false;
    this.m_ParkingPlacementSettings = (ParkingPlacementSettings) null;
    this.m_strFirstLegSegmentID = string.Empty;
    this.m_strFirstPlacementSegmentID = string.Empty;
  }

  public ParkingPlacementSettings Parking
  {
    get
    {
      if (this.m_ParkingPlacementSettings == null)
        this.m_ParkingPlacementSettings = new ParkingPlacementSettings();
      return this.m_ParkingPlacementSettings;
    }
  }

  public LocateType LocateType
  {
    get => this.m_LocateType;
    set => this.m_LocateType = value;
  }

  public PlacementType PlacementType
  {
    get => this.m_PlacementType;
    set => this.m_PlacementType = value;
  }

  public bool DeleteExistingChecked
  {
    get => this.m_bDeleteExistingChecked;
    set => this.m_bDeleteExistingChecked = value;
  }

  public bool ExistingElementChecked
  {
    get => this.m_bExistingElementChecked;
    set => this.m_bExistingElementChecked = value;
  }

  public bool PlaceGroupTagChecked
  {
    get => this.m_bPlaceGroupTagChecked;
    set => this.m_bPlaceGroupTagChecked = value;
  }

  public bool LeaderedTagChecked
  {
    get => this.m_bLeaderedTagChecked;
    set => this.m_bLeaderedTagChecked = value;
  }

  public Level Level
  {
    get => this.m_Level;
    set => this.m_Level = value;
  }

  public View View
  {
    get => this.m_View;
    set => this.m_View = value;
  }

  public FamilySymbol Type
  {
    get => this.m_Type;
    set => this.m_Type = value;
  }

  public List<TopographySurfaceContainer> SurfaceList
  {
    get => this.m_SurfaceList;
    set => this.m_SurfaceList = value;
  }

  public double SetbackSpacing
  {
    get => this.m_dSetbackSpacing;
    set => this.m_dSetbackSpacing = value;
  }

  public double Height
  {
    get => this.m_dHeight;
    set => this.m_dHeight = value;
  }

  public double HeightVariance
  {
    get => this.m_dHeightVariance;
    set => this.m_dHeightVariance = value;
  }

  public double Width
  {
    get => this.m_dWidth;
    set => this.m_dWidth = value;
  }

  public double WidthVariance
  {
    get => this.m_dWidthVariance;
    set => this.m_dWidthVariance = value;
  }

  public double PlantSpacing
  {
    get => this.m_dPlantSpacing;
    set => this.m_dPlantSpacing = value;
  }

  public double RotationAngle
  {
    get => this.m_dRotationAngle;
    set => this.m_dRotationAngle = value;
  }

  public double StartingDistance
  {
    get => this.m_dStartingDistance;
    set => this.m_dStartingDistance = value;
  }

  public FamilySymbol PlacementSymbol
  {
    get => this.m_PlacementSymbol;
    set => this.m_PlacementSymbol = value;
  }

  public List<KeyValuePair<string, string>> GenericModelIDList
  {
    get => this.m_GenericModelIDList;
    set => this.m_GenericModelIDList = value;
  }

  public bool UseRightSide
  {
    get => this.m_bUseRightSide;
    set => this.m_bUseRightSide = value;
  }

  public bool IsReverse
  {
    get => this.m_bIsReverse;
    set => this.m_bIsReverse = value;
  }

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }

  public bool AlignTo
  {
    get => this.m_bAlignTo;
    set => this.m_bAlignTo = value;
  }

  public string FirstLegSegmentID
  {
    get => this.m_strFirstLegSegmentID;
    set => this.m_strFirstLegSegmentID = value;
  }

  public string LastLegSegmentID
  {
    get => this.m_strLastLegSegmentID;
    set => this.m_strLastLegSegmentID = value;
  }

  public string FirstPlacementSegmentID
  {
    get => this.m_strFirstPlacementSegmentID;
    set => this.m_strFirstPlacementSegmentID = value;
  }
}
