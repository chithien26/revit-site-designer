﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlacePlantForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlacePlantForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private PlantCreation m_dataBuffer;
  private FamilySymbol m_CurType;
  private FormatOptions m_FormatOptions;
  private FormatOptions m_AngularOptions;
  private View m_CurView;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private UnitSymbolType m_AngularSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private double m_dAngularRounding;
  private IContainer components;
  private Label m_PlantFamilyLabel;
  private ComboBox m_PlantFamilyComboBox;
  private RadioButton m_HedgeRowRadioButton;
  private Label m_PlantNameLabel;
  private ComboBox m_PlantNameComboBox;
  private Label m_PlantWidthLabel;
  private TextBox m_PlantWidthTextBox;
  private Label m_VarianceWidthLabel;
  private TextBox m_VarianceWidthTextBox;
  private TextBox m_VarianceHeightTextBox;
  private Label m_VarianceHeightLabel;
  private TextBox m_PlantHeightTextBox;
  private Label m_PlantHeightLabel;
  private Label m_PlantSpacingLabel;
  private TextBox m_PlantSpacingTextBox;
  private RadioButton m_GroveRadioButton;
  private Button m_SearchButton;
  private Panel m_HedgeRowPanel;
  private RadioButton m_SideHedgeRadioButton;
  private RadioButton m_AlternateHedgeRadioButton;
  private RadioButton m_CenterHedgeRadioButton;
  private Panel m_GrovePanel;
  private RadioButton m_SquareRadioButton;
  private RadioButton m_TriangularRadioButton;
  private Label m_RotationLabel;
  private TextBox m_RotationTextBox;
  private Button m_LoadFamilyButton;
  private CheckBox m_ExistingElementCheckBox;
  private RadioButton m_SingleRadioButton;
  private Panel m_FirstMoveablePanel;
  private GroupBox m_PlaceTagGroupBox;
  private CheckBox m_LeaderedTagCheckBox;
  private CheckBox m_CreatePlantGroupTagCheckBox;
  private ComboBox m_LevelComboBox;
  private Label m_LevelLabel;
  private Panel m_SecondMoveablePanel;
  private CheckBox m_DeleteExistingCheckBox;
  private Button m_CancelButton;
  private Button m_InsertButton;
  private Label m_SetbackLabel;
  private TextBox m_SetbackTextBox;
  private RadioButton m_ChainRadioButton;
  private RadioButton m_SegmentRadioButton;
  private Label m_StartingDistanceLabel;
  private TextBox m_StartingDistanceTextBox;
  private ComboBox m_SurfaceList;
  private Label m_SelectedSurfaceLabel;
  private CheckBox m_ToposurfaceCheckBox;

  public PlacePlantForm(PlantCreation dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("LocatePlantsDialog");
    this.m_PlantFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_PlantFamilyDialog");
    this.m_PlantNameLabel.Text = EPShared.LocalRM.GetString("P_AMP_lantNameDialog");
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("Sea_AMP_rchDialog");
    this.m_PlantWidthLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_WidthDialog");
    this.m_VarianceWidthLabel.Text = EPShared.LocalRM.GetString("AMP_VarianceDialog");
    this.m_PlantHeightLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_HeightDialog");
    this.m_VarianceHeightLabel.Text = EPShared.LocalRM.GetString("Varianc_AMP_eDialog");
    this.m_PlantSpacingLabel.Text = EPShared.LocalRM.GetString("Plan_AMP_tSpacingDialog");
    this.m_SetbackLabel.Text = EPShared.LocalRM.GetString("Set_AMP_backDialog");
    this.m_HedgeRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_HedgeRowDialog");
    this.m_CenterHedgeRadioButton.Text = EPShared.LocalRM.GetString("C_AMP_enterDialog");
    this.m_AlternateHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_AlternateDialog");
    this.m_SideHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_SideDialog");
    this.m_GroveRadioButton.Text = EPShared.LocalRM.GetString("AMP_GroveDialog");
    this.m_TriangularRadioButton.Text = EPShared.LocalRM.GetString("Triang_AMP_ularDialog");
    this.m_SquareRadioButton.Text = EPShared.LocalRM.GetString("S_AMP_quareDialog");
    this.m_RotationLabel.Text = EPShared.LocalRM.GetString("R_AMP_otationDialog");
    this.m_SingleRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleDialog");
    this.m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
    this.m_PlaceTagGroupBox.Text = EPShared.LocalRM.GetString("PlaceTagDialog");
    this.m_CreatePlantGroupTagCheckBox.Text = EPShared.LocalRM.GetString("CreatePlant_AMP_GroupTagDialog");
    this.m_LeaderedTagCheckBox.Text = EPShared.LocalRM.GetString("CreatePlant_AMP_GroupTagDialog");
    this.m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_LeaderedTagCheckBox.Text = EPShared.LocalRM.GetString("Lea_AMP_deredTagDialog");
    this.m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
    this.m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
    this.m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
    this.m_ToposurfaceCheckBox.Checked = false;
    this.m_SurfaceList.Enabled = false;
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.m_dataBuffer = dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_AngularOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 3);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_AngularSymbolType = this.m_AngularOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_AngularSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_dAngularRounding = this.m_AngularOptions.Accuracy;
    }
    catch (InvalidOperationException ex)
    {
      this.m_dAngularRounding = 1.0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
    ManagePlants.VerifySharedParameters(this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer);
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty1 = string.Empty;
    this.GetDialogPosition();
    this.m_HedgeRowRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantPlacementOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_HedgeRowRadioButton.Checked = true;
          break;
        case 1:
          this.m_GroveRadioButton.Checked = true;
          break;
        default:
          this.m_SingleRadioButton.Checked = true;
          break;
      }
    }
    this.m_CenterHedgeRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantHedgeRowOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_CenterHedgeRadioButton.Checked = true;
          break;
        case 1:
          this.m_AlternateHedgeRadioButton.Checked = true;
          break;
        default:
          this.m_SideHedgeRadioButton.Checked = true;
          break;
      }
    }
    this.m_TriangularRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantGroveRowOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_TriangularRadioButton.Checked = true;
      else
        this.m_SquareRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantGroveRotation", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dReturnValue, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref empty1);
    this.m_RotationTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantPlantSpacing", ref _dReturnValue))
      _dReturnValue = 5.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_PlantSpacingTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantSetback", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_SetbackTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantHeightVariance", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_VarianceHeightTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantWidthVariance", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_VarianceWidthTextBox.Text = empty1;
    this.m_CreatePlantGroupTagCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantCreatePlantGroupTag", ref _nReturnValue))
      this.m_CreatePlantGroupTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_LeaderedTagCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantCreateLeaderedTag", ref _nReturnValue))
      this.m_LeaderedTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ExistingElementCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantExistingElement", ref _nReturnValue))
      this.m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_DeleteExistingCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantDeleteExisting", ref _nReturnValue))
      this.m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantStartingDistance", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_StartingDistanceTextBox.Text = empty1;
    this.m_PlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.PlantFamilyList;
    this.m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_PlantFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_PlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty1, true) == 0)
        {
          this.m_PlantFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantPlantName", ref empty1))
    {
      for (int index = 0; index < this.m_PlantNameComboBox.Items.Count; ++index)
      {
        if (this.m_PlantNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty1, true) == 0)
        {
          this.m_PlantNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.GetPlantParameters();
    this.m_LevelComboBox.DataSource = (object) this.m_dataBuffer.Views;
    this.m_LevelComboBox.DisplayMember = EPShared.LocalRM.GetString("ViewNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantViewName", ref empty1))
    {
      for (int index = 0; index < this.m_LevelComboBox.Items.Count; ++index)
      {
        if (this.m_LevelComboBox.Items[index] is View view && string.Compare(((Element) view).Name, empty1, true) == 0)
        {
          this.m_LevelComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_SegmentRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantSegmentChainOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_SegmentRadioButton.Checked = true;
      else
        this.m_ChainRadioButton.Checked = true;
    }
    this.m_ToposurfaceCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantPickToposurface", ref _nReturnValue))
      this.m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    Parameter parameter1 = (Parameter) null;
    string name = string.Empty;
    if (this.m_dataBuffer.SurfaceList.Count > 0)
    {
      int num = 1;
      foreach (TopographySurfaceContainer surface in this.m_dataBuffer.SurfaceList)
      {
        Parameter parameter2 = ((Element) surface.TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter2 != null)
          name = parameter2.AsString();
        if (name == null || name == string.Empty)
        {
          name = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
          ++num;
        }
        this.m_SurfaceList.Items.Add((object) new ToposurfaceItem(name, surface));
      }
    }
    else
    {
      this.m_ToposurfaceCheckBox.Checked = false;
      this.m_ToposurfaceCheckBox.Enabled = false;
      this.m_SurfaceList.Enabled = false;
    }
    parameter1 = (Parameter) null;
    string empty2 = string.Empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantSurfaceName", ref empty1))
    {
      for (int index = 0; index < this.m_SurfaceList.Items.Count; ++index)
      {
        if (this.m_SurfaceList.Items[index] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, empty1, true) == 0)
        {
          this.m_SurfaceList.SelectedIndex = index;
          break;
        }
      }
    }
    if (this.m_SurfaceList.Items.Count <= 0 || this.m_SurfaceList.SelectedIndex != -1)
      return;
    this.m_SurfaceList.SelectedIndex = 0;
  }

  private void SaveSettings()
  {
    this.m_CurView = this.m_LevelComboBox.SelectedItem as View;
    if (this.m_CurView == null)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.m_CurType = this.m_PlantNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_CurType == null)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantPlacementOption", !this.m_HedgeRowRadioButton.Checked ? (!this.m_GroveRadioButton.Checked ? 2 : 1) : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantHedgeRowOption", !this.m_CenterHedgeRadioButton.Checked ? (!this.m_AlternateHedgeRadioButton.Checked ? 2 : 1) : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantGroveRowOption", !this.m_TriangularRadioButton.Checked ? 1 : 0);
        double _dReturnedDouble = 0.0;
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantPlantSpacing", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantSetback", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_VarianceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantHeightVariance", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_VarianceWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantWidthVariance", _dReturnedDouble);
        double radians = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_RotationTextBox.Text);
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantGroveRotation", radians);
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantCreatePlantGroupTag", Convert.ToInt32(this.m_CreatePlantGroupTagCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantCreateLeaderedTag", Convert.ToInt32(this.m_LeaderedTagCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantExistingElement", Convert.ToInt32(this.m_ExistingElementCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantDeleteExisting", Convert.ToInt32(this.m_DeleteExistingCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref radians, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantStartingDistance", radians);
        if (this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantFamilyName", selectedItem.FamilyName);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantPlantName", ((Element) this.m_CurType).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantViewName", ((Element) this.m_CurView).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantSegmentChainOption", !this.m_SegmentRadioButton.Checked ? 1 : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantPickToposurface", Convert.ToInt32(this.m_ToposurfaceCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "PlacePlantSurfaceName", Convert.ToString(this.m_SurfaceList.SelectedItem));
      }
    }
  }

  private bool ValidateFields()
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_PlantSpacingTextBox.Text;
    if (string.IsNullOrEmpty(text1))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyPlantSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_PlantSpacingTextBox.Focus();
      return false;
    }
    if (!RevitGeometry.Units_ConvertStringToDouble(text1, this.m_Units, (UnitType) 0, ref _dReturnedDouble1) || _dReturnedDouble1 <= 1E-05)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_PlantSpacingTextBox.Focus();
      return false;
    }
    if (this.m_HedgeRowRadioButton.Checked && !this.m_CenterHedgeRadioButton.Checked && (!RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble1) || _dReturnedDouble1 <= 1E-05))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_SetbackTextBox.Focus();
      return false;
    }
    if (this.m_PlantWidthTextBox.Enabled)
    {
      string text2 = this.m_PlantWidthTextBox.Text;
      if (string.IsNullOrEmpty(text2))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyPlantWidthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_PlantWidthTextBox.Focus();
        return false;
      }
      if (!RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble1) || _dReturnedDouble1 <= 1E-05)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantWidthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_PlantWidthTextBox.Focus();
        return false;
      }
      string text3 = this.m_VarianceWidthTextBox.Text;
      if (!string.IsNullOrEmpty(text3))
      {
        double _dReturnedDouble2 = 0.0;
        if (!RevitGeometry.Units_ConvertStringToDouble(text3, this.m_Units, (UnitType) 0, ref _dReturnedDouble2) || _dReturnedDouble2 < 0.0)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantWidthVarianceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_VarianceWidthTextBox.Focus();
          return false;
        }
        if (RevitDefines.GE(_dReturnedDouble2, _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("VarianceMoreThanPlantWidthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_VarianceWidthTextBox.Focus();
          return false;
        }
      }
    }
    if (this.m_PlantHeightTextBox.Enabled)
    {
      string text4 = this.m_PlantHeightTextBox.Text;
      if (string.IsNullOrEmpty(text4))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyPlantHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_PlantHeightTextBox.Focus();
        return false;
      }
      if (!RevitGeometry.Units_ConvertStringToDouble(text4, this.m_Units, (UnitType) 0, ref _dReturnedDouble1) || _dReturnedDouble1 <= 1E-05)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_PlantHeightTextBox.Focus();
        return false;
      }
      string text5 = this.m_VarianceHeightTextBox.Text;
      if (!string.IsNullOrEmpty(text5))
      {
        double _dReturnedDouble3 = 0.0;
        if (!RevitGeometry.Units_ConvertStringToDouble(text5, this.m_Units, (UnitType) 0, ref _dReturnedDouble3) || _dReturnedDouble3 < 0.0)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantHeightVarianceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_VarianceHeightTextBox.Focus();
          return false;
        }
        if (RevitDefines.GE(_dReturnedDouble3, _dReturnedDouble1))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("VarianceMoreThanPlantHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_VarianceHeightTextBox.Focus();
          return false;
        }
      }
    }
    return true;
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnSearchButtonClick(object sender, EventArgs e)
  {
    if (!(this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    List<FamilySymbol> _SearchSymbolList = new List<FamilySymbol>();
    if (!ManagePlants.FindFamilySymbols(EPShared.LocalRM.GetString("LocatePlantSearchTitle"), this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer, selectedItem.FamilySymbolList, ref _SearchSymbolList))
      return;
    this.m_PlantNameComboBox.DataSource = (object) _SearchSymbolList;
    this.m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnSingleHedgeRowGroveOptionChecked(object sender, EventArgs e)
  {
    this.m_CenterHedgeRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_AlternateHedgeRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_SideHedgeRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_TriangularRadioButton.Enabled = this.m_GroveRadioButton.Checked;
    this.m_SquareRadioButton.Enabled = this.m_GroveRadioButton.Checked;
    this.m_RotationLabel.Enabled = this.m_GroveRadioButton.Checked;
    this.m_RotationTextBox.Enabled = this.m_GroveRadioButton.Checked;
    this.m_PlantSpacingLabel.Enabled = !this.m_SingleRadioButton.Checked;
    this.m_PlantSpacingTextBox.Enabled = !this.m_SingleRadioButton.Checked;
    this.m_SegmentRadioButton.Enabled = !this.m_GroveRadioButton.Checked;
    this.m_ChainRadioButton.Enabled = !this.m_GroveRadioButton.Checked;
    this.m_StartingDistanceLabel.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
    this.m_StartingDistanceTextBox.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
    this.OnHedgeRowOptionChecked(sender, e);
  }

  private void OnHedgeRowOptionChecked(object sender, EventArgs e)
  {
    if (this.m_HedgeRowRadioButton.Checked)
    {
      this.m_SetbackLabel.Enabled = !this.m_CenterHedgeRadioButton.Checked;
      this.m_SetbackTextBox.Enabled = !this.m_CenterHedgeRadioButton.Checked;
    }
    else
    {
      this.m_SetbackLabel.Enabled = !this.m_SingleRadioButton.Checked;
      this.m_SetbackTextBox.Enabled = !this.m_SingleRadioButton.Checked;
    }
  }

  private void FormatPlantSpacingValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_PlantSpacingTextBox.Text = empty;
    }
    else
      this.m_PlantSpacingTextBox.Focus();
  }

  private void OnPlantSpacingTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatPlantSpacingValue();
  }

  private void FormatPlantWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_PlantWidthTextBox.Text = empty;
    }
    else
      this.m_PlantWidthTextBox.Focus();
  }

  private void OnPlantWidthTextBoxLeave(object sender, EventArgs e) => this.FormatPlantWidthValue();

  private void FormatVarianceWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_VarianceWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_VarianceWidthTextBox.Text = empty;
    }
    else
      this.m_VarianceWidthTextBox.Focus();
  }

  private void OnVarianceWidthTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatVarianceWidthValue();
  }

  private void FormatPlantHeightValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_PlantHeightTextBox.Text = empty;
    }
    else
      this.m_PlantHeightTextBox.Focus();
  }

  private void OnPlantHeightTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatPlantHeightValue();
  }

  private void FormatVarianceHeightValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_VarianceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_VarianceHeightTextBox.Text = empty;
    }
    else
      this.m_VarianceHeightTextBox.Focus();
  }

  private void OnVarianceHeightTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatVarianceHeightValue();
  }

  private void FormatSetbackValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_SetbackTextBox.Text = empty;
    }
    else
      this.m_SetbackTextBox.Focus();
  }

  private void OnSetbackTextBoxLeave(object sender, EventArgs e) => this.FormatSetbackValue();

  private void FormatRotationValue()
  {
    string empty = string.Empty;
    if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_RotationTextBox.Text), this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref empty) == 0)
      this.m_RotationTextBox.Text = empty;
    else
      this.m_RotationTextBox.Focus();
  }

  private void OnRotationTextBoxLeave(object sender, EventArgs e) => this.FormatRotationValue();

  private void OnPlantWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatPlantWidthValue();
  }

  private void OnPlantHeightTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatPlantHeightValue();
  }

  private void OnPlantSpacingTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatPlantSpacingValue();
  }

  private void OnVarianceWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatVarianceWidthValue();
  }

  private void OnVarianceHeightTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatVarianceHeightValue();
  }

  private void OnRotationTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatRotationValue();
  }

  private void OnSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatSetbackValue();
  }

  private void OnCreatePlantGroupCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_LeaderedTagCheckBox.Enabled = this.m_CreatePlantGroupTagCheckBox.Checked;
  }

  private void GetPlantParameters()
  {
    Eps_Point _SecondCheckPnt = new Eps_Point();
    if (!(this.m_PlantNameComboBox.SelectedItem is FamilySymbol selectedItem))
      return;
    this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
    List<Eps_Point> _PointList = (List<Eps_Point>) null;
    foreach (Element currentElement in this.m_dataBuffer.CurrentElementList)
    {
      if (currentElement is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) selectedItem).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
      {
        if (_PointList == null)
          _PointList = new List<Eps_Point>();
        Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
          _PointList.Add(_FindPoint);
      }
    }
    if (_PointList != null && _PointList.Count > 0)
    {
      bool flag = true;
      while (flag)
      {
        flag = false;
        for (int index = 0; index < _PointList.Count; ++index)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index], _SecondCheckPnt))
          {
            ++_SecondCheckPnt.z;
            flag = true;
            break;
          }
        }
      }
    }
    EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
    FamilyInstance familyInstance1 = RevitUtility.NewFamilyInstance(this.m_dataBuffer.Document, _SecondCheckPnt.XYZ, selectedItem, (Element) null, (Level) null, (StructuralType) 0, ref transactionContainer);
    this.m_dataBuffer.TransactionContainer = transactionContainer;
    ElementSet elm_set = new ElementSet();
    elm_set.Insert((Element) familyInstance1);
    this.m_dataBuffer.Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
    if (familyInstance1 != null && familyInstance1.Symbol != null)
    {
      string empty = string.Empty;
      Parameter parameter1 = ((Element) familyInstance1).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
      if (parameter1 != null)
      {
        this.m_PlantHeightLabel.Enabled = true;
        this.m_PlantHeightTextBox.Enabled = true;
        this.m_VarianceHeightLabel.Enabled = true;
        this.m_VarianceHeightTextBox.Enabled = true;
        RevitGeometry.Units_ConvertDoubleToString(parameter1.AsDouble(), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
        this.m_PlantHeightTextBox.Text = empty;
      }
      else
      {
        this.m_PlantHeightTextBox.Text = string.Empty;
        this.m_PlantHeightLabel.Enabled = false;
        this.m_PlantHeightTextBox.Enabled = false;
        this.m_VarianceHeightLabel.Enabled = false;
        this.m_VarianceHeightTextBox.Enabled = false;
      }
      Parameter parameter2 = ((Element) familyInstance1).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
      if (parameter2 != null)
      {
        this.m_PlantWidthLabel.Enabled = true;
        this.m_PlantWidthTextBox.Enabled = true;
        this.m_VarianceWidthLabel.Enabled = true;
        this.m_VarianceWidthTextBox.Enabled = true;
        RevitGeometry.Units_ConvertDoubleToString(parameter2.AsDouble(), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
        this.m_PlantWidthTextBox.Text = empty;
      }
      else
      {
        this.m_PlantWidthTextBox.Text = string.Empty;
        this.m_PlantWidthLabel.Enabled = false;
        this.m_PlantWidthTextBox.Enabled = false;
        this.m_VarianceWidthLabel.Enabled = false;
        this.m_VarianceWidthTextBox.Enabled = false;
      }
      Parameter parameter3 = ((Element) familyInstance1.Symbol).LookupParameter(RevitParameters.PlantSpacingPlantFamilyParameter);
      if (parameter3 != null)
      {
        double num = parameter3.AsDouble();
        if (RevitDefines.GT(num, 0.0))
        {
          RevitGeometry.Units_ConvertDoubleToString(num, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          this.m_PlantSpacingTextBox.Text = empty;
        }
      }
      this.m_dataBuffer.TransactionContainer.BeginTransaction();
      this.m_dataBuffer.Document.Delete(((Element) familyInstance1).Id);
      this.m_dataBuffer.TransactionContainer.EndTransaction();
    }
    this.m_dataBuffer.TransactionContainer.Rollback();
  }

  private void OnPlantNameComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    this.GetPlantParameters();
  }

  private void OnPlacePlantFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_PlantNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_PlantFamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectPlantingFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            this.m_dataBuffer.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_PlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.PlantFamilyList;
        this.m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_PlantFamilyComboBox.Items.Count; ++index)
          {
            if (this.m_PlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_PlantFamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_PlantFamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_DeleteExistingCheckBox.Enabled = this.m_ExistingElementCheckBox.Checked;
    this.m_StartingDistanceLabel.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
    this.m_StartingDistanceTextBox.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
  }

  private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatStartingDistanceValue();
  }

  private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatStartingDistanceValue();
  }

  private void FormatStartingDistanceValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_StartingDistanceTextBox.Text = empty;
    }
    else
      this.m_StartingDistanceTextBox.Focus();
  }

  private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
  {
    this.m_SurfaceList.Enabled = this.m_ToposurfaceCheckBox.Checked;
    this.m_SelectedSurfaceLabel.Enabled = this.m_ToposurfaceCheckBox.Checked;
  }

  public bool ExistingElementChecked => this.m_ExistingElementCheckBox.Checked;

  public PlacementType PlacementType
  {
    get
    {
      if (this.m_HedgeRowRadioButton.Checked)
      {
        if (this.m_CenterHedgeRadioButton.Checked)
          return PlacementType.HedgeRowCenter;
        return this.m_AlternateHedgeRadioButton.Checked ? PlacementType.HedgeRowAlternate : PlacementType.HedgeRowSide;
      }
      if (!this.m_GroveRadioButton.Checked)
        return PlacementType.Single;
      return this.m_TriangularRadioButton.Checked ? PlacementType.GroveTrianglular : PlacementType.GroveSquare;
    }
  }

  public bool SingleChecked => this.m_SingleRadioButton.Checked;

  public bool HedgeRowChecked => this.m_HedgeRowRadioButton.Checked;

  public bool GroveChecked => this.m_GroveRadioButton.Checked;

  public bool TriangularGroveChecked => this.m_TriangularRadioButton.Checked;

  public bool SquareGroveChecked => this.m_SquareRadioButton.Checked;

  public bool CenteredHedgeRowChecked => this.m_CenterHedgeRadioButton.Checked;

  public bool AlternateHedgeRowChecked => this.m_AlternateHedgeRadioButton.Checked;

  public bool SideHedgeRadioButton => this.m_SideHedgeRadioButton.Checked;

  public bool DeleteExistingChecked
  {
    get => this.m_ExistingElementCheckBox.Checked && this.m_DeleteExistingCheckBox.Checked;
  }

  public double StartingDistance
  {
    get
    {
      if (!this.m_HedgeRowRadioButton.Checked || !this.m_ExistingElementCheckBox.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_StartingDistanceTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool PlaceGroupTagChecked => this.m_CreatePlantGroupTagCheckBox.Checked;

  public bool LeaderedTagChecked => this.m_LeaderedTagCheckBox.Checked;

  public Level Level => this.m_CurView.GenLevel;

  public View View => this.m_CurView;

  public FamilySymbol Type => this.m_CurType;

  public double RotationAngle
  {
    get
    {
      double rotationAngle = 0.0;
      if (this.m_RotationTextBox.Text != string.Empty)
        rotationAngle = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_RotationTextBox.Text);
      return rotationAngle;
    }
  }

  public double PlantSpacing
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_PlantSpacingTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double SetbackSpacing
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_SetbackTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double PlantHeight
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_PlantHeightTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_PlantHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double HeightVariance
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_VarianceHeightTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_VarianceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double PlantWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_PlantWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_PlantWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double WidthVariance
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_VarianceWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_VarianceWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool SegmentChecked
  {
    get => !this.m_GroveRadioButton.Checked && this.m_SegmentRadioButton.Checked;
  }

  public bool ChainChecked => this.m_GroveRadioButton.Checked || this.m_ChainRadioButton.Checked;

  public TopographySurfaceContainer Surface
  {
    get
    {
      TopographySurfaceContainer surface = (TopographySurfaceContainer) null;
      if (this.m_SurfaceList.SelectedItem is ToposurfaceItem selectedItem)
        surface = selectedItem.Value;
      return surface;
    }
  }

  public bool PickToposurface => this.m_ToposurfaceCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_PlantFamilyLabel = new Label();
    this.m_PlantFamilyComboBox = new ComboBox();
    this.m_HedgeRowRadioButton = new RadioButton();
    this.m_PlantNameLabel = new Label();
    this.m_PlantNameComboBox = new ComboBox();
    this.m_PlantWidthLabel = new Label();
    this.m_PlantWidthTextBox = new TextBox();
    this.m_VarianceWidthLabel = new Label();
    this.m_VarianceWidthTextBox = new TextBox();
    this.m_VarianceHeightTextBox = new TextBox();
    this.m_VarianceHeightLabel = new Label();
    this.m_PlantHeightTextBox = new TextBox();
    this.m_PlantHeightLabel = new Label();
    this.m_PlantSpacingLabel = new Label();
    this.m_PlantSpacingTextBox = new TextBox();
    this.m_GroveRadioButton = new RadioButton();
    this.m_SearchButton = new Button();
    this.m_HedgeRowPanel = new Panel();
    this.m_SideHedgeRadioButton = new RadioButton();
    this.m_AlternateHedgeRadioButton = new RadioButton();
    this.m_CenterHedgeRadioButton = new RadioButton();
    this.m_GrovePanel = new Panel();
    this.m_SquareRadioButton = new RadioButton();
    this.m_TriangularRadioButton = new RadioButton();
    this.m_RotationLabel = new Label();
    this.m_RotationTextBox = new TextBox();
    this.m_LoadFamilyButton = new Button();
    this.m_ExistingElementCheckBox = new CheckBox();
    this.m_SingleRadioButton = new RadioButton();
    this.m_FirstMoveablePanel = new Panel();
    this.m_SurfaceList = new ComboBox();
    this.m_SelectedSurfaceLabel = new Label();
    this.m_ToposurfaceCheckBox = new CheckBox();
    this.m_ChainRadioButton = new RadioButton();
    this.m_SegmentRadioButton = new RadioButton();
    this.m_PlaceTagGroupBox = new GroupBox();
    this.m_LeaderedTagCheckBox = new CheckBox();
    this.m_CreatePlantGroupTagCheckBox = new CheckBox();
    this.m_LevelComboBox = new ComboBox();
    this.m_LevelLabel = new Label();
    this.m_SecondMoveablePanel = new Panel();
    this.m_StartingDistanceLabel = new Label();
    this.m_StartingDistanceTextBox = new TextBox();
    this.m_DeleteExistingCheckBox = new CheckBox();
    this.m_CancelButton = new Button();
    this.m_InsertButton = new Button();
    this.m_SetbackLabel = new Label();
    this.m_SetbackTextBox = new TextBox();
    this.m_HedgeRowPanel.SuspendLayout();
    this.m_GrovePanel.SuspendLayout();
    this.m_FirstMoveablePanel.SuspendLayout();
    this.m_PlaceTagGroupBox.SuspendLayout();
    this.m_SecondMoveablePanel.SuspendLayout();
    this.SuspendLayout();
    this.m_PlantFamilyLabel.AutoSize = true;
    this.m_PlantFamilyLabel.Location = new Point(12, 15);
    this.m_PlantFamilyLabel.Name = "m_PlantFamilyLabel";
    this.m_PlantFamilyLabel.Size = new Size(66, 13);
    this.m_PlantFamilyLabel.TabIndex = 0;
    this.m_PlantFamilyLabel.Text = "&Plant Family:";
    this.m_PlantFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantFamilyComboBox.FormattingEnabled = true;
    this.m_PlantFamilyComboBox.Location = new Point(116, 12);
    this.m_PlantFamilyComboBox.Name = "m_PlantFamilyComboBox";
    this.m_PlantFamilyComboBox.Size = new Size(214, 21);
    this.m_PlantFamilyComboBox.TabIndex = 1;
    this.m_PlantFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnPlantFamilyComboBoxSelectedIndexChanged);
    this.m_HedgeRowRadioButton.AutoSize = true;
    this.m_HedgeRowRadioButton.Location = new Point(12, 146);
    this.m_HedgeRowRadioButton.Name = "m_HedgeRowRadioButton";
    this.m_HedgeRowRadioButton.Size = new Size(82, 17);
    this.m_HedgeRowRadioButton.TabIndex = 18;
    this.m_HedgeRowRadioButton.TabStop = true;
    this.m_HedgeRowRadioButton.Text = "&Hedge Row";
    this.m_HedgeRowRadioButton.UseVisualStyleBackColor = true;
    this.m_HedgeRowRadioButton.CheckedChanged += new EventHandler(this.OnSingleHedgeRowGroveOptionChecked);
    this.m_PlantNameLabel.AutoSize = true;
    this.m_PlantNameLabel.Location = new Point(12, 43);
    this.m_PlantNameLabel.Name = "m_PlantNameLabel";
    this.m_PlantNameLabel.Size = new Size(65, 13);
    this.m_PlantNameLabel.TabIndex = 3;
    this.m_PlantNameLabel.Text = "P&lant Name:";
    this.m_PlantNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantNameComboBox.FormattingEnabled = true;
    this.m_PlantNameComboBox.Location = new Point(116, 39);
    this.m_PlantNameComboBox.Name = "m_PlantNameComboBox";
    this.m_PlantNameComboBox.Size = new Size(214, 21);
    this.m_PlantNameComboBox.TabIndex = 4;
    this.m_PlantNameComboBox.SelectedIndexChanged += new EventHandler(this.OnPlantNameComboBoxSelectedIndexChanged);
    this.m_PlantWidthLabel.AutoSize = true;
    this.m_PlantWidthLabel.Location = new Point(12, 71);
    this.m_PlantWidthLabel.Name = "m_PlantWidthLabel";
    this.m_PlantWidthLabel.Size = new Size(65, 13);
    this.m_PlantWidthLabel.TabIndex = 6;
    this.m_PlantWidthLabel.Text = "Plant &Width:";
    this.m_PlantWidthTextBox.Location = new Point(116, 68);
    this.m_PlantWidthTextBox.Name = "m_PlantWidthTextBox";
    this.m_PlantWidthTextBox.Size = new Size(100, 20);
    this.m_PlantWidthTextBox.TabIndex = 7;
    this.m_PlantWidthTextBox.KeyDown += new KeyEventHandler(this.OnPlantWidthTextBoxKeyDown);
    this.m_PlantWidthTextBox.Leave += new EventHandler(this.OnPlantWidthTextBoxLeave);
    this.m_VarianceWidthLabel.AutoSize = true;
    this.m_VarianceWidthLabel.Location = new Point(234, 71);
    this.m_VarianceWidthLabel.Name = "m_VarianceWidthLabel";
    this.m_VarianceWidthLabel.Size = new Size(52, 13);
    this.m_VarianceWidthLabel.TabIndex = 8;
    this.m_VarianceWidthLabel.Text = "&Variance:";
    this.m_VarianceWidthTextBox.Location = new Point(311, 68);
    this.m_VarianceWidthTextBox.Name = "m_VarianceWidthTextBox";
    this.m_VarianceWidthTextBox.Size = new Size(100, 20);
    this.m_VarianceWidthTextBox.TabIndex = 9;
    this.m_VarianceWidthTextBox.KeyDown += new KeyEventHandler(this.OnVarianceWidthTextBoxKeyDown);
    this.m_VarianceWidthTextBox.Leave += new EventHandler(this.OnVarianceWidthTextBoxLeave);
    this.m_VarianceHeightTextBox.Location = new Point(311, 94);
    this.m_VarianceHeightTextBox.Name = "m_VarianceHeightTextBox";
    this.m_VarianceHeightTextBox.Size = new Size(100, 20);
    this.m_VarianceHeightTextBox.TabIndex = 13;
    this.m_VarianceHeightTextBox.KeyDown += new KeyEventHandler(this.OnVarianceHeightTextBoxKeyDown);
    this.m_VarianceHeightTextBox.Leave += new EventHandler(this.OnVarianceHeightTextBoxLeave);
    this.m_VarianceHeightLabel.AutoSize = true;
    this.m_VarianceHeightLabel.Location = new Point(234, 97);
    this.m_VarianceHeightLabel.Name = "m_VarianceHeightLabel";
    this.m_VarianceHeightLabel.Size = new Size(52, 13);
    this.m_VarianceHeightLabel.TabIndex = 12;
    this.m_VarianceHeightLabel.Text = "Varianc&e:";
    this.m_PlantHeightTextBox.Location = new Point(116, 94);
    this.m_PlantHeightTextBox.Name = "m_PlantHeightTextBox";
    this.m_PlantHeightTextBox.Size = new Size(100, 20);
    this.m_PlantHeightTextBox.TabIndex = 11;
    this.m_PlantHeightTextBox.KeyDown += new KeyEventHandler(this.OnPlantHeightTextBoxKeyDown);
    this.m_PlantHeightTextBox.Leave += new EventHandler(this.OnPlantHeightTextBoxLeave);
    this.m_PlantHeightLabel.AutoSize = true;
    this.m_PlantHeightLabel.Location = new Point(12, 97);
    this.m_PlantHeightLabel.Name = "m_PlantHeightLabel";
    this.m_PlantHeightLabel.Size = new Size(68, 13);
    this.m_PlantHeightLabel.TabIndex = 10;
    this.m_PlantHeightLabel.Text = "Pla&nt Height:";
    this.m_PlantSpacingLabel.AutoSize = true;
    this.m_PlantSpacingLabel.Location = new Point(12, 123);
    this.m_PlantSpacingLabel.Name = "m_PlantSpacingLabel";
    this.m_PlantSpacingLabel.Size = new Size(76, 13);
    this.m_PlantSpacingLabel.TabIndex = 14;
    this.m_PlantSpacingLabel.Text = "Plan&t Spacing:";
    this.m_PlantSpacingTextBox.Location = new Point(116, 120);
    this.m_PlantSpacingTextBox.Name = "m_PlantSpacingTextBox";
    this.m_PlantSpacingTextBox.Size = new Size(100, 20);
    this.m_PlantSpacingTextBox.TabIndex = 15;
    this.m_PlantSpacingTextBox.KeyDown += new KeyEventHandler(this.OnPlantSpacingTextBoxKeyDown);
    this.m_PlantSpacingTextBox.Leave += new EventHandler(this.OnPlantSpacingTextBoxLeave);
    this.m_GroveRadioButton.AutoSize = true;
    this.m_GroveRadioButton.Location = new Point(12, 197);
    this.m_GroveRadioButton.Name = "m_GroveRadioButton";
    this.m_GroveRadioButton.Size = new Size(54, 17);
    this.m_GroveRadioButton.TabIndex = 20;
    this.m_GroveRadioButton.TabStop = true;
    this.m_GroveRadioButton.Text = "&Grove";
    this.m_GroveRadioButton.UseVisualStyleBackColor = true;
    this.m_GroveRadioButton.CheckedChanged += new EventHandler(this.OnSingleHedgeRowGroveOptionChecked);
    this.m_SearchButton.Location = new Point(336, 38);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(75, 23);
    this.m_SearchButton.TabIndex = 5;
    this.m_SearchButton.Text = "Sea&rch";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButtonClick);
    this.m_HedgeRowPanel.Controls.Add((Control) this.m_SideHedgeRadioButton);
    this.m_HedgeRowPanel.Controls.Add((Control) this.m_AlternateHedgeRadioButton);
    this.m_HedgeRowPanel.Controls.Add((Control) this.m_CenterHedgeRadioButton);
    this.m_HedgeRowPanel.Location = new Point(29, 169);
    this.m_HedgeRowPanel.Name = "m_HedgeRowPanel";
    this.m_HedgeRowPanel.Size = new Size(382, 24);
    this.m_HedgeRowPanel.TabIndex = 19;
    this.m_SideHedgeRadioButton.AutoSize = true;
    this.m_SideHedgeRadioButton.Location = new Point(270, 4);
    this.m_SideHedgeRadioButton.Name = "m_SideHedgeRadioButton";
    this.m_SideHedgeRadioButton.Size = new Size(46, 17);
    this.m_SideHedgeRadioButton.TabIndex = 2;
    this.m_SideHedgeRadioButton.TabStop = true;
    this.m_SideHedgeRadioButton.Text = "&Side";
    this.m_SideHedgeRadioButton.UseVisualStyleBackColor = true;
    this.m_SideHedgeRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowOptionChecked);
    this.m_AlternateHedgeRadioButton.AutoSize = true;
    this.m_AlternateHedgeRadioButton.Location = new Point(139, 4);
    this.m_AlternateHedgeRadioButton.Name = "m_AlternateHedgeRadioButton";
    this.m_AlternateHedgeRadioButton.Size = new Size(67, 17);
    this.m_AlternateHedgeRadioButton.TabIndex = 1;
    this.m_AlternateHedgeRadioButton.TabStop = true;
    this.m_AlternateHedgeRadioButton.Text = "&Alternate";
    this.m_AlternateHedgeRadioButton.UseVisualStyleBackColor = true;
    this.m_AlternateHedgeRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowOptionChecked);
    this.m_CenterHedgeRadioButton.AutoSize = true;
    this.m_CenterHedgeRadioButton.Location = new Point(3, 4);
    this.m_CenterHedgeRadioButton.Name = "m_CenterHedgeRadioButton";
    this.m_CenterHedgeRadioButton.Size = new Size(56, 17);
    this.m_CenterHedgeRadioButton.TabIndex = 0;
    this.m_CenterHedgeRadioButton.TabStop = true;
    this.m_CenterHedgeRadioButton.Text = "C&enter";
    this.m_CenterHedgeRadioButton.UseVisualStyleBackColor = true;
    this.m_CenterHedgeRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowOptionChecked);
    this.m_GrovePanel.Controls.Add((Control) this.m_SquareRadioButton);
    this.m_GrovePanel.Controls.Add((Control) this.m_TriangularRadioButton);
    this.m_GrovePanel.Location = new Point(29, 220);
    this.m_GrovePanel.Name = "m_GrovePanel";
    this.m_GrovePanel.Size = new Size(382, 24);
    this.m_GrovePanel.TabIndex = 21;
    this.m_SquareRadioButton.AutoSize = true;
    this.m_SquareRadioButton.Location = new Point(139, 3);
    this.m_SquareRadioButton.Name = "m_SquareRadioButton";
    this.m_SquareRadioButton.Size = new Size(59, 17);
    this.m_SquareRadioButton.TabIndex = 1;
    this.m_SquareRadioButton.TabStop = true;
    this.m_SquareRadioButton.Text = "S&quare";
    this.m_SquareRadioButton.UseVisualStyleBackColor = true;
    this.m_TriangularRadioButton.AutoSize = true;
    this.m_TriangularRadioButton.Location = new Point(3, 3);
    this.m_TriangularRadioButton.Name = "m_TriangularRadioButton";
    this.m_TriangularRadioButton.Size = new Size(72, 17);
    this.m_TriangularRadioButton.TabIndex = 0;
    this.m_TriangularRadioButton.TabStop = true;
    this.m_TriangularRadioButton.Text = "Triang&ular";
    this.m_TriangularRadioButton.UseVisualStyleBackColor = true;
    this.m_RotationLabel.AutoSize = true;
    this.m_RotationLabel.Enabled = false;
    this.m_RotationLabel.Location = new Point(31 /*0x1F*/, 253);
    this.m_RotationLabel.Name = "m_RotationLabel";
    this.m_RotationLabel.Size = new Size(50, 13);
    this.m_RotationLabel.TabIndex = 22;
    this.m_RotationLabel.Text = "R&otation:";
    this.m_RotationTextBox.Enabled = false;
    this.m_RotationTextBox.Location = new Point(116, 250);
    this.m_RotationTextBox.Name = "m_RotationTextBox";
    this.m_RotationTextBox.Size = new Size(100, 20);
    this.m_RotationTextBox.TabIndex = 23;
    this.m_RotationTextBox.KeyDown += new KeyEventHandler(this.OnRotationTextBoxKeyDown);
    this.m_RotationTextBox.Leave += new EventHandler(this.OnRotationTextBoxLeave);
    this.m_LoadFamilyButton.Location = new Point(336, 12);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_ExistingElementCheckBox.AutoSize = true;
    this.m_ExistingElementCheckBox.Location = new Point(12, 473);
    this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
    this.m_ExistingElementCheckBox.Size = new Size(103, 17);
    this.m_ExistingElementCheckBox.TabIndex = 26;
    this.m_ExistingElementCheckBox.Text = "Existing Ele&ment";
    this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
    this.m_ExistingElementCheckBox.CheckedChanged += new EventHandler(this.OnExistingElementCheckBoxChecked);
    this.m_SingleRadioButton.AutoSize = true;
    this.m_SingleRadioButton.Location = new Point(12, 276);
    this.m_SingleRadioButton.Name = "m_SingleRadioButton";
    this.m_SingleRadioButton.Size = new Size(54, 17);
    this.m_SingleRadioButton.TabIndex = 24;
    this.m_SingleRadioButton.TabStop = true;
    this.m_SingleRadioButton.Text = "Single";
    this.m_SingleRadioButton.UseVisualStyleBackColor = true;
    this.m_SingleRadioButton.CheckedChanged += new EventHandler(this.OnSingleHedgeRowGroveOptionChecked);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_SurfaceList);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_SelectedSurfaceLabel);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_ToposurfaceCheckBox);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_ChainRadioButton);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_SegmentRadioButton);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_PlaceTagGroupBox);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_LevelComboBox);
    this.m_FirstMoveablePanel.Controls.Add((Control) this.m_LevelLabel);
    this.m_FirstMoveablePanel.Location = new Point(12, 299);
    this.m_FirstMoveablePanel.Name = "m_FirstMoveablePanel";
    this.m_FirstMoveablePanel.Size = new Size(399, 168);
    this.m_FirstMoveablePanel.TabIndex = 25;
    this.m_SurfaceList.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_SurfaceList.Enabled = false;
    this.m_SurfaceList.FormattingEnabled = true;
    this.m_SurfaceList.Location = new Point(104, 53);
    this.m_SurfaceList.Name = "m_SurfaceList";
    this.m_SurfaceList.Size = new Size(214, 21);
    this.m_SurfaceList.TabIndex = 4;
    this.m_SelectedSurfaceLabel.AutoSize = true;
    this.m_SelectedSurfaceLabel.Enabled = false;
    this.m_SelectedSurfaceLabel.Location = new Point(0, 55);
    this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
    this.m_SelectedSurfaceLabel.Size = new Size(44, 13);
    this.m_SelectedSurfaceLabel.TabIndex = 3;
    this.m_SelectedSurfaceLabel.Text = "Surface";
    this.m_ToposurfaceCheckBox.AutoSize = true;
    this.m_ToposurfaceCheckBox.Location = new Point(0, 30);
    this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
    this.m_ToposurfaceCheckBox.Size = new Size(110, 17);
    this.m_ToposurfaceCheckBox.TabIndex = 2;
    this.m_ToposurfaceCheckBox.Text = "Pick Toposurface";
    this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
    this.m_ToposurfaceCheckBox.CheckStateChanged += new EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
    this.m_ChainRadioButton.AutoSize = true;
    this.m_ChainRadioButton.Location = new Point(151, 151);
    this.m_ChainRadioButton.Name = "m_ChainRadioButton";
    this.m_ChainRadioButton.Size = new Size(52, 17);
    this.m_ChainRadioButton.TabIndex = 7;
    this.m_ChainRadioButton.Text = "&Chain";
    this.m_ChainRadioButton.UseVisualStyleBackColor = true;
    this.m_SegmentRadioButton.AutoSize = true;
    this.m_SegmentRadioButton.Checked = true;
    this.m_SegmentRadioButton.Location = new Point(0, 151);
    this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
    this.m_SegmentRadioButton.Size = new Size(67, 17);
    this.m_SegmentRadioButton.TabIndex = 6;
    this.m_SegmentRadioButton.TabStop = true;
    this.m_SegmentRadioButton.Text = "&Segment";
    this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_PlaceTagGroupBox.Controls.Add((Control) this.m_LeaderedTagCheckBox);
    this.m_PlaceTagGroupBox.Controls.Add((Control) this.m_CreatePlantGroupTagCheckBox);
    this.m_PlaceTagGroupBox.Location = new Point(0, 80 /*0x50*/);
    this.m_PlaceTagGroupBox.Name = "m_PlaceTagGroupBox";
    this.m_PlaceTagGroupBox.Size = new Size(399, 65);
    this.m_PlaceTagGroupBox.TabIndex = 5;
    this.m_PlaceTagGroupBox.TabStop = false;
    this.m_PlaceTagGroupBox.Text = "Place Tag";
    this.m_LeaderedTagCheckBox.AutoSize = true;
    this.m_LeaderedTagCheckBox.Enabled = false;
    this.m_LeaderedTagCheckBox.Location = new Point(20, 42);
    this.m_LeaderedTagCheckBox.Name = "m_LeaderedTagCheckBox";
    this.m_LeaderedTagCheckBox.Size = new Size(93, 17);
    this.m_LeaderedTagCheckBox.TabIndex = 1;
    this.m_LeaderedTagCheckBox.Text = "Lea&dered Tag";
    this.m_LeaderedTagCheckBox.UseVisualStyleBackColor = true;
    this.m_CreatePlantGroupTagCheckBox.AutoSize = true;
    this.m_CreatePlantGroupTagCheckBox.Location = new Point(6, 19);
    this.m_CreatePlantGroupTagCheckBox.Name = "m_CreatePlantGroupTagCheckBox";
    this.m_CreatePlantGroupTagCheckBox.Size = new Size(138, 17);
    this.m_CreatePlantGroupTagCheckBox.TabIndex = 0;
    this.m_CreatePlantGroupTagCheckBox.Text = "Create Plant Group Tag";
    this.m_CreatePlantGroupTagCheckBox.UseVisualStyleBackColor = true;
    this.m_CreatePlantGroupTagCheckBox.CheckedChanged += new EventHandler(this.OnCreatePlantGroupCheckBoxChecked);
    this.m_LevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LevelComboBox.FormattingEnabled = true;
    this.m_LevelComboBox.Location = new Point(104, 3);
    this.m_LevelComboBox.Name = "m_LevelComboBox";
    this.m_LevelComboBox.Size = new Size(214, 21);
    this.m_LevelComboBox.TabIndex = 1;
    this.m_LevelLabel.AutoSize = true;
    this.m_LevelLabel.Location = new Point(0, 3);
    this.m_LevelLabel.Name = "m_LevelLabel";
    this.m_LevelLabel.Size = new Size(36, 13);
    this.m_LevelLabel.TabIndex = 0;
    this.m_LevelLabel.Text = "&Level:";
    this.m_SecondMoveablePanel.Controls.Add((Control) this.m_StartingDistanceLabel);
    this.m_SecondMoveablePanel.Controls.Add((Control) this.m_StartingDistanceTextBox);
    this.m_SecondMoveablePanel.Controls.Add((Control) this.m_DeleteExistingCheckBox);
    this.m_SecondMoveablePanel.Controls.Add((Control) this.m_CancelButton);
    this.m_SecondMoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_SecondMoveablePanel.Location = new Point(12, 496);
    this.m_SecondMoveablePanel.Name = "m_SecondMoveablePanel";
    this.m_SecondMoveablePanel.Size = new Size(399, 72);
    this.m_SecondMoveablePanel.TabIndex = 27;
    this.m_StartingDistanceLabel.AutoSize = true;
    this.m_StartingDistanceLabel.Enabled = false;
    this.m_StartingDistanceLabel.Location = new Point(20, 26);
    this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
    this.m_StartingDistanceLabel.Size = new Size(91, 13);
    this.m_StartingDistanceLabel.TabIndex = 1;
    this.m_StartingDistanceLabel.Text = "Starting Distance:";
    this.m_StartingDistanceTextBox.Enabled = false;
    this.m_StartingDistanceTextBox.Location = new Point(156, 23);
    this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
    this.m_StartingDistanceTextBox.Size = new Size(100, 20);
    this.m_StartingDistanceTextBox.TabIndex = 2;
    this.m_StartingDistanceTextBox.KeyDown += new KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
    this.m_StartingDistanceTextBox.Leave += new EventHandler(this.OnStartingDistanceTextBoxLeave);
    this.m_DeleteExistingCheckBox.AutoSize = true;
    this.m_DeleteExistingCheckBox.Enabled = false;
    this.m_DeleteExistingCheckBox.Location = new Point(20, 0);
    this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
    this.m_DeleteExistingCheckBox.Size = new Size(137, 17);
    this.m_DeleteExistingCheckBox.TabIndex = 0;
    this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
    this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(324, 49);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_InsertButton.Location = new Point(243, 49);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 3;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_SetbackLabel.AutoSize = true;
    this.m_SetbackLabel.Location = new Point(234, 123);
    this.m_SetbackLabel.Name = "m_SetbackLabel";
    this.m_SetbackLabel.Size = new Size(50, 13);
    this.m_SetbackLabel.TabIndex = 16 /*0x10*/;
    this.m_SetbackLabel.Text = "Set&back:";
    this.m_SetbackTextBox.Location = new Point(311, 120);
    this.m_SetbackTextBox.Name = "m_SetbackTextBox";
    this.m_SetbackTextBox.Size = new Size(100, 20);
    this.m_SetbackTextBox.TabIndex = 17;
    this.m_SetbackTextBox.KeyDown += new KeyEventHandler(this.OnSetbackTextBoxKeyDown);
    this.m_SetbackTextBox.Leave += new EventHandler(this.OnSetbackTextBoxLeave);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(423, 580);
    this.Controls.Add((Control) this.m_SetbackLabel);
    this.Controls.Add((Control) this.m_SetbackTextBox);
    this.Controls.Add((Control) this.m_SecondMoveablePanel);
    this.Controls.Add((Control) this.m_FirstMoveablePanel);
    this.Controls.Add((Control) this.m_SingleRadioButton);
    this.Controls.Add((Control) this.m_ExistingElementCheckBox);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_RotationLabel);
    this.Controls.Add((Control) this.m_RotationTextBox);
    this.Controls.Add((Control) this.m_GrovePanel);
    this.Controls.Add((Control) this.m_HedgeRowPanel);
    this.Controls.Add((Control) this.m_SearchButton);
    this.Controls.Add((Control) this.m_GroveRadioButton);
    this.Controls.Add((Control) this.m_PlantSpacingLabel);
    this.Controls.Add((Control) this.m_PlantSpacingTextBox);
    this.Controls.Add((Control) this.m_VarianceHeightTextBox);
    this.Controls.Add((Control) this.m_VarianceHeightLabel);
    this.Controls.Add((Control) this.m_PlantHeightTextBox);
    this.Controls.Add((Control) this.m_PlantHeightLabel);
    this.Controls.Add((Control) this.m_VarianceWidthTextBox);
    this.Controls.Add((Control) this.m_VarianceWidthLabel);
    this.Controls.Add((Control) this.m_PlantWidthTextBox);
    this.Controls.Add((Control) this.m_PlantWidthLabel);
    this.Controls.Add((Control) this.m_PlantNameComboBox);
    this.Controls.Add((Control) this.m_PlantNameLabel);
    this.Controls.Add((Control) this.m_HedgeRowRadioButton);
    this.Controls.Add((Control) this.m_PlantFamilyComboBox);
    this.Controls.Add((Control) this.m_PlantFamilyLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (PlacePlantForm);
    this.Text = "Locate Plants";
    this.FormClosing += new FormClosingEventHandler(this.OnPlacePlantFormClosing);
    this.m_HedgeRowPanel.ResumeLayout(false);
    this.m_HedgeRowPanel.PerformLayout();
    this.m_GrovePanel.ResumeLayout(false);
    this.m_GrovePanel.PerformLayout();
    this.m_FirstMoveablePanel.ResumeLayout(false);
    this.m_FirstMoveablePanel.PerformLayout();
    this.m_PlaceTagGroupBox.ResumeLayout(false);
    this.m_PlaceTagGroupBox.PerformLayout();
    this.m_SecondMoveablePanel.ResumeLayout(false);
    this.m_SecondMoveablePanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
