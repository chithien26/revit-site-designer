﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ManageFamily
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

internal class ManageFamily
{
  public static List<FamilyParameterTypeWrapper> SoftTerrainParameterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SoftTerrainLeftOffsetWidthParameter"), RevitParameters.SoftTerrainLeftOffsetWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SoftTerrainRightOffsetWidthParameter"), RevitParameters.SoftTerrainRightOffsetWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"), RevitParameters.SoftTerrainCutSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"), RevitParameters.SoftTerrainFillSlopeParameter, (ParameterType) 159));
    ManageFamily.CommonParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<FamilyParameterTypeWrapper> StreetParamenterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetNumberOfLanesParameter"), RevitParameters.StreetNumberOfLanesParameter, (ParameterType) 2));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetLaneWidthParameter"), RevitParameters.StreetLaneWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetPavementDepthParameter"), RevitParameters.StreetPavementDepthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCrossSlopeParameter"), RevitParameters.StreetCrossSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCutSlopeParameter"), RevitParameters.StreetCutSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetFillSlopeParameter"), RevitParameters.StreetFillSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbDisplayParameter"), RevitParameters.StreetCurbDisplayParameter, (ParameterType) 10));
    ManageFamily.CommonCurbParametersList(ref _ReturnParameterList);
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetBoulevardWidthParameter"), RevitParameters.StreetBoulevardWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), RevitParameters.StreetPavementSurfaceParameter, (ParameterType) 2));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetBaseSurfaceParameter"), RevitParameters.StreetBaseSurfaceParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter"), RevitParameters.StreetSubbaseSurfaceParameter, (ParameterType) 4));
    ManageFamily.CommonParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<FamilyParameterTypeWrapper> CurbParameterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CurbGutterHeightParameter"), RevitParameters.CurbGutterHeightParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CurbBaseSurfaceParameter"), RevitParameters.CurbBaseSurfaceParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CurbSubbaseSurfaceParameter"), RevitParameters.CurbSubbaseSurfaceParameter, (ParameterType) 4));
    ManageFamily.CommonCurbParametersList(ref _ReturnParameterList);
    ManageFamily.CommonParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  private static void CommonCurbParametersList(
    ref List<FamilyParameterTypeWrapper> _ReturnParameterList)
  {
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbHeightParameter"), RevitParameters.StreetCurbHeightParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), RevitParameters.StreetCurbOffsetParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbWidthParameter"), RevitParameters.StreetCurbWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetGutterWidthParameter"), RevitParameters.StreetGutterWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetGutterSlopeParameter"), RevitParameters.StreetGutterSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StreetCurbMaterialParameter"), RevitParameters.StreetCurbMaterialParameter, (ParameterType) 2));
  }

  public static List<FamilyParameterTypeWrapper> SideWalkParamterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkLocationLineParameter"), RevitParameters.SideWalkLocationLineParameter, (ParameterType) 3));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkWidthParameter"), RevitParameters.SideWalkWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkPavementDepthParameter"), RevitParameters.SideWalkPavementDepthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkPavementSurfaceParameter"), RevitParameters.SideWalkPavementSurfaceParameter, (ParameterType) 2));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkBaseSurfaceParameter"), RevitParameters.SideWalkBaseSurfaceParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkSubbaseSurfaceParameter"), RevitParameters.SideWalkSubbaseSurfaceParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkCutSlopeParameter"), RevitParameters.SideWalkCutSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SideWalkFillSlopeParameter"), RevitParameters.SideWalkFillSlopeParameter, (ParameterType) 159));
    ManageFamily.CommonParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<FamilyParameterTypeWrapper> RetainingWallParameterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallWidthParameter"), RevitParameters.RetainingWallWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallHeightParameter"), RevitParameters.RetainingWallHeightParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallSlopeProjectionParameter"), RevitParameters.RetainingWallSlopeProjectionParameter, (ParameterType) 10));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallMaterialParameter"), RevitParameters.RetainingWallMaterialParameter, (ParameterType) 2));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallCutSlopeParameter"), RevitParameters.RetainingWallCutSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallFillSlopeParameter"), RevitParameters.RetainingWallFillSlopeParameter, (ParameterType) 159));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallBaseSurfaceParameter"), RevitParameters.RetainingWallBaseSurfaceParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RetainingWallSubbaseSurfaceParameter"), RevitParameters.RetainingWallSubbaseSurfaceParameter, (ParameterType) 4));
    ManageFamily.CommonParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<FamilyParameterTypeWrapper> StepsParameterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StepsHeightParameter"), RevitParameters.StepsHeightParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StepsTreadParameter"), RevitParameters.StepsTreadParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StepsWidthParameter"), RevitParameters.StepsWidthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("StepsMaterialParameter"), RevitParameters.StepsMaterialParameter, (ParameterType) 2));
    ManageFamily.CommonParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<FamilyParameterTypeWrapper> ParkingLotParameterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ParkingLotPavementDepthParameter"), RevitParameters.ParkingLotPavementDepthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ParkingLotParkingPavementSurfaceParameter"), RevitParameters.ParkingLotParkingPavementSurfaceParameter, (ParameterType) 2));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ParkingLotParkingBaseDepthParameter"), RevitParameters.ParkingLotParkingBaseDepthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ParkingLotParkingSubBaseDepthParameter"), RevitParameters.ParkingLotParkingSubBaseDepthParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), RevitParameters.SiteworksIDFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, (ParameterType) 4));
    ManageFamily.GenericModelParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static void CommonParamenterList(
    ref List<FamilyParameterTypeWrapper> _ReturnParameterList)
  {
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SiteworksIDFamilyParameter"), RevitParameters.SiteworksIDFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, (ParameterType) 7));
    ManageFamily.GenericModelParamenterList(ref _ReturnParameterList);
  }

  public static void GenericModelParamenterList(
    ref List<FamilyParameterTypeWrapper> _ReturnParameterList)
  {
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), RevitParameters.KeynoteGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1140422));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), RevitParameters.ModelGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010109));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), RevitParameters.ManufacturerGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010108));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), RevitParameters.TypeCommentsGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010105));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), RevitParameters.URLGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010104));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), RevitParameters.DescriptionGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010103));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), RevitParameters.CostGenericFamilyParameter, (ParameterType) 172, (BuiltInParameter) -1001205));
  }

  public static bool CreateNewFamilyDocument(
    Document _ActiveDocument,
    List<FamilyTypeContainer> _FamilyTypeList,
    LandcaddID _Type,
    string _strNewFilename,
    ref Document _FamilyDocument)
  {
    double _dValue = 0.0;
    string empty1 = string.Empty;
    int _nValue = 0;
    ElementId elementId = (ElementId) null;
    bool _bIsActiveDocument = false;
    bool _bIsDocumentOpen = false;
    Document _CurDocument = _ActiveDocument;
    EPTransactionContainer _TransactionContainer = (EPTransactionContainer) null;
    List<FamilyParameter> _NewFamilyParameterList = new List<FamilyParameter>();
    if (!ManageFamily.SetupFamilyDocument(_ActiveDocument, _strNewFilename, _Type, ref _bIsActiveDocument, ref _bIsDocumentOpen, ref _CurDocument, ref _TransactionContainer, ref _NewFamilyParameterList))
      return false;
    bool flag = false;
    string empty2 = string.Empty;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _FamilyTypeList.Count <= 0 || _FamilyTypeList == null ? 30 : _FamilyTypeList.Count;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarCreatingFamilyMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    for (int index1 = 0; index1 < _FamilyTypeList.Count; ++index1)
    {
      FamilyType _SelectedType = (FamilyType) null;
      if (_FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName != string.Empty)
      {
        FamilyType familyType = ManageFamily.FindTypeNames(_CurDocument.FamilyManager.Types, _FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName, ref _SelectedType) ? _SelectedType : _CurDocument.FamilyManager.NewType(_FamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
        progressBarForm.Message = $"{EPShared.LocalRM.GetString("CreatingFamilyTypeMessage")} {familyType.Name}";
        progressBarForm.ResetValue();
        progressBarForm.MinValue = 0;
        progressBarForm.MaxValue = _NewFamilyParameterList.Count * 2;
label_47:
        for (int index2 = 0; index2 < _NewFamilyParameterList.Count; ++index2)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter1 = _NewFamilyParameterList[index2];
          if (familyParameter1 != null)
          {
            for (int index3 = 0; index3 < _FamilyTypeList[index1].FamilyParameterList.Count; ++index3)
            {
              FamilyParameterWrapper familyParameter2 = _FamilyTypeList[index1].FamilyParameterList[index3];
              if (familyParameter2 != null && (familyParameter2.FamilyParameter != null && familyParameter2.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter2.FamilyParameter.Id, familyParameter1.Id) || string.Compare(familyParameter2.ParameterName, familyParameter1.Definition.Name, true) == 0) && familyParameter2.StorageType == familyParameter1.StorageType)
              {
                string formula = familyParameter1.Formula;
                if (formula == null || formula == string.Empty)
                {
                  if (_FamilyTypeList[index1].HasValue(index3))
                  {
                    switch (familyParameter2.StorageType - 1)
                    {
                      case 0:
                        if (_FamilyTypeList[index1].GetIntegerValue(index3, ref _nValue))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, _nValue);
                          goto label_47;
                        }
                        goto label_47;
                      case 1:
                        if (_FamilyTypeList[index1].GetDoubleValue(index3, ref _dValue))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, _dValue);
                          goto label_47;
                        }
                        goto label_47;
                      case 2:
                        if (_FamilyTypeList[index1].GetStringValue(index3, ref empty1))
                        {
                          if (string.Compare(_FamilyTypeList[index1].FamilyParameterList[index3].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0)
                          {
                            switch (_Type)
                            {
                              case LandcaddID.PlantMix:
                                empty1 = Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
                                break;
                              case LandcaddID.PatioWalk:
                                empty1 = Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000");
                                break;
                              case LandcaddID.SoftTerrain:
                                empty1 = Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000");
                                break;
                              case LandcaddID.Street:
                                empty1 = Convert.ToInt32((object) LandcaddID.Street).ToString("000");
                                break;
                              case LandcaddID.Curb:
                                empty1 = Convert.ToInt32((object) LandcaddID.Curb).ToString("000");
                                break;
                              case LandcaddID.Sidewalk:
                                empty1 = Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000");
                                break;
                              case LandcaddID.RetainingWall:
                                empty1 = Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000");
                                break;
                              case LandcaddID.Steps:
                                empty1 = Convert.ToInt32((object) LandcaddID.Steps).ToString("000");
                                break;
                              case LandcaddID.ParkingLot:
                                empty1 = Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000");
                                break;
                            }
                          }
                          _CurDocument.FamilyManager.Set(familyParameter1, empty1);
                          goto label_47;
                        }
                        goto label_47;
                      case 3:
                        if (_FamilyTypeList[index1].GetElementIdValue(index3, ref elementId))
                        {
                          try
                          {
                            _CurDocument.FamilyManager.Set(familyParameter1, elementId);
                            goto label_47;
                          }
                          catch (ArgumentOutOfRangeException ex)
                          {
                            if (ex.Message.StartsWith(EPShared.LocalRM.GetString("OutOfRangeArgumentMessage")))
                            {
                              flag = true;
                              goto label_47;
                            }
                            goto label_47;
                          }
                        }
                        else
                          goto label_47;
                      default:
                        goto label_47;
                    }
                  }
                  else
                  {
                    if (string.Compare(_FamilyTypeList[index1].FamilyParameterList[index3].ParameterName, RevitParameters.SiteworksIDFamilyParameter, true) == 0)
                    {
                      switch (_Type)
                      {
                        case LandcaddID.PlantMix:
                          empty1 = Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
                          break;
                        case LandcaddID.PatioWalk:
                          empty1 = Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000");
                          break;
                        case LandcaddID.SoftTerrain:
                          empty1 = Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000");
                          break;
                        case LandcaddID.Street:
                          empty1 = Convert.ToInt32((object) LandcaddID.Street).ToString("000");
                          break;
                        case LandcaddID.Curb:
                          empty1 = Convert.ToInt32((object) LandcaddID.Curb).ToString("000");
                          break;
                        case LandcaddID.Sidewalk:
                          empty1 = Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000");
                          break;
                        case LandcaddID.RetainingWall:
                          empty1 = Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000");
                          break;
                        case LandcaddID.Steps:
                          empty1 = Convert.ToInt32((object) LandcaddID.Steps).ToString("000");
                          break;
                        case LandcaddID.ParkingLot:
                          empty1 = Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000");
                          break;
                      }
                      _CurDocument.FamilyManager.Set(familyParameter1, empty1);
                      break;
                    }
                    break;
                  }
                }
              }
            }
          }
        }
        for (int index4 = 0; index4 < _NewFamilyParameterList.Count; ++index4)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter3 = _NewFamilyParameterList[index4];
          if (familyParameter3 != null)
          {
            for (int index5 = 0; index5 < _FamilyTypeList[index1].FamilyParameterList.Count; ++index5)
            {
              FamilyParameterWrapper familyParameter4 = _FamilyTypeList[index1].FamilyParameterList[index5];
              if (familyParameter4 != null && (familyParameter4.FamilyParameter != null && familyParameter4.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter4.FamilyParameter.Id, familyParameter3.Id) || string.Compare(familyParameter4.ParameterName, familyParameter3.Definition.Name, true) == 0) && familyParameter4.StorageType == familyParameter3.StorageType)
              {
                string formula = familyParameter3.Formula;
                if (formula != null && formula != string.Empty)
                {
                  if (_FamilyTypeList[index1].HasValue(index5))
                    _CurDocument.FamilyManager.SetFormula(familyParameter3, formula);
                  _FamilyTypeList[index1].FamilyParameterList.RemoveAt(index5);
                  _NewFamilyParameterList.RemoveAt(index4);
                  --index4;
                  break;
                }
              }
            }
          }
        }
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    _TransactionContainer.EndTransaction();
    _TransactionContainer.Commit();
    int num1 = _bIsActiveDocument ? 1 : 0;
    _FamilyDocument = _CurDocument;
    if (flag)
    {
      int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("GetNewRevitVersionMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    return true;
  }

  public static List<FamilyType> RemoveTypesFromDocument(
    FamilyTypeSet DocFamilyTypeList,
    List<FamilyTypeContainer> _FamilyTypeList)
  {
    List<FamilyType> familyTypeList = new List<FamilyType>();
    foreach (FamilyType docFamilyType in DocFamilyTypeList)
    {
      bool flag = false;
      foreach (FamilyTypeContainer familyType in _FamilyTypeList)
      {
        if (string.Compare(familyType.FamilyTypeWrapper.FamilyTypeName, docFamilyType.Name, false) == 0)
        {
          flag = true;
          break;
        }
      }
      if (!flag)
        familyTypeList.Add(docFamilyType);
    }
    return familyTypeList;
  }

  public static bool FindTypeNames(
    FamilyTypeSet _CurFamilyTypeList,
    string _strTypeName,
    ref FamilyType _SelectedType)
  {
    foreach (FamilyType curFamilyType in _CurFamilyTypeList)
    {
      if (string.Compare(curFamilyType.Name, _strTypeName, true) == 0)
      {
        _SelectedType = curFamilyType;
        return true;
      }
    }
    return false;
  }

  private static bool SetupFamilyDocument(
    Document _ActiveDocument,
    string _strNewFilename,
    LandcaddID _Type,
    ref bool _bIsActiveDocument,
    ref bool _bIsDocumentOpen,
    ref Document _CurDocument,
    ref EPTransactionContainer _TransactionContainer,
    ref List<FamilyParameter> _NewFamilyParameterList)
  {
    _CurDocument = _ActiveDocument;
    if (RevitUtility.CompareFileNames(_ActiveDocument.PathName, _strNewFilename) == 0)
      _bIsActiveDocument = true;
    else if (File.Exists(_strNewFilename))
    {
      _bIsDocumentOpen = ManagePlants.IsDocumentOpen(_ActiveDocument.Application, _strNewFilename, ref _CurDocument);
      if (!_bIsDocumentOpen)
        _CurDocument = _ActiveDocument.Application.OpenDocumentFile(_strNewFilename);
    }
    else
    {
      string empty1 = string.Empty;
      string strFolderName;
      string strFileName;
      ManageFamily.GetFolderFileName(_Type, empty1, out strFolderName, out strFileName);
      string empty2 = string.Empty;
      if (RevitUtility.GetFullFamilyFilenameIfExist(strFolderName, strFileName, ref empty2))
      {
        _CurDocument = _ActiveDocument.Application.NewFamilyDocument(empty2);
      }
      else
      {
        if (!ManageFamily.FindSiteTemplateFileName(_CurDocument, ref empty2, true))
          return false;
        _CurDocument = _ActiveDocument.Application.NewFamilyDocument(empty2);
      }
    }
    _TransactionContainer = new EPTransactionContainer(_CurDocument);
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList = new List<FamilyParameterTypeWrapper>();
    string empty = string.Empty;
    switch (_Type)
    {
      case LandcaddID.PlantMix:
        parameterTypeWrapperList = ManagePlants.PlantMixParamenterList();
        _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePlantMixFamilyTransaction"));
        break;
      case LandcaddID.PatioWalk:
        parameterTypeWrapperList = ManagePlants.PatioWalkParamenterList();
        _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePatioWalkFamilyTransaction"));
        break;
      case LandcaddID.SoftTerrain:
        parameterTypeWrapperList = ManageFamily.SoftTerrainParameterList();
        string _strTransactionName1 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("SoftTerrainManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName1);
        break;
      case LandcaddID.Street:
        parameterTypeWrapperList = ManageFamily.StreetParamenterList();
        string _strTransactionName2 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("StreetTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName2);
        break;
      case LandcaddID.Curb:
        parameterTypeWrapperList = ManageFamily.CurbParameterList();
        string _strTransactionName3 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("CurbTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName3);
        break;
      case LandcaddID.Sidewalk:
        parameterTypeWrapperList = ManageFamily.SideWalkParamterList();
        string _strTransactionName4 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("SidewalkTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName4);
        break;
      case LandcaddID.RetainingWall:
        parameterTypeWrapperList = ManageFamily.RetainingWallParameterList();
        string _strTransactionName5 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("RetainingWallManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName5);
        break;
      case LandcaddID.Steps:
        parameterTypeWrapperList = ManageFamily.StepsParameterList();
        string _strTransactionName6 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("StepsManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName6);
        break;
      case LandcaddID.ParkingLot:
        parameterTypeWrapperList = ManageFamily.ParkingLotParameterList();
        string _strTransactionName7 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("ParkingLotManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName7);
        break;
    }
    _TransactionContainer.BeginTransaction();
    BuiltInParameterGroup inParameterGroup = (BuiltInParameterGroup) -1;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = parameterTypeWrapperList.Count;
    if (parameterTypeWrapperList.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSettingParametersMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    for (int index = 0; index < parameterTypeWrapperList.Count; ++index)
    {
      if (string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) != 0)
      {
        FamilyParameter familyParameter = (FamilyParameter) null;
        if (parameterTypeWrapperList[index].BuiltInParameter != -1)
          familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList[index].BuiltInParameter];
        if (familyParameter == null)
          familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList[index].ParameterName];
        if (familyParameter != null)
        {
          _NewFamilyParameterList.Add(familyParameter);
        }
        else
        {
          if (parameterTypeWrapperList[index].ParameterType == 3 || parameterTypeWrapperList[index].ParameterType == 2 || parameterTypeWrapperList[index].ParameterType == 4)
            inParameterGroup = (BuiltInParameterGroup) -5000101;
          else if (parameterTypeWrapperList[index].ParameterType == 1 || parameterTypeWrapperList[index].ParameterType == 17 || parameterTypeWrapperList[index].ParameterType == 172)
            inParameterGroup = (BuiltInParameterGroup) -5000100;
          if (string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0)
            _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList[index].ParameterName, inParameterGroup, parameterTypeWrapperList[index].ParameterType, true));
          else
            _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList[index].ParameterName, inParameterGroup, parameterTypeWrapperList[index].ParameterType, false));
        }
        progressBarForm.UpdateProgressBar(1);
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  private static string GetFolderFileName(
    LandcaddID _Type,
    string strCurrentFamilyType,
    out string strFolderName,
    out string strFileName)
  {
    strFolderName = string.Empty;
    strFileName = string.Empty;
    switch (_Type)
    {
      case LandcaddID.PlantMix:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
        strFolderName = string.Empty;
        strFileName = string.Empty;
        break;
      case LandcaddID.PatioWalk:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000");
        strFolderName = string.Empty;
        strFileName = string.Empty;
        break;
      case LandcaddID.SoftTerrain:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000");
        strFolderName = string.Empty;
        strFileName = "Sample Soft Terrain.rft";
        break;
      case LandcaddID.Street:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.Street).ToString("000");
        strFolderName = string.Empty;
        strFileName = "Sample Street.rft";
        break;
      case LandcaddID.Curb:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.Curb).ToString("000");
        strFolderName = string.Empty;
        strFileName = "Sample Curb.rft";
        break;
      case LandcaddID.Sidewalk:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000");
        strFolderName = string.Empty;
        strFileName = "Sample Sidewalk.rft";
        break;
      case LandcaddID.RetainingWall:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000");
        strFolderName = string.Empty;
        strFileName = "Sample Retaining Wall.rft";
        break;
      case LandcaddID.Steps:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.Steps).ToString("000");
        strFolderName = string.Empty;
        strFileName = string.Empty;
        break;
      case LandcaddID.ParkingLot:
        strCurrentFamilyType = Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000");
        strFolderName = string.Empty;
        strFileName = "Sample Parking Lot.rft";
        break;
    }
    return strCurrentFamilyType;
  }

  private static bool SetupFamilyDocument(
    Document _ActiveDocument,
    string _strNewFilename,
    LandcaddID _Type,
    Family _CurrFamily,
    ref bool _bIsActiveDocument,
    ref bool _bIsDocumentOpen,
    ref Document _CurDocument,
    ref EPTransactionContainer _TransactionContainer,
    ref List<FamilyParameter> _NewFamilyParameterList)
  {
    _CurDocument = _ActiveDocument;
    if (_CurrFamily != null)
    {
      EPTransactionContainer transactionContainer = new EPTransactionContainer(_ActiveDocument);
      transactionContainer.Start(EPShared.LocalRM.GetString("UpdatingFamilyTransaction"));
      transactionContainer.BeginTransaction();
      _ActiveDocument.Delete(((Element) _CurrFamily).Id);
      transactionContainer.EndTransaction();
      transactionContainer.Commit();
    }
    if (RevitUtility.CompareFileNames(_ActiveDocument.PathName, _strNewFilename) == 0)
      _bIsActiveDocument = true;
    else if (File.Exists(_strNewFilename))
    {
      _bIsDocumentOpen = ManagePlants.IsDocumentOpen(_ActiveDocument.Application, _strNewFilename, ref _CurDocument);
      if (!_bIsDocumentOpen)
        _CurDocument = _ActiveDocument.Application.OpenDocumentFile(_strNewFilename);
    }
    else
    {
      string empty1 = string.Empty;
      string strFolderName;
      string strFileName;
      ManageFamily.GetFolderFileName(_Type, empty1, out strFolderName, out strFileName);
      string empty2 = string.Empty;
      if (RevitUtility.GetFullFamilyFilenameIfExist(strFolderName, strFileName, ref empty2))
      {
        _CurDocument = _ActiveDocument.Application.NewFamilyDocument(empty2);
      }
      else
      {
        if (!ManageFamily.FindSiteTemplateFileName(_CurDocument, ref empty2, true))
          return false;
        _CurDocument = _ActiveDocument.Application.NewFamilyDocument(empty2);
      }
    }
    _TransactionContainer = new EPTransactionContainer(_CurDocument);
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList = new List<FamilyParameterTypeWrapper>();
    string empty = string.Empty;
    switch (_Type)
    {
      case LandcaddID.PlantMix:
        parameterTypeWrapperList = ManagePlants.PlantMixParamenterList();
        _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePlantMixFamilyTransaction"));
        break;
      case LandcaddID.PatioWalk:
        parameterTypeWrapperList = ManagePlants.PatioWalkParamenterList();
        _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePatioWalkFamilyTransaction"));
        break;
      case LandcaddID.SoftTerrain:
        parameterTypeWrapperList = ManageFamily.SoftTerrainParameterList();
        string _strTransactionName1 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("SoftTerrainManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName1);
        break;
      case LandcaddID.Street:
        parameterTypeWrapperList = ManageFamily.StreetParamenterList();
        string _strTransactionName2 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("StreetTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName2);
        break;
      case LandcaddID.Curb:
        parameterTypeWrapperList = ManageFamily.CurbParameterList();
        string _strTransactionName3 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("CurbTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName3);
        break;
      case LandcaddID.Sidewalk:
        parameterTypeWrapperList = ManageFamily.SideWalkParamterList();
        string _strTransactionName4 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("SidewalkTypeManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName4);
        break;
      case LandcaddID.RetainingWall:
        parameterTypeWrapperList = ManageFamily.RetainingWallParameterList();
        string _strTransactionName5 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("RetainingWallManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName5);
        break;
      case LandcaddID.Steps:
        parameterTypeWrapperList = ManageFamily.StepsParameterList();
        string _strTransactionName6 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("StepsManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName6);
        break;
      case LandcaddID.ParkingLot:
        parameterTypeWrapperList = ManageFamily.ParkingLotParameterList();
        string _strTransactionName7 = EPShared.LocalRM.GetString("Create_") + EPShared.LocalRM.GetString("ParkingLotManagerString") + EPShared.LocalRM.GetString("_Family_");
        _TransactionContainer.Start(_strTransactionName7);
        break;
    }
    _TransactionContainer.BeginTransaction();
    BuiltInParameterGroup inParameterGroup = (BuiltInParameterGroup) -1;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = parameterTypeWrapperList.Count;
    if (parameterTypeWrapperList.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSettingParametersMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    for (int index = 0; index < parameterTypeWrapperList.Count; ++index)
    {
      if (string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) != 0)
      {
        FamilyParameter familyParameter = (FamilyParameter) null;
        if (parameterTypeWrapperList[index].BuiltInParameter != -1)
          familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList[index].BuiltInParameter];
        if (familyParameter == null)
          familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList[index].ParameterName];
        if (familyParameter != null)
        {
          _NewFamilyParameterList.Add(familyParameter);
        }
        else
        {
          if (parameterTypeWrapperList[index].ParameterType == 3 || parameterTypeWrapperList[index].ParameterType == 2 || parameterTypeWrapperList[index].ParameterType == 4)
            inParameterGroup = (BuiltInParameterGroup) -5000101;
          else if (parameterTypeWrapperList[index].ParameterType == 1 || parameterTypeWrapperList[index].ParameterType == 17 || parameterTypeWrapperList[index].ParameterType == 172)
            inParameterGroup = (BuiltInParameterGroup) -5000100;
          if (string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0)
            _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList[index].ParameterName, inParameterGroup, parameterTypeWrapperList[index].ParameterType, true));
          else
            _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList[index].ParameterName, inParameterGroup, parameterTypeWrapperList[index].ParameterType, false));
        }
        progressBarForm.UpdateProgressBar(1);
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  private static string GetUniqueTypeName(FamilyTypeSet _CurFamilyTypeSet, string _strQueryTypeName)
  {
    foreach (FamilyType curFamilyType in _CurFamilyTypeSet)
    {
      if (string.Compare(curFamilyType.Name, _strQueryTypeName, true) == 0)
      {
        string str1 = string.Empty;
        string empty = string.Empty;
        int length = _strQueryTypeName.LastIndexOf(" ");
        if (length > 0 && length < _strQueryTypeName.Length - 1)
        {
          str1 = _strQueryTypeName.Substring(0, length);
          int index = length + 1;
          while (length < _strQueryTypeName.Length)
          {
            if (char.IsDigit(_strQueryTypeName[index]))
            {
              empty += _strQueryTypeName[index].ToString();
              ++index;
            }
            else
            {
              empty = string.Empty;
              break;
            }
          }
        }
        string str2;
        if (empty == string.Empty)
        {
          str1 = _strQueryTypeName;
          str2 = "1";
        }
        else
          str2 = Convert.ToString(Convert.ToInt32(empty) + 1);
        return ManageFamily.GetUniqueTypeName(_CurFamilyTypeSet, $"{str1} {str2}");
      }
    }
    return _strQueryTypeName;
  }

  private static bool IsTypeNameDuplicate(FamilyTypeSet _CurFamilyTypeSet, string _strQueryTypeName)
  {
    foreach (FamilyType curFamilyType in _CurFamilyTypeSet)
    {
      if (string.Compare(curFamilyType.Name, _strQueryTypeName, true) == 0)
        return true;
    }
    return false;
  }

  public static bool FindSiteTemplateFileName(
    Document _Document,
    ref string _strTemplateFileName,
    bool _bIssueWarning)
  {
    bool templateFileName = false;
    string _strSettingsName = "SiteTemplateFileName";
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName, ref _strTemplateFileName) || !File.Exists(_strTemplateFileName))
    {
      if (_Document != null)
      {
        string searchPattern = string.Empty;
        string empty = string.Empty;
        IDictionary<string, string> libraryPaths = _Document.Application.GetLibraryPaths();
        if (libraryPaths != null && libraryPaths.Count > 0)
        {
          foreach (string path in (IEnumerable<string>) libraryPaths.Values)
          {
            DirectoryInfo directoryInfo1 = new DirectoryInfo(path);
            DirectoryInfo directoryInfo2 = (DirectoryInfo) null;
            if (directoryInfo1.Parent != null)
              directoryInfo2 = directoryInfo1.Parent.Parent;
            if (directoryInfo2 != null)
            {
              if (_Document.DisplayUnitSystem == 1)
              {
                if (searchPattern == string.Empty)
                  searchPattern = ApplicationUtility.GetString("SiteImperialTemplate") + ".rft";
                if (empty == string.Empty)
                  empty = ApplicationUtility.GetString("ENU-ImperialTemplateFolderName");
              }
              else if (_Document.DisplayUnitSystem == null)
              {
                if (searchPattern == string.Empty)
                  searchPattern = ApplicationUtility.GetString("SiteMetricTemplate") + ".rft";
                if (empty == string.Empty)
                  empty = ApplicationUtility.GetString("ENU-MetricTemplateFolderName");
              }
              if (directoryInfo2.Exists)
              {
                try
                {
                  foreach (DirectoryInfo directory in directoryInfo2.GetDirectories(empty, SearchOption.AllDirectories))
                  {
                    foreach (FileInfo file in directory.GetFiles(searchPattern, SearchOption.AllDirectories))
                    {
                      if (file.Exists)
                      {
                        _strTemplateFileName = file.FullName;
                        templateFileName = true;
                        break;
                      }
                    }
                    if (templateFileName)
                      break;
                  }
                }
                catch (UnauthorizedAccessException ex)
                {
                  continue;
                }
                catch (DirectoryNotFoundException ex)
                {
                  continue;
                }
              }
            }
            if (templateFileName)
              break;
          }
        }
      }
      if (!templateFileName)
      {
        string empty1 = string.Empty;
        string empty2 = string.Empty;
        if (!File.Exists(ApplicationUtility.RevitIniFilename))
        {
          if (_bIssueWarning)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RevitINIFileMissingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
          }
          return false;
        }
        StreamReader streamReader = new StreamReader((Stream) new FileStream(ApplicationUtility.RevitIniFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
        string strA;
        while ((strA = streamReader.ReadLine()) != null)
        {
          if (strA.Contains(ApplicationUtility.GetString("FamilyTemplatePath")))
          {
            string str = string.Empty;
            int num = strA.IndexOf('=');
            if (num >= 0 && num < strA.Length - 1)
            {
              str = strA.Substring(num + 1);
              if (!str.EndsWith("\\"))
                str += "\\";
            }
            _strTemplateFileName = !strA.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str + ApplicationUtility.GetString("SiteMetricTemplate") : str + ApplicationUtility.GetString("SiteImperialTemplate");
            _strTemplateFileName += ".rft";
            if (File.Exists(_strTemplateFileName))
            {
              templateFileName = true;
              break;
            }
            _strTemplateFileName = string.Empty;
          }
          else if (string.Compare(strA, EPShared.LocalRM.GetString("ContentInstalledName"), true) == 0)
          {
            string str1;
            while ((str1 = streamReader.ReadLine()) != null)
            {
              if (str1.Contains(ApplicationUtility.GetString("ImperialTemplateCabName")) || str1.Contains(ApplicationUtility.GetString("MetricTemplateCabName")))
              {
                string str2 = string.Empty;
                int num = str1.IndexOf('=');
                if (num >= 0 && num < str1.Length - 1)
                {
                  str2 = str1.Substring(num + 1);
                  if (!str2.EndsWith("\\"))
                    str2 += "\\";
                }
                _strTemplateFileName = !str1.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str2 + ApplicationUtility.GetString("SiteMetricTemplate") : str2 + ApplicationUtility.GetString("SiteImperialTemplate");
                _strTemplateFileName += ".rft";
                if (File.Exists(_strTemplateFileName))
                {
                  templateFileName = true;
                  break;
                }
                _strTemplateFileName = string.Empty;
              }
            }
            break;
          }
        }
        streamReader.Close();
      }
      if (!templateFileName)
      {
        if (!_bIssueWarning)
          return false;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSiteRFTMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
          openFileDialog.Title = EPShared.LocalRM.GetString("TemplateNotLoadedErrorMessage");
          openFileDialog.RestoreDirectory = true;
          openFileDialog.Filter = ApplicationUtility.GetString("TemplateFilePickerFilter");
          if (openFileDialog.ShowDialog() == DialogResult.Cancel)
            return false;
          _strTemplateFileName = openFileDialog.FileName;
          templateFileName = true;
        }
      }
      ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName, _strTemplateFileName);
    }
    else
      templateFileName = true;
    return templateFileName;
  }

  public static void GetGenericModelFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager,
    ref List<FamilyParameterWrapper> _ReturnFamilyParameterSet)
  {
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameter _FamilyParameter1 = _FamilyManager[(BuiltInParameter) -1140422] ?? _FamilyManager[RevitParameters.KeynoteGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper1 = _FamilyParameter1 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), RevitParameters.KeynoteGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), _FamilyParameter1, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameter _FamilyParameter2 = _FamilyManager[(BuiltInParameter) -1010109] ?? _FamilyManager[RevitParameters.ModelGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper2 = _FamilyParameter2 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), RevitParameters.ModelGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), _FamilyParameter2, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameter _FamilyParameter3 = _FamilyManager[(BuiltInParameter) -1010108] ?? _FamilyManager[RevitParameters.ManufacturerGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper3 = _FamilyParameter3 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), RevitParameters.ManufacturerGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), _FamilyParameter3, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameter _FamilyParameter4 = _FamilyManager[(BuiltInParameter) -1010105] ?? _FamilyManager[RevitParameters.TypeCommentsGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper4 = _FamilyParameter4 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), RevitParameters.TypeCommentsGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), _FamilyParameter4, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameter _FamilyParameter5 = _FamilyManager[(BuiltInParameter) -1010104] ?? _FamilyManager[RevitParameters.URLGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper5 = _FamilyParameter5 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), RevitParameters.URLGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), _FamilyParameter5, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameter _FamilyParameter6 = _FamilyManager[(BuiltInParameter) -1010103] ?? _FamilyManager[RevitParameters.DescriptionGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper6 = _FamilyParameter6 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), RevitParameters.DescriptionGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), _FamilyParameter6, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    FamilyParameter _FamilyParameter7 = _FamilyManager[(BuiltInParameter) -1001205] ?? _FamilyManager[RevitParameters.CostGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper7 = _FamilyParameter7 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), RevitParameters.CostGenericFamilyParameter, "1.0", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), _FamilyParameter7, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper7);
  }

  public static List<FamilyParameterWrapper> GetStreetFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> parameterSetForType = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.StreetNumberOfLanesParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetNumberOfLanesParameter"), RevitParameters.StreetNumberOfLanesParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetNumberOfLanesParameter"), _FamilyManager[RevitParameters.StreetNumberOfLanesParameter], "");
    parameterSetForType.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.StreetLaneWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetLaneWidthParameter"), RevitParameters.StreetLaneWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetLaneWidthParameter"), _FamilyManager[RevitParameters.StreetLaneWidthParameter], "");
    parameterSetForType.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.StreetPavementDepthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetPavementDepthParameter"), RevitParameters.StreetPavementDepthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetPavementDepthParameter"), _FamilyManager[RevitParameters.StreetPavementDepthParameter], "");
    parameterSetForType.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.StreetCrossSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCrossSlopeParameter"), RevitParameters.StreetCrossSlopeParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCrossSlopeParameter"), _FamilyManager[RevitParameters.StreetCrossSlopeParameter], "");
    parameterSetForType.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.StreetCutSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCutSlopeParameter"), RevitParameters.StreetCutSlopeParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCutSlopeParameter"), _FamilyManager[RevitParameters.StreetCutSlopeParameter], "");
    parameterSetForType.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.StreetFillSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetFillSlopeParameter"), RevitParameters.StreetFillSlopeParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetFillSlopeParameter"), _FamilyManager[RevitParameters.StreetFillSlopeParameter], "");
    parameterSetForType.Add(parameterWrapper6);
    FamilyParameterWrapper parameterWrapper7 = _FamilyManager[RevitParameters.StreetCurbDisplayParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbDisplayParameter"), RevitParameters.StreetCurbDisplayParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbDisplayParameter"), _FamilyManager[RevitParameters.StreetCurbDisplayParameter], "");
    parameterSetForType.Add(parameterWrapper7);
    ManageFamily.GetCommonCurbParameters(ref parameterSetForType, _FamilyType, _FamilyManager);
    FamilyParameterWrapper parameterWrapper8 = _FamilyManager[RevitParameters.StreetBoulevardWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetBoulevardWidthParameter"), RevitParameters.StreetBoulevardWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetBoulevardWidthParameter"), _FamilyManager[RevitParameters.StreetBoulevardWidthParameter], "");
    parameterSetForType.Add(parameterWrapper8);
    FamilyParameterWrapper parameterWrapper9 = _FamilyManager[RevitParameters.StreetPavementSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), RevitParameters.StreetPavementSurfaceParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), _FamilyManager[RevitParameters.StreetPavementSurfaceParameter], "");
    parameterSetForType.Add(parameterWrapper9);
    FamilyParameterWrapper parameterWrapper10 = _FamilyManager[RevitParameters.StreetBaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetBaseSurfaceParameter"), RevitParameters.StreetBaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetBaseSurfaceParameter"), _FamilyManager[RevitParameters.StreetBaseSurfaceParameter], "");
    parameterSetForType.Add(parameterWrapper10);
    FamilyParameterWrapper parameterWrapper11 = _FamilyManager[RevitParameters.StreetSubbaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter"), RevitParameters.StreetSubbaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetSubbaseSurfaceParameter"), _FamilyManager[RevitParameters.StreetSubbaseSurfaceParameter], "");
    parameterSetForType.Add(parameterWrapper11);
    FamilyParameterWrapper parameterWrapper12 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    parameterSetForType.Add(parameterWrapper12);
    FamilyParameterWrapper parameterWrapper13 = _FamilyManager[RevitParameters.CurveIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), _FamilyManager[RevitParameters.CurveIncrementParameter], "");
    parameterSetForType.Add(parameterWrapper13);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref parameterSetForType);
    return parameterSetForType;
  }

  public static List<FamilyParameterWrapper> GetCurbFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> parameterSetForType = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.CurbGutterHeightParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbGutterHeightParameter"), RevitParameters.CurbGutterHeightParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbGutterHeightParameter"), _FamilyManager[RevitParameters.CurbGutterHeightParameter], "");
    parameterSetForType.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.CurbBaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbBaseSurfaceParameter"), RevitParameters.CurbBaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbBaseSurfaceParameter"), _FamilyManager[RevitParameters.CurbBaseSurfaceParameter], "");
    parameterSetForType.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.CurbSubbaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbSubbaseSurfaceParameter"), RevitParameters.CurbSubbaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbSubbaseSurfaceParameter"), _FamilyManager[RevitParameters.CurbSubbaseSurfaceParameter], "");
    parameterSetForType.Add(parameterWrapper3);
    ManageFamily.GetCommonCurbParameters(ref parameterSetForType, _FamilyType, _FamilyManager);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    parameterSetForType.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.CurveIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), _FamilyManager[RevitParameters.CurveIncrementParameter], "");
    parameterSetForType.Add(parameterWrapper5);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref parameterSetForType);
    return parameterSetForType;
  }

  private static void GetCommonCurbParameters(
    ref List<FamilyParameterWrapper> ReturnFamilyParameterSet,
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.StreetCurbHeightParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbHeightParameter"), RevitParameters.StreetCurbHeightParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbHeightParameter"), _FamilyManager[RevitParameters.StreetCurbHeightParameter], "");
    ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.StreetCurbOffsetParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), RevitParameters.StreetCurbOffsetParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbOffsetParameter"), _FamilyManager[RevitParameters.StreetCurbOffsetParameter], "");
    ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.StreetCurbWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbWidthParameter"), RevitParameters.StreetCurbWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetCurbWidthParameter"), _FamilyManager[RevitParameters.StreetCurbWidthParameter], "");
    ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.StreetGutterWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetGutterWidthParameter"), RevitParameters.StreetGutterWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StreetGutterWidthParameter"), _FamilyManager[RevitParameters.StreetGutterWidthParameter], "");
    ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.CurbGutterSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbGutterSlopeParameter"), RevitParameters.CurbGutterSlopeParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbGutterSlopeParameter"), _FamilyManager[RevitParameters.CurbGutterSlopeParameter], "");
    ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.CurbMaterialParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbMaterialParameter"), RevitParameters.CurbMaterialParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurbMaterialParameter"), _FamilyManager[RevitParameters.CurbMaterialParameter], "");
    ReturnFamilyParameterSet.Add(parameterWrapper6);
  }

  public static List<FamilyParameterWrapper> GetSidewalkFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.SideWalkLocationLineParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkLocationLineParameter"), RevitParameters.SideWalkLocationLineParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkLocationLineParameter"), _FamilyManager[RevitParameters.SideWalkLocationLineParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.SideWalkWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkWidthParameter"), RevitParameters.SideWalkWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkWidthParameter"), _FamilyManager[RevitParameters.SideWalkWidthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.SideWalkPavementDepthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkPavementDepthParameter"), RevitParameters.SideWalkPavementDepthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkPavementDepthParameter"), _FamilyManager[RevitParameters.SideWalkPavementDepthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.SideWalkPavementSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkPavementSurfaceParameter"), RevitParameters.SideWalkPavementSurfaceParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkPavementSurfaceParameter"), _FamilyManager[RevitParameters.SideWalkPavementSurfaceParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.SideWalkBaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkBaseSurfaceParameter"), RevitParameters.SideWalkBaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkBaseSurfaceParameter"), _FamilyManager[RevitParameters.SideWalkBaseSurfaceParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.SideWalkSubbaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkSubbaseSurfaceParameter"), RevitParameters.SideWalkSubbaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkSubbaseSurfaceParameter"), _FamilyManager[RevitParameters.SideWalkSubbaseSurfaceParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    FamilyParameterWrapper parameterWrapper7 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper7);
    FamilyParameterWrapper parameterWrapper8 = _FamilyManager[RevitParameters.CurveIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), _FamilyManager[RevitParameters.CurveIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper8);
    FamilyParameterWrapper parameterWrapper9 = _FamilyManager[RevitParameters.SideWalkCutSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkCutSlopeParameter"), RevitParameters.SideWalkCutSlopeParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkCutSlopeParameter"), _FamilyManager[RevitParameters.SideWalkCutSlopeParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper9);
    FamilyParameterWrapper parameterWrapper10 = _FamilyManager[RevitParameters.SideWalkFillSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkFillSlopeParameter"), RevitParameters.SideWalkFillSlopeParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SideWalkFillSlopeParameter"), _FamilyManager[RevitParameters.SideWalkFillSlopeParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper10);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }

  public static List<FamilyParameterWrapper> GetRetainingWallFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.RetainingWallWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallWidthParameter"), RevitParameters.RetainingWallWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallWidthParameter"), _FamilyManager[RevitParameters.RetainingWallWidthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.RetainingWallHeightParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallHeightParameter"), RevitParameters.RetainingWallHeightParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallHeightParameter"), _FamilyManager[RevitParameters.RetainingWallHeightParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.RetainingWallSlopeProjectionParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallSlopeProjectionParameter"), RevitParameters.RetainingWallSlopeProjectionParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallSlopeProjectionParameter"), _FamilyManager[RevitParameters.RetainingWallSlopeProjectionParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.RetainingWallMaterialParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallMaterialParameter"), RevitParameters.RetainingWallMaterialParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallMaterialParameter"), _FamilyManager[RevitParameters.RetainingWallMaterialParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.RetainingWallCutSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallCutSlopeParameter"), RevitParameters.RetainingWallCutSlopeParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallCutSlopeParameter"), _FamilyManager[RevitParameters.RetainingWallCutSlopeParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.RetainingWallFillSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallFillSlopeParameter"), RevitParameters.RetainingWallFillSlopeParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallFillSlopeParameter"), _FamilyManager[RevitParameters.RetainingWallFillSlopeParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    FamilyParameterWrapper parameterWrapper7 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper7);
    FamilyParameterWrapper parameterWrapper8 = _FamilyManager[RevitParameters.CurveIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), _FamilyManager[RevitParameters.CurveIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper8);
    FamilyParameterWrapper parameterWrapper9 = _FamilyManager[RevitParameters.RetainingWallBaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallBaseSurfaceParameter"), RevitParameters.RetainingWallBaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallBaseSurfaceParameter"), _FamilyManager[RevitParameters.RetainingWallBaseSurfaceParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper9);
    FamilyParameterWrapper parameterWrapper10 = _FamilyManager[RevitParameters.RetainingWallSubbaseSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallSubbaseSurfaceParameter"), RevitParameters.RetainingWallSubbaseSurfaceParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RetainingWallSubbaseSurfaceParameter"), _FamilyManager[RevitParameters.RetainingWallSubbaseSurfaceParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper10);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }

  public static List<FamilyParameterWrapper> GetStepsFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.StepsHeightParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsHeightParameter"), RevitParameters.StepsHeightParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsHeightParameter"), _FamilyManager[RevitParameters.StepsHeightParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.StepsTreadParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsTreadParameter"), RevitParameters.StepsTreadParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsTreadParameter"), _FamilyManager[RevitParameters.StepsTreadParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.StepsWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsWidthParameter"), RevitParameters.StepsWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsWidthParameter"), _FamilyManager[RevitParameters.StepsWidthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.StepsMaterialParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsMaterialParameter"), RevitParameters.StepsMaterialParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("StepsMaterialParameter"), _FamilyManager[RevitParameters.StepsMaterialParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.CurveIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), _FamilyManager[RevitParameters.CurveIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }

  public static List<FamilyParameterWrapper> GetParkingLotFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.ParkingLotPavementDepthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotPavementDepthParameter"), RevitParameters.ParkingLotPavementDepthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotPavementDepthParameter"), _FamilyManager[RevitParameters.ParkingLotPavementDepthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.ParkingLotParkingPavementSurfaceParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotParkingPavementSurfaceParameter"), RevitParameters.ParkingLotParkingPavementSurfaceParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotParkingPavementSurfaceParameter"), _FamilyManager[RevitParameters.ParkingLotParkingPavementSurfaceParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.ParkingLotParkingBaseDepthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotParkingBaseDepthParameter"), RevitParameters.ParkingLotParkingBaseDepthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotParkingBaseDepthParameter"), _FamilyManager[RevitParameters.ParkingLotParkingBaseDepthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.ParkingLotParkingSubBaseDepthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotParkingSubBaseDepthParameter"), RevitParameters.ParkingLotParkingSubBaseDepthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ParkingLotParkingSubBaseDepthParameter"), _FamilyManager[RevitParameters.ParkingLotParkingSubBaseDepthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }

  public static List<FamilyParameterWrapper> GetSoftTerrainFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.SoftTerrainLeftOffsetWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainLeftOffsetWidthParameter"), RevitParameters.SoftTerrainLeftOffsetWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainLeftOffsetWidthParameter"), _FamilyManager[RevitParameters.SoftTerrainLeftOffsetWidthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.SoftTerrainRightOffsetWidthParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainRightOffsetWidthParameter"), RevitParameters.SoftTerrainRightOffsetWidthParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainRightOffsetWidthParameter"), _FamilyManager[RevitParameters.SoftTerrainRightOffsetWidthParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.SoftTerrainCutSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"), RevitParameters.SoftTerrainCutSlopeParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainCutSlopeParameter"), _FamilyManager[RevitParameters.SoftTerrainCutSlopeParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.SoftTerrainFillSlopeParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"), RevitParameters.SoftTerrainFillSlopeParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SoftTerrainFillSlopeParameter"), _FamilyManager[RevitParameters.SoftTerrainFillSlopeParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.LinearIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), RevitParameters.LinearIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LinearIncrementParameter"), _FamilyManager[RevitParameters.LinearIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.CurveIncrementParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), RevitParameters.CurveIncrementParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CurveIncrementParameter"), _FamilyManager[RevitParameters.CurveIncrementParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    ManageFamily.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }
}
