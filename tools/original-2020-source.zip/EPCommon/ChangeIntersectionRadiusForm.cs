﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ChangeIntersectionRadiusForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ChangeIntersectionRadiusForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private List<IntersectionStationContainer> m_LeftIntersectionStations;
  private List<IntersectionStationContainer> m_RightIntersectionStations;
  private List<Eps_Point> m_IntersectionPointList = new List<Eps_Point>();
  private Document m_Document;
  private EPTransactionContainer m_TransactionContainer;
  private ElementSet m_DeleteElementSet;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private bool m_bRightSide = true;
  private int m_nIntersectionStationContainerIndex = -1;
  private int m_nIntersectionStationIndex = -1;
  private Eps_Leg m_LeftExistingOffsetLeg;
  private Eps_Leg m_RightExistingOffsetLeg;
  private Eps_Leg m_LeftOffsetLeg;
  private Eps_Leg m_RightOffsetLeg;
  private double m_dExistingAdjustSubgradeElev;
  private bool m_bIsFirstIntersectionFourWay;
  private Eps_Point m_InvalidLegSegmentPoint;
  private double m_dMinimumRadius;
  private LandcaddID m_CurLocateType;
  private IContainer components;
  private GroupBox m_RadiusGroupBox;
  private Button m_ApplyButton;
  private Button m_EditRadiusButton;
  private Label m_NewRadiusLbl;
  private Label m_CurrentRadiusLbl;
  private Button m_FinishButton;
  private Button m_CancelButton;
  private Label m_CurrentRadiusValueLbl;
  private TextBox m_NewRadiusTextBox;

  public ChangeIntersectionRadiusForm(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    LandcaddID _LocateType,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    Eps_Leg _LeftOffsetLeg,
    Eps_Leg _RightOffsetLeg,
    double _dExistingAdjustSubgradeElev,
    bool _bIsFirstIntersectionFourWay,
    double _dMinimumRadius)
  {
    this.InitializeComponent();
    this.m_Document = _Document;
    this.m_TransactionContainer = _TransactionContainer;
    this.m_CurLocateType = _LocateType;
    this.ContextualHelpID = "HID_SDstreetRadius";
    this.SetupString();
    this.GetDialogPosition();
    this.m_LeftExistingOffsetLeg = _LeftExistingOffsetLeg;
    this.m_RightExistingOffsetLeg = _RightExistingOffsetLeg;
    this.m_LeftOffsetLeg = _LeftOffsetLeg;
    this.m_RightOffsetLeg = _RightOffsetLeg;
    this.m_dExistingAdjustSubgradeElev = _dExistingAdjustSubgradeElev;
    this.m_bIsFirstIntersectionFourWay = _bIsFirstIntersectionFourWay;
    this.m_dMinimumRadius = _dMinimumRadius;
    this.m_Units = this.m_Document.GetUnits();
  }

  public void ShowDialog(ref DialogResult _DialogResult) => _DialogResult = this.ShowDialog();

  public void Draw()
  {
    this.m_IntersectionPointList.Clear();
    if (this.m_DeleteElementSet != null)
    {
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_DeleteElementSet));
      this.m_DeleteElementSet = (ElementSet) null;
    }
    this.DrawAnnotate(this.m_LeftIntersectionStations);
    this.DrawAnnotate(this.m_RightIntersectionStations);
  }

  private void DrawAnnotate(
    List<IntersectionStationContainer> _IntersectionStations)
  {
    foreach (IntersectionStationContainer intersectionStation1 in _IntersectionStations)
    {
      foreach (IntersectionStation intersectionStation2 in intersectionStation1.IntersectionStations)
      {
        if (intersectionStation2.InvalidIntersectionPnt == null)
        {
          Eps_Point epsPoint = new Eps_Point();
          bool _bDoesMassLineSubCategoryExist = false;
          if (intersectionStation2.IntersectionLeg != null)
          {
            if (intersectionStation2.IntersectionLeg.Arc != null)
            {
              double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(intersectionStation2.IntersectionLeg.Arc.Radius, intersectionStation2.IntersectionLeg.Arc.Delta);
              EPShared.eplGeoE_FindStaOffPointAlongArc(intersectionStation2.IntersectionLeg.Arc, num / 2.0, 0.0, ref epsPoint);
              this.m_IntersectionPointList.Add(epsPoint);
              this.m_TransactionContainer.BeginTransaction();
              ModelCurve modelCurve = RevitUtility.NewModelCurve(this.m_Document, intersectionStation2.IntersectionLeg.Arc);
              Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(this.m_Document, LandcaddID.IntersectionPlacement, ref _bDoesMassLineSubCategoryExist);
              if (componentLineSubCategory != null)
                ((CurveElement) modelCurve).LineStyle = (Element) componentLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
              if (this.m_DeleteElementSet == null)
                this.m_DeleteElementSet = new ElementSet();
              this.m_DeleteElementSet.Insert((Element) modelCurve);
              this.m_TransactionContainer.EndTransaction();
            }
            else if (intersectionStation2.IntersectionLeg.Line != null)
            {
              EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(intersectionStation2.IntersectionLeg.Line.EndPnt, intersectionStation2.IntersectionLeg.Line.StartPnt, ref epsPoint);
              this.m_IntersectionPointList.Add(epsPoint);
            }
          }
        }
        else
          this.m_IntersectionPointList.Add(intersectionStation2.InvalidIntersectionPnt);
      }
    }
    this.m_Document.Regenerate();
  }

  private void SetupString()
  {
    this.m_FormatOptions = this.m_Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_Document.DisplayUnitSystem;
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_Document.GetUnits().DecimalSymbol;
    this.Text = EPShared.LocalRM.GetString("ChangeRadiusDialogTitle");
    this.m_RadiusGroupBox.Text = EPShared.LocalRM.GetString("RadiusSettingsGroupTitle");
    this.m_CurrentRadiusLbl.Text = EPShared.LocalRM.GetString("AMP_CurrentRadiusDialog");
    this.m_CurrentRadiusValueLbl.Text = EPShared.LocalRM.GetString("NotAvailableString");
    this.m_NewRadiusLbl.Text = EPShared.LocalRM.GetString("AMP_NewRadiusDialog");
    this.m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.m_FinishButton.Text = EPShared.LocalRM.GetString("AMP_FinishDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_EditRadiusButton.Text = EPShared.LocalRM.GetString("AMP_Select");
    this.m_ApplyButton.Enabled = false;
    this.m_NewRadiusTextBox.Enabled = false;
  }

  private void OnNewRadiusKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatNewRadiusValue();
  }

  private void OnNewRadiusTextBoxLeave(object sender, EventArgs e) => this.FormatNewRadiusValue();

  private void FormatNewRadiusValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_NewRadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      if (_dReturnedDouble < this.m_dMinimumRadius)
      {
        if (this.m_dMinimumRadius > 0.0)
        {
          int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusForStreetMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
        else
        {
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
        this.m_NewRadiusTextBox.SelectAll();
        this.m_NewRadiusTextBox.Focus();
      }
      else
      {
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
        this.m_NewRadiusTextBox.Text = empty;
      }
    }
    else
      this.m_NewRadiusTextBox.Focus();
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    if (this.m_DeleteElementSet != null && this.m_DeleteElementSet.Size > 0)
    {
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_DeleteElementSet));
      this.m_DeleteElementSet = (ElementSet) null;
    }
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnFinishButtonClicked(object sender, EventArgs e)
  {
    TopographySurfaceManagement.GetIntersectionProfiles(this.m_CurLocateType, this.m_LeftExistingOffsetLeg, this.m_RightExistingOffsetLeg, this.m_RightOffsetLeg, this.m_dExistingAdjustSubgradeElev, this.m_bIsFirstIntersectionFourWay, TopographySurfaceManagement.GetIntersectionProfiles(this.m_CurLocateType, this.m_LeftExistingOffsetLeg, this.m_RightExistingOffsetLeg, this.m_LeftOffsetLeg, this.m_dExistingAdjustSubgradeElev, this.m_bIsFirstIntersectionFourWay, this.m_RightIntersectionStations, ref this.m_LeftIntersectionStations), this.m_LeftIntersectionStations, ref this.m_RightIntersectionStations);
    if (this.m_DeleteElementSet != null && this.m_DeleteElementSet.Size > 0)
    {
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_DeleteElementSet));
      this.m_DeleteElementSet = (ElementSet) null;
    }
    this.m_IntersectionPointList.Clear();
    foreach (IntersectionStationContainer intersectionStation1 in this.m_RightIntersectionStations)
    {
      foreach (IntersectionStation intersectionStation2 in intersectionStation1.IntersectionStations)
      {
        if (intersectionStation2.InvalidIntersectionPnt != null)
          this.m_IntersectionPointList.Add(intersectionStation2.InvalidIntersectionPnt);
      }
    }
    foreach (IntersectionStationContainer intersectionStation3 in this.m_LeftIntersectionStations)
    {
      foreach (IntersectionStation intersectionStation4 in intersectionStation3.IntersectionStations)
      {
        if (intersectionStation4.InvalidIntersectionPnt != null)
          this.m_IntersectionPointList.Add(intersectionStation4.InvalidIntersectionPnt);
      }
    }
    if (this.m_IntersectionPointList.Count > 0)
      this.DialogResult = DialogResult.Retry;
    else
      this.DialogResult = DialogResult.OK;
  }

  private void OnApplyButtonClicked(object sender, EventArgs e)
  {
    bool flag = true;
    double _dReturnedDouble = 0.0;
    if (this.m_NewRadiusTextBox.Text != string.Empty && RevitGeometry.Units_ConvertStringToDouble(this.m_NewRadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble) && _dReturnedDouble >= this.m_dMinimumRadius)
      flag = false;
    if (flag)
    {
      if (this.m_dMinimumRadius > 0.0)
      {
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusForStreetMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    else
    {
      try
      {
        if (this.m_InvalidLegSegmentPoint != null && this.m_IntersectionPointList.Remove(this.m_InvalidLegSegmentPoint))
          this.m_InvalidLegSegmentPoint = (Eps_Point) null;
        if (this.m_bRightSide)
        {
          if (this.m_nIntersectionStationContainerIndex >= 0 && this.m_nIntersectionStationIndex >= 0 && this.m_nIntersectionStationContainerIndex < this.m_RightIntersectionStations.Count && this.m_nIntersectionStationIndex < this.m_RightIntersectionStations[this.m_nIntersectionStationContainerIndex].IntersectionStations.Count)
            this.m_RightIntersectionStations[this.m_nIntersectionStationContainerIndex].IntersectionStations[this.m_nIntersectionStationIndex].Radius = _dReturnedDouble;
        }
        else if (this.m_nIntersectionStationContainerIndex >= 0 && this.m_nIntersectionStationIndex >= 0 && this.m_nIntersectionStationContainerIndex < this.m_LeftIntersectionStations.Count && this.m_nIntersectionStationIndex < this.m_LeftIntersectionStations[this.m_nIntersectionStationContainerIndex].IntersectionStations.Count)
          this.m_LeftIntersectionStations[this.m_nIntersectionStationContainerIndex].IntersectionStations[this.m_nIntersectionStationIndex].Radius = _dReturnedDouble;
        if (this.m_bRightSide)
        {
          TopographySurfaceManagement.GetIntersectionProfiles(this.m_CurLocateType, this.m_LeftExistingOffsetLeg, this.m_RightExistingOffsetLeg, this.m_RightOffsetLeg, this.m_dExistingAdjustSubgradeElev, this.m_bIsFirstIntersectionFourWay, this.m_nIntersectionStationContainerIndex, this.m_nIntersectionStationIndex, this.m_LeftIntersectionStations, ref this.m_RightIntersectionStations);
          this.m_InvalidLegSegmentPoint = this.m_RightIntersectionStations[this.m_nIntersectionStationContainerIndex].IntersectionStations[this.m_nIntersectionStationIndex].InvalidIntersectionPnt;
        }
        else
        {
          TopographySurfaceManagement.GetIntersectionProfiles(this.m_CurLocateType, this.m_LeftExistingOffsetLeg, this.m_RightExistingOffsetLeg, this.m_LeftOffsetLeg, this.m_dExistingAdjustSubgradeElev, this.m_bIsFirstIntersectionFourWay, this.m_nIntersectionStationContainerIndex, this.m_nIntersectionStationIndex, this.m_RightIntersectionStations, ref this.m_LeftIntersectionStations);
          this.m_InvalidLegSegmentPoint = this.m_LeftIntersectionStations[this.m_nIntersectionStationContainerIndex].IntersectionStations[this.m_nIntersectionStationIndex].InvalidIntersectionPnt;
        }
        this.DialogResult = DialogResult.Ignore;
      }
      catch (Exception ex)
      {
      }
    }
  }

  private string CalculateDisplayValue(string _strValue)
  {
    double _dConvertedDouble = 0.0;
    string _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
    if (_strValue != string.Empty)
      _dConvertedDouble = RevitGeometry.ConvertLinearValue(ValueConversion.ToDouble(_strValue), (DisplayUnitType) 3, this.m_FormatOptions.DisplayUnits);
    if (_dConvertedDouble >= 0.0)
      RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
    return _strToDisplay;
  }

  private void OnEditArcClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.m_ApplyButton.Enabled = true;
    this.m_NewRadiusTextBox.Enabled = true;
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  private void OnFormLoad(object sender, EventArgs e) => this.OverrideKeyUp();

  public void SetNewRadius(double _dNewRadius)
  {
    this.m_NewRadiusTextBox.Text = this.CalculateDisplayValue(_dNewRadius.ToString());
    this.m_CurrentRadiusValueLbl.Text = this.m_NewRadiusTextBox.Text;
  }

  public List<IntersectionStationContainer> LeftIntersectionStations
  {
    get => this.m_LeftIntersectionStations;
    set => this.m_LeftIntersectionStations = value;
  }

  public List<IntersectionStationContainer> RightIntersectionStations
  {
    get => this.m_RightIntersectionStations;
    set => this.m_RightIntersectionStations = value;
  }

  public List<Eps_Point> MidPointList => this.m_IntersectionPointList;

  public bool RightSide
  {
    get => this.m_bRightSide;
    set => this.m_bRightSide = value;
  }

  public int IntersectStationContainerIndex
  {
    get => this.m_nIntersectionStationContainerIndex;
    set => this.m_nIntersectionStationContainerIndex = value;
  }

  public int IntersectStationIndex
  {
    get => this.m_nIntersectionStationIndex;
    set => this.m_nIntersectionStationIndex = value;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_RadiusGroupBox = new GroupBox();
    this.m_NewRadiusTextBox = new TextBox();
    this.m_CurrentRadiusValueLbl = new Label();
    this.m_ApplyButton = new Button();
    this.m_EditRadiusButton = new Button();
    this.m_NewRadiusLbl = new Label();
    this.m_CurrentRadiusLbl = new Label();
    this.m_FinishButton = new Button();
    this.m_CancelButton = new Button();
    this.m_RadiusGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_FinishButton);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_CancelButton);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_NewRadiusTextBox);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_CurrentRadiusValueLbl);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_ApplyButton);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_EditRadiusButton);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_NewRadiusLbl);
    this.m_RadiusGroupBox.Controls.Add((Control) this.m_CurrentRadiusLbl);
    this.m_RadiusGroupBox.Location = new Point(12, 12);
    this.m_RadiusGroupBox.Name = "m_RadiusGroupBox";
    this.m_RadiusGroupBox.Size = new Size(334, 101);
    this.m_RadiusGroupBox.TabIndex = 0;
    this.m_RadiusGroupBox.TabStop = false;
    this.m_RadiusGroupBox.Text = "Radius Settings";
    this.m_NewRadiusTextBox.Location = new Point(113, 45);
    this.m_NewRadiusTextBox.Name = "m_NewRadiusTextBox";
    this.m_NewRadiusTextBox.Size = new Size(137, 20);
    this.m_NewRadiusTextBox.TabIndex = 3;
    this.m_NewRadiusTextBox.KeyDown += new KeyEventHandler(this.OnNewRadiusKeyDown);
    this.m_NewRadiusTextBox.Leave += new EventHandler(this.OnNewRadiusTextBoxLeave);
    this.m_CurrentRadiusValueLbl.AutoSize = true;
    this.m_CurrentRadiusValueLbl.Location = new Point(110, 19);
    this.m_CurrentRadiusValueLbl.Name = "m_CurrentRadiusValueLbl";
    this.m_CurrentRadiusValueLbl.Size = new Size(27, 13);
    this.m_CurrentRadiusValueLbl.TabIndex = 1;
    this.m_CurrentRadiusValueLbl.Text = "N/A";
    this.m_ApplyButton.Location = new Point(253, 43);
    this.m_ApplyButton.Name = "m_ApplyButton";
    this.m_ApplyButton.Size = new Size(75, 23);
    this.m_ApplyButton.TabIndex = 5;
    this.m_ApplyButton.Text = "Apply";
    this.m_ApplyButton.UseVisualStyleBackColor = true;
    this.m_ApplyButton.Click += new EventHandler(this.OnApplyButtonClicked);
    this.m_EditRadiusButton.Location = new Point(253, 14);
    this.m_EditRadiusButton.Name = "m_EditRadiusButton";
    this.m_EditRadiusButton.Size = new Size(75, 23);
    this.m_EditRadiusButton.TabIndex = 4;
    this.m_EditRadiusButton.UseVisualStyleBackColor = true;
    this.m_EditRadiusButton.Click += new EventHandler(this.OnEditArcClicked);
    this.m_NewRadiusLbl.AutoSize = true;
    this.m_NewRadiusLbl.Location = new Point(6, 48 /*0x30*/);
    this.m_NewRadiusLbl.Name = "m_NewRadiusLbl";
    this.m_NewRadiusLbl.Size = new Size(65, 13);
    this.m_NewRadiusLbl.TabIndex = 2;
    this.m_NewRadiusLbl.Text = "New Radius";
    this.m_CurrentRadiusLbl.AutoSize = true;
    this.m_CurrentRadiusLbl.Location = new Point(6, 19);
    this.m_CurrentRadiusLbl.Name = "m_CurrentRadiusLbl";
    this.m_CurrentRadiusLbl.Size = new Size(77, 13);
    this.m_CurrentRadiusLbl.TabIndex = 0;
    this.m_CurrentRadiusLbl.Text = "Current Radius";
    this.m_FinishButton.Location = new Point(172, 72);
    this.m_FinishButton.Name = "m_FinishButton";
    this.m_FinishButton.Size = new Size(75, 23);
    this.m_FinishButton.TabIndex = 6;
    this.m_FinishButton.Text = "Done";
    this.m_FinishButton.UseVisualStyleBackColor = true;
    this.m_FinishButton.Click += new EventHandler(this.OnFinishButtonClicked);
    this.m_CancelButton.Location = new Point(253, 72);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 7;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClicked);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(358, 125);
    this.Controls.Add((Control) this.m_RadiusGroupBox);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ChangeIntersectionRadiusForm);
    this.Text = nameof (ChangeIntersectionRadiusForm);
    this.Load += new EventHandler(this.OnFormLoad);
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.m_RadiusGroupBox.ResumeLayout(false);
    this.m_RadiusGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ApplyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
