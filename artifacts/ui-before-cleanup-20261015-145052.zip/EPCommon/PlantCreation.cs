using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;

namespace EPCommon;

public class PlantCreation
{
	private Document m_Document;

	private List<Autodesk.Revit.DB.View> m_ViewList;

	private PlacePlantForm m_DisplayForm;

	private List<TopographySurfaceContainer> m_SurfaceList;

	private List<FamilyContainer> m_PlantFamilyList;

	private FamilySymbol m_PlantingPlacementSymbol;

	private EPTransactionContainer m_TransactionContainer;

	private List<Element> m_CurrentElementList;

	public ReadOnlyCollection<Autodesk.Revit.DB.View> Views => new ReadOnlyCollection<Autodesk.Revit.DB.View>(m_ViewList);

	public Document Document => m_Document;

	public ReadOnlyCollection<FamilyContainer> PlantFamilyList => new ReadOnlyCollection<FamilyContainer>(m_PlantFamilyList);

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public List<Element> CurrentElementList => m_CurrentElementList;

	public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList => new ReadOnlyCollection<TopographySurfaceContainer>(m_SurfaceList);

	public PlantCreation(Document _CurDocument)
	{
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_ViewList = new List<Autodesk.Revit.DB.View>();
		m_SurfaceList = new List<TopographySurfaceContainer>();
		m_PlantFamilyList = new List<FamilyContainer>();
		InitializeListData();
	}

	public void PopulateFamilyAndSymbolLists()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: false);
	}

	private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
	{
		int num = 0;
		m_PlantFamilyList.Clear();
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		FilteredElementIterator elementIterator = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_Planting).GetElementIterator();
		filteredElementCollector = new FilteredElementCollector(m_Document);
		m_CurrentElementList = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements()
			.ToList();
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
		Eps_Point eps_Point = new Eps_Point();
		FamilySymbol familySymbol = null;
		FamilyInstance familyInstance = null;
		List<Eps_Point> list = null;
		LocationPoint locationPoint = null;
		Eps_Point eps_Point2 = null;
		elementIterator.Reset();
		while (elementIterator.MoveNext())
		{
			if (!(elementIterator.Current is FamilySymbol { Category: not null } familySymbol2) || familySymbol2.Category.Id.Value64() != BuiltInCategory.OST_Planting.GetHashCode())
			{
				continue;
			}
			list = null;
			foreach (Element currentElement in m_CurrentElementList)
			{
				if (currentElement is FamilyInstance { Symbol: not null } familyInstance2 && familyInstance2.Symbol.Category != null && familyInstance2.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(familySymbol2.UniqueId, familyInstance2.Symbol.UniqueId, ignoreCase: true) == 0)
				{
					if (list == null)
					{
						list = new List<Eps_Point>();
					}
					locationPoint = familyInstance2.Location as LocationPoint;
					eps_Point2 = new Eps_Point(locationPoint.Point);
					if (!RevitUtility.IsPointInPointList(eps_Point2, list))
					{
						list.Add(eps_Point2);
					}
				}
			}
			if (list != null && list.Count > 0)
			{
				bool flag = true;
				while (flag)
				{
					flag = false;
					for (int i = 0; i < list.Count; i++)
					{
						if (EPShared.eplGeoE_ArePntsDuplicates3D(list[i], eps_Point))
						{
							eps_Point.z++;
							flag = true;
							break;
						}
					}
				}
			}
			bool flag2 = false;
			for (num = 0; num < m_PlantFamilyList.Count; num++)
			{
				if (string.Compare(m_PlantFamilyList[num].FamilyName, familySymbol2.Family.Name, ignoreCase: true) == 0)
				{
					m_PlantFamilyList[num].FamilySymbolList.Add(familySymbol2);
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				FamilyContainer familyContainer = new FamilyContainer(familySymbol2.Family.Name);
				familyContainer.FamilySymbolList.Add(familySymbol2);
				m_PlantFamilyList.Add(familyContainer);
			}
		}
		m_TransactionContainer.Rollback();
		filteredElementCollector = new FilteredElementCollector(m_Document);
		elementIterator = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_PlantingTags).GetElementIterator();
		bool flag3 = false;
		elementIterator.Reset();
		while (elementIterator.MoveNext())
		{
			if (elementIterator.Current is FamilySymbol { Category: not null } familySymbol3 && familySymbol3.Category.Id.Value64() == BuiltInCategory.OST_PlantingTags.GetHashCode())
			{
				flag3 = true;
				break;
			}
		}
		bool flag4 = true;
		filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel);
		Parameter CurLanddCadID = null;
		IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0);
		List<Element> list2 = source.ToList();
		flag4 = false;
		FamilySymbol familySymbol4 = null;
		foreach (Element item in list2)
		{
			if (item is FamilySymbol { Category: not null } familySymbol5)
			{
				CurLanddCadID = familySymbol5.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
				if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0)
				{
					m_PlantingPlacementSymbol = familySymbol5;
					flag4 = true;
					break;
				}
			}
		}
		string _strFullFamilyFilename = string.Empty;
		if (_bCheckForFamily && (m_PlantFamilyList.Count == 0 || !flag3 || !flag4))
		{
			List<string> list3 = new List<string>();
			list3.Add(EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"));
			list3.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, "PlacePlant", EPShared.LocalRM.GetString("PlantingTagFamiliesNotLoadedMessage"), list3);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), ignoreCase: true) == 0)
			{
				Family _Family = null;
				if (m_PlantFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Conifer", "LC Conifers.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId in _Family.GetFamilySymbolIds())
						{
							if (!(m_Document.GetElement(familySymbolId) is FamilySymbol familySymbol6))
							{
								continue;
							}
							bool flag5 = false;
							for (num = 0; num < m_PlantFamilyList.Count; num++)
							{
								if (string.Compare(m_PlantFamilyList[num].FamilyName, familySymbol6.Family.Name, ignoreCase: true) == 0)
								{
									m_PlantFamilyList[num].FamilySymbolList.Add(familySymbol6);
									flag5 = true;
									break;
								}
							}
							if (!flag5)
							{
								FamilyContainer familyContainer2 = new FamilyContainer(familySymbol6.Family.Name);
								familyContainer2.FamilySymbolList.Add(familySymbol6);
								m_PlantFamilyList.Add(familyContainer2);
							}
						}
					}
				}
				if (!flag3 && RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Tags", "LC Plant Tags - Single Line.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantingTagFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
				}
				if (!flag4 && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						using IEnumerator<ElementId> enumerator4 = _Family.GetFamilySymbolIds().GetEnumerator();
						if (enumerator4.MoveNext())
						{
							ElementId current4 = enumerator4.Current;
							if (m_Document.GetElement(current4) is FamilySymbol plantingPlacementSymbol)
							{
								m_PlantingPlacementSymbol = plantingPlacementSymbol;
							}
						}
					}
				}
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		for (num = 0; num < m_PlantFamilyList.Count; num++)
		{
			m_PlantFamilyList[num].FamilySymbolList.Sort(comparer);
		}
	}

	private void InitializeListData()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: true);
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(Autodesk.Revit.DB.View)).ToElements();
		foreach (Autodesk.Revit.DB.View item in list)
		{
			if (item.GenLevel == null || m_ViewList.Contains(item) || (item.ViewType != ViewType.FloorPlan && item.ViewType != ViewType.EngineeringPlan && item.ViewType != ViewType.AreaPlan) || string.Compare(item.Name, EPShared.LocalRM.GetString("SiteString"), ignoreCase: true) == 0)
			{
				continue;
			}
			bool flag = false;
			for (int i = 0; i < m_ViewList.Count; i++)
			{
				if (string.Compare(m_ViewList[i].GenLevel.UniqueId, item.GenLevel.UniqueId, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				m_ViewList.Add(item);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list2 = filteredElementCollector.OfClass(typeof(TopographySurface)).OfCategory(BuiltInCategory.OST_Topography).ToElements();
		foreach (Element item2 in list2)
		{
			TopographySurface topographySurface = item2 as TopographySurface;
			m_SurfaceList.Add(new TopographySurfaceContainer(m_Document.Application, topographySurface));
		}
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		bool flag = false;
		if (m_PlantFamilyList.Count <= 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new PlacePlantForm(this))
		{
			while (_DialogResult == DialogResult.OK)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult != DialogResult.OK)
		{
			return false;
		}
		List<TopographySurfaceContainer> list = new List<TopographySurfaceContainer>();
		if (m_DisplayForm.PickToposurface)
		{
			list.Add(m_DisplayForm.Surface);
		}
		PlacementSettings placementSettings = new PlacementSettings(LocateType.Plant, m_DisplayForm.PlacementType, m_DisplayForm.DeleteExistingChecked, m_DisplayForm.ExistingElementChecked, m_DisplayForm.PlaceGroupTagChecked, m_DisplayForm.Level, m_DisplayForm.View, m_DisplayForm.Type, list, m_DisplayForm.SetbackSpacing, m_DisplayForm.PlantHeight, m_DisplayForm.HeightVariance, m_DisplayForm.PlantWidth, m_DisplayForm.WidthVariance, m_DisplayForm.PlantSpacing, m_DisplayForm.RotationAngle, m_DisplayForm.StartingDistance, m_PlantingPlacementSymbol, m_TransactionContainer);
		placementSettings.LeaderedTagChecked = m_DisplayForm.LeaderedTagChecked;
		ElementSet _Elements = null;
		string strPrompt = string.Empty;
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlantsTransaction"));
		List<FailureDefinitionId> list2 = new List<FailureDefinitionId>();
		list2.Add(BuiltInFailures.InaccurateFailures.InaccurateLine);
		if (m_DisplayForm.PlaceGroupTagChecked)
		{
			list2.Add(BuiltInFailures.GroupFailures.AtomViolationWhenOnePlaceInstance);
		}
		m_TransactionContainer.FailureHandlingOptions(list2);
		if (!m_DisplayForm.ExistingElementChecked)
		{
			if (m_DisplayForm.GroveChecked)
			{
				strPrompt = EPShared.LocalRM.GetString("PickPointsForBoundaryPrompt");
			}
			else if (m_DisplayForm.HedgeRowChecked)
			{
				strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
			}
			else if (m_DisplayForm.SingleChecked)
			{
				strPrompt = EPShared.LocalRM.GetString("PickPointPrompt");
			}
			ElementSet elementSet = new ElementSet();
			ElementSet elementSet2 = new ElementSet();
			FamilyInstance familyInstance = null;
			List<ModelCurve> list3 = new List<ModelCurve>();
			Eps_Leg eps_Leg = null;
			Eps_Leg eps_Leg2 = null;
			Eps_Point _Point = null;
			Eps_Point eps_Point = null;
			bool flag = true;
			while (flag)
			{
				flag = RevitUtility.GetPointFromProject(m_Document, strPrompt, ref _Point, _bDisplayError: false);
				if (flag)
				{
					if (m_DisplayForm.SingleChecked)
					{
						familyInstance = PlantCommon.PlaceSingleOnPoint(m_Document, placementSettings, null, _Point, _bCreateTag: false);
						elementSet2.Insert(familyInstance);
						if (m_DisplayForm.SegmentChecked)
						{
							flag = false;
						}
					}
					else if (eps_Point != null)
					{
						eps_Leg2 = new Eps_Leg();
						eps_Leg2.Line = new Eps_Line();
						eps_Leg2.Line.StartPnt = eps_Point;
						eps_Leg2.Line.EndPnt = _Point;
						if (eps_Leg == null)
						{
							eps_Leg = Eps_Leg.SingleLeg(eps_Leg2);
						}
						else
						{
							eps_Leg.Last.Next = Eps_Leg.SingleLeg(eps_Leg2);
						}
						m_TransactionContainer.BeginTransaction();
						list3.Add(RevitUtility.NewModelCurve(m_Document, eps_Leg2.Line));
						m_TransactionContainer.EndTransaction();
						if (m_DisplayForm.SegmentChecked)
						{
							flag = false;
						}
					}
					else if (m_DisplayForm.HedgeRowChecked)
					{
						strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
					}
					eps_Point = _Point;
				}
				m_Document.Regenerate();
			}
			if (eps_Leg != null && eps_Leg.Next != null && m_DisplayForm.GroveChecked && !EPShared.eplGeoE_ArePntsDuplicates2D(eps_Leg.LegStartPnt, eps_Leg.LegEndPnt, 1E-05))
			{
				eps_Leg2 = new Eps_Leg();
				eps_Leg2.Line = new Eps_Line();
				eps_Leg2.Line.StartPnt = eps_Leg.LegEndPnt;
				eps_Leg2.Line.EndPnt = eps_Leg.LegStartPnt;
				eps_Leg.Last.Next = Eps_Leg.SingleLeg(eps_Leg2);
				m_TransactionContainer.BeginTransaction();
				list3.Add(RevitUtility.NewModelCurve(m_Document, eps_Leg2.Line));
				m_TransactionContainer.EndTransaction();
			}
			for (int i = 0; i < list3.Count; i++)
			{
				elementSet.Insert(list3[i]);
			}
			bool result = true;
			if (eps_Leg != null)
			{
				result = PlantCommon.PlaceLegList(m_Document, placementSettings, eps_Leg);
			}
			m_TransactionContainer.BeginTransaction();
			m_Document.Delete(ElementSetConverter.ToIDList(elementSet));
			m_TransactionContainer.EndTransaction();
			return result;
		}
		if (!RevitUtility.GetElementsFromProject(_strPrompt: (!m_DisplayForm.GroveChecked) ? EPShared.LocalRM.GetString("PickObjectMessage") : EPShared.LocalRM.GetString("PickClosedBoundaryMessage"), _Document: m_Document, _Elements: ref _Elements))
		{
			return false;
		}
		foreach (Element item5 in _Elements)
		{
			LocationCurve locationCurve = item5.Location as LocationCurve;
			Curve curve = null;
			if (locationCurve != null)
			{
				curve = locationCurve.Curve;
			}
			if (curve != null)
			{
				Eps_Leg eps_Leg3 = null;
				if (locationCurve != null && m_DisplayForm.ChainChecked)
				{
					eps_Leg3 = RevitGeometry.GetLegFromElementList(null, item5);
				}
				if (eps_Leg3 != null)
				{
					double dY = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, dY))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					return PlantCommon.PlaceLegList(m_Document, placementSettings, eps_Leg3);
				}
				if (curve is Arc)
				{
					Arc arc = (Arc)curve;
					if (m_DisplayForm.SingleChecked)
					{
						Eps_Point _StaOffPnt = new Eps_Point();
						if (!arc.IsBound)
						{
							_StaOffPnt = new Eps_Point(arc.Center);
						}
						else
						{
							EPShared.eplGeoE_FindStaOffPointAlongArc(new Eps_Arc(arc), arc.Length / 2.0, 0.0, ref _StaOffPnt);
						}
						PlantCommon.PlaceSingleOnPoint(m_Document, placementSettings, item5, _StaOffPnt);
					}
					else if (m_DisplayForm.GroveChecked)
					{
						if (arc.IsBound)
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return false;
						}
						eps_Leg3 = new Eps_Leg();
						eps_Leg3.Arc = new Eps_Arc(arc);
						List<Eps_Leg> _IslandList = new List<Eps_Leg>();
						PlantCommon.PickIslandLegs(m_Document, ref _IslandList);
						PlantCommon.PlaceHedgeGrove(m_Document, placementSettings, eps_Leg3, _IslandList);
						if (m_DisplayForm.DeleteExistingChecked)
						{
							m_TransactionContainer.BeginTransaction();
							for (int j = 0; j < _IslandList.Count; j++)
							{
								if (_IslandList[j].ElementSet != null && _IslandList[j].ElementSet.Size > 0)
								{
									m_Document.Delete(ElementSetConverter.ToIDList(_IslandList[j].ElementSet));
								}
							}
							m_TransactionContainer.EndTransaction();
						}
					}
					else if (m_DisplayForm.HedgeRowChecked)
					{
						if (RevitDefines.GT(m_DisplayForm.StartingDistance, curve.Length))
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return false;
						}
						Eps_Arc _EvalArc = new Eps_Arc(arc);
						if (!RevitUtility.EvaluateArc(m_Document, m_TransactionContainer, m_DisplayForm.PlantSpacing, ref _EvalArc))
						{
							return false;
						}
						placementSettings.IsReverse = _EvalArc.IsReverse;
						if (m_DisplayForm.CenteredHedgeRowChecked)
						{
							PlantCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _EvalArc);
						}
						else if (m_DisplayForm.AlternateHedgeRowChecked)
						{
							PlantCommon.PlaceAltRowOnArc(m_Document, placementSettings, item5, _EvalArc);
						}
						else
						{
							Eps_Arc _OffsetArc = new Eps_Arc();
							EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, m_DisplayForm.SetbackSpacing, 1, ref _OffsetArc);
							Eps_Arc _OffsetArc2 = new Eps_Arc();
							EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, m_DisplayForm.SetbackSpacing, 2, ref _OffsetArc2);
							ElementSet elementSet3 = new ElementSet();
							if (_OffsetArc.Radius > 0.0)
							{
								m_TransactionContainer.BeginTransaction();
								ModelCurve item = RevitUtility.NewModelCurve(m_Document, _OffsetArc);
								m_TransactionContainer.EndTransaction();
								elementSet3.Insert(item);
							}
							if (_OffsetArc2.Radius > 0.0)
							{
								m_TransactionContainer.BeginTransaction();
								ModelCurve item2 = RevitUtility.NewModelCurve(m_Document, _OffsetArc2);
								m_TransactionContainer.EndTransaction();
								elementSet3.Insert(item2);
							}
							bool _UseRightSide = true;
							bool flag2 = RevitUtility.PickSideArc(m_Document, _EvalArc, ref _UseRightSide);
							m_TransactionContainer.BeginTransaction();
							m_Document.Delete(ElementSetConverter.ToIDList(elementSet3));
							m_TransactionContainer.EndTransaction();
							if (!flag2)
							{
								return false;
							}
							placementSettings.UseRightSide = _UseRightSide;
							if (_UseRightSide)
							{
								PlantCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _OffsetArc);
							}
							else
							{
								PlantCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _OffsetArc2);
							}
						}
					}
				}
				else if (curve is Line)
				{
					if (m_DisplayForm.SingleChecked)
					{
						Eps_Point _MidPoint = new Eps_Point();
						EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(new Eps_Point(curve.GetEndPoint(0)), new Eps_Point(curve.GetEndPoint(1)), ref _MidPoint);
						PlantCommon.PlaceSingleOnPoint(m_Document, placementSettings, item5, _MidPoint);
					}
					else
					{
						if (m_DisplayForm.GroveChecked)
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return false;
						}
						if (m_DisplayForm.HedgeRowChecked)
						{
							if (RevitDefines.GT(m_DisplayForm.StartingDistance, curve.Length))
							{
								RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
								return false;
							}
							Eps_Line _EvalLine = new Eps_Line();
							_EvalLine.StartPnt = new Eps_Point(curve.GetEndPoint(0));
							_EvalLine.EndPnt = new Eps_Point(curve.GetEndPoint(1));
							if (!RevitUtility.EvaluateLine(m_Document, m_TransactionContainer, m_DisplayForm.PlantSpacing, ref _EvalLine))
							{
								return false;
							}
							placementSettings.IsReverse = _EvalLine.IsReverse;
							if (m_DisplayForm.CenteredHedgeRowChecked)
							{
								PlantCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _EvalLine);
							}
							else if (m_DisplayForm.AlternateHedgeRowChecked)
							{
								PlantCommon.PlaceAltRowOnLine(m_Document, placementSettings, item5, _EvalLine);
							}
							else
							{
								Eps_Line _OffsetLine = new Eps_Line();
								EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, m_DisplayForm.SetbackSpacing, 1, ref _OffsetLine);
								Eps_Line _OffsetLine2 = new Eps_Line();
								EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, m_DisplayForm.SetbackSpacing, 2, ref _OffsetLine2);
								m_TransactionContainer.BeginTransaction();
								ModelCurve item3 = RevitUtility.NewModelCurve(m_Document, _OffsetLine);
								ModelCurve item4 = RevitUtility.NewModelCurve(m_Document, _OffsetLine2);
								m_TransactionContainer.EndTransaction();
								m_Document.Regenerate();
								bool _UseRightSide2 = true;
								bool flag3 = RevitUtility.PickSideLine(m_Document, _EvalLine, ref _UseRightSide2);
								ElementSet elementSet4 = new ElementSet();
								elementSet4.Insert(item3);
								elementSet4.Insert(item4);
								m_TransactionContainer.BeginTransaction();
								m_Document.Delete(ElementSetConverter.ToIDList(elementSet4));
								m_TransactionContainer.EndTransaction();
								if (!flag3)
								{
									return false;
								}
								placementSettings.UseRightSide = _UseRightSide2;
								if (_UseRightSide2)
								{
									PlantCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _OffsetLine);
								}
								else
								{
									PlantCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _OffsetLine2);
								}
							}
						}
					}
				}
				else
				{
					if (!(curve is Ellipse) && !(curve is NurbSpline) && !(curve is HermiteSpline))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedPlantingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					if (m_DisplayForm.SingleChecked && curve is Ellipse && !curve.IsBound)
					{
						Ellipse ellipse = (Ellipse)curve;
						PlantCommon.PlaceSingleOnPoint(m_Document, placementSettings, item5, new Eps_Point(ellipse.Center));
					}
					else
					{
						IList<XYZ> list4 = curve.Tessellate();
						int count = list4.Count;
						if (count > 1)
						{
							int num = 0;
							Eps_Point startPnt = new Eps_Point();
							Eps_Point eps_Point2 = new Eps_Point();
							eps_Leg3 = null;
							Eps_Leg eps_Leg4 = null;
							for (num = 0; num < count; num += 2)
							{
								eps_Point2 = new Eps_Point(list4[num]);
								if (num > 0)
								{
									eps_Leg4 = new Eps_Leg();
									eps_Leg4.Line = new Eps_Line();
									eps_Leg4.Line.StartPnt = startPnt;
									eps_Leg4.Line.EndPnt = eps_Point2;
									if (eps_Leg3 == null)
									{
										eps_Leg3 = eps_Leg4;
										eps_Leg3.Element = item5;
									}
									else
									{
										eps_Leg3.Last.Next = eps_Leg4;
										eps_Leg3.Last.Element = item5;
									}
								}
								startPnt = eps_Point2;
							}
							if (num == count)
							{
								eps_Leg4 = new Eps_Leg();
								eps_Leg4.Line = new Eps_Line();
								eps_Leg4.Line.StartPnt = startPnt;
								eps_Leg4.Line.EndPnt = new Eps_Point(list4[count - 1]);
								if (eps_Leg3 == null)
								{
									eps_Leg3 = eps_Leg4;
									eps_Leg3.Element = item5;
								}
								else
								{
									eps_Leg3.Last.Next = eps_Leg4;
									eps_Leg3.Last.Element = item5;
								}
							}
						}
						double dY2 = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
						if (RevitDefines.GT(m_DisplayForm.StartingDistance, dY2))
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return false;
						}
						if (!PlantCommon.PlaceLegList(m_Document, placementSettings, eps_Leg3))
						{
							return false;
						}
					}
				}
				if (m_DisplayForm.DeleteExistingChecked)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(item5.Id);
					m_TransactionContainer.EndTransaction();
				}
			}
			else
			{
				if (!(item5.Location is LocationPoint locationPoint))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedPlantingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				PlantCommon.PlaceSingleOnPoint(m_Document, placementSettings, item5, new Eps_Point(locationPoint.Point));
				if (m_DisplayForm.DeleteExistingChecked)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(item5.Id);
					m_TransactionContainer.EndTransaction();
				}
			}
		}
		return true;
	}
}
