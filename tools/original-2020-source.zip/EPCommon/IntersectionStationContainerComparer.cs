﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.IntersectionStationContainerComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class IntersectionStationContainerComparer : IComparer<IntersectionStationContainer>
{
  private bool m_bDecendingValues;
  private bool m_bCompareFirstStations = true;

  public IntersectionStationContainerComparer(bool _bCompareFirstStations)
  {
    this.m_bCompareFirstStations = _bCompareFirstStations;
  }

  int IComparer<IntersectionStationContainer>.Compare(
    IntersectionStationContainer first,
    IntersectionStationContainer second)
  {
    int num = 0;
    if (first != null && first.IntersectionStations != null && first.IntersectionStations.Count > 0)
      num = second == null || second.IntersectionStations == null || second.IntersectionStations.Count <= 0 ? -1 : (!this.m_bCompareFirstStations ? first.IntersectionStations[first.IntersectionStations.Count - 1].Station.CompareTo(second.IntersectionStations[second.IntersectionStations.Count - 1].Station) : first.IntersectionStations[0].Station.CompareTo(second.IntersectionStations[0].Station));
    else if (second != null && second.IntersectionStations != null && second.IntersectionStations.Count > 0)
      num = 1;
    if (this.m_bDecendingValues)
      num = -num;
    return num;
  }
}
