﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.TopoPoint
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class TopoPoint : Eps_Point
{
  private uint m_Number;

  public TopoPoint()
  {
  }

  public TopoPoint(Eps_Point _Point)
    : base(_Point)
  {
  }

  public TopoPoint(TopoPoint _Point)
    : base((Eps_Point) _Point)
  {
    this.m_Number = _Point.Number;
  }

  public TopoPoint(XYZ _XYZPoint)
    : base(_XYZPoint)
  {
  }

  public TopoPoint(double _dX, double _dY, double _dZ)
    : base(_dX, _dY, _dZ)
  {
  }

  public uint Number
  {
    get => this.m_Number;
    set => this.m_Number = value;
  }
}
