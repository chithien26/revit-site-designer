﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.CreatePlantMix
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class CreatePlantMix
{
  private Document m_Document;
  private List<FamilySymbol> m_ListOfInstance;
  private PlantMixForm m_PlantMixForm;
  private string m_strLandcaddID;
  private string m_strPlantOrPatioWalkText;
  private CreateDialogType m_CreateDialogType;
  private EPTransactionContainer m_TransactionContainer;

  public CreatePlantMix(CreateDialogType _CreateDialogType, Document _CurDocument)
  {
    this.m_CreateDialogType = _CreateDialogType;
    if (this.m_CreateDialogType == CreateDialogType.PlantMix)
    {
      this.m_strLandcaddID = Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
      this.m_strPlantOrPatioWalkText = EPShared.LocalRM.GetString("PlantMixMessage");
    }
    else
    {
      this.m_strLandcaddID = Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000");
      this.m_strPlantOrPatioWalkText = EPShared.LocalRM.GetString("PatioWalkString");
    }
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_ListOfInstance = new List<FamilySymbol>();
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    this.PopulateFamilySymbolList();
    if (this.m_ListOfInstance.Count == 0)
    {
      List<string> _WarningOptions = new List<string>();
      _WarningOptions.Add(EPShared.LocalRM.GetString("LoadDefaultFamilyOption"));
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string _strWarningText;
      string _strSearchFilename;
      if (this.m_CreateDialogType == CreateDialogType.PlantMix)
      {
        _strWarningText = EPShared.LocalRM.GetString("PlantMixFamilyNotLoadedMessage");
        _strSearchFilename = "Sample Plant Mix - Turf mix.rfa";
        _WarningOptions.Add(EPShared.LocalRM.GetString("LaunchPlantMixFamilyManagerOption"));
      }
      else
      {
        _strWarningText = EPShared.LocalRM.GetString("PatioWalkFamilyNotLoadedMessage");
        _strSearchFilename = "Sample Concrete Patio with Edging.rfa";
        _WarningOptions.Add(EPShared.LocalRM.GetString("LaunchPatioWalkFamilyManagerOption"));
      }
      _WarningOptions.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamilyOption"));
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(this.m_Document.PathName, Enum.GetName(typeof (CreateDialogType), (object) this.m_CreateDialogType.GetHashCode()).ToUpper(), _strWarningText, _WarningOptions);
      int num1 = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK)
      {
        if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamilyOption"), true) == 0)
        {
          Family _Family = (Family) null;
          string empty3 = string.Empty;
          if (RevitUtility.GetFullFamilyFilenameIfExist(_strSearchFilename, ref empty3))
          {
            if (this.m_CreateDialogType == CreateDialogType.PlantMix)
              this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantMixFamilyTransaction") + Path.GetFileName(empty3));
            else
              this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPatioWalkFamilyTransaction") + Path.GetFileName(empty3));
            RevitUtility.LoadFamily(this.m_Document, empty3, out _Family, true, ref this.m_TransactionContainer);
            this.m_TransactionContainer.Commit();
            if (_Family != null && _Family.GetFamilySymbolIds() != null)
            {
              foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
              {
                if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
                  this.m_ListOfInstance.Add(element);
              }
            }
          }
        }
        else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LaunchPlantMixFamilyManagerOption"), true) == 0 || string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LaunchPatioWalkFamilyManagerOption"), true) == 0)
        {
          DialogType _Type = DialogType.PlantMix;
          if (this.m_CreateDialogType == CreateDialogType.PatioWalk)
            _Type = DialogType.Patio;
          using (PlantMixFamilyManager mixFamilyManager = new PlantMixFamilyManager(_Type, this.m_Document))
          {
            int num2 = (int) mixFamilyManager.ShowDialog();
            this.PopulateFamilySymbolList();
          }
        }
      }
    }
    if (this.m_ListOfInstance.Count == 0)
    {
      int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    this.m_PlantMixForm = new PlantMixForm(this);
    int num4 = (int) this.m_PlantMixForm.ShowDialog();
    if (this.m_PlantMixForm.DialogResult != DialogResult.OK)
      return false;
    while (this.m_PlantMixForm.ApplyStatus)
    {
      if (this.SelectPlantMix(this.m_PlantMixForm.RegionName))
        this.m_TransactionContainer.Commit();
      else
        this.m_TransactionContainer.Rollback();
      this.m_PlantMixForm = new PlantMixForm(this);
      int num5 = (int) this.m_PlantMixForm.ShowDialog();
      if (this.m_PlantMixForm.DialogResult != DialogResult.OK)
        return false;
    }
    if (this.SelectPlantMix(this.m_PlantMixForm.RegionName))
      this.m_TransactionContainer.Commit();
    else
      this.m_TransactionContainer.Rollback();
    return true;
  }

  private bool SelectPlantMix(string _strRegionName)
  {
    string empty = string.Empty;
    List<Element> elementList = new List<Element>();
    Reference reference;
    try
    {
      reference = new UIDocument(this.m_Document).Selection.PickObject((ObjectType) 1, EPShared.LocalRM.GetString("PickRegionSubRegionMessage"));
    }
    catch (OperationCanceledException ex)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    if (reference != null && this.m_Document.GetElement(reference) != null)
    {
      Element element1 = this.m_Document.GetElement(reference);
      string strA = element1.Name;
      if (string.Compare(strA, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), true) == 0 || string.Compare(strA, EPShared.LocalRM.GetString("SubRegionElement"), true) == 0)
      {
        string uniqueId = element1.UniqueId;
        Parameter LandcaddIDParameter = (Parameter) null;
        FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
        source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151);
        FindFamilyInstance = (FamilyInstance) null;
        List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (LandcaddIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), this.m_strLandcaddID, true) == 0)).ToList<Element>();
        if (this.m_CreateDialogType == CreateDialogType.PlantMix)
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("AssignPlantMixTransaction"));
        else
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("AssignPatioWalkTransaction"));
        foreach (Element element2 in list)
        {
          if (element2 is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
          {
            LandcaddIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
            if (LandcaddIDParameter != null && string.Compare(LandcaddIDParameter.AsString(), this.m_strLandcaddID, true) == 0)
            {
              Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.RegionNameGenericModelFamilyParameter);
              if (parameter1 != null && this.m_PlantMixForm.AssignRegion && string.Compare(parameter1.AsString(), _strRegionName, true) == 0)
              {
                int num = (int) RevitMessageBox.Show($"{_strRegionName} {EPShared.LocalRM.GetString("_RegionNameAlreadyAssigned_Message")} {element1.Name}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
              if (parameter2 != null && string.Compare(parameter2.AsString(), uniqueId, true) == 0)
              {
                if (parameter1 != null)
                  strA = parameter1.AsString();
                if (this.m_PlantMixForm.AssignRegion)
                {
                  if (RevitMessageBox.Show($"{EPShared.LocalRM.GetString("OverWrite_Message")}{this.m_strPlantOrPatioWalkText}{EPShared.LocalRM.GetString("_AssignTo_Message")}{strA}?", EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
                    return false;
                  this.m_TransactionContainer.BeginTransaction();
                  this.m_Document.Delete(((Element) familyInstance).Id);
                  this.m_TransactionContainer.EndTransaction();
                }
                else
                {
                  if (RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Unassign_Message")}{this.m_strPlantOrPatioWalkText}{EPShared.LocalRM.GetString("_From_Message")}{strA}?", EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
                    return false;
                  this.m_TransactionContainer.BeginTransaction();
                  this.m_Document.Delete(((Element) familyInstance).Id);
                  this.m_TransactionContainer.EndTransaction();
                  return true;
                }
              }
            }
          }
        }
        if (this.m_PlantMixForm.AssignRegion)
        {
          FamilySymbol _FamilySymobl = this.m_PlantMixForm.SelectedFamilySymbol;
          if (_FamilySymobl == null)
          {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
              openFileDialog.Title = this.m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyNotLoaded_Message") + this.m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyFileMessage");
              openFileDialog.RestoreDirectory = true;
              openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
              bool flag = false;
              DialogResult dialogResult = DialogResult.OK;
              while (dialogResult != DialogResult.Cancel)
              {
                dialogResult = openFileDialog.ShowDialog();
                if (dialogResult != DialogResult.Cancel)
                {
                  try
                  {
                    flag = RevitUtility.LoadFamily(this.m_Document, openFileDialog.FileName, true, ref this.m_TransactionContainer);
                    break;
                  }
                  catch (SEHException ex)
                  {
                    flag = false;
                    if (string.Compare(ex.Message, EPShared.LocalRM.GetString("ExternalComponentExceptionMessage"), true) == 0)
                    {
                      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyCannotbeLoadedPickanother_Message") + this.m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                    }
                  }
                }
              }
              if (!flag)
              {
                int num = (int) RevitMessageBox.Show(this.m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyCannotBePlaceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              _FamilySymobl = this.FindFamilySymbol();
            }
          }
          if (_FamilySymobl != null)
          {
            int num1 = 0;
            Parameter parameter = ((Element) _FamilySymobl).LookupParameter(RevitParameters.EdgePathWalkFamilyParameter);
            if (parameter != null)
              num1 = parameter.AsInteger();
            if (string.Compare(strA, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), true) == 0 && num1 == 1)
            {
              int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoLinearFootageMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
            }
          }
          return this.SetFamilyInstance(element1, _FamilySymobl, _strRegionName, uniqueId);
        }
        int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RegionSelectedNotAssignedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRegion"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    return true;
  }

  private FamilySymbol FindFamilySymbol()
  {
    FamilySymbol familySymbol = (FamilySymbol) null;
    List<FamilySymbol> familySymbolList = this.LoadFamilySymbols(true);
    if (familySymbolList.Count > 0)
      familySymbol = familySymbolList[0];
    return familySymbol;
  }

  public void PopulateFamilySymbolList() => this.m_ListOfInstance = this.LoadFamilySymbols(false);

  private List<FamilySymbol> LoadFamilySymbols(bool _bFindFirstSymbol)
  {
    List<FamilySymbol> familySymbolList = new List<FamilySymbol>();
    Parameter LandcaddIDParameter = (Parameter) null;
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (LandcaddIDParameter = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), this.m_strLandcaddID, true) == 0)).ToList<Element>();
    foreach (Element element in list)
    {
      if (element is FamilySymbol familySymbol && ((Element) familySymbol).Category != null && familySymbol.Family != null && ((Element) familySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        LandcaddIDParameter = ((Element) familySymbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (LandcaddIDParameter != null && string.Compare(LandcaddIDParameter.AsString(), this.m_strLandcaddID, true) == 0)
        {
          bool flag = false;
          for (int index = 0; index < familySymbolList.Count; ++index)
          {
            if (string.Compare(((Element) familySymbolList[index].Family).Name, ((Element) familySymbol.Family).Name, true) == 0)
            {
              flag = true;
              break;
            }
          }
          if (!flag)
            familySymbolList.Add(familySymbol);
          if (_bFindFirstSymbol)
            break;
        }
      }
    }
    return familySymbolList;
  }

  private bool SetFamilyInstance(
    Element _Element,
    FamilySymbol _FamilySymobl,
    string _strRegionName,
    string _strUniqueID)
  {
    bool flag = false;
    if (_FamilySymobl != null)
    {
      FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(this.m_Document, new XYZ(0.0, 0.0, 0.0), _FamilySymobl, _Element, (Level) null, (StructuralType) 0, ref this.m_TransactionContainer);
      ElementSet elm_set = new ElementSet();
      elm_set.Insert((Element) familyInstance);
      this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.RegionNameGenericModelFamilyParameter);
      if (parameter1 != null && !((APIObject) parameter1).IsReadOnly)
        parameter1.Set(_strRegionName);
      Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
      if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
        parameter2.Set(_strUniqueID);
      flag = true;
      int num = (int) RevitMessageBox.Show(this.m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_AssignFor_Message") + _strRegionName, EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
    }
    return flag;
  }

  public string LandcaddIDValue => this.m_strLandcaddID;

  public string PlantOrPatioWalkText => this.m_strPlantOrPatioWalkText;

  public string FormText
  {
    get => EPShared.LocalRM.GetString("Assign_Message") + this.m_strPlantOrPatioWalkText;
  }

  public CreateDialogType CreateDialogType => this.m_CreateDialogType;

  public ReadOnlyCollection<FamilySymbol> PlantMixFamilyList
  {
    get => new ReadOnlyCollection<FamilySymbol>((IList<FamilySymbol>) this.m_ListOfInstance);
  }

  public Document Document => this.m_Document;

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }
}
