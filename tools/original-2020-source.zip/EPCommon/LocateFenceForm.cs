﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LocateFenceForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LocateFenceForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private FenceCreation m_dataBuffer;
  private View m_CurView;
  private FamilySymbol m_CurType;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Label m_FenceFamilyLabel;
  private ComboBox m_FenceFamilyComboBox;
  private ComboBox m_LevelComboBox;
  private Label m_LevelLabel;
  private Label m_FenceNameLabel;
  private ComboBox m_FenceNameComboBox;
  private Label m_SetbackLabel;
  private TextBox m_SetbackTextBox;
  private Label m_FenceHeightLabel;
  private TextBox m_FenceHeightTextBox;
  private Label m_FenceSpanLabel;
  private TextBox m_FenceSpanTextBox;
  private Button m_LoadFamilyButton;
  private CheckBox m_ExistingElementCheckBox;
  private Panel m_MoveablePanel;
  private CheckBox m_DeleteExistingCheckBox;
  private Button m_CancelButton;
  private Button m_InsertButton;
  private RadioButton m_ChainRadioButton;
  private RadioButton m_SegmentRadioButton;
  private Label m_StartingDistanceLabel;
  private TextBox m_StartingDistanceTextBox;
  private Panel m_ToposurfacePane;
  private ComboBox m_SurfaceList;
  private Label m_SelectedSurfaceLabel;
  private CheckBox m_ToposurfaceCheckBox;

  public LocateFenceForm(FenceCreation dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("LocateFenceDialog");
    this.m_FenceFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FenceFamilyDialog");
    this.m_FenceNameLabel.Text = EPShared.LocalRM.GetString("F_AMP_enceNameDialog");
    this.m_FenceHeightLabel.Text = EPShared.LocalRM.GetString("Fence_AMP_HeightDialog");
    this.m_FenceSpanLabel.Text = EPShared.LocalRM.GetString("FenceS_AMP_panDialog");
    this.m_SetbackLabel.Text = EPShared.LocalRM.GetString("Set_AMP_backDialog");
    this.m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
    this.m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_ExistingElementCheckBox.Text = EPShared.LocalRM.GetString("ExistingEle_AMP_mentDialog");
    this.m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
    this.m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
    this.m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.m_ToposurfaceCheckBox.Checked = false;
    this.m_SurfaceList.Enabled = false;
    this.m_dataBuffer = dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty1 = string.Empty;
    this.GetDialogPosition();
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceSetback", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_SetbackTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceHeight", ref _dReturnValue))
      _dReturnValue = 4.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_FenceHeightTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceSpan", ref _dReturnValue))
      _dReturnValue = 6.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_FenceSpanTextBox.Text = empty1;
    this.m_ExistingElementCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceExistingElement", ref _nReturnValue))
      this.m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_DeleteExistingCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceDeleteExisting", ref _nReturnValue))
      this.m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ToposurfaceCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFencePickToposurface", ref _nReturnValue))
      this.m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceStartingDistance", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_StartingDistanceTextBox.Text = empty1;
    this.m_FenceFamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
    this.m_FenceFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateFenceFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_FenceFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_FenceFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty1, true) == 0)
        {
          this.m_FenceFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateFencePlantName", ref empty1))
    {
      for (int index = 0; index < this.m_FenceNameComboBox.Items.Count; ++index)
      {
        if (this.m_FenceNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty1, true) == 0)
        {
          this.m_FenceNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_LevelComboBox.DataSource = (object) this.m_dataBuffer.Views;
    this.m_LevelComboBox.DisplayMember = EPShared.LocalRM.GetString("ViewNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateFenceViewName", ref empty1))
    {
      for (int index = 0; index < this.m_LevelComboBox.Items.Count; ++index)
      {
        if (this.m_LevelComboBox.Items[index] is View view && string.Compare(((Element) view).Name, empty1, true) == 0)
        {
          this.m_LevelComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    Parameter parameter1 = (Parameter) null;
    string name = string.Empty;
    if (this.m_dataBuffer.SurfaceList.Count > 0)
    {
      int num = 1;
      foreach (TopographySurfaceContainer surface in this.m_dataBuffer.SurfaceList)
      {
        Parameter parameter2 = ((Element) surface.TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter2 != null)
          name = parameter2.AsString();
        if (name == null || name == string.Empty)
        {
          name = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
          ++num;
        }
        this.m_SurfaceList.Items.Add((object) new ToposurfaceItem(name, surface));
      }
    }
    else
    {
      this.m_ToposurfaceCheckBox.Checked = false;
      this.m_ToposurfaceCheckBox.Enabled = false;
      this.m_SurfaceList.Enabled = false;
    }
    parameter1 = (Parameter) null;
    string empty2 = string.Empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateFenceSurfaceName", ref empty1))
    {
      for (int index = 0; index < this.m_SurfaceList.Items.Count; ++index)
      {
        if (this.m_SurfaceList.Items[index] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, empty1, true) == 0)
        {
          this.m_SurfaceList.SelectedIndex = index;
          break;
        }
      }
    }
    if (this.m_SurfaceList.Items.Count > 0 && this.m_SurfaceList.SelectedIndex == -1)
      this.m_SurfaceList.SelectedIndex = 0;
    this.m_SegmentRadioButton.Checked = true;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFenceSegmentChainOption", ref _nReturnValue))
      return;
    if (_nReturnValue == 0)
      this.m_SegmentRadioButton.Checked = true;
    else
      this.m_ChainRadioButton.Checked = true;
  }

  private void SaveSettings()
  {
    this.m_CurView = this.m_LevelComboBox.SelectedItem as View;
    if (this.m_CurView == null)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.m_CurType = this.m_FenceNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_CurType == null)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        double _dReturnedDouble = 0.0;
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceSetback", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_FenceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceHeight", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_FenceSpanTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceSpan", _dReturnedDouble);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceExistingElement", Convert.ToInt32(this.m_ExistingElementCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceDeleteExisting", Convert.ToInt32(this.m_DeleteExistingCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateFencePickToposurface", Convert.ToInt32(this.m_ToposurfaceCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceStartingDistance", _dReturnedDouble);
        if (this.m_FenceFamilyComboBox.SelectedItem is FamilyContainer selectedItem)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateFenceFamilyName", selectedItem.FamilyName);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateFencePlantName", ((Element) this.m_CurType).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateFenceViewName", Convert.ToString(this.m_LevelComboBox.SelectedItem));
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateFenceSurfaceName", Convert.ToString(this.m_SurfaceList.SelectedItem));
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateFenceSegmentChainOption", !this.m_SegmentRadioButton.Checked ? 1 : 0);
      }
    }
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private bool ValidateFields()
  {
    double _dReturnedDouble = 0.0;
    if (!RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_SetbackTextBox.Focus();
      return false;
    }
    if (_dReturnedDouble < 0.0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_SetbackTextBox.Focus();
      return false;
    }
    if (!RevitGeometry.Units_ConvertStringToDouble(this.m_FenceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFenceHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FenceHeightTextBox.Focus();
      return false;
    }
    if (_dReturnedDouble <= 0.0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidFenceHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FenceHeightTextBox.Focus();
      return false;
    }
    if (!RevitGeometry.Units_ConvertStringToDouble(this.m_FenceSpanTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFenceSpanMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FenceSpanTextBox.Focus();
      return false;
    }
    if (_dReturnedDouble > 0.0)
      return true;
    int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidSpenceSpanMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    this.m_FenceSpanTextBox.Focus();
    return false;
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void FormatSetbackValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_SetbackTextBox.Text = empty;
    }
    else
      this.m_SetbackTextBox.Focus();
  }

  private void OnSetbackTextBoxLeave(object sender, EventArgs e) => this.FormatSetbackValue();

  private void OnSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatSetbackValue();
  }

  private void OnComponentNameComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
  }

  private void OnComponentFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_FenceFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_FenceNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_FenceNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void FormatFenceSpanValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_FenceSpanTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_FenceSpanTextBox.Text = empty;
    }
    else
      this.m_FenceSpanTextBox.Focus();
  }

  private void FormatFenceHeightValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_FenceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_FenceHeightTextBox.Text = empty;
    }
    else
      this.m_FenceHeightTextBox.Focus();
  }

  private void OnFenceHeightKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatFenceHeightValue();
  }

  private void OnFenceSpanTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatFenceSpanValue();
  }

  private void OnFenceHeightTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatFenceHeightValue();
  }

  private void OnFenceSpanTextBoxLeave(object sender, EventArgs e) => this.FormatFenceSpanValue();

  private void OnLocateFenceFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_FenceFamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectFenceFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadFenceFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            this.m_dataBuffer.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceFamilyCantBeLoadedMessage") + Convert.ToInt32((object) LandcaddID.Fence).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceFamilyNotLoadedWithIDMessage") + Convert.ToInt32((object) LandcaddID.Fence).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_FenceFamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
        this.m_FenceFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_FenceFamilyComboBox.Items.Count; ++index)
          {
            if (this.m_FenceFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_FenceFamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_FenceFamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotFenceMessage") + Convert.ToInt32((object) LandcaddID.Fence).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_DeleteExistingCheckBox.Enabled = this.m_ExistingElementCheckBox.Checked;
    this.m_StartingDistanceLabel.Enabled = this.m_ExistingElementCheckBox.Checked;
    this.m_StartingDistanceTextBox.Enabled = this.m_ExistingElementCheckBox.Checked;
  }

  private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatStartingDistanceValue();
  }

  private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatStartingDistanceValue();
  }

  private void FormatStartingDistanceValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_StartingDistanceTextBox.Text = empty;
    }
    else
      this.m_StartingDistanceTextBox.Focus();
  }

  private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
  {
    this.m_SurfaceList.Enabled = this.m_ToposurfaceCheckBox.Checked;
    this.m_SelectedSurfaceLabel.Enabled = this.m_ToposurfaceCheckBox.Checked;
  }

  public bool ExistingElementChecked => this.m_ExistingElementCheckBox.Checked;

  public bool DeleteExistingChecked
  {
    get => this.m_ExistingElementCheckBox.Checked && this.m_DeleteExistingCheckBox.Checked;
  }

  public double StartingDistance
  {
    get
    {
      if (!this.m_ExistingElementCheckBox.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_StartingDistanceTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public Level Level => this.m_CurView.GenLevel;

  public View View => this.m_CurView;

  public FamilySymbol Type => this.m_CurType;

  public TopographySurfaceContainer Surface
  {
    get
    {
      TopographySurfaceContainer surface = (TopographySurfaceContainer) null;
      if (this.m_SurfaceList.SelectedItem is ToposurfaceItem selectedItem)
        surface = selectedItem.Value;
      return surface;
    }
  }

  public double SetbackSpacing
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_SetbackTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double FenceSpan
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_FenceSpanTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_FenceSpanTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double FenceHeight
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_FenceHeightTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_FenceHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool SegmentChecked => this.m_SegmentRadioButton.Checked;

  public bool ChainChecked => this.m_ChainRadioButton.Checked;

  public bool PickToposurface => this.m_ToposurfaceCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_FenceFamilyLabel = new Label();
    this.m_FenceFamilyComboBox = new ComboBox();
    this.m_LevelComboBox = new ComboBox();
    this.m_LevelLabel = new Label();
    this.m_FenceNameLabel = new Label();
    this.m_FenceNameComboBox = new ComboBox();
    this.m_SetbackLabel = new Label();
    this.m_SetbackTextBox = new TextBox();
    this.m_FenceHeightLabel = new Label();
    this.m_FenceHeightTextBox = new TextBox();
    this.m_FenceSpanLabel = new Label();
    this.m_FenceSpanTextBox = new TextBox();
    this.m_LoadFamilyButton = new Button();
    this.m_ExistingElementCheckBox = new CheckBox();
    this.m_MoveablePanel = new Panel();
    this.m_StartingDistanceLabel = new Label();
    this.m_StartingDistanceTextBox = new TextBox();
    this.m_DeleteExistingCheckBox = new CheckBox();
    this.m_CancelButton = new Button();
    this.m_InsertButton = new Button();
    this.m_ChainRadioButton = new RadioButton();
    this.m_SegmentRadioButton = new RadioButton();
    this.m_ToposurfacePane = new Panel();
    this.m_SurfaceList = new ComboBox();
    this.m_SelectedSurfaceLabel = new Label();
    this.m_ToposurfaceCheckBox = new CheckBox();
    this.m_MoveablePanel.SuspendLayout();
    this.m_ToposurfacePane.SuspendLayout();
    this.SuspendLayout();
    this.m_FenceFamilyLabel.AutoSize = true;
    this.m_FenceFamilyLabel.Location = new Point(9, 15);
    this.m_FenceFamilyLabel.Name = "m_FenceFamilyLabel";
    this.m_FenceFamilyLabel.Size = new Size(72, 13);
    this.m_FenceFamilyLabel.TabIndex = 0;
    this.m_FenceFamilyLabel.Text = "&Fence Family:";
    this.m_FenceFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_FenceFamilyComboBox.FormattingEnabled = true;
    this.m_FenceFamilyComboBox.Location = new Point(130, 12);
    this.m_FenceFamilyComboBox.Name = "m_FenceFamilyComboBox";
    this.m_FenceFamilyComboBox.Size = new Size(215, 21);
    this.m_FenceFamilyComboBox.TabIndex = 1;
    this.m_FenceFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnComponentFamilyComboBoxSelectedIndexChanged);
    this.m_LevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LevelComboBox.FormattingEnabled = true;
    this.m_LevelComboBox.Location = new Point(130, 144 /*0x90*/);
    this.m_LevelComboBox.Name = "m_LevelComboBox";
    this.m_LevelComboBox.Size = new Size(215, 21);
    this.m_LevelComboBox.TabIndex = 12;
    this.m_LevelLabel.AutoSize = true;
    this.m_LevelLabel.Location = new Point(9, 147);
    this.m_LevelLabel.Name = "m_LevelLabel";
    this.m_LevelLabel.Size = new Size(36, 13);
    this.m_LevelLabel.TabIndex = 11;
    this.m_LevelLabel.Text = "&Level:";
    this.m_FenceNameLabel.AutoSize = true;
    this.m_FenceNameLabel.Location = new Point(9, 42);
    this.m_FenceNameLabel.Name = "m_FenceNameLabel";
    this.m_FenceNameLabel.Size = new Size(68, 13);
    this.m_FenceNameLabel.TabIndex = 3;
    this.m_FenceNameLabel.Text = "F&ence Name";
    this.m_FenceNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_FenceNameComboBox.FormattingEnabled = true;
    this.m_FenceNameComboBox.Location = new Point(130, 39);
    this.m_FenceNameComboBox.Name = "m_FenceNameComboBox";
    this.m_FenceNameComboBox.Size = new Size(215, 21);
    this.m_FenceNameComboBox.TabIndex = 4;
    this.m_FenceNameComboBox.SelectedIndexChanged += new EventHandler(this.OnComponentNameComboBoxSelectedIndexChanged);
    this.m_SetbackLabel.AutoSize = true;
    this.m_SetbackLabel.Location = new Point(9, 121);
    this.m_SetbackLabel.Name = "m_SetbackLabel";
    this.m_SetbackLabel.Size = new Size(50, 13);
    this.m_SetbackLabel.TabIndex = 9;
    this.m_SetbackLabel.Text = "Set&back:";
    this.m_SetbackTextBox.Location = new Point(130, 118);
    this.m_SetbackTextBox.Name = "m_SetbackTextBox";
    this.m_SetbackTextBox.Size = new Size(100, 20);
    this.m_SetbackTextBox.TabIndex = 10;
    this.m_SetbackTextBox.KeyDown += new KeyEventHandler(this.OnSetbackTextBoxKeyDown);
    this.m_SetbackTextBox.Leave += new EventHandler(this.OnSetbackTextBoxLeave);
    this.m_FenceHeightLabel.AutoSize = true;
    this.m_FenceHeightLabel.Location = new Point(9, 69);
    this.m_FenceHeightLabel.Name = "m_FenceHeightLabel";
    this.m_FenceHeightLabel.Size = new Size(74, 13);
    this.m_FenceHeightLabel.TabIndex = 5;
    this.m_FenceHeightLabel.Text = "Fence &Height:";
    this.m_FenceHeightTextBox.Location = new Point(130, 66);
    this.m_FenceHeightTextBox.Name = "m_FenceHeightTextBox";
    this.m_FenceHeightTextBox.Size = new Size(100, 20);
    this.m_FenceHeightTextBox.TabIndex = 6;
    this.m_FenceHeightTextBox.KeyDown += new KeyEventHandler(this.OnFenceHeightKeyDown);
    this.m_FenceHeightTextBox.Leave += new EventHandler(this.OnFenceHeightTextBoxLeave);
    this.m_FenceSpanLabel.AutoSize = true;
    this.m_FenceSpanLabel.Location = new Point(9, 95);
    this.m_FenceSpanLabel.Name = "m_FenceSpanLabel";
    this.m_FenceSpanLabel.Size = new Size(68, 13);
    this.m_FenceSpanLabel.TabIndex = 7;
    this.m_FenceSpanLabel.Text = "Fence &Span:";
    this.m_FenceSpanTextBox.Location = new Point(130, 92);
    this.m_FenceSpanTextBox.Name = "m_FenceSpanTextBox";
    this.m_FenceSpanTextBox.Size = new Size(100, 20);
    this.m_FenceSpanTextBox.TabIndex = 8;
    this.m_FenceSpanTextBox.KeyDown += new KeyEventHandler(this.OnFenceSpanTextBoxKeyDown);
    this.m_FenceSpanTextBox.Leave += new EventHandler(this.OnFenceSpanTextBoxLeave);
    this.m_LoadFamilyButton.Location = new Point(351, 13);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_ExistingElementCheckBox.AutoSize = true;
    this.m_ExistingElementCheckBox.Location = new Point(12, 244);
    this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
    this.m_ExistingElementCheckBox.Size = new Size(103, 17);
    this.m_ExistingElementCheckBox.TabIndex = 16 /*0x10*/;
    this.m_ExistingElementCheckBox.Text = "Existing Ele&ment";
    this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
    this.m_ExistingElementCheckBox.CheckedChanged += new EventHandler(this.OnExistingElementCheckBoxChecked);
    this.m_MoveablePanel.Controls.Add((Control) this.m_StartingDistanceLabel);
    this.m_MoveablePanel.Controls.Add((Control) this.m_StartingDistanceTextBox);
    this.m_MoveablePanel.Controls.Add((Control) this.m_DeleteExistingCheckBox);
    this.m_MoveablePanel.Controls.Add((Control) this.m_CancelButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Location = new Point(12, 268);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(363, 72);
    this.m_MoveablePanel.TabIndex = 17;
    this.m_StartingDistanceLabel.AutoSize = true;
    this.m_StartingDistanceLabel.Enabled = false;
    this.m_StartingDistanceLabel.Location = new Point(20, 26);
    this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
    this.m_StartingDistanceLabel.Size = new Size(91, 13);
    this.m_StartingDistanceLabel.TabIndex = 1;
    this.m_StartingDistanceLabel.Text = "Starting Distance:";
    this.m_StartingDistanceTextBox.Enabled = false;
    this.m_StartingDistanceTextBox.Location = new Point(118, 23);
    this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
    this.m_StartingDistanceTextBox.Size = new Size(100, 20);
    this.m_StartingDistanceTextBox.TabIndex = 2;
    this.m_StartingDistanceTextBox.KeyDown += new KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
    this.m_StartingDistanceTextBox.Leave += new EventHandler(this.OnStartingDistanceTextBoxLeave);
    this.m_DeleteExistingCheckBox.AutoSize = true;
    this.m_DeleteExistingCheckBox.Enabled = false;
    this.m_DeleteExistingCheckBox.Location = new Point(20, 0);
    this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
    this.m_DeleteExistingCheckBox.Size = new Size(137, 17);
    this.m_DeleteExistingCheckBox.TabIndex = 0;
    this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
    this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(287, 49);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(76, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_InsertButton.Location = new Point(206, 49);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 3;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_ChainRadioButton.AutoSize = true;
    this.m_ChainRadioButton.Location = new Point(130, 221);
    this.m_ChainRadioButton.Name = "m_ChainRadioButton";
    this.m_ChainRadioButton.Size = new Size(52, 17);
    this.m_ChainRadioButton.TabIndex = 15;
    this.m_ChainRadioButton.Text = "&Chain";
    this.m_ChainRadioButton.UseVisualStyleBackColor = true;
    this.m_SegmentRadioButton.AutoSize = true;
    this.m_SegmentRadioButton.Checked = true;
    this.m_SegmentRadioButton.Location = new Point(12, 221);
    this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
    this.m_SegmentRadioButton.Size = new Size(67, 17);
    this.m_SegmentRadioButton.TabIndex = 14;
    this.m_SegmentRadioButton.TabStop = true;
    this.m_SegmentRadioButton.Text = "&Segment";
    this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_ToposurfacePane.Controls.Add((Control) this.m_SurfaceList);
    this.m_ToposurfacePane.Controls.Add((Control) this.m_SelectedSurfaceLabel);
    this.m_ToposurfacePane.Controls.Add((Control) this.m_ToposurfaceCheckBox);
    this.m_ToposurfacePane.Location = new Point(12, 171);
    this.m_ToposurfacePane.Name = "m_ToposurfacePane";
    this.m_ToposurfacePane.Size = new Size(363, 44);
    this.m_ToposurfacePane.TabIndex = 13;
    this.m_SurfaceList.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_SurfaceList.Enabled = false;
    this.m_SurfaceList.FormattingEnabled = true;
    this.m_SurfaceList.Location = new Point(118, 23);
    this.m_SurfaceList.Name = "m_SurfaceList";
    this.m_SurfaceList.Size = new Size(215, 21);
    this.m_SurfaceList.TabIndex = 2;
    this.m_SelectedSurfaceLabel.AutoSize = true;
    this.m_SelectedSurfaceLabel.Enabled = false;
    this.m_SelectedSurfaceLabel.Location = new Point(0, 26);
    this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
    this.m_SelectedSurfaceLabel.Size = new Size(44, 13);
    this.m_SelectedSurfaceLabel.TabIndex = 1;
    this.m_SelectedSurfaceLabel.Text = "Surface";
    this.m_ToposurfaceCheckBox.AutoSize = true;
    this.m_ToposurfaceCheckBox.Location = new Point(0, 0);
    this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
    this.m_ToposurfaceCheckBox.Size = new Size(86, 17);
    this.m_ToposurfaceCheckBox.TabIndex = 0;
    this.m_ToposurfaceCheckBox.Text = "Toposurface";
    this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
    this.m_ToposurfaceCheckBox.CheckStateChanged += new EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(387, 352);
    this.Controls.Add((Control) this.m_ToposurfacePane);
    this.Controls.Add((Control) this.m_ChainRadioButton);
    this.Controls.Add((Control) this.m_SegmentRadioButton);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.Controls.Add((Control) this.m_ExistingElementCheckBox);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_FenceSpanLabel);
    this.Controls.Add((Control) this.m_FenceSpanTextBox);
    this.Controls.Add((Control) this.m_FenceHeightLabel);
    this.Controls.Add((Control) this.m_FenceHeightTextBox);
    this.Controls.Add((Control) this.m_SetbackLabel);
    this.Controls.Add((Control) this.m_SetbackTextBox);
    this.Controls.Add((Control) this.m_FenceNameComboBox);
    this.Controls.Add((Control) this.m_FenceNameLabel);
    this.Controls.Add((Control) this.m_LevelComboBox);
    this.Controls.Add((Control) this.m_LevelLabel);
    this.Controls.Add((Control) this.m_FenceFamilyComboBox);
    this.Controls.Add((Control) this.m_FenceFamilyLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (LocateFenceForm);
    this.Text = "Locate Fence";
    this.FormClosing += new FormClosingEventHandler(this.OnLocateFenceFormClosing);
    this.m_MoveablePanel.ResumeLayout(false);
    this.m_MoveablePanel.PerformLayout();
    this.m_ToposurfacePane.ResumeLayout(false);
    this.m_ToposurfacePane.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
