﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.AddModifyMix
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class AddModifyMix : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private DisplayUnit m_DisplayUnitSystem;
  private FormatOptions m_FormatOptions;
  private UnitSymbolType m_UnitSymbolType;
  private List<FamilyTypeContainer> m_FamilyTypeContainerList;
  private int m_nSeletedIndex = -1;
  private List<FamilyParameterTypeWrapper> m_ParameterList = new List<FamilyParameterTypeWrapper>();
  private QuantumListView m_ParameterListView = new QuantumListView();
  private DialogType m_DlgType;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;

  public AddModifyMix(
    List<FamilyParameterTypeWrapper> _ParameterList,
    ref List<FamilyTypeContainer> _FamilyTypeContainerList,
    Units _Units,
    DisplayUnit _UnitType,
    FormatOptions _FormatOption,
    UnitSymbolType _UnitSymbolType,
    DecimalSymbol _DecimalSymbolType,
    int _nSelectedIndex,
    DialogType _DlgType)
  {
    this.InitializeComponent();
    this.m_ParameterList = _ParameterList;
    this.m_FamilyTypeContainerList = _FamilyTypeContainerList;
    this.m_DisplayUnitSystem = _UnitType;
    this.m_FormatOptions = _FormatOption;
    this.m_UnitSymbolType = _UnitSymbolType;
    this.m_DecimalSymbolType = _DecimalSymbolType;
    this.m_nSeletedIndex = _nSelectedIndex;
    this.m_DlgType = _DlgType;
    this.m_Units = _Units;
    this.InitializeData();
    this.GetDialogPosition();
    this.m_ParameterListView.OnListViewItemChanged += new ListViewItemChanged(this.ParameterListViewOnListViewItemChanged);
    this.FormClosing += new FormClosingEventHandler(this.AddModifyMixFormClosing);
  }

  private void AddModifyMixFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void ParameterListViewOnListViewItemChanged(int _nChangedIndex)
  {
    double _dReturnedDouble1 = 0.0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (this.m_DlgType == DialogType.PlantMix)
    {
      if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("PlantSizePlantMixFamilyParameter"), text1, true) == 0)
        return;
      if (string.Compare(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), text1, true) == 0)
      {
        if (string.Compare(text2, EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"), true) == 0)
        {
          this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text = EPShared.LocalRM.GetString("NotAvailableString");
        }
        else
        {
          if (string.Compare(this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0 && !(this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text == string.Empty))
            return;
          string empty = string.Empty;
          RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
          this.m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text = empty;
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), text1, true) == 0)
      {
        try
        {
          if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1))
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          }
          else if (_dReturnedDouble1 >= 0.0)
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) _dReturnedDouble1);
          else
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", (object) 0.0);
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), text1, true) == 0)
      {
        try
        {
          if (!RevitGeometry.StrE_GetValidRealNumber(text2, ref _dReturnedDouble1) || _dReturnedDouble1 <= 0.0 || _dReturnedDouble1 > 100.0)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = "1";
          }
          else
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else
      {
        if (string.Compare(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), text1, true) != 0)
          return;
        try
        {
          double _dReturnedDouble2 = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble2);
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble2, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
    }
    else if (string.Compare(EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble3 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble3);
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble3, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), text1, true) != 0)
        return;
      try
      {
        double _dReturnedDouble4 = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble4);
        if (_dReturnedDouble4 <= 3.0)
        {
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble4, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(3.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("ValidEdgeWidth")} {text2}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void InitializeData()
  {
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ParameterListView.View = View.Details;
    this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
    this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_ParameterListView
    });
    this.m_ParameterListView.Columns[0].Width = 215;
    this.m_ParameterListView.Columns[1].Width = 215;
    if (this.m_DlgType == DialogType.PlantMix)
    {
      this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular"));
      this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("PlantMixSpacingMethodSquare"));
      this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"));
    }
    else
    {
      this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("NoString"));
      this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("YesString"));
    }
    ListViewItem listViewItem1 = new ListViewItem();
    if (this.m_nSeletedIndex < 0)
    {
      this.Text = EPShared.LocalRM.GetString("AddDialog");
      FamilyTypeContainer familyTypeContainer = new FamilyTypeContainer();
      for (int index = 0; index < this.m_ParameterList.Count; ++index)
      {
        string parameterDisplayName = this.m_ParameterList[index].ParameterDisplayName;
        string parameterName = this.m_ParameterList[index].ParameterName;
        string _strToDisplay = string.Empty;
        if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
        {
          if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular");
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
            _strToDisplay = ValueConversion.ToString(this.m_DecimalSymbolType, 1.0);
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
            _strToDisplay = "1";
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("NoString");
          else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
            RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
          ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(parameterName, parameterDisplayName, string.Empty);
          listViewItem2.SubItems.Add(_strToDisplay);
          listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = _strToDisplay;
        }
      }
    }
    else
    {
      this.Text = EPShared.LocalRM.GetString("ModifyDialog");
      for (int index = 0; index < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index)
      {
        string displayName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].DisplayName;
        string parameterName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName;
        string _strToDisplay = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
        if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(parameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
        {
          if (this.m_DlgType == DialogType.PlantMix)
          {
            if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
            {
              double _dConvertedDouble = 1.0;
              if (parameterName != string.Empty && _strToDisplay != null)
                _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
            }
            else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
            {
              _strToDisplay = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
              if (_strToDisplay == string.Empty || _strToDisplay == null)
                _strToDisplay = EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular");
            }
            else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
            {
              if (_strToDisplay == null)
                _strToDisplay = "1.0";
              else if (_strToDisplay != null && _strToDisplay == string.Empty)
                _strToDisplay = "1.0";
            }
          }
          else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
          {
            double _dConvertedDouble = 1.0;
            if (parameterName != string.Empty && _strToDisplay != null && _strToDisplay != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
          }
          else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
          {
            _strToDisplay = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value;
            if (_strToDisplay == string.Empty || _strToDisplay == null)
              _strToDisplay = EPShared.LocalRM.GetString("NoString");
            else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "0", true) == 0)
              _strToDisplay = EPShared.LocalRM.GetString("NoString");
            else if (string.Compare(this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index].Value, "1", true) == 0)
              _strToDisplay = EPShared.LocalRM.GetString("YesString");
          }
          ListViewItem listViewItem3 = this.m_ParameterListView.Items.Add(parameterName, displayName, string.Empty);
          if (_strToDisplay == null)
            _strToDisplay = string.Empty;
          listViewItem3.SubItems.Add(_strToDisplay);
          listViewItem3.SubItems[listViewItem3.SubItems.Count - 1].Text = _strToDisplay;
        }
      }
    }
    if (this.m_DlgType == DialogType.PlantMix)
      this.Text = $"{this.Text} {EPShared.LocalRM.GetString("PlantMixDialog")}";
    else
      this.Text = $"{this.Text} {EPShared.LocalRM.GetString("PathWalkDialog")}";
  }

  private void OnButtonOkClicked(object sender, EventArgs e)
  {
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    string _strFamilyTypeName1 = string.Empty;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string str1 = string.Empty;
    string str2 = string.Empty;
    if (this.m_DlgType == DialogType.PlantMix)
    {
      for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
      {
        string text1 = this.m_ParameterListView.Items[index].SubItems[0].Text;
        string text2 = this.m_ParameterListView.Items[index].SubItems[1].Text;
        if (string.Compare(text1, EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), true) == 0)
        {
          if (!string.IsNullOrEmpty(text2))
          {
            flag1 = true;
            str2 = text2;
            if (flag2)
              break;
          }
        }
        else if (string.Compare(text1, EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), true) == 0 && !string.IsNullOrEmpty(text2))
        {
          flag2 = true;
          str1 = text2;
          if (flag1)
            break;
        }
      }
      if (!flag1 && !flag2)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeCommonOrScientificName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
      {
        string text3 = this.m_ParameterListView.Items[index].SubItems[0].Text;
        string text4 = this.m_ParameterListView.Items[index].SubItems[1].Text;
        if (string.Compare(text3, EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), true) == 0)
        {
          if (text4 != string.Empty)
            flag3 = true;
        }
        else if (string.Compare(text3, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), true) == 0 && text4 != string.Empty)
          flag4 = true;
      }
      if (!flag3 && !flag4)
      {
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter")} {EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter")}{EPShared.LocalRM.GetString("_And_")}{EPShared.LocalRM.GetString("ValidFields")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag3)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag4)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (this.m_nSeletedIndex < 0)
      {
        FamilyTypeContainer _Container = new FamilyTypeContainer();
        _Container.FamilyParameterList = new List<FamilyParameterWrapper>();
        string _strFamilyTypeName2 = string.Empty;
        string empty3 = string.Empty;
        string empty4 = string.Empty;
        if ((flag2 || flag1) && _strFamilyTypeName2 == string.Empty)
        {
          if (flag2 && flag1)
            _strFamilyTypeName2 = $"{str1}/{str2}";
          else if (flag2)
            _strFamilyTypeName2 = str1;
          else if (flag1)
            _strFamilyTypeName2 = str2;
          if (_Container.FamilyTypeWrapper == null)
            _Container.FamilyTypeWrapper = new FamilyTypeWrapper(_strFamilyTypeName2);
          else
            _Container.FamilyTypeWrapper.FamilyTypeName = _strFamilyTypeName2;
        }
        for (int index = 0; index < this.m_ParameterListView.Items.Count; ++index)
        {
          StorageType _StorageType = (StorageType) 3;
          string name = this.m_ParameterListView.Items[index].SubItems[0].Name;
          string text = this.m_ParameterListView.Items[index].SubItems[0].Text;
          string _strParameterValue = this.m_ParameterListView.Items[index].SubItems[1].Text;
          if (string.Compare(text, EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), true) == 0)
          {
            string str3 = this.m_ParameterListView.Items[index].SubItems[1].Text;
            if (string.Compare(str3, EPShared.LocalRM.GetString("NotAvailableString"), true) == 0)
              str3 = "0.0";
            _StorageType = (StorageType) 2;
            if (string.Compare(text, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), true) == 0)
            {
              double _dReturnedDouble = 0.0;
              RevitGeometry.Units_ConvertStringToDouble(str3, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
              _strParameterValue = ValueConversion.ToString(this.m_DecimalSymbolType, _dReturnedDouble);
            }
            else
              _strParameterValue = str3;
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("CostGenericFamilyParameter"), true) == 0)
          {
            _StorageType = (StorageType) 2;
            _strParameterValue = this.m_ParameterListView.Items[index].SubItems[1].Text;
          }
          if (string.Compare(text, EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), true) == 0)
            _strParameterValue = string.Empty;
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(text, name, _strParameterValue, _StorageType);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.RegionNameGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.UniqueIDGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.AssemblyCodeGenericFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), RevitParameters.AssemblyCodeGenericFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        this.m_FamilyTypeContainerList.Add(_Container);
      }
      else
      {
        string str4 = string.Empty;
        if ((flag2 || flag1) && str4 == string.Empty)
        {
          if (flag2 && flag1)
            str4 = $"{str1}/{str2}";
          else if (flag2)
            str4 = str1;
          else if (flag1)
            str4 = str2;
          this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName = str4;
        }
        for (int index1 = 0; index1 < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index1)
        {
          string displayName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].DisplayName;
          string parameterName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].ParameterName;
          if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
          {
            string empty5 = string.Empty;
            this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].Value = empty5;
          }
          else
          {
            for (int index2 = 0; index2 < this.m_ParameterListView.Items.Count; ++index2)
            {
              if (string.Compare(displayName, this.m_ParameterListView.Items[index2].SubItems[0].Text, true) == 0)
              {
                string str5 = this.m_ParameterListView.Items[index2].SubItems[1].Text;
                if (string.Compare(parameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
                {
                  double _dReturnedDouble = 0.0;
                  if (str5 != null && str5 != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), str5, true) == 0)
                    _dReturnedDouble = 0.0;
                  else if (str5 != null && str5 != string.Empty)
                    RevitGeometry.Units_ConvertStringToDouble(str5, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
                  str5 = ValueConversion.ToString(this.m_DecimalSymbolType, _dReturnedDouble);
                }
                if (str5 == null)
                  str5 = string.Empty;
                this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index1].Value = str5;
                break;
              }
            }
          }
        }
      }
    }
    else
    {
      bool flag5 = false;
      if (this.m_nSeletedIndex < 0)
        flag5 = this.IsDuplicateEdiging();
      bool flag6 = false;
      bool flag7 = false;
      bool flag8 = false;
      bool flag9 = false;
      int index3 = -1;
      for (int index4 = 0; index4 < this.m_ParameterListView.Items.Count; ++index4)
      {
        string text5 = this.m_ParameterListView.Items[index4].SubItems[0].Text;
        string text6 = this.m_ParameterListView.Items[index4].SubItems[1].Text;
        if (string.Compare(text5, EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty)
          {
            _strFamilyTypeName1 = text6;
            flag9 = true;
          }
        }
        else if (string.Compare(text5, EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty && string.Compare(text6, EPShared.LocalRM.GetString("YesString"), true) == 0)
            flag6 = true;
        }
        else if (string.Compare(text5, EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty && string.Compare(text6, EPShared.LocalRM.GetString("YesString"), true) == 0)
            flag7 = true;
        }
        else if (string.Compare(text5, EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), true) == 0)
        {
          if (text6 != string.Empty)
          {
            try
            {
              double _dReturnedDouble = 0.0;
              if (RevitGeometry.Units_ConvertStringToDouble(text6, this.m_Units, (UnitType) 0, ref _dReturnedDouble) && _dReturnedDouble > 0.0)
              {
                empty2 = ValueConversion.ToString(this.m_DecimalSymbolType, _dReturnedDouble);
                flag8 = true;
              }
              index3 = index4;
            }
            catch (Exception ex)
            {
              flag8 = false;
              index3 = index4;
            }
          }
        }
      }
      if (!flag9)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidTypeName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (flag6 && flag7 && !flag8)
      {
        string empty6 = string.Empty;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidEdgeWidth"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty6);
        this.m_ParameterListView.Items[index3].SubItems[1].Text = empty6;
        return;
      }
      if (!flag6 && !flag7 && flag8)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedEdgeMowingYes"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag6 && flag7)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoEdgingYesMowingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (flag6 && !flag7 && flag8)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedEdgeMowingYes"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (!flag6 && flag7 && flag8)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoEdgingYesMowingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (flag6 && flag5)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateEdgeString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (this.m_nSeletedIndex < 0)
      {
        FamilyTypeContainer _Container = new FamilyTypeContainer();
        _Container.FamilyParameterList = new List<FamilyParameterWrapper>();
        string empty7 = string.Empty;
        string empty8 = string.Empty;
        string empty9 = string.Empty;
        for (int index5 = 0; index5 < this.m_ParameterListView.Items.Count; ++index5)
        {
          StorageType _StorageType = (StorageType) 3;
          string name = this.m_ParameterListView.Items[index5].SubItems[0].Name;
          string text = this.m_ParameterListView.Items[index5].SubItems[0].Text;
          string str6 = this.m_ParameterListView.Items[index5].SubItems[1].Text;
          if (string.Compare(text, EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), true) == 0)
            _Container.FamilyTypeWrapper = new FamilyTypeWrapper(_strFamilyTypeName1);
          else if (string.Compare(text, EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), true) == 0)
          {
            _StorageType = (StorageType) 2;
            double _dReturnedDouble = 0.0;
            if (str6 != null && str6 != string.Empty)
              RevitGeometry.Units_ConvertStringToDouble(str6, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
            str6 = ValueConversion.ToString(this.m_DecimalSymbolType, _dReturnedDouble);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), true) == 0)
          {
            _StorageType = (StorageType) 1;
            if (string.Compare(str6, EPShared.LocalRM.GetString("YesString"), true) == 0)
              str6 = "1";
            else if (string.Compare(str6, EPShared.LocalRM.GetString("NoString"), true) == 0)
              str6 = "0";
          }
          if (string.Compare(text, EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), true) == 0)
            str6 = string.Empty;
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(text, name, str6, _StorageType);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.RegionNameGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.UniqueIDGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        if (!this.FindParameter(RevitParameters.AssemblyCodeGenericFamilyParameter, _Container))
        {
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), RevitParameters.AssemblyCodeGenericFamilyParameter, "", (StorageType) 3);
          _Container.FamilyParameterList.Add(parameterWrapper);
        }
        this.m_FamilyTypeContainerList.Add(_Container);
      }
      else
      {
        for (int index6 = 0; index6 < this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList.Count; ++index6)
        {
          string displayName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].DisplayName;
          string parameterName = this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].ParameterName;
          for (int index7 = 0; index7 < this.m_ParameterListView.Items.Count; ++index7)
          {
            if (string.Compare(displayName, this.m_ParameterListView.Items[index7].SubItems[0].Text, true) == 0)
            {
              string str7 = this.m_ParameterListView.Items[index7].SubItems[1].Text;
              if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0)
              {
                string empty10 = string.Empty;
                this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].Value = empty10;
              }
              else
              {
                if (string.Compare(parameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
                {
                  double _dReturnedDouble = 1.0;
                  if (str7 != null && str7 != string.Empty)
                    RevitGeometry.Units_ConvertStringToDouble(str7, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
                  str7 = ValueConversion.ToString(this.m_DecimalSymbolType, _dReturnedDouble);
                }
                if (string.Compare(parameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(parameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
                {
                  if (string.Compare(str7, EPShared.LocalRM.GetString("YesString"), true) == 0)
                    str7 = "1";
                  else if (string.Compare(str7, EPShared.LocalRM.GetString("NoString"), true) == 0)
                    str7 = "0";
                }
                if (str7 == null)
                  str7 = string.Empty;
                if (string.Compare(parameterName, RevitParameters.MaterialPathWalkFamilyParameter, true) == 0 && str7 != string.Empty)
                  this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName = str7;
                this.m_FamilyTypeContainerList[this.m_nSeletedIndex].FamilyParameterList[index6].Value = str7;
                break;
              }
            }
          }
        }
      }
    }
    this.DialogResult = DialogResult.OK;
  }

  private bool IsDuplicateEdiging()
  {
    for (int index1 = 0; index1 < this.m_FamilyTypeContainerList.Count; ++index1)
    {
      int count = this.m_FamilyTypeContainerList[index1].FamilyParameterList.Count;
      for (int index2 = 0; index2 < count; ++index2)
      {
        if (string.Compare(this.m_FamilyTypeContainerList[index1].FamilyParameterList[index2].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 && string.Compare(this.m_FamilyTypeContainerList[index1].FamilyParameterList[index2].Value, "1", true) == 0)
          return true;
      }
    }
    return false;
  }

  private void OnButtonCancelClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private bool FindParameter(string _strValue, FamilyTypeContainer _Container)
  {
    string empty = string.Empty;
    for (int index = 0; index < _Container.FamilyParameterList.Count; ++index)
    {
      if (string.Compare(_Container.FamilyParameterList[index].ParameterName, _strValue, true) == 0)
        return true;
    }
    return false;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.SuspendLayout();
    this.m_ButtonOk.Location = new Point(298, 303);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 0;
    this.m_ButtonOk.Text = "&OK";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnButtonOkClicked);
    this.m_ButtonCancel.Location = new Point(379, 303);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 1;
    this.m_ButtonCancel.Text = "&Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnButtonCancelClicked);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(456, 332);
    this.Controls.Add((Control) this.m_ButtonCancel);
    this.Controls.Add((Control) this.m_ButtonOk);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (AddModifyMix);
    this.Text = nameof (AddModifyMix);
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
