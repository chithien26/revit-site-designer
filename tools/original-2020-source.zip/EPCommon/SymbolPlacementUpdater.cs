﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SymbolPlacementUpdater
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace EPCommon;

public class SymbolPlacementUpdater : IUpdater
{
  private static AddInId m_ApplicationId = new AddInId(new Guid("da9d271e-f7a0-4291-8837-02947862c85e"));
  private static UpdaterId m_UpdaterId = new UpdaterId(SymbolPlacementUpdater.m_ApplicationId, new Guid("df40ed3d-8df8-44e8-a41f-24dfec3317ee"));
  private List<GenericModelFamilyInstanceWrapper> m_GenericModelElementList;
  private int m_nDocumentsOpenCount;

  public SymbolPlacementUpdater()
  {
    this.m_GenericModelElementList = new List<GenericModelFamilyInstanceWrapper>();
  }

  public void Execute(UpdaterData _Data)
  {
    Document document = _Data.GetDocument();
    List<Element> elementList = (List<Element>) null;
    List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList = (List<KeyValuePair<string, FamilyInstance>>) null;
    List<LocateType> _FamilyQueryLocateTyoeList = (List<LocateType>) null;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    foreach (ElementId addedElementId in (IEnumerable<ElementId>) _Data.GetAddedElementIds())
    {
      if (document.GetElement(addedElementId) is FamilyInstance element1 && ((Element) element1).Category != null)
      {
        int integerValue1 = ((Element) element1).Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001360;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 != hashCode1)
        {
          int integerValue2 = ((Element) element1).Category.Id.IntegerValue;
          builtInCategory = (BuiltInCategory) -2001180;
          int hashCode2 = builtInCategory.GetHashCode();
          if (integerValue2 != hashCode2)
          {
            int integerValue3 = ((Element) element1).Category.Id.IntegerValue;
            builtInCategory = (BuiltInCategory) -2001260;
            int hashCode3 = builtInCategory.GetHashCode();
            if (integerValue3 != hashCode3)
            {
              int integerValue4 = ((Element) element1).Category.Id.IntegerValue;
              builtInCategory = (BuiltInCategory) -2001370;
              int hashCode4 = builtInCategory.GetHashCode();
              if (integerValue4 != hashCode4)
              {
                int integerValue5 = ((Element) element1).Category.Id.IntegerValue;
                builtInCategory = (BuiltInCategory) -2000080;
                int hashCode5 = builtInCategory.GetHashCode();
                if (integerValue5 != hashCode5)
                {
                  int integerValue6 = ((Element) element1).Category.Id.IntegerValue;
                  builtInCategory = (BuiltInCategory) -2001040;
                  int hashCode6 = builtInCategory.GetHashCode();
                  if (integerValue6 != hashCode6)
                  {
                    int integerValue7 = ((Element) element1).Category.Id.IntegerValue;
                    builtInCategory = (BuiltInCategory) -2000151;
                    int hashCode7 = builtInCategory.GetHashCode();
                    if (integerValue7 != hashCode7)
                    {
                      int integerValue8 = ((Element) element1).Category.Id.IntegerValue;
                      builtInCategory = (BuiltInCategory) -2001120;
                      int hashCode8 = builtInCategory.GetHashCode();
                      if (integerValue8 != hashCode8)
                      {
                        int integerValue9 = ((Element) element1).Category.Id.IntegerValue;
                        builtInCategory = (BuiltInCategory) -2000100;
                        int hashCode9 = builtInCategory.GetHashCode();
                        if (integerValue9 != hashCode9)
                          continue;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        Parameter parameter1 = ((Element) element1.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (parameter1 != null && string.Compare(parameter1.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)
        {
          Parameter parameter2 = ((Element) element1).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter2 != null)
          {
            if (elementList == null)
            {
              elementList = new List<Element>();
              foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(document).OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051).ToElements())
              {
                if (element != null && element.Category != null)
                {
                  int integerValue10 = element.Category.Id.IntegerValue;
                  builtInCategory = (BuiltInCategory) -2000051;
                  int hashCode10 = builtInCategory.GetHashCode();
                  if (integerValue10 == hashCode10)
                  {
                    for (int index = 0; index < this.m_GenericModelElementList.Count; ++index)
                    {
                      if (this.m_GenericModelElementList[index].IndexOfFamilyInstanceUniqueID(document, element.UniqueId) >= 0)
                      {
                        flag2 = true;
                        break;
                      }
                    }
                    if (!flag2)
                      elementList.Add(element);
                    else
                      flag2 = false;
                  }
                }
              }
            }
            for (int index1 = 0; index1 < elementList.Count; ++index1)
            {
              if (string.Compare(parameter2.AsString(), elementList[index1].UniqueId, true) == 0)
              {
                Parameter parameter3 = ((Element) element1).LookupParameter(RevitParameters.BoundaryIslandIDGenericFamilyParameter);
                if (parameter3 == null || parameter3.AsString() == string.Empty)
                {
                  Parameter parameter4 = ((Element) element1).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
                  if (parameter4 != null && parameter4.AsString() != string.Empty)
                  {
                    for (int index2 = 0; index2 < this.m_GenericModelElementList.Count; ++index2)
                    {
                      if (string.Compare(parameter4.AsString(), this.m_GenericModelElementList[index2].ChainID, true) == 0)
                      {
                        flag3 = true;
                        this.m_GenericModelElementList[index2].FamilyContainerList.Add(new GenericModelFamilyInstanceContainer(elementList[index1].Id, element1));
                        break;
                      }
                    }
                    if (!flag3)
                      this.m_GenericModelElementList.Add(new GenericModelFamilyInstanceWrapper(parameter4.AsString(), new List<GenericModelFamilyInstanceContainer>()
                      {
                        new GenericModelFamilyInstanceContainer(elementList[index1].Id, element1)
                      }));
                    else
                      flag3 = false;
                  }
                }
                else
                {
                  for (int index3 = 0; index3 < this.m_GenericModelElementList.Count; ++index3)
                  {
                    if (this.m_GenericModelElementList[index3].IndexOfFamilyInstanceUniqueID(document, parameter3.AsString()) >= 0)
                    {
                      if (this.m_GenericModelElementList[index3].IslandFamilyInstanceList == null)
                        this.m_GenericModelElementList[index3].IslandFamilyInstanceList = new List<GenericModelFamilyInstanceContainer>();
                      this.m_GenericModelElementList[index3].IslandFamilyInstanceList.Add(new GenericModelFamilyInstanceContainer(elementList[index1].Id, element1));
                      break;
                    }
                  }
                }
                flag1 = true;
                break;
              }
            }
          }
        }
        else
        {
          int integerValue11 = ((Element) element1).Category.Id.IntegerValue;
          builtInCategory = (BuiltInCategory) -2000151;
          int hashCode11 = builtInCategory.GetHashCode();
          if (integerValue11 != hashCode11 || parameter1 != null)
          {
            Parameter parameter5 = ((Element) element1).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
            if (parameter5 != null && !this.AddFamilyAssignmentToList(document, parameter5.AsString(), element1))
            {
              if (_GenericModelElementList == null)
                _GenericModelElementList = new List<KeyValuePair<string, FamilyInstance>>();
              _GenericModelElementList.Add(new KeyValuePair<string, FamilyInstance>(parameter5.AsString(), element1));
              flag1 = true;
            }
          }
        }
      }
    }
    if (flag1)
    {
      if (_GenericModelElementList == null)
        return;
      for (int index = 0; index < _GenericModelElementList.Count; ++index)
      {
        Document _CurrentDocument = document;
        KeyValuePair<string, FamilyInstance> keyValuePair = _GenericModelElementList[index];
        string key = keyValuePair.Key;
        keyValuePair = _GenericModelElementList[index];
        FamilyInstance _FamilyInstance = keyValuePair.Value;
        this.AddFamilyAssignmentToList(_CurrentDocument, key, _FamilyInstance);
      }
    }
    else
    {
      bool flag4 = false;
      List<GenericModelFamilyInstanceWrapper> familyInstanceWrapperList = (List<GenericModelFamilyInstanceWrapper>) null;
      List<FamilyInstance> _DeleteFamilyInstanceList = (List<FamilyInstance>) null;
      List<ElementId> _DeletedElementsList = new List<ElementId>();
      foreach (ElementId deletedElementId in (IEnumerable<ElementId>) _Data.GetDeletedElementIds())
        _DeletedElementsList.Add(deletedElementId);
      for (int index4 = 0; index4 < _DeletedElementsList.Count; ++index4)
      {
        ElementId elementId = _DeletedElementsList[index4];
        for (int index5 = 0; index5 < this.m_GenericModelElementList.Count; ++index5)
        {
          int index6 = this.m_GenericModelElementList[index5].IndexOfContainerID(document, elementId);
          if (index6 >= 0)
          {
            bool flag5 = false;
            FamilyInstance familyInstance1 = this.m_GenericModelElementList[index5].FamilyContainerList[index6].GetFamilyInstance(document);
            if (familyInstance1 != null)
            {
              Parameter parameter = ((Element) familyInstance1).LookupParameter(RevitParameters.PlacementTypeGenericFamilyParameter);
              if (parameter != null)
              {
                foreach (int num in Enum.GetValues(typeof (PlacementType)))
                {
                  if (parameter.AsInteger() == num)
                  {
                    if ((PlacementType) Enum.ToObject(typeof (PlacementType), num) != PlacementType.GroveSquare)
                    {
                      if ((PlacementType) Enum.ToObject(typeof (PlacementType), num) != PlacementType.GroveTrianglular)
                        break;
                    }
                    flag5 = true;
                    break;
                  }
                }
              }
              _GenericModelElementList = !flag5 ? this.m_GenericModelElementList[index5].GetFamilyAssignmentInstanceList(document, familyInstance1) : this.m_GenericModelElementList[index5].GetFamilyAssignmentInstanceList(document);
            }
            if (_GenericModelElementList != null)
            {
              for (int index7 = _GenericModelElementList.Count - 1; index7 >= 0; --index7)
              {
                int index8 = this.m_GenericModelElementList[index5].IndexOfFamilyInstanceUniqueID(document, _GenericModelElementList[index7].Key);
                if (index8 >= 0 && (flag5 || index8 == index6))
                {
                  if (_DeleteFamilyInstanceList == null)
                    _DeleteFamilyInstanceList = new List<FamilyInstance>();
                  FamilyInstance familyInstance2 = this.m_GenericModelElementList[index5].FamilyContainerList[index8].GetFamilyInstance(document);
                  if (familyInstance2 != null && !_DeleteFamilyInstanceList.Contains(familyInstance2))
                    _DeleteFamilyInstanceList.Add(familyInstance2);
                  int index9 = _DeletedElementsList.IndexOf(((Element) _GenericModelElementList[index7].Value).Id);
                  if (index9 >= 0)
                  {
                    _DeletedElementsList.RemoveAt(index9);
                    if (index9 < index4)
                      --index4;
                  }
                  document.Delete(((Element) _GenericModelElementList[index7].Value).Id);
                  _GenericModelElementList.RemoveAt(index7);
                }
              }
            }
            this.DeleteGenericModelsFromList(document, _DeleteFamilyInstanceList, index5);
            flag4 = true;
            break;
          }
          int index10 = -1;
          if (this.m_GenericModelElementList[index5].IslandFamilyInstanceList != null && this.m_GenericModelElementList[index5].IslandFamilyInstanceList.Count > 0)
          {
            index10 = this.m_GenericModelElementList[index5].IndexOfIslandContainerID(document, elementId);
            if (index10 >= 0)
            {
              FamilyInstance familyInstance3 = this.m_GenericModelElementList[index5].IslandFamilyInstanceList[index10].GetFamilyInstance(document);
              if (familyInstance3 != null)
              {
                Parameter parameter6 = ((Element) familyInstance3).LookupParameter(RevitParameters.BoundaryIslandIDGenericFamilyParameter);
                if (parameter6 != null)
                {
                  string strB = parameter6.AsString();
                  for (int index11 = this.m_GenericModelElementList[index5].IslandFamilyInstanceList.Count - 1; index11 >= 0; --index11)
                  {
                    FamilyInstance familyInstance4 = this.m_GenericModelElementList[index5].IslandFamilyInstanceList[index11].GetFamilyInstance(document);
                    if (familyInstance4 != null)
                    {
                      Parameter parameter7 = ((Element) familyInstance4).LookupParameter(RevitParameters.BoundaryIslandIDGenericFamilyParameter);
                      if (parameter7 != null && string.Compare(parameter7.AsString(), strB, true) == 0)
                        document.Delete(((Element) familyInstance4).Id);
                    }
                  }
                }
              }
              if (familyInstanceWrapperList == null)
                familyInstanceWrapperList = new List<GenericModelFamilyInstanceWrapper>();
              bool flag6 = false;
              for (int index12 = 0; index12 < familyInstanceWrapperList.Count; ++index12)
              {
                if (familyInstanceWrapperList[index12].FamilyContainerList != null && familyInstanceWrapperList[index12].FamilyContainerList.Count != 0)
                {
                  for (int index13 = 0; index13 < familyInstanceWrapperList[index12].FamilyContainerList.Count; ++index13)
                  {
                    if (this.m_GenericModelElementList[index5].IndexOfContainerID(document, familyInstanceWrapperList[index12].FamilyContainerList[index13].ID) >= 0)
                    {
                      flag6 = true;
                      break;
                    }
                  }
                  if (flag6)
                    break;
                }
              }
              if (!flag6)
                familyInstanceWrapperList.Add(this.m_GenericModelElementList[index5]);
              flag4 = true;
              break;
            }
          }
          if (index10 < 0 && this.m_GenericModelElementList[index5].IndexOfFamilyAssignmentInstanceID(document, elementId) >= 0)
          {
            FamilyInstance existingFamilyInstance = this.m_GenericModelElementList[index5].GetFirstExistingFamilyInstance(document);
            if (existingFamilyInstance != null)
            {
              int _nFamilyDeletedCount = -1;
              bool assignmentDeletedList = this.m_GenericModelElementList[index5].GetFamilyAssignmentDeletedList(document, ref _DeletedElementsList, ref _nFamilyDeletedCount);
              if (_nFamilyDeletedCount > 0)
              {
                if (index4 >= _nFamilyDeletedCount)
                  index4 -= _nFamilyDeletedCount;
                if (assignmentDeletedList)
                {
                  this.DeleteGenericModelFromList(document, existingFamilyInstance, index5);
                  flag4 = true;
                  break;
                }
                break;
              }
              break;
            }
            break;
          }
        }
      }
      List<string> _GenericModelAlreadyModified = new List<string>();
      if (flag4)
      {
        if (familyInstanceWrapperList == null)
          return;
        for (int index = 0; index < familyInstanceWrapperList.Count; ++index)
        {
          if (familyInstanceWrapperList[index].FamilyContainerList != null && familyInstanceWrapperList[index].FamilyContainerList.Count > 0)
          {
            Element firstExistingElement = familyInstanceWrapperList[index].GetFirstExistingElement(document);
            if (firstExistingElement != null && firstExistingElement.Location is LocationCurve)
              this.ModifyPlacement(document, firstExistingElement, familyInstanceWrapperList[index].GetFirstExistingFamilyInstance(document), familyInstanceWrapperList[index], ref _GenericModelElementList, ref _FamilyQueryLocateTyoeList, ref _GenericModelAlreadyModified);
          }
        }
      }
      else
      {
        foreach (ElementId modifiedElementId in (IEnumerable<ElementId>) _Data.GetModifiedElementIds())
        {
          LocationCurve location = document.GetElement(modifiedElementId).Location as LocationCurve;
          Curve curve = (Curve) null;
          if (location != null)
            curve = location.Curve;
          if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
          {
            for (int index14 = 0; index14 < this.m_GenericModelElementList.Count; ++index14)
            {
              int index15 = this.m_GenericModelElementList[index14].IndexOfContainerID(document, modifiedElementId);
              if (index15 >= 0)
                this.ModifyPlacement(document, this.m_GenericModelElementList[index14].GetFirstExistingElement(document, this.m_GenericModelElementList[index14].FamilyContainerList[index15].ID), this.m_GenericModelElementList[index14].GetFirstExistingFamilyInstance(document, this.m_GenericModelElementList[index14].FamilyContainerList[index15].ID), this.m_GenericModelElementList[index14], ref _GenericModelElementList, ref _FamilyQueryLocateTyoeList, ref _GenericModelAlreadyModified);
              else if (this.m_GenericModelElementList[index14].IndexOfIslandContainerID(document, modifiedElementId) >= 0)
                this.ModifyPlacement(document, this.m_GenericModelElementList[index14].GetFirstExistingElement(document), this.m_GenericModelElementList[index14].GetFirstExistingFamilyInstance(document), this.m_GenericModelElementList[index14], ref _GenericModelElementList, ref _FamilyQueryLocateTyoeList, ref _GenericModelAlreadyModified);
            }
          }
        }
      }
    }
  }

  private void ModifyPlacement(
    Document _CurrentDocument,
    Element _CurrentElement,
    FamilyInstance _CurFamilyInstance,
    GenericModelFamilyInstanceWrapper _CurGenericModelPlantContainer,
    ref List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList,
    ref List<LocateType> _FamilyQueryLocateTyoeList,
    ref List<string> _GenericModelAlreadyModified)
  {
    if (_CurrentElement == null || _CurFamilyInstance == null || _CurGenericModelPlantContainer.FamilyContainerList == null || _CurGenericModelPlantContainer.FamilyContainerList.Count == 0)
      return;
    for (int index = 0; index < _CurGenericModelPlantContainer.FamilyContainerList.Count; ++index)
    {
      FamilyInstance familyInstance = _CurGenericModelPlantContainer.FamilyContainerList[index].GetFamilyInstance(_CurrentDocument);
      if (familyInstance != null && _GenericModelAlreadyModified.Contains(((Element) familyInstance).UniqueId))
        return;
    }
    FamilySymbol _FamilySymbol1 = (FamilySymbol) null;
    LocateType _LocateType = LocateType.Plant;
    Parameter parameter1 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
    if (parameter1 != null)
    {
      foreach (int num in Enum.GetValues(typeof (LocateType)))
      {
        if (parameter1.AsInteger() == num)
        {
          _LocateType = (LocateType) Enum.ToObject(typeof (LocateType), num);
          break;
        }
      }
    }
    Parameter parameter2 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
    if (parameter2 != null)
      this.GetFamilySymbolList(_CurrentDocument, _LocateType, parameter2.AsString(), ref _FamilySymbol1);
    if (_FamilyQueryLocateTyoeList == null)
      _FamilyQueryLocateTyoeList = new List<LocateType>();
    if (_GenericModelElementList == null || _GenericModelElementList.Count == 0 || !_FamilyQueryLocateTyoeList.Contains(_LocateType))
    {
      this.GetFamilyInstanceList(_CurrentDocument, _LocateType, ref _GenericModelElementList);
      if (!_FamilyQueryLocateTyoeList.Contains(_LocateType))
        _FamilyQueryLocateTyoeList.Add(_LocateType);
    }
    if (_FamilySymbol1 == null)
      return;
    Parameter parameter3 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.IsSingleSegmentGenericFamilyParameter);
    if (parameter3 == null)
      return;
    bool boolean = Convert.ToBoolean(parameter3.AsInteger());
    Eps_Leg _CurrentLeg = (Eps_Leg) null;
    PlacementSettings _PlacementSettings = new PlacementSettings();
    Parameter parameter4 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.HeightGenericFamilyParameter);
    if (parameter4 != null)
      _PlacementSettings.Height = !RevitDefines.GE(parameter4.AsDouble(), 1E-05) ? 1.0 : parameter4.AsDouble();
    Parameter parameter5 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.HeightVarianceGenericFamilyParameter);
    if (parameter5 != null)
      _PlacementSettings.HeightVariance = parameter5.AsDouble();
    Parameter parameter6 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.WidthGenericFamilyParameter);
    if (parameter6 != null)
      _PlacementSettings.Width = !RevitDefines.GE(parameter6.AsDouble(), 1E-05) ? 1.0 : parameter6.AsDouble();
    Parameter parameter7 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.WidthVarianceGenericFamilyParameter);
    if (parameter7 != null)
      _PlacementSettings.WidthVariance = parameter7.AsDouble();
    Parameter parameter8 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.SpacingGenericFamilyParameter);
    if (parameter8 != null)
      _PlacementSettings.PlantSpacing = parameter8.AsDouble();
    Parameter parameter9 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.SetbackGenericFamilyParameter);
    if (parameter9 != null)
      _PlacementSettings.SetbackSpacing = parameter9.AsDouble();
    Parameter parameter10 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.GroveRotationGenericFamilyParameter);
    if (parameter10 != null)
      _PlacementSettings.RotationAngle = parameter10.AsDouble();
    Parameter parameter11 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.PlacementTypeGenericFamilyParameter);
    if (parameter11 != null)
    {
      foreach (int num in Enum.GetValues(typeof (PlacementType)))
      {
        if (parameter11.AsInteger() == num)
        {
          _PlacementSettings.PlacementType = (PlacementType) Enum.ToObject(typeof (PlacementType), num);
          break;
        }
      }
    }
    Parameter parameter12 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
    if (parameter12 != null)
      _PlacementSettings.UseRightSide = Convert.ToBoolean(parameter12.AsInteger());
    Parameter parameter13 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.AlignToGenericFamilyParameter);
    if (parameter13 != null)
      _PlacementSettings.AlignTo = Convert.ToBoolean(parameter13.AsInteger());
    Parameter parameter14 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.StartingDistanceGenericFamilyParameter);
    if (parameter14 != null)
      _PlacementSettings.StartingDistance = parameter14.AsDouble();
    _PlacementSettings.Type = _FamilySymbol1;
    if (ElementId.op_Inequality(((Element) _CurFamilyInstance).LevelId, (ElementId) null))
      _PlacementSettings.Level = (Level) _CurrentDocument.GetElement(((Element) _CurFamilyInstance).LevelId);
    Parameter parameter15 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.ToposurfaceIDFamilyParameter);
    if (parameter15 != null)
    {
      string _strFormUniqueId = parameter15.AsString();
      if (!string.IsNullOrEmpty(_strFormUniqueId))
      {
        TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(_CurrentDocument, _strFormUniqueId);
        TopographySurfaceContainer surfaceContainer = new TopographySurfaceContainer(_CurrentDocument.Application, topoSurfaceInstance);
        if (_PlacementSettings.SurfaceList == null)
          _PlacementSettings.SurfaceList = new List<TopographySurfaceContainer>();
        _PlacementSettings.SurfaceList.Add(surfaceContainer);
      }
    }
    if (_LocateType == LocateType.ParkingLot)
    {
      Parameter parameter16 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.ADAStallWidthGenericModelFamilyParameter);
      if (parameter16 != null)
        _PlacementSettings.Parking.ADAStallWidth = parameter16.AsDouble();
      Parameter parameter17 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.ADAStallCountGenericModelFamilyParameter);
      if (parameter17 != null)
        _PlacementSettings.Parking.ADAStallCount = parameter17.AsInteger();
      Parameter parameter18 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.BumperHeightGenericModelFamilyParameter);
      if (parameter18 != null)
        _PlacementSettings.Parking.BumperHeight = parameter18.AsDouble();
      Parameter parameter19 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.BumperWidthGenericModelFamilyParameter);
      if (parameter19 != null)
        _PlacementSettings.Parking.BumperWidth = parameter19.AsDouble();
      Parameter parameter20 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.BumperOffsetGenericModelFamilyParameter);
      if (parameter20 != null)
        _PlacementSettings.Parking.BumperOffset = parameter20.AsDouble();
      Parameter parameter21 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.BumperSetbackGenericModelFamilyParameter);
      if (parameter21 != null)
        _PlacementSettings.Parking.BumperSetback = parameter21.AsDouble();
      Parameter parameter22 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.IslandHeightGenericModelFamilyParameter);
      if (parameter22 != null)
        _PlacementSettings.Parking.IslandHeight = parameter22.AsDouble();
      Parameter parameter23 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.IslandWidthGenericModelFamilyParameter);
      if (parameter23 != null)
        _PlacementSettings.Parking.IslandWidth = parameter23.AsDouble();
      Parameter parameter24 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.StallLengthGenericModelFamilyParameter);
      if (parameter24 != null)
        _PlacementSettings.Parking.StallLength = parameter24.AsDouble();
      Parameter parameter25 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.AreaDistanceBetweenCenterlinesGenericModelFamilyParameter);
      if (parameter25 != null)
        _PlacementSettings.Parking.AreaDistanceBetweenCenterlines = parameter25.AsDouble();
      Parameter parameter26 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.AreaAisleWidthGenericModelFamilyParameter);
      if (parameter26 != null)
        _PlacementSettings.Parking.AreaAisleWidth = parameter26.AsDouble();
      Parameter parameter27 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.PlaceIslandGenericModelFamilyParameter);
      if (parameter27 != null)
        _PlacementSettings.Parking.PlaceIsland = Convert.ToBoolean(parameter27.AsInteger());
      Parameter parameter28 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.PlaceBumperGenericModelFamilyParameter);
      if (parameter28 != null)
        _PlacementSettings.Parking.PlaceBumper = Convert.ToBoolean(parameter28.AsInteger());
      Parameter parameter29 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.OptimizeParkingGenericModelFamilyParameter);
      if (parameter29 != null)
        _PlacementSettings.Parking.OptimizeParking = Convert.ToBoolean(parameter29.AsInteger());
      Parameter parameter30 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.AreaBidirectionalAislesGenericModelFamilyParameter);
      if (parameter30 != null)
        _PlacementSettings.Parking.AreaBiDirectionalAisles = Convert.ToBoolean(parameter30.AsInteger());
      Parameter parameter31 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.StallCountGenericModelFamilyParameter);
      if (parameter31 != null)
        _PlacementSettings.Parking.StallCount = parameter31.AsInteger();
      Parameter parameter32 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.AreaRowCountGenericModelFamilyParameter);
      if (parameter32 != null)
        _PlacementSettings.Parking.AreaRowCount = parameter32.AsInteger();
      Parameter parameter33 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.AreaRowSpacingOptionsGenericModelFamilyParameter);
      if (parameter33 != null)
        _PlacementSettings.Parking.AreaRowSpacingOptions = parameter33.AsInteger();
      Parameter parameter34 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.ADAStallSymbolIDGenericFamilyParameter);
      if (parameter34 != null)
      {
        FamilySymbol _FamilySymbol2 = (FamilySymbol) null;
        this.GetFamilySymbolList(_CurrentDocument, _LocateType, parameter34.AsString(), ref _FamilySymbol2);
        if (_FamilySymbol2 != null)
          _PlacementSettings.Parking.ADAStallSymbol = _FamilySymbol2;
      }
      Parameter parameter35 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.IslandSymbolIDGenericFamilyParameter);
      if (parameter35 != null)
      {
        FamilySymbol _FamilySymbol3 = (FamilySymbol) null;
        this.GetFamilySymbolList(_CurrentDocument, _LocateType, parameter35.AsString(), ref _FamilySymbol3);
        if (_FamilySymbol3 != null)
          _PlacementSettings.Parking.IslandSymbol = _FamilySymbol3;
      }
      Parameter parameter36 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.BumperSymbolIDGenericFamilyParameter);
      if (parameter36 != null)
      {
        FamilySymbol _FamilySymbol4 = (FamilySymbol) null;
        this.GetFamilySymbolList(_CurrentDocument, _LocateType, parameter36.AsString(), ref _FamilySymbol4);
        if (_FamilySymbol4 != null)
          _PlacementSettings.Parking.BumperSymbol = _FamilySymbol4;
      }
      Parameter parameter37 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.MiddleStallPlacementGenericFamilyParameter);
      if (parameter37 != null)
        _PlacementSettings.Parking.MiddleStallPlacement = Convert.ToBoolean(parameter37.AsInteger());
      Parameter parameter38 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.ADAStallSharedAccessibleAisleGenericModelFamilyParameter);
      if (parameter38 != null)
        _PlacementSettings.Parking.ADAStallSharedAccessibleAisle = Convert.ToBoolean(parameter38.AsInteger());
    }
    if (boolean)
      _CurrentLeg = RevitGeometry.GetLegFromElementList((Eps_Leg) null, _CurrentElement);
    List<FamilyInstance> _FamilyInstanceList = new List<FamilyInstance>();
    List<FamilyInstance> _ParkingADAStallInstanceList = new List<FamilyInstance>();
    List<FamilyInstance> _ParkingBumperInstanceList = new List<FamilyInstance>();
    List<FamilyInstance> _ParkingIslandInstanceList = new List<FamilyInstance>();
    if (_CurrentLeg != null)
    {
      switch (_LocateType)
      {
        case LocateType.Plant:
          this.UpdateFamilyListsAndSettings(_CurrentDocument, _LocateType, _CurGenericModelPlantContainer.FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList);
          this.PlacePlantsOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings);
          break;
        case LocateType.Component:
          this.UpdateFamilyListsAndSettings(_CurrentDocument, _LocateType, _CurGenericModelPlantContainer.FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList);
          this.PlaceComponentsOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings);
          break;
        case LocateType.Fence:
          this.UpdateFamilyListsAndSettings(_CurrentDocument, _LocateType, _CurGenericModelPlantContainer.FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList);
          this.PlaceFenceOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _PlacementSettings);
          break;
        case LocateType.ParkingLot:
          this.UpdateFamilyListsAndSettings(_CurrentDocument, _LocateType, _CurGenericModelPlantContainer.FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList, ref _ParkingADAStallInstanceList, ref _ParkingBumperInstanceList, ref _ParkingIslandInstanceList);
          this.PlaceParkingStallsOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _ParkingADAStallInstanceList, _ParkingBumperInstanceList, _PlacementSettings);
          break;
      }
    }
    else
    {
      for (int index = _GenericModelElementList.Count - 1; index >= 0; --index)
      {
        KeyValuePair<string, FamilyInstance> keyValuePair = _GenericModelElementList[index];
        if (string.Compare(keyValuePair.Key, ((Element) _CurFamilyInstance).UniqueId, true) == 0)
        {
          if (_LocateType == LocateType.ParkingLot)
          {
            keyValuePair = _GenericModelElementList[index];
            if (keyValuePair.Value.Symbol != null)
            {
              keyValuePair = _GenericModelElementList[index];
              Parameter parameter39 = ((Element) keyValuePair.Value.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
              if (parameter39 != null)
              {
                string strA1 = parameter39.AsString();
                int int32 = Convert.ToInt32((object) LandcaddID.ParkingStall);
                string strB1 = int32.ToString("000");
                if (string.Compare(strA1, strB1, true) == 0)
                {
                  List<FamilyInstance> familyInstanceList = _FamilyInstanceList;
                  keyValuePair = _GenericModelElementList[index];
                  FamilyInstance familyInstance = keyValuePair.Value;
                  familyInstanceList.Add(familyInstance);
                  goto label_136;
                }
                string strA2 = parameter39.AsString();
                int32 = Convert.ToInt32((object) LandcaddID.ADAParkingStall);
                string strB2 = int32.ToString("000");
                if (string.Compare(strA2, strB2, true) == 0)
                {
                  List<FamilyInstance> familyInstanceList = _ParkingADAStallInstanceList;
                  keyValuePair = _GenericModelElementList[index];
                  FamilyInstance familyInstance = keyValuePair.Value;
                  familyInstanceList.Add(familyInstance);
                  goto label_136;
                }
                string strA3 = parameter39.AsString();
                int32 = Convert.ToInt32((object) LandcaddID.ParkingBumper);
                string strB3 = int32.ToString("000");
                if (string.Compare(strA3, strB3, true) == 0)
                {
                  List<FamilyInstance> familyInstanceList = _ParkingBumperInstanceList;
                  keyValuePair = _GenericModelElementList[index];
                  FamilyInstance familyInstance = keyValuePair.Value;
                  familyInstanceList.Add(familyInstance);
                  goto label_136;
                }
                string strA4 = parameter39.AsString();
                int32 = Convert.ToInt32((object) LandcaddID.ParkingIsland);
                string strB4 = int32.ToString("000");
                if (string.Compare(strA4, strB4, true) == 0)
                {
                  List<FamilyInstance> familyInstanceList = _ParkingIslandInstanceList;
                  keyValuePair = _GenericModelElementList[index];
                  FamilyInstance familyInstance = keyValuePair.Value;
                  familyInstanceList.Add(familyInstance);
                  goto label_136;
                }
                goto label_136;
              }
              goto label_136;
            }
          }
          List<FamilyInstance> familyInstanceList1 = _FamilyInstanceList;
          keyValuePair = _GenericModelElementList[index];
          FamilyInstance familyInstance1 = keyValuePair.Value;
          familyInstanceList1.Add(familyInstance1);
label_136:
          _GenericModelElementList.RemoveAt(index);
        }
      }
      _GenericModelAlreadyModified.Add(((Element) _CurFamilyInstance).UniqueId);
      if (_PlacementSettings.GenericModelIDList == null)
        _PlacementSettings.GenericModelIDList = new List<KeyValuePair<string, string>>();
      _PlacementSettings.GenericModelIDList.Add(new KeyValuePair<string, string>(_CurrentElement.UniqueId, ((Element) _CurFamilyInstance).UniqueId));
      Parameter parameter40 = ((Element) _CurFamilyInstance).LookupParameter(RevitParameters.IsReverseGenericFamilyParameter);
      if (parameter40 != null)
        _PlacementSettings.IsReverse = Convert.ToBoolean(parameter40.AsInteger());
      Curve curve = (_CurrentElement.Location as LocationCurve).Curve;
      switch (curve)
      {
        case Arc _:
          Arc _Arc = (Arc) curve;
          switch (_LocateType)
          {
            case LocateType.Plant:
              this.PlacePlantsOnArc(_CurrentDocument, _CurrentElement, _Arc, _FamilyInstanceList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings);
              return;
            case LocateType.Component:
              this.PlaceComponentsOnArc(_CurrentDocument, _CurrentElement, _Arc, _FamilyInstanceList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings);
              return;
            case LocateType.Fence:
              this.PlaceFenceOnArc(_CurrentDocument, _CurrentElement, _Arc, _FamilyInstanceList, _PlacementSettings);
              return;
            case LocateType.ParkingLot:
              this.PlaceParkingStallsOnArc(_CurrentDocument, _CurrentElement, _Arc, _FamilyInstanceList, _ParkingADAStallInstanceList, _ParkingBumperInstanceList, _PlacementSettings);
              return;
            default:
              return;
          }
        case Line _:
          Line _Line = (Line) curve;
          switch (_LocateType)
          {
            case LocateType.Plant:
              this.PlacePlantsOnLine(_CurrentDocument, _CurrentElement, _Line, _FamilyInstanceList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings);
              return;
            case LocateType.Component:
              this.PlaceComponentsOnLine(_CurrentDocument, _CurrentElement, _Line, _FamilyInstanceList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings);
              return;
            case LocateType.Fence:
              this.PlaceFenceOnLine(_CurrentDocument, _CurrentElement, _Line, _FamilyInstanceList, _PlacementSettings);
              return;
            case LocateType.ParkingLot:
              this.PlaceParkingStallsOnLine(_CurrentDocument, _CurrentElement, _Line, _FamilyInstanceList, _ParkingADAStallInstanceList, _ParkingBumperInstanceList, _ParkingIslandInstanceList, _PlacementSettings);
              return;
            default:
              return;
          }
        case Ellipse _:
        case NurbSpline _:
        case HermiteSpline _:
          switch (_LocateType)
          {
            case LocateType.Plant:
              this.PlacePlantsOnSpline(_CurrentDocument, curve, _CurrentElement, _FamilyInstanceList, _CurGenericModelPlantContainer.FamilyContainerList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings, ref _GenericModelElementList, ref _GenericModelAlreadyModified);
              return;
            case LocateType.Component:
              this.PlaceComponentsOnSpline(_CurrentDocument, curve, _CurrentElement, _FamilyInstanceList, _CurGenericModelPlantContainer.FamilyContainerList, _CurGenericModelPlantContainer.IslandFamilyInstanceList, _PlacementSettings, ref _GenericModelElementList, ref _GenericModelAlreadyModified);
              return;
            case LocateType.Fence:
              this.PlaceFenceOnSpline(_CurrentDocument, curve, _CurrentElement, _FamilyInstanceList, _CurGenericModelPlantContainer.FamilyContainerList, _PlacementSettings, ref _GenericModelElementList, ref _GenericModelAlreadyModified);
              return;
            default:
              return;
          }
      }
    }
  }

  private void UpdateFamilyListsAndSettings(
    Document _CurrentDocument,
    LocateType _LocateType,
    List<GenericModelFamilyInstanceContainer> PlantContainerList,
    ref Eps_Leg _CurrentLeg,
    ref List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList,
    ref List<string> _GenericModelAlreadyModified,
    ref PlacementSettings _PlacementSettings,
    ref List<FamilyInstance> _FamilyInstanceList)
  {
    List<FamilyInstance> _ParkingADAStallInstanceList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ParkingBumperInstanceList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ParkingIslandInstanceList = (List<FamilyInstance>) null;
    this.UpdateFamilyListsAndSettings(_CurrentDocument, _LocateType, PlantContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList, ref _ParkingADAStallInstanceList, ref _ParkingBumperInstanceList, ref _ParkingIslandInstanceList);
  }

  private void UpdateFamilyListsAndSettings(
    Document _CurrentDocument,
    LocateType _LocateType,
    List<GenericModelFamilyInstanceContainer> _ContainerList,
    ref Eps_Leg _CurrentLeg,
    ref List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList,
    ref List<string> _GenericModelAlreadyModified,
    ref PlacementSettings _PlacementSettings,
    ref List<FamilyInstance> _FamilyInstanceList,
    ref List<FamilyInstance> _ParkingADAStallInstanceList,
    ref List<FamilyInstance> _ParkingBumperInstanceList,
    ref List<FamilyInstance> _ParkingIslandInstanceList)
  {
    FamilyInstance familyInstance1 = (FamilyInstance) null;
    Parameter parameter1 = (Parameter) null;
    for (int index1 = 0; index1 < _ContainerList.Count; ++index1)
    {
      for (int index2 = _GenericModelElementList.Count - 1; index2 >= 0; --index2)
      {
        FamilyInstance familyInstance2 = _ContainerList[index1].GetFamilyInstance(_CurrentDocument);
        if (familyInstance2 != null)
        {
          KeyValuePair<string, FamilyInstance> keyValuePair = _GenericModelElementList[index2];
          if (string.Compare(keyValuePair.Key, ((Element) familyInstance2).UniqueId, true) == 0)
          {
            if (_LocateType == LocateType.ParkingLot)
            {
              keyValuePair = _GenericModelElementList[index2];
              if (keyValuePair.Value.Symbol != null)
              {
                keyValuePair = _GenericModelElementList[index2];
                Parameter parameter2 = ((Element) keyValuePair.Value.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
                if (parameter2 != null)
                {
                  string strA1 = parameter2.AsString();
                  int int32 = Convert.ToInt32((object) LandcaddID.ParkingStall);
                  string strB1 = int32.ToString("000");
                  if (string.Compare(strA1, strB1, true) == 0)
                  {
                    List<FamilyInstance> familyInstanceList = _FamilyInstanceList;
                    keyValuePair = _GenericModelElementList[index2];
                    FamilyInstance familyInstance3 = keyValuePair.Value;
                    familyInstanceList.Add(familyInstance3);
                    goto label_16;
                  }
                  string strA2 = parameter2.AsString();
                  int32 = Convert.ToInt32((object) LandcaddID.ADAParkingStall);
                  string strB2 = int32.ToString("000");
                  if (string.Compare(strA2, strB2, true) == 0)
                  {
                    List<FamilyInstance> familyInstanceList = _ParkingADAStallInstanceList;
                    keyValuePair = _GenericModelElementList[index2];
                    FamilyInstance familyInstance4 = keyValuePair.Value;
                    familyInstanceList.Add(familyInstance4);
                    goto label_16;
                  }
                  string strA3 = parameter2.AsString();
                  int32 = Convert.ToInt32((object) LandcaddID.ParkingBumper);
                  string strB3 = int32.ToString("000");
                  if (string.Compare(strA3, strB3, true) == 0)
                  {
                    List<FamilyInstance> familyInstanceList = _ParkingBumperInstanceList;
                    keyValuePair = _GenericModelElementList[index2];
                    FamilyInstance familyInstance5 = keyValuePair.Value;
                    familyInstanceList.Add(familyInstance5);
                    goto label_16;
                  }
                  string strA4 = parameter2.AsString();
                  int32 = Convert.ToInt32((object) LandcaddID.ParkingIsland);
                  string strB4 = int32.ToString("000");
                  if (string.Compare(strA4, strB4, true) == 0)
                  {
                    List<FamilyInstance> familyInstanceList = _ParkingIslandInstanceList;
                    keyValuePair = _GenericModelElementList[index2];
                    FamilyInstance familyInstance6 = keyValuePair.Value;
                    familyInstanceList.Add(familyInstance6);
                    goto label_16;
                  }
                  goto label_16;
                }
                goto label_16;
              }
            }
            List<FamilyInstance> familyInstanceList1 = _FamilyInstanceList;
            keyValuePair = _GenericModelElementList[index2];
            FamilyInstance familyInstance7 = keyValuePair.Value;
            familyInstanceList1.Add(familyInstance7);
label_16:
            _GenericModelElementList.RemoveAt(index2);
          }
        }
      }
    }
    List<KeyValuePair<string, string>> keyValuePairList = (List<KeyValuePair<string, string>>) null;
    parameter1 = (Parameter) null;
    int num1 = 0;
    int num2 = -1;
    int num3 = -1;
    string str = string.Empty;
    for (Eps_Leg epsLeg = _CurrentLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Element != null)
      {
        for (int index = 0; index < _ContainerList.Count; ++index)
        {
          FamilyInstance familyInstance8 = _ContainerList[index].GetFamilyInstance(_CurrentDocument);
          if (familyInstance8 != null)
          {
            Parameter parameter3 = ((Element) familyInstance8).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
            if (parameter3 != null && string.Compare(epsLeg.Element.UniqueId, parameter3.AsString(), true) == 0)
            {
              Parameter parameter4 = ((Element) familyInstance8).LookupParameter(RevitParameters.IsFirstPlacementSegmentGenericFamilyParameter);
              if (parameter4 != null && Convert.ToBoolean(parameter4.AsInteger()))
              {
                str = parameter3.AsString();
                Parameter parameter5 = ((Element) familyInstance8).LookupParameter(RevitParameters.IsReverseGenericFamilyParameter);
                if (parameter5 != null)
                  _PlacementSettings.IsReverse = Convert.ToBoolean(parameter5.AsInteger());
              }
              if (num2 == -1 || num3 == -1)
              {
                Parameter parameter6 = ((Element) familyInstance8).LookupParameter(RevitParameters.IsFirstLegSegmentGenericFamilyParameter);
                if (parameter6 != null && Convert.ToBoolean(parameter6.AsInteger()))
                  num2 = num1;
                Parameter parameter7 = ((Element) familyInstance8).LookupParameter(RevitParameters.IsLastLegSegmentGenericFamilyParameter);
                if (parameter7 != null && Convert.ToBoolean(parameter7.AsInteger()))
                  num3 = num1;
              }
              if (keyValuePairList == null)
                keyValuePairList = new List<KeyValuePair<string, string>>();
              keyValuePairList.Add(new KeyValuePair<string, string>(parameter3.AsString(), ((Element) familyInstance8).UniqueId));
              _GenericModelAlreadyModified.Add(((Element) familyInstance8).UniqueId);
              break;
            }
          }
        }
        ++num1;
      }
    }
    if (num3 <= 0 && num2 == num1 - 1)
      _CurrentLeg = _CurrentLeg.Reverse();
    _PlacementSettings.GenericModelIDList = keyValuePairList;
    _PlacementSettings.FirstPlacementSegmentID = str;
    List<Element> list1 = ((IEnumerable<Element>) new FilteredElementCollector(_CurrentDocument).OfClass(typeof (Group)).OfCategory((BuiltInCategory) -2000095)).ToList<Element>();
    List<Group> groupList = new List<Group>();
    familyInstance1 = (FamilyInstance) null;
    bool flag = false;
    foreach (Element element1 in list1)
    {
      if (element1 is Group group && ((Element) group).Category != null)
      {
        foreach (ElementId memberId in (IEnumerable<ElementId>) group.GetMemberIds())
        {
          if (_CurrentDocument.GetElement(memberId) is FamilyInstance element2)
          {
            for (int index = 0; index < _FamilyInstanceList.Count; ++index)
            {
              if (string.Compare(((Element) element2).UniqueId, ((Element) _FamilyInstanceList[index]).UniqueId) == 0)
              {
                if (!flag)
                {
                  flag = true;
                  groupList.Add(group);
                }
                _FamilyInstanceList.RemoveAt(index);
                _PlacementSettings.PlaceGroupTagChecked = true;
                break;
              }
            }
          }
        }
        flag = false;
      }
    }
    for (int index = 0; index < groupList.Count; ++index)
    {
      List<ElementId> list2 = groupList[index].UngroupMembers().ToList<ElementId>();
      if (list2 != null && list2.Count > 0)
        _CurrentDocument.Delete((ICollection<ElementId>) list2);
    }
  }

  private void PlacePlantsOnLine(
    Document _CurrentDocument,
    Element _CurrentElement,
    Line _Line,
    List<FamilyInstance> _PlantFamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlantPlacementSettings)
  {
    if (_PlantPlacementSettings.PlacementType == PlacementType.Single)
    {
      Eps_Point _MidPoint = new Eps_Point();
      EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(new Eps_Point(((Curve) _Line).GetEndPoint(0)), new Eps_Point(((Curve) _Line).GetEndPoint(1)), ref _MidPoint);
      PlantCommon.PlaceSingleOnPoint(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, _MidPoint, _PlantFamilyInstanceList[0]);
    }
    else
    {
      if (_PlantPlacementSettings.PlacementType != PlacementType.HedgeRowCenter && _PlantPlacementSettings.PlacementType != PlacementType.HedgeRowAlternate && _PlantPlacementSettings.PlacementType != PlacementType.HedgeRowSide)
        return;
      Eps_Line epsLine = new Eps_Line();
      epsLine.StartPnt = new Eps_Point(((Curve) _Line).GetEndPoint(0));
      epsLine.EndPnt = new Eps_Point(((Curve) _Line).GetEndPoint(1));
      if (_PlantPlacementSettings.IsReverse)
        epsLine = epsLine.Reverse();
      if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        PlantCommon.PlaceCenterRowOnLine(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, epsLine, _PlantFamilyInstanceList);
      else if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        PlantCommon.PlaceAltRowOnLine(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, epsLine, _PlantFamilyInstanceList);
      }
      else
      {
        Eps_Line _OffsetLine = new Eps_Line();
        if (_PlantPlacementSettings.UseRightSide)
          EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlantPlacementSettings.SetbackSpacing, 1, ref _OffsetLine);
        else
          EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlantPlacementSettings.SetbackSpacing, 2, ref _OffsetLine);
        PlantCommon.PlaceCenterRowOnLine(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, _OffsetLine, _PlantFamilyInstanceList);
      }
    }
  }

  private void PlacePlantsOnArc(
    Document _CurrentDocument,
    Element _CurrentElement,
    Arc _Arc,
    List<FamilyInstance> _PlantFamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlantPlacementSettings)
  {
    if (_PlantPlacementSettings.PlacementType == PlacementType.Single)
    {
      Eps_Point _StaOffPnt = new Eps_Point();
      if (!((Curve) _Arc).IsBound)
        _StaOffPnt = new Eps_Point(_Arc.Center);
      else
        EPShared.eplGeoE_FindStaOffPointAlongArc(new Eps_Arc(_Arc), ((Curve) _Arc).Length / 2.0, 0.0, ref _StaOffPnt);
      PlantCommon.PlaceSingleOnPoint(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, _StaOffPnt, _PlantFamilyInstanceList[0]);
    }
    else if (_PlantPlacementSettings.PlacementType == PlacementType.GroveSquare || _PlantPlacementSettings.PlacementType == PlacementType.GroveTrianglular)
    {
      if (((Curve) _Arc).IsBound)
        return;
      Eps_Leg _BoundaryLeg = new Eps_Leg();
      _BoundaryLeg.Arc = new Eps_Arc(_Arc);
      List<Eps_Leg> _IslandList = new List<Eps_Leg>();
      this.GetIslandList(_CurrentDocument, _IslandFamilyInstanceList, ref _IslandList);
      PlantCommon.PlaceHedgeGrove(_CurrentDocument, _PlantPlacementSettings, _BoundaryLeg, _IslandList, _PlantFamilyInstanceList);
    }
    else
    {
      if (_PlantPlacementSettings.PlacementType != PlacementType.HedgeRowCenter && _PlantPlacementSettings.PlacementType != PlacementType.HedgeRowAlternate && _PlantPlacementSettings.PlacementType != PlacementType.HedgeRowSide)
        return;
      Eps_Arc epsArc = new Eps_Arc(_Arc);
      if (_PlantPlacementSettings.IsReverse)
        epsArc = epsArc.Reverse();
      if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        PlantCommon.PlaceCenterRowOnArc(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, epsArc, _PlantFamilyInstanceList);
      else if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        PlantCommon.PlaceAltRowOnArc(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, epsArc, _PlantFamilyInstanceList);
      }
      else
      {
        Eps_Arc _OffsetArc = new Eps_Arc();
        if (_PlantPlacementSettings.UseRightSide)
          EPShared.eplGeoE_ConstructOffsetArc(epsArc, _PlantPlacementSettings.SetbackSpacing, 1, ref _OffsetArc);
        else
          EPShared.eplGeoE_ConstructOffsetArc(epsArc, _PlantPlacementSettings.SetbackSpacing, 2, ref _OffsetArc);
        PlantCommon.PlaceCenterRowOnArc(_CurrentDocument, _PlantPlacementSettings, _CurrentElement, _OffsetArc, _PlantFamilyInstanceList);
      }
    }
  }

  private void PlacePlantsOnLeg(
    Document _CurrentDocument,
    Eps_Leg _CurrentLeg,
    List<FamilyInstance> _PlantFamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlantPlacementSettings)
  {
    if (_PlantPlacementSettings.PlacementType == PlacementType.Single)
      PlantCommon.PlaceSingleOnLeg(_CurrentDocument, _PlantPlacementSettings, _CurrentLeg, _PlantFamilyInstanceList[0]);
    else if (_PlantPlacementSettings.PlacementType == PlacementType.GroveSquare || _PlantPlacementSettings.PlacementType == PlacementType.GroveTrianglular)
    {
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt, 1E-05))
        return;
      List<Eps_Leg> _IslandList = new List<Eps_Leg>();
      this.GetIslandList(_CurrentDocument, _IslandFamilyInstanceList, ref _IslandList);
      PlantCommon.PlaceHedgeGrove(_CurrentDocument, _PlantPlacementSettings, _CurrentLeg, _IslandList, _PlantFamilyInstanceList);
    }
    else
    {
      if (_PlantPlacementSettings.PlacementType != PlacementType.HedgeRowCenter && _PlantPlacementSettings.PlacementType != PlacementType.HedgeRowAlternate && _PlantPlacementSettings.PlacementType != PlacementType.HedgeRowSide)
        return;
      if (_PlantPlacementSettings.GenericModelIDList != null && string.Compare(_CurrentLeg.Element.UniqueId, _PlantPlacementSettings.GenericModelIDList[0].Key, true) != 0)
        _PlantPlacementSettings.GenericModelIDList.Reverse();
      if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        PlantCommon.PlaceCenterRowOnLeg(_CurrentDocument, _PlantPlacementSettings, _CurrentLeg, _PlantFamilyInstanceList);
      else if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        PlantCommon.PlaceAltRowOnLeg(_CurrentDocument, _PlantPlacementSettings, _CurrentLeg, _PlantFamilyInstanceList);
      }
      else
      {
        Eps_Leg ppOffsetLegList = new Eps_Leg();
        if (_PlantPlacementSettings.UseRightSide)
          RevitGeometry.OffsetLegList(_CurrentLeg, _PlantPlacementSettings.SetbackSpacing, 1, ref ppOffsetLegList, true);
        else
          RevitGeometry.OffsetLegList(_CurrentLeg, _PlantPlacementSettings.SetbackSpacing, 2, ref ppOffsetLegList, true);
        PlantCommon.PlaceCenterRowOnLeg(_CurrentDocument, _PlantPlacementSettings, ppOffsetLegList, _CurrentLeg.ElementList, _PlantFamilyInstanceList);
      }
    }
  }

  private void PlacePlantsOnSpline(
    Document _CurrentDocument,
    Curve _Curve,
    Element _CurrentElement,
    List<FamilyInstance> _FamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _FamilyContainerList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlacementSettings,
    ref List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList,
    ref List<string> _GenericModelAlreadyModified)
  {
    if (_PlacementSettings.PlacementType == PlacementType.Single && _Curve is Ellipse && !_Curve.IsBound)
    {
      Ellipse ellipse = (Ellipse) _Curve;
      PlantCommon.PlaceSingleOnPoint(_CurrentDocument, _PlacementSettings, _CurrentElement, new Eps_Point(ellipse.Center), _FamilyInstanceList[0]);
    }
    else
    {
      IList<XYZ> xyzList = _Curve.Tessellate();
      int count = xyzList.Count;
      Eps_Leg _CurrentLeg = (Eps_Leg) null;
      if (count > 1)
      {
        Eps_Point epsPoint1 = new Eps_Point();
        Eps_Point epsPoint2 = new Eps_Point();
        int index;
        for (index = 0; index < count; index += 2)
        {
          Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
          if (index > 0)
          {
            Eps_Leg epsLeg = new Eps_Leg();
            epsLeg.Line = new Eps_Line();
            epsLeg.Line.StartPnt = epsPoint1;
            epsLeg.Line.EndPnt = epsPoint3;
            if (_CurrentLeg == null)
            {
              _CurrentLeg = epsLeg;
              _CurrentLeg.Element = _CurrentElement;
            }
            else
            {
              _CurrentLeg.Last.Next = epsLeg;
              _CurrentLeg.Last.Element = _CurrentElement;
            }
          }
          epsPoint1 = epsPoint3;
        }
        if (index == count)
        {
          Eps_Leg epsLeg = new Eps_Leg();
          epsLeg.Line = new Eps_Line();
          epsLeg.Line.StartPnt = epsPoint1;
          epsLeg.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
          if (_CurrentLeg == null)
          {
            _CurrentLeg = epsLeg;
            _CurrentLeg.Element = _CurrentElement;
          }
          else
          {
            _CurrentLeg.Last.Next = epsLeg;
            _CurrentLeg.Last.Element = _CurrentElement;
          }
        }
      }
      if (_CurrentLeg == null)
        return;
      this.UpdateFamilyListsAndSettings(_CurrentDocument, LocateType.Plant, _FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList);
      this.PlacePlantsOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _IslandFamilyInstanceList, _PlacementSettings);
    }
  }

  private void PlaceComponentsOnLine(
    Document _CurrentDocument,
    Element _CurrentElement,
    Line _Line,
    List<FamilyInstance> _FamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlacementSettings)
  {
    if (_PlacementSettings.PlacementType != PlacementType.HedgeRowCenter && _PlacementSettings.PlacementType != PlacementType.HedgeRowAlternate && _PlacementSettings.PlacementType != PlacementType.HedgeRowSide)
      return;
    Eps_Line epsLine = new Eps_Line();
    epsLine.StartPnt = new Eps_Point(((Curve) _Line).GetEndPoint(0));
    epsLine.EndPnt = new Eps_Point(((Curve) _Line).GetEndPoint(1));
    if (_PlacementSettings.IsReverse)
      epsLine = epsLine.Reverse();
    if (_PlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
      ComponentCommon.PlaceCenterRowOnLine(_CurrentDocument, _PlacementSettings, _CurrentElement, epsLine, _FamilyInstanceList);
    else if (_PlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
    {
      ComponentCommon.PlaceAltRowOnLine(_CurrentDocument, _PlacementSettings, _CurrentElement, epsLine, _FamilyInstanceList);
    }
    else
    {
      Eps_Line _OffsetLine = new Eps_Line();
      if (_PlacementSettings.UseRightSide)
        EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.SetbackSpacing, 1, ref _OffsetLine);
      else
        EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.SetbackSpacing, 2, ref _OffsetLine);
      ComponentCommon.PlaceCenterRowOnLine(_CurrentDocument, _PlacementSettings, _CurrentElement, _OffsetLine, _FamilyInstanceList);
    }
  }

  private void PlaceComponentsOnArc(
    Document _CurrentDocument,
    Element _CurrentElement,
    Arc _Arc,
    List<FamilyInstance> _FamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlacementSettings)
  {
    if (_PlacementSettings.PlacementType == PlacementType.GroveSquare || _PlacementSettings.PlacementType == PlacementType.GroveTrianglular)
    {
      if (((Curve) _Arc).IsBound)
        return;
      Eps_Leg _BoundaryLeg = new Eps_Leg();
      _BoundaryLeg.Arc = new Eps_Arc(_Arc);
      List<Eps_Leg> _IslandList = new List<Eps_Leg>();
      this.GetIslandList(_CurrentDocument, _IslandFamilyInstanceList, ref _IslandList);
      ComponentCommon.PlaceHedgeGrove(_CurrentDocument, _PlacementSettings, _BoundaryLeg, _IslandList, _FamilyInstanceList);
    }
    else
    {
      if (_PlacementSettings.PlacementType != PlacementType.HedgeRowCenter && _PlacementSettings.PlacementType != PlacementType.HedgeRowAlternate && _PlacementSettings.PlacementType != PlacementType.HedgeRowSide)
        return;
      Eps_Arc epsArc = new Eps_Arc(_Arc);
      if (_PlacementSettings.IsReverse)
        epsArc = epsArc.Reverse();
      if (_PlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        ComponentCommon.PlaceCenterRowOnArc(_CurrentDocument, _PlacementSettings, _CurrentElement, epsArc, _FamilyInstanceList);
      else if (_PlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        ComponentCommon.PlaceAltRowOnArc(_CurrentDocument, _PlacementSettings, _CurrentElement, epsArc, _FamilyInstanceList);
      }
      else
      {
        Eps_Arc _OffsetArc = new Eps_Arc();
        if (_PlacementSettings.UseRightSide)
          EPShared.eplGeoE_ConstructOffsetArc(epsArc, _PlacementSettings.SetbackSpacing, 1, ref _OffsetArc);
        else
          EPShared.eplGeoE_ConstructOffsetArc(epsArc, _PlacementSettings.SetbackSpacing, 2, ref _OffsetArc);
        ComponentCommon.PlaceCenterRowOnArc(_CurrentDocument, _PlacementSettings, _CurrentElement, _OffsetArc, _FamilyInstanceList);
      }
    }
  }

  private void PlaceComponentsOnLeg(
    Document _CurrentDocument,
    Eps_Leg _CurrentLeg,
    List<FamilyInstance> _FamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlacementSettings)
  {
    if (_PlacementSettings.PlacementType == PlacementType.GroveSquare || _PlacementSettings.PlacementType == PlacementType.GroveTrianglular)
    {
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt, 1E-05))
        return;
      List<Eps_Leg> _IslandList = new List<Eps_Leg>();
      this.GetIslandList(_CurrentDocument, _IslandFamilyInstanceList, ref _IslandList);
      ComponentCommon.PlaceHedgeGrove(_CurrentDocument, _PlacementSettings, _CurrentLeg, _IslandList, _FamilyInstanceList);
    }
    else
    {
      if (_PlacementSettings.PlacementType != PlacementType.HedgeRowCenter && _PlacementSettings.PlacementType != PlacementType.HedgeRowAlternate && _PlacementSettings.PlacementType != PlacementType.HedgeRowSide)
        return;
      if (_PlacementSettings.GenericModelIDList != null && string.Compare(_CurrentLeg.Element.UniqueId, _PlacementSettings.GenericModelIDList[0].Key, true) != 0)
        _PlacementSettings.GenericModelIDList.Reverse();
      if (_PlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        ComponentCommon.PlaceCenterRowOnLeg(_CurrentDocument, _PlacementSettings, _CurrentLeg, _FamilyInstanceList);
      else if (_PlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        ComponentCommon.PlaceAltRowOnLeg(_CurrentDocument, _PlacementSettings, _CurrentLeg, _FamilyInstanceList);
      }
      else
      {
        Eps_Leg ppOffsetLegList = new Eps_Leg();
        if (_PlacementSettings.UseRightSide)
          RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 1, ref ppOffsetLegList, true);
        else
          RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 2, ref ppOffsetLegList, true);
        ComponentCommon.PlaceCenterRowOnLeg(_CurrentDocument, _PlacementSettings, ppOffsetLegList, _CurrentLeg.ElementList, _FamilyInstanceList);
      }
    }
  }

  private void PlaceComponentsOnSpline(
    Document _CurrentDocument,
    Curve _Curve,
    Element _CurrentElement,
    List<FamilyInstance> _FamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _FamilyContainerList,
    List<GenericModelFamilyInstanceContainer> _IslandFamilyInstanceList,
    PlacementSettings _PlacementSettings,
    ref List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList,
    ref List<string> _GenericModelAlreadyModified)
  {
    IList<XYZ> xyzList = _Curve.Tessellate();
    int count = xyzList.Count;
    Eps_Leg _CurrentLeg = (Eps_Leg) null;
    if (count > 1)
    {
      Eps_Point epsPoint1 = new Eps_Point();
      Eps_Point epsPoint2 = new Eps_Point();
      int index;
      for (index = 0; index < count; index += 2)
      {
        Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
        if (index > 0)
        {
          Eps_Leg epsLeg = new Eps_Leg();
          epsLeg.Line = new Eps_Line();
          epsLeg.Line.StartPnt = epsPoint1;
          epsLeg.Line.EndPnt = epsPoint3;
          if (_CurrentLeg == null)
          {
            _CurrentLeg = epsLeg;
            _CurrentLeg.Element = _CurrentElement;
          }
          else
          {
            _CurrentLeg.Last.Next = epsLeg;
            _CurrentLeg.Last.Element = _CurrentElement;
          }
        }
        epsPoint1 = epsPoint3;
      }
      if (index == count)
      {
        Eps_Leg epsLeg = new Eps_Leg();
        epsLeg.Line = new Eps_Line();
        epsLeg.Line.StartPnt = epsPoint1;
        epsLeg.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
        if (_CurrentLeg == null)
        {
          _CurrentLeg = epsLeg;
          _CurrentLeg.Element = _CurrentElement;
        }
        else
        {
          _CurrentLeg.Last.Next = epsLeg;
          _CurrentLeg.Last.Element = _CurrentElement;
        }
      }
    }
    if (_CurrentLeg == null)
      return;
    this.UpdateFamilyListsAndSettings(_CurrentDocument, LocateType.Component, _FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList);
    this.PlaceComponentsOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _IslandFamilyInstanceList, _PlacementSettings);
  }

  private void PlaceFenceOnLine(
    Document _CurrentDocument,
    Element _CurrentElement,
    Line _Line,
    List<FamilyInstance> _FamilyInstanceList,
    PlacementSettings _PlacementSettings)
  {
    Eps_Line epsLine = new Eps_Line();
    epsLine.StartPnt = new Eps_Point(((Curve) _Line).GetEndPoint(0));
    epsLine.EndPnt = new Eps_Point(((Curve) _Line).GetEndPoint(1));
    if (_PlacementSettings.IsReverse)
      epsLine = epsLine.Reverse();
    if (RevitDefines.EQ(_PlacementSettings.SetbackSpacing, 0.0))
    {
      FenceCommon.PlaceCenterRowOnLine(_CurrentDocument, _PlacementSettings, _CurrentElement, epsLine, _FamilyInstanceList);
    }
    else
    {
      Eps_Line _OffsetLine = new Eps_Line();
      if (_PlacementSettings.UseRightSide)
        EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.SetbackSpacing, 1, ref _OffsetLine);
      else
        EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.SetbackSpacing, 2, ref _OffsetLine);
      FenceCommon.PlaceCenterRowOnLine(_CurrentDocument, _PlacementSettings, _CurrentElement, _OffsetLine, _FamilyInstanceList);
    }
  }

  private void PlaceFenceOnArc(
    Document _CurrentDocument,
    Element _CurrentElement,
    Arc _Arc,
    List<FamilyInstance> _FamilyInstanceList,
    PlacementSettings _PlacementSettings)
  {
    Eps_Arc epsArc = new Eps_Arc(_Arc);
    if (_PlacementSettings.IsReverse)
      epsArc = epsArc.Reverse();
    if (RevitDefines.EQ(_PlacementSettings.SetbackSpacing, 0.0))
    {
      FenceCommon.PlaceCenterRowOnArc(_CurrentDocument, _PlacementSettings, _CurrentElement, epsArc, _FamilyInstanceList);
    }
    else
    {
      Eps_Arc _OffsetArc = new Eps_Arc();
      if (_PlacementSettings.UseRightSide)
        EPShared.eplGeoE_ConstructOffsetArc(epsArc, _PlacementSettings.SetbackSpacing, 1, ref _OffsetArc);
      else
        EPShared.eplGeoE_ConstructOffsetArc(epsArc, _PlacementSettings.SetbackSpacing, 2, ref _OffsetArc);
      FenceCommon.PlaceCenterRowOnArc(_CurrentDocument, _PlacementSettings, _CurrentElement, _OffsetArc, _FamilyInstanceList);
    }
  }

  private void PlaceFenceOnLeg(
    Document _CurrentDocument,
    Eps_Leg _CurrentLeg,
    List<FamilyInstance> _FamilyInstanceList,
    PlacementSettings _PlacementSettings)
  {
    if (_PlacementSettings.GenericModelIDList != null && string.Compare(_CurrentLeg.Element.UniqueId, _PlacementSettings.GenericModelIDList[0].Key, true) != 0)
      _PlacementSettings.GenericModelIDList.Reverse();
    if (RevitDefines.EQ(_PlacementSettings.SetbackSpacing, 0.0))
    {
      FenceCommon.PlaceCenterRowOnLeg(_CurrentDocument, _PlacementSettings, _CurrentLeg, _FamilyInstanceList);
    }
    else
    {
      Eps_Leg ppOffsetLegList = new Eps_Leg();
      if (_PlacementSettings.UseRightSide)
        RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 1, ref ppOffsetLegList, true);
      else
        RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 2, ref ppOffsetLegList, true);
      FenceCommon.PlaceCenterRowOnLeg(_CurrentDocument, _PlacementSettings, ppOffsetLegList, _CurrentLeg.ElementList, _FamilyInstanceList);
    }
  }

  private void PlaceFenceOnSpline(
    Document _CurrentDocument,
    Curve _Curve,
    Element _CurrentElement,
    List<FamilyInstance> _FamilyInstanceList,
    List<GenericModelFamilyInstanceContainer> _FamilyContainerList,
    PlacementSettings _PlacementSettings,
    ref List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList,
    ref List<string> _GenericModelAlreadyModified)
  {
    IList<XYZ> xyzList = _Curve.Tessellate();
    int count = xyzList.Count;
    Eps_Leg _CurrentLeg = (Eps_Leg) null;
    if (count > 1)
    {
      Eps_Point epsPoint1 = new Eps_Point();
      Eps_Point epsPoint2 = new Eps_Point();
      int index;
      for (index = 0; index < count; index += 2)
      {
        Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
        if (index > 0)
        {
          Eps_Leg epsLeg = new Eps_Leg();
          epsLeg.Line = new Eps_Line();
          epsLeg.Line.StartPnt = epsPoint1;
          epsLeg.Line.EndPnt = epsPoint3;
          if (_CurrentLeg == null)
          {
            _CurrentLeg = epsLeg;
            _CurrentLeg.Element = _CurrentElement;
          }
          else
          {
            _CurrentLeg.Last.Next = epsLeg;
            _CurrentLeg.Last.Element = _CurrentElement;
          }
        }
        epsPoint1 = epsPoint3;
      }
      if (index == count)
      {
        Eps_Leg epsLeg = new Eps_Leg();
        epsLeg.Line = new Eps_Line();
        epsLeg.Line.StartPnt = epsPoint1;
        epsLeg.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
        if (_CurrentLeg == null)
        {
          _CurrentLeg = epsLeg;
          _CurrentLeg.Element = _CurrentElement;
        }
        else
        {
          _CurrentLeg.Last.Next = epsLeg;
          _CurrentLeg.Last.Element = _CurrentElement;
        }
      }
    }
    if (_CurrentLeg == null)
      return;
    this.UpdateFamilyListsAndSettings(_CurrentDocument, LocateType.Fence, _FamilyContainerList, ref _CurrentLeg, ref _GenericModelElementList, ref _GenericModelAlreadyModified, ref _PlacementSettings, ref _FamilyInstanceList);
    this.PlaceFenceOnLeg(_CurrentDocument, _CurrentLeg, _FamilyInstanceList, _PlacementSettings);
  }

  private void PlaceParkingStallsOnLine(
    Document _CurrentDocument,
    Element _CurrentElement,
    Line _Line,
    List<FamilyInstance> _FamilyInstanceList,
    List<FamilyInstance> _ParkingADAStallInstanceList,
    List<FamilyInstance> _ParkingBumperInstanceList,
    List<FamilyInstance> _ParkingIslandInstanceList,
    PlacementSettings _PlacementSettings)
  {
    Eps_Line _ParkingLotLine = new Eps_Line();
    _ParkingLotLine.StartPnt = new Eps_Point(((Curve) _Line).GetEndPoint(0));
    _ParkingLotLine.EndPnt = new Eps_Point(((Curve) _Line).GetEndPoint(1));
    Eps_Line _FirstLine = (Eps_Line) null;
    Eps_Line _SecondLine = (Eps_Line) null;
    if (_PlacementSettings.PlacementType == PlacementType.ParkingArea)
    {
      if (_PlacementSettings.IsReverse)
        _ParkingLotLine = _ParkingLotLine.Reverse();
      _SecondLine = _ParkingLotLine;
      _FirstLine = _ParkingLotLine;
    }
    else if (!_PlacementSettings.Parking.MiddleStallPlacement)
    {
      if (!_PlacementSettings.IsReverse)
        _SecondLine = _ParkingLotLine;
      else
        _FirstLine = _ParkingLotLine.Reverse();
    }
    else
    {
      Eps_Point _MidPoint = new Eps_Point();
      EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_ParkingLotLine.StartPnt, _ParkingLotLine.EndPnt, ref _MidPoint);
      Eps_Line epsLine1 = new Eps_Line();
      epsLine1.StartPnt = _ParkingLotLine.StartPnt;
      epsLine1.EndPnt = _MidPoint;
      if (_FirstLine == null)
        _FirstLine = epsLine1;
      Eps_Line epsLine2 = new Eps_Line();
      epsLine2.StartPnt = _MidPoint;
      epsLine2.EndPnt = _ParkingLotLine.EndPnt;
      if (_SecondLine == null)
        _SecondLine = epsLine2;
      if (_FirstLine != null)
        _FirstLine = _FirstLine.Reverse();
    }
    ParkingLotCommon.PlaceStallsOnLine(_CurrentDocument, _PlacementSettings, _CurrentElement, _ParkingLotLine, _FirstLine, _SecondLine, _PlacementSettings.IsReverse, ref _FamilyInstanceList, ref _ParkingADAStallInstanceList, ref _ParkingBumperInstanceList, ref _ParkingIslandInstanceList);
  }

  private void PlaceParkingStallsOnArc(
    Document _CurrentDocument,
    Element _CurrentElement,
    Arc _Arc,
    List<FamilyInstance> _FamilyInstanceList,
    List<FamilyInstance> _ParkingADAStallInstanceList,
    List<FamilyInstance> _ParkingBumperInstanceList,
    PlacementSettings _PlacementSettings)
  {
    Eps_Arc epsArc1 = new Eps_Arc(_Arc);
    Eps_Arc _FirstArc = (Eps_Arc) null;
    Eps_Arc _SecondArc = (Eps_Arc) null;
    if (_PlacementSettings.PlacementType == PlacementType.ParkingArea)
    {
      if (_PlacementSettings.IsReverse)
        epsArc1 = epsArc1.Reverse();
    }
    else if (!_PlacementSettings.Parking.MiddleStallPlacement)
    {
      if (!_PlacementSettings.IsReverse)
        _SecondArc = epsArc1;
      else
        _FirstArc = epsArc1.Reverse();
    }
    else
    {
      Eps_Point _StaOffPnt = new Eps_Point();
      double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsArc1.Radius, epsArc1.Delta);
      EPShared.eplGeoE_FindStaOffPointAlongArc(epsArc1, num / 2.0, 0.0, ref _StaOffPnt);
      Eps_Arc epsArc2 = new Eps_Arc(epsArc1);
      epsArc2.Delta = epsArc1.Delta / 2.0;
      epsArc2.StartPnt = epsArc1.StartPnt;
      epsArc2.EndPnt = _StaOffPnt;
      if (_FirstArc == null)
        _FirstArc = epsArc2;
      Eps_Arc epsArc3 = new Eps_Arc(epsArc1);
      epsArc3.Delta = epsArc1.Delta / 2.0;
      epsArc3.StartPnt = _StaOffPnt;
      epsArc3.EndPnt = epsArc1.EndPnt;
      if (_SecondArc == null)
        _SecondArc = epsArc3;
      if (_FirstArc != null)
        _FirstArc = _FirstArc.Reverse();
    }
    ParkingLotCommon.PlaceStallsOnArc(_CurrentDocument, _PlacementSettings, _CurrentElement, epsArc1, _FirstArc, _SecondArc, _PlacementSettings.IsReverse, ref _FamilyInstanceList, ref _ParkingADAStallInstanceList, ref _ParkingBumperInstanceList);
  }

  private void PlaceParkingStallsOnLeg(
    Document _CurrentDocument,
    Eps_Leg _CurrentLeg,
    List<FamilyInstance> _FamilyInstanceList,
    List<FamilyInstance> _ParkingADAStallInstanceList,
    List<FamilyInstance> _ParkingBumperInstanceList,
    PlacementSettings _PlacementSettings)
  {
    Eps_Leg FirstLeg = (Eps_Leg) null;
    Eps_Leg SecondLeg = (Eps_Leg) null;
    Eps_Point epsPoint = new Eps_Point();
    bool flag = false;
    for (Eps_Leg _CompleteLeg1 = _CurrentLeg; _CompleteLeg1 != null; _CompleteLeg1 = _CompleteLeg1.Next)
    {
      if (flag)
      {
        if (SecondLeg == null)
          SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
        else
          SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
      }
      else
      {
        if (string.Compare(_PlacementSettings.FirstPlacementSegmentID, _CompleteLeg1.Element.UniqueId, true) == 0)
          flag = true;
        if (_CompleteLeg1.Line != null)
        {
          if (flag && _PlacementSettings.Parking.MiddleStallPlacement)
          {
            EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_CompleteLeg1.Line.StartPnt, _CompleteLeg1.Line.EndPnt, ref epsPoint);
            Eps_Leg _CompleteLeg2 = new Eps_Leg();
            _CompleteLeg2.Line = new Eps_Line();
            _CompleteLeg2.Line.StartPnt = _CompleteLeg1.Line.StartPnt;
            _CompleteLeg2.Line.EndPnt = epsPoint;
            _CompleteLeg2.Element = _CompleteLeg1.Element;
            if (FirstLeg == null)
              FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg2);
            else
              FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
            Eps_Leg _CompleteLeg3 = new Eps_Leg();
            _CompleteLeg3.Line = new Eps_Line();
            _CompleteLeg3.Line.StartPnt = epsPoint;
            _CompleteLeg3.Line.EndPnt = _CompleteLeg1.Line.EndPnt;
            _CompleteLeg3.Element = _CompleteLeg1.Element;
            if (SecondLeg == null)
              SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg3);
            else
              SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg3);
          }
          else if (flag && !_PlacementSettings.IsReverse)
          {
            if (SecondLeg == null)
              SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
            else
              SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
          }
          else if (FirstLeg == null)
            FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
          else
            FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
        }
        else if (_CompleteLeg1.Arc != null)
        {
          if (flag && _PlacementSettings.Parking.MiddleStallPlacement)
          {
            double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_CompleteLeg1.Arc.Radius, _CompleteLeg1.Arc.Delta);
            EPShared.eplGeoE_FindStaOffPointAlongArc(_CompleteLeg1.Arc, num / 2.0, 0.0, ref epsPoint);
            Eps_Leg _CompleteLeg4 = new Eps_Leg();
            _CompleteLeg4.Arc = new Eps_Arc(_CompleteLeg1.Arc);
            _CompleteLeg4.Arc.Delta = _CompleteLeg1.Arc.Delta / 2.0;
            _CompleteLeg4.Arc.StartPnt = _CompleteLeg1.Arc.StartPnt;
            _CompleteLeg4.Arc.EndPnt = epsPoint;
            _CompleteLeg4.Element = _CompleteLeg1.Element;
            if (FirstLeg == null)
              FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg4);
            else
              FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg4);
            Eps_Leg _CompleteLeg5 = new Eps_Leg();
            _CompleteLeg5.Arc = new Eps_Arc(_CompleteLeg1.Arc);
            _CompleteLeg5.Arc.Delta = _CompleteLeg1.Arc.Delta / 2.0;
            _CompleteLeg5.Arc.StartPnt = epsPoint;
            _CompleteLeg5.Arc.EndPnt = _CompleteLeg1.Arc.EndPnt;
            _CompleteLeg5.Element = _CompleteLeg1.Element;
            if (SecondLeg == null)
              SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg5);
            else
              SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg5);
          }
          else if (flag && !_PlacementSettings.IsReverse)
          {
            if (SecondLeg == null)
              SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
            else
              SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
          }
          else if (FirstLeg == null)
            FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
          else
            FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
        }
      }
    }
    if (FirstLeg != null)
      FirstLeg = FirstLeg.Reverse();
    ParkingLotCommon.PlaceLegList(_CurrentDocument, _PlacementSettings, _CurrentLeg, FirstLeg, SecondLeg, _PlacementSettings.IsReverse, _FamilyInstanceList, _ParkingADAStallInstanceList, _ParkingBumperInstanceList);
  }

  private void GetIslandList(
    Document _CurrentDocument,
    List<GenericModelFamilyInstanceContainer> _IslandGenericModelList,
    ref List<Eps_Leg> _IslandList)
  {
    if (_IslandGenericModelList == null)
      return;
    List<ElementId> elementIdList = (List<ElementId>) null;
    for (int index = 0; index < _IslandGenericModelList.Count; ++index)
    {
      if (elementIdList == null)
        elementIdList = new List<ElementId>();
      if (!elementIdList.Contains(_IslandGenericModelList[index].ID))
        elementIdList.Add(_IslandGenericModelList[index].ID);
    }
    if (elementIdList == null)
      return;
    for (int index1 = elementIdList.Count - 1; index1 >= 0; --index1)
    {
      Element element = _CurrentDocument.GetElement(elementIdList[index1]);
      if (element == null)
        elementIdList.RemoveAt(index1);
      else if (!(element.Location is LocationCurve location))
      {
        elementIdList.RemoveAt(index1);
      }
      else
      {
        Eps_Leg legFromElementList = RevitGeometry.GetLegFromElementList((Eps_Leg) null, element);
        if (legFromElementList != null)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates2D(legFromElementList.LegStartPnt, legFromElementList.LegEndPnt, 1E-05))
            _IslandList.Add(legFromElementList);
          for (int index2 = 0; index2 < legFromElementList.ElementList.Count; ++index2)
          {
            elementIdList.Remove(legFromElementList.ElementList[index2].Id);
            if (index2 > 0)
              --index1;
          }
        }
        else
        {
          Curve curve = location.Curve;
          if (!curve.IsBound)
          {
            switch (curve)
            {
              case Arc _:
                Arc _Arc = (Arc) curve;
                _IslandList.Add(new Eps_Leg()
                {
                  Arc = new Eps_Arc(_Arc)
                });
                break;
              case Ellipse _:
              case NurbSpline _:
              case HermiteSpline _:
                IList<XYZ> xyzList = curve.Tessellate();
                int count = xyzList.Count;
                if (count > 1)
                {
                  Eps_Point epsPoint1 = new Eps_Point();
                  Eps_Point epsPoint2 = new Eps_Point();
                  Eps_Leg epsLeg1 = (Eps_Leg) null;
                  int index3;
                  for (index3 = 0; index3 < count; index3 += 2)
                  {
                    Eps_Point epsPoint3 = new Eps_Point(xyzList[index3]);
                    if (index3 > 0)
                    {
                      Eps_Leg epsLeg2 = new Eps_Leg();
                      epsLeg2.Line = new Eps_Line();
                      epsLeg2.Line.StartPnt = epsPoint1;
                      epsLeg2.Line.EndPnt = epsPoint3;
                      if (epsLeg1 == null)
                      {
                        epsLeg1 = epsLeg2;
                        epsLeg1.Element = element;
                      }
                      else
                        epsLeg1.Last.Next = epsLeg2;
                    }
                    epsPoint1 = epsPoint3;
                  }
                  if (index3 == count)
                  {
                    Eps_Leg epsLeg3 = new Eps_Leg();
                    epsLeg3.Line = new Eps_Line();
                    epsLeg3.Line.StartPnt = epsPoint1;
                    epsLeg3.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
                    if (epsLeg1 == null)
                    {
                      epsLeg1 = epsLeg3;
                      epsLeg1.Element = element;
                    }
                    else
                      epsLeg1.Last.Next = epsLeg3;
                  }
                  _IslandList.Add(epsLeg1);
                  break;
                }
                break;
            }
          }
          elementIdList.RemoveAt(index1);
        }
      }
    }
  }

  private bool IsCategoryCorrect(FamilySymbol _FamilySymbol, LocateType _LocateType)
  {
    if (_FamilySymbol != null && ((Element) _FamilySymbol).Category != null)
    {
      switch (_LocateType)
      {
        case LocateType.Plant:
          if (((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
            return true;
          break;
        case LocateType.Component:
          if (((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode() || ((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001370).GetHashCode() || ((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000080).GetHashCode() || ((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001040).GetHashCode() || ((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode() || ((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001120).GetHashCode() || ((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000100).GetHashCode())
            return true;
          break;
        case LocateType.Fence:
          if (((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
          {
            Parameter parameter = ((Element) _FamilySymbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
            if (parameter != null && string.Compare(parameter.AsString(), Convert.ToInt32((object) LandcaddID.Fence).ToString("000"), true) == 0)
              return true;
            break;
          }
          break;
        case LocateType.ParkingLot:
          if (((Element) _FamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001180).GetHashCode())
            return true;
          break;
      }
    }
    return false;
  }

  private void GetFamilyInstanceList(
    Document _CurrentDocument,
    LocateType _LocateType,
    ref List<KeyValuePair<string, FamilyInstance>> _FamilyInstanceList)
  {
    if (_FamilyInstanceList == null)
      _FamilyInstanceList = new List<KeyValuePair<string, FamilyInstance>>();
    FilteredElementCollector source = new FilteredElementCollector(_CurrentDocument);
    switch (_LocateType)
    {
      case LocateType.Plant:
        source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360);
        break;
      case LocateType.Component:
        FilteredElementCollector elementCollector1 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector2 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector3 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector4 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector5 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector6 = new FilteredElementCollector(_CurrentDocument);
        source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260).UnionWith(elementCollector1.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001370).UnionWith(elementCollector2.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000080).UnionWith(elementCollector3.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001040).UnionWith(elementCollector4.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151).UnionWith(elementCollector5.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001120).UnionWith(elementCollector6.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000100)))))));
        break;
      case LocateType.Fence:
        source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151);
        break;
      case LocateType.ParkingLot:
        source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001180);
        break;
    }
    IList<Element> list = (IList<Element>) ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.LookupParameter(RevitParameters.PlacementIDFamilyParameter) != null)).ToList<Element>();
    bool flag = false;
    foreach (Element element in (IEnumerable<Element>) list)
    {
      if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && this.IsCategoryCorrect(familyInstance.Symbol, _LocateType))
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
        if (parameter != null && parameter.AsString() != string.Empty)
        {
          for (int index = 0; index < _FamilyInstanceList.Count; ++index)
          {
            if (string.Compare(((Element) _FamilyInstanceList[index].Value).UniqueId, ((Element) familyInstance).UniqueId, true) == 0)
            {
              flag = true;
              break;
            }
          }
          if (!flag)
            _FamilyInstanceList.Add(new KeyValuePair<string, FamilyInstance>(parameter.AsString(), familyInstance));
          else
            flag = false;
        }
      }
    }
  }

  private void GetFamilySymbolList(
    Document _CurrentDocument,
    LocateType _LocateType,
    string _strSymbolID,
    ref FamilySymbol _FamilySymbol)
  {
    FilteredElementCollector source1 = new FilteredElementCollector(_CurrentDocument);
    List<Element> elementList = new List<Element>();
    switch (_LocateType)
    {
      case LocateType.Plant:
        source1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001360);
        elementList = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.UniqueId == _strSymbolID)).ToList<Element>();
        break;
      case LocateType.Component:
        source1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260);
        elementList = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.LookupParameter(RevitParameters.SiteworksIDFamilyParameter) == null && CurrentElement.UniqueId == _strSymbolID)).ToList<Element>();
        FilteredElementCollector elementCollector1 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector2 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector3 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector source2 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector4 = new FilteredElementCollector(_CurrentDocument);
        FilteredElementCollector elementCollector5 = new FilteredElementCollector(_CurrentDocument);
        elementCollector1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001370).UnionWith(elementCollector2.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000080).UnionWith(elementCollector3.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001040).UnionWith(elementCollector4.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001120).UnionWith(elementCollector5.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000100)))));
        List<Element> list1 = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.UniqueId == _strSymbolID)).ToList<Element>();
        elementList.AddRange((IEnumerable<Element>) list1);
        source2.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151);
        List<Element> list2 = ((IEnumerable<Element>) source2).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter) != null && CurrentElement.UniqueId == _strSymbolID)).ToList<Element>();
        elementList.AddRange((IEnumerable<Element>) list2);
        break;
      case LocateType.Fence:
        source1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151);
        Parameter CurLanddCadID = (Parameter) null;
        elementList = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.UniqueId == _strSymbolID && (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.Fence).ToString("000"), true) == 0)).ToList<Element>();
        break;
      case LocateType.ParkingLot:
        source1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001180);
        elementList = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.UniqueId == _strSymbolID)).ToList<Element>();
        break;
    }
    foreach (Element element in elementList)
    {
      if (element is FamilySymbol _FamilySymbol1 && ((Element) _FamilySymbol1).Category != null && this.IsCategoryCorrect(_FamilySymbol1, _LocateType) && string.Compare(((Element) _FamilySymbol1).UniqueId, _strSymbolID, true) == 0)
      {
        _FamilySymbol = _FamilySymbol1;
        break;
      }
    }
  }

  public void UpdateGenericModelElementList(
    string _strCurrentToposurfaceID,
    string _strNewToposurfaceID,
    Document _CurrentDocument)
  {
    List<KeyValuePair<string, FamilyInstance>> _GenericModelElementList = (List<KeyValuePair<string, FamilyInstance>>) null;
    List<LocateType> _FamilyQueryLocateTyoeList = (List<LocateType>) null;
    List<string> _GenericModelAlreadyModified = new List<string>();
    foreach (GenericModelFamilyInstanceWrapper genericModelElement in this.m_GenericModelElementList)
    {
      foreach (GenericModelFamilyInstanceContainer familyContainer in genericModelElement.FamilyContainerList)
      {
        FamilyInstance familyInstance = familyContainer.GetFamilyInstance(_CurrentDocument);
        if (familyInstance != null)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ToposurfaceIDFamilyParameter);
          if (parameter != null && string.Compare(parameter.AsString(), _strCurrentToposurfaceID, false) == 0)
          {
            parameter.Set(_strNewToposurfaceID);
            this.ModifyPlacement(_CurrentDocument, genericModelElement.GetFirstExistingElement(_CurrentDocument, ((Element) familyInstance).Id), familyInstance, genericModelElement, ref _GenericModelElementList, ref _FamilyQueryLocateTyoeList, ref _GenericModelAlreadyModified);
          }
        }
      }
    }
  }

  public void AddElements(Document _CurrentDocument)
  {
    ++this.m_nDocumentsOpenCount;
    FilteredElementCollector source1 = new FilteredElementCollector(_CurrentDocument);
    source1.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151);
    if (source1.FirstElement() == null)
      return;
    Parameter LandcaddIDParameter = (Parameter) null;
    FindFamilyInstance = (FamilyInstance) null;
    List<Element> list;
    try
    {
      list = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (LandcaddIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    }
    catch (InternalException ex)
    {
      return;
    }
    catch (ApplicationException ex)
    {
      return;
    }
    List<KeyValuePair<string, GenericModelFamilyInstanceContainer>> keyValuePairList1 = new List<KeyValuePair<string, GenericModelFamilyInstanceContainer>>();
    LandcaddIDParameter = (Parameter) null;
    bool flag1 = false;
    IList<Element> elements = new FilteredElementCollector(_CurrentDocument).OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051).ToElements();
    foreach (Element element1 in list)
    {
      if (element1 is FamilyInstance _FamilyInstance && ((Element) _FamilyInstance).Category != null && ((Element) _FamilyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        LandcaddIDParameter = ((Element) _FamilyInstance.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (LandcaddIDParameter != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)
        {
          Parameter parameter1 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter1 != null)
          {
            Parameter parameter2 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.BoundaryIslandIDGenericFamilyParameter);
            bool flag2;
            if (parameter2 == null || parameter2.AsString() == string.Empty)
            {
              flag2 = false;
              parameter2 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
            }
            else
              flag2 = true;
            if (parameter2 != null && parameter2.AsString() != string.Empty)
            {
              for (int index1 = 0; index1 < elements.Count; ++index1)
              {
                Element element2 = elements[index1];
                if (element2 != null && element2.Category != null && element2.Category.Id.IntegerValue == ((BuiltInCategory) -2000051).GetHashCode() && string.Compare(parameter1.AsString(), element2.UniqueId, true) == 0)
                {
                  if (!flag2)
                  {
                    for (int index2 = 0; index2 < this.m_GenericModelElementList.Count; ++index2)
                    {
                      if (string.Compare(parameter2.AsString(), this.m_GenericModelElementList[index2].ChainID, true) == 0)
                      {
                        flag1 = true;
                        this.m_GenericModelElementList[index2].FamilyContainerList.Add(new GenericModelFamilyInstanceContainer(element2.Id, _FamilyInstance));
                        break;
                      }
                    }
                    if (!flag1)
                    {
                      this.m_GenericModelElementList.Add(new GenericModelFamilyInstanceWrapper(parameter2.AsString(), new List<GenericModelFamilyInstanceContainer>()
                      {
                        new GenericModelFamilyInstanceContainer(element2.Id, _FamilyInstance)
                      }));
                      break;
                    }
                    flag1 = false;
                    break;
                  }
                  keyValuePairList1.Add(new KeyValuePair<string, GenericModelFamilyInstanceContainer>(parameter2.AsString(), new GenericModelFamilyInstanceContainer(element2.Id, _FamilyInstance)));
                  break;
                }
              }
            }
          }
        }
      }
    }
    for (int index3 = 0; index3 < this.m_GenericModelElementList.Count; ++index3)
    {
      for (int index4 = 0; index4 < keyValuePairList1.Count; ++index4)
      {
        if (this.m_GenericModelElementList[index3].IndexOfFamilyInstanceUniqueID(_CurrentDocument, keyValuePairList1[index4].Key) >= 0)
        {
          if (this.m_GenericModelElementList[index3].IslandFamilyInstanceList == null)
            this.m_GenericModelElementList[index3].IslandFamilyInstanceList = new List<GenericModelFamilyInstanceContainer>();
          this.m_GenericModelElementList[index3].IslandFamilyInstanceList.Add(keyValuePairList1[index4].Value);
        }
      }
    }
    List<KeyValuePair<string, FamilyInstance>> keyValuePairList2 = new List<KeyValuePair<string, FamilyInstance>>();
    FilteredElementCollector source2 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector1 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector2 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector3 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector4 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector5 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector6 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector7 = new FilteredElementCollector(_CurrentDocument);
    FilteredElementCollector elementCollector8 = new FilteredElementCollector(_CurrentDocument);
    source2.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).UnionWith(elementCollector6.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001180).UnionWith(elementCollector5.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260).UnionWith(elementCollector1.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001370).UnionWith(elementCollector2.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000080).UnionWith(elementCollector3.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001040).UnionWith(elementCollector4.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151).UnionWith(elementCollector7.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001120).UnionWith(elementCollector8.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000100)))))))));
    foreach (Element element in (IEnumerable<Element>) ((IEnumerable<Element>) source2).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.LookupParameter(RevitParameters.PlacementIDFamilyParameter) != null)).ToList<Element>())
    {
      if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
        if (parameter != null && parameter.AsString() != string.Empty)
          keyValuePairList2.Add(new KeyValuePair<string, FamilyInstance>(parameter.AsString(), familyInstance));
      }
    }
    for (int index5 = 0; index5 < this.m_GenericModelElementList.Count; ++index5)
    {
      for (int index6 = 0; index6 < keyValuePairList2.Count; ++index6)
      {
        if (this.m_GenericModelElementList[index5].IndexOfFamilyInstanceUniqueID(_CurrentDocument, keyValuePairList2[index6].Key) >= 0)
        {
          if (this.m_GenericModelElementList[index5].FamilyAssignmentList == null)
            this.m_GenericModelElementList[index5].FamilyAssignmentList = new List<FamilyInstanceAssignmentContainer>();
          this.m_GenericModelElementList[index5].FamilyAssignmentList.Add(new FamilyInstanceAssignmentContainer(((Element) keyValuePairList2[index6].Value).Id, keyValuePairList2[index6].Value));
        }
      }
    }
  }

  public void RemoveElements(Document _CurrentDocument)
  {
    --this.m_nDocumentsOpenCount;
    for (int index1 = this.m_GenericModelElementList.Count - 1; index1 >= 0; --index1)
    {
      bool flag = false;
      if (this.m_GenericModelElementList[index1].FamilyContainerList != null)
      {
        for (int index2 = this.m_GenericModelElementList[index1].FamilyContainerList.Count - 1; index2 >= 0; --index2)
        {
          FamilyInstance familyInstance = this.m_GenericModelElementList[index1].FamilyContainerList[index2].GetFamilyInstance(_CurrentDocument);
          if (familyInstance != null && RevitUtility.CompareFileNames(((Element) familyInstance).Document.PathName, _CurrentDocument.PathName) == 0 && RevitUtility.CompareFileNames(((Element) familyInstance).Document.Title, _CurrentDocument.Title) == 0)
          {
            this.m_GenericModelElementList[index1].FamilyContainerList.RemoveAt(index2);
            if (this.m_GenericModelElementList[index1].FamilyContainerList.Count == 0)
            {
              this.m_GenericModelElementList.RemoveAt(index1);
              flag = true;
              break;
            }
          }
        }
      }
      if (!flag && this.m_GenericModelElementList.Count > 0 && this.m_GenericModelElementList[index1] != null)
      {
        if (this.m_GenericModelElementList[index1].IslandFamilyInstanceList != null)
        {
          for (int index3 = this.m_GenericModelElementList[index1].IslandFamilyInstanceList.Count - 1; index3 >= 0; --index3)
          {
            FamilyInstance familyInstance = this.m_GenericModelElementList[index1].IslandFamilyInstanceList[index3].GetFamilyInstance(_CurrentDocument);
            if (familyInstance != null && RevitUtility.CompareFileNames(((Element) familyInstance).Document.PathName, _CurrentDocument.PathName) == 0 && RevitUtility.CompareFileNames(((Element) familyInstance).Document.Title, _CurrentDocument.Title) == 0)
              this.m_GenericModelElementList[index1].IslandFamilyInstanceList.RemoveAt(index3);
          }
        }
        if (this.m_GenericModelElementList[index1].FamilyAssignmentList != null)
        {
          for (int index4 = this.m_GenericModelElementList[index1].FamilyAssignmentList.Count - 1; index4 >= 0; --index4)
          {
            FamilyInstance familyInstance = this.m_GenericModelElementList[index1].FamilyAssignmentList[index4].GetFamilyInstance(_CurrentDocument);
            if (familyInstance != null && RevitUtility.CompareFileNames(((Element) familyInstance).Document.PathName, _CurrentDocument.PathName) == 0 && RevitUtility.CompareFileNames(((Element) familyInstance).Document.Title, _CurrentDocument.Title) == 0)
              this.m_GenericModelElementList[index1].FamilyAssignmentList.RemoveAt(index4);
          }
        }
      }
    }
  }

  private bool AddFamilyAssignmentToList(
    Document _CurrentDocument,
    string _strPlacementID,
    FamilyInstance _FamilyInstance)
  {
    bool flag = false;
    bool list = false;
    for (int index1 = 0; index1 < this.m_GenericModelElementList.Count; ++index1)
    {
      if (this.m_GenericModelElementList[index1].IndexOfFamilyInstanceUniqueID(_CurrentDocument, _strPlacementID) >= 0)
      {
        if (this.m_GenericModelElementList[index1].FamilyAssignmentList == null)
          this.m_GenericModelElementList[index1].FamilyAssignmentList = new List<FamilyInstanceAssignmentContainer>();
        if (this.m_GenericModelElementList[index1].IndexOfFamilyAssignmentInstanceID(_CurrentDocument, ((Element) _FamilyInstance).Id) < 0)
        {
          for (int index2 = 0; index2 < this.m_GenericModelElementList[index1].FamilyAssignmentList.Count; ++index2)
          {
            if (((Element) _FamilyInstance).Id.IntegerValue == this.m_GenericModelElementList[index1].FamilyAssignmentList[index2].ID.IntegerValue)
            {
              flag = true;
              break;
            }
          }
          if (!flag)
            this.m_GenericModelElementList[index1].FamilyAssignmentList.Add(new FamilyInstanceAssignmentContainer(((Element) _FamilyInstance).Id, _FamilyInstance));
        }
        list = true;
        break;
      }
    }
    return list;
  }

  private void DeleteGenericModelFromList(
    Document _CurrentDocument,
    FamilyInstance _DeleteFamilyInstance,
    int _nListIndex)
  {
    this.DeleteGenericModelsFromList(_CurrentDocument, new List<FamilyInstance>()
    {
      _DeleteFamilyInstance
    }, _nListIndex);
  }

  private void DeleteGenericModelsFromList(
    Document _CurrentDocument,
    List<FamilyInstance> _DeleteFamilyInstanceList,
    int _nListIndex)
  {
    if (_DeleteFamilyInstanceList == null)
      return;
    for (int index1 = 0; index1 < _DeleteFamilyInstanceList.Count; ++index1)
    {
      if (_DeleteFamilyInstanceList[index1] != null)
      {
        Parameter parameter1 = ((Element) _DeleteFamilyInstanceList[index1]).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
        if (parameter1 != null)
        {
          string strB = parameter1.AsString();
          if (this.m_GenericModelElementList[_nListIndex].FamilyContainerList != null && this.m_GenericModelElementList[_nListIndex].FamilyContainerList.Count > 0)
          {
            for (int index2 = this.m_GenericModelElementList[_nListIndex].FamilyContainerList.Count - 1; index2 >= 0; --index2)
            {
              FamilyInstance familyInstance = this.m_GenericModelElementList[_nListIndex].FamilyContainerList[index2].GetFamilyInstance(_CurrentDocument);
              if (familyInstance != null && !_DeleteFamilyInstanceList.Contains(familyInstance))
              {
                Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
                if (parameter2 != null && string.Compare(parameter2.AsString(), strB, true) == 0)
                  _CurrentDocument.Delete(((Element) familyInstance).Id);
              }
            }
          }
          if (this.m_GenericModelElementList[_nListIndex].IslandFamilyInstanceList != null && this.m_GenericModelElementList[_nListIndex].IslandFamilyInstanceList.Count > 0)
          {
            for (int index3 = this.m_GenericModelElementList[_nListIndex].IslandFamilyInstanceList.Count - 1; index3 >= 0; --index3)
            {
              FamilyInstance familyInstance = this.m_GenericModelElementList[_nListIndex].IslandFamilyInstanceList[index3].GetFamilyInstance(_CurrentDocument);
              if (familyInstance != null && !_DeleteFamilyInstanceList.Contains(familyInstance))
              {
                Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
                if (parameter3 != null && string.Compare(parameter3.AsString(), strB, true) == 0)
                  _CurrentDocument.Delete(((Element) familyInstance).Id);
              }
            }
          }
        }
      }
      _CurrentDocument.Delete(((Element) _DeleteFamilyInstanceList[index1]).Id);
    }
  }

  public string GetAdditionalInformation() => "This will handle Symbol Placement Generic Models.";

  public ChangePriority GetChangePriority() => (ChangePriority) 15;

  public UpdaterId GetUpdaterId() => SymbolPlacementUpdater.m_UpdaterId;

  public string GetUpdaterName() => "Symbol Placement Updater";

  public int DocumentsOpenCount() => this.m_nDocumentsOpenCount;
}
