﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParkingLotAreaSettingsForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ParkingLotAreaSettingsForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private Document m_Document;
  private FormatOptions m_LengthFormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_LengthUnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private TextBox m_AisleWidthTextBox;
  private GroupBox m_RowSpacingGroupBox;
  private ComboBox m_RowSpacingOptionsComboBox;
  private Label m_ParkingFamilyLabel;
  private CheckBox m_BiDirectionalAislesCheckBox;
  private TextBox m_DistanceBetweenCenterlinesTextBox;
  private Button m_OKButton;
  private Button m_CancelButton;
  private TextBox m_ParkingNumberOfRowsTextBox;
  private Label m_ParkingNumberOfRowsLabel;

  public ParkingLotAreaSettingsForm(Document _Document)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ParkingLotAreaSettingsDialog");
    this.m_RowSpacingGroupBox.Text = EPShared.LocalRM.GetString("RowSpacingDialog");
    this.m_ParkingNumberOfRowsLabel.Text = EPShared.LocalRM.GetString("AMP_NumberOfRowsDialog");
    this.m_BiDirectionalAislesCheckBox.Text = EPShared.LocalRM.GetString("AMP_UseBiDirectionalAislesDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_Document = _Document;
    this.m_DisplayUnitSystem = this.m_Document.DisplayUnitSystem;
    this.m_LengthFormatOptions = this.m_Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_Units = this.m_Document.GetUnits();
    try
    {
      this.m_LengthUnitSymbolType = this.m_LengthFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_LengthUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_Document.GetUnits().DecimalSymbol;
    this.m_RowSpacingOptionsComboBox.Items.Add((object) EPShared.LocalRM.GetString("DistBetweenLinesString"));
    this.m_RowSpacingOptionsComboBox.Items.Add((object) EPShared.LocalRM.GetString("AisleWidthString"));
    this.InitializeControls();
  }

  private void InitializeControls() => this.GetDialogPosition();

  private void SaveSettings()
  {
    int _nReturnedInt = 0;
    double _dReturnedDouble = 0.0;
    ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsRowSpacingOption", this.m_RowSpacingOptionsComboBox.SelectedIndex);
    ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsBiDirectionalAisles", Convert.ToInt32(this.m_BiDirectionalAislesCheckBox.Checked));
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_DistanceBetweenCenterlinesTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsDistanceBetweenCenterlines", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_AisleWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsAisleWidth", _dReturnedDouble);
    if (!RevitGeometry.StrE_GetValidWholeNumber(this.m_ParkingNumberOfRowsTextBox.Text, ref _nReturnedInt))
      return;
    ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsNumberOfRows", _nReturnedInt);
  }

  private void FormatDistanceBetweenCenterlinesValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_DistanceBetweenCenterlinesTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_DistanceBetweenCenterlinesTextBox.Text = empty;
    }
    else
      this.m_DistanceBetweenCenterlinesTextBox.Focus();
  }

  private void FormatAisleWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_AisleWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_AisleWidthTextBox.Text = empty;
    }
    else
      this.m_AisleWidthTextBox.Focus();
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnRowSpacingOptionsComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (this.m_RowSpacingOptionsComboBox.SelectedIndex == 0)
    {
      this.m_DistanceBetweenCenterlinesTextBox.Visible = true;
      this.m_AisleWidthTextBox.Visible = false;
    }
    else
    {
      this.m_DistanceBetweenCenterlinesTextBox.Visible = false;
      this.m_AisleWidthTextBox.Visible = true;
    }
  }

  private void OnDistanceBetweenCenterlinesTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatDistanceBetweenCenterlinesValue();
  }

  private void OnDistanceBetweenCenterlinesTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatDistanceBetweenCenterlinesValue();
  }

  private void OnAisleWidthTextBoxLeave(object sender, EventArgs e) => this.FormatAisleWidthValue();

  private void OnAisleWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatAisleWidthValue();
  }

  private void ParkingLotAreaSettingsFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public string DistanceBetweenCenterlines
  {
    get => this.m_DistanceBetweenCenterlinesTextBox.Text;
    set => this.m_DistanceBetweenCenterlinesTextBox.Text = value;
  }

  public string AisleWidth
  {
    get => this.m_AisleWidthTextBox.Text;
    set => this.m_AisleWidthTextBox.Text = value;
  }

  public bool BiDirectionalAisles
  {
    get => this.m_BiDirectionalAislesCheckBox.Checked;
    set => this.m_BiDirectionalAislesCheckBox.Checked = value;
  }

  public int RowSpacingOptions
  {
    get => this.m_RowSpacingOptionsComboBox.SelectedIndex;
    set
    {
      int num = value;
      if (num < 0 || num >= this.m_RowSpacingOptionsComboBox.Items.Count)
        return;
      this.m_RowSpacingOptionsComboBox.SelectedIndex = num;
    }
  }

  public int ParkingNumberOfRows
  {
    get
    {
      int _nReturnedInt = 0;
      RevitGeometry.StrE_GetValidWholeNumber(this.m_ParkingNumberOfRowsTextBox.Text, ref _nReturnedInt);
      return _nReturnedInt;
    }
    set => this.m_ParkingNumberOfRowsTextBox.Text = Convert.ToString(value);
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_AisleWidthTextBox = new TextBox();
    this.m_RowSpacingGroupBox = new GroupBox();
    this.m_ParkingNumberOfRowsTextBox = new TextBox();
    this.m_ParkingNumberOfRowsLabel = new Label();
    this.m_DistanceBetweenCenterlinesTextBox = new TextBox();
    this.m_BiDirectionalAislesCheckBox = new CheckBox();
    this.m_RowSpacingOptionsComboBox = new ComboBox();
    this.m_ParkingFamilyLabel = new Label();
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_RowSpacingGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_AisleWidthTextBox.Location = new Point(231, 20);
    this.m_AisleWidthTextBox.Name = "m_AisleWidthTextBox";
    this.m_AisleWidthTextBox.Size = new Size(100, 20);
    this.m_AisleWidthTextBox.TabIndex = 2;
    this.m_AisleWidthTextBox.KeyDown += new KeyEventHandler(this.OnAisleWidthTextBoxKeyDown);
    this.m_AisleWidthTextBox.Leave += new EventHandler(this.OnAisleWidthTextBoxLeave);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_ParkingNumberOfRowsTextBox);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_ParkingNumberOfRowsLabel);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_DistanceBetweenCenterlinesTextBox);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_BiDirectionalAislesCheckBox);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_RowSpacingOptionsComboBox);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_AisleWidthTextBox);
    this.m_RowSpacingGroupBox.Controls.Add((Control) this.m_ParkingFamilyLabel);
    this.m_RowSpacingGroupBox.Location = new Point(12, 12);
    this.m_RowSpacingGroupBox.Name = "m_RowSpacingGroupBox";
    this.m_RowSpacingGroupBox.Size = new Size(340, 99);
    this.m_RowSpacingGroupBox.TabIndex = 0;
    this.m_RowSpacingGroupBox.TabStop = false;
    this.m_RowSpacingGroupBox.Text = "Row Spacing";
    this.m_ParkingNumberOfRowsTextBox.Location = new Point(125, 46);
    this.m_ParkingNumberOfRowsTextBox.Name = "m_ParkingNumberOfRowsTextBox";
    this.m_ParkingNumberOfRowsTextBox.Size = new Size(100, 20);
    this.m_ParkingNumberOfRowsTextBox.TabIndex = 3;
    this.m_ParkingNumberOfRowsLabel.AutoSize = true;
    this.m_ParkingNumberOfRowsLabel.Location = new Point(6, 49);
    this.m_ParkingNumberOfRowsLabel.Name = "m_ParkingNumberOfRowsLabel";
    this.m_ParkingNumberOfRowsLabel.Size = new Size(89, 13);
    this.m_ParkingNumberOfRowsLabel.TabIndex = 2;
    this.m_ParkingNumberOfRowsLabel.Text = "&Number of Rows:";
    this.m_DistanceBetweenCenterlinesTextBox.Location = new Point(231, 20);
    this.m_DistanceBetweenCenterlinesTextBox.Name = "m_DistanceBetweenCenterlinesTextBox";
    this.m_DistanceBetweenCenterlinesTextBox.Size = new Size(100, 20);
    this.m_DistanceBetweenCenterlinesTextBox.TabIndex = 1;
    this.m_DistanceBetweenCenterlinesTextBox.KeyDown += new KeyEventHandler(this.OnDistanceBetweenCenterlinesTextBoxKeyDown);
    this.m_DistanceBetweenCenterlinesTextBox.Leave += new EventHandler(this.OnDistanceBetweenCenterlinesTextBoxLeave);
    this.m_BiDirectionalAislesCheckBox.AutoSize = true;
    this.m_BiDirectionalAislesCheckBox.Location = new Point(6, 72);
    this.m_BiDirectionalAislesCheckBox.Name = "m_BiDirectionalAislesCheckBox";
    this.m_BiDirectionalAislesCheckBox.Size = new Size(140, 17);
    this.m_BiDirectionalAislesCheckBox.TabIndex = 4;
    this.m_BiDirectionalAislesCheckBox.Text = "&Use Bi-Directional Aisles";
    this.m_BiDirectionalAislesCheckBox.UseVisualStyleBackColor = true;
    this.m_RowSpacingOptionsComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_RowSpacingOptionsComboBox.FormattingEnabled = true;
    this.m_RowSpacingOptionsComboBox.Location = new Point(6, 19);
    this.m_RowSpacingOptionsComboBox.Name = "m_RowSpacingOptionsComboBox";
    this.m_RowSpacingOptionsComboBox.Size = new Size(219, 21);
    this.m_RowSpacingOptionsComboBox.TabIndex = 0;
    this.m_RowSpacingOptionsComboBox.SelectedIndexChanged += new EventHandler(this.OnRowSpacingOptionsComboBoxSelectedIndexChanged);
    this.m_ParkingFamilyLabel.AutoSize = true;
    this.m_ParkingFamilyLabel.Location = new Point(-93, 38);
    this.m_ParkingFamilyLabel.Name = "m_ParkingFamilyLabel";
    this.m_ParkingFamilyLabel.Size = new Size(39, 13);
    this.m_ParkingFamilyLabel.TabIndex = 3;
    this.m_ParkingFamilyLabel.Text = "&Family:";
    this.m_OKButton.Location = new Point(196, 117);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 1;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(277, 117);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 2;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(364, 151);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_RowSpacingGroupBox);
    this.Name = nameof (ParkingLotAreaSettingsForm);
    this.Text = "Parking Lot Area Settings";
    this.FormClosing += new FormClosingEventHandler(this.ParkingLotAreaSettingsFormClosing);
    this.m_RowSpacingGroupBox.ResumeLayout(false);
    this.m_RowSpacingGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
