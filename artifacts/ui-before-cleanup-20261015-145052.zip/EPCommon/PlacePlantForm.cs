using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;

namespace EPCommon;

public class PlacePlantForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private PlantCreation m_dataBuffer;

	private FamilySymbol m_CurType;

	private FormatOptions m_FormatOptions;

	private FormatOptions m_AngularOptions;

	private Autodesk.Revit.DB.View m_CurView;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private UnitSymbolType m_AngularSymbolType;

	private DecimalSymbol m_DecimalSymbolType;

	private double m_dAngularRounding;

	private IContainer components;

	private Label m_PlantFamilyLabel;

	private ComboBox m_PlantFamilyComboBox;

	private RadioButton m_HedgeRowRadioButton;

	private Label m_PlantNameLabel;

	private ComboBox m_PlantNameComboBox;

	private Label m_PlantWidthLabel;

	private TextBox m_PlantWidthTextBox;

	private Label m_VarianceWidthLabel;

	private TextBox m_VarianceWidthTextBox;

	private TextBox m_VarianceHeightTextBox;

	private Label m_VarianceHeightLabel;

	private TextBox m_PlantHeightTextBox;

	private Label m_PlantHeightLabel;

	private Label m_PlantSpacingLabel;

	private TextBox m_PlantSpacingTextBox;

	private RadioButton m_GroveRadioButton;

	private Button m_SearchButton;

	private System.Windows.Forms.Panel m_HedgeRowPanel;

	private RadioButton m_SideHedgeRadioButton;

	private RadioButton m_AlternateHedgeRadioButton;

	private RadioButton m_CenterHedgeRadioButton;

	private System.Windows.Forms.Panel m_GrovePanel;

	private RadioButton m_SquareRadioButton;

	private RadioButton m_TriangularRadioButton;

	private Label m_RotationLabel;

	private TextBox m_RotationTextBox;

	private Button m_LoadFamilyButton;

	private CheckBox m_ExistingElementCheckBox;

	private RadioButton m_SingleRadioButton;

	private System.Windows.Forms.Panel m_FirstMoveablePanel;

	private GroupBox m_PlaceTagGroupBox;

	private CheckBox m_LeaderedTagCheckBox;

	private CheckBox m_CreatePlantGroupTagCheckBox;

	private ComboBox m_LevelComboBox;

	private Label m_LevelLabel;

	private System.Windows.Forms.Panel m_SecondMoveablePanel;

	private CheckBox m_DeleteExistingCheckBox;

	private Button m_CancelButton;

	private Button m_InsertButton;

	private Label m_SetbackLabel;

	private TextBox m_SetbackTextBox;

	private RadioButton m_ChainRadioButton;

	private RadioButton m_SegmentRadioButton;

	private Label m_StartingDistanceLabel;

	private TextBox m_StartingDistanceTextBox;

	private ComboBox m_SurfaceList;

	private Label m_SelectedSurfaceLabel;

	private CheckBox m_ToposurfaceCheckBox;

	public bool ExistingElementChecked => m_ExistingElementCheckBox.Checked;

	public PlacementType PlacementType
	{
		get
		{
			if (m_HedgeRowRadioButton.Checked)
			{
				if (m_CenterHedgeRadioButton.Checked)
				{
					return PlacementType.HedgeRowCenter;
				}
				if (m_AlternateHedgeRadioButton.Checked)
				{
					return PlacementType.HedgeRowAlternate;
				}
				return PlacementType.HedgeRowSide;
			}
			if (m_GroveRadioButton.Checked)
			{
				if (m_TriangularRadioButton.Checked)
				{
					return PlacementType.GroveTrianglular;
				}
				return PlacementType.GroveSquare;
			}
			return PlacementType.Single;
		}
	}

	public bool SingleChecked => m_SingleRadioButton.Checked;

	public bool HedgeRowChecked => m_HedgeRowRadioButton.Checked;

	public bool GroveChecked => m_GroveRadioButton.Checked;

	public bool TriangularGroveChecked => m_TriangularRadioButton.Checked;

	public bool SquareGroveChecked => m_SquareRadioButton.Checked;

	public bool CenteredHedgeRowChecked => m_CenterHedgeRadioButton.Checked;

	public bool AlternateHedgeRowChecked => m_AlternateHedgeRadioButton.Checked;

	public bool SideHedgeRadioButton => m_SideHedgeRadioButton.Checked;

	public bool DeleteExistingChecked
	{
		get
		{
			if (!m_ExistingElementCheckBox.Checked)
			{
				return false;
			}
			return m_DeleteExistingCheckBox.Checked;
		}
	}

	public double StartingDistance
	{
		get
		{
			if (!m_HedgeRowRadioButton.Checked || !m_ExistingElementCheckBox.Checked)
			{
				return 0.0;
			}
			double _dReturnedDouble = 0.0;
			if (m_StartingDistanceTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool PlaceGroupTagChecked => m_CreatePlantGroupTagCheckBox.Checked;

	public bool LeaderedTagChecked => m_LeaderedTagCheckBox.Checked;

	public Level Level => m_CurView.GenLevel;

	public Autodesk.Revit.DB.View View => m_CurView;

	public FamilySymbol Type => m_CurType;

	public double RotationAngle
	{
		get
		{
			double result = 0.0;
			if (m_RotationTextBox.Text != string.Empty)
			{
				result = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_RotationTextBox.Text);
			}
			return result;
		}
	}

	public double PlantSpacing
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_PlantSpacingTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double SetbackSpacing
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_SetbackTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double PlantHeight
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_PlantHeightTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_PlantHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double HeightVariance
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_VarianceHeightTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_VarianceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double PlantWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_PlantWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_PlantWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double WidthVariance
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_VarianceWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_VarianceWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool SegmentChecked
	{
		get
		{
			if (m_GroveRadioButton.Checked)
			{
				return false;
			}
			return m_SegmentRadioButton.Checked;
		}
	}

	public bool ChainChecked
	{
		get
		{
			if (m_GroveRadioButton.Checked)
			{
				return true;
			}
			return m_ChainRadioButton.Checked;
		}
	}

	public TopographySurfaceContainer Surface
	{
		get
		{
			TopographySurfaceContainer result = null;
			if (m_SurfaceList.SelectedItem is ToposurfaceItem toposurfaceItem)
			{
				result = toposurfaceItem.Value;
			}
			return result;
		}
	}

	public bool PickToposurface => m_ToposurfaceCheckBox.Checked;

	public PlacePlantForm(PlantCreation dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("LocatePlantsDialog");
		m_PlantFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_PlantFamilyDialog");
		m_PlantNameLabel.Text = EPShared.LocalRM.GetString("P_AMP_lantNameDialog");
		m_SearchButton.Text = EPShared.LocalRM.GetString("Sea_AMP_rchDialog");
		m_PlantWidthLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_WidthDialog");
		m_VarianceWidthLabel.Text = EPShared.LocalRM.GetString("AMP_VarianceDialog");
		m_PlantHeightLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_HeightDialog");
		m_VarianceHeightLabel.Text = EPShared.LocalRM.GetString("Varianc_AMP_eDialog");
		m_PlantSpacingLabel.Text = EPShared.LocalRM.GetString("Plan_AMP_tSpacingDialog");
		m_SetbackLabel.Text = EPShared.LocalRM.GetString("Set_AMP_backDialog");
		m_HedgeRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_HedgeRowDialog");
		m_CenterHedgeRadioButton.Text = EPShared.LocalRM.GetString("C_AMP_enterDialog");
		m_AlternateHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_AlternateDialog");
		m_SideHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_SideDialog");
		m_GroveRadioButton.Text = EPShared.LocalRM.GetString("AMP_GroveDialog");
		m_TriangularRadioButton.Text = EPShared.LocalRM.GetString("Triang_AMP_ularDialog");
		m_SquareRadioButton.Text = EPShared.LocalRM.GetString("S_AMP_quareDialog");
		m_RotationLabel.Text = EPShared.LocalRM.GetString("R_AMP_otationDialog");
		m_SingleRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleDialog");
		m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
		m_PlaceTagGroupBox.Text = EPShared.LocalRM.GetString("PlaceTagDialog");
		m_CreatePlantGroupTagCheckBox.Text = EPShared.LocalRM.GetString("CreatePlant_AMP_GroupTagDialog");
		m_LeaderedTagCheckBox.Text = EPShared.LocalRM.GetString("CreatePlant_AMP_GroupTagDialog");
		m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
		m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
		m_LeaderedTagCheckBox.Text = EPShared.LocalRM.GetString("Lea_AMP_deredTagDialog");
		m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
		m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
		m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
		m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
		m_ToposurfaceCheckBox.Checked = false;
		m_SurfaceList.Enabled = false;
		EPToolTip.SetToolTip(m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		m_dataBuffer = dataBuffer;
		m_FormatOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_AngularOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Angle);
		m_DisplayUnitSystem = m_dataBuffer.Document.DisplayUnitSystem;
		m_Units = m_dataBuffer.Document.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_AngularSymbolType = m_AngularOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_AngularSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_dAngularRounding = m_AngularOptions.Accuracy;
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_dAngularRounding = 1.0;
		}
		m_DecimalSymbolType = m_dataBuffer.Document.GetUnits().DecimalSymbol;
		InitializeControls();
		ManagePlants.VerifySharedParameters(m_dataBuffer.Document, m_dataBuffer.TransactionContainer);
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		double _dReturnValue = 0.0;
		string _strAngleStr = string.Empty;
		GetDialogPosition();
		m_HedgeRowRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantPlacementOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_HedgeRowRadioButton.Checked = true;
				break;
			case 1:
				m_GroveRadioButton.Checked = true;
				break;
			default:
				m_SingleRadioButton.Checked = true;
				break;
			}
		}
		m_CenterHedgeRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantHedgeRowOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_CenterHedgeRadioButton.Checked = true;
				break;
			case 1:
				m_AlternateHedgeRadioButton.Checked = true;
				break;
			default:
				m_SideHedgeRadioButton.Checked = true;
				break;
			}
		}
		m_TriangularRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantGroveRowOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_TriangularRadioButton.Checked = true;
			}
			else
			{
				m_SquareRadioButton.Checked = true;
			}
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantGroveRotation", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.eplStrE_ConvertRadiansToAngleStr(m_AngularOptions.LegacyDisplayUnits(), _dReturnValue, m_dAngularRounding, m_AngularSymbolType, m_DecimalSymbolType, ref _strAngleStr);
		m_RotationTextBox.Text = _strAngleStr;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantPlantSpacing", ref _dReturnValue))
		{
			_dReturnValue = 5.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_PlantSpacingTextBox.Text = _strAngleStr;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantSetback", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_SetbackTextBox.Text = _strAngleStr;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantHeightVariance", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_VarianceHeightTextBox.Text = _strAngleStr;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantWidthVariance", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_VarianceWidthTextBox.Text = _strAngleStr;
		m_CreatePlantGroupTagCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantCreatePlantGroupTag", ref _nReturnValue))
		{
			m_CreatePlantGroupTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_LeaderedTagCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantCreateLeaderedTag", ref _nReturnValue))
		{
			m_LeaderedTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_ExistingElementCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantExistingElement", ref _nReturnValue))
		{
			m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_DeleteExistingCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantDeleteExisting", ref _nReturnValue))
		{
			m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantStartingDistance", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_StartingDistanceTextBox.Text = _strAngleStr;
		m_PlantFamilyComboBox.DataSource = m_dataBuffer.PlantFamilyList;
		m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "PlacePlantFamilyName", ref _strAngleStr))
		{
			FamilyContainer familyContainer = null;
			for (int i = 0; i < m_PlantFamilyComboBox.Items.Count; i++)
			{
				if (m_PlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strAngleStr, ignoreCase: true) == 0)
				{
					m_PlantFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "PlacePlantPlantName", ref _strAngleStr))
		{
			FamilySymbol familySymbol = null;
			for (int j = 0; j < m_PlantNameComboBox.Items.Count; j++)
			{
				if (m_PlantNameComboBox.Items[j] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strAngleStr, ignoreCase: true) == 0)
				{
					m_PlantNameComboBox.SelectedIndex = j;
					break;
				}
			}
		}
		GetPlantParameters();
		m_LevelComboBox.DataSource = m_dataBuffer.Views;
		m_LevelComboBox.DisplayMember = EPShared.LocalRM.GetString("ViewNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "PlacePlantViewName", ref _strAngleStr))
		{
			Autodesk.Revit.DB.View view = null;
			for (int k = 0; k < m_LevelComboBox.Items.Count; k++)
			{
				if (m_LevelComboBox.Items[k] is Autodesk.Revit.DB.View view2 && string.Compare(view2.Name, _strAngleStr, ignoreCase: true) == 0)
				{
					m_LevelComboBox.SelectedIndex = k;
					break;
				}
			}
		}
		m_SegmentRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantSegmentChainOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_SegmentRadioButton.Checked = true;
			}
			else
			{
				m_ChainRadioButton.Checked = true;
			}
		}
		m_ToposurfaceCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlacePlantPickToposurface", ref _nReturnValue))
		{
			m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		Parameter parameter = null;
		string text = string.Empty;
		if (m_dataBuffer.SurfaceList.Count > 0)
		{
			int num = 1;
			foreach (TopographySurfaceContainer surface in m_dataBuffer.SurfaceList)
			{
				parameter = ((Element)surface.TopographySurface).get_Parameter(BuiltInParameter.ROOM_NAME);
				if (parameter != null)
				{
					text = parameter.AsString();
				}
				if (text == null || text == string.Empty)
				{
					text = "<" + EPShared.LocalRM.GetString("UnnamedSurfaceDialog") + " " + Convert.ToString(num) + ">";
					num++;
				}
				m_SurfaceList.Items.Add(new ToposurfaceItem(text, surface));
			}
		}
		else
		{
			m_ToposurfaceCheckBox.Checked = false;
			m_ToposurfaceCheckBox.Enabled = false;
			m_SurfaceList.Enabled = false;
		}
		parameter = null;
		text = string.Empty;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "PlacePlantSurfaceName", ref _strAngleStr))
		{
			for (int l = 0; l < m_SurfaceList.Items.Count; l++)
			{
				if (m_SurfaceList.Items[l] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, _strAngleStr, ignoreCase: true) == 0)
				{
					m_SurfaceList.SelectedIndex = l;
					break;
				}
			}
		}
		if (m_SurfaceList.Items.Count > 0 && m_SurfaceList.SelectedIndex == -1)
		{
			m_SurfaceList.SelectedIndex = 0;
		}
	}

	private void SaveSettings()
	{
		m_CurView = m_LevelComboBox.SelectedItem as Autodesk.Revit.DB.View;
		if (m_CurView == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		m_CurType = m_PlantNameComboBox.SelectedItem as FamilySymbol;
		if (m_CurType == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		int num = 0;
		num = ((!m_HedgeRowRadioButton.Checked) ? (m_GroveRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantPlacementOption", num);
		num = ((!m_CenterHedgeRadioButton.Checked) ? (m_AlternateHedgeRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantHedgeRowOption", num);
		num = ((!m_TriangularRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantGroveRowOption", num);
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantPlantSpacing", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantSetback", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_VarianceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantHeightVariance", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_VarianceWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantWidthVariance", _dReturnedDouble);
		}
		_dReturnedDouble = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_RotationTextBox.Text);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantGroveRotation", _dReturnedDouble);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantCreatePlantGroupTag", Convert.ToInt32(m_CreatePlantGroupTagCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantCreateLeaderedTag", Convert.ToInt32(m_LeaderedTagCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantExistingElement", Convert.ToInt32(m_ExistingElementCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantDeleteExisting", Convert.ToInt32(m_DeleteExistingCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantStartingDistance", _dReturnedDouble);
		}
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "PlacePlantFamilyName", familyContainer.FamilyName);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "PlacePlantPlantName", m_CurType.Name);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "PlacePlantViewName", m_CurView.Name);
		num = ((!m_SegmentRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantSegmentChainOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlacePlantPickToposurface", Convert.ToInt32(m_ToposurfaceCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "PlacePlantSurfaceName", Convert.ToString(m_SurfaceList.SelectedItem));
	}

	private bool ValidateFields()
	{
		double _dReturnedDouble = 0.0;
		string text = m_PlantSpacingTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyPlantSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_PlantSpacingTextBox);
			return false;
		}
		if (!RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_PlantSpacingTextBox);
			return false;
		}
		if (m_HedgeRowRadioButton.Checked && !m_CenterHedgeRadioButton.Checked && (!RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
			return false;
		}
		if (m_PlantWidthTextBox.Enabled)
		{
			text = m_PlantWidthTextBox.Text;
			if (string.IsNullOrEmpty(text))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyPlantWidthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				SiteDesigner.UI.WpfFocus.Focus(m_PlantWidthTextBox);
				return false;
			}
			if (!RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantWidthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				SiteDesigner.UI.WpfFocus.Focus(m_PlantWidthTextBox);
				return false;
			}
			text = m_VarianceWidthTextBox.Text;
			if (!string.IsNullOrEmpty(text))
			{
				double _dReturnedDouble2 = 0.0;
				if (!RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref _dReturnedDouble2) || _dReturnedDouble2 < 0.0)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantWidthVarianceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					SiteDesigner.UI.WpfFocus.Focus(m_VarianceWidthTextBox);
					return false;
				}
				if (RevitDefines.GE(_dReturnedDouble2, _dReturnedDouble))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("VarianceMoreThanPlantWidthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					SiteDesigner.UI.WpfFocus.Focus(m_VarianceWidthTextBox);
					return false;
				}
			}
		}
		if (m_PlantHeightTextBox.Enabled)
		{
			text = m_PlantHeightTextBox.Text;
			if (string.IsNullOrEmpty(text))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyPlantHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				SiteDesigner.UI.WpfFocus.Focus(m_PlantHeightTextBox);
				return false;
			}
			if (!RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				SiteDesigner.UI.WpfFocus.Focus(m_PlantHeightTextBox);
				return false;
			}
			text = m_VarianceHeightTextBox.Text;
			if (!string.IsNullOrEmpty(text))
			{
				double _dReturnedDouble3 = 0.0;
				if (!RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref _dReturnedDouble3) || _dReturnedDouble3 < 0.0)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidPlantHeightVarianceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					SiteDesigner.UI.WpfFocus.Focus(m_VarianceHeightTextBox);
					return false;
				}
				if (RevitDefines.GE(_dReturnedDouble3, _dReturnedDouble))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("VarianceMoreThanPlantHeightMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					SiteDesigner.UI.WpfFocus.Focus(m_VarianceHeightTextBox);
					return false;
				}
			}
		}
		return true;
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		if (ValidateFields())
		{
			SaveSettings();
			DialogResult = DialogResult.OK;
			Close();
		}
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void OnSearchButtonClick(object sender, EventArgs e)
	{
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			List<FamilySymbol> _SearchSymbolList = new List<FamilySymbol>();
			if (ManagePlants.FindFamilySymbols(EPShared.LocalRM.GetString("LocatePlantSearchTitle"), m_dataBuffer.Document, m_dataBuffer.TransactionContainer, familyContainer.FamilySymbolList, ref _SearchSymbolList))
			{
				m_PlantNameComboBox.DataSource = _SearchSymbolList;
				m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
			}
		}
	}

	private void OnSingleHedgeRowGroveOptionChecked(object sender, EventArgs e)
	{
		m_CenterHedgeRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_AlternateHedgeRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_SideHedgeRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_TriangularRadioButton.Enabled = m_GroveRadioButton.Checked;
		m_SquareRadioButton.Enabled = m_GroveRadioButton.Checked;
		m_RotationLabel.Enabled = m_GroveRadioButton.Checked;
		m_RotationTextBox.Enabled = m_GroveRadioButton.Checked;
		m_PlantSpacingLabel.Enabled = !m_SingleRadioButton.Checked;
		m_PlantSpacingTextBox.Enabled = !m_SingleRadioButton.Checked;
		m_SegmentRadioButton.Enabled = !m_GroveRadioButton.Checked;
		m_ChainRadioButton.Enabled = !m_GroveRadioButton.Checked;
		m_StartingDistanceLabel.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
		m_StartingDistanceTextBox.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
		OnHedgeRowOptionChecked(sender, e);
	}

	private void OnHedgeRowOptionChecked(object sender, EventArgs e)
	{
		if (m_HedgeRowRadioButton.Checked)
		{
			m_SetbackLabel.Enabled = !m_CenterHedgeRadioButton.Checked;
			m_SetbackTextBox.Enabled = !m_CenterHedgeRadioButton.Checked;
		}
		else
		{
			m_SetbackLabel.Enabled = !m_SingleRadioButton.Checked;
			m_SetbackTextBox.Enabled = !m_SingleRadioButton.Checked;
		}
	}

	private void FormatPlantSpacingValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_PlantSpacingTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_PlantSpacingTextBox);
		}
	}

	private void OnPlantSpacingTextBoxLeave(object sender, EventArgs e)
	{
		FormatPlantSpacingValue();
	}

	private void FormatPlantWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_PlantWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_PlantWidthTextBox);
		}
	}

	private void OnPlantWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatPlantWidthValue();
	}

	private void FormatVarianceWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_VarianceWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_VarianceWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_VarianceWidthTextBox);
		}
	}

	private void OnVarianceWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatVarianceWidthValue();
	}

	private void FormatPlantHeightValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_PlantHeightTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_PlantHeightTextBox);
		}
	}

	private void OnPlantHeightTextBoxLeave(object sender, EventArgs e)
	{
		FormatPlantHeightValue();
	}

	private void FormatVarianceHeightValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_VarianceHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_VarianceHeightTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_VarianceHeightTextBox);
		}
	}

	private void OnVarianceHeightTextBoxLeave(object sender, EventArgs e)
	{
		FormatVarianceHeightValue();
	}

	private void FormatSetbackValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_SetbackTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
		}
	}

	private void OnSetbackTextBoxLeave(object sender, EventArgs e)
	{
		FormatSetbackValue();
	}

	private void FormatRotationValue()
	{
		string _strAngleStr = string.Empty;
		double num = 0.0;
		num = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_RotationTextBox.Text);
		if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(m_AngularOptions.LegacyDisplayUnits(), num, m_dAngularRounding, m_AngularSymbolType, m_DecimalSymbolType, ref _strAngleStr) == 0)
		{
			m_RotationTextBox.Text = _strAngleStr;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_RotationTextBox);
		}
	}

	private void OnRotationTextBoxLeave(object sender, EventArgs e)
	{
		FormatRotationValue();
	}

	private void OnPlantWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatPlantWidthValue();
		}
	}

	private void OnPlantHeightTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatPlantHeightValue();
		}
	}

	private void OnPlantSpacingTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatPlantSpacingValue();
		}
	}

	private void OnVarianceWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatVarianceWidthValue();
		}
	}

	private void OnVarianceHeightTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatVarianceHeightValue();
		}
	}

	private void OnRotationTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatRotationValue();
		}
	}

	private void OnSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatSetbackValue();
		}
	}

	private void OnCreatePlantGroupCheckBoxChecked(object sender, EventArgs e)
	{
		m_LeaderedTagCheckBox.Enabled = m_CreatePlantGroupTagCheckBox.Checked;
	}

	private void GetPlantParameters()
	{
		List<Eps_Point> list = null;
		LocationPoint locationPoint = null;
		Eps_Point eps_Point = new Eps_Point();
		Eps_Point eps_Point2 = null;
		FamilyInstance familyInstance = null;
		if (!(m_PlantNameComboBox.SelectedItem is FamilySymbol familySymbol))
		{
			return;
		}
		m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
		list = null;
		foreach (Element currentElement in m_dataBuffer.CurrentElementList)
		{
			if (currentElement is FamilyInstance { Symbol: not null } familyInstance2 && familyInstance2.Symbol.Category != null && familyInstance2.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(familySymbol.UniqueId, familyInstance2.Symbol.UniqueId, ignoreCase: true) == 0)
			{
				if (list == null)
				{
					list = new List<Eps_Point>();
				}
				locationPoint = familyInstance2.Location as LocationPoint;
				eps_Point2 = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point2, list))
				{
					list.Add(eps_Point2);
				}
			}
		}
		if (list != null && list.Count > 0)
		{
			bool flag = true;
			while (flag)
			{
				flag = false;
				for (int i = 0; i < list.Count; i++)
				{
					if (EPShared.eplGeoE_ArePntsDuplicates3D(list[i], eps_Point))
					{
						eps_Point.z++;
						flag = true;
						break;
					}
				}
			}
		}
		EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
		FamilyInstance familyInstance3 = RevitUtility.NewFamilyInstance(m_dataBuffer.Document, eps_Point.XYZ, familySymbol, null, null, StructuralType.NonStructural, ref _TransactionContainer);
		m_dataBuffer.TransactionContainer = _TransactionContainer;
		ElementSet elementSet = new ElementSet();
		elementSet.Insert(familyInstance3);
		m_dataBuffer.Document.ActiveView.HideElements(ElementSetConverter.ToIDList(elementSet));
		if (familyInstance3 != null && familyInstance3.Symbol != null)
		{
			double num = 0.0;
			string _strToDisplay = string.Empty;
			Parameter parameter = familyInstance3.LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
			if (parameter != null)
			{
				m_PlantHeightLabel.Enabled = true;
				m_PlantHeightTextBox.Enabled = true;
				m_VarianceHeightLabel.Enabled = true;
				m_VarianceHeightTextBox.Enabled = true;
				num = parameter.AsDouble();
				RevitGeometry.Units_ConvertDoubleToString(num, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_PlantHeightTextBox.Text = _strToDisplay;
			}
			else
			{
				m_PlantHeightTextBox.Text = string.Empty;
				m_PlantHeightLabel.Enabled = false;
				m_PlantHeightTextBox.Enabled = false;
				m_VarianceHeightLabel.Enabled = false;
				m_VarianceHeightTextBox.Enabled = false;
			}
			parameter = familyInstance3.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
			if (parameter != null)
			{
				m_PlantWidthLabel.Enabled = true;
				m_PlantWidthTextBox.Enabled = true;
				m_VarianceWidthLabel.Enabled = true;
				m_VarianceWidthTextBox.Enabled = true;
				num = parameter.AsDouble();
				RevitGeometry.Units_ConvertDoubleToString(num, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_PlantWidthTextBox.Text = _strToDisplay;
			}
			else
			{
				m_PlantWidthTextBox.Text = string.Empty;
				m_PlantWidthLabel.Enabled = false;
				m_PlantWidthTextBox.Enabled = false;
				m_VarianceWidthLabel.Enabled = false;
				m_VarianceWidthTextBox.Enabled = false;
			}
			parameter = familyInstance3.Symbol.LookupParameter(RevitParameters.PlantSpacingPlantFamilyParameter);
			if (parameter != null)
			{
				num = parameter.AsDouble();
				if (RevitDefines.GT(num, 0.0))
				{
					RevitGeometry.Units_ConvertDoubleToString(num, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
					m_PlantSpacingTextBox.Text = _strToDisplay;
				}
			}
			m_dataBuffer.TransactionContainer.BeginTransaction();
			m_dataBuffer.Document.Delete(familyInstance3.Id);
			m_dataBuffer.TransactionContainer.EndTransaction();
		}
		m_dataBuffer.TransactionContainer.Rollback();
	}

	private void OnPlantNameComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		GetPlantParameters();
	}

	private void OnPlacePlantFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_PlantNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnLoadFamilyButtonClick(object sender, EventArgs e)
	{
		int count = m_PlantFamilyComboBox.Items.Count;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		FamilyContainer familyContainer = null;
		Family _Family = null;
		openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectPlantingFamilyFileMessage");
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				try
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + openFileDialog.SafeFileName);
					EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
					flag = RevitUtility.LoadFamily(m_dataBuffer.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
					m_dataBuffer.TransactionContainer = _TransactionContainer;
					m_dataBuffer.TransactionContainer.Commit();
				}
				catch (SEHException)
				{
					m_dataBuffer.TransactionContainer.Rollback();
					flag = false;
					RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					continue;
				}
				break;
			}
		}
		if (!flag)
		{
			if (count == 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_dataBuffer.PopulateFamilyAndSymbolLists();
		m_PlantFamilyComboBox.DataSource = m_dataBuffer.PlantFamilyList;
		m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (_Family != null)
		{
			for (int i = 0; i < m_PlantFamilyComboBox.Items.Count; i++)
			{
				if (m_PlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _Family.Name, ignoreCase: true) == 0)
				{
					m_PlantFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (m_PlantFamilyComboBox.Items.Count == count)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
	{
		m_DeleteExistingCheckBox.Enabled = m_ExistingElementCheckBox.Checked;
		m_StartingDistanceLabel.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
		m_StartingDistanceTextBox.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
	}

	private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyData == Keys.Return)
		{
			FormatStartingDistanceValue();
		}
	}

	private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
	{
		FormatStartingDistanceValue();
	}

	private void FormatStartingDistanceValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_StartingDistanceTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_StartingDistanceTextBox);
		}
	}

	private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
	{
		m_SurfaceList.Enabled = m_ToposurfaceCheckBox.Checked;
		m_SelectedSurfaceLabel.Enabled = m_ToposurfaceCheckBox.Checked;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_PlantFamilyLabel = new System.Windows.Forms.Label();
		this.m_PlantFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_HedgeRowRadioButton = new System.Windows.Forms.RadioButton();
		this.m_PlantNameLabel = new System.Windows.Forms.Label();
		this.m_PlantNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_PlantWidthLabel = new System.Windows.Forms.Label();
		this.m_PlantWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_VarianceWidthLabel = new System.Windows.Forms.Label();
		this.m_VarianceWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_VarianceHeightTextBox = new System.Windows.Forms.TextBox();
		this.m_VarianceHeightLabel = new System.Windows.Forms.Label();
		this.m_PlantHeightTextBox = new System.Windows.Forms.TextBox();
		this.m_PlantHeightLabel = new System.Windows.Forms.Label();
		this.m_PlantSpacingLabel = new System.Windows.Forms.Label();
		this.m_PlantSpacingTextBox = new System.Windows.Forms.TextBox();
		this.m_GroveRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SearchButton = new System.Windows.Forms.Button();
		this.m_HedgeRowPanel = new System.Windows.Forms.Panel();
		this.m_SideHedgeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_AlternateHedgeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CenterHedgeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_GrovePanel = new System.Windows.Forms.Panel();
		this.m_SquareRadioButton = new System.Windows.Forms.RadioButton();
		this.m_TriangularRadioButton = new System.Windows.Forms.RadioButton();
		this.m_RotationLabel = new System.Windows.Forms.Label();
		this.m_RotationTextBox = new System.Windows.Forms.TextBox();
		this.m_LoadFamilyButton = new System.Windows.Forms.Button();
		this.m_ExistingElementCheckBox = new System.Windows.Forms.CheckBox();
		this.m_SingleRadioButton = new System.Windows.Forms.RadioButton();
		this.m_FirstMoveablePanel = new System.Windows.Forms.Panel();
		this.m_SurfaceList = new System.Windows.Forms.ComboBox();
		this.m_SelectedSurfaceLabel = new System.Windows.Forms.Label();
		this.m_ToposurfaceCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ChainRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SegmentRadioButton = new System.Windows.Forms.RadioButton();
		this.m_PlaceTagGroupBox = new System.Windows.Forms.GroupBox();
		this.m_LeaderedTagCheckBox = new System.Windows.Forms.CheckBox();
		this.m_CreatePlantGroupTagCheckBox = new System.Windows.Forms.CheckBox();
		this.m_LevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelLabel = new System.Windows.Forms.Label();
		this.m_SecondMoveablePanel = new System.Windows.Forms.Panel();
		this.m_StartingDistanceLabel = new System.Windows.Forms.Label();
		this.m_StartingDistanceTextBox = new System.Windows.Forms.TextBox();
		this.m_DeleteExistingCheckBox = new System.Windows.Forms.CheckBox();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_InsertButton = new System.Windows.Forms.Button();
		this.m_SetbackLabel = new System.Windows.Forms.Label();
		this.m_SetbackTextBox = new System.Windows.Forms.TextBox();
		this.m_HedgeRowPanel.SuspendLayout();
		this.m_GrovePanel.SuspendLayout();
		this.m_FirstMoveablePanel.SuspendLayout();
		this.m_PlaceTagGroupBox.SuspendLayout();
		this.m_SecondMoveablePanel.SuspendLayout();
		base.SuspendLayout();
		this.m_PlantFamilyLabel.AutoSize = true;
		this.m_PlantFamilyLabel.Location = new System.Drawing.Point(12, 15);
		this.m_PlantFamilyLabel.Name = "m_PlantFamilyLabel";
		this.m_PlantFamilyLabel.Size = new System.Drawing.Size(66, 13);
		this.m_PlantFamilyLabel.TabIndex = 0;
		this.m_PlantFamilyLabel.Text = "&Plant Family:";
		this.m_PlantFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantFamilyComboBox.FormattingEnabled = true;
		this.m_PlantFamilyComboBox.Location = new System.Drawing.Point(116, 12);
		this.m_PlantFamilyComboBox.Name = "m_PlantFamilyComboBox";
		this.m_PlantFamilyComboBox.Size = new System.Drawing.Size(214, 21);
		this.m_PlantFamilyComboBox.TabIndex = 1;
		this.m_PlantFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnPlantFamilyComboBoxSelectedIndexChanged);
		this.m_HedgeRowRadioButton.AutoSize = true;
		this.m_HedgeRowRadioButton.Location = new System.Drawing.Point(12, 146);
		this.m_HedgeRowRadioButton.Name = "m_HedgeRowRadioButton";
		this.m_HedgeRowRadioButton.Size = new System.Drawing.Size(82, 17);
		this.m_HedgeRowRadioButton.TabIndex = 18;
		this.m_HedgeRowRadioButton.TabStop = true;
		this.m_HedgeRowRadioButton.Text = "&Hedge Row";
		this.m_HedgeRowRadioButton.UseVisualStyleBackColor = true;
		this.m_HedgeRowRadioButton.CheckedChanged += new System.EventHandler(this.OnSingleHedgeRowGroveOptionChecked);
		this.m_PlantNameLabel.AutoSize = true;
		this.m_PlantNameLabel.Location = new System.Drawing.Point(12, 43);
		this.m_PlantNameLabel.Name = "m_PlantNameLabel";
		this.m_PlantNameLabel.Size = new System.Drawing.Size(65, 13);
		this.m_PlantNameLabel.TabIndex = 3;
		this.m_PlantNameLabel.Text = "P&lant Name:";
		this.m_PlantNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantNameComboBox.FormattingEnabled = true;
		this.m_PlantNameComboBox.Location = new System.Drawing.Point(116, 39);
		this.m_PlantNameComboBox.Name = "m_PlantNameComboBox";
		this.m_PlantNameComboBox.Size = new System.Drawing.Size(214, 21);
		this.m_PlantNameComboBox.TabIndex = 4;
		this.m_PlantNameComboBox.SelectedIndexChanged += new System.EventHandler(this.OnPlantNameComboBoxSelectedIndexChanged);
		this.m_PlantWidthLabel.AutoSize = true;
		this.m_PlantWidthLabel.Location = new System.Drawing.Point(12, 71);
		this.m_PlantWidthLabel.Name = "m_PlantWidthLabel";
		this.m_PlantWidthLabel.Size = new System.Drawing.Size(65, 13);
		this.m_PlantWidthLabel.TabIndex = 6;
		this.m_PlantWidthLabel.Text = "Plant &Width:";
		this.m_PlantWidthTextBox.Location = new System.Drawing.Point(116, 68);
		this.m_PlantWidthTextBox.Name = "m_PlantWidthTextBox";
		this.m_PlantWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_PlantWidthTextBox.TabIndex = 7;
		this.m_PlantWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnPlantWidthTextBoxKeyDown);
		this.m_PlantWidthTextBox.Leave += new System.EventHandler(this.OnPlantWidthTextBoxLeave);
		this.m_VarianceWidthLabel.AutoSize = true;
		this.m_VarianceWidthLabel.Location = new System.Drawing.Point(234, 71);
		this.m_VarianceWidthLabel.Name = "m_VarianceWidthLabel";
		this.m_VarianceWidthLabel.Size = new System.Drawing.Size(52, 13);
		this.m_VarianceWidthLabel.TabIndex = 8;
		this.m_VarianceWidthLabel.Text = "&Variance:";
		this.m_VarianceWidthTextBox.Location = new System.Drawing.Point(311, 68);
		this.m_VarianceWidthTextBox.Name = "m_VarianceWidthTextBox";
		this.m_VarianceWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_VarianceWidthTextBox.TabIndex = 9;
		this.m_VarianceWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnVarianceWidthTextBoxKeyDown);
		this.m_VarianceWidthTextBox.Leave += new System.EventHandler(this.OnVarianceWidthTextBoxLeave);
		this.m_VarianceHeightTextBox.Location = new System.Drawing.Point(311, 94);
		this.m_VarianceHeightTextBox.Name = "m_VarianceHeightTextBox";
		this.m_VarianceHeightTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_VarianceHeightTextBox.TabIndex = 13;
		this.m_VarianceHeightTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnVarianceHeightTextBoxKeyDown);
		this.m_VarianceHeightTextBox.Leave += new System.EventHandler(this.OnVarianceHeightTextBoxLeave);
		this.m_VarianceHeightLabel.AutoSize = true;
		this.m_VarianceHeightLabel.Location = new System.Drawing.Point(234, 97);
		this.m_VarianceHeightLabel.Name = "m_VarianceHeightLabel";
		this.m_VarianceHeightLabel.Size = new System.Drawing.Size(52, 13);
		this.m_VarianceHeightLabel.TabIndex = 12;
		this.m_VarianceHeightLabel.Text = "Varianc&e:";
		this.m_PlantHeightTextBox.Location = new System.Drawing.Point(116, 94);
		this.m_PlantHeightTextBox.Name = "m_PlantHeightTextBox";
		this.m_PlantHeightTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_PlantHeightTextBox.TabIndex = 11;
		this.m_PlantHeightTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnPlantHeightTextBoxKeyDown);
		this.m_PlantHeightTextBox.Leave += new System.EventHandler(this.OnPlantHeightTextBoxLeave);
		this.m_PlantHeightLabel.AutoSize = true;
		this.m_PlantHeightLabel.Location = new System.Drawing.Point(12, 97);
		this.m_PlantHeightLabel.Name = "m_PlantHeightLabel";
		this.m_PlantHeightLabel.Size = new System.Drawing.Size(68, 13);
		this.m_PlantHeightLabel.TabIndex = 10;
		this.m_PlantHeightLabel.Text = "Pla&nt Height:";
		this.m_PlantSpacingLabel.AutoSize = true;
		this.m_PlantSpacingLabel.Location = new System.Drawing.Point(12, 123);
		this.m_PlantSpacingLabel.Name = "m_PlantSpacingLabel";
		this.m_PlantSpacingLabel.Size = new System.Drawing.Size(76, 13);
		this.m_PlantSpacingLabel.TabIndex = 14;
		this.m_PlantSpacingLabel.Text = "Plan&t Spacing:";
		this.m_PlantSpacingTextBox.Location = new System.Drawing.Point(116, 120);
		this.m_PlantSpacingTextBox.Name = "m_PlantSpacingTextBox";
		this.m_PlantSpacingTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_PlantSpacingTextBox.TabIndex = 15;
		this.m_PlantSpacingTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnPlantSpacingTextBoxKeyDown);
		this.m_PlantSpacingTextBox.Leave += new System.EventHandler(this.OnPlantSpacingTextBoxLeave);
		this.m_GroveRadioButton.AutoSize = true;
		this.m_GroveRadioButton.Location = new System.Drawing.Point(12, 197);
		this.m_GroveRadioButton.Name = "m_GroveRadioButton";
		this.m_GroveRadioButton.Size = new System.Drawing.Size(54, 17);
		this.m_GroveRadioButton.TabIndex = 20;
		this.m_GroveRadioButton.TabStop = true;
		this.m_GroveRadioButton.Text = "&Grove";
		this.m_GroveRadioButton.UseVisualStyleBackColor = true;
		this.m_GroveRadioButton.CheckedChanged += new System.EventHandler(this.OnSingleHedgeRowGroveOptionChecked);
		this.m_SearchButton.Location = new System.Drawing.Point(336, 38);
		this.m_SearchButton.Name = "m_SearchButton";
		this.m_SearchButton.Size = new System.Drawing.Size(75, 23);
		this.m_SearchButton.TabIndex = 5;
		this.m_SearchButton.Text = "Sea&rch";
		this.m_SearchButton.UseVisualStyleBackColor = true;
		this.m_SearchButton.Click += new System.EventHandler(this.OnSearchButtonClick);
		this.m_HedgeRowPanel.Controls.Add(this.m_SideHedgeRadioButton);
		this.m_HedgeRowPanel.Controls.Add(this.m_AlternateHedgeRadioButton);
		this.m_HedgeRowPanel.Controls.Add(this.m_CenterHedgeRadioButton);
		this.m_HedgeRowPanel.Location = new System.Drawing.Point(29, 169);
		this.m_HedgeRowPanel.Name = "m_HedgeRowPanel";
		this.m_HedgeRowPanel.Size = new System.Drawing.Size(382, 24);
		this.m_HedgeRowPanel.TabIndex = 19;
		this.m_SideHedgeRadioButton.AutoSize = true;
		this.m_SideHedgeRadioButton.Location = new System.Drawing.Point(270, 4);
		this.m_SideHedgeRadioButton.Name = "m_SideHedgeRadioButton";
		this.m_SideHedgeRadioButton.Size = new System.Drawing.Size(46, 17);
		this.m_SideHedgeRadioButton.TabIndex = 2;
		this.m_SideHedgeRadioButton.TabStop = true;
		this.m_SideHedgeRadioButton.Text = "&Side";
		this.m_SideHedgeRadioButton.UseVisualStyleBackColor = true;
		this.m_SideHedgeRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowOptionChecked);
		this.m_AlternateHedgeRadioButton.AutoSize = true;
		this.m_AlternateHedgeRadioButton.Location = new System.Drawing.Point(139, 4);
		this.m_AlternateHedgeRadioButton.Name = "m_AlternateHedgeRadioButton";
		this.m_AlternateHedgeRadioButton.Size = new System.Drawing.Size(67, 17);
		this.m_AlternateHedgeRadioButton.TabIndex = 1;
		this.m_AlternateHedgeRadioButton.TabStop = true;
		this.m_AlternateHedgeRadioButton.Text = "&Alternate";
		this.m_AlternateHedgeRadioButton.UseVisualStyleBackColor = true;
		this.m_AlternateHedgeRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowOptionChecked);
		this.m_CenterHedgeRadioButton.AutoSize = true;
		this.m_CenterHedgeRadioButton.Location = new System.Drawing.Point(3, 4);
		this.m_CenterHedgeRadioButton.Name = "m_CenterHedgeRadioButton";
		this.m_CenterHedgeRadioButton.Size = new System.Drawing.Size(56, 17);
		this.m_CenterHedgeRadioButton.TabIndex = 0;
		this.m_CenterHedgeRadioButton.TabStop = true;
		this.m_CenterHedgeRadioButton.Text = "C&enter";
		this.m_CenterHedgeRadioButton.UseVisualStyleBackColor = true;
		this.m_CenterHedgeRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowOptionChecked);
		this.m_GrovePanel.Controls.Add(this.m_SquareRadioButton);
		this.m_GrovePanel.Controls.Add(this.m_TriangularRadioButton);
		this.m_GrovePanel.Location = new System.Drawing.Point(29, 220);
		this.m_GrovePanel.Name = "m_GrovePanel";
		this.m_GrovePanel.Size = new System.Drawing.Size(382, 24);
		this.m_GrovePanel.TabIndex = 21;
		this.m_SquareRadioButton.AutoSize = true;
		this.m_SquareRadioButton.Location = new System.Drawing.Point(139, 3);
		this.m_SquareRadioButton.Name = "m_SquareRadioButton";
		this.m_SquareRadioButton.Size = new System.Drawing.Size(59, 17);
		this.m_SquareRadioButton.TabIndex = 1;
		this.m_SquareRadioButton.TabStop = true;
		this.m_SquareRadioButton.Text = "S&quare";
		this.m_SquareRadioButton.UseVisualStyleBackColor = true;
		this.m_TriangularRadioButton.AutoSize = true;
		this.m_TriangularRadioButton.Location = new System.Drawing.Point(3, 3);
		this.m_TriangularRadioButton.Name = "m_TriangularRadioButton";
		this.m_TriangularRadioButton.Size = new System.Drawing.Size(72, 17);
		this.m_TriangularRadioButton.TabIndex = 0;
		this.m_TriangularRadioButton.TabStop = true;
		this.m_TriangularRadioButton.Text = "Triang&ular";
		this.m_TriangularRadioButton.UseVisualStyleBackColor = true;
		this.m_RotationLabel.AutoSize = true;
		this.m_RotationLabel.Enabled = false;
		this.m_RotationLabel.Location = new System.Drawing.Point(31, 253);
		this.m_RotationLabel.Name = "m_RotationLabel";
		this.m_RotationLabel.Size = new System.Drawing.Size(50, 13);
		this.m_RotationLabel.TabIndex = 22;
		this.m_RotationLabel.Text = "R&otation:";
		this.m_RotationTextBox.Enabled = false;
		this.m_RotationTextBox.Location = new System.Drawing.Point(116, 250);
		this.m_RotationTextBox.Name = "m_RotationTextBox";
		this.m_RotationTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_RotationTextBox.TabIndex = 23;
		this.m_RotationTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnRotationTextBoxKeyDown);
		this.m_RotationTextBox.Leave += new System.EventHandler(this.OnRotationTextBoxLeave);
		this.m_LoadFamilyButton.Location = new System.Drawing.Point(336, 12);
		this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
		this.m_LoadFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadFamilyButton.TabIndex = 2;
		this.m_LoadFamilyButton.TabStop = false;
		this.m_LoadFamilyButton.Text = "...";
		this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Click += new System.EventHandler(this.OnLoadFamilyButtonClick);
		this.m_ExistingElementCheckBox.AutoSize = true;
		this.m_ExistingElementCheckBox.Location = new System.Drawing.Point(12, 473);
		this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
		this.m_ExistingElementCheckBox.Size = new System.Drawing.Size(103, 17);
		this.m_ExistingElementCheckBox.TabIndex = 26;
		this.m_ExistingElementCheckBox.Text = "Existing Ele&ment";
		this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
		this.m_ExistingElementCheckBox.CheckedChanged += new System.EventHandler(this.OnExistingElementCheckBoxChecked);
		this.m_SingleRadioButton.AutoSize = true;
		this.m_SingleRadioButton.Location = new System.Drawing.Point(12, 276);
		this.m_SingleRadioButton.Name = "m_SingleRadioButton";
		this.m_SingleRadioButton.Size = new System.Drawing.Size(54, 17);
		this.m_SingleRadioButton.TabIndex = 24;
		this.m_SingleRadioButton.TabStop = true;
		this.m_SingleRadioButton.Text = "Single";
		this.m_SingleRadioButton.UseVisualStyleBackColor = true;
		this.m_SingleRadioButton.CheckedChanged += new System.EventHandler(this.OnSingleHedgeRowGroveOptionChecked);
		this.m_FirstMoveablePanel.Controls.Add(this.m_SurfaceList);
		this.m_FirstMoveablePanel.Controls.Add(this.m_SelectedSurfaceLabel);
		this.m_FirstMoveablePanel.Controls.Add(this.m_ToposurfaceCheckBox);
		this.m_FirstMoveablePanel.Controls.Add(this.m_ChainRadioButton);
		this.m_FirstMoveablePanel.Controls.Add(this.m_SegmentRadioButton);
		this.m_FirstMoveablePanel.Controls.Add(this.m_PlaceTagGroupBox);
		this.m_FirstMoveablePanel.Controls.Add(this.m_LevelComboBox);
		this.m_FirstMoveablePanel.Controls.Add(this.m_LevelLabel);
		this.m_FirstMoveablePanel.Location = new System.Drawing.Point(12, 299);
		this.m_FirstMoveablePanel.Name = "m_FirstMoveablePanel";
		this.m_FirstMoveablePanel.Size = new System.Drawing.Size(399, 168);
		this.m_FirstMoveablePanel.TabIndex = 25;
		this.m_SurfaceList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_SurfaceList.Enabled = false;
		this.m_SurfaceList.FormattingEnabled = true;
		this.m_SurfaceList.Location = new System.Drawing.Point(104, 53);
		this.m_SurfaceList.Name = "m_SurfaceList";
		this.m_SurfaceList.Size = new System.Drawing.Size(214, 21);
		this.m_SurfaceList.TabIndex = 4;
		this.m_SelectedSurfaceLabel.AutoSize = true;
		this.m_SelectedSurfaceLabel.Enabled = false;
		this.m_SelectedSurfaceLabel.Location = new System.Drawing.Point(0, 55);
		this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
		this.m_SelectedSurfaceLabel.Size = new System.Drawing.Size(44, 13);
		this.m_SelectedSurfaceLabel.TabIndex = 3;
		this.m_SelectedSurfaceLabel.Text = "Surface";
		this.m_ToposurfaceCheckBox.AutoSize = true;
		this.m_ToposurfaceCheckBox.Location = new System.Drawing.Point(0, 30);
		this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
		this.m_ToposurfaceCheckBox.Size = new System.Drawing.Size(110, 17);
		this.m_ToposurfaceCheckBox.TabIndex = 2;
		this.m_ToposurfaceCheckBox.Text = "Pick Toposurface";
		this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
		this.m_ToposurfaceCheckBox.CheckStateChanged += new System.EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
		this.m_ChainRadioButton.AutoSize = true;
		this.m_ChainRadioButton.Location = new System.Drawing.Point(151, 151);
		this.m_ChainRadioButton.Name = "m_ChainRadioButton";
		this.m_ChainRadioButton.Size = new System.Drawing.Size(52, 17);
		this.m_ChainRadioButton.TabIndex = 7;
		this.m_ChainRadioButton.Text = "&Chain";
		this.m_ChainRadioButton.UseVisualStyleBackColor = true;
		this.m_SegmentRadioButton.AutoSize = true;
		this.m_SegmentRadioButton.Checked = true;
		this.m_SegmentRadioButton.Location = new System.Drawing.Point(0, 151);
		this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
		this.m_SegmentRadioButton.Size = new System.Drawing.Size(67, 17);
		this.m_SegmentRadioButton.TabIndex = 6;
		this.m_SegmentRadioButton.TabStop = true;
		this.m_SegmentRadioButton.Text = "&Segment";
		this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
		this.m_PlaceTagGroupBox.Controls.Add(this.m_LeaderedTagCheckBox);
		this.m_PlaceTagGroupBox.Controls.Add(this.m_CreatePlantGroupTagCheckBox);
		this.m_PlaceTagGroupBox.Location = new System.Drawing.Point(0, 80);
		this.m_PlaceTagGroupBox.Name = "m_PlaceTagGroupBox";
		this.m_PlaceTagGroupBox.Size = new System.Drawing.Size(399, 65);
		this.m_PlaceTagGroupBox.TabIndex = 5;
		this.m_PlaceTagGroupBox.TabStop = false;
		this.m_PlaceTagGroupBox.Text = "Place Tag";
		this.m_LeaderedTagCheckBox.AutoSize = true;
		this.m_LeaderedTagCheckBox.Enabled = false;
		this.m_LeaderedTagCheckBox.Location = new System.Drawing.Point(20, 42);
		this.m_LeaderedTagCheckBox.Name = "m_LeaderedTagCheckBox";
		this.m_LeaderedTagCheckBox.Size = new System.Drawing.Size(93, 17);
		this.m_LeaderedTagCheckBox.TabIndex = 1;
		this.m_LeaderedTagCheckBox.Text = "Lea&dered Tag";
		this.m_LeaderedTagCheckBox.UseVisualStyleBackColor = true;
		this.m_CreatePlantGroupTagCheckBox.AutoSize = true;
		this.m_CreatePlantGroupTagCheckBox.Location = new System.Drawing.Point(6, 19);
		this.m_CreatePlantGroupTagCheckBox.Name = "m_CreatePlantGroupTagCheckBox";
		this.m_CreatePlantGroupTagCheckBox.Size = new System.Drawing.Size(138, 17);
		this.m_CreatePlantGroupTagCheckBox.TabIndex = 0;
		this.m_CreatePlantGroupTagCheckBox.Text = "Create Plant Group Tag";
		this.m_CreatePlantGroupTagCheckBox.UseVisualStyleBackColor = true;
		this.m_CreatePlantGroupTagCheckBox.CheckedChanged += new System.EventHandler(this.OnCreatePlantGroupCheckBoxChecked);
		this.m_LevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LevelComboBox.FormattingEnabled = true;
		this.m_LevelComboBox.Location = new System.Drawing.Point(104, 3);
		this.m_LevelComboBox.Name = "m_LevelComboBox";
		this.m_LevelComboBox.Size = new System.Drawing.Size(214, 21);
		this.m_LevelComboBox.TabIndex = 1;
		this.m_LevelLabel.AutoSize = true;
		this.m_LevelLabel.Location = new System.Drawing.Point(0, 3);
		this.m_LevelLabel.Name = "m_LevelLabel";
		this.m_LevelLabel.Size = new System.Drawing.Size(36, 13);
		this.m_LevelLabel.TabIndex = 0;
		this.m_LevelLabel.Text = "&Level:";
		this.m_SecondMoveablePanel.Controls.Add(this.m_StartingDistanceLabel);
		this.m_SecondMoveablePanel.Controls.Add(this.m_StartingDistanceTextBox);
		this.m_SecondMoveablePanel.Controls.Add(this.m_DeleteExistingCheckBox);
		this.m_SecondMoveablePanel.Controls.Add(this.m_CancelButton);
		this.m_SecondMoveablePanel.Controls.Add(this.m_InsertButton);
		this.m_SecondMoveablePanel.Location = new System.Drawing.Point(12, 496);
		this.m_SecondMoveablePanel.Name = "m_SecondMoveablePanel";
		this.m_SecondMoveablePanel.Size = new System.Drawing.Size(399, 72);
		this.m_SecondMoveablePanel.TabIndex = 27;
		this.m_StartingDistanceLabel.AutoSize = true;
		this.m_StartingDistanceLabel.Enabled = false;
		this.m_StartingDistanceLabel.Location = new System.Drawing.Point(20, 26);
		this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
		this.m_StartingDistanceLabel.Size = new System.Drawing.Size(91, 13);
		this.m_StartingDistanceLabel.TabIndex = 1;
		this.m_StartingDistanceLabel.Text = "Starting Distance:";
		this.m_StartingDistanceTextBox.Enabled = false;
		this.m_StartingDistanceTextBox.Location = new System.Drawing.Point(156, 23);
		this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
		this.m_StartingDistanceTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_StartingDistanceTextBox.TabIndex = 2;
		this.m_StartingDistanceTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
		this.m_StartingDistanceTextBox.Leave += new System.EventHandler(this.OnStartingDistanceTextBoxLeave);
		this.m_DeleteExistingCheckBox.AutoSize = true;
		this.m_DeleteExistingCheckBox.Enabled = false;
		this.m_DeleteExistingCheckBox.Location = new System.Drawing.Point(20, 0);
		this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
		this.m_DeleteExistingCheckBox.Size = new System.Drawing.Size(137, 17);
		this.m_DeleteExistingCheckBox.TabIndex = 0;
		this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
		this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(324, 49);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_InsertButton.Location = new System.Drawing.Point(243, 49);
		this.m_InsertButton.Name = "m_InsertButton";
		this.m_InsertButton.Size = new System.Drawing.Size(75, 23);
		this.m_InsertButton.TabIndex = 3;
		this.m_InsertButton.Text = "&Insert";
		this.m_InsertButton.UseVisualStyleBackColor = true;
		this.m_InsertButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_SetbackLabel.AutoSize = true;
		this.m_SetbackLabel.Location = new System.Drawing.Point(234, 123);
		this.m_SetbackLabel.Name = "m_SetbackLabel";
		this.m_SetbackLabel.Size = new System.Drawing.Size(50, 13);
		this.m_SetbackLabel.TabIndex = 16;
		this.m_SetbackLabel.Text = "Set&back:";
		this.m_SetbackTextBox.Location = new System.Drawing.Point(311, 120);
		this.m_SetbackTextBox.Name = "m_SetbackTextBox";
		this.m_SetbackTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_SetbackTextBox.TabIndex = 17;
		this.m_SetbackTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnSetbackTextBoxKeyDown);
		this.m_SetbackTextBox.Leave += new System.EventHandler(this.OnSetbackTextBoxLeave);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(423, 580);
		base.Controls.Add(this.m_SetbackLabel);
		base.Controls.Add(this.m_SetbackTextBox);
		base.Controls.Add(this.m_SecondMoveablePanel);
		base.Controls.Add(this.m_FirstMoveablePanel);
		base.Controls.Add(this.m_SingleRadioButton);
		base.Controls.Add(this.m_ExistingElementCheckBox);
		base.Controls.Add(this.m_LoadFamilyButton);
		base.Controls.Add(this.m_RotationLabel);
		base.Controls.Add(this.m_RotationTextBox);
		base.Controls.Add(this.m_GrovePanel);
		base.Controls.Add(this.m_HedgeRowPanel);
		base.Controls.Add(this.m_SearchButton);
		base.Controls.Add(this.m_GroveRadioButton);
		base.Controls.Add(this.m_PlantSpacingLabel);
		base.Controls.Add(this.m_PlantSpacingTextBox);
		base.Controls.Add(this.m_VarianceHeightTextBox);
		base.Controls.Add(this.m_VarianceHeightLabel);
		base.Controls.Add(this.m_PlantHeightTextBox);
		base.Controls.Add(this.m_PlantHeightLabel);
		base.Controls.Add(this.m_VarianceWidthTextBox);
		base.Controls.Add(this.m_VarianceWidthLabel);
		base.Controls.Add(this.m_PlantWidthTextBox);
		base.Controls.Add(this.m_PlantWidthLabel);
		base.Controls.Add(this.m_PlantNameComboBox);
		base.Controls.Add(this.m_PlantNameLabel);
		base.Controls.Add(this.m_HedgeRowRadioButton);
		base.Controls.Add(this.m_PlantFamilyComboBox);
		base.Controls.Add(this.m_PlantFamilyLabel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "PlacePlantForm";
		this.Text = "Locate Plants";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlacePlantFormClosing);
		this.m_HedgeRowPanel.ResumeLayout(false);
		this.m_HedgeRowPanel.PerformLayout();
		this.m_GrovePanel.ResumeLayout(false);
		this.m_GrovePanel.PerformLayout();
		this.m_FirstMoveablePanel.ResumeLayout(false);
		this.m_FirstMoveablePanel.PerformLayout();
		this.m_PlaceTagGroupBox.ResumeLayout(false);
		this.m_PlaceTagGroupBox.PerformLayout();
		this.m_SecondMoveablePanel.ResumeLayout(false);
		this.m_SecondMoveablePanel.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_InsertButton;
		base.CancelButton = this.m_CancelButton;
	}
}
