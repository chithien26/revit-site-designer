﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.QuantumListView
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

#nullable disable
namespace EPCommon;

public class QuantumListView : ListView
{
  private ListViewItem m_ListItem;
  private int m_nX;
  private int m_nY;
  private string m_strSubItemText;
  private int m_nSubItemSelected;
  private TextBox m_EditBox = new TextBox();
  private TextBox m_FileEditBox = new TextBox();
  private Button m_FileOpenButton = new Button();
  private TextBox m_DirectoryEditBox = new TextBox();
  private Button m_DirectoryOpenButton = new Button();
  private Button m_ColorOpenButton = new Button();
  private ComboBox m_OptionsCmbBox = new ComboBox();
  private ComboBox m_CmbBox = new ComboBox();
  public DialogType m_DlgType;
  private bool m_bKeyBoard;
  private bool m_bHandleListViewItem = true;
  private string m_strPreviousFilePath = string.Empty;
  private string m_strPreviousDirectoryPath = string.Empty;
  private const int m_nPopupControlHeight = 20;

  public event ListViewItemChanged OnListViewItemChanged;

  public QuantumListView()
  {
    this.Dock = DockStyle.None;
    this.FullRowSelect = true;
    this.MinimumSize = new Size(430, 280);
    this.Name = nameof (QuantumListView);
    this.Size = new Size(430, 280);
    this.Location = new Point(10, 3);
    this.TabIndex = 0;
    this.View = View.Details;
    this.MouseDown += new MouseEventHandler(this.ListViewMouseDown);
    this.KeyDown += new KeyEventHandler(this.ListViewKeyDown);
    this.Click += new EventHandler(this.ListViewSingleClick);
    this.ColumnWidthChanging += new ColumnWidthChangingEventHandler(this.ColumnWidthChanged);
    this.GridLines = true;
    this.Scrollable = false;
    this.OwnerDraw = false;
    this.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_EditBox.Size = new Size(0, 20);
    this.m_EditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_EditBox
    });
    this.m_EditBox.KeyPress += new KeyPressEventHandler(this.EditOver);
    this.m_EditBox.LostFocus += new EventHandler(this.FocusOver);
    this.m_EditBox.BackColor = Color.White;
    this.m_EditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_EditBox.Hide();
    this.m_EditBox.Text = "";
    this.m_FileEditBox.Size = new Size(0, 20);
    this.m_FileEditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_FileEditBox
    });
    this.m_FileEditBox.KeyPress += new KeyPressEventHandler(this.FileEditEditOver);
    this.m_FileEditBox.LostFocus += new EventHandler(this.FileEditFocusOver);
    this.m_FileEditBox.BackColor = Color.White;
    this.m_FileEditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_FileEditBox.Hide();
    this.m_FileEditBox.Text = "";
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_FileOpenButton
    });
    this.m_FileOpenButton.Size = new Size(0, 20);
    this.m_FileOpenButton.Location = new Point(0, 0);
    this.m_FileOpenButton.BackColor = Control.DefaultBackColor;
    this.m_FileOpenButton.Click += new EventHandler(this.FileOpenButtonClick);
    this.m_FileOpenButton.Text = "...";
    this.m_FileOpenButton.Hide();
    this.m_DirectoryEditBox.Size = new Size(0, 20);
    this.m_DirectoryEditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_DirectoryEditBox
    });
    this.m_DirectoryEditBox.KeyPress += new KeyPressEventHandler(this.DirectoryEditEditOver);
    this.m_DirectoryEditBox.LostFocus += new EventHandler(this.DirectoryEditFocusOver);
    this.m_DirectoryEditBox.BackColor = Color.White;
    this.m_DirectoryEditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_DirectoryEditBox.Hide();
    this.m_DirectoryEditBox.Text = "";
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_DirectoryOpenButton
    });
    this.m_DirectoryOpenButton.Size = new Size(0, 20);
    this.m_DirectoryOpenButton.Location = new Point(0, 0);
    this.m_DirectoryOpenButton.BackColor = Control.DefaultBackColor;
    this.m_DirectoryOpenButton.Click += new EventHandler(this.DirectoryOpenButtonClick);
    this.m_DirectoryOpenButton.Text = "...";
    this.m_DirectoryOpenButton.Hide();
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_ColorOpenButton
    });
    this.m_ColorOpenButton.Size = new Size(0, 20);
    this.m_ColorOpenButton.Location = new Point(0, 0);
    this.m_ColorOpenButton.ImageAlign = ContentAlignment.MiddleLeft;
    this.m_ColorOpenButton.BackColor = Control.DefaultBackColor;
    this.m_ColorOpenButton.Click += new EventHandler(this.ColorOpenButtonClick);
    this.m_ColorOpenButton.LostFocus += new EventHandler(this.ColorFocusOver);
    this.m_ColorOpenButton.KeyPress += new KeyPressEventHandler(this.ColorKeyPress);
    this.m_ColorOpenButton.Text = string.Empty;
    this.m_ColorOpenButton.Hide();
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_OptionsCmbBox
    });
    this.m_OptionsCmbBox.SelectedIndexChanged += new EventHandler(this.CmbSelected);
    this.m_OptionsCmbBox.LostFocus += new EventHandler(this.CmbFocusOver);
    this.m_OptionsCmbBox.KeyPress += new KeyPressEventHandler(this.CmbKeyPress);
    this.m_OptionsCmbBox.BackColor = Color.White;
    this.m_OptionsCmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_OptionsCmbBox.Hide();
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_CmbBox
    });
    this.m_CmbBox.SelectedIndexChanged += new EventHandler(this.MaterialCmbSelected);
    this.m_CmbBox.LostFocus += new EventHandler(this.MaterialCmbFocusOver);
    this.m_CmbBox.KeyPress += new KeyPressEventHandler(this.MaterialCmbKeyPress);
    this.m_CmbBox.BackColor = Color.White;
    this.m_CmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_CmbBox.Hide();
  }

  public QuantumListView(int _nWidth, int _nHeight)
  {
    this.Dock = DockStyle.None;
    this.FullRowSelect = true;
    this.MinimumSize = new Size(_nWidth, _nHeight);
    this.Name = nameof (QuantumListView);
    this.Size = new Size(_nWidth, _nHeight);
    this.Location = new Point(10, 3);
    this.TabIndex = 0;
    this.View = View.Details;
    this.MouseDown += new MouseEventHandler(this.ListViewMouseDown);
    this.KeyDown += new KeyEventHandler(this.ListViewKeyDown);
    this.Click += new EventHandler(this.ListViewSingleClick);
    this.ColumnWidthChanging += new ColumnWidthChangingEventHandler(this.ColumnWidthChanged);
    this.GridLines = true;
    this.Scrollable = false;
    this.OwnerDraw = false;
    this.m_EditBox.Size = new Size(0, 20);
    this.m_EditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_EditBox
    });
    this.m_EditBox.KeyPress += new KeyPressEventHandler(this.EditOver);
    this.m_EditBox.LostFocus += new EventHandler(this.FocusOver);
    this.m_EditBox.BackColor = Color.White;
    this.m_EditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_EditBox.Hide();
    this.m_EditBox.Text = "";
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_OptionsCmbBox
    });
    this.m_OptionsCmbBox.SelectedIndexChanged += new EventHandler(this.CmbSelected);
    this.m_OptionsCmbBox.LostFocus += new EventHandler(this.CmbFocusOver);
    this.m_OptionsCmbBox.KeyPress += new KeyPressEventHandler(this.CmbKeyPress);
    this.m_OptionsCmbBox.BackColor = Color.White;
    this.m_OptionsCmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_OptionsCmbBox.Hide();
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_CmbBox
    });
    this.m_CmbBox.SelectedIndexChanged += new EventHandler(this.MaterialCmbSelected);
    this.m_CmbBox.LostFocus += new EventHandler(this.MaterialCmbFocusOver);
    this.m_CmbBox.KeyPress += new KeyPressEventHandler(this.MaterialCmbKeyPress);
    this.m_CmbBox.BackColor = Color.White;
    this.m_CmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_CmbBox.Hide();
    this.m_FileEditBox.Size = new Size(0, 20);
    this.m_FileEditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_FileEditBox
    });
    this.m_FileEditBox.KeyPress += new KeyPressEventHandler(this.FileEditEditOver);
    this.m_FileEditBox.LostFocus += new EventHandler(this.FileEditFocusOver);
    this.m_FileEditBox.BackColor = Color.White;
    this.m_FileEditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_FileEditBox.Hide();
    this.m_FileEditBox.Text = "";
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_FileOpenButton
    });
    this.m_FileOpenButton.Size = new Size(0, 20);
    this.m_FileOpenButton.Location = new Point(0, 0);
    this.m_FileOpenButton.BackColor = Control.DefaultBackColor;
    this.m_FileOpenButton.Click += new EventHandler(this.FileOpenButtonClick);
    this.m_FileOpenButton.Text = "...";
    this.m_FileOpenButton.Hide();
    this.m_DirectoryEditBox.Size = new Size(0, 20);
    this.m_DirectoryEditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_DirectoryEditBox
    });
    this.m_DirectoryEditBox.KeyPress += new KeyPressEventHandler(this.DirectoryEditEditOver);
    this.m_DirectoryEditBox.LostFocus += new EventHandler(this.DirectoryEditFocusOver);
    this.m_DirectoryEditBox.BackColor = Color.White;
    this.m_DirectoryEditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_DirectoryEditBox.Hide();
    this.m_DirectoryEditBox.Text = "";
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_DirectoryOpenButton
    });
    this.m_DirectoryOpenButton.Size = new Size(0, 20);
    this.m_DirectoryOpenButton.Location = new Point(0, 0);
    this.m_DirectoryOpenButton.BackColor = Control.DefaultBackColor;
    this.m_DirectoryOpenButton.Click += new EventHandler(this.DirectoryOpenButtonClick);
    this.m_DirectoryOpenButton.Text = "...";
    this.m_DirectoryOpenButton.Hide();
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_ColorOpenButton
    });
    this.m_ColorOpenButton.Size = new Size(0, 20);
    this.m_ColorOpenButton.Location = new Point(0, 0);
    this.m_ColorOpenButton.ImageAlign = ContentAlignment.MiddleLeft;
    this.m_ColorOpenButton.BackColor = Control.DefaultBackColor;
    this.m_ColorOpenButton.Click += new EventHandler(this.ColorOpenButtonClick);
    this.m_ColorOpenButton.LostFocus += new EventHandler(this.ColorFocusOver);
    this.m_ColorOpenButton.KeyPress += new KeyPressEventHandler(this.ColorKeyPress);
    this.m_ColorOpenButton.Text = string.Empty;
    this.m_ColorOpenButton.Hide();
  }

  private void ColorOpenButtonClick(object sender, EventArgs e)
  {
    using (ColorDialog colorDialog = new ColorDialog())
    {
      Color _FindColor = new Color();
      if (RevitUtility.FindColorFromString(this.m_ListItem.SubItems[this.m_nSubItemSelected].Text, ref _FindColor))
        colorDialog.Color = _FindColor;
      if (colorDialog.ShowDialog() == DialogResult.OK)
      {
        Color color = colorDialog.Color;
        if (color.IsNamedColor)
        {
          ListViewItem.ListViewSubItem subItem = this.m_ListItem.SubItems[this.m_nSubItemSelected];
          color = colorDialog.Color;
          string name = color.Name;
          subItem.Text = name;
        }
        else
        {
          ListViewItem.ListViewSubItem subItem = this.m_ListItem.SubItems[this.m_nSubItemSelected];
          string[] strArray = new string[7];
          strArray[0] = ApplicationUtility.GetString("RGBString");
          strArray[1] = " ";
          color = colorDialog.Color;
          strArray[2] = Convert.ToString(color.R);
          strArray[3] = "-";
          color = colorDialog.Color;
          strArray[4] = Convert.ToString(color.G);
          strArray[5] = "-";
          color = colorDialog.Color;
          strArray[6] = Convert.ToString(color.B);
          string str = string.Concat(strArray);
          subItem.Text = str;
        }
      }
      this.m_ColorOpenButton.Hide();
      this.m_bHandleListViewItem = true;
    }
  }

  private void FileOpenButtonClick(object sender, EventArgs e)
  {
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      openFileDialog.Title = EPShared.LocalRM.GetString("SelectTemplateMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("TemplateFilePickerFilter");
      openFileDialog.Multiselect = false;
      if (openFileDialog.ShowDialog() == DialogResult.OK)
        this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = openFileDialog.FileName;
      this.m_FileEditBox.Hide();
      this.m_FileOpenButton.Hide();
      this.m_bHandleListViewItem = true;
    }
  }

  private void DirectoryOpenButtonClick(object sender, EventArgs e)
  {
    FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
    folderBrowserDialog.ShowNewFolderButton = true;
    if (this.m_ListItem.SubItems[this.m_nSubItemSelected].Text != string.Empty)
      folderBrowserDialog.SelectedPath = Path.GetDirectoryName(this.m_ListItem.SubItems[this.m_nSubItemSelected].Text);
    if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
      this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = folderBrowserDialog.SelectedPath;
    this.m_DirectoryEditBox.Hide();
    this.m_DirectoryOpenButton.Hide();
    this.m_bHandleListViewItem = true;
  }

  public void RefreshListView()
  {
    foreach (Control control in (ArrangedElementCollection) this.Controls)
      control.Hide();
  }

  private void EditOver(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\r')
    {
      e.Handled = true;
      if (this.m_bHandleListViewItem)
      {
        this.m_bHandleListViewItem = false;
        this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_EditBox.Text;
        if (this.OnListViewItemChanged != null)
          this.OnListViewItemChanged(this.m_ListItem.Index);
        this.m_EditBox.Hide();
        this.m_bHandleListViewItem = true;
      }
    }
    else if (e.KeyChar == '\t' && this.m_bHandleListViewItem)
    {
      this.m_bHandleListViewItem = false;
      this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_EditBox.Text;
      if (this.OnListViewItemChanged != null)
        this.OnListViewItemChanged(this.m_ListItem.Index);
      this.m_EditBox.Hide();
      this.m_bHandleListViewItem = true;
    }
    if (e.KeyChar != '\u001B')
      return;
    this.m_EditBox.Hide();
    this.m_nSubItemSelected = 0;
    for (Control parent = this.Parent; parent != null; parent = parent.Parent)
    {
      if (parent is EPForm epForm)
      {
        epForm.OverrideKeyUp();
        break;
      }
    }
  }

  private void FocusOver(object sender, EventArgs e)
  {
    if (!this.m_bHandleListViewItem)
      return;
    this.m_bHandleListViewItem = false;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_EditBox.Text;
    if (this.OnListViewItemChanged != null)
      this.OnListViewItemChanged(this.m_ListItem.Index);
    this.m_EditBox.Hide();
    this.Refresh();
    this.FocusedItem = this.SelectedItems[0];
    this.Focus();
    this.m_bHandleListViewItem = true;
  }

  private void FileEditEditOver(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\r')
    {
      e.Handled = true;
      if (this.m_bHandleListViewItem)
      {
        this.m_bHandleListViewItem = false;
        this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_FileEditBox.Text;
        if (this.OnListViewItemChanged != null)
          this.OnListViewItemChanged(this.m_ListItem.Index);
        this.m_FileEditBox.Hide();
        this.m_FileOpenButton.Hide();
        this.m_bHandleListViewItem = true;
      }
    }
    else if (e.KeyChar == '\t' && this.m_bHandleListViewItem)
    {
      this.m_bHandleListViewItem = false;
      this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_FileEditBox.Text;
      if (this.OnListViewItemChanged != null)
        this.OnListViewItemChanged(this.m_ListItem.Index);
      this.m_FileEditBox.Hide();
      this.m_FileOpenButton.Hide();
      this.m_bHandleListViewItem = true;
    }
    if (e.KeyChar != '\u001B')
      return;
    this.m_FileEditBox.Hide();
    this.m_FileOpenButton.Hide();
    this.m_nSubItemSelected = 0;
    for (Control parent = this.Parent; parent != null; parent = parent.Parent)
    {
      if (parent is EPForm epForm)
      {
        epForm.OverrideKeyUp();
        break;
      }
    }
  }

  private void FileEditFocusOver(object sender, EventArgs e)
  {
    if (!this.m_bHandleListViewItem)
      return;
    this.m_bHandleListViewItem = false;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_FileEditBox.Text;
    if (this.OnListViewItemChanged != null)
      this.OnListViewItemChanged(this.m_ListItem.Index);
    this.m_FileEditBox.Hide();
    this.m_FileOpenButton.Hide();
    this.Refresh();
    this.FocusedItem = this.SelectedItems[0];
    this.Focus();
    this.m_bHandleListViewItem = true;
  }

  private void DirectoryEditEditOver(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\r')
    {
      e.Handled = true;
      if (this.m_bHandleListViewItem)
      {
        this.m_bHandleListViewItem = false;
        this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_DirectoryEditBox.Text;
        if (this.OnListViewItemChanged != null)
          this.OnListViewItemChanged(this.m_ListItem.Index);
        this.m_DirectoryEditBox.Hide();
        this.m_DirectoryOpenButton.Hide();
        this.m_bHandleListViewItem = true;
      }
    }
    else if (e.KeyChar == '\t' && this.m_bHandleListViewItem)
    {
      this.m_bHandleListViewItem = false;
      this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_DirectoryEditBox.Text;
      if (this.OnListViewItemChanged != null)
        this.OnListViewItemChanged(this.m_ListItem.Index);
      this.m_DirectoryEditBox.Hide();
      this.m_DirectoryOpenButton.Hide();
      this.m_bHandleListViewItem = true;
    }
    if (e.KeyChar != '\u001B')
      return;
    this.m_DirectoryEditBox.Hide();
    this.m_DirectoryOpenButton.Hide();
    this.m_nSubItemSelected = 0;
    for (Control parent = this.Parent; parent != null; parent = parent.Parent)
    {
      if (parent is EPForm epForm)
      {
        epForm.OverrideKeyUp();
        break;
      }
    }
  }

  private void DirectoryEditFocusOver(object sender, EventArgs e)
  {
    if (!this.m_bHandleListViewItem)
      return;
    this.m_bHandleListViewItem = false;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_DirectoryEditBox.Text;
    if (this.OnListViewItemChanged != null)
      this.OnListViewItemChanged(this.m_ListItem.Index);
    this.m_DirectoryEditBox.Hide();
    this.m_DirectoryOpenButton.Hide();
    this.Refresh();
    this.FocusedItem = this.SelectedItems[0];
    this.Focus();
    this.m_bHandleListViewItem = true;
  }

  private void ColorFocusOver(object sender, EventArgs e)
  {
    if (!this.m_bHandleListViewItem)
      return;
    this.m_bHandleListViewItem = false;
    if (this.OnListViewItemChanged != null)
      this.OnListViewItemChanged(this.m_ListItem.Index);
    this.m_ColorOpenButton.Hide();
    this.Refresh();
    this.FocusedItem = this.SelectedItems[0];
    this.Focus();
    this.m_bHandleListViewItem = true;
  }

  private void HideSelectedControls()
  {
    if (this.m_FileEditBox.Visible)
      this.m_FileEditBox.Hide();
    if (this.m_FileOpenButton.Visible)
      this.m_FileOpenButton.Hide();
    if (this.m_DirectoryEditBox.Visible)
      this.m_DirectoryEditBox.Hide();
    if (this.m_DirectoryOpenButton.Visible)
      this.m_DirectoryOpenButton.Hide();
    if (this.m_OptionsCmbBox.Visible)
      this.m_OptionsCmbBox.Hide();
    if (this.m_CmbBox.Visible)
      this.m_CmbBox.Hide();
    if (this.m_ColorOpenButton.Visible)
      this.m_ColorOpenButton.Hide();
    if (!this.m_EditBox.Visible)
      return;
    this.m_EditBox.Hide();
  }

  private void ColumnWidthChanged(object sender, ColumnWidthChangingEventArgs e) => this.Draw();

  public void ListViewSingleClick(object sender, EventArgs e) => this.Draw();

  private void Draw()
  {
    int num1 = 0;
    int width1 = this.Columns[0].Width;
    if (!this.m_bKeyBoard)
    {
      this.m_nSubItemSelected = 0;
      int nX = this.m_nX;
      for (int index = 1; index < this.Columns.Count; ++index)
      {
        num1 = width1;
        width1 += this.Columns[index].Width;
        if (nX > num1 && nX < width1)
        {
          this.m_nSubItemSelected = index;
          break;
        }
      }
      if (this.m_nSubItemSelected == 0)
      {
        this.HideSelectedControls();
        return;
      }
    }
    else
    {
      num1 = width1;
      width1 += this.Columns[1].Width;
      this.m_nSubItemSelected = 1;
    }
    if (string.Compare(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), this.m_ListItem.SubItems[0].Text, true) == 0 && string.Compare(Convert.ToString(this.m_OptionsCmbBox.SelectedItem), EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"), true) == 0)
    {
      int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoAreaSpacingMethod"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.m_strSubItemText = this.m_ListItem.SubItems[this.m_nSubItemSelected].Text;
      string text1 = this.Columns[this.m_nSubItemSelected].Text;
      string text2 = this.m_ListItem.SubItems[0].Text;
      Rectangle rectangle;
      if (string.Compare(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SideWalkLocationLineParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StreetCurbDisplayParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("MassCreationOnlyMode"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("UseSharedElevation"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("RetainingWallSlopeProjectionParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("CheckForUpdateNotification"), text2, true) == 0)
      {
        ref Rectangle local = ref rectangle;
        int x1 = num1;
        int y1 = this.m_ListItem.Bounds.Y;
        int width2 = width1;
        Rectangle bounds = this.m_ListItem.Bounds;
        int bottom = bounds.Bottom;
        local = new Rectangle(x1, y1, width2, bottom);
        this.m_OptionsCmbBox.Width = this.Columns[this.m_nSubItemSelected].Width - 10;
        ComboBox optionsCmbBox = this.m_OptionsCmbBox;
        int x2 = num1;
        bounds = this.m_ListItem.Bounds;
        int y2 = bounds.Y - 4;
        Point point = new Point(x2, y2);
        optionsCmbBox.Location = point;
        this.m_OptionsCmbBox.Show();
        this.m_OptionsCmbBox.SelectAll();
        int num3 = this.m_OptionsCmbBox.FindString(this.m_strSubItemText);
        if (num3 >= 0)
          this.m_OptionsCmbBox.SelectedIndex = num3;
        else if (this.m_OptionsCmbBox.SelectedIndex < 0 && this.m_OptionsCmbBox.Items.Count > 0)
          this.m_OptionsCmbBox.SelectedIndex = 0;
        this.m_OptionsCmbBox.Focus();
      }
      else if (string.Compare(EPShared.LocalRM.GetString("StreetPavementSurfaceParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StreetCurbMaterialParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StepsMaterialParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ParkingLotParkingPavementSurfaceParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("RetainingWallMaterialParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SideWalkPavementSurfaceParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"), text2, true) == 0)
      {
        ref Rectangle local = ref rectangle;
        int x3 = num1;
        int y3 = this.m_ListItem.Bounds.Y;
        int width3 = width1;
        Rectangle bounds = this.m_ListItem.Bounds;
        int bottom = bounds.Bottom;
        local = new Rectangle(x3, y3, width3, bottom);
        this.m_CmbBox.Width = this.Columns[this.m_nSubItemSelected].Width - 10;
        ComboBox cmbBox = this.m_CmbBox;
        int x4 = num1;
        bounds = this.m_ListItem.Bounds;
        int y4 = bounds.Y - 4;
        Point point = new Point(x4, y4);
        cmbBox.Location = point;
        this.m_CmbBox.Show();
        this.m_CmbBox.SelectAll();
        int num4 = this.m_CmbBox.FindString(this.m_strSubItemText);
        if (num4 >= 0)
          this.m_CmbBox.SelectedIndex = num4;
        else if (this.m_CmbBox.SelectedIndex < 0 && this.m_CmbBox.Items.Count > 0)
          this.m_CmbBox.SelectedIndex = 0;
        this.m_CmbBox.Focus();
      }
      else if (string.Compare(EPShared.LocalRM.GetString("MassTemplateFileNameString"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StreetMassTemplateFileNameString"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("CurbMassTemplateFileNameString"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SidewalkMassTemplateFileNameString"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("RetainingWallMassTemplateFileNameString"), text2, true) == 0)
      {
        ref Rectangle local = ref rectangle;
        int x5 = num1;
        int y5 = this.m_ListItem.Bounds.Y;
        int width4 = width1;
        Rectangle bounds = this.m_ListItem.Bounds;
        int bottom = bounds.Bottom;
        local = new Rectangle(x5, y5, width4, bottom);
        this.m_FileEditBox.Width = this.Columns[this.m_nSubItemSelected].Width - 35;
        TextBox fileEditBox = this.m_FileEditBox;
        int x6 = num1;
        bounds = this.m_ListItem.Bounds;
        int y6 = bounds.Y - 4;
        Point point1 = new Point(x6, y6);
        fileEditBox.Location = point1;
        this.m_FileOpenButton.Size = new Size(25, this.m_FileEditBox.Height);
        Button fileOpenButton = this.m_FileOpenButton;
        int x7 = width1 - 35;
        bounds = this.m_ListItem.Bounds;
        int y7 = bounds.Y - 4;
        Point point2 = new Point(x7, y7);
        fileOpenButton.Location = point2;
        this.m_FileOpenButton.Show();
        this.m_FileEditBox.Show();
        this.m_FileEditBox.Text = this.m_strSubItemText;
        this.m_strPreviousFilePath = this.m_strSubItemText;
      }
      else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SidewalkLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StreetLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("IntersectionLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("CurbLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryColor"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryColor"), text2, true) == 0)
      {
        ref Rectangle local = ref rectangle;
        int x8 = num1;
        int y8 = this.m_ListItem.Bounds.Y;
        int width5 = width1;
        Rectangle bounds = this.m_ListItem.Bounds;
        int bottom = bounds.Bottom;
        local = new Rectangle(x8, y8, width5, bottom);
        this.m_ColorOpenButton.Width = this.Columns[this.m_nSubItemSelected].Width - 10;
        Button colorOpenButton = this.m_ColorOpenButton;
        int x9 = num1;
        bounds = this.m_ListItem.Bounds;
        int y9 = bounds.Y - 4;
        Point point = new Point(x9, y9);
        colorOpenButton.Location = point;
        Color _FindColor = new Color();
        bool colorFromString = RevitUtility.FindColorFromString(this.m_ListItem.SubItems[this.m_nSubItemSelected].Text, ref _FindColor);
        Bitmap bitmap = new Bitmap(15, 8);
        if (colorFromString)
        {
          for (int x10 = 0; x10 < bitmap.Width; ++x10)
          {
            for (int y10 = 0; y10 < bitmap.Height; ++y10)
              bitmap.SetPixel(x10, y10, _FindColor);
          }
        }
        this.m_ColorOpenButton.Image = (Image) bitmap;
        this.m_ColorOpenButton.Show();
        this.m_ColorOpenButton.Text = this.m_strSubItemText;
        this.m_ColorOpenButton.Focus();
      }
      else if (string.Compare(EPShared.LocalRM.GetString("LibraryPath"), text2, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SamplePath"), text2, true) == 0)
      {
        ref Rectangle local = ref rectangle;
        int x11 = num1;
        int y11 = this.m_ListItem.Bounds.Y;
        int width6 = width1;
        Rectangle bounds = this.m_ListItem.Bounds;
        int bottom = bounds.Bottom;
        local = new Rectangle(x11, y11, width6, bottom);
        this.m_DirectoryEditBox.Width = this.Columns[this.m_nSubItemSelected].Width - 35;
        TextBox directoryEditBox = this.m_DirectoryEditBox;
        int x12 = num1;
        bounds = this.m_ListItem.Bounds;
        int y12 = bounds.Y - 4;
        Point point3 = new Point(x12, y12);
        directoryEditBox.Location = point3;
        this.m_DirectoryOpenButton.Size = new Size(25, this.m_DirectoryEditBox.Height);
        Button directoryOpenButton = this.m_DirectoryOpenButton;
        int x13 = width1 - 35;
        bounds = this.m_ListItem.Bounds;
        int y13 = bounds.Y - 4;
        Point point4 = new Point(x13, y13);
        directoryOpenButton.Location = point4;
        this.m_DirectoryOpenButton.Show();
        this.m_DirectoryEditBox.Show();
        this.m_DirectoryEditBox.Text = this.m_strSubItemText;
        this.m_strPreviousDirectoryPath = this.m_strSubItemText;
      }
      else
      {
        ref Rectangle local = ref rectangle;
        int x14 = num1;
        int y14 = this.m_ListItem.Bounds.Y;
        int width7 = width1;
        Rectangle bounds = this.m_ListItem.Bounds;
        int bottom = bounds.Bottom;
        local = new Rectangle(x14, y14, width7, bottom);
        this.m_EditBox.Width = this.Columns[this.m_nSubItemSelected].Width;
        TextBox editBox = this.m_EditBox;
        int x15 = num1;
        bounds = this.m_ListItem.Bounds;
        int y15 = bounds.Y - 4;
        Point point = new Point(x15, y15);
        editBox.Location = point;
        this.m_EditBox.Show();
        this.m_EditBox.Text = this.m_strSubItemText;
        this.m_EditBox.SelectAll();
        this.m_EditBox.Focus();
      }
    }
  }

  public void SetFocus(int _nIndex)
  {
    this.Refresh();
    Rectangle rectangle;
    ref Rectangle local = ref rectangle;
    Rectangle bounds1 = this.m_ListItem.SubItems[1].Bounds;
    int x1 = bounds1.X;
    bounds1 = this.m_ListItem.SubItems[1].Bounds;
    int y1 = bounds1.Y;
    int width = this.Columns[0].Width + this.Columns[this.m_nSubItemSelected].Width;
    bounds1 = this.m_ListItem.SubItems[1].Bounds;
    int bottom = bounds1.Bottom;
    local = new Rectangle(x1, y1, width, bottom);
    this.m_EditBox.Width = this.Columns[this.m_nSubItemSelected].Width;
    TextBox editBox = this.m_EditBox;
    Rectangle bounds2 = this.m_ListItem.SubItems[1].Bounds;
    int x2 = bounds2.X;
    bounds2 = this.m_ListItem.SubItems[1].Bounds;
    int y2 = bounds2.Y - 4;
    Point point = new Point(x2, y2);
    editBox.Location = point;
    this.m_EditBox.Text = string.Empty;
    this.m_EditBox.Show();
    this.m_EditBox.SelectAll();
    this.m_EditBox.Focus();
  }

  public void SetFilePickerFocus(int _nIndex)
  {
    this.m_ListItem.SubItems[1].Text = this.m_strPreviousFilePath;
  }

  public void SetDirectoryPickerFocus(int _nIndex)
  {
    this.m_ListItem.SubItems[1].Text = this.m_strPreviousDirectoryPath;
  }

  public void ListViewMouseDown(object sender, MouseEventArgs e)
  {
    this.m_ListItem = this.GetItemAt(e.X, e.Y);
    this.m_nX = e.X;
    this.m_nY = e.Y;
    this.m_bKeyBoard = false;
  }

  private void ListViewKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode == Keys.Return)
    {
      this.m_bKeyBoard = true;
      Rectangle itemRect = this.GetItemRect(this.SelectedIndices[0]);
      this.m_nX = itemRect.X + this.Columns[1].Width;
      this.m_nY = itemRect.Y;
      this.m_ListItem = this.FindItemWithText(this.SelectedItems[0].Text);
      this.Draw();
    }
    else
    {
      if (e.KeyCode != Keys.Escape || this.m_nSubItemSelected <= 0)
        return;
      this.m_nSubItemSelected = 0;
      this.HideSelectedControls();
      for (Control parent = this.Parent; parent != null; parent = parent.Parent)
      {
        if (parent is EPForm epForm)
        {
          epForm.OverrideKeyUp();
          break;
        }
      }
    }
  }

  private void CmbKeyPress(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar != '\r' && e.KeyChar != '\u001B')
      return;
    this.m_OptionsCmbBox.Hide();
    this.m_CmbBox.Hide();
    if (e.KeyChar != '\u001B')
      return;
    this.m_nSubItemSelected = 0;
    for (Control parent = this.Parent; parent != null; parent = parent.Parent)
    {
      if (parent is EPForm epForm)
      {
        epForm.OverrideKeyUp();
        break;
      }
    }
  }

  private void ColorKeyPress(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar != '\u001B')
      return;
    this.m_ColorOpenButton.Hide();
    this.m_nSubItemSelected = 0;
    for (Control parent = this.Parent; parent != null; parent = parent.Parent)
    {
      if (parent is EPForm epForm)
      {
        epForm.OverrideKeyUp();
        break;
      }
    }
  }

  private void CmbSelected(object sender, EventArgs e)
  {
    int selectedIndex = this.m_OptionsCmbBox.SelectedIndex;
    if (selectedIndex < 0)
      return;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_OptionsCmbBox.Items[selectedIndex].ToString();
    this.m_OptionsCmbBox.Hide();
    if (this.OnListViewItemChanged == null)
      return;
    this.OnListViewItemChanged(this.m_ListItem.Index);
  }

  private void CmbFocusOver(object sender, EventArgs e)
  {
    this.m_OptionsCmbBox.Hide();
    this.m_CmbBox.Hide();
    this.Focus();
  }

  private void MaterialCmbKeyPress(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar != '\r' && e.KeyChar != '\u001B')
      return;
    this.m_CmbBox.Hide();
    if (e.KeyChar != '\u001B')
      return;
    this.m_nSubItemSelected = 0;
    for (Control parent = this.Parent; parent != null; parent = parent.Parent)
    {
      if (parent is EPForm epForm)
      {
        epForm.OverrideKeyUp();
        break;
      }
    }
  }

  private void MaterialCmbSelected(object sender, EventArgs e)
  {
    int selectedIndex = this.m_CmbBox.SelectedIndex;
    if (selectedIndex < 0)
      return;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_CmbBox.Items[selectedIndex].ToString();
    this.m_CmbBox.Hide();
    if (this.OnListViewItemChanged == null)
      return;
    this.OnListViewItemChanged(this.m_ListItem.Index);
  }

  private void MaterialCmbFocusOver(object sender, EventArgs e)
  {
    this.m_CmbBox.Hide();
    this.Focus();
  }

  public void SetAnchor()
  {
    this.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
  }

  public ComboBox CmbBox
  {
    get => this.m_OptionsCmbBox;
    set => this.m_OptionsCmbBox = value;
  }

  public ComboBox MaterialCmbBox
  {
    get => this.m_CmbBox;
    set => this.m_CmbBox = value;
  }

  public ListViewItem CurrListItem
  {
    get => this.m_ListItem;
    set => this.m_ListItem = value;
  }
}
