﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ProgressBarForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using SITES.Sites_Core;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ProgressBarForm : Form
{
  private ProgressBar m_ProgressBar;
  private string m_strMessage = string.Empty;
  private IContainer components;
  private Label ProgMessageBox;
  private Panel m_Panel;

  public ProgressBarForm()
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ProgressDialog");
    this.SetupProgressBar();
    this.StartPosition = FormStartPosition.CenterScreen;
    this.m_ProgressBar.Location = new Point(12, this.ProgMessageBox.Height + 20);
    this.m_ProgressBar.Width = this.ProgMessageBox.Width;
    this.Height = 10 + this.ProgMessageBox.Height + 20 + this.m_ProgressBar.Height + 20;
    this.m_ProgressBar.Value = 0;
  }

  public void ShowForm()
  {
    if (ApplicationUtility.RevitWindowWrapper != null)
      this.Show((IWin32Window) ApplicationUtility.RevitWindowWrapper);
    else
      this.Show();
  }

  private void SetupProgressBar()
  {
    this.m_ProgressBar.BackColor = Color.Transparent;
    this.m_ProgressBar.BackgroundColor = Color.FromArgb(100, 201, 201, 201);
    this.m_ProgressBar.HighlightColor = Color.Orange;
    this.m_ProgressBar.StartColor = Color.FromArgb(0, 211, 40);
    this.m_ProgressBar.EndColor = Color.FromArgb(0, 211, 40);
    this.m_ProgressBar.GlowColor = Color.White;
    this.Invalidate();
    this.Refresh();
  }

  public void UpdateProgressBar(int _nValue)
  {
    this.m_ProgressBar.Value += _nValue;
    this.Invalidate();
    this.Refresh();
  }

  public void SetMaxValue()
  {
    this.m_ProgressBar.Value = this.m_ProgressBar.MaxValue - 1;
    this.Invalidate();
    this.Refresh();
  }

  public void ResetValue()
  {
    this.m_ProgressBar.Value = 0;
    this.Invalidate();
    this.Refresh();
  }

  public string Message
  {
    get => this.m_strMessage;
    set
    {
      if (string.Compare(value, this.m_strMessage) == 0)
        return;
      this.m_strMessage = value;
      this.ProgMessageBox.Text = this.m_strMessage;
      this.Height = 10 + this.ProgMessageBox.Height + 20 + this.m_ProgressBar.Height + 20;
      this.Focus();
    }
  }

  public int MinValue
  {
    set
    {
      this.m_ProgressBar.MinValue = value;
      this.m_ProgressBar.Invalidate();
      this.Invalidate();
      this.Refresh();
    }
  }

  public int MaxValue
  {
    set
    {
      this.m_ProgressBar.MaxValue = value;
      this.m_ProgressBar.Invalidate();
      this.Invalidate();
      this.Refresh();
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (ProgressBarForm));
    this.ProgMessageBox = new Label();
    this.m_ProgressBar = new ProgressBar();
    this.m_Panel = new Panel();
    this.SuspendLayout();
    this.m_Panel.SuspendLayout();
    this.ProgMessageBox.BorderStyle = BorderStyle.None;
    this.ProgMessageBox.Location = new Point(12, 6);
    this.ProgMessageBox.Name = "ProgMessageBox";
    this.ProgMessageBox.Size = new Size(324, 20);
    this.ProgMessageBox.TabIndex = 1;
    this.m_ProgressBar.BackColor = Color.Transparent;
    this.m_ProgressBar.Location = new Point(0, 0);
    this.m_ProgressBar.Name = "m_ProgressBar";
    this.m_ProgressBar.Size = new Size(264, 32 /*0x20*/);
    this.m_ProgressBar.TabIndex = 2;
    this.m_Panel.AutoSize = true;
    this.m_Panel.AutoSizeMode = AutoSizeMode.GrowAndShrink;
    this.m_Panel.Dock = DockStyle.Fill;
    this.m_Panel.Location = new Point(0, 0);
    this.m_Panel.Name = "m_Panel";
    this.m_Panel.Size = new Size(348, 90);
    this.m_Panel.TabIndex = 3;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(348, 90);
    this.m_Panel.Controls.Add((Control) this.ProgMessageBox);
    this.m_Panel.Controls.Add((Control) this.m_ProgressBar);
    this.Controls.Add((Control) this.m_Panel);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Icon = Resources.Siteworks;
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.MinimumSize = new Size(354, 140);
    this.Name = nameof (ProgressBarForm);
    this.ShowInTaskbar = false;
    this.Text = "Progress";
    this.m_Panel.ResumeLayout(false);
    this.m_Panel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
