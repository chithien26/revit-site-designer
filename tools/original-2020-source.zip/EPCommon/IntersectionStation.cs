﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.IntersectionStation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class IntersectionStation
{
  private bool m_bIsLeft;
  private bool m_bIsPrimaryLeft;
  private bool m_bStartingIntersection;
  private double m_dStation;
  private double m_dPrimaryStation;
  private double m_dRadius;
  private double m_dTransitioningDistance;
  private Eps_Leg m_IntersectionLeg;
  private Eps_Point m_InvalidIntersectionPnt;

  public IntersectionStation()
  {
    this.m_bIsLeft = true;
    this.m_bIsPrimaryLeft = true;
    this.m_bStartingIntersection = true;
    this.m_dStation = 0.0;
    this.m_dPrimaryStation = 0.0;
    this.m_dRadius = 0.0;
    this.m_dTransitioningDistance = 0.0;
    this.m_IntersectionLeg = (Eps_Leg) null;
    this.m_InvalidIntersectionPnt = (Eps_Point) null;
  }

  public IntersectionStation(double _dStation)
  {
    this.m_bIsLeft = true;
    this.m_bIsPrimaryLeft = true;
    this.m_bStartingIntersection = true;
    this.m_dStation = _dStation;
    this.m_dPrimaryStation = 0.0;
    this.m_dRadius = 0.0;
    this.m_dTransitioningDistance = 0.0;
    this.m_IntersectionLeg = (Eps_Leg) null;
    this.m_InvalidIntersectionPnt = (Eps_Point) null;
  }

  public bool IsLeft
  {
    get => this.m_bIsLeft;
    set => this.m_bIsLeft = value;
  }

  public bool IsPrimaryLeft
  {
    get => this.m_bIsPrimaryLeft;
    set => this.m_bIsPrimaryLeft = value;
  }

  public double PrimaryStation
  {
    get => this.m_dPrimaryStation;
    set => this.m_dPrimaryStation = value;
  }

  public double Station
  {
    get => this.m_dStation;
    set => this.m_dStation = value;
  }

  public double Radius
  {
    get => this.m_dRadius;
    set => this.m_dRadius = value;
  }

  public double TransitioningDistance
  {
    get => this.m_dTransitioningDistance;
    set => this.m_dTransitioningDistance = value;
  }

  public Eps_Leg IntersectionLeg
  {
    get => this.m_IntersectionLeg;
    set => this.m_IntersectionLeg = value;
  }

  public bool StartingIntersection
  {
    get => this.m_bStartingIntersection;
    set => this.m_bStartingIntersection = value;
  }

  public Eps_Point InvalidIntersectionPnt
  {
    get => this.m_InvalidIntersectionPnt;
    set => this.m_InvalidIntersectionPnt = value;
  }
}
