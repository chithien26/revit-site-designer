﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FamilyContainer
{
  private string m_strFamilyName;
  private List<FamilySymbol> m_FamilySymbolList;

  public FamilyContainer(string _strFamilyName)
  {
    this.m_strFamilyName = _strFamilyName;
    this.m_FamilySymbolList = new List<FamilySymbol>();
  }

  public string FamilyName
  {
    get => this.m_strFamilyName;
    set => this.m_strFamilyName = value;
  }

  public List<FamilySymbol> FamilySymbolList
  {
    get => this.m_FamilySymbolList;
    set => this.m_FamilySymbolList = value;
  }
}
