﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandXMLImportOptions
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public enum LandXMLImportOptions
{
  AutoCenterToCenter,
  AutoOriginToOrigin,
  ManualCenter,
  UsePreviousTranslation,
  UseSharedCoordinates,
}
