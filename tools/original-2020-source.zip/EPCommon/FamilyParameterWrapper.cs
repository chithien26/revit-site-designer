﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyParameterWrapper
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;

#nullable disable
namespace EPCommon;

public class FamilyParameterWrapper
{
  private string m_displayName;
  private string m_strParameterName;
  private string m_strParameterValue;
  private double m_dParameterValue;
  private int m_nParameterValue;
  private ElementId m_IdParameterValue;
  private StorageType m_StorageType;
  private FamilyParameter m_FamilyParameter;
  private bool m_bInternalValuesSet;

  public FamilyParameterWrapper(
    string _strParameterDisplayName,
    string _strParameterName,
    string _strParameterValue,
    StorageType _StorageType)
  {
    this.m_displayName = _strParameterDisplayName;
    this.m_strParameterName = _strParameterName;
    this.m_strParameterValue = _strParameterValue;
    this.m_StorageType = _StorageType;
    this.m_bInternalValuesSet = true;
    if (this.m_strParameterValue == null || !(this.m_strParameterValue != string.Empty))
      return;
    switch (this.m_StorageType - 1)
    {
      case 0:
        int _nReturnedInt1 = 0;
        if (string.Compare(_strParameterValue, EPShared.LocalRM.GetString("YesString"), true) == 0)
        {
          this.m_nParameterValue = 1;
          break;
        }
        if (string.Compare(_strParameterValue, EPShared.LocalRM.GetString("NoString"), true) == 0)
        {
          this.m_nParameterValue = 0;
          break;
        }
        if (!RevitGeometry.StrE_GetValidWholeNumber(this.m_strParameterValue, ref _nReturnedInt1))
          break;
        this.m_nParameterValue = _nReturnedInt1;
        break;
      case 1:
        double _dReturnedDouble = 0.0;
        if (!RevitGeometry.StrE_GetValidRealNumber(this.m_strParameterValue, ref _dReturnedDouble))
          break;
        this.m_dParameterValue = _dReturnedDouble;
        break;
      case 3:
        int _nReturnedInt2 = 0;
        if (!RevitGeometry.StrE_GetValidWholeNumber(this.m_strParameterValue, ref _nReturnedInt2))
          break;
        this.m_IdParameterValue = new ElementId(_nReturnedInt2);
        break;
    }
  }

  public FamilyParameterWrapper(
    string _strParameterDisplayName,
    FamilyParameter _FamilyParameter,
    string _strParameterValue)
  {
    this.m_displayName = _strParameterDisplayName;
    this.m_strParameterValue = _strParameterValue;
    this.m_FamilyParameter = _FamilyParameter;
    if (_FamilyParameter != null && _FamilyParameter.Definition != null)
    {
      this.m_strParameterName = _FamilyParameter.Definition.Name;
      this.m_StorageType = _FamilyParameter.StorageType;
    }
    this.m_bInternalValuesSet = false;
  }

  public string DisplayName
  {
    get => this.m_displayName;
    set => this.m_displayName = value;
  }

  public string ParameterName
  {
    get => this.m_strParameterName;
    set => this.m_strParameterName = value;
  }

  public string Value
  {
    get => this.m_strParameterValue;
    set
    {
      this.m_strParameterValue = value;
      this.m_bInternalValuesSet = true;
      if (this.m_strParameterValue == null || !(this.m_strParameterValue != string.Empty))
        return;
      switch (this.m_StorageType - 1)
      {
        case 0:
          int _nReturnedInt1 = 0;
          if (string.Compare(this.m_strParameterValue, EPShared.LocalRM.GetString("YesString"), true) == 0)
          {
            this.m_nParameterValue = 1;
            break;
          }
          if (string.Compare(this.m_strParameterValue, EPShared.LocalRM.GetString("NoString"), true) == 0)
          {
            this.m_nParameterValue = 0;
            break;
          }
          if (!RevitGeometry.StrE_GetValidWholeNumber(this.m_strParameterValue, ref _nReturnedInt1))
            break;
          this.m_nParameterValue = _nReturnedInt1;
          break;
        case 1:
          double _dReturnedDouble = 0.0;
          if (!RevitGeometry.StrE_GetValidRealNumber(this.m_strParameterValue, ref _dReturnedDouble))
            break;
          this.m_dParameterValue = _dReturnedDouble;
          break;
        case 3:
          int _nReturnedInt2 = 0;
          if (!RevitGeometry.StrE_GetValidWholeNumber(this.m_strParameterValue, ref _nReturnedInt2))
            break;
          this.m_IdParameterValue = new ElementId(_nReturnedInt2);
          break;
      }
    }
  }

  public double DoubleValue
  {
    get => this.m_dParameterValue;
    set
    {
      this.m_dParameterValue = value;
      this.m_strParameterValue = ValueConversion.ToString(this.m_dParameterValue);
      this.m_bInternalValuesSet = true;
    }
  }

  public int IntegerValue
  {
    get => this.m_nParameterValue;
    set
    {
      this.m_nParameterValue = value;
      this.m_strParameterValue = Convert.ToString(this.m_nParameterValue);
      this.m_bInternalValuesSet = true;
    }
  }

  public ElementId ElementIdValue
  {
    get => this.m_IdParameterValue;
    set
    {
      this.m_IdParameterValue = value;
      this.m_strParameterValue = Convert.ToString(this.m_IdParameterValue.IntegerValue);
      this.m_bInternalValuesSet = true;
    }
  }

  public StorageType StorageType
  {
    get => this.m_StorageType;
    set => this.m_StorageType = value;
  }

  public FamilyParameter FamilyParameter
  {
    get => this.m_FamilyParameter;
    set
    {
      this.m_FamilyParameter = value;
      if (this.m_FamilyParameter == null || this.m_FamilyParameter.Definition == null)
        return;
      this.m_strParameterName = this.m_FamilyParameter.Definition.Name;
      this.m_StorageType = this.m_FamilyParameter.StorageType;
    }
  }

  public bool InternalValueSet => this.m_bInternalValuesSet;
}
