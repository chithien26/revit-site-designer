﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilySymbolParameterContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class FamilySymbolParameterContainer
{
  private string m_strParameterName;
  private ExternalDefinition m_FamilyDefinition;
  private BuiltInParameterGroup m_BuiltInParameterGroup;
  private ParameterType m_ParameterType;
  private Category m_FamilyCategory;
  private bool m_bIsInstance;

  public FamilySymbolParameterContainer(
    string _strParameterName,
    BuiltInParameterGroup _BuiltInParameterGroup,
    ParameterType _ParameterType,
    bool _bIsInstance)
  {
    this.m_strParameterName = _strParameterName;
    this.m_BuiltInParameterGroup = _BuiltInParameterGroup;
    this.m_ParameterType = _ParameterType;
    this.m_bIsInstance = _bIsInstance;
    this.m_FamilyDefinition = (ExternalDefinition) null;
    this.m_FamilyCategory = (Category) null;
  }

  public FamilySymbolParameterContainer(
    string _strParameterName,
    BuiltInParameterGroup _BuiltInParameterGroup,
    Category _FamilyCategory,
    bool _bIsInstance)
  {
    this.m_strParameterName = _strParameterName;
    this.m_BuiltInParameterGroup = _BuiltInParameterGroup;
    this.m_ParameterType = (ParameterType) 0;
    this.m_bIsInstance = _bIsInstance;
    this.m_FamilyDefinition = (ExternalDefinition) null;
    this.m_FamilyCategory = _FamilyCategory;
  }

  public FamilySymbolParameterContainer(
    ExternalDefinition _FamilyDefinition,
    BuiltInParameterGroup _BuiltInParameterGroup,
    bool _bIsInstance)
  {
    this.m_strParameterName = string.Empty;
    this.m_BuiltInParameterGroup = _BuiltInParameterGroup;
    this.m_ParameterType = (ParameterType) 0;
    this.m_bIsInstance = _bIsInstance;
    this.m_FamilyDefinition = _FamilyDefinition;
    this.m_FamilyCategory = (Category) null;
  }

  public string ParameterName
  {
    get => this.m_strParameterName;
    set => this.m_strParameterName = value;
  }

  public BuiltInParameterGroup BuiltInParameterGroup
  {
    get => this.m_BuiltInParameterGroup;
    set => this.m_BuiltInParameterGroup = value;
  }

  public ParameterType ParameterType
  {
    get => this.m_ParameterType;
    set => this.m_ParameterType = value;
  }

  public bool IsInstance
  {
    get => this.m_bIsInstance;
    set => this.m_bIsInstance = value;
  }

  public ExternalDefinition FamilyDefinition
  {
    get => this.m_FamilyDefinition;
    set => this.m_FamilyDefinition = value;
  }

  public Category FamilyCategory
  {
    get => this.m_FamilyCategory;
    set => this.m_FamilyCategory = value;
  }
}
