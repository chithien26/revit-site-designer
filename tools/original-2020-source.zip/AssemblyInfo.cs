﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Autodesk® Site Designer for Revit®")]
[assembly: AssemblyDescription("Autodesk® Site Designer for Revit®")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: Guid("E06B037C-0055-43FB-90E8-57C3404FF5D3")]
[assembly: AssemblyProduct("Autodesk Revit")]
[assembly: AssemblyCompany("Autodesk, Inc.")]
[assembly: AssemblyCopyright("Copyright (c) 2019 Autodesk, Inc. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("20.0.0.377")]
[assembly: AssemblyVersion("20.0.0.0")]
