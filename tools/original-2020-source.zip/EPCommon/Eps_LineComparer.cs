﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_LineComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class Eps_LineComparer : IComparer<Eps_Line>
{
  int IComparer<Eps_Line>.Compare(Eps_Line first, Eps_Line second)
  {
    int num = 0;
    if (first != null)
    {
      if (second != null)
      {
        Eps_Line epsLine1 = first.StartPnt.x >= first.EndPnt.x ? (first.StartPnt.x <= first.EndPnt.x ? (first.StartPnt.y >= first.EndPnt.y ? first.Reverse() : first) : first.Reverse()) : first;
        Eps_Line epsLine2 = second.StartPnt.x >= second.EndPnt.x ? (second.StartPnt.x <= second.EndPnt.x ? (second.StartPnt.y >= second.EndPnt.y ? second.Reverse() : second) : second.Reverse()) : second;
        num = epsLine1.StartPnt.x.CompareTo(epsLine2.StartPnt.x);
        if (num == 0)
        {
          num = epsLine1.StartPnt.y.CompareTo(epsLine2.StartPnt.y);
          if (num == 0)
          {
            num = epsLine1.EndPnt.x.CompareTo(epsLine2.EndPnt.x);
            if (num == 0)
              num = epsLine1.EndPnt.y.CompareTo(epsLine2.EndPnt.y);
          }
        }
      }
      else
        num = -1;
    }
    else if (second != null)
      num = 1;
    return num;
  }
}
