﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.GeometryData
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class GeometryData
{
  private BoundingBoxXYZ m_BoundingBox;
  private List<IList<XYZ>> m_3DCurveList = new List<IList<XYZ>>();

  public Graphics3DData Data3D
  {
    get
    {
      return new Graphics3DData(new List<IList<XYZ>>((IEnumerable<IList<XYZ>>) this.m_3DCurveList), this.m_BoundingBox);
    }
  }

  public GeometryData(
    Application _CurApplication,
    Element _Element,
    ViewDetailLevel _Detail,
    View _CurrentView)
  {
    Options options = _CurApplication.Create.NewGeometryOptions();
    options.DetailLevel = _Detail;
    options.ComputeReferences = false;
    this.AddGeoElement((GeometryObject) _Element[options], Transform.CreateTranslation(new XYZ(0.0, 0.0, 0.0)));
    this.m_BoundingBox = _Element[_CurrentView];
  }

  public GeometryData(Application _CurApplication, Element _Element, View _CurrentView)
  {
    Options options = _CurApplication.Create.NewGeometryOptions();
    options.View = _CurrentView;
    options.ComputeReferences = false;
    this.AddGeoElement((GeometryObject) _Element[options], Transform.CreateTranslation(new XYZ(0.0, 0.0, 0.0)));
    this.m_BoundingBox = _Element[_CurrentView];
  }

  private void AddGeoElement(GeometryObject _Object, Transform _Transform)
  {
    GeometryElement geometryElement = _Object as GeometryElement;
    if (GeometryObject.op_Equality((GeometryObject) geometryElement, (GeometryObject) null))
      return;
    List<GeometryObject> _Objects = new List<GeometryObject>();
    if (GeometryObject.op_Inequality((GeometryObject) geometryElement, (GeometryObject) null))
      _Objects = ElementSetConverter.ToGeometryObjectList(geometryElement.GetEnumerator());
    this.AddGeometryObjects(_Objects, _Transform);
  }

  private void AddGeometryObjects(List<GeometryObject> _Objects, Transform _Transform)
  {
    foreach (GeometryObject _Object in _Objects)
    {
      string str = _Object.GetType().Name;
      if (str.StartsWith("Geometry"))
        str = str.Remove(0, 8);
      switch (str)
      {
        case "Arc":
        case "Curve":
        case "Line":
          this.AddCurve(_Object, _Transform);
          continue;
        case "Edge":
          this.AddEdge(_Object, _Transform);
          continue;
        case "Element":
          this.AddGeoElement(_Object, _Transform);
          continue;
        case "Face":
          this.AddFace(_Object, _Transform);
          continue;
        case "Instance":
          this.AddInstance(_Object, _Transform);
          continue;
        case "Mesh":
          this.AddMesh(_Object, _Transform);
          continue;
        case "Profile":
          this.AddProfile(_Object, _Transform);
          continue;
        case "Solid":
          this.AddSolid(_Object, _Transform);
          continue;
        default:
          continue;
      }
    }
  }

  private void AddSolid(GeometryObject _Object, Transform _Transform)
  {
    Solid solid = _Object as Solid;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) solid))
      return;
    FaceArray faces = solid.Faces;
    if (faces.Size == 0)
      return;
    foreach (GeometryObject _Object1 in faces)
      this.AddFace(_Object1, _Transform);
  }

  private void AddFace(GeometryObject _Object, Transform _Transform)
  {
    Face face = _Object as Face;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) face))
      return;
    Mesh _Object1 = face.Triangulate();
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) _Object1))
      return;
    this.AddMesh((GeometryObject) _Object1, _Transform);
  }

  private void AddProfile(GeometryObject _Object, Transform _Transform)
  {
    Profile profile = _Object as Profile;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) profile))
      return;
    foreach (GeometryObject curve in profile.Curves)
      this.AddCurve(curve, _Transform);
  }

  private void AddMesh(GeometryObject _Object, Transform _Transform)
  {
    Mesh mesh = _Object as Mesh;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) mesh))
      return;
    for (int index1 = 0; index1 < mesh.NumTriangles; ++index1)
    {
      MeshTriangle meshTriangle = mesh[index1];
      IList<XYZ> xyzList = (IList<XYZ>) new List<XYZ>();
      try
      {
        for (int index2 = 0; index2 < 3; ++index2)
        {
          XYZ basis = MathUtil.GetBasis(meshTriangle[index2], _Transform);
          xyzList.Add(basis);
        }
        XYZ xyz = xyzList[0];
        xyzList.Add(xyz);
        this.m_3DCurveList.Add(xyzList);
      }
      catch
      {
      }
    }
  }

  private void AddCurve(GeometryObject _Object, Transform _Transform)
  {
    Curve curve = _Object as Curve;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) curve) || !curve.IsBound)
      return;
    IList<XYZ> xyzList1 = curve.Tessellate();
    IList<XYZ> xyzList2 = (IList<XYZ>) new List<XYZ>();
    foreach (XYZ point in (IEnumerable<XYZ>) xyzList1)
    {
      XYZ basis = MathUtil.GetBasis(point, _Transform);
      xyzList2.Add(basis);
    }
    this.m_3DCurveList.Add(xyzList2);
  }

  private void AddInstance(GeometryObject _Object, Transform _Transform)
  {
    GeometryInstance geometryInstance = _Object as GeometryInstance;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) geometryInstance))
      return;
    Transform _Transform1 = this.AddTransform(_Transform, geometryInstance.Transform);
    GeometryElement symbolGeometry = geometryInstance.SymbolGeometry;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) symbolGeometry))
      return;
    List<GeometryObject> _Objects = new List<GeometryObject>();
    if (GeometryObject.op_Inequality((GeometryObject) symbolGeometry, (GeometryObject) null))
      _Objects = ElementSetConverter.ToGeometryObjectList(symbolGeometry.GetEnumerator());
    this.AddGeometryObjects(_Objects, _Transform1);
  }

  private void AddEdge(GeometryObject _Object, Transform _Transform)
  {
    Edge edge = _Object as Edge;
    if (GeometryObject.op_Equality((GeometryObject) null, (GeometryObject) edge))
      return;
    IList<XYZ> xyzList1 = edge.Tessellate();
    IList<XYZ> xyzList2 = (IList<XYZ>) new List<XYZ>();
    foreach (XYZ point in (IEnumerable<XYZ>) xyzList1)
    {
      XYZ basis = MathUtil.GetBasis(point, _Transform);
      xyzList2.Add(basis);
    }
    this.m_3DCurveList.Add(xyzList2);
  }

  private Transform AddTransform(Transform _FirstTransform, Transform _SecondTransform)
  {
    Transform translation = Transform.CreateTranslation(new XYZ(0.0, 0.0, 0.0));
    translation.Origin = MathUtil.AddXYZ(_FirstTransform.Origin, _SecondTransform.Origin);
    XYZ[] m1 = new XYZ[3];
    XYZ[] m2 = new XYZ[3];
    for (int index = 0; index < 3; ++index)
    {
      m1[index] = _FirstTransform[index];
      m2[index] = _SecondTransform[index];
    }
    XYZ[] xyzArray = MathUtil.MultiCross(m1, m2);
    for (int index = 0; index < 3; ++index)
      translation[index] = xyzArray[index];
    return translation;
  }
}
