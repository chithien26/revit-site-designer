using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class ModifyPlantForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private ModifyPlant m_dataBuffer;

	private FamilySymbol m_CurType;

	private FamilySymbol m_ExistingType;

	private FormatOptions m_FormatOptions;

	private UnitSymbolType m_UnitSymbolType;

	private DisplayUnit m_DisplayUnitSystem;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private GroupBox m_ExistingGroupBox;

	private Button m_PickPlantButton;

	private ComboBox m_ExistingPlantNameComboBox;

	private Label m_ExistingPlantNameLabel;

	private ComboBox m_ExistingPlantFamilyComboBox;

	private Label m_ExistingPlantFamilyLabel;

	private GroupBox m_ModifyPlantGroupBox;

	private Button m_SearchButton;

	private ComboBox m_PlantNameComboBox;

	private Label m_PlantNameLabel;

	private ComboBox m_PlantFamilyComboBox;

	private Label m_PlantFamilyLabel;

	private TextBox m_PlantHeightTextBox;

	private Label m_PlantHeightLabel;

	private TextBox m_PlantWidthTextBox;

	private Label m_PlantWidthLabel;

	private RadioButton m_AllInstancesRadioButton;

	private GroupBox m_SelectionMethodsGroupBox;

	private RadioButton m_WindowSelectRadioButton;

	private RadioButton m_SelectionSetRadioButton;

	private CheckBox m_ModifyPlantHeightCheckBox;

	private CheckBox m_ModifyPlantWidthCheckBox;

	private CheckBox m_ModifyPlantTypeCheckBox;

	private Button m_ApplyButton;

	private Button m_CancelButton;

	private Button m_LoadFamilyButton;

	public bool SelectionSetChecked => m_SelectionSetRadioButton.Checked;

	public bool WindowSelectChecked => m_WindowSelectRadioButton.Checked;

	public bool AllInstancesChecked => m_AllInstancesRadioButton.Checked;

	public FamilySymbol Type => m_CurType;

	public FamilySymbol ExistingType => m_ExistingType;

	public bool ModifyPlantTypeChecked => m_ModifyPlantTypeCheckBox.Checked;

	public bool ModifyPlantWidthChecked => m_ModifyPlantWidthCheckBox.Checked;

	public bool ModifyPlantHeightChecked => m_ModifyPlantHeightCheckBox.Checked;

	public double PlantHeight
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_PlantHeightTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_PlantHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double PlantWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_PlantWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_PlantWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public ModifyPlantForm(ModifyPlant _dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("ModifyPlantsDialog");
		m_ExistingGroupBox.Text = EPShared.LocalRM.GetString("ExistingPlantsInProjDialog");
		m_ExistingPlantFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_PlantFamilyDialog");
		m_ExistingPlantNameLabel.Text = EPShared.LocalRM.GetString("P_AMP_lantNameDialog");
		m_PickPlantButton.Text = EPShared.LocalRM.GetString("Pic_AMP_kPlantDialog");
		m_ModifyPlantGroupBox.Text = EPShared.LocalRM.GetString("ModifyPlantsInProjDialog");
		m_ModifyPlantTypeCheckBox.Text = EPShared.LocalRM.GetString("AMP_ModifyPlantTypeDialog");
		m_PlantFamilyLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_FamilyDialog");
		m_PlantNameLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_NameDialog");
		m_SearchButton.Text = EPShared.LocalRM.GetString("Sea_AMP_rchDialog");
		m_ModifyPlantWidthCheckBox.Text = EPShared.LocalRM.GetString("M_AMP_odifyPlantWidthDialog");
		m_PlantWidthLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_WidthDialog");
		m_ModifyPlantHeightCheckBox.Text = EPShared.LocalRM.GetString("Mo_AMP_difyPlantWidthDialog");
		m_PlantHeightLabel.Text = EPShared.LocalRM.GetString("Plant_AMP_HeightDialog");
		m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
		m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
		m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
		m_AllInstancesRadioButton.Text = EPShared.LocalRM.GetString("All_AMP_InstancesDialog");
		m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		EPToolTip.SetToolTip(m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		m_dataBuffer = _dataBuffer;
		m_FormatOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_dataBuffer.Document.DisplayUnitSystem;
		m_Units = m_dataBuffer.Document.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_dataBuffer.Document.GetUnits().DecimalSymbol;
		InitializeControls();
		ManagePlants.VerifySharedParameters(m_dataBuffer.Document, m_dataBuffer.TransactionContainer);
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		double _dReturnValue = 0.0;
		string _strToDisplay = string.Empty;
		GetDialogPosition();
		m_SelectionSetRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsSelectMethodOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_SelectionSetRadioButton.Checked = true;
				break;
			case 1:
				m_WindowSelectRadioButton.Checked = true;
				break;
			default:
				m_AllInstancesRadioButton.Checked = true;
				break;
			}
		}
		m_ModifyPlantTypeCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsModifyPlantType", ref _nReturnValue))
		{
			m_ModifyPlantTypeCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_ModifyPlantWidthCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsModifyPlantWidth", ref _nReturnValue))
		{
			m_ModifyPlantWidthCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsPlantWidth", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
		m_PlantWidthTextBox.Text = _strToDisplay;
		m_ModifyPlantHeightCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsModifyPlantHeight", ref _nReturnValue))
		{
			m_ModifyPlantHeightCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ModifyPlantsPlantHeight", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
		m_PlantHeightTextBox.Text = _strToDisplay;
		m_PlantFamilyComboBox.DataSource = m_dataBuffer.PlantFamilyList;
		m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsFamilyName", ref _strToDisplay))
		{
			FamilyContainer familyContainer = null;
			for (int i = 0; i < m_PlantFamilyComboBox.Items.Count; i++)
			{
				if (m_PlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strToDisplay, ignoreCase: true) == 0)
				{
					m_PlantFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsPlantName", ref _strToDisplay))
		{
			FamilySymbol familySymbol = null;
			for (int j = 0; j < m_PlantNameComboBox.Items.Count; j++)
			{
				if (m_PlantNameComboBox.Items[j] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strToDisplay, ignoreCase: true) == 0)
				{
					m_PlantNameComboBox.SelectedIndex = j;
					break;
				}
			}
		}
		m_ExistingPlantFamilyComboBox.DataSource = m_dataBuffer.ExistingPlantFamilyList;
		m_ExistingPlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsExistingFamilyName", ref _strToDisplay))
		{
			SetExistingPlantFamilyComboBox(_strToDisplay);
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsExistingPlantName", ref _strToDisplay))
		{
			SetExistingPlantNameComboBox(_strToDisplay);
		}
	}

	private void OnPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_PlantNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnExistingPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_ExistingPlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_ExistingPlantNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_ExistingPlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnSearchButtonClick(object sender, EventArgs e)
	{
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			List<FamilySymbol> _SearchSymbolList = new List<FamilySymbol>();
			if (ManagePlants.FindFamilySymbols(EPShared.LocalRM.GetString("ModifyPlantSearchTitle"), m_dataBuffer.Document, m_dataBuffer.TransactionContainer, familyContainer.FamilySymbolList, ref _SearchSymbolList))
			{
				m_PlantNameComboBox.DataSource = _SearchSymbolList;
				m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
			}
		}
	}

	private void SaveSettings()
	{
		m_CurType = m_PlantNameComboBox.SelectedItem as FamilySymbol;
		if (m_CurType == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		int num = 0;
		num = ((!m_SelectionSetRadioButton.Checked) ? (m_WindowSelectRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsSelectMethodOption", num);
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsFamilyName", familyContainer.FamilyName);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsModifyPlantType", Convert.ToInt32(m_ModifyPlantTypeCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsModifyPlantWidth", Convert.ToInt32(m_ModifyPlantWidthCheckBox.Checked));
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsPlantWidth", _dReturnedDouble);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsModifyPlantHeight", Convert.ToInt32(m_ModifyPlantHeightCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ModifyPlantsPlantHeight", _dReturnedDouble);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsPlantName", m_CurType.Name);
		if (m_ExistingPlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer2)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsExistingFamilyName", familyContainer2.FamilyName);
		}
		m_ExistingType = m_ExistingPlantNameComboBox.SelectedItem as FamilySymbol;
		if (m_ExistingType != null)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ModifyPlantsExistingPlantName", m_ExistingType.Name);
		}
	}

	private void OnModifyPlantTypeCheckBoxChecked(object sender, EventArgs e)
	{
		m_PlantFamilyLabel.Enabled = m_ModifyPlantTypeCheckBox.Checked;
		m_PlantFamilyComboBox.Enabled = m_ModifyPlantTypeCheckBox.Checked;
		m_PlantNameLabel.Enabled = m_ModifyPlantTypeCheckBox.Checked;
		m_PlantNameComboBox.Enabled = m_ModifyPlantTypeCheckBox.Checked;
		m_SearchButton.Enabled = m_ModifyPlantTypeCheckBox.Checked;
	}

	private void OnModifyPlantWidthCheckBoxChecked(object sender, EventArgs e)
	{
		m_PlantWidthLabel.Enabled = m_ModifyPlantWidthCheckBox.Checked;
		m_PlantWidthTextBox.Enabled = m_ModifyPlantWidthCheckBox.Checked;
	}

	private void OnModifyPlantHeightCheckBoxChecked(object sender, EventArgs e)
	{
		m_PlantHeightLabel.Enabled = m_ModifyPlantHeightCheckBox.Checked;
		m_PlantHeightTextBox.Enabled = m_ModifyPlantHeightCheckBox.Checked;
	}

	private void OnPickPlantButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Retry;
		Close();
	}

	private void FormatPlantWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_PlantWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_PlantWidthTextBox);
		}
	}

	private void OnPlantWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatPlantWidthValue();
	}

	private void FormatPlantHeightValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_PlantHeightTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_PlantHeightTextBox);
		}
	}

	private void OnPlantHeightTextBoxLeave(object sender, EventArgs e)
	{
		FormatPlantHeightValue();
	}

	private void OnPlantWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatPlantWidthValue();
		}
	}

	private void OnPlantHeightTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatPlantHeightValue();
		}
	}

	private void OnApplyButtonClick(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	public void SetExistingPlantFamilyComboBox(string _strFamilyName)
	{
		FamilyContainer familyContainer = null;
		for (int i = 0; i < m_ExistingPlantFamilyComboBox.Items.Count; i++)
		{
			if (m_ExistingPlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strFamilyName, ignoreCase: true) == 0)
			{
				m_ExistingPlantFamilyComboBox.SelectedIndex = i;
				break;
			}
		}
	}

	public void SetExistingPlantNameComboBox(string _strPlantName)
	{
		FamilySymbol familySymbol = null;
		for (int i = 0; i < m_ExistingPlantNameComboBox.Items.Count; i++)
		{
			if (m_ExistingPlantNameComboBox.Items[i] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strPlantName, ignoreCase: true) == 0)
			{
				m_ExistingPlantNameComboBox.SelectedIndex = i;
				break;
			}
		}
	}

	private void OnModifyPlantFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnLoadFamilyButtonClick(object sender, EventArgs e)
	{
		int count = m_PlantFamilyComboBox.Items.Count;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		FamilyContainer familyContainer = null;
		Family _Family = null;
		openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectPlantingFamilyFileMessage");
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				try
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + openFileDialog.SafeFileName);
					EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
					flag = RevitUtility.LoadFamily(m_dataBuffer.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
					m_dataBuffer.TransactionContainer = _TransactionContainer;
					m_dataBuffer.TransactionContainer.Commit();
				}
				catch (SEHException)
				{
					m_dataBuffer.TransactionContainer.Rollback();
					flag = false;
					RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					continue;
				}
				break;
			}
		}
		if (!flag)
		{
			if (count == 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_dataBuffer.PopulateFamilyAndSymbolLists();
		m_PlantFamilyComboBox.DataSource = m_dataBuffer.PlantFamilyList;
		m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (_Family != null)
		{
			for (int i = 0; i < m_PlantFamilyComboBox.Items.Count; i++)
			{
				if (m_PlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _Family.Name, ignoreCase: true) == 0)
				{
					m_PlantFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (m_PlantFamilyComboBox.Items.Count == count)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ExistingGroupBox = new System.Windows.Forms.GroupBox();
		this.m_PickPlantButton = new System.Windows.Forms.Button();
		this.m_ExistingPlantNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_ExistingPlantNameLabel = new System.Windows.Forms.Label();
		this.m_ExistingPlantFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_ExistingPlantFamilyLabel = new System.Windows.Forms.Label();
		this.m_ModifyPlantGroupBox = new System.Windows.Forms.GroupBox();
		this.m_LoadFamilyButton = new System.Windows.Forms.Button();
		this.m_ModifyPlantTypeCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ModifyPlantHeightCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ModifyPlantWidthCheckBox = new System.Windows.Forms.CheckBox();
		this.m_PlantHeightTextBox = new System.Windows.Forms.TextBox();
		this.m_PlantHeightLabel = new System.Windows.Forms.Label();
		this.m_PlantWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_PlantWidthLabel = new System.Windows.Forms.Label();
		this.m_SearchButton = new System.Windows.Forms.Button();
		this.m_PlantNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_PlantNameLabel = new System.Windows.Forms.Label();
		this.m_PlantFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_PlantFamilyLabel = new System.Windows.Forms.Label();
		this.m_AllInstancesRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionMethodsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_WindowSelectRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionSetRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ApplyButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_ExistingGroupBox.SuspendLayout();
		this.m_ModifyPlantGroupBox.SuspendLayout();
		this.m_SelectionMethodsGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_ExistingGroupBox.Controls.Add(this.m_PickPlantButton);
		this.m_ExistingGroupBox.Controls.Add(this.m_ExistingPlantNameComboBox);
		this.m_ExistingGroupBox.Controls.Add(this.m_ExistingPlantNameLabel);
		this.m_ExistingGroupBox.Controls.Add(this.m_ExistingPlantFamilyComboBox);
		this.m_ExistingGroupBox.Controls.Add(this.m_ExistingPlantFamilyLabel);
		this.m_ExistingGroupBox.Location = new System.Drawing.Point(12, 12);
		this.m_ExistingGroupBox.Name = "m_ExistingGroupBox";
		this.m_ExistingGroupBox.Size = new System.Drawing.Size(453, 78);
		this.m_ExistingGroupBox.TabIndex = 0;
		this.m_ExistingGroupBox.TabStop = false;
		this.m_ExistingGroupBox.Text = "Existing Plant(s) in Project";
		this.m_PickPlantButton.Location = new System.Drawing.Point(372, 44);
		this.m_PickPlantButton.Name = "m_PickPlantButton";
		this.m_PickPlantButton.Size = new System.Drawing.Size(75, 23);
		this.m_PickPlantButton.TabIndex = 4;
		this.m_PickPlantButton.Text = "&Pick Plant";
		this.m_PickPlantButton.UseVisualStyleBackColor = true;
		this.m_PickPlantButton.Click += new System.EventHandler(this.OnPickPlantButtonClick);
		this.m_ExistingPlantNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ExistingPlantNameComboBox.FormattingEnabled = true;
		this.m_ExistingPlantNameComboBox.Location = new System.Drawing.Point(124, 46);
		this.m_ExistingPlantNameComboBox.Name = "m_ExistingPlantNameComboBox";
		this.m_ExistingPlantNameComboBox.Size = new System.Drawing.Size(242, 21);
		this.m_ExistingPlantNameComboBox.TabIndex = 3;
		this.m_ExistingPlantNameLabel.AutoSize = true;
		this.m_ExistingPlantNameLabel.Location = new System.Drawing.Point(6, 50);
		this.m_ExistingPlantNameLabel.Name = "m_ExistingPlantNameLabel";
		this.m_ExistingPlantNameLabel.Size = new System.Drawing.Size(65, 13);
		this.m_ExistingPlantNameLabel.TabIndex = 2;
		this.m_ExistingPlantNameLabel.Text = "Plan&t Name:";
		this.m_ExistingPlantFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ExistingPlantFamilyComboBox.FormattingEnabled = true;
		this.m_ExistingPlantFamilyComboBox.Location = new System.Drawing.Point(124, 19);
		this.m_ExistingPlantFamilyComboBox.Name = "m_ExistingPlantFamilyComboBox";
		this.m_ExistingPlantFamilyComboBox.Size = new System.Drawing.Size(242, 21);
		this.m_ExistingPlantFamilyComboBox.TabIndex = 1;
		this.m_ExistingPlantFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnExistingPlantFamilyComboBoxSelectedIndexChanged);
		this.m_ExistingPlantFamilyLabel.AutoSize = true;
		this.m_ExistingPlantFamilyLabel.Location = new System.Drawing.Point(6, 22);
		this.m_ExistingPlantFamilyLabel.Name = "m_ExistingPlantFamilyLabel";
		this.m_ExistingPlantFamilyLabel.Size = new System.Drawing.Size(66, 13);
		this.m_ExistingPlantFamilyLabel.TabIndex = 0;
		this.m_ExistingPlantFamilyLabel.Text = "P&lant Family:";
		this.m_ModifyPlantGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_LoadFamilyButton);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_ModifyPlantTypeCheckBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_ModifyPlantHeightCheckBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_ModifyPlantWidthCheckBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantHeightTextBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantHeightLabel);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantWidthTextBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantWidthLabel);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_SearchButton);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantNameComboBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantNameLabel);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantFamilyComboBox);
		this.m_ModifyPlantGroupBox.Controls.Add(this.m_PlantFamilyLabel);
		this.m_ModifyPlantGroupBox.Location = new System.Drawing.Point(12, 96);
		this.m_ModifyPlantGroupBox.Name = "m_ModifyPlantGroupBox";
		this.m_ModifyPlantGroupBox.Size = new System.Drawing.Size(453, 202);
		this.m_ModifyPlantGroupBox.TabIndex = 1;
		this.m_ModifyPlantGroupBox.TabStop = false;
		this.m_ModifyPlantGroupBox.Text = "Modify Plant(s) in Project";
		this.m_LoadFamilyButton.Location = new System.Drawing.Point(372, 44);
		this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
		this.m_LoadFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadFamilyButton.TabIndex = 3;
		this.m_LoadFamilyButton.TabStop = false;
		this.m_LoadFamilyButton.Text = "...";
		this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Click += new System.EventHandler(this.OnLoadFamilyButtonClick);
		this.m_ModifyPlantTypeCheckBox.AutoSize = true;
		this.m_ModifyPlantTypeCheckBox.Location = new System.Drawing.Point(7, 20);
		this.m_ModifyPlantTypeCheckBox.Name = "m_ModifyPlantTypeCheckBox";
		this.m_ModifyPlantTypeCheckBox.Size = new System.Drawing.Size(111, 17);
		this.m_ModifyPlantTypeCheckBox.TabIndex = 0;
		this.m_ModifyPlantTypeCheckBox.Text = "&Modify Plant Type";
		this.m_ModifyPlantTypeCheckBox.UseVisualStyleBackColor = true;
		this.m_ModifyPlantTypeCheckBox.CheckStateChanged += new System.EventHandler(this.OnModifyPlantTypeCheckBoxChecked);
		this.m_ModifyPlantHeightCheckBox.AutoSize = true;
		this.m_ModifyPlantHeightCheckBox.Location = new System.Drawing.Point(6, 148);
		this.m_ModifyPlantHeightCheckBox.Name = "m_ModifyPlantHeightCheckBox";
		this.m_ModifyPlantHeightCheckBox.Size = new System.Drawing.Size(118, 17);
		this.m_ModifyPlantHeightCheckBox.TabIndex = 10;
		this.m_ModifyPlantHeightCheckBox.Text = "Mo&dify Plant Height";
		this.m_ModifyPlantHeightCheckBox.UseVisualStyleBackColor = true;
		this.m_ModifyPlantHeightCheckBox.CheckStateChanged += new System.EventHandler(this.OnModifyPlantHeightCheckBoxChecked);
		this.m_ModifyPlantWidthCheckBox.AutoSize = true;
		this.m_ModifyPlantWidthCheckBox.Location = new System.Drawing.Point(9, 97);
		this.m_ModifyPlantWidthCheckBox.Name = "m_ModifyPlantWidthCheckBox";
		this.m_ModifyPlantWidthCheckBox.Size = new System.Drawing.Size(115, 17);
		this.m_ModifyPlantWidthCheckBox.TabIndex = 7;
		this.m_ModifyPlantWidthCheckBox.Text = "M&odify Plant Width";
		this.m_ModifyPlantWidthCheckBox.UseVisualStyleBackColor = true;
		this.m_ModifyPlantWidthCheckBox.CheckStateChanged += new System.EventHandler(this.OnModifyPlantWidthCheckBoxChecked);
		this.m_PlantHeightTextBox.Enabled = false;
		this.m_PlantHeightTextBox.Location = new System.Drawing.Point(124, 167);
		this.m_PlantHeightTextBox.Name = "m_PlantHeightTextBox";
		this.m_PlantHeightTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_PlantHeightTextBox.TabIndex = 12;
		this.m_PlantHeightTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnPlantHeightTextBoxKeyDown);
		this.m_PlantHeightTextBox.Leave += new System.EventHandler(this.OnPlantHeightTextBoxLeave);
		this.m_PlantHeightLabel.AutoSize = true;
		this.m_PlantHeightLabel.Enabled = false;
		this.m_PlantHeightLabel.Location = new System.Drawing.Point(24, 170);
		this.m_PlantHeightLabel.Name = "m_PlantHeightLabel";
		this.m_PlantHeightLabel.Size = new System.Drawing.Size(68, 13);
		this.m_PlantHeightLabel.TabIndex = 11;
		this.m_PlantHeightLabel.Text = "Plant &Height:";
		this.m_PlantWidthTextBox.Enabled = false;
		this.m_PlantWidthTextBox.Location = new System.Drawing.Point(124, 120);
		this.m_PlantWidthTextBox.Name = "m_PlantWidthTextBox";
		this.m_PlantWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_PlantWidthTextBox.TabIndex = 9;
		this.m_PlantWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnPlantWidthTextBoxKeyDown);
		this.m_PlantWidthTextBox.Leave += new System.EventHandler(this.OnPlantWidthTextBoxLeave);
		this.m_PlantWidthLabel.AutoSize = true;
		this.m_PlantWidthLabel.Enabled = false;
		this.m_PlantWidthLabel.Location = new System.Drawing.Point(24, 123);
		this.m_PlantWidthLabel.Name = "m_PlantWidthLabel";
		this.m_PlantWidthLabel.Size = new System.Drawing.Size(65, 13);
		this.m_PlantWidthLabel.TabIndex = 8;
		this.m_PlantWidthLabel.Text = "Plant &Width:";
		this.m_SearchButton.Enabled = false;
		this.m_SearchButton.Location = new System.Drawing.Point(372, 69);
		this.m_SearchButton.Name = "m_SearchButton";
		this.m_SearchButton.Size = new System.Drawing.Size(75, 23);
		this.m_SearchButton.TabIndex = 6;
		this.m_SearchButton.Text = "Sea&rch";
		this.m_SearchButton.UseVisualStyleBackColor = true;
		this.m_SearchButton.Click += new System.EventHandler(this.OnSearchButtonClick);
		this.m_PlantNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantNameComboBox.Enabled = false;
		this.m_PlantNameComboBox.FormattingEnabled = true;
		this.m_PlantNameComboBox.Location = new System.Drawing.Point(124, 70);
		this.m_PlantNameComboBox.Name = "m_PlantNameComboBox";
		this.m_PlantNameComboBox.Size = new System.Drawing.Size(242, 21);
		this.m_PlantNameComboBox.TabIndex = 5;
		this.m_PlantNameLabel.AutoSize = true;
		this.m_PlantNameLabel.Enabled = false;
		this.m_PlantNameLabel.Location = new System.Drawing.Point(24, 74);
		this.m_PlantNameLabel.Name = "m_PlantNameLabel";
		this.m_PlantNameLabel.Size = new System.Drawing.Size(65, 13);
		this.m_PlantNameLabel.TabIndex = 4;
		this.m_PlantNameLabel.Text = "Plant &Name:";
		this.m_PlantFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantFamilyComboBox.Enabled = false;
		this.m_PlantFamilyComboBox.FormattingEnabled = true;
		this.m_PlantFamilyComboBox.Location = new System.Drawing.Point(124, 43);
		this.m_PlantFamilyComboBox.Name = "m_PlantFamilyComboBox";
		this.m_PlantFamilyComboBox.Size = new System.Drawing.Size(242, 21);
		this.m_PlantFamilyComboBox.TabIndex = 2;
		this.m_PlantFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnPlantFamilyComboBoxSelectedIndexChanged);
		this.m_PlantFamilyLabel.AutoSize = true;
		this.m_PlantFamilyLabel.Enabled = false;
		this.m_PlantFamilyLabel.Location = new System.Drawing.Point(24, 46);
		this.m_PlantFamilyLabel.Name = "m_PlantFamilyLabel";
		this.m_PlantFamilyLabel.Size = new System.Drawing.Size(66, 13);
		this.m_PlantFamilyLabel.TabIndex = 1;
		this.m_PlantFamilyLabel.Text = "Plant &Family:";
		this.m_AllInstancesRadioButton.AutoSize = true;
		this.m_AllInstancesRadioButton.Location = new System.Drawing.Point(308, 19);
		this.m_AllInstancesRadioButton.Name = "m_AllInstancesRadioButton";
		this.m_AllInstancesRadioButton.Size = new System.Drawing.Size(85, 17);
		this.m_AllInstancesRadioButton.TabIndex = 2;
		this.m_AllInstancesRadioButton.TabStop = true;
		this.m_AllInstancesRadioButton.Text = "All &Instances";
		this.m_AllInstancesRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionMethodsGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_AllInstancesRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_WindowSelectRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_SelectionSetRadioButton);
		this.m_SelectionMethodsGroupBox.Location = new System.Drawing.Point(12, 304);
		this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
		this.m_SelectionMethodsGroupBox.Size = new System.Drawing.Size(453, 43);
		this.m_SelectionMethodsGroupBox.TabIndex = 2;
		this.m_SelectionMethodsGroupBox.TabStop = false;
		this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
		this.m_WindowSelectRadioButton.AutoSize = true;
		this.m_WindowSelectRadioButton.Location = new System.Drawing.Point(152, 19);
		this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
		this.m_WindowSelectRadioButton.Size = new System.Drawing.Size(97, 17);
		this.m_WindowSelectRadioButton.TabIndex = 1;
		this.m_WindowSelectRadioButton.TabStop = true;
		this.m_WindowSelectRadioButton.Text = "Window S&elect";
		this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionSetRadioButton.AutoSize = true;
		this.m_SelectionSetRadioButton.Location = new System.Drawing.Point(6, 19);
		this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
		this.m_SelectionSetRadioButton.Size = new System.Drawing.Size(88, 17);
		this.m_SelectionSetRadioButton.TabIndex = 0;
		this.m_SelectionSetRadioButton.TabStop = true;
		this.m_SelectionSetRadioButton.Text = "&Selection Set";
		this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
		this.m_ApplyButton.Location = new System.Drawing.Point(309, 353);
		this.m_ApplyButton.Name = "m_ApplyButton";
		this.m_ApplyButton.Size = new System.Drawing.Size(75, 23);
		this.m_ApplyButton.TabIndex = 3;
		this.m_ApplyButton.Text = "&Apply";
		this.m_ApplyButton.UseVisualStyleBackColor = true;
		this.m_ApplyButton.Click += new System.EventHandler(this.OnApplyButtonClick);
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(390, 353);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(477, 388);
		base.Controls.Add(this.m_ApplyButton);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_SelectionMethodsGroupBox);
		base.Controls.Add(this.m_ModifyPlantGroupBox);
		base.Controls.Add(this.m_ExistingGroupBox);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "ModifyPlantForm";
		this.Text = "Modify Plants";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnModifyPlantFormClosing);
		this.m_ExistingGroupBox.ResumeLayout(false);
		this.m_ExistingGroupBox.PerformLayout();
		this.m_ModifyPlantGroupBox.ResumeLayout(false);
		this.m_ModifyPlantGroupBox.PerformLayout();
		this.m_SelectionMethodsGroupBox.ResumeLayout(false);
		this.m_SelectionMethodsGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.AcceptButton = this.m_ApplyButton;
		base.CancelButton = this.m_CancelButton;
	}
}
