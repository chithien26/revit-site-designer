﻿// Decompiled with JetBrains decompiler
// Type: SITES.ExternalApplication
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;
using Autodesk.Windows;
using EPCommon;
using SITES.Sites_Core;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using UIFramework;

#nullable disable
namespace SITES;

[Regeneration]
[Journaling]
public class ExternalApplication : IExternalApplication
{
  private static RunCommands m_RunCommands = (RunCommands) null;
  private const string m_strSitesINIFilename = "SitesRevit.ini";
  private const string m_strSitesHelpFilename = "Site Designer for Revit.chm";
  private static string m_strCurUserSitesRegistryKey = $"Software\\Autodesk\\Siteworks for Revit\\Siteworks for Revit {ApplicationUtility.RevitVersion}";
  private DocumentViewContainerList m_DocumentViewContainerList;

  private void DocumentExitHandler(object sender, DocumentSavingEventArgs args)
  {
  }

  private void DocumentExitHandler(object sender, DocumentSavingAsEventArgs args)
  {
    Document document = ((RevitAPIPreDocEventArgs) args).Document;
    if (document == null || document.IsFamilyDocument || RevitUtility.CompareFileNames(args.PathName, document.PathName) == 0)
      return;
    List<KeyValuePair<string, string>> sectionValuesAsList = ApplicationUtility.Settings.eplSetE_GetSectionValuesAsList(document.PathName);
    if (sectionValuesAsList == null || sectionValuesAsList.Count <= 0)
      return;
    foreach (KeyValuePair<string, string> keyValuePair in sectionValuesAsList)
      ApplicationUtility.Settings.eplSetE_SetSettingWithAbbreviation(args.PathName, keyValuePair.Key, keyValuePair.Value);
  }

  private void DocumentExitHandler(object sender, DocumentPrintingEventArgs args)
  {
  }

  private void ViewActivatedHandler(object sender, ViewActivatedEventArgs args)
  {
    if (!this.AddLandcaddRibbonIfNotPresent() || ((RevitAPIPostDocEventArgs) args).Document.IsFamilyDocument)
      return;
    int indexDocument = this.m_DocumentViewContainerList.FindIndexDocument(((RevitAPIPostDocEventArgs) args).Document);
    if (indexDocument == -1)
    {
      Document document = ((RevitAPIPostDocEventArgs) args).Document;
      this.AddDocumentViewContainerToList(((RevitAPIPostDocEventArgs) args).Document);
      indexDocument = this.m_DocumentViewContainerList.FindIndexDocument(((RevitAPIPostDocEventArgs) args).Document);
    }
    if (indexDocument < 0 || this.m_DocumentViewContainerList.ContainsView(indexDocument, args.CurrentActiveView))
      return;
    RevitUtility.HideAllSiteComponents(((RevitAPIPostDocEventArgs) args).Document, args.CurrentActiveView);
    this.m_DocumentViewContainerList.DocumentViewList[indexDocument].ViewList.Add(args.CurrentActiveView);
  }

  private void AddDocumentViewContainerToList(Document _Document)
  {
    if (_Document.IsFamilyDocument || this.m_DocumentViewContainerList.FindIndexDocument(_Document) != -1)
      return;
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<View> _ViewList = new List<View>();
    bool flag = false;
    foreach (View view in (IEnumerable<Element>) elements)
    {
      for (int index = 0; index < _ViewList.Count; ++index)
      {
        if (string.Compare(((Element) _ViewList[index]).Name, ((Element) view).Name, true) == 0)
        {
          flag = true;
          break;
        }
      }
      if (!flag)
        _ViewList.Add(view);
      else
        flag = false;
    }
    this.m_DocumentViewContainerList.DocumentViewList.Add(new DocumentViewContainer(_Document, _ViewList));
  }

  private void DocumentCreatedHandler(object sender, DocumentCreatedEventArgs args)
  {
    Document document = ((RevitAPIPostDocEventArgs) args).Document;
    if (document == null)
      return;
    this.AddDocumentViewContainerToList(document);
  }

  private void DocumentOpenedHandler(object sender, DocumentOpenedEventArgs args)
  {
    Document document = ((RevitAPIPostDocEventArgs) args).Document;
    if (document == null)
      return;
    this.AddDocumentViewContainerToList(document);
  }

  private void DocumentClosingHandler(object sender, DocumentClosingEventArgs args)
  {
    try
    {
      Document document = ((RevitAPIPreDocEventArgs) args).Document;
      if (document == null || document.IsFamilyDocument)
        return;
      ApplicationUtility.Settings.eplSetE_UpdateIniInformation(document.PathName);
      int indexDocument = this.m_DocumentViewContainerList.FindIndexDocument(document);
      if (indexDocument < 0 || indexDocument >= this.m_DocumentViewContainerList.DocumentViewList.Count)
        return;
      this.m_DocumentViewContainerList.DocumentViewList.RemoveAt(indexDocument);
    }
    catch (Exception ex)
    {
    }
  }

  private void ApplicationClosingHandler(object sender, ApplicationClosingEventArgs args)
  {
    ExternalApplication.m_RunCommands.epl_UnloadHelper(ApplicationUtility.Is64BitInstall);
    EPShared.eplLicM_ReturnLicense();
  }

  private void DialogBoxShowingHandler(object sender, DialogBoxShowingEventArgs args)
  {
    if (string.Compare(args.GetType().Name, "TaskDialogShowingEventArgs", true) != 0)
      return;
    TaskDialogShowingEventArgs showingEventArgs = (TaskDialogShowingEventArgs) args;
    if (showingEventArgs == null || string.Compare(((DialogBoxShowingEventArgs) showingEventArgs).DialogId, "TaskDialog_Missing_Third_Party_Updater", true) != 0 || !showingEventArgs.Message.Contains("LANDCADDApplication : Symbol Placement Updater"))
      return;
    ((DialogBoxShowingEventArgs) showingEventArgs).OverrideResult(1001);
  }

  public Result OnStartup(UIControlledApplication application)
  {
    IntPtr num = new IntPtr();
    IntPtr mainWindowHandle = application.MainWindowHandle;
    if (!ApplicationUtility.Initialize(application.ControlledApplication, ExternalApplication.m_strCurUserSitesRegistryKey, "SitesRevit.ini", "Site Designer for Revit.chm", mainWindowHandle, RevitProduct.SITES))
      return (Result) -1;
    ExternalApplication.m_RunCommands = new RunCommands();
    this.m_DocumentViewContainerList = new DocumentViewContainerList();
    ExternalApplication.m_RunCommands.epl_SetRevitVersion(RevitVersion.Revit2011, ApplicationUtility.Is64BitInstall);
    application.ControlledApplication.DocumentOpened += new EventHandler<DocumentOpenedEventArgs>(this.DocumentOpenedHandler);
    application.ControlledApplication.DocumentSaving += new EventHandler<DocumentSavingEventArgs>(this.DocumentExitHandler);
    application.ControlledApplication.DocumentPrinting += new EventHandler<DocumentPrintingEventArgs>(this.DocumentExitHandler);
    application.ControlledApplication.DocumentSavingAs += new EventHandler<DocumentSavingAsEventArgs>(this.DocumentExitHandler);
    application.ControlledApplication.DocumentClosing += new EventHandler<DocumentClosingEventArgs>(this.DocumentClosingHandler);
    application.ControlledApplication.DocumentCreated += new EventHandler<DocumentCreatedEventArgs>(this.DocumentCreatedHandler);
    application.DialogBoxShowing += new EventHandler<DialogBoxShowingEventArgs>(this.DialogBoxShowingHandler);
    application.ViewActivated += new EventHandler<ViewActivatedEventArgs>(this.ViewActivatedHandler);
    application.ApplicationClosing += new EventHandler<ApplicationClosingEventArgs>(this.ApplicationClosingHandler);
    this.AddRibbonItems(application);
    return (Result) 0;
  }

  private void SetTabsRight()
  {
    RibbonControl ribbonControl;
    try
    {
      ribbonControl = (RibbonControl) RevitRibbonControl.RibbonControl;
    }
    catch (TypeInitializationException ex)
    {
      return;
    }
    int oldIndex = -1;
    int newIndex = -1;
    int num = -1;
    for (int index = 0; index < ((Collection<RibbonTab>) ribbonControl.Tabs).Count; ++index)
    {
      RibbonTab tab = ((Collection<RibbonTab>) ribbonControl.Tabs)[index];
      if (string.Compare(tab.Id, EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), true) == 0)
        oldIndex = index;
      else if (string.Compare(tab.Id, EPShared.LocalRM.GetString("LandcaddRibbonTab"), true) == 0)
        newIndex = index;
      else if (string.Compare(tab.Id, "Add-Ins", true) == 0)
        num = index;
    }
    if (num != -1)
    {
      if (oldIndex != -1)
        ((ObservableCollection<RibbonTab>) ribbonControl.Tabs).Move(oldIndex, num + 1);
      if (newIndex == -1)
        return;
      ((ObservableCollection<RibbonTab>) ribbonControl.Tabs).Move(oldIndex, num + 2);
    }
    else
    {
      if (oldIndex == -1 || newIndex == -1 || newIndex <= oldIndex)
        return;
      ((ObservableCollection<RibbonTab>) ribbonControl.Tabs).Move(oldIndex, newIndex);
    }
  }

  private void AddRibbonItems(UIControlledApplication application)
  {
    this.CreateSitesRibbon(application);
  }

  private void CreateSitesRibbon(UIControlledApplication application)
  {
    this.CreateSitesRibbon(application, -1);
  }

  private void CreateSitesRibbon(UIControlledApplication application, int _nLandcaddRibbonIndex)
  {
    string location = Assembly.GetExecutingAssembly().Location;
    application.CreateRibbonTab(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"));
    RibbonPanel ribbonPanel1 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("ImportExportRibbonPanel"));
    if (ribbonPanel1 == null)
      return;
    PushButtonData pushButtonData1 = new PushButtonData(EPShared.LocalRM.GetString("ImportLandXMLRibbonButton"), EPShared.LocalRM.GetString("ImportLandXMLRibbonButton"), location, typeof (ImportLandXMLCommand).FullName);
    ((RibbonItemData) pushButtonData1).ToolTip = EPShared.LocalRM.GetString("ImportLandXMLRibbonToolTip");
    ((RibbonItemData) pushButtonData1).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDimportLandXML"));
    ((ButtonData) pushButtonData1).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ImportLandXML.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData2 = new PushButtonData(EPShared.LocalRM.GetString("ExportLandXMLRibbonButton"), EPShared.LocalRM.GetString("ExportLandXMLRibbonButton"), location, typeof (ExportLandXMLCommand).FullName);
    ((RibbonItemData) pushButtonData2).ToolTip = EPShared.LocalRM.GetString("ExportLandXMLRibbonToolTip");
    ((RibbonItemData) pushButtonData2).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDexportLandXML"));
    ((ButtonData) pushButtonData2).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ExportLandXML.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel1.AddStackedItems((RibbonItemData) pushButtonData1, (RibbonItemData) pushButtonData2);
    RibbonPanel ribbonPanel2 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("ConvertRibbonPanel"));
    PushButtonData pushButtonData3 = new PushButtonData(EPShared.LocalRM.GetString("SetBaseTopoSurfaceRibbonButton"), EPShared.LocalRM.GetString("SetBaseTopoSurfaceRibbonButton"), location, typeof (SetBaseToposurfaceCommand).FullName);
    ((RibbonItemData) pushButtonData3).ToolTip = EPShared.LocalRM.GetString("SetBaseTopoSurfaceRibbonToolTip");
    ((RibbonItemData) pushButtonData3).LongDescription = EPShared.LocalRM.GetString("SetBaseTopoSurfaceRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData3).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDsetBaseTopo"));
    ((ButtonData) pushButtonData3).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.SetBaseToposurface.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData4 = new PushButtonData(EPShared.LocalRM.GetString("ToposurfaceConversionRibbonButton"), EPShared.LocalRM.GetString("ToposurfaceConversionRibbonButton"), location, typeof (ConvertObjectToToposurfaceCommand).FullName);
    ((RibbonItemData) pushButtonData4).ToolTip = EPShared.LocalRM.GetString("ConvertObjectToToposurfaceRibbonToolTip");
    ((RibbonItemData) pushButtonData4).LongDescription = EPShared.LocalRM.GetString("ConvertObjectToToposurfaceRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData4).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDtopoConversion"));
    ((ButtonData) pushButtonData4).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ToposurfaceConversion.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel2.AddStackedItems((RibbonItemData) pushButtonData3, (RibbonItemData) pushButtonData4);
    RibbonPanel ribbonPanel3 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("LocateRibbonPanel"));
    if (ribbonPanel3 == null)
      return;
    PushButtonData pushButtonData5 = new PushButtonData(EPShared.LocalRM.GetString("LocateSoftTerrainRibbonButton"), EPShared.LocalRM.GetString("LocateSoftTerrainRibbonButton"), location, typeof (LocateSoftTerrainCommand).FullName);
    ((RibbonItemData) pushButtonData5).ToolTip = EPShared.LocalRM.GetString("LocateSoftTerrainRibbonToolTip");
    ((RibbonItemData) pushButtonData5).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_soft_terrain.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData5).LongDescription = EPShared.LocalRM.GetString("LocateSoftTerrainRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData5).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDsoftTerrainCreate"));
    ((ButtonData) pushButtonData5).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateSoftTerrain.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData6 = new PushButtonData(EPShared.LocalRM.GetString("FeatureLineRibbonButton"), EPShared.LocalRM.GetString("FeatureLineRibbonButton"), location, typeof (LocateFeatureLineCommand).FullName);
    ((RibbonItemData) pushButtonData6).ToolTip = EPShared.LocalRM.GetString("LocateFeatureLineRibbonToolTip");
    ((RibbonItemData) pushButtonData6).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_feature_line.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData6).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfeatureLineCreate"));
    ((ButtonData) pushButtonData6).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateFeatureLine.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData7 = new PushButtonData(EPShared.LocalRM.GetString("PointWipeoutRibbonButton"), EPShared.LocalRM.GetString("PointWipeoutRibbonButton"), location, typeof (LocatePointWipeoutCommand).FullName);
    ((RibbonItemData) pushButtonData7).ToolTip = EPShared.LocalRM.GetString("LocatePointWipeoutRibbonToolTip");
    ((RibbonItemData) pushButtonData7).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_point_wipeout.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData7).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDpointWipeoutCreate"));
    ((ButtonData) pushButtonData7).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocatePointWipeout.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel3.AddStackedItems((RibbonItemData) pushButtonData5, (RibbonItemData) pushButtonData6, (RibbonItemData) pushButtonData7);
    PushButtonData pushButtonData8 = new PushButtonData(EPShared.LocalRM.GetString("LocateStreetRibbonButton"), EPShared.LocalRM.GetString("LocateStreetRibbonButton"), location, typeof (LocateStreetCommand).FullName);
    ((RibbonItemData) pushButtonData8).ToolTip = EPShared.LocalRM.GetString("LocateStreetRibbonToolTip");
    ((RibbonItemData) pushButtonData8).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_street.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData8).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDstreetCreate"));
    ((ButtonData) pushButtonData8).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateStreet.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData9 = new PushButtonData(EPShared.LocalRM.GetString("LocateRetainingWallRibbonButton"), EPShared.LocalRM.GetString("LocateRetainingWallRibbonButton"), location, typeof (LocateRetainingWallCommand).FullName);
    ((RibbonItemData) pushButtonData9).ToolTip = EPShared.LocalRM.GetString("LocateRetainingWallRibbonToolTip");
    ((RibbonItemData) pushButtonData9).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_retaining_wall.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData9).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDretainingWallCreate"));
    ((ButtonData) pushButtonData9).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateRetainingWall.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel3.AddStackedItems((RibbonItemData) pushButtonData8, (RibbonItemData) pushButtonData9);
    PushButtonData pushButtonData10 = new PushButtonData(EPShared.LocalRM.GetString("LocateSidewalkRibbonButton"), EPShared.LocalRM.GetString("LocateSidewalkRibbonButton"), location, typeof (LocateSideWalkCommand).FullName);
    ((RibbonItemData) pushButtonData10).ToolTip = EPShared.LocalRM.GetString("LocateSidewalkRibbonToolTip");
    ((RibbonItemData) pushButtonData10).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_sidewalk.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData10).LongDescription = EPShared.LocalRM.GetString("LocateSidewalkRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData10).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDsidewalkCreate"));
    ((ButtonData) pushButtonData10).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateSidewalk.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData11 = new PushButtonData(EPShared.LocalRM.GetString("LocateParkingLotRibbonButton"), EPShared.LocalRM.GetString("LocateParkingLotRibbonButton"), location, typeof (LocateParkingLotCommand).FullName);
    ((RibbonItemData) pushButtonData11).ToolTip = EPShared.LocalRM.GetString("LocateParkingLotRibbonToolTip");
    ((RibbonItemData) pushButtonData11).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_parking_lot.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData11).LongDescription = EPShared.LocalRM.GetString("LocateParkingLotRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData11).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDparkinglotCreate"));
    ((ButtonData) pushButtonData11).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateParkingLot.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData12 = new PushButtonData(EPShared.LocalRM.GetString("LocateCurbRibbonButton"), EPShared.LocalRM.GetString("LocateCurbRibbonButton"), location, typeof (LocateCurbCommand).FullName);
    ((RibbonItemData) pushButtonData12).ToolTip = EPShared.LocalRM.GetString("LocateCurbRibbonToolTip");
    ((RibbonItemData) pushButtonData12).ToolTipImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.tooltip_curb.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ((RibbonItemData) pushButtonData12).LongDescription = EPShared.LocalRM.GetString("LocateCurbRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData12).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDcurbCreate"));
    ((ButtonData) pushButtonData12).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.LocateCurb.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel3.AddStackedItems((RibbonItemData) pushButtonData10, (RibbonItemData) pushButtonData11, (RibbonItemData) pushButtonData12);
    RibbonPanel ribbonPanel4 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("ModifyRibbonPanel"));
    if (ribbonPanel4 == null)
      return;
    PushButtonData pushButtonData13 = new PushButtonData(EPShared.LocalRM.GetString("ModifySoftTerrainRibbonButton"), EPShared.LocalRM.GetString("ModifySoftTerrainRibbonButton"), location, typeof (ModifySoftTerrainCommand).FullName);
    ((RibbonItemData) pushButtonData13).ToolTip = EPShared.LocalRM.GetString("ModifySoftTerrainRibbonToolTip");
    ((RibbonItemData) pushButtonData13).LongDescription = EPShared.LocalRM.GetString("ModifySoftTerrainRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData13).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDsoftTerrainModify"));
    ((ButtonData) pushButtonData13).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifySoftTerrain.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData14 = new PushButtonData(EPShared.LocalRM.GetString("FeatureLineRibbonButton"), EPShared.LocalRM.GetString("FeatureLineRibbonButton"), location, typeof (ModifyFeatureLineCommand).FullName);
    ((RibbonItemData) pushButtonData14).ToolTip = EPShared.LocalRM.GetString("ModifyFeatureLineRibbonToolTip");
    ((RibbonItemData) pushButtonData14).LongDescription = EPShared.LocalRM.GetString("ModifyFeatureLineRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData14).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfeatureLineModify"));
    ((ButtonData) pushButtonData14).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifyFeatureLine.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData15 = new PushButtonData(EPShared.LocalRM.GetString("PointWipeoutRibbonButton"), EPShared.LocalRM.GetString("PointWipeoutRibbonButton"), location, typeof (ModifyPointWipeoutCommand).FullName);
    ((RibbonItemData) pushButtonData15).ToolTip = EPShared.LocalRM.GetString("ModifyPointWipeoutRibbonToolTip");
    ((RibbonItemData) pushButtonData15).LongDescription = EPShared.LocalRM.GetString("ModifyPointWipeoutRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData15).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDpointWipeoutModify"));
    ((ButtonData) pushButtonData15).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifyPointWipeout.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel4.AddStackedItems((RibbonItemData) pushButtonData13, (RibbonItemData) pushButtonData14, (RibbonItemData) pushButtonData15);
    PushButtonData pushButtonData16 = new PushButtonData(EPShared.LocalRM.GetString("ModifyStreetRibbonButton"), EPShared.LocalRM.GetString("ModifyStreetRibbonButton"), location, typeof (ModifyStreetCommand).FullName);
    ((RibbonItemData) pushButtonData16).ToolTip = EPShared.LocalRM.GetString("ModifyStreetRibbonToolTip");
    ((RibbonItemData) pushButtonData16).LongDescription = EPShared.LocalRM.GetString("ModifyStreetRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData16).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDstreetModify"));
    ((ButtonData) pushButtonData16).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifyStreet.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData17 = new PushButtonData(EPShared.LocalRM.GetString("ModifyRetainingWallRibbonButton"), EPShared.LocalRM.GetString("ModifyRetainingWallRibbonButton"), location, typeof (ModifyRetainingWallCommand).FullName);
    ((RibbonItemData) pushButtonData17).ToolTip = EPShared.LocalRM.GetString("ModifyRetainingWallRibbonToolTip");
    ((RibbonItemData) pushButtonData17).LongDescription = EPShared.LocalRM.GetString("ModifyRetainingWallRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData17).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDretainingWallModify"));
    ((ButtonData) pushButtonData17).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifyRetainingWall.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel4.AddStackedItems((RibbonItemData) pushButtonData16, (RibbonItemData) pushButtonData17);
    PushButtonData pushButtonData18 = new PushButtonData(EPShared.LocalRM.GetString("ModifySidewalkRibbonButton"), EPShared.LocalRM.GetString("ModifySidewalkRibbonButton"), location, typeof (ModifySidewalkCommand).FullName);
    ((RibbonItemData) pushButtonData18).ToolTip = EPShared.LocalRM.GetString("ModifySidewalkRibbonToolTip");
    ((RibbonItemData) pushButtonData18).LongDescription = EPShared.LocalRM.GetString("ModifySidewalkRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData18).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDsidewalkModify"));
    ((ButtonData) pushButtonData18).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifySidewalk.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData19 = new PushButtonData(EPShared.LocalRM.GetString("ModifyParkingLotRibbonButton"), EPShared.LocalRM.GetString("ModifyParkingLotRibbonButton"), location, typeof (ModifyParkingLotCommand).FullName);
    ((RibbonItemData) pushButtonData19).ToolTip = EPShared.LocalRM.GetString("ModifyParkingLotRibbonToolTip");
    ((RibbonItemData) pushButtonData19).LongDescription = EPShared.LocalRM.GetString("ModifyParkingLotRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData19).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDparkinglotModify"));
    ((ButtonData) pushButtonData19).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifyParkingLot.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData20 = new PushButtonData(EPShared.LocalRM.GetString("ModifyCurbRibbonButton"), EPShared.LocalRM.GetString("ModifyCurbRibbonButton"), location, typeof (ModifyCurbCommand).FullName);
    ((RibbonItemData) pushButtonData20).ToolTip = EPShared.LocalRM.GetString("ModifyCurbRibbonToolTip");
    ((RibbonItemData) pushButtonData20).LongDescription = EPShared.LocalRM.GetString("ModifyCurbRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData20).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDcurbModify"));
    ((ButtonData) pushButtonData20).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ModifyCurb.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel4.AddStackedItems((RibbonItemData) pushButtonData18, (RibbonItemData) pushButtonData19, (RibbonItemData) pushButtonData20);
    RibbonPanel ribbonPanel5 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("ReportRibbonPanel"));
    if (ribbonPanel5 == null)
      return;
    PushButtonData pushButtonData21 = new PushButtonData(EPShared.LocalRM.GetString("AnnotateRibbonButton"), EPShared.LocalRM.GetString("AnnotateRibbonButton"), location, typeof (AnnotateCommand).FullName);
    ((RibbonItemData) pushButtonData21).ToolTip = EPShared.LocalRM.GetString("AnnotateRibbonToolTip");
    ((RibbonItemData) pushButtonData21).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDannotate"));
    ((ButtonData) pushButtonData21).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.Annotate.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData22 = new PushButtonData(EPShared.LocalRM.GetString("SitesReportRibbonButton"), EPShared.LocalRM.GetString("SitesReportRibbonButton"), location, typeof (SitesReportCommand).FullName);
    ((RibbonItemData) pushButtonData22).ToolTip = EPShared.LocalRM.GetString("SitesReportRibbonToolTip");
    ((RibbonItemData) pushButtonData22).LongDescription = EPShared.LocalRM.GetString("SitesReportRibbonToolTipLongDescription");
    ((RibbonItemData) pushButtonData22).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDreports"));
    ((ButtonData) pushButtonData22).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.Report.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel5.AddStackedItems((RibbonItemData) pushButtonData21, (RibbonItemData) pushButtonData22);
    RibbonPanel ribbonPanel6 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("FamilyManagerRibbonPanel"));
    if (ribbonPanel6 == null)
      return;
    PulldownButtonData pulldownButtonData = new PulldownButtonData(EPShared.LocalRM.GetString("FamilyManagerRibbonPanel"), EPShared.LocalRM.GetString("FamilyManagerRibbonPanel"));
    ((RibbonItemData) pulldownButtonData).ToolTip = EPShared.LocalRM.GetString("SiteComponentFamilyManagerToolTip");
    ((RibbonItemData) pulldownButtonData).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDtipFamilyManagers"));
    ((ButtonData) pulldownButtonData).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.StreetFamilyManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PulldownButton pulldownButton = ribbonPanel6.AddItem((RibbonItemData) pulldownButtonData) as PulldownButton;
    PushButtonData pushButtonData23 = new PushButtonData(EPShared.LocalRM.GetString("SoftTerrainFamilyManagerRibbonButton"), EPShared.LocalRM.GetString("SoftTerrainFamilyManagerRibbonButton"), location, typeof (SoftTerrainFamilyManagerCommand).FullName);
    ((RibbonItemData) pushButtonData23).ToolTip = EPShared.LocalRM.GetString("SoftTerrainFamilyManagerRibbonToolTip");
    ((RibbonItemData) pushButtonData23).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfamilyMgrSoftTerrain"));
    ((ButtonData) pushButtonData23).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.SoftTerrainManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    pulldownButton.AddPushButton(pushButtonData23);
    PushButtonData pushButtonData24 = new PushButtonData(EPShared.LocalRM.GetString("StreetFamilyManagerRibbonButton"), EPShared.LocalRM.GetString("StreetFamilyManagerRibbonButton"), location, typeof (StreetsFamilyManagerCommand).FullName);
    ((RibbonItemData) pushButtonData24).ToolTip = EPShared.LocalRM.GetString("StreetFamilyManagerToolTip");
    ((RibbonItemData) pushButtonData24).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfamilyMgrStreet"));
    ((ButtonData) pushButtonData24).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.StreetFamilyManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    pulldownButton.AddPushButton(pushButtonData24);
    PushButtonData pushButtonData25 = new PushButtonData(EPShared.LocalRM.GetString("RetainingWallFamilyManagerRibbonButton"), EPShared.LocalRM.GetString("RetainingWallFamilyManagerRibbonButton"), location, typeof (RetainingWallFamilyManagerCommand).FullName);
    ((RibbonItemData) pushButtonData25).ToolTip = EPShared.LocalRM.GetString("RetainingWallFamilyManagerToolTip");
    ((RibbonItemData) pushButtonData25).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfamilyMgrRetainingWall"));
    ((ButtonData) pushButtonData25).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.RetainingWallFamilyManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    pulldownButton.AddPushButton(pushButtonData25);
    PushButtonData pushButtonData26 = new PushButtonData(EPShared.LocalRM.GetString("SidewalkFamilyManagerRibbonButton"), EPShared.LocalRM.GetString("SidewalkFamilyManagerRibbonButton"), location, typeof (SidewalkFamilyManagerCommand).FullName);
    ((RibbonItemData) pushButtonData26).ToolTip = EPShared.LocalRM.GetString("SidewalkFamilyManagerToolTip");
    ((RibbonItemData) pushButtonData26).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfamilyMgrSidewalk"));
    ((ButtonData) pushButtonData26).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.SidewalkFamilyManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    pulldownButton.AddPushButton(pushButtonData26);
    PushButtonData pushButtonData27 = new PushButtonData(EPShared.LocalRM.GetString("ParkingLotFamilyManagerRibbonButton"), EPShared.LocalRM.GetString("ParkingLotFamilyManagerRibbonButton"), location, typeof (ParkingLotFamilyManagerCommand).FullName);
    ((RibbonItemData) pushButtonData27).ToolTip = EPShared.LocalRM.GetString("ParkingLotFamilyManagerToolTip");
    ((RibbonItemData) pushButtonData27).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfamilyMgrParkinglot"));
    ((ButtonData) pushButtonData27).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.ParkingLotFamilyManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    pulldownButton.AddPushButton(pushButtonData27);
    PushButtonData pushButtonData28 = new PushButtonData(EPShared.LocalRM.GetString("CurbFamilyManagerRibbonButton"), EPShared.LocalRM.GetString("CurbFamilyManagerRibbonButton"), location, typeof (CurbFamilyManagerCommand).FullName);
    ((RibbonItemData) pushButtonData28).ToolTip = EPShared.LocalRM.GetString("CurbFamilyManagerToolTip");
    ((RibbonItemData) pushButtonData28).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDfamilyMgrCurb"));
    ((ButtonData) pushButtonData28).LargeImage = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.CurbFamilyManager.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    pulldownButton.AddPushButton(pushButtonData28);
    RibbonPanel ribbonPanel7 = application.CreateRibbonPanel(EPShared.LocalRM.GetString("LandcaddSitesRibbonTab"), EPShared.LocalRM.GetString("SettingRibbonButton"));
    if (ribbonPanel7 == null)
      return;
    PushButtonData pushButtonData29 = new PushButtonData($"{EPShared.LocalRM.GetString("LandcaddSitesRibbonTab")} {EPShared.LocalRM.GetString("AboutRibbonButton")}", EPShared.LocalRM.GetString("AboutRibbonButton"), location, typeof (SitesAboutCommand).FullName);
    ((RibbonItemData) pushButtonData29).ToolTip = EPShared.LocalRM.GetString("AboutSiteworksRibbonToolTip");
    ((RibbonItemData) pushButtonData29).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDabout"));
    ((ButtonData) pushButtonData29).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.About.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    PushButtonData pushButtonData30 = new PushButtonData($"{EPShared.LocalRM.GetString("LandcaddSitesRibbonTab")} {EPShared.LocalRM.GetString("SettingRibbonButton")}", EPShared.LocalRM.GetString("SettingRibbonButton"), location, typeof (SitesSettingsCommand).FullName);
    ((RibbonItemData) pushButtonData30).ToolTip = EPShared.LocalRM.GetString("SettingRibbonToolTip");
    ((RibbonItemData) pushButtonData30).SetContextualHelp(new ContextualHelp((ContextualHelpType) 1, "HID_SDsettings"));
    ((ButtonData) pushButtonData30).Image = (ImageSource) System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(Resources.Settings.GetHbitmap(), IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
    ribbonPanel7.AddStackedItems((RibbonItemData) pushButtonData30, (RibbonItemData) pushButtonData29);
  }

  private bool AddLandcaddRibbonIfNotPresent() => true;

  public Result OnShutdown(UIControlledApplication application)
  {
    application.ControlledApplication.DocumentOpened -= new EventHandler<DocumentOpenedEventArgs>(this.DocumentOpenedHandler);
    application.ControlledApplication.DocumentSaving -= new EventHandler<DocumentSavingEventArgs>(this.DocumentExitHandler);
    application.ControlledApplication.DocumentPrinting -= new EventHandler<DocumentPrintingEventArgs>(this.DocumentExitHandler);
    application.ControlledApplication.DocumentSavingAs -= new EventHandler<DocumentSavingAsEventArgs>(this.DocumentExitHandler);
    application.ControlledApplication.DocumentClosing -= new EventHandler<DocumentClosingEventArgs>(this.DocumentClosingHandler);
    application.ControlledApplication.DocumentCreated -= new EventHandler<DocumentCreatedEventArgs>(this.DocumentCreatedHandler);
    application.DialogBoxShowing -= new EventHandler<DialogBoxShowingEventArgs>(this.DialogBoxShowingHandler);
    application.ViewActivated -= new EventHandler<ViewActivatedEventArgs>(this.ViewActivatedHandler);
    application.ApplicationClosing -= new EventHandler<ApplicationClosingEventArgs>(this.ApplicationClosingHandler);
    return (Result) 0;
  }
}
