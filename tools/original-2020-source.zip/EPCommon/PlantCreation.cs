﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantCreation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantCreation
{
  private Document m_Document;
  private List<View> m_ViewList;
  private PlacePlantForm m_DisplayForm;
  private List<TopographySurfaceContainer> m_SurfaceList;
  private List<FamilyContainer> m_PlantFamilyList;
  private FamilySymbol m_PlantingPlacementSymbol;
  private EPTransactionContainer m_TransactionContainer;
  private List<Element> m_CurrentElementList;

  public PlantCreation(Document _CurDocument)
  {
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_ViewList = new List<View>();
    this.m_SurfaceList = new List<TopographySurfaceContainer>();
    this.m_PlantFamilyList = new List<FamilyContainer>();
    this.InitializeListData();
  }

  public void PopulateFamilyAndSymbolLists() => this.PopulateFamilyAndSymbolLists(false);

  private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
  {
    this.m_PlantFamilyList.Clear();
    FilteredElementIterator elementIterator1 = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001360).GetElementIterator();
    this.m_CurrentElementList = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements().ToList<Element>();
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
    Eps_Point _SecondCheckPnt = new Eps_Point();
    elementIterator1.Reset();
    BuiltInCategory builtInCategory;
    while (elementIterator1.MoveNext())
    {
      if (elementIterator1.Current is FamilySymbol current1 && ((Element) current1).Category != null)
      {
        int integerValue1 = ((Element) current1).Category.Id.IntegerValue;
        builtInCategory = (BuiltInCategory) -2001360;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1)
        {
          List<Eps_Point> _PointList = (List<Eps_Point>) null;
          foreach (Element currentElement in this.m_CurrentElementList)
          {
            if (currentElement is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null)
            {
              int integerValue2 = ((Element) familyInstance.Symbol).Category.Id.IntegerValue;
              builtInCategory = (BuiltInCategory) -2001360;
              int hashCode2 = builtInCategory.GetHashCode();
              if (integerValue2 == hashCode2 && string.Compare(((Element) current1).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
              {
                if (_PointList == null)
                  _PointList = new List<Eps_Point>();
                Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
                if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
                  _PointList.Add(_FindPoint);
              }
            }
          }
          if (_PointList != null && _PointList.Count > 0)
          {
            bool flag = true;
            while (flag)
            {
              flag = false;
              for (int index = 0; index < _PointList.Count; ++index)
              {
                if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index], _SecondCheckPnt))
                {
                  ++_SecondCheckPnt.z;
                  flag = true;
                  break;
                }
              }
            }
          }
          bool flag1 = false;
          for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
          {
            if (string.Compare(this.m_PlantFamilyList[index].FamilyName, ((Element) current1.Family).Name, true) == 0)
            {
              this.m_PlantFamilyList[index].FamilySymbolList.Add(current1);
              flag1 = true;
              break;
            }
          }
          if (!flag1)
            this.m_PlantFamilyList.Add(new FamilyContainer(((Element) current1.Family).Name)
            {
              FamilySymbolList = {
                current1
              }
            });
        }
      }
    }
    this.m_TransactionContainer.Rollback();
    FilteredElementIterator elementIterator2 = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2005021).GetElementIterator();
    bool flag2 = false;
    elementIterator2.Reset();
    while (elementIterator2.MoveNext())
    {
      if (elementIterator2.Current is FamilySymbol current2 && ((Element) current2).Category != null)
      {
        int integerValue = ((Element) current2).Category.Id.IntegerValue;
        builtInCategory = (BuiltInCategory) -2005021;
        int hashCode = builtInCategory.GetHashCode();
        if (integerValue == hashCode)
        {
          flag2 = true;
          break;
        }
      }
    }
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151);
    Parameter CurLanddCadID = (Parameter) null;
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)).ToList<Element>();
    bool flag3 = false;
    foreach (Element element in list)
    {
      if (element is FamilySymbol familySymbol && ((Element) familySymbol).Category != null)
      {
        CurLanddCadID = ((Element) familySymbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)
        {
          this.m_PlantingPlacementSymbol = familySymbol;
          flag3 = true;
          break;
        }
      }
    }
    string empty = string.Empty;
    if (_bCheckForFamily && (this.m_PlantFamilyList.Count == 0 || !flag2 || !flag3))
    {
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(this.m_Document.PathName, "PlacePlant", EPShared.LocalRM.GetString("PlantingTagFamiliesNotLoadedMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"),
        EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption")
      });
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), true) == 0)
      {
        Family _Family = (Family) null;
        if (this.m_PlantFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Conifer", "LC Conifers.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
              {
                bool flag4 = false;
                for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
                {
                  if (string.Compare(this.m_PlantFamilyList[index].FamilyName, ((Element) element.Family).Name, true) == 0)
                  {
                    this.m_PlantFamilyList[index].FamilySymbolList.Add(element);
                    flag4 = true;
                    break;
                  }
                }
                if (!flag4)
                  this.m_PlantFamilyList.Add(new FamilyContainer(((Element) element.Family).Name)
                  {
                    FamilySymbolList = {
                      element
                    }
                  });
              }
            }
          }
        }
        if (!flag2 && RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Tags", "LC Plant Tags - Single Line.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantingTagFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
        }
        if (!flag3 && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            using (IEnumerator<ElementId> enumerator = _Family.GetFamilySymbolIds().GetEnumerator())
            {
              if (enumerator.MoveNext())
              {
                if (this.m_Document.GetElement(enumerator.Current) is FamilySymbol element)
                  this.m_PlantingPlacementSymbol = element;
              }
            }
          }
        }
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
      this.m_PlantFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  private void InitializeListData()
  {
    this.PopulateFamilyAndSymbolLists(true);
    foreach (View element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (View)).ToElements())
    {
      if (element.GenLevel != null && !this.m_ViewList.Contains(element) && (element.ViewType == 1 || element.ViewType == 115 || element.ViewType == 116) && string.Compare(((Element) element).Name, EPShared.LocalRM.GetString("SiteString"), true) != 0)
      {
        bool flag = false;
        for (int index = 0; index < this.m_ViewList.Count; ++index)
        {
          if (string.Compare(((Element) this.m_ViewList[index].GenLevel).UniqueId, ((Element) element.GenLevel).UniqueId, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          this.m_ViewList.Add(element);
      }
    }
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
      this.m_SurfaceList.Add(new TopographySurfaceContainer(this.m_Document.Application, element as TopographySurface));
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    if (this.m_PlantFamilyList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_DisplayForm = new PlacePlantForm(this))
    {
      while (_DialogResult == DialogResult.OK)
      {
        flag = this.ShowDialog(ref _DialogResult);
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    return flag;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    int num1 = (int) this.m_DisplayForm.ShowDialog();
    _DialogResult = this.m_DisplayForm.DialogResult;
    if (_DialogResult != DialogResult.OK)
      return false;
    List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
    if (this.m_DisplayForm.PickToposurface)
      _SurfaceList.Add(this.m_DisplayForm.Surface);
    PlacementSettings _PlantPlacementSettings = new PlacementSettings(LocateType.Plant, this.m_DisplayForm.PlacementType, this.m_DisplayForm.DeleteExistingChecked, this.m_DisplayForm.ExistingElementChecked, this.m_DisplayForm.PlaceGroupTagChecked, this.m_DisplayForm.Level, this.m_DisplayForm.View, this.m_DisplayForm.Type, _SurfaceList, this.m_DisplayForm.SetbackSpacing, this.m_DisplayForm.PlantHeight, this.m_DisplayForm.HeightVariance, this.m_DisplayForm.PlantWidth, this.m_DisplayForm.WidthVariance, this.m_DisplayForm.PlantSpacing, this.m_DisplayForm.RotationAngle, this.m_DisplayForm.StartingDistance, this.m_PlantingPlacementSymbol, this.m_TransactionContainer);
    _PlantPlacementSettings.LeaderedTagChecked = this.m_DisplayForm.LeaderedTagChecked;
    ElementSet _Elements = (ElementSet) null;
    string empty = string.Empty;
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlantsTransaction"));
    List<FailureDefinitionId> FailureDefinitionIdList = new List<FailureDefinitionId>();
    FailureDefinitionIdList.Add(BuiltInFailures.InaccurateFailures.InaccurateLine);
    if (this.m_DisplayForm.PlaceGroupTagChecked)
      FailureDefinitionIdList.Add(BuiltInFailures.GroupFailures.AtomViolationWhenOnePlaceInstance);
    this.m_TransactionContainer.FailureHandlingOptions(FailureDefinitionIdList);
    if (!this.m_DisplayForm.ExistingElementChecked)
    {
      if (this.m_DisplayForm.GroveChecked)
        empty = EPShared.LocalRM.GetString("PickPointsForBoundaryPrompt");
      else if (this.m_DisplayForm.HedgeRowChecked)
        empty = EPShared.LocalRM.GetString("PickStartPointPrompt");
      else if (this.m_DisplayForm.SingleChecked)
        empty = EPShared.LocalRM.GetString("PickPointPrompt");
      ElementSet elm_set = new ElementSet();
      ElementSet elementSet = new ElementSet();
      List<ModelCurve> modelCurveList = new List<ModelCurve>();
      Eps_Leg _CurrentLeg = (Eps_Leg) null;
      Eps_Point _Point = (Eps_Point) null;
      Eps_Point epsPoint = (Eps_Point) null;
      bool flag1 = true;
      while (flag1)
      {
        flag1 = RevitUtility.GetPointFromProject(this.m_Document, empty, ref _Point, false);
        if (flag1)
        {
          if (this.m_DisplayForm.SingleChecked)
          {
            FamilyInstance familyInstance = PlantCommon.PlaceSingleOnPoint(this.m_Document, _PlantPlacementSettings, (Element) null, _Point, false);
            elementSet.Insert((Element) familyInstance);
            if (this.m_DisplayForm.SegmentChecked)
              flag1 = false;
          }
          else if (epsPoint != null)
          {
            Eps_Leg _CompleteLeg = new Eps_Leg();
            _CompleteLeg.Line = new Eps_Line();
            _CompleteLeg.Line.StartPnt = epsPoint;
            _CompleteLeg.Line.EndPnt = _Point;
            if (_CurrentLeg == null)
              _CurrentLeg = Eps_Leg.SingleLeg(_CompleteLeg);
            else
              _CurrentLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
            this.m_TransactionContainer.BeginTransaction();
            modelCurveList.Add(RevitUtility.NewModelCurve(this.m_Document, _CompleteLeg.Line));
            this.m_TransactionContainer.EndTransaction();
            if (this.m_DisplayForm.SegmentChecked)
              flag1 = false;
          }
          else if (this.m_DisplayForm.HedgeRowChecked)
            empty = EPShared.LocalRM.GetString("PickEndPointPrompt");
          epsPoint = _Point;
        }
        this.m_Document.Regenerate();
      }
      if (_CurrentLeg != null && _CurrentLeg.Next != null && this.m_DisplayForm.GroveChecked && !EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt, 1E-05))
      {
        Eps_Leg _CompleteLeg = new Eps_Leg();
        _CompleteLeg.Line = new Eps_Line();
        _CompleteLeg.Line.StartPnt = _CurrentLeg.LegEndPnt;
        _CompleteLeg.Line.EndPnt = _CurrentLeg.LegStartPnt;
        _CurrentLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
        this.m_TransactionContainer.BeginTransaction();
        modelCurveList.Add(RevitUtility.NewModelCurve(this.m_Document, _CompleteLeg.Line));
        this.m_TransactionContainer.EndTransaction();
      }
      for (int index = 0; index < modelCurveList.Count; ++index)
        elm_set.Insert((Element) modelCurveList[index]);
      bool flag2 = true;
      if (_CurrentLeg != null)
        flag2 = PlantCommon.PlaceLegList(this.m_Document, _PlantPlacementSettings, _CurrentLeg);
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
      return flag2;
    }
    if (!RevitUtility.GetElementsFromProject(this.m_Document, !this.m_DisplayForm.GroveChecked ? EPShared.LocalRM.GetString("PickObjectMessage") : EPShared.LocalRM.GetString("PickClosedBoundaryMessage"), ref _Elements))
      return false;
    foreach (Element element in _Elements)
    {
      LocationCurve location1 = element.Location as LocationCurve;
      Curve curve = (Curve) null;
      if (location1 != null)
        curve = location1.Curve;
      if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
      {
        Eps_Leg epsLeg1 = (Eps_Leg) null;
        if (location1 != null && this.m_DisplayForm.ChainChecked)
          epsLeg1 = RevitGeometry.GetLegFromElementList((Eps_Leg) null, element);
        if (epsLeg1 != null)
        {
          if (!RevitDefines.GT(this.m_DisplayForm.StartingDistance, RevitGeometry.eplGeoE_CalcLegListLength(epsLeg1)))
            return PlantCommon.PlaceLegList(this.m_Document, _PlantPlacementSettings, epsLeg1);
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
        switch (curve)
        {
          case Arc _:
            Arc _Arc = (Arc) curve;
            if (this.m_DisplayForm.SingleChecked)
            {
              Eps_Point _StaOffPnt = new Eps_Point();
              if (!((Curve) _Arc).IsBound)
                _StaOffPnt = new Eps_Point(_Arc.Center);
              else
                EPShared.eplGeoE_FindStaOffPointAlongArc(new Eps_Arc(_Arc), ((Curve) _Arc).Length / 2.0, 0.0, ref _StaOffPnt);
              PlantCommon.PlaceSingleOnPoint(this.m_Document, _PlantPlacementSettings, element, _StaOffPnt);
              break;
            }
            if (this.m_DisplayForm.GroveChecked)
            {
              if (!((Curve) _Arc).IsBound)
              {
                Eps_Leg _BoundaryLeg = new Eps_Leg();
                _BoundaryLeg.Arc = new Eps_Arc(_Arc);
                List<Eps_Leg> _IslandList = new List<Eps_Leg>();
                PlantCommon.PickIslandLegs(this.m_Document, ref _IslandList);
                PlantCommon.PlaceHedgeGrove(this.m_Document, _PlantPlacementSettings, _BoundaryLeg, _IslandList);
                if (this.m_DisplayForm.DeleteExistingChecked)
                {
                  this.m_TransactionContainer.BeginTransaction();
                  for (int index = 0; index < _IslandList.Count; ++index)
                  {
                    if (_IslandList[index].ElementSet != null && _IslandList[index].ElementSet.Size > 0)
                      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_IslandList[index].ElementSet));
                  }
                  this.m_TransactionContainer.EndTransaction();
                  break;
                }
                break;
              }
              int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
            if (this.m_DisplayForm.HedgeRowChecked)
            {
              if (RevitDefines.GT(this.m_DisplayForm.StartingDistance, curve.Length))
              {
                int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              Eps_Arc _EvalArc = new Eps_Arc(_Arc);
              if (!RevitUtility.EvaluateArc(this.m_Document, this.m_TransactionContainer, this.m_DisplayForm.PlantSpacing, ref _EvalArc))
                return false;
              _PlantPlacementSettings.IsReverse = _EvalArc.IsReverse;
              if (this.m_DisplayForm.CenteredHedgeRowChecked)
              {
                PlantCommon.PlaceCenterRowOnArc(this.m_Document, _PlantPlacementSettings, element, _EvalArc);
                break;
              }
              if (this.m_DisplayForm.AlternateHedgeRowChecked)
              {
                PlantCommon.PlaceAltRowOnArc(this.m_Document, _PlantPlacementSettings, element, _EvalArc);
                break;
              }
              Eps_Arc _OffsetArc1 = new Eps_Arc();
              EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, this.m_DisplayForm.SetbackSpacing, 1, ref _OffsetArc1);
              Eps_Arc _OffsetArc2 = new Eps_Arc();
              EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, this.m_DisplayForm.SetbackSpacing, 2, ref _OffsetArc2);
              ElementSet elm_set = new ElementSet();
              if (_OffsetArc1.Radius > 0.0)
              {
                this.m_TransactionContainer.BeginTransaction();
                ModelCurve modelCurve = RevitUtility.NewModelCurve(this.m_Document, _OffsetArc1);
                this.m_TransactionContainer.EndTransaction();
                elm_set.Insert((Element) modelCurve);
              }
              if (_OffsetArc2.Radius > 0.0)
              {
                this.m_TransactionContainer.BeginTransaction();
                ModelCurve modelCurve = RevitUtility.NewModelCurve(this.m_Document, _OffsetArc2);
                this.m_TransactionContainer.EndTransaction();
                elm_set.Insert((Element) modelCurve);
              }
              bool _UseRightSide = true;
              bool flag = RevitUtility.PickSideArc(this.m_Document, _EvalArc, ref _UseRightSide);
              this.m_TransactionContainer.BeginTransaction();
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
              this.m_TransactionContainer.EndTransaction();
              if (!flag)
                return false;
              _PlantPlacementSettings.UseRightSide = _UseRightSide;
              if (_UseRightSide)
              {
                PlantCommon.PlaceCenterRowOnArc(this.m_Document, _PlantPlacementSettings, element, _OffsetArc1);
                break;
              }
              PlantCommon.PlaceCenterRowOnArc(this.m_Document, _PlantPlacementSettings, element, _OffsetArc2);
              break;
            }
            break;
          case Line _:
            if (this.m_DisplayForm.SingleChecked)
            {
              Eps_Point _MidPoint = new Eps_Point();
              EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(new Eps_Point(curve.GetEndPoint(0)), new Eps_Point(curve.GetEndPoint(1)), ref _MidPoint);
              PlantCommon.PlaceSingleOnPoint(this.m_Document, _PlantPlacementSettings, element, _MidPoint);
              break;
            }
            if (this.m_DisplayForm.GroveChecked)
            {
              int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
            if (this.m_DisplayForm.HedgeRowChecked)
            {
              if (RevitDefines.GT(this.m_DisplayForm.StartingDistance, curve.Length))
              {
                int num6 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              Eps_Line _EvalLine = new Eps_Line();
              _EvalLine.StartPnt = new Eps_Point(curve.GetEndPoint(0));
              _EvalLine.EndPnt = new Eps_Point(curve.GetEndPoint(1));
              if (!RevitUtility.EvaluateLine(this.m_Document, this.m_TransactionContainer, this.m_DisplayForm.PlantSpacing, ref _EvalLine))
                return false;
              _PlantPlacementSettings.IsReverse = _EvalLine.IsReverse;
              if (this.m_DisplayForm.CenteredHedgeRowChecked)
              {
                PlantCommon.PlaceCenterRowOnLine(this.m_Document, _PlantPlacementSettings, element, _EvalLine);
                break;
              }
              if (this.m_DisplayForm.AlternateHedgeRowChecked)
              {
                PlantCommon.PlaceAltRowOnLine(this.m_Document, _PlantPlacementSettings, element, _EvalLine);
                break;
              }
              Eps_Line _OffsetLine1 = new Eps_Line();
              EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, this.m_DisplayForm.SetbackSpacing, 1, ref _OffsetLine1);
              Eps_Line _OffsetLine2 = new Eps_Line();
              EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, this.m_DisplayForm.SetbackSpacing, 2, ref _OffsetLine2);
              this.m_TransactionContainer.BeginTransaction();
              ModelCurve modelCurve1 = RevitUtility.NewModelCurve(this.m_Document, _OffsetLine1);
              ModelCurve modelCurve2 = RevitUtility.NewModelCurve(this.m_Document, _OffsetLine2);
              this.m_TransactionContainer.EndTransaction();
              this.m_Document.Regenerate();
              bool _UseRightSide = true;
              bool flag = RevitUtility.PickSideLine(this.m_Document, _EvalLine, ref _UseRightSide);
              ElementSet elm_set = new ElementSet();
              elm_set.Insert((Element) modelCurve1);
              elm_set.Insert((Element) modelCurve2);
              this.m_TransactionContainer.BeginTransaction();
              this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
              this.m_TransactionContainer.EndTransaction();
              if (!flag)
                return false;
              _PlantPlacementSettings.UseRightSide = _UseRightSide;
              if (_UseRightSide)
              {
                PlantCommon.PlaceCenterRowOnLine(this.m_Document, _PlantPlacementSettings, element, _OffsetLine1);
                break;
              }
              PlantCommon.PlaceCenterRowOnLine(this.m_Document, _PlantPlacementSettings, element, _OffsetLine2);
              break;
            }
            break;
          case Ellipse _:
          case NurbSpline _:
          case HermiteSpline _:
            if (this.m_DisplayForm.SingleChecked && curve is Ellipse && !curve.IsBound)
            {
              Ellipse ellipse = (Ellipse) curve;
              PlantCommon.PlaceSingleOnPoint(this.m_Document, _PlantPlacementSettings, element, new Eps_Point(ellipse.Center));
              break;
            }
            IList<XYZ> xyzList = curve.Tessellate();
            int count = xyzList.Count;
            if (count > 1)
            {
              Eps_Point epsPoint1 = new Eps_Point();
              Eps_Point epsPoint2 = new Eps_Point();
              epsLeg1 = (Eps_Leg) null;
              int index;
              for (index = 0; index < count; index += 2)
              {
                Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
                if (index > 0)
                {
                  Eps_Leg epsLeg2 = new Eps_Leg();
                  epsLeg2.Line = new Eps_Line();
                  epsLeg2.Line.StartPnt = epsPoint1;
                  epsLeg2.Line.EndPnt = epsPoint3;
                  if (epsLeg1 == null)
                  {
                    epsLeg1 = epsLeg2;
                    epsLeg1.Element = element;
                  }
                  else
                  {
                    epsLeg1.Last.Next = epsLeg2;
                    epsLeg1.Last.Element = element;
                  }
                }
                epsPoint1 = epsPoint3;
              }
              if (index == count)
              {
                Eps_Leg epsLeg3 = new Eps_Leg();
                epsLeg3.Line = new Eps_Line();
                epsLeg3.Line.StartPnt = epsPoint1;
                epsLeg3.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
                if (epsLeg1 == null)
                {
                  epsLeg1 = epsLeg3;
                  epsLeg1.Element = element;
                }
                else
                {
                  epsLeg1.Last.Next = epsLeg3;
                  epsLeg1.Last.Element = element;
                }
              }
            }
            if (RevitDefines.GT(this.m_DisplayForm.StartingDistance, RevitGeometry.eplGeoE_CalcLegListLength(epsLeg1)))
            {
              int num7 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
            if (!PlantCommon.PlaceLegList(this.m_Document, _PlantPlacementSettings, epsLeg1))
              return false;
            break;
          default:
            int num8 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedPlantingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return false;
        }
        if (this.m_DisplayForm.DeleteExistingChecked)
        {
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete(element.Id);
          this.m_TransactionContainer.EndTransaction();
        }
      }
      else if (element.Location is LocationPoint location2)
      {
        PlantCommon.PlaceSingleOnPoint(this.m_Document, _PlantPlacementSettings, element, new Eps_Point(location2.Point));
        if (this.m_DisplayForm.DeleteExistingChecked)
        {
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete(element.Id);
          this.m_TransactionContainer.EndTransaction();
        }
      }
      else
      {
        int num9 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedPlantingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    return true;
  }

  public ReadOnlyCollection<View> Views
  {
    get => new ReadOnlyCollection<View>((IList<View>) this.m_ViewList);
  }

  public Document Document => this.m_Document;

  public ReadOnlyCollection<FamilyContainer> PlantFamilyList
  {
    get => new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_PlantFamilyList);
  }

  public EPTransactionContainer TransactionContainer
  {
    set => this.m_TransactionContainer = value;
    get => this.m_TransactionContainer;
  }

  public List<Element> CurrentElementList => this.m_CurrentElementList;

  public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList
  {
    get
    {
      return new ReadOnlyCollection<TopographySurfaceContainer>((IList<TopographySurfaceContainer>) this.m_SurfaceList);
    }
  }
}
