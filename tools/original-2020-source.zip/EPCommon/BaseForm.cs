﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.BaseForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System.Collections.Generic;
using System.IO;
using System.Threading;

#nullable disable
namespace EPCommon;

public class BaseForm
{
  protected EPTransactionContainer m_TransactionContainer;
  protected EPTransactionContainer m_AdditionalTransactionContainer;
  private Eps_Leg m_CurrentLeg;
  protected Eps_Point m_LegInsertPoint;
  protected Eps_Leg m_MassLeg;
  protected Document m_MassDocument;
  protected Document m_AdditionalMassDocument;
  protected ProgressBarForm m_ProgressBarForm;
  protected double m_dOffsetAdjust = 0.01;
  protected List<IntersectionContainer> m_IntersectionContainers;

  public BaseForm(Eps_Leg _CurrentLeg)
  {
    this.m_CurrentLeg = _CurrentLeg;
    this.m_TransactionContainer = (EPTransactionContainer) null;
    this.m_AdditionalTransactionContainer = (EPTransactionContainer) null;
    this.m_MassDocument = (Document) null;
    this.m_AdditionalMassDocument = (Document) null;
    this.m_MassLeg = (Eps_Leg) null;
    this.m_IntersectionContainers = (List<IntersectionContainer>) null;
  }

  public string CreateForm(Document _ProjectDocument, string _strSiteComponentName)
  {
    string empty = string.Empty;
    return this.CreateForm(_ProjectDocument, _strSiteComponentName, true, 0.0, ref empty);
  }

  public string CreateForm(
    Document _ProjectDocument,
    string _strSiteComponentName,
    ref string _strAdditionalLoftID)
  {
    return this.CreateForm(_ProjectDocument, _strSiteComponentName, true, 0.0, ref _strAdditionalLoftID);
  }

  public string CreateForm(
    Document _ProjectDocument,
    string _strSiteComponentName,
    bool _bUseInternalPoint,
    double _dElevation)
  {
    string empty = string.Empty;
    return this.CreateForm(_ProjectDocument, _strSiteComponentName, _bUseInternalPoint, _dElevation, ref empty);
  }

  public string CreateForm(
    Document _ProjectDocument,
    string _strSiteComponentName,
    bool _bUseInternalPoint,
    double _dElevation,
    ref string _strAdditionalLoftID)
  {
    if (!ApplicationUtility.UseMass)
      return this.CreateElement(_ProjectDocument, _strSiteComponentName, _bUseInternalPoint, _dElevation, ref _strAdditionalLoftID);
    LandcaddID _CurID = LandcaddID.Steps;
    switch (this)
    {
      case SidewalkForm _:
        _CurID = LandcaddID.Sidewalk;
        break;
      case RetainingWallForm _:
        _CurID = LandcaddID.RetainingWall;
        break;
      case CurbForm _:
        _CurID = LandcaddID.Curb;
        break;
      case StreetForm _:
        _CurID = LandcaddID.Street;
        break;
    }
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    _strAdditionalLoftID = string.Empty;
    if (!RevitUtility.FindMassTemplateFileName(_ProjectDocument, _CurID, ref empty1, ref empty2))
      return (string) null;
    if (this.m_CurrentLeg == null)
      return (string) null;
    string tempPath = Path.GetTempPath();
    if (tempPath != string.Empty)
    {
      tempPath += "\\Autodesk\\Site Designer for Revit\\";
      if (!Directory.Exists(tempPath))
        Directory.CreateDirectory(tempPath);
    }
    else
      ApplicationUtility.RegistryPaths.GetSupportPath(string.Empty, ref tempPath);
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    Eps_Point _FirstPnt = new Eps_Point(this.m_CurrentLeg.LegStartPnt);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, new Eps_Point(0.0, 0.0, 0.0), ref _dDistance);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, new Eps_Point(0.0, 0.0, 0.0), ref _dDirection);
    this.m_MassLeg = this.m_CurrentLeg.MoveLeg(_dDirection, _dDistance, -_FirstPnt.z);
    if (this.m_IntersectionContainers != null && this.m_IntersectionContainers.Count > 0)
    {
      Eps_Point _NewPnt = new Eps_Point();
      for (int index1 = 0; index1 < this.m_IntersectionContainers.Count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_IntersectionContainers[index1].Profiles.Count; ++index2)
        {
          for (int index3 = 0; index3 < this.m_IntersectionContainers[index1].Profiles[index2].Points.Count; ++index3)
          {
            EPShared.eplGeoE_CalcPolarToXY(this.m_IntersectionContainers[index1].Profiles[index2].Points[index3], EPShared.eplGeoE_NormalizeRadians(_dDirection), _dDistance, ref _NewPnt);
            _NewPnt.z -= _FirstPnt.z;
            this.m_IntersectionContainers[index1].Profiles[index2].Points[index3] = new Eps_Point(_NewPnt);
          }
        }
        if (this.m_IntersectionContainers[index1].LeftOffsetLeg != null)
          this.m_IntersectionContainers[index1].LeftOffsetLeg = this.m_IntersectionContainers[index1].LeftOffsetLeg.MoveLeg(_dDirection, _dDistance, -_FirstPnt.z);
        if (this.m_IntersectionContainers[index1].RightOffsetLeg != null)
          this.m_IntersectionContainers[index1].RightOffsetLeg = this.m_IntersectionContainers[index1].RightOffsetLeg.MoveLeg(_dDirection, _dDistance, -_FirstPnt.z);
      }
    }
    this.m_MassLeg = this.m_MassLeg.SplitArcsInLeg();
    this.m_MassDocument = _ProjectDocument.Application.NewFamilyDocument(empty1);
    this.m_TransactionContainer = new EPTransactionContainer(this.m_MassDocument);
    this.m_TransactionContainer.Start($"{EPShared.LocalRM.GetString("CreateMassFormTransaction")} {_strSiteComponentName}");
    List<FailureDefinitionId> FailureDefinitionIdList = new List<FailureDefinitionId>();
    FailureDefinitionIdList.Add(BuiltInFailures.InaccurateFailures.InaccurateLine);
    FailureDefinitionIdList.Add(BuiltInFailures.InaccurateFailures.InaccurateMassingSketchLine);
    FailureDefinitionIdList.Add(BuiltInFailures.OverlapFailures.CurvesOverlap);
    FailureDefinitionIdList.Add(BuiltInFailures.JoinElementsFailures.CannotJoinElements);
    FailureDefinitionIdList.Add(BuiltInFailures.MassFailures.CannotMergeGeometry);
    this.m_TransactionContainer.FailureHandlingOptions(FailureDefinitionIdList);
    this.m_TransactionContainer.BeginTransaction();
    this.m_MassDocument.FamilyManager.NewType(_strSiteComponentName);
    List<Form> formList = (List<Form>) null;
    switch (this)
    {
      case SidewalkForm _:
        formList = ((SidewalkForm) this).CreateLoftFormWithParameters();
        break;
      case StreetForm _:
        StreetForm streetForm = (StreetForm) this;
        if (streetForm.StreetFamilySymbol != null)
        {
          Parameter parameter = ((Element) streetForm.StreetFamilySymbol).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
          if (parameter != null && parameter.AsInteger() != 0)
          {
            this.m_AdditionalMassDocument = _ProjectDocument.Application.NewFamilyDocument(empty2);
            this.m_AdditionalTransactionContainer = new EPTransactionContainer(this.m_AdditionalMassDocument);
            this.m_AdditionalTransactionContainer.Start($"{EPShared.LocalRM.GetString("CreateMassFormTransaction")} {_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}");
            this.m_AdditionalTransactionContainer.FailureHandlingOptions(FailureDefinitionIdList);
            this.m_AdditionalTransactionContainer.BeginTransaction();
            this.m_AdditionalMassDocument.FamilyManager.NewType($"{_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}");
          }
        }
        formList = streetForm.CreateLoftFormWithParameters();
        break;
      case RetainingWallForm _:
        formList = ((RetainingWallForm) this).CreateLoftFormWithParameters();
        break;
      case CurbForm _:
        formList = ((CurbForm) this).CreateLoftFormWithParameters(0.0, _dElevation, _bUseInternalPoint);
        break;
    }
    this.m_TransactionContainer.EndTransaction();
    if (this.m_AdditionalTransactionContainer != null)
      this.m_AdditionalTransactionContainer.EndTransaction();
    if (formList == null || formList.Count == 0)
    {
      this.m_TransactionContainer.Rollback();
      if (this.m_AdditionalTransactionContainer != null)
        this.m_AdditionalTransactionContainer.Rollback();
      return string.Empty;
    }
    this.m_TransactionContainer.Commit();
    if (this.m_AdditionalTransactionContainer != null)
      this.m_AdditionalTransactionContainer.Commit();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 10;
    switch (this)
    {
      case SidewalkForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingSidewalkMassMessage");
        break;
      case RetainingWallForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingRetainingWallMassMessage");
        break;
      case StreetForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingStreetMassMessage");
        break;
      case CurbForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingCurbMassMessage");
        break;
    }
    this.m_MassDocument.SaveAs(Path.Combine(tempPath, _strSiteComponentName + ".rfa"), new SaveAsOptions()
    {
      OverwriteExistingFile = true
    });
    this.m_MassDocument.Close(false);
    if (this.m_AdditionalMassDocument != null)
    {
      this.m_AdditionalMassDocument.SaveAs(Path.Combine(tempPath, $"{_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}.rfa"), new SaveAsOptions()
      {
        OverwriteExistingFile = true
      });
      this.m_AdditionalMassDocument.Close(false);
    }
    this.m_ProgressBarForm.UpdateProgressBar(1);
    FamilySymbol _FamilySymbol1 = (FamilySymbol) null;
    FamilySymbol _FamilySymbol2 = (FamilySymbol) null;
    RevitUtility.LoadFamilySymbol(_ProjectDocument, Path.Combine(tempPath, _strSiteComponentName + ".rfa"), _strSiteComponentName, out _FamilySymbol1, true, ref this.m_TransactionContainer);
    if (this.m_AdditionalMassDocument != null)
      RevitUtility.LoadFamilySymbol(_ProjectDocument, Path.Combine(tempPath, $"{_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}.rfa"), $"{_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}", out _FamilySymbol2, true, ref this.m_TransactionContainer);
    this.m_ProgressBarForm.UpdateProgressBar(6);
    FamilyInstance familyInstance1 = RevitUtility.NewFamilyInstance(_ProjectDocument, _FirstPnt.XYZ, _FamilySymbol1, (Element) null, _ProjectDocument.ActiveView.GenLevel, (StructuralType) 0, ref this.m_TransactionContainer);
    string uniqueId = ((Element) familyInstance1).UniqueId;
    FamilyInstance familyInstance2 = (FamilyInstance) null;
    if (_FamilySymbol2 != null)
    {
      familyInstance2 = RevitUtility.NewFamilyInstance(_ProjectDocument, _FirstPnt.XYZ, _FamilySymbol2, (Element) null, _ProjectDocument.ActiveView.GenLevel, (StructuralType) 0, ref this.m_TransactionContainer);
      _strAdditionalLoftID = ((Element) familyInstance2).UniqueId;
    }
    this.m_ProgressBarForm.UpdateProgressBar(1);
    switch (this)
    {
      case SidewalkForm _:
        Parameter parameter1 = ((Element) familyInstance1).LookupParameter(RevitParameters.SideWalkPavementSurfaceParameter);
        if (parameter1 != null)
        {
          Parameter parameter2 = ((Element) ((SidewalkForm) this).SidewalkFamilySymbol).LookupParameter(RevitParameters.SideWalkPavementSurfaceParameter);
          if (parameter2 != null)
          {
            int num = parameter2.AsInteger();
            parameter1.Set(new ElementId(num));
            break;
          }
          break;
        }
        break;
      case RetainingWallForm _:
        Parameter parameter3 = ((Element) familyInstance1).LookupParameter(RevitParameters.RetainingWallMaterialParameter);
        if (parameter3 != null)
        {
          Parameter parameter4 = ((Element) ((RetainingWallForm) this).RetainingWallFamilySymbol).LookupParameter(RevitParameters.RetainingWallMaterialParameter);
          if (parameter4 != null)
          {
            int num = parameter4.AsInteger();
            parameter3.Set(new ElementId(num));
            break;
          }
          break;
        }
        break;
      case StreetForm _:
        Parameter parameter5 = ((Element) familyInstance1).LookupParameter(RevitParameters.StreetPavementSurfaceParameter);
        if (parameter5 != null)
        {
          Parameter parameter6 = ((Element) ((StreetForm) this).StreetFamilySymbol).LookupParameter(RevitParameters.StreetPavementSurfaceParameter);
          if (parameter6 != null)
          {
            int num = parameter6.AsInteger();
            parameter5.Set(new ElementId(num));
          }
        }
        if (familyInstance2 != null)
        {
          Parameter parameter7 = ((Element) familyInstance2).LookupParameter(RevitParameters.StreetCurbMaterialParameter);
          if (parameter7 != null)
          {
            Parameter parameter8 = ((Element) ((StreetForm) this).StreetFamilySymbol).LookupParameter(RevitParameters.StreetCurbMaterialParameter);
            if (parameter8 != null)
            {
              int num = parameter8.AsInteger();
              parameter7.Set(new ElementId(num));
              break;
            }
            break;
          }
          break;
        }
        break;
      case CurbForm _:
        Parameter parameter9 = ((Element) familyInstance1).LookupParameter(RevitParameters.StreetCurbMaterialParameter);
        if (parameter9 != null)
        {
          Parameter parameter10 = ((Element) ((CurbForm) this).CurbFamilySymbol).LookupParameter(RevitParameters.StreetCurbMaterialParameter);
          if (parameter10 != null)
          {
            int num = parameter10.AsInteger();
            parameter9.Set(new ElementId(num));
            break;
          }
          break;
        }
        break;
    }
    this.m_ProgressBarForm.UpdateProgressBar(1);
    File.Delete(Path.Combine(tempPath, _strSiteComponentName + ".rfa"));
    if (this.m_AdditionalMassDocument != null)
      File.Delete(Path.Combine(tempPath, $"{_strSiteComponentName} {EPShared.LocalRM.GetString("StreetCurbDisplayParameter")}.rfa"));
    DirectoryInfo directoryInfo = new DirectoryInfo(tempPath);
    if (Directory.Exists(tempPath))
    {
      foreach (FileSystemInfo file in directoryInfo.GetFiles("*.rfa"))
        file.Delete();
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return uniqueId;
  }

  public string CreateElement(
    Document _ProjectDocument,
    string _strSiteComponentName,
    bool _bUseInternalPoint,
    double _dElevation,
    ref string _strAdditionalLoftID)
  {
    string empty = string.Empty;
    _strAdditionalLoftID = string.Empty;
    if (this.m_CurrentLeg == null)
      return string.Empty;
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    this.m_LegInsertPoint = new Eps_Point(this.m_CurrentLeg.LegStartPnt);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(this.m_LegInsertPoint, new Eps_Point(0.0, 0.0, 0.0), ref _dDistance);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(this.m_LegInsertPoint, new Eps_Point(0.0, 0.0, 0.0), ref _dDirection);
    this.m_MassLeg = this.m_CurrentLeg.MoveLeg(_dDirection, _dDistance, -this.m_LegInsertPoint.z);
    if (this.m_IntersectionContainers != null && this.m_IntersectionContainers.Count > 0)
    {
      Eps_Point _NewPnt = new Eps_Point();
      for (int index1 = 0; index1 < this.m_IntersectionContainers.Count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_IntersectionContainers[index1].Profiles.Count; ++index2)
        {
          for (int index3 = 0; index3 < this.m_IntersectionContainers[index1].Profiles[index2].Points.Count; ++index3)
          {
            EPShared.eplGeoE_CalcPolarToXY(this.m_IntersectionContainers[index1].Profiles[index2].Points[index3], EPShared.eplGeoE_NormalizeRadians(_dDirection), _dDistance, ref _NewPnt);
            _NewPnt.z -= this.m_LegInsertPoint.z;
            this.m_IntersectionContainers[index1].Profiles[index2].Points[index3] = new Eps_Point(_NewPnt);
          }
        }
        if (this.m_IntersectionContainers[index1].LeftOffsetLeg != null)
          this.m_IntersectionContainers[index1].LeftOffsetLeg = this.m_IntersectionContainers[index1].LeftOffsetLeg.MoveLeg(_dDirection, _dDistance, -this.m_LegInsertPoint.z);
        if (this.m_IntersectionContainers[index1].RightOffsetLeg != null)
          this.m_IntersectionContainers[index1].RightOffsetLeg = this.m_IntersectionContainers[index1].RightOffsetLeg.MoveLeg(_dDirection, _dDistance, -this.m_LegInsertPoint.z);
      }
    }
    this.m_MassLeg = this.m_MassLeg.SplitArcsInLeg();
    string element = this.CreateElement(_ProjectDocument, ref _strAdditionalLoftID, _strSiteComponentName, 0.0, _dElevation, _bUseInternalPoint);
    if (element == null || element == string.Empty)
      return element;
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 10;
    switch (this)
    {
      case SidewalkForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingSidewalkMassMessage");
        break;
      case RetainingWallForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingRetainingWallMassMessage");
        break;
      case StreetForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingStreetMassMessage");
        break;
      case CurbForm _:
        this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingCurbMassMessage");
        break;
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return element;
  }

  public virtual string CreateElement(
    Document doc,
    ref string _strAdditionalLoftID,
    string _strSiteComponentName,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseInternalPoint)
  {
    return (string) null;
  }

  protected ReferenceArray ApplyReferenceArrayProfile(List<Eps_Point> _PointList)
  {
    ReferenceArray referenceArray = new ReferenceArray();
    CurveArray curveArray = new CurveArray();
    for (int index1 = 0; index1 < _PointList.Count; ++index1)
    {
      int index2 = index1 != _PointList.Count - 1 ? index1 + 1 : 0;
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index1], _PointList[index2], 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(_PointList[index1].XYZ, _PointList[index2].XYZ, true);
        curveArray.Append((Curve) line);
      }
    }
    CurveLoop curveLoop = new CurveLoop();
    foreach (Curve curve in curveArray)
      curveLoop.Append(curve);
    SketchPlane sketchPlane = SketchPlane.Create(this.m_MassDocument, curveLoop.GetPlane());
    foreach (Curve curve in curveArray)
    {
      ModelCurve modelCurve = ((ItemFactoryBase) this.m_MassDocument.FamilyCreate).NewModelCurve(curve, sketchPlane);
      referenceArray.Append(((CurveElement) modelCurve).GeometryCurve.Reference);
    }
    return referenceArray;
  }

  protected CurveLoop ApplyCurveLoopProfile(List<Eps_Point> _PointList)
  {
    CurveArray curveArray = new CurveArray();
    for (int index1 = 0; index1 < _PointList.Count; ++index1)
    {
      int index2 = index1 != _PointList.Count - 1 ? index1 + 1 : 0;
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index1], _PointList[index2], 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(_PointList[index1].XYZ, _PointList[index2].XYZ, true);
        curveArray.Append((Curve) line);
      }
    }
    CurveLoop curveLoop = new CurveLoop();
    foreach (Curve curve in curveArray)
      curveLoop.Append(curve);
    return curveLoop;
  }

  protected ReferenceArray ApplyReferenceArrayProfileAdjustingStation(
    double _dStation,
    List<Eps_Point> _PointList)
  {
    ReferenceArray referenceArray = new ReferenceArray();
    CurveArray curveArray = new CurveArray();
    double _dStation1 = 0.0;
    double _dOffset = 0.0;
    Eps_Point epsPoint = new Eps_Point();
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    epsPointList.AddRange((IEnumerable<Eps_Point>) _PointList);
    for (int index = 0; index < epsPointList.Count; ++index)
    {
      double z = epsPointList[index].z;
      RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsPointList[index], this.m_MassLeg, ref _dStation1, ref _dOffset);
      Eps_Point Pnt = new Eps_Point();
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation1 + _dStation, _dOffset, ref Pnt);
      epsPointList[index] = Pnt;
      epsPointList[index].z = z;
    }
    for (int index1 = 0; index1 < epsPointList.Count; ++index1)
    {
      int index2 = index1 != _PointList.Count - 1 ? index1 + 1 : 0;
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPointList[index1], epsPointList[index2], 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPointList[index1].XYZ, epsPointList[index2].XYZ, true);
        curveArray.Append((Curve) line);
      }
    }
    CurveLoop curveLoop = new CurveLoop();
    foreach (Curve curve in curveArray)
      curveLoop.Append(curve);
    SketchPlane sketchPlane = SketchPlane.Create(this.m_MassDocument, curveLoop.GetPlane());
    foreach (Curve curve in curveArray)
    {
      ModelCurve modelCurve = ((ItemFactoryBase) this.m_MassDocument.FamilyCreate).NewModelCurve(curve, sketchPlane);
      referenceArray.Append(((CurveElement) modelCurve).GeometryCurve.Reference);
    }
    return referenceArray;
  }

  public Eps_Leg CurrentLeg
  {
    get => this.m_CurrentLeg;
    set => this.m_CurrentLeg = value;
  }

  public Eps_Leg MassLeg
  {
    get => this.m_MassLeg;
    set => this.m_MassLeg = value;
  }

  public Document MassDocument
  {
    get => this.m_MassDocument;
    set => this.m_MassDocument = value;
  }

  public List<IntersectionContainer> IntersectionContainers
  {
    get => this.m_IntersectionContainers;
    set => this.m_IntersectionContainers = value;
  }
}
