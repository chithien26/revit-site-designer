﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyInstancePointComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FamilyInstancePointComparer : IComparer<FamilyInstance>
{
  private XYZ m_QueryPoint;

  public FamilyInstancePointComparer(XYZ _QueryPoint) => this.m_QueryPoint = _QueryPoint;

  int IComparer<FamilyInstance>.Compare(FamilyInstance first, FamilyInstance second)
  {
    int num = 0;
    if (first != null && ((Element) first).Location != null)
    {
      if (((Element) first).Location is LocationPoint location2 && second != null && ((Element) second).Location != null)
      {
        if (((Element) second).Location is LocationPoint location1)
          num = Math.Sqrt(Math.Pow(this.m_QueryPoint.X - location2.Point.X, 2.0) + Math.Pow(this.m_QueryPoint.Y - location2.Point.Y, 2.0)).CompareTo(Math.Sqrt(Math.Pow(this.m_QueryPoint.X - location1.Point.X, 2.0) + Math.Pow(this.m_QueryPoint.Y - location1.Point.Y, 2.0)));
      }
      else
        num = -1;
    }
    else if (second != null && ((Element) second).Location != null)
      num = 1;
    return num;
  }
}
