﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Annotation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class Annotation
{
  private Document m_Document;
  private EPTransactionContainer m_TransactionContainer;
  private List<FamilyInstanceComponentWrapper> m_AllSiteComponentList;
  private FamilyInstance m_TopoPlacementFamilyInstance;
  private ElementSet m_LineElementSet;
  private AnnotateForm m_DisplayForm;
  private TopographySurfaceContainer m_BaseSurface;
  private TopographySurfaceContainer m_ProposedSurface;

  public Annotation(Document _CurDocument)
  {
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_AllSiteComponentList = new List<FamilyInstanceComponentWrapper>();
    this.m_LineElementSet = new ElementSet();
    this.m_TopoPlacementFamilyInstance = (FamilyInstance) null;
    this.m_DisplayForm = (AnnotateForm) null;
    this.m_BaseSurface = (TopographySurfaceContainer) null;
    this.m_ProposedSurface = (TopographySurfaceContainer) null;
    this.InitializeData();
  }

  private void InitializeData()
  {
    FamilyInstance _BasePlacementFamilyInstance = (FamilyInstance) null;
    TopographySurfaceManagement.FindBaseLandcaddTopographySurface(this.m_Document, ref this.m_BaseSurface, ref _BasePlacementFamilyInstance, ref this.m_ProposedSurface, ref this.m_TopoPlacementFamilyInstance);
    if (this.m_BaseSurface == null || this.m_ProposedSurface == null)
      return;
    FindFamilyInstance = (FamilyInstance) null;
    Parameter LandcaddIDParameter = (Parameter) null;
    Parameter LocateTypeParameter = (Parameter) null;
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (LandcaddIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && (LocateTypeParameter = ((Element) FindFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter)) != null && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    IList<Element> elements = new FilteredElementCollector(this.m_Document).OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051).ToElements();
    bool flag = false;
    foreach (Element element in list)
    {
      if (element is FamilyInstance _FamilyInstance && ((Element) _FamilyInstance).Category != null)
      {
        int integerValue1 = ((Element) _FamilyInstance).Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001260;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1)
        {
          LandcaddIDParameter = ((Element) _FamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
          if (LandcaddIDParameter != null)
          {
            LocateTypeParameter = ((Element) _FamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (LocateTypeParameter != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
            {
              Parameter parameter1 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
              if (parameter1 != null)
              {
                Parameter parameter2 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
                if (parameter2 != null && parameter2.AsString() != string.Empty)
                {
                  for (int index1 = 0; index1 < elements.Count; ++index1)
                  {
                    Element _Element = elements[index1];
                    if (_Element != null && _Element.Category != null)
                    {
                      int integerValue2 = _Element.Category.Id.IntegerValue;
                      builtInCategory = (BuiltInCategory) -2000051;
                      int hashCode2 = builtInCategory.GetHashCode();
                      if (integerValue2 == hashCode2 && string.Compare(parameter1.AsString(), _Element.UniqueId, true) == 0)
                      {
                        for (int index2 = 0; index2 < this.m_AllSiteComponentList.Count; ++index2)
                        {
                          if (string.Compare(parameter2.AsString(), this.m_AllSiteComponentList[index2].ChainID, true) == 0)
                          {
                            flag = true;
                            this.m_AllSiteComponentList[index2].FamilyContainerList.Add(new FamilyInstanceComponentContainer(_Element, _FamilyInstance));
                            break;
                          }
                        }
                        if (!flag)
                        {
                          new List<FamilyInstanceComponentContainer>()
                          {
                            new FamilyInstanceComponentContainer(_Element, _FamilyInstance)
                          };
                          int _nDrawOrder = 0;
                          Parameter parameter3 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
                          if (parameter3 != null)
                            _nDrawOrder = parameter3.AsInteger();
                          this.m_AllSiteComponentList.Add(new FamilyInstanceComponentWrapper(parameter2.AsString(), new List<FamilyInstanceComponentContainer>()
                          {
                            new FamilyInstanceComponentContainer(_Element, _FamilyInstance)
                          }, _nDrawOrder));
                        }
                        else
                          flag = false;
                        elements.RemoveAt(index1);
                        break;
                      }
                    }
                  }
                  if (elements.Count == 0)
                    break;
                }
              }
            }
          }
        }
      }
    }
    for (int index = 0; index < elements.Count; ++index)
    {
      Element element = elements[index];
      if (element != null && element.Category != null && element.Category.Id.IntegerValue == ((BuiltInCategory) -2000051).GetHashCode() && !element.IsHidden(this.m_Document.ActiveView))
        this.m_LineElementSet.Insert(element);
    }
  }

  public void Run()
  {
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("AnnotateSiteComponentTransaction"));
    if (this.m_BaseSurface == null || this.m_ProposedSurface == null)
    {
      if (RevitUtility.RemoveAllSiteComponents(this.m_Document, this.m_TransactionContainer))
        this.m_TransactionContainer.Commit();
      else
        this.m_TransactionContainer.Rollback();
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoToposurfaceCanBeModifiedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    else if (this.DisplayUI())
    {
      if (this.PromptPick())
      {
        if (this.m_LineElementSet != null && this.m_LineElementSet.Size > 0)
          this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_LineElementSet));
        this.HideSiteAlignmentLines();
        this.m_TransactionContainer.Commit();
      }
      else
        this.m_TransactionContainer.Rollback();
    }
    else
      this.m_TransactionContainer.Rollback();
  }

  private bool DisplayUI()
  {
    bool flag = false;
    using (this.m_DisplayForm = new AnnotateForm(this))
    {
      if (this.m_DisplayForm.ShowDialog() == DialogResult.OK)
        flag = true;
    }
    return flag;
  }

  private bool PromptPick()
  {
    if (this.m_LineElementSet != null && this.m_LineElementSet.Size > 0)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_LineElementSet));
      this.m_TransactionContainer.EndTransaction();
    }
    if (this.m_AllSiteComponentList != null && this.m_AllSiteComponentList.Count > 0)
    {
      this.DisplaySiteAlignmentLines();
      this.m_Document.Regenerate();
      if (!this.PickSiteAlignmentElement())
        return false;
      this.m_Document.Regenerate();
      return true;
    }
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RunLocateSiteComponentsMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    return false;
  }

  private void DisplaySiteAlignmentLines()
  {
    if (this.m_AllSiteComponentList == null)
      return;
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AllSiteComponentList[index].GetOriginalElementSet()));
      this.m_TransactionContainer.EndTransaction();
    }
  }

  private void HideSiteAlignmentLines()
  {
    if (this.m_AllSiteComponentList == null)
      return;
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AllSiteComponentList[index].GetOriginalElementSet()));
      this.m_TransactionContainer.EndTransaction();
    }
  }

  private bool PickSiteAlignmentElement()
  {
    bool flag = false;
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
    {
      this.RemoveSiteAlignmentLines(string.Empty);
      return false;
    }
    foreach (Element element1 in _Elements)
    {
      for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
      {
        if (this.m_AllSiteComponentList[index].IndexOfOriginalElementID(element1.Id) >= 0)
        {
          flag = true;
          TopographySurfaceContainer _Surface = (TopographySurfaceContainer) null;
          LandcaddID landcaddId = LandcaddID.SoftTerrain;
          ElementSet instanceElementSet = this.m_AllSiteComponentList[index].GetFamilyInstanceElementSet();
          if (instanceElementSet != null && instanceElementSet.Size > 0)
          {
            string _strFormUniqueId = string.Empty;
            foreach (Element element2 in instanceElementSet)
            {
              Parameter parameter1 = element2.LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
              if (parameter1 != null)
              {
                foreach (int num in Enum.GetValues(typeof (LandcaddID)))
                {
                  if (string.Compare(parameter1.AsString(), num.ToString("000"), true) == 0)
                  {
                    landcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
                    break;
                  }
                }
              }
              if (landcaddId == LandcaddID.ParkingLot)
              {
                Parameter parameter2 = element2.LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
                if (parameter2 != null)
                {
                  _strFormUniqueId = parameter2.AsString();
                  break;
                }
              }
              else
                break;
            }
            TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(this.m_Document, _strFormUniqueId);
            if (topoSurfaceInstance != null)
              _Surface = new TopographySurfaceContainer(this.m_Document.Application, topoSurfaceInstance, true);
          }
          this.m_AllSiteComponentList[index].ParkingLotTopographySurface = _Surface;
          if (_Surface == null)
            _Surface = this.m_ProposedSurface;
          this.m_AllSiteComponentList[index].CreateProposedLeg(_Surface);
          if (this.m_AllSiteComponentList[index].ProposedLeg != null)
          {
            ElementSet _ElevationText = new ElementSet();
            ElementSet _GradeText = new ElementSet();
            RevitUtility.AnnotateGradeAndElevationOnLegList(this.m_Document, this.m_TransactionContainer, this.m_AllSiteComponentList[index], this.m_DisplayForm.AnnotateElevations, this.m_DisplayForm.AnnotateGrades, false, this.m_DisplayForm.TextNoteType, ref _ElevationText, ref _GradeText, true);
            break;
          }
          break;
        }
      }
      if (!flag)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NotSiteComponentHostLineMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.RemoveSiteAlignmentLines(string.Empty);
        return false;
      }
    }
    return true;
  }

  private void RemoveSiteAlignmentLines(string _strIgnoreSiteID)
  {
    if (this.m_AllSiteComponentList == null)
      return;
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      if (string.Compare(this.m_AllSiteComponentList[index].ChainID, _strIgnoreSiteID, true) != 0 && this.m_AllSiteComponentList[index].ProposedLeg != null && this.m_AllSiteComponentList[index].ProposedElementSet != null)
      {
        this.m_TransactionContainer.BeginTransaction();
        this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(this.m_AllSiteComponentList[index].ProposedElementSet));
        this.m_TransactionContainer.EndTransaction();
        this.m_AllSiteComponentList[index].ProposedLeg = (Eps_Leg) null;
        this.m_AllSiteComponentList[index].ProposedElementSet = (ElementSet) null;
      }
    }
  }

  public Document Document => this.m_Document;

  public ReadOnlyCollection<TextNoteType> TextTypeList
  {
    get
    {
      List<TextNoteType> list = new List<TextNoteType>();
      foreach (TextNoteType textNoteType in (IEnumerable<Element>) ((IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (TextNoteType))).ToList<Element>())
        list.Add(textNoteType);
      return new ReadOnlyCollection<TextNoteType>((IList<TextNoteType>) list);
    }
  }
}
