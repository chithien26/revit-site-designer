using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using SITES.Sites_Core;

namespace EPCommon;

public class PlantMixForm : EPForm
{
	private bool m_bApply;

	private string m_strCurrentInstance = string.Empty;

	private ReadOnlyCollection<FamilySymbol> m_ListOfPlantMixInstances;

	private string m_strSetttingName = string.Empty;

	private CreatePlantMix m_dataBuffer;

	private IContainer components;

	private Button m_OKButton;

	private Button m_CancelButton;

	private Button m_ApplyButton;

	private ComboBox m_PlantMixComboBox;

	private Label m_FamilyLabel;

	private TextBox m_RegionName;

	private Label m_RegionNameLabel;

	private RadioButton m_UnassignRadioButton;

	private RadioButton m_AssignRadioButton;

	private Button m_LoadFamilyButton;

	private Button m_FamilyManagerButton;

	public bool AssignRegion => m_AssignRadioButton.Checked;

	public string RegionName => m_RegionName.Text;

	public bool ApplyStatus => m_bApply;

	public FamilySymbol SelectedFamilySymbol
	{
		get
		{
			if (m_PlantMixComboBox.SelectedIndex < m_ListOfPlantMixInstances.Count)
			{
				return m_ListOfPlantMixInstances[m_PlantMixComboBox.SelectedIndex];
			}
			return null;
		}
	}

	public PlantMixForm(CreatePlantMix _dataBuffer)
	{
		InitializeComponent();
		EPToolTip.SetToolTip(m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		m_dataBuffer = _dataBuffer;
		if (m_dataBuffer.CreateDialogType == CreateDialogType.PlantMix)
		{
			m_FamilyManagerButton.Image = Resources.PlantMixManager;
			EPToolTip.SetToolTip(m_FamilyManagerButton, EPShared.LocalRM.GetString("PlantMixFamilyManagerRibbonButton"));
		}
		else
		{
			m_FamilyManagerButton.Image = Resources.PatioWalkManager;
			EPToolTip.SetToolTip(m_FamilyManagerButton, EPShared.LocalRM.GetString("PatioWalkFamilyManagerRibbonButton"));
		}
		Text = m_dataBuffer.FormText;
		m_FamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
		m_RegionNameLabel.Text = EPShared.LocalRM.GetString("AMP_RegionNameDialog");
		m_AssignRadioButton.Text = EPShared.LocalRM.GetString("AssignDialog");
		m_UnassignRadioButton.Text = EPShared.LocalRM.GetString("UnassignDialog");
		m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
		m_strSetttingName = Enum.GetName(typeof(CreateDialogType), m_dataBuffer.CreateDialogType.GetHashCode()).ToUpper();
		GetSettings();
		m_ListOfPlantMixInstances = m_dataBuffer.PlantMixFamilyList;
		if (m_ListOfPlantMixInstances.Count > 0)
		{
			for (int i = 0; i < m_ListOfPlantMixInstances.Count; i++)
			{
				if (!m_PlantMixComboBox.Items.Contains(m_ListOfPlantMixInstances[i].Family.Name))
				{
					m_PlantMixComboBox.Items.Add(m_ListOfPlantMixInstances[i].Family.Name);
				}
			}
		}
		int num = m_PlantMixComboBox.FindString(m_strCurrentInstance);
		if (num >= 0)
		{
			m_PlantMixComboBox.SelectedIndex = num;
		}
	}

	private void GetSettings()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, m_strSetttingName + "PickCurrentInstance", ref m_strCurrentInstance);
		m_AssignRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSetttingName + "AssignOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_AssignRadioButton.Checked = true;
			}
			else
			{
				m_UnassignRadioButton.Checked = true;
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSetttingName + "PickCurrentType", ref _strReturnValue))
		{
			m_RegionName.Text = _strReturnValue;
		}
	}

	private void SaveSettings()
	{
		if (m_PlantMixComboBox.SelectedIndex < m_ListOfPlantMixInstances.Count)
		{
			string name = m_ListOfPlantMixInstances[m_PlantMixComboBox.SelectedIndex].Family.Name;
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, m_strSetttingName + "PickCurrentInstance", name);
		}
		int num = 0;
		num = ((!m_AssignRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_strSetttingName + "AssignOption", num);
		if (m_RegionName.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_strSetttingName + "PickCurrentType", m_RegionName.Text);
		}
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		m_bApply = false;
		SaveSettings();
		DialogResult = DialogResult.OK;
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		m_bApply = false;
		DialogResult = DialogResult.Cancel;
	}

	private void OnApplyButtonClick(object sender, EventArgs e)
	{
		m_bApply = true;
		SaveSettings();
		DialogResult = DialogResult.OK;
	}

	private void OnAssignPlantMixFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnLoadFamilyButtonClick(object sender, EventArgs e)
	{
		int count = m_PlantMixComboBox.Items.Count;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		Family _Family = null;
		openFileDialog.Title = EPShared.LocalRM.GetString("Select__String") + m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("__GenericModelFamilyString");
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult == DialogResult.Cancel)
			{
				continue;
			}
			try
			{
				if (m_dataBuffer.CreateDialogType == CreateDialogType.PlantMix)
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantMixFamilyTransaction") + openFileDialog.SafeFileName);
				}
				else
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPatioWalkFamilyTransaction") + openFileDialog.SafeFileName);
				}
				EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
				flag = RevitUtility.LoadFamily(m_dataBuffer.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
				m_dataBuffer.TransactionContainer = _TransactionContainer;
				m_dataBuffer.TransactionContainer.Commit();
			}
			catch (SEHException ex)
			{
				flag = false;
				if (string.Compare(ex.Message, EPShared.LocalRM.GetString("ExternalComponentExceptionMessage"), ignoreCase: true) == 0)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyCannotbeLoadedPickanother_Message") + m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("GenericModelLandcaddID_String") + m_dataBuffer.LandcaddIDValue + EPShared.LocalRM.GetString("_TypeParameterString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				}
				continue;
			}
			break;
		}
		if (!flag)
		{
			if (count == 0)
			{
				RevitMessageBox.Show(m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("GenericModelLandcaddID_String") + m_dataBuffer.LandcaddIDValue + EPShared.LocalRM.GetString("_TypeParameterPFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_dataBuffer.PopulateFamilySymbolList();
		m_PlantMixComboBox.Items.Clear();
		m_ListOfPlantMixInstances = m_dataBuffer.PlantMixFamilyList;
		if (m_ListOfPlantMixInstances.Count > 0)
		{
			for (int i = 0; i < m_ListOfPlantMixInstances.Count; i++)
			{
				if (!m_PlantMixComboBox.Items.Contains(m_ListOfPlantMixInstances[i].Family.Name))
				{
					m_PlantMixComboBox.Items.Add(m_ListOfPlantMixInstances[i].Family.Name);
					if (_Family != null && string.Compare(m_ListOfPlantMixInstances[i].Family.Name, _Family.Name, ignoreCase: true) == 0)
					{
						m_PlantMixComboBox.SelectedIndex = i;
					}
				}
			}
			m_PlantMixComboBox.SelectedIndex = 0;
		}
		if (m_PlantMixComboBox.Items.Count == count)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyLoadedNotA_Message") + m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("GenericModelLandcaddID_String") + m_dataBuffer.LandcaddIDValue + EPShared.LocalRM.GetString("_TypeParameterString"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	private void OnFamilyManagerButtonClick(object sender, EventArgs e)
	{
		DialogType type = DialogType.PlantMix;
		if (m_dataBuffer.CreateDialogType == CreateDialogType.PatioWalk)
		{
			type = DialogType.Patio;
		}
		using PlantMixFamilyManager plantMixFamilyManager = new PlantMixFamilyManager(type, m_dataBuffer.Document);
		plantMixFamilyManager.ShowDialog();
		m_dataBuffer.PopulateFamilySymbolList();
		m_ListOfPlantMixInstances = m_dataBuffer.PlantMixFamilyList;
		if (m_ListOfPlantMixInstances.Count <= 0)
		{
			return;
		}
		for (int i = 0; i < m_ListOfPlantMixInstances.Count; i++)
		{
			if (!m_PlantMixComboBox.Items.Contains(m_ListOfPlantMixInstances[i].Family.Name))
			{
				m_PlantMixComboBox.Items.Add(m_ListOfPlantMixInstances[i].Family.Name);
				m_PlantMixComboBox.SelectedIndex = i;
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_OKButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_ApplyButton = new System.Windows.Forms.Button();
		this.m_PlantMixComboBox = new System.Windows.Forms.ComboBox();
		this.m_FamilyLabel = new System.Windows.Forms.Label();
		this.m_RegionName = new System.Windows.Forms.TextBox();
		this.m_RegionNameLabel = new System.Windows.Forms.Label();
		this.m_UnassignRadioButton = new System.Windows.Forms.RadioButton();
		this.m_AssignRadioButton = new System.Windows.Forms.RadioButton();
		this.m_LoadFamilyButton = new System.Windows.Forms.Button();
		this.m_FamilyManagerButton = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.m_OKButton.Location = new System.Drawing.Point(147, 91);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 8;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_CancelButton.Location = new System.Drawing.Point(228, 91);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 9;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_ApplyButton.Location = new System.Drawing.Point(310, 91);
		this.m_ApplyButton.Name = "m_ApplyButton";
		this.m_ApplyButton.Size = new System.Drawing.Size(75, 23);
		this.m_ApplyButton.TabIndex = 10;
		this.m_ApplyButton.Text = "&Apply";
		this.m_ApplyButton.UseVisualStyleBackColor = true;
		this.m_ApplyButton.Click += new System.EventHandler(this.OnApplyButtonClick);
		this.m_PlantMixComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantMixComboBox.FormattingEnabled = true;
		this.m_PlantMixComboBox.Location = new System.Drawing.Point(110, 12);
		this.m_PlantMixComboBox.Name = "m_PlantMixComboBox";
		this.m_PlantMixComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_PlantMixComboBox.TabIndex = 1;
		this.m_FamilyLabel.AutoSize = true;
		this.m_FamilyLabel.Location = new System.Drawing.Point(12, 15);
		this.m_FamilyLabel.Name = "m_FamilyLabel";
		this.m_FamilyLabel.Size = new System.Drawing.Size(39, 13);
		this.m_FamilyLabel.TabIndex = 0;
		this.m_FamilyLabel.Text = "&Family:";
		this.m_RegionName.Location = new System.Drawing.Point(110, 39);
		this.m_RegionName.Name = "m_RegionName";
		this.m_RegionName.Size = new System.Drawing.Size(215, 20);
		this.m_RegionName.TabIndex = 5;
		this.m_RegionNameLabel.AutoSize = true;
		this.m_RegionNameLabel.Location = new System.Drawing.Point(12, 42);
		this.m_RegionNameLabel.Name = "m_RegionNameLabel";
		this.m_RegionNameLabel.Size = new System.Drawing.Size(78, 13);
		this.m_RegionNameLabel.TabIndex = 4;
		this.m_RegionNameLabel.Text = "&Region Name :";
		this.m_UnassignRadioButton.AutoSize = true;
		this.m_UnassignRadioButton.Location = new System.Drawing.Point(110, 65);
		this.m_UnassignRadioButton.Name = "m_UnassignRadioButton";
		this.m_UnassignRadioButton.Size = new System.Drawing.Size(69, 17);
		this.m_UnassignRadioButton.TabIndex = 7;
		this.m_UnassignRadioButton.TabStop = true;
		this.m_UnassignRadioButton.Text = "&Unassign";
		this.m_UnassignRadioButton.UseVisualStyleBackColor = true;
		this.m_AssignRadioButton.AutoSize = true;
		this.m_AssignRadioButton.Location = new System.Drawing.Point(15, 65);
		this.m_AssignRadioButton.Name = "m_AssignRadioButton";
		this.m_AssignRadioButton.Size = new System.Drawing.Size(56, 17);
		this.m_AssignRadioButton.TabIndex = 6;
		this.m_AssignRadioButton.TabStop = true;
		this.m_AssignRadioButton.Text = "A&ssign";
		this.m_AssignRadioButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Location = new System.Drawing.Point(331, 12);
		this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
		this.m_LoadFamilyButton.Size = new System.Drawing.Size(24, 21);
		this.m_LoadFamilyButton.TabIndex = 2;
		this.m_LoadFamilyButton.TabStop = false;
		this.m_LoadFamilyButton.Text = "...";
		this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Click += new System.EventHandler(this.OnLoadFamilyButtonClick);
		this.m_FamilyManagerButton.Location = new System.Drawing.Point(361, 12);
		this.m_FamilyManagerButton.Name = "m_FamilyManagerButton";
		this.m_FamilyManagerButton.Size = new System.Drawing.Size(23, 21);
		this.m_FamilyManagerButton.TabIndex = 3;
		this.m_FamilyManagerButton.TabStop = false;
		this.m_FamilyManagerButton.UseVisualStyleBackColor = true;
		this.m_FamilyManagerButton.Click += new System.EventHandler(this.OnFamilyManagerButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(397, 126);
		base.Controls.Add(this.m_FamilyManagerButton);
		base.Controls.Add(this.m_LoadFamilyButton);
		base.Controls.Add(this.m_AssignRadioButton);
		base.Controls.Add(this.m_UnassignRadioButton);
		base.Controls.Add(this.m_PlantMixComboBox);
		base.Controls.Add(this.m_FamilyLabel);
		base.Controls.Add(this.m_RegionName);
		base.Controls.Add(this.m_RegionNameLabel);
		base.Controls.Add(this.m_ApplyButton);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_OKButton);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "PlantMixForm";
		this.Text = "Assign Plant Mix";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnAssignPlantMixFormClosing);
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_ApplyButton;
		base.CancelButton = this.m_CancelButton;
	}
}
