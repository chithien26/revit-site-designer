﻿// Decompiled with JetBrains decompiler
// Type: SITES.Properties.Resources
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace SITES.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
  private static ResourceManager resourceMan;
  private static CultureInfo resourceCulture;

  internal Resources()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      if (SITES.Properties.Resources.resourceMan == null)
        SITES.Properties.Resources.resourceMan = new ResourceManager("SITES.Properties.Resources", typeof (SITES.Properties.Resources).Assembly);
      return SITES.Properties.Resources.resourceMan;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get => SITES.Properties.Resources.resourceCulture;
    set => SITES.Properties.Resources.resourceCulture = value;
  }

  internal static Bitmap AboutBoxImage
  {
    get
    {
      return (Bitmap) SITES.Properties.Resources.ResourceManager.GetObject(nameof (AboutBoxImage), SITES.Properties.Resources.resourceCulture);
    }
  }

  internal static Bitmap AutodeskLogo
  {
    get
    {
      return (Bitmap) SITES.Properties.Resources.ResourceManager.GetObject(nameof (AutodeskLogo), SITES.Properties.Resources.resourceCulture);
    }
  }
}
