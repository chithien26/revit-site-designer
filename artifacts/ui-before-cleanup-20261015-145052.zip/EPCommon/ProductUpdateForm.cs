using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EPCommon;

public class ProductUpdateForm : EPForm
{
	private bool m_bDailyVersionCheck;

	private IContainer components;

	private TextBox m_InstructionTextBox;

	private TextBox m_MessageTextBox;

	private Button m_CloseButton;

	private Button m_DownloadNowButton;

	private CheckBox m_DoNotShowMessageAgainCheckBox;

	public ProductUpdateForm(bool _bDailyVersionCheck)
	{
		InitializeComponent();
		m_bDailyVersionCheck = _bDailyVersionCheck;
		Text = EPShared.LocalRM.GetString("ProductUpdateAvailableTitle");
		m_MessageTextBox.Text = EPShared.LocalRM.GetString("NewerVersionAvailableForDownloadDialog");
		m_InstructionTextBox.Text = EPShared.LocalRM.GetString("ProductDownloadIntructionsDialog");
		m_DoNotShowMessageAgainCheckBox.Text = EPShared.LocalRM.GetString("AMP_DoNotShowMessageDialog");
		m_DownloadNowButton.Text = EPShared.LocalRM.GetString("AMP_DownloadNow");
		m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
		if (!m_bDailyVersionCheck)
		{
			Point location = m_DownloadNowButton.Location;
			location.Y -= m_DoNotShowMessageAgainCheckBox.Size.Height + 5;
			m_DownloadNowButton.TabIndex--;
			m_DownloadNowButton.Location = location;
			location = m_CloseButton.Location;
			location.Y -= m_DoNotShowMessageAgainCheckBox.Size.Height + 5;
			m_CloseButton.TabIndex--;
			m_CloseButton.Location = location;
			Size size = Size;
			size.Height -= m_DoNotShowMessageAgainCheckBox.Size.Height + 5;
			Size = size;
		}
		m_DoNotShowMessageAgainCheckBox.Visible = m_bDailyVersionCheck;
		InitializeControls();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		GetDialogPosition();
		m_DoNotShowMessageAgainCheckBox.Checked = false;
		if (m_bDailyVersionCheck && ApplicationUtility.Settings.eplSetE_GetSetting("CheckForUpdateNotificationDoNotShowAgainOption", ref _nReturnValue))
		{
			m_DoNotShowMessageAgainCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
	}

	private void SaveSettings()
	{
		if (m_bDailyVersionCheck)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("CheckForUpdateNotificationDoNotShowAgainOption", Convert.ToInt32(m_DoNotShowMessageAgainCheckBox.Checked));
		}
	}

	private void OnCancelButtton(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void OnDownloadNowButtton(object sender, EventArgs e)
	{
		ApplicationUtility.StartWebClient();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnProductUpdateClosing(object sender, FormClosingEventArgs e)
	{
		SaveSettings();
		SetDialogPosition();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_InstructionTextBox = new System.Windows.Forms.TextBox();
		this.m_MessageTextBox = new System.Windows.Forms.TextBox();
		this.m_CloseButton = new System.Windows.Forms.Button();
		this.m_DownloadNowButton = new System.Windows.Forms.Button();
		this.m_DoNotShowMessageAgainCheckBox = new System.Windows.Forms.CheckBox();
		base.SuspendLayout();
		this.m_InstructionTextBox.Location = new System.Drawing.Point(12, 61);
		this.m_InstructionTextBox.Multiline = true;
		this.m_InstructionTextBox.Name = "m_InstructionTextBox";
		this.m_InstructionTextBox.ReadOnly = true;
		this.m_InstructionTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.m_InstructionTextBox.Size = new System.Drawing.Size(268, 179);
		this.m_InstructionTextBox.TabIndex = 1;
		this.m_MessageTextBox.BackColor = System.Drawing.SystemColors.Control;
		this.m_MessageTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.m_MessageTextBox.Location = new System.Drawing.Point(12, 12);
		this.m_MessageTextBox.Multiline = true;
		this.m_MessageTextBox.Name = "m_MessageTextBox";
		this.m_MessageTextBox.Size = new System.Drawing.Size(268, 43);
		this.m_MessageTextBox.TabIndex = 0;
		this.m_MessageTextBox.TabStop = false;
		this.m_MessageTextBox.Text = "A newer version is available for download.  Please follow the instructions below and click the Download Now button to get the latest version. ";
		this.m_CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CloseButton.Location = new System.Drawing.Point(204, 269);
		this.m_CloseButton.Name = "m_CancelButton";
		this.m_CloseButton.Size = new System.Drawing.Size(76, 23);
		this.m_CloseButton.TabIndex = 4;
		this.m_CloseButton.Text = "&Cancel";
		this.m_CloseButton.UseVisualStyleBackColor = true;
		this.m_CloseButton.Click += new System.EventHandler(this.OnCancelButtton);
		this.m_DownloadNowButton.Location = new System.Drawing.Point(83, 269);
		this.m_DownloadNowButton.Name = "m_DownloadNowButton";
		this.m_DownloadNowButton.Size = new System.Drawing.Size(115, 23);
		this.m_DownloadNowButton.TabIndex = 3;
		this.m_DownloadNowButton.Text = "&Download Now";
		this.m_DownloadNowButton.UseVisualStyleBackColor = true;
		this.m_DownloadNowButton.Click += new System.EventHandler(this.OnDownloadNowButtton);
		this.m_DoNotShowMessageAgainCheckBox.AutoSize = true;
		this.m_DoNotShowMessageAgainCheckBox.Location = new System.Drawing.Point(12, 246);
		this.m_DoNotShowMessageAgainCheckBox.Name = "m_DoNotShowMessageAgainCheckBox";
		this.m_DoNotShowMessageAgainCheckBox.Size = new System.Drawing.Size(160, 17);
		this.m_DoNotShowMessageAgainCheckBox.TabIndex = 2;
		this.m_DoNotShowMessageAgainCheckBox.Text = "&Do not show message again";
		this.m_DoNotShowMessageAgainCheckBox.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(292, 304);
		base.Controls.Add(this.m_DoNotShowMessageAgainCheckBox);
		base.Controls.Add(this.m_CloseButton);
		base.Controls.Add(this.m_DownloadNowButton);
		base.Controls.Add(this.m_MessageTextBox);
		base.Controls.Add(this.m_InstructionTextBox);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "ProductUpdateForm";
		this.Text = "ProductUpdateForm";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnProductUpdateClosing);
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_DownloadNowButton;
		base.CancelButton = this.m_CloseButton;
	}
}
