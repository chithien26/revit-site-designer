﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.XYZEqualityComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class XYZEqualityComparer : IEqualityComparer<XYZ>
{
  public bool Equals(XYZ x, XYZ y)
  {
    if (y == null && x == null)
      return true;
    return !(x == null | y == null) && x.IsAlmostEqualTo(y);
  }

  public int GetHashCode(XYZ obj)
  {
    Decimal num1 = Math.Round((Decimal) obj.X, 9);
    int hashCode1 = num1.GetHashCode();
    num1 = Math.Round((Decimal) obj.Y, 9);
    int hashCode2 = num1.GetHashCode();
    int num2 = hashCode1 + hashCode2;
    num1 = Math.Round((Decimal) obj.Y, 9);
    int hashCode3 = num1.GetHashCode();
    return num2 + hashCode3;
  }
}
