﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.TopoPointEqualityComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class TopoPointEqualityComparer : IEqualityComparer<TopoPoint>
{
  bool IEqualityComparer<TopoPoint>.Equals(TopoPoint x, TopoPoint y)
  {
    return x != null && y != null && EPShared.eplGeoE_ArePntsDuplicates2D((Eps_Point) x, (Eps_Point) y);
  }

  int IEqualityComparer<TopoPoint>.GetHashCode(TopoPoint obj)
  {
    double x = obj.x;
    double y = obj.y;
    double z = obj.z;
    uint number = obj.Number;
    return x.GetHashCode() + y.GetHashCode() + z.GetHashCode() + number.GetHashCode();
  }
}
