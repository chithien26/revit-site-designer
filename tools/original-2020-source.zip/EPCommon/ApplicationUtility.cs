﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ApplicationUtility
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ApplicationUtility
{
  private static RevitLanguageType m_RevitLanguangeType;
  private static string m_strThreeLetterWindowsLanguageName;
  private static string m_strInstallLocation;
  private static string m_strRevitIniFilename;
  private static StringTableModule m_StringTableModule;
  private static Settings m_Settings;
  private static string m_strHelpNamespace;
  private static WindowWrapper m_RevitWindowWrapper;
  private static RegistryPaths m_RegistryPaths;
  private static bool m_bIs64BitInstall = false;
  private static string m_strCurUserLandcaddRegistryKey;
  private static bool m_bIsRevitVersionValid = true;
  private static string m_strRevitVersion;
  private static string m_strSitesInstallationDir = "Autodesk\\Site Designer for Revit {0}";

  private ApplicationUtility()
  {
  }

  public static bool Initialize(
    ControlledApplication _Application,
    string _strCurUserLandcaddRegistryKey,
    string _strINIFilename,
    string _strHelpFilename,
    IntPtr _mainWindowHandle,
    RevitProduct _RevitProduct)
  {
    ApplicationUtility.m_strRevitVersion = _Application.VersionNumber;
    ApplicationUtility.m_strSitesInstallationDir = string.Format(ApplicationUtility.m_strSitesInstallationDir, (object) ApplicationUtility.m_strRevitVersion);
    ApplicationUtility.m_bIs64BitInstall = Environment.Is64BitProcess;
    ApplicationUtility.m_strCurUserLandcaddRegistryKey = _strCurUserLandcaddRegistryKey;
    ApplicationUtility.m_RegistryPaths = new RegistryPaths();
    string str1 = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
    string str2 = $"{Directory.GetCurrentDirectory()}\\{_strINIFilename}";
    if (!File.Exists(str2))
      str2 = str1 + ApplicationUtility.m_RegistryPaths.SupportPath + _strINIFilename;
    if (!File.Exists(str2))
    {
      str1 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), ApplicationUtility.m_strSitesInstallationDir);
      str2 = str1 + ApplicationUtility.m_RegistryPaths.SupportPath + _strINIFilename;
    }
    ApplicationUtility.m_RegistryPaths.ProgramPath = str1;
    string path = string.Empty;
    bool flag = false;
    while (!flag)
    {
      if (str2 != string.Empty)
      {
        try
        {
          path = Path.GetDirectoryName(str2);
          if (path != string.Empty)
          {
            FileIOPermission perm = new FileIOPermission(FileIOPermissionAccess.Write, str2);
            PermissionSet permissionSet = new PermissionSet(PermissionState.None);
            permissionSet.AddPermission((IPermission) perm);
            if (permissionSet.IsSubsetOf(AppDomain.CurrentDomain.PermissionSet))
            {
              if (Directory.Exists(path))
              {
                using (FileStream fileStream = new FileStream(str2, FileMode.OpenOrCreate))
                {
                  if (fileStream.CanWrite)
                    flag = true;
                }
              }
              else
              {
                Directory.CreateDirectory(path);
                flag = true;
              }
            }
          }
        }
        catch (UnauthorizedAccessException ex)
        {
          flag = false;
        }
        catch (Exception ex)
        {
          flag = false;
        }
      }
      if (!flag)
      {
        string str3 = $"Site Designer for Revit must have read/write access to file {_strINIFilename}";
        int num = (int) RevitMessageBox.Show(!(path != string.Empty) ? str3 + ". Please specify a valid directory that the current user will have permissions to read/write to." : str3 + ". Please specify a different directory that the current user will have permissions to read/write to.", "Error", MessageBoxIcon.Hand);
        FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
        folderBrowserDialog.Description = "Select the directory that you want for file " + _strINIFilename;
        folderBrowserDialog.ShowNewFolderButton = true;
        if (path != string.Empty)
          folderBrowserDialog.SelectedPath = path;
        if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
        {
          string selectedPath = folderBrowserDialog.SelectedPath;
          if (!folderBrowserDialog.SelectedPath.EndsWith("\\") && !folderBrowserDialog.SelectedPath.EndsWith("/"))
            selectedPath += "\\";
          str2 = selectedPath + _strINIFilename;
        }
        else
          flag = true;
      }
    }
    ApplicationUtility.m_Settings = new Settings(str2);
    string empty = string.Empty;
    if (ApplicationUtility.m_RegistryPaths.GetHelpPath(_strHelpFilename, ref empty) == 0)
      ApplicationUtility.m_strHelpNamespace = empty;
    Process currentProcess = Process.GetCurrentProcess();
    if (currentProcess != null)
    {
      ApplicationUtility.m_RevitWindowWrapper = new WindowWrapper(_mainWindowHandle);
      if (ApplicationUtility.m_bIsRevitVersionValid)
      {
        ApplicationUtility.m_strInstallLocation = Path.GetDirectoryName(currentProcess.MainModule.FileName);
        foreach (string directory in Directory.GetDirectories(ApplicationUtility.m_strInstallLocation))
        {
          if (Directory.GetFiles(directory, "Revit.ini").Length != 0)
          {
            ApplicationUtility.m_strInstallLocation = directory;
            break;
          }
        }
      }
    }
    ApplicationUtility.m_strRevitIniFilename = Path.Combine(ApplicationUtility.m_strInstallLocation, "Revit.ini");
    if (!File.Exists(ApplicationUtility.m_strRevitIniFilename))
      ApplicationUtility.m_strRevitIniFilename = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), $"Autodesk\\Revit\\{_Application.VersionName}\\Revit.ini");
    ApplicationUtility.SetLanguage(_Application);
    ApplicationUtility.m_StringTableModule = new StringTableModule(_RevitProduct);
    if (ApplicationUtility.m_bIsRevitVersionValid)
      return true;
    int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InstallUpdate1ToRunSiteworksMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private static void SetLanguage(ControlledApplication _Application)
  {
    switch (_Application.Language - -1)
    {
      case 0:
        bool flag = false;
        if (ApplicationUtility.m_Settings.eplSetE_GetSetting("LanguageName", ref ApplicationUtility.m_strThreeLetterWindowsLanguageName))
          flag = true;
        else if (ApplicationUtility.m_Settings.eplSetE_GetSetting("LanguageName", ref ApplicationUtility.m_strThreeLetterWindowsLanguageName, ApplicationUtility.m_strRevitIniFilename))
          flag = true;
        if (!flag && !RevitUtility.FindLanguageName(ref ApplicationUtility.m_strThreeLetterWindowsLanguageName) && !string.IsNullOrEmpty(ApplicationUtility.m_strThreeLetterWindowsLanguageName))
        {
          List<string> _WarningOptions = new List<string>();
          _WarningOptions.Add("Czech");
          _WarningOptions.Add("Hungarian");
          _WarningOptions.Add("Polish");
          _WarningOptions.Add("Portuguese");
          int _nDefaultOption = 0;
          if (string.Compare(CultureInfo.CurrentCulture.ThreeLetterWindowsLanguageName, "CSY", true) == 0)
            _nDefaultOption = 0;
          else if (string.Compare(CultureInfo.CurrentCulture.ThreeLetterWindowsLanguageName, "HUN", true) == 0)
            _nDefaultOption = 1;
          else if (string.Compare(CultureInfo.CurrentCulture.ThreeLetterWindowsLanguageName, "PLK", true) == 0)
            _nDefaultOption = 2;
          else if (string.Compare(CultureInfo.CurrentCulture.ThreeLetterWindowsLanguageName, "PTG", true) == 0 || string.Compare(CultureInfo.CurrentCulture.ThreeLetterWindowsLanguageName, "PTB", true) == 0)
            _nDefaultOption = 3;
          WarningOptionsForm warningOptionsForm = new WarningOptionsForm("Warning", string.Empty, "LanguageName", "Please pick the language for your version of Revit.", _WarningOptions, _nDefaultOption, false, false);
          int num = (int) warningOptionsForm.ShowDialog();
          if (warningOptionsForm.DialogResult == DialogResult.OK)
          {
            if (string.Compare(warningOptionsForm.WarningOption, "Czech", true) == 0)
              ApplicationUtility.m_strThreeLetterWindowsLanguageName = "CSY";
            else if (string.Compare(warningOptionsForm.WarningOption, "Hungarian", true) == 0)
              ApplicationUtility.m_strThreeLetterWindowsLanguageName = "HUN";
            else if (string.Compare(warningOptionsForm.WarningOption, "Polish", true) == 0)
              ApplicationUtility.m_strThreeLetterWindowsLanguageName = "PLK";
            else if (string.Compare(warningOptionsForm.WarningOption, "Portuguese", true) == 0)
              ApplicationUtility.m_strThreeLetterWindowsLanguageName = "PTG";
          }
          ApplicationUtility.m_Settings.eplSetE_SetSetting("LanguageName", ApplicationUtility.m_strThreeLetterWindowsLanguageName);
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "CSY", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Czech;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "HUN", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Hungarian;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "PLK", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Polish;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "PTG", true) == 0 || string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "PTB", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Portuguese;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "CHS", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.ChineseSimplified;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "CHT", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.ChineseTraditional;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "NLD", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Dutch;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "ENU", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.English;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "FRA", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.French;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "DEU", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.German;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "FRA", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.French;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "ITA", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Italian;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "JPN", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Japanese;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "KOR", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Korean;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "RUS", true) == 0)
        {
          ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Russian;
          break;
        }
        if (string.Compare(ApplicationUtility.m_strThreeLetterWindowsLanguageName, "ESP", true) != 0)
          break;
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Spanish;
        break;
      case 1:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.English;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "ENU";
        break;
      case 2:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.German;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "DEU";
        break;
      case 3:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Spanish;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "ESP";
        break;
      case 4:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.French;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "FRA";
        break;
      case 5:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Italian;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "ITA";
        break;
      case 6:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Dutch;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "NLD";
        break;
      case 7:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.ChineseSimplified;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "CHS";
        break;
      case 8:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.ChineseTraditional;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "CHT";
        break;
      case 9:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Japanese;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "JPN";
        break;
      case 10:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Korean;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "KOR";
        break;
      case 11:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Russian;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "RUS";
        break;
      case 12:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Czech;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "CSY";
        break;
      case 13:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Polish;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "PLK";
        break;
      case 14:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Hungarian;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "HUN";
        break;
      case 15:
        ApplicationUtility.m_RevitLanguangeType = RevitLanguageType.Portuguese;
        ApplicationUtility.m_strThreeLetterWindowsLanguageName = "PTG";
        break;
    }
  }

  public static string GetString(string _strValue)
  {
    return ApplicationUtility.m_StringTableModule != null ? ApplicationUtility.m_StringTableModule.GetString(_strValue) : string.Empty;
  }

  public static string GetString(bool _bUseWindowsLanguageName, string _strValue)
  {
    return _bUseWindowsLanguageName ? ApplicationUtility.m_StringTableModule.GetString(ApplicationUtility.m_strThreeLetterWindowsLanguageName, _strValue) : ApplicationUtility.m_StringTableModule.GetString(_strValue);
  }

  public static void StartWebClient()
  {
    try
    {
      Process.Start(string.Format("ftp://epuserweblinks:3pUser@ftp.eaglepoint.com/Downloads/Siteworks for Revit {0}/SiteworksforRevit{0}.zip", (object) ApplicationUtility.RevitVersion));
    }
    catch (Exception ex)
    {
      if (!EPShared.eplLicM_IsNodeLicense())
      {
        int num1 = (int) RevitMessageBox.Show(ApplicationUtility.GetString("ConnectionCouldNotBeMadeContactITAdminMessage"), ApplicationUtility.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        int num2 = (int) RevitMessageBox.Show(ApplicationUtility.GetString("ConnectionCouldNotBeMadeMessage"), ApplicationUtility.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
  }

  public static void VerifyProductVersion() => ApplicationUtility.VerifyProductVersion(true);

  public static void VerifyProductVersion(bool _bDailyVersionCheck)
  {
  }

  public static bool UseMass
  {
    get
    {
      int _nReturnValue = 0;
      return ApplicationUtility.Settings.eplSetE_GetSetting(nameof (UseMass), ref _nReturnValue) && _nReturnValue == 1;
    }
  }

  public static StringTableModule StringTable => ApplicationUtility.m_StringTableModule;

  public static Settings Settings => ApplicationUtility.m_Settings;

  public static string HelpFilename => ApplicationUtility.m_strHelpNamespace;

  public static WindowWrapper RevitWindowWrapper => ApplicationUtility.m_RevitWindowWrapper;

  public static RegistryPaths RegistryPaths => ApplicationUtility.m_RegistryPaths;

  public static bool Is64BitInstall => ApplicationUtility.m_bIs64BitInstall;

  public static string InstallLocation => ApplicationUtility.m_strInstallLocation;

  public static string RevitIniFilename => ApplicationUtility.m_strRevitIniFilename;

  public static string CurrentUserRegistryKey => ApplicationUtility.m_strCurUserLandcaddRegistryKey;

  public static bool IsRevitVersionValid => ApplicationUtility.m_bIsRevitVersionValid;

  public static string RevitVersion => ApplicationUtility.m_strRevitVersion;

  public static RevitLanguageType RevitLanguageType => ApplicationUtility.m_RevitLanguangeType;

  public static string ThreeLetterWindowsLanguageName
  {
    get => ApplicationUtility.m_strThreeLetterWindowsLanguageName;
  }
}
