﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantMixFamilyManager
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantMixFamilyManager : EPForm
{
  private Units m_Units;
  private List<Document> m_OpenDocumentList;
  private string m_strSourceFile = string.Empty;
  private List<KeyValuePair<string, string>> m_RecenFilesList;
  private Document m_CurDocument;
  private List<FamilyParameterTypeWrapper> m_ParameterList;
  private List<FamilyTypeContainer> m_PlantListFamilyTypeList;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private DialogType m_DlgType;
  private int m_nMixtListViewSortColumn = -1;
  private EPTransactionContainer m_TransactionContainer;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private GroupBox m_DynGroupBox;
  private GroupBox m_DestinationGroupBox;
  private ListView m_MixListView;
  private TextBox m_DestinationTextBox;
  private Button m_DestinationFileChooserBtn;
  private Label m_DestinationFileLbl;
  private Button m_EqualButton;
  private Button m_DeleteButton;
  private Button m_AddButton;
  private Button m_SearchButton;
  private Button m_ModifyButton;
  private Button m_SaveFamilyButton;
  private Button m_CancelButton;
  private GroupBox m_SourceGroupBox;
  private TextBox m_SourceTxtBox;
  private Button m_RFAOpenFileButton;
  private Label m_SourceFileLbl;

  public PlantMixFamilyManager(DialogType _Type, Document _CurDocument)
  {
    this.InitializeComponent();
    this.EPToolTip.SetToolTip((Control) this.m_RFAOpenFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_DestinationFileChooserBtn, EPShared.LocalRM.GetString("NewFamilyToolTip"));
    this.m_CurDocument = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_CurDocument);
    this.m_FormatOptions = this.m_CurDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_CurDocument.DisplayUnitSystem;
    this.m_Units = this.m_CurDocument.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_CurDocument.GetUnits().DecimalSymbol;
    this.m_DlgType = _Type;
    this.SetStringValues();
    this.SetDefaultValues();
  }

  private void SetStringValues()
  {
    string str = string.Empty;
    switch (this.m_DlgType)
    {
      case DialogType.PlantMix:
        str = $"{EPShared.LocalRM.GetString("PlantMixFamilyDialog")} {EPShared.LocalRM.GetString("CollectionDialog")}";
        this.Text = $"{EPShared.LocalRM.GetString("PlantMixFamilyDialog")} {EPShared.LocalRM.GetString("ManagerDialog")}";
        this.m_ParameterList = ManagePlants.PlantMixParamenterList();
        this.m_SearchButton.Visible = true;
        this.m_EqualButton.Visible = true;
        break;
      case DialogType.Patio:
        str = $"{EPShared.LocalRM.GetString("PathWalkFamilyDialog")} {EPShared.LocalRM.GetString("CollectionDialog")}";
        this.Text = $"{EPShared.LocalRM.GetString("PathWalkFamilyDialog")} {EPShared.LocalRM.GetString("ManagerDialog")}";
        this.m_ParameterList = ManagePlants.PatioWalkParamenterList();
        this.m_SearchButton.Visible = false;
        this.m_EqualButton.Visible = false;
        break;
    }
    this.m_MixListView.View = View.Details;
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
        this.m_MixListView.Columns.Add(this.m_ParameterList[index].ParameterDisplayName);
    }
    this.m_DynGroupBox.Text = str;
    this.m_SourceFileLbl.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_DestinationFileLbl.Text = EPShared.LocalRM.GetString("Fi_AMP_leDialog");
    this.m_SourceGroupBox.Text = EPShared.LocalRM.GetString("SourceDialog");
    this.m_DestinationGroupBox.Text = EPShared.LocalRM.GetString("DestinationDialog");
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("AMP_SearchDialog");
    this.m_AddButton.Text = EPShared.LocalRM.GetString("AMP_AddDialog");
    this.m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
    this.m_DeleteButton.Text = EPShared.LocalRM.GetString("AMP_DeleteDialog");
    this.m_EqualButton.Text = EPShared.LocalRM.GetString("AMP_EqualDialog");
    this.m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("Save_AMP_FamilyDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
  }

  private void SetDefaultValues()
  {
    string empty = string.Empty;
    this.GetDialogPosition();
    if (this.m_DlgType == DialogType.PlantMix)
    {
      if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixFamilyManagerSourcePath", ref empty))
        this.m_SourceTxtBox.Text = empty;
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixFamilyManagerDestinationPath", ref empty))
        return;
      this.m_DestinationTextBox.Text = empty;
    }
    else
    {
      if (ApplicationUtility.Settings.eplSetE_GetSetting("PatioWalkFamilyManagerSourcePath", ref empty))
        this.m_SourceTxtBox.Text = empty;
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("PatioWalkFamilyManagerDestinationPath", ref empty))
        return;
      this.m_DestinationTextBox.Text = empty;
    }
  }

  private void FindRecentFileList()
  {
    this.m_RecenFilesList = Settings.eplSetE_GetSectionValuesAsList("Recent File List", ApplicationUtility.RevitIniFilename);
  }

  private void ResetRecentFileList()
  {
    if (this.m_RecenFilesList == null || this.m_RecenFilesList.Count <= 0 || !Settings.eplSetE_DeleteSection("Recent File List", ApplicationUtility.RevitIniFilename))
      return;
    foreach (KeyValuePair<string, string> recenFiles in this.m_RecenFilesList)
      Settings.eplSetE_SetSetting("Recent File List", recenFiles.Key, recenFiles.Value, ApplicationUtility.RevitIniFilename);
  }

  private void CloseOpenDocuments()
  {
    if (this.m_OpenDocumentList != null && this.m_OpenDocumentList.Count > 0)
    {
      for (int index = this.m_OpenDocumentList.Count - 1; index >= 0; --index)
      {
        this.m_OpenDocumentList[index].Close(false);
        this.m_OpenDocumentList.RemoveAt(index);
      }
    }
    this.ResetRecentFileList();
  }

  private void VerifyFileAndPopulateFamilyTypeSetList(FileInfo _CurrentFile)
  {
    Document CurDocument = (Document) null;
    string str = _CurrentFile.Name.Substring(0, _CurrentFile.Name.Length - _CurrentFile.Extension.Length);
    int num1 = str.LastIndexOf('.');
    if (num1 >= 0 && str.Length - 1 == num1 + 4)
    {
      int result = -1;
      if (int.TryParse(str.Substring(num1 + 1), out result))
        return;
    }
    bool flag = ManagePlants.IsDocumentOpen(this.m_CurDocument.Application, _CurrentFile.FullName, ref CurDocument);
    if (!flag)
      CurDocument = this.m_CurDocument.Application.OpenDocumentFile(_CurrentFile.FullName);
    EPTransactionContainer transactionContainer = new EPTransactionContainer(CurDocument);
    transactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
    transactionContainer.BeginTransaction();
    List<FamilyTypeContainer> familyTypeContainerList = this.PopulateFamilyTypeSetList(CurDocument.FamilyManager);
    if (familyTypeContainerList == null || familyTypeContainerList.Count <= 0)
    {
      if (this.m_DlgType == DialogType.PlantMix)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NotValidLANDCADDPlantMixFamilyMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_SourceTxtBox.Text = string.Empty;
        this.m_SourceTxtBox.Focus();
      }
      else
      {
        int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NotValidLANDCADDPatioWalkFamilyMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_SourceTxtBox.Text = string.Empty;
        this.m_SourceTxtBox.Focus();
      }
    }
    transactionContainer.EndTransaction();
    transactionContainer.Rollback();
    if (familyTypeContainerList != null)
    {
      if (this.m_OpenDocumentList == null)
        this.m_OpenDocumentList = new List<Document>();
      if (!flag)
        this.m_OpenDocumentList.Add(CurDocument);
      foreach (FamilyTypeContainer familyTypeContainer in familyTypeContainerList)
        this.m_PlantListFamilyTypeList.Add(familyTypeContainer);
    }
    else if (!flag)
      CurDocument.Close(false);
    this.CleanMix();
  }

  private List<FamilyTypeContainer> PopulateFamilyTypeSetList(FamilyManager _FamilyManager)
  {
    List<FamilyTypeContainer> familyTypeContainerList = (List<FamilyTypeContainer>) null;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    bool flag = false;
    LandcaddID landcaddId = LandcaddID.PatioWalk;
    if (this.m_DlgType == DialogType.PlantMix)
      landcaddId = LandcaddID.PlantMix;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _FamilyManager.Types.Size;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarLoadingFamilyMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    foreach (FamilyType type in _FamilyManager.Types)
    {
      FamilyParameter familyParameter = _FamilyManager[RevitParameters.LandcaddIDGenericModelFamilyParameter];
      if (familyParameter != null && type.HasValue(familyParameter) && string.Compare(type.AsString(familyParameter), Convert.ToInt32((object) landcaddId).ToString("000"), true) == 0)
      {
        string str1 = type.Name.Trim();
        if (str1 != string.Empty)
        {
          foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
          {
            if (string.Compare(str1, plantListFamilyType.FamilyTypeWrapper.FamilyTypeName, true) == 0)
            {
              flag = true;
              break;
            }
          }
          if (!flag)
          {
            ListViewItem listViewItem = new ListViewItem();
            for (int index = 0; index < this.m_ParameterList.Count; ++index)
            {
              if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
              {
                if (this.m_DlgType == DialogType.PlantMix)
                {
                  string str2 = string.Empty;
                  this.FindParamenterValue(_FamilyManager, type, this.m_ParameterList[index].ParameterName, ref str2);
                  if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
                  {
                    double _dConvertedDouble = 1.0;
                    if (str2 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str2);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str2);
                  }
                  else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
                  {
                    if (str2 == null || str2 == string.Empty)
                      str2 = "1.0";
                  }
                  else if (str2 == string.Empty && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                    str2 = str1;
                  if (index == 0)
                  {
                    listViewItem = this.m_MixListView.Items.Add(str1, str2, string.Empty);
                    listViewItem.Tag = (object) str1;
                  }
                  else
                    listViewItem.SubItems.Add(str2);
                }
                else
                {
                  string str3 = string.Empty;
                  this.FindParamenterValue(_FamilyManager, type, this.m_ParameterList[index].ParameterName, ref str3);
                  if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
                  {
                    double _dConvertedDouble = 0.0;
                    if (str3 != string.Empty)
                      _dConvertedDouble = ValueConversion.ToDouble(str3);
                    RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref str3);
                  }
                  else if (string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
                    str3 = string.Compare(str3, "1", true) != 0 ? (string.Compare(str3, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
                  else if (str3 == string.Empty && string.Compare(this.m_ParameterList[index].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
                    str3 = str1;
                  if (index == 0)
                  {
                    listViewItem = this.m_MixListView.Items.Add(str1, str3, string.Empty);
                    listViewItem.Tag = (object) str1;
                  }
                  else
                    listViewItem.SubItems.Add(str3);
                }
              }
            }
            if (familyTypeContainerList == null)
              familyTypeContainerList = new List<FamilyTypeContainer>();
            if (this.m_DlgType == DialogType.PlantMix)
              familyTypeContainerList.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetPlantMixFamilyParameterSetForType(type, _FamilyManager)));
            else
              familyTypeContainerList.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetPatioWalkFamilyParameterSetForType(type, _FamilyManager)));
          }
          else
            flag = false;
        }
        progressBarForm.UpdateProgressBar(1);
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return familyTypeContainerList;
  }

  private bool FindParamenterValue(
    FamilyManager FamilyManager,
    FamilyType type,
    string _strParamter,
    ref string _strValue)
  {
    bool paramenterValue = false;
    FamilyParameter familyParameter = FamilyManager[_strParamter];
    if (familyParameter != null && type.HasValue(familyParameter))
    {
      switch (familyParameter.StorageType - 1)
      {
        case 0:
          if ((ValueType) type.AsInteger(familyParameter) is int)
          {
            paramenterValue = true;
            _strValue = Convert.ToString((object) type.AsInteger(familyParameter));
            break;
          }
          break;
        case 1:
          if ((ValueType) type.AsDouble(familyParameter) is double)
          {
            paramenterValue = true;
            _strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
            break;
          }
          break;
        case 2:
          if (type.AsString(familyParameter) != null)
          {
            paramenterValue = true;
            _strValue = type.AsString(familyParameter);
            break;
          }
          break;
      }
    }
    return paramenterValue;
  }

  private void OnSingleFileTextBoxLeaveFocus(object sender, EventArgs e) => this.LoadData();

  private void OnSourceTxtBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.LoadData();
  }

  private void LoadData()
  {
    if (!string.IsNullOrEmpty(this.m_SourceTxtBox.Text) && new FileInfo(this.m_SourceTxtBox.Text).Extension == string.Empty)
      this.m_SourceTxtBox.Text += ".rfa";
    if (RevitUtility.CompareFileNames(this.m_strSourceFile, this.m_SourceTxtBox.Text) == 0)
      return;
    this.CloseOpenDocuments();
    this.FindRecentFileList();
    this.m_strSourceFile = this.m_SourceTxtBox.Text;
    this.m_MixListView.Items.Clear();
    this.m_nMixtListViewSortColumn = -1;
    this.m_MixListView.Sorting = SortOrder.None;
    this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    if (this.m_OpenDocumentList != null)
      this.m_OpenDocumentList.Clear();
    if (string.IsNullOrEmpty(this.m_strSourceFile))
      return;
    FileInfo _CurrentFile = new FileInfo(this.m_strSourceFile);
    if (!File.Exists(this.m_strSourceFile))
      return;
    if (string.Compare(_CurrentFile.Extension, ".rfa", true) != 0)
    {
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Source")} {EPShared.LocalRM.GetString("NoRFAExtension")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
      this.VerifyFileAndPopulateFamilyTypeSetList(_CurrentFile);
  }

  private bool ValidateFields()
  {
    string text = this.m_DestinationTextBox.Text;
    if (string.IsNullOrEmpty(text))
    {
      int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("Source")} {EPShared.LocalRM.GetString("NoRFAExtension")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_DestinationTextBox.Focus();
      return false;
    }
    string empty = string.Empty;
    string str = ".rfa";
    if (text.IndexOf(str) < 0)
    {
      if (text.IndexOf("\\") > 0 || text.IndexOf("/") > 0)
      {
        int length = -1;
        if (text.IndexOf("\\") > 0)
          length = text.LastIndexOf("\\");
        else if (text.IndexOf("/") > 0)
          length = text.LastIndexOf("/");
        if (Directory.Exists(text.Substring(0, length)))
        {
          text += str;
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else if (text.IndexOf("\\") > 0 || text.IndexOf("/") > 0)
    {
      int length = -1;
      if (text.IndexOf("\\") > 0)
        length = text.LastIndexOf("\\");
      else if (text.IndexOf("/") > 0)
        length = text.LastIndexOf("/");
      if (!Directory.Exists(text.Substring(0, length)))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    this.m_DestinationTextBox.Text = text;
    if (File.Exists(text))
    {
      if (RevitUtility.CompareFileNames(this.m_CurDocument.PathName, text) != 0)
      {
        switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation))
        {
          case DialogResult.Cancel:
            return false;
          case DialogResult.Yes:
            Document CurDocument = (Document) null;
            if (ManagePlants.IsDocumentOpen(this.m_CurDocument.Application, text, ref CurDocument))
            {
              bool flag = false;
              if (this.m_OpenDocumentList != null && this.m_OpenDocumentList.Count > 0)
              {
                for (int index = this.m_OpenDocumentList.Count - 1; index >= 0; --index)
                {
                  if (RevitUtility.CompareFileNames(this.m_OpenDocumentList[index].PathName, CurDocument.PathName) == 0)
                  {
                    this.m_OpenDocumentList[index].Close(false);
                    this.m_OpenDocumentList.RemoveAt(index);
                    flag = true;
                    break;
                  }
                }
              }
              if (!flag)
                CurDocument.Close(false);
            }
            File.Delete(text);
            break;
        }
      }
      else if (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationFamilyOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
        return false;
    }
    return true;
  }

  private bool FindSelectedPlantList(ref List<FamilyTypeContainer> _SelectedPlantList)
  {
    int count;
    if ((count = this.m_MixListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = 0; index1 < count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_PlantListFamilyTypeList.Count; ++index2)
        {
          if (this.m_PlantListFamilyTypeList[index2].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string) this.m_MixListView.SelectedItems[index1].Tag, this.m_PlantListFamilyTypeList[index2].FamilyTypeWrapper.FamilyTypeName, true) == 0)
          {
            _SelectedPlantList.Add(this.m_PlantListFamilyTypeList[index2]);
            break;
          }
        }
      }
      return true;
    }
    string empty = string.Empty;
    int num = (int) RevitMessageBox.Show(this.m_DlgType != DialogType.PlantMix ? EPShared.LocalRM.GetString("NoPatioWalkSelected") : EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private void SaveFamilyButtonClicked(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    FileInfo fileInfo = new FileInfo(RevitUtility.GetFormattedFileName(this.m_DestinationTextBox.Text, true));
    List<FamilyTypeContainer> _SelectedPlantList = new List<FamilyTypeContainer>();
    if (this.m_DlgType == DialogType.PlantMix)
    {
      if (this.CheckPercentage())
      {
        if (!this.FindSelectedPlantList(ref _SelectedPlantList))
          return;
        if (ManagePlants.CreateNewMixFamilyDocument(this.m_CurDocument, _SelectedPlantList, this.m_DlgType, fileInfo.FullName))
        {
          this.CloseOpenDocuments();
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantMixFamilyTransaction") + fileInfo.Name);
          RevitUtility.LoadFamily(this.m_CurDocument, fileInfo.FullName, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
        }
        this.SaveSettings();
      }
      else if (this.m_PlantListFamilyTypeList == null || this.m_PlantListFamilyTypeList.Count <= 0)
      {
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PercentageError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    else
    {
      if (!this.FindSelectedPlantList(ref _SelectedPlantList))
        return;
      if (ManagePlants.CreateNewMixFamilyDocument(this.m_CurDocument, _SelectedPlantList, this.m_DlgType, fileInfo.FullName))
      {
        this.CloseOpenDocuments();
        this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPatioWalkFamilyTransaction") + fileInfo.Name);
        RevitUtility.LoadFamily(this.m_CurDocument, fileInfo.FullName, true, ref this.m_TransactionContainer);
        this.m_TransactionContainer.Commit();
      }
      this.SaveSettings();
    }
  }

  private void CancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnSearchButtonClicked(object sender, EventArgs e)
  {
    PlantMixSearchForm plantMixSearchForm = new PlantMixSearchForm(this.m_CurDocument);
    int num = (int) plantMixSearchForm.ShowDialog();
    if (plantMixSearchForm.DialogResult != DialogResult.OK)
      return;
    List<string> _TypeNames = new List<string>();
    if (this.m_PlantListFamilyTypeList == null)
      this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    for (int index = 0; index < this.m_PlantListFamilyTypeList.Count; ++index)
      _TypeNames.Add(this.m_PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName);
    this.CheckForDuplicates(plantMixSearchForm.SelectedPlantListFamilyTypeList, _TypeNames);
  }

  private void CheckForDuplicates(
    List<FamilyTypeContainer> _PlantListFamilyTypeList,
    List<string> _TypeNames)
  {
    bool flag1 = false;
    bool flag2 = false;
    string empty = string.Empty;
    for (int index = 0; index < _PlantListFamilyTypeList.Count; ++index)
    {
      if (_PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName != string.Empty)
      {
        if (flag1)
        {
          _PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName = ManagePlants.GetUniqueTypeName(_TypeNames, _PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName);
          this.m_PlantListFamilyTypeList.Add(_PlantListFamilyTypeList[index]);
          this.UpdateList(this.m_MixListView.Items.Count, this.m_PlantListFamilyTypeList.Count, false);
        }
        else if (ManagePlants.IsTypeNameDuplicate(_TypeNames, _PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName))
        {
          if (!flag2)
          {
            flag2 = true;
            if (RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateTypeAppendMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
              flag1 = true;
              _PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName = ManagePlants.GetUniqueTypeName(_TypeNames, _PlantListFamilyTypeList[index].FamilyTypeWrapper.FamilyTypeName);
              this.m_PlantListFamilyTypeList.Add(_PlantListFamilyTypeList[index]);
              this.UpdateList(this.m_MixListView.Items.Count, this.m_PlantListFamilyTypeList.Count, false);
            }
          }
        }
        else
        {
          this.m_PlantListFamilyTypeList.Add(_PlantListFamilyTypeList[index]);
          this.UpdateList(this.m_MixListView.Items.Count, this.m_PlantListFamilyTypeList.Count, false);
        }
      }
    }
  }

  private void OnPlantMixFamilyManagerFormClosing(object sender, FormClosingEventArgs e)
  {
    this.CloseOpenDocuments();
    this.SetDialogPosition();
  }

  private void SaveSettings()
  {
    if (this.m_DlgType == DialogType.PlantMix)
    {
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixFamilyManagerSourcePath", this.m_SourceTxtBox.Text);
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixFamilyManagerDestinationPath", this.m_DestinationTextBox.Text);
    }
    else
    {
      ApplicationUtility.Settings.eplSetE_SetSetting("PatioWalkFamilyManagerSourcePath", this.m_SourceTxtBox.Text);
      ApplicationUtility.Settings.eplSetE_SetSetting("PatioWalkFamilyManagerDestinationPath", this.m_DestinationTextBox.Text);
    }
  }

  private void OnAddButtonClicked(object sender, EventArgs e)
  {
    FamilyTypeContainer familyTypeContainer = new FamilyTypeContainer();
    int _nSelectedIndex = -1;
    if (this.m_PlantListFamilyTypeList == null)
      this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    using (AddModifyMix addModifyMix = new AddModifyMix(this.m_ParameterList, ref this.m_PlantListFamilyTypeList, this.m_CurDocument.GetUnits(), this.m_DisplayUnitSystem, this.m_FormatOptions, this.m_UnitSymbolType, this.m_DecimalSymbolType, _nSelectedIndex, this.m_DlgType))
    {
      int num = (int) addModifyMix.ShowDialog();
      if (addModifyMix.DialogResult != DialogResult.OK)
        return;
      this.UpdateList(this.m_MixListView.Items.Count, this.m_PlantListFamilyTypeList.Count, false);
    }
  }

  private void OnModifyButtonClicked(object sender, EventArgs e)
  {
    if (this.m_MixListView.Items.Count <= 0)
      return;
    this.Modify();
  }

  private void Modify()
  {
    int index = -1;
    if (this.m_MixListView.SelectedItems.Count >= 1)
    {
      int num1;
      for (num1 = 0; num1 < this.m_PlantListFamilyTypeList.Count; ++num1)
      {
        if (this.m_PlantListFamilyTypeList[num1].Status != FamilyParameterWrapperStatus.Excluded)
        {
          index = this.m_MixListView.SelectedItems.IndexOfKey(this.m_PlantListFamilyTypeList[num1].FamilyTypeWrapper.FamilyTypeName);
          if (index >= 0)
            break;
        }
      }
      using (AddModifyMix addModifyMix = new AddModifyMix(this.m_ParameterList, ref this.m_PlantListFamilyTypeList, this.m_CurDocument.GetUnits(), this.m_DisplayUnitSystem, this.m_FormatOptions, this.m_UnitSymbolType, this.m_DecimalSymbolType, num1, this.m_DlgType))
      {
        int num2 = (int) addModifyMix.ShowDialog();
        if (addModifyMix.DialogResult != DialogResult.OK)
          return;
        this.UpdateList(this.m_MixListView.SelectedIndices[index], num1, true);
      }
    }
    else
    {
      string empty = string.Empty;
      int num = (int) RevitMessageBox.Show(this.m_DlgType != DialogType.PlantMix ? EPShared.LocalRM.GetString("NoPatioWalkSelected") : EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void OnDeleteButtonClicked(object sender, EventArgs e)
  {
    if (this.m_MixListView.SelectedItems.Count >= 1)
    {
      for (int index1 = this.m_PlantListFamilyTypeList.Count - 1; index1 >= 0; --index1)
      {
        int index2 = this.m_MixListView.SelectedItems.IndexOfKey(this.m_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
        if (index2 >= 0)
        {
          this.m_PlantListFamilyTypeList.RemoveAt(index1);
          this.m_MixListView.SelectedItems[index2].Remove();
          if (this.m_MixListView.SelectedItems.Count == 0)
            break;
        }
      }
    }
    else
    {
      string empty = string.Empty;
      int num = (int) RevitMessageBox.Show(this.m_DlgType != DialogType.PlantMix ? EPShared.LocalRM.GetString("NoPatioWalkSelected") : EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void CleanMix()
  {
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList1 = new List<FamilyParameterTypeWrapper>();
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList2 = this.m_DlgType != DialogType.PlantMix ? ManagePlants.PatioWalkParamenterList() : ManagePlants.PlantMixParamenterList();
    bool flag = false;
    for (int index1 = 0; index1 < this.m_PlantListFamilyTypeList.Count; ++index1)
    {
      List<FamilyParameterWrapper> parameterWrapperList = new List<FamilyParameterWrapper>();
      for (int index2 = 0; index2 < parameterTypeWrapperList2.Count; ++index2)
      {
        for (int index3 = 0; index3 < this.m_PlantListFamilyTypeList[index1].FamilyParameterList.Count; ++index3)
        {
          if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index3].ParameterName, true) == 0)
          {
            parameterWrapperList.Add(this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index3]);
            flag = true;
            break;
          }
        }
        if (!flag)
        {
          if (this.m_DlgType == DialogType.PlantMix)
          {
            if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, this.m_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName, (StorageType) 3);
              parameterWrapperList.Add(parameterWrapper);
            }
            else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, "", (StorageType) 3);
              parameterWrapperList.Add(parameterWrapper);
            }
            else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, RevitParameters.PlantMixSpacingMethodTriangular, (StorageType) 3);
              parameterWrapperList.Add(parameterWrapper);
            }
            else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, "0.0", (StorageType) 2);
              parameterWrapperList.Add(parameterWrapper);
            }
          }
          else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, this.m_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName, (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
          }
          else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, "", (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
          }
          else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, "", (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
          }
          else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, RevitParameters.NoString, (StorageType) 1);
            parameterWrapperList.Add(parameterWrapper);
          }
          else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.MaterialPathWalkFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, ApplicationUtility.GetString(" "), (StorageType) 3);
            parameterWrapperList.Add(parameterWrapper);
          }
          else if (string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index2].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
          {
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index2].ParameterDisplayName, parameterTypeWrapperList2[index2].ParameterName, "0.0", (StorageType) 2);
            parameterWrapperList.Add(parameterWrapper);
          }
        }
      }
      flag = false;
      string empty = string.Empty;
      for (int index4 = 0; index4 < parameterTypeWrapperList2.Count; ++index4)
      {
        for (int index5 = 0; index5 < parameterWrapperList.Count; ++index5)
        {
          if (string.Compare(parameterTypeWrapperList2[index4].ParameterName, parameterWrapperList[index5].ParameterName, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
        {
          StorageType _StorageType;
          string _strParameterValue;
          if (string.Compare(parameterTypeWrapperList2[index4].ParameterName, RevitParameters.PlantSpacingPlantFamilyParameter, true) == 0)
          {
            _StorageType = (StorageType) 2;
            _strParameterValue = "0.0";
          }
          else
          {
            _StorageType = (StorageType) 3;
            _strParameterValue = "";
          }
          FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index4].ParameterDisplayName, parameterTypeWrapperList2[index4].ParameterName, _strParameterValue, _StorageType);
          parameterWrapperList.Insert(index4, parameterWrapper);
        }
        flag = false;
      }
      this.m_PlantListFamilyTypeList[index1].FamilyParameterList = parameterWrapperList;
    }
  }

  private void UpdateList(int _nSelectedListIndex, int _nFamilyTypeListIndex, bool _bModify)
  {
    if (_bModify)
      this.m_MixListView.Items.RemoveAt(_nSelectedListIndex);
    else
      --_nFamilyTypeListIndex;
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList1 = new List<FamilyParameterTypeWrapper>();
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList2 = ManagePlants.PlantMixParamenterList();
    List<FamilyParameterWrapper> parameterWrapperList = new List<FamilyParameterWrapper>();
    if (!_bModify)
    {
      if (this.m_DlgType == DialogType.PlantMix)
      {
        bool flag1 = false;
        for (int index1 = 0; index1 < parameterTypeWrapperList2.Count; ++index1)
        {
          for (int index2 = 0; index2 < this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList.Count; ++index2)
          {
            if (string.Compare(parameterTypeWrapperList2[index1].ParameterName, this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList[index2].ParameterName, true) == 0)
            {
              parameterWrapperList.Add(this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList[index2]);
              flag1 = true;
              break;
            }
          }
          if (!flag1)
          {
            if (string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.TypeNamePlantFamilyType, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index1].ParameterDisplayName, parameterTypeWrapperList2[index1].ParameterName, this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, (StorageType) 3);
              parameterWrapperList.Add(parameterWrapper);
              continue;
            }
            if (string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index1].ParameterDisplayName, parameterTypeWrapperList2[index1].ParameterName, "", (StorageType) 3);
              parameterWrapperList.Add(parameterWrapper);
              continue;
            }
            if (string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index1].ParameterDisplayName, parameterTypeWrapperList2[index1].ParameterName, RevitParameters.PlantMixSpacingMethodTriangular, (StorageType) 3);
              parameterWrapperList.Add(parameterWrapper);
              continue;
            }
            if (string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0 || string.Compare(parameterTypeWrapperList2[index1].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
            {
              FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index1].ParameterDisplayName, parameterTypeWrapperList2[index1].ParameterName, "0.0", (StorageType) 2);
              parameterWrapperList.Add(parameterWrapper);
              continue;
            }
          }
          flag1 = false;
        }
        bool flag2 = false;
        string empty = string.Empty;
        for (int index3 = 0; index3 < parameterTypeWrapperList2.Count; ++index3)
        {
          for (int index4 = 0; index4 < parameterWrapperList.Count; ++index4)
          {
            if (string.Compare(parameterTypeWrapperList2[index3].ParameterName, parameterWrapperList[index4].ParameterName, true) == 0)
            {
              flag2 = true;
              break;
            }
          }
          if (!flag2)
          {
            StorageType _StorageType = (StorageType) 3;
            string _strParameterValue = "";
            FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(parameterTypeWrapperList2[index3].ParameterDisplayName, parameterTypeWrapperList2[index3].ParameterName, _strParameterValue, _StorageType);
            parameterWrapperList.Insert(index3, parameterWrapper);
          }
          flag2 = false;
        }
      }
      else
        parameterWrapperList = this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList;
    }
    else
      parameterWrapperList = this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList;
    string empty1 = string.Empty;
    ListViewItem listViewItem = new ListViewItem();
    listViewItem.Tag = (object) this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
    for (int index = 0; index < parameterWrapperList.Count; ++index)
    {
      string _strToDisplay = parameterWrapperList[index].Value;
      if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
      {
        if (this.m_DlgType == DialogType.PlantMix)
        {
          if (_strToDisplay == null)
            _strToDisplay = string.Empty;
          if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
          {
            double _dConvertedDouble = 1.0;
            if (_strToDisplay != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
          }
          else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
          {
            double num = 1.0;
            if (_strToDisplay != string.Empty)
              num = ValueConversion.ToDouble(_strToDisplay);
            _strToDisplay = Convert.ToString(num);
          }
        }
        else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, true) == 0)
        {
          double _dConvertedDouble = 1.0;
          if (_strToDisplay != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
        }
        else if (string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, true) == 0 || string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, true) == 0)
          _strToDisplay = string.Compare(_strToDisplay, "1", true) != 0 ? (string.Compare(_strToDisplay, "0", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString")) : EPShared.LocalRM.GetString("YesString");
        else if (_strToDisplay == string.Empty && string.Compare(parameterWrapperList[index].ParameterName, RevitParameters.MaterialPathWalkFamilyParameter, true) == 0)
          _strToDisplay = this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
        if (index == 0)
        {
          listViewItem = !_bModify ? this.m_MixListView.Items.Add(this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, _strToDisplay, string.Empty) : this.m_MixListView.Items.Insert(_nSelectedListIndex, this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, _strToDisplay, string.Empty);
          listViewItem.Tag = (object) this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
        }
        else
          listViewItem.SubItems.Add(_strToDisplay);
      }
    }
    this.m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList = parameterWrapperList;
  }

  private void DestinationFileChooserBtnClicked(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_DestinationTextBox.Text = saveFileDialog.FileName;
  }

  private void OnEqualButtonClick(object sender, EventArgs e)
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index1 = 0; index1 < this.m_PlantListFamilyTypeList.Count; ++index1)
    {
      int count = this.m_PlantListFamilyTypeList[index1].FamilyParameterList.Count;
      for (int index2 = 0; index2 < count; ++index2)
      {
        if (string.Compare(this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
        {
          double num = 100.0 / (double) this.m_PlantListFamilyTypeList.Count;
          this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].Value = ValueConversion.Format("{0:F2}", (object) num);
          break;
        }
      }
    }
    this.RefreshListView();
  }

  private void RefreshListView()
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    this.m_MixListView.Items.Clear();
    string empty3 = string.Empty;
    string empty4 = string.Empty;
    for (int index1 = 0; index1 < this.m_PlantListFamilyTypeList.Count; ++index1)
    {
      int count = this.m_PlantListFamilyTypeList[index1].FamilyParameterList.Count;
      ListViewItem listViewItem = new ListViewItem();
      for (int index2 = 0; index2 < count; ++index2)
      {
        string parameterName = this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].ParameterName;
        string _strToDisplay = this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].Value;
        if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, true) != 0 && string.Compare(parameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) != 0 && string.Compare(parameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, true) != 0)
        {
          if (string.Compare(parameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, true) == 0)
          {
            double _dConvertedDouble = 1.0;
            if (_strToDisplay != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
          }
          if (index2 == 0)
          {
            listViewItem = this.m_MixListView.Items.Add(this.m_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName, _strToDisplay, string.Empty);
            listViewItem.Tag = (object) this.m_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName;
          }
          else
            listViewItem.SubItems.Add(_strToDisplay);
        }
      }
    }
  }

  private bool CheckPercentage()
  {
    if (this.m_PlantListFamilyTypeList == null || this.m_PlantListFamilyTypeList.Count <= 0)
      return false;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    double a = 0.0;
    for (int index1 = 0; index1 < this.m_PlantListFamilyTypeList.Count; ++index1)
    {
      int count = this.m_PlantListFamilyTypeList[index1].FamilyParameterList.Count;
      for (int index2 = 0; index2 < count; ++index2)
      {
        if (string.Compare(this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, true) == 0)
        {
          if (this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].Value != null && this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].Value != string.Empty)
          {
            a += ValueConversion.ToDouble(this.m_PlantListFamilyTypeList[index1].FamilyParameterList[index2].Value);
            break;
          }
          break;
        }
      }
    }
    return Math.Round(a) <= 100.0;
  }

  private void MixListViewDoubleClicked(object sender, EventArgs e) => this.Modify();

  private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nMixtListViewSortColumn)
    {
      this.m_nMixtListViewSortColumn = e.Column;
      this.m_MixListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_MixListView.Sorting = this.m_MixListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_MixListView.Sort();
    this.m_MixListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_MixListView.Sorting);
  }

  private void OnDestinationTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.AddExtensionToDestination();
  }

  private void RFAOpenFileButtonClicked(object sender, EventArgs e)
  {
    OpenFileDialog openFileDialog = new OpenFileDialog();
    openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    openFileDialog.FilterIndex = 1;
    openFileDialog.RestoreDirectory = true;
    if (openFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_SourceTxtBox.Text = openFileDialog.FileName;
    this.LoadData();
  }

  private void AddExtensionToDestination()
  {
    if (string.IsNullOrEmpty(this.m_DestinationTextBox.Text) || !(new FileInfo(this.m_DestinationTextBox.Text).Extension == string.Empty))
      return;
    this.m_DestinationTextBox.Text += ".rfa";
  }

  private void OnDestinationTextBoxLeaveFocus(object sender, EventArgs e)
  {
    this.AddExtensionToDestination();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_DynGroupBox = new GroupBox();
    this.m_ModifyButton = new Button();
    this.m_EqualButton = new Button();
    this.m_DeleteButton = new Button();
    this.m_AddButton = new Button();
    this.m_SearchButton = new Button();
    this.m_MixListView = new ListView();
    this.m_DestinationGroupBox = new GroupBox();
    this.m_DestinationTextBox = new TextBox();
    this.m_DestinationFileChooserBtn = new Button();
    this.m_DestinationFileLbl = new Label();
    this.m_SaveFamilyButton = new Button();
    this.m_CancelButton = new Button();
    this.m_SourceGroupBox = new GroupBox();
    this.m_SourceTxtBox = new TextBox();
    this.m_RFAOpenFileButton = new Button();
    this.m_SourceFileLbl = new Label();
    this.m_DynGroupBox.SuspendLayout();
    this.m_DestinationGroupBox.SuspendLayout();
    this.m_SourceGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_DynGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DynGroupBox.Controls.Add((Control) this.m_ModifyButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_EqualButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_DeleteButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_AddButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_SearchButton);
    this.m_DynGroupBox.Controls.Add((Control) this.m_MixListView);
    this.m_DynGroupBox.Location = new Point(12, 2);
    this.m_DynGroupBox.Name = "m_DynGroupBox";
    this.m_DynGroupBox.Size = new Size(573, (int) byte.MaxValue);
    this.m_DynGroupBox.TabIndex = 0;
    this.m_DynGroupBox.TabStop = false;
    this.m_DynGroupBox.Text = "PlantMix";
    this.m_ModifyButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ModifyButton.Location = new Point(491, 41);
    this.m_ModifyButton.Name = "m_ModifyButton";
    this.m_ModifyButton.Size = new Size(75, 23);
    this.m_ModifyButton.TabIndex = 2;
    this.m_ModifyButton.Text = "Modify";
    this.m_ModifyButton.UseVisualStyleBackColor = true;
    this.m_ModifyButton.Click += new EventHandler(this.OnModifyButtonClicked);
    this.m_EqualButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_EqualButton.Location = new Point(491, 100);
    this.m_EqualButton.Name = "m_EqualButton";
    this.m_EqualButton.Size = new Size(75, 23);
    this.m_EqualButton.TabIndex = 4;
    this.m_EqualButton.Text = "Equal";
    this.m_EqualButton.UseVisualStyleBackColor = true;
    this.m_EqualButton.Click += new EventHandler(this.OnEqualButtonClick);
    this.m_DeleteButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_DeleteButton.Location = new Point(491, 70);
    this.m_DeleteButton.Name = "m_DeleteButton";
    this.m_DeleteButton.Size = new Size(75, 24);
    this.m_DeleteButton.TabIndex = 3;
    this.m_DeleteButton.Text = "Delete";
    this.m_DeleteButton.UseVisualStyleBackColor = true;
    this.m_DeleteButton.Click += new EventHandler(this.OnDeleteButtonClicked);
    this.m_AddButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_AddButton.Location = new Point(491, 12);
    this.m_AddButton.Name = "m_AddButton";
    this.m_AddButton.Size = new Size(75, 23);
    this.m_AddButton.TabIndex = 1;
    this.m_AddButton.Text = "Add";
    this.m_AddButton.UseVisualStyleBackColor = true;
    this.m_AddButton.Click += new EventHandler(this.OnAddButtonClicked);
    this.m_SearchButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_SearchButton.Location = new Point(491, 129);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(75, 23);
    this.m_SearchButton.TabIndex = 5;
    this.m_SearchButton.Text = "Search";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButtonClicked);
    this.m_MixListView.Anchor = AnchorStyles.Left | AnchorStyles.Right;
    this.m_MixListView.FullRowSelect = true;
    this.m_MixListView.HideSelection = false;
    this.m_MixListView.Location = new Point(7, 13);
    this.m_MixListView.Name = "m_MixListView";
    this.m_MixListView.Size = new Size(479, 235);
    this.m_MixListView.TabIndex = 0;
    this.m_MixListView.UseCompatibleStateImageBehavior = false;
    this.m_MixListView.DoubleClick += new EventHandler(this.MixListViewDoubleClicked);
    this.m_MixListView.ColumnClick += new ColumnClickEventHandler(this.OnMixListViewColumnClick);
    this.m_DestinationGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DestinationGroupBox.Controls.Add((Control) this.m_DestinationTextBox);
    this.m_DestinationGroupBox.Controls.Add((Control) this.m_DestinationFileChooserBtn);
    this.m_DestinationGroupBox.Controls.Add((Control) this.m_DestinationFileLbl);
    this.m_DestinationGroupBox.Location = new Point(12, 309);
    this.m_DestinationGroupBox.Name = "m_DestinationGroupBox";
    this.m_DestinationGroupBox.Size = new Size(573, 49);
    this.m_DestinationGroupBox.TabIndex = 2;
    this.m_DestinationGroupBox.TabStop = false;
    this.m_DestinationGroupBox.Text = "Destination";
    this.m_DestinationTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DestinationTextBox.Location = new Point(68, 17);
    this.m_DestinationTextBox.Name = "m_DestinationTextBox";
    this.m_DestinationTextBox.Size = new Size(468, 20);
    this.m_DestinationTextBox.TabIndex = 1;
    this.m_DestinationTextBox.KeyDown += new KeyEventHandler(this.OnDestinationTextBoxKeyDown);
    this.m_DestinationTextBox.Leave += new EventHandler(this.OnDestinationTextBoxLeaveFocus);
    this.m_DestinationFileChooserBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DestinationFileChooserBtn.Location = new Point(542, 16 /*0x10*/);
    this.m_DestinationFileChooserBtn.Name = "m_DestinationFileChooserBtn";
    this.m_DestinationFileChooserBtn.Size = new Size(24, 20);
    this.m_DestinationFileChooserBtn.TabIndex = 2;
    this.m_DestinationFileChooserBtn.Text = "...";
    this.m_DestinationFileChooserBtn.UseVisualStyleBackColor = true;
    this.m_DestinationFileChooserBtn.Click += new EventHandler(this.DestinationFileChooserBtnClicked);
    this.m_DestinationFileLbl.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DestinationFileLbl.AutoSize = true;
    this.m_DestinationFileLbl.Location = new Point(4, 20);
    this.m_DestinationFileLbl.Name = "m_DestinationFileLbl";
    this.m_DestinationFileLbl.Size = new Size(23, 13);
    this.m_DestinationFileLbl.TabIndex = 0;
    this.m_DestinationFileLbl.Text = "File";
    this.m_SaveFamilyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_SaveFamilyButton.Location = new Point(412, 364);
    this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
    this.m_SaveFamilyButton.Size = new Size(92, 23);
    this.m_SaveFamilyButton.TabIndex = 3;
    this.m_SaveFamilyButton.Text = "Save Family";
    this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
    this.m_SaveFamilyButton.Click += new EventHandler(this.SaveFamilyButtonClicked);
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.Location = new Point(510, 364);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.CancelButtonClicked);
    this.m_SourceGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SourceTxtBox);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_RFAOpenFileButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SourceFileLbl);
    this.m_SourceGroupBox.Location = new Point(12, 259);
    this.m_SourceGroupBox.Name = "m_SourceGroupBox";
    this.m_SourceGroupBox.Size = new Size(573, 46);
    this.m_SourceGroupBox.TabIndex = 1;
    this.m_SourceGroupBox.TabStop = false;
    this.m_SourceGroupBox.Text = "Source";
    this.m_SourceTxtBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SourceTxtBox.Location = new Point(68, 17);
    this.m_SourceTxtBox.Name = "m_SourceTxtBox";
    this.m_SourceTxtBox.Size = new Size(468, 20);
    this.m_SourceTxtBox.TabIndex = 1;
    this.m_SourceTxtBox.KeyDown += new KeyEventHandler(this.OnSourceTxtBoxKeyDown);
    this.m_SourceTxtBox.Leave += new EventHandler(this.OnSingleFileTextBoxLeaveFocus);
    this.m_RFAOpenFileButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_RFAOpenFileButton.Location = new Point(542, 16 /*0x10*/);
    this.m_RFAOpenFileButton.Name = "m_RFAOpenFileButton";
    this.m_RFAOpenFileButton.Size = new Size(24, 20);
    this.m_RFAOpenFileButton.TabIndex = 2;
    this.m_RFAOpenFileButton.Text = "...";
    this.m_RFAOpenFileButton.UseVisualStyleBackColor = true;
    this.m_RFAOpenFileButton.Click += new EventHandler(this.RFAOpenFileButtonClicked);
    this.m_SourceFileLbl.AutoSize = true;
    this.m_SourceFileLbl.Location = new Point(6, 20);
    this.m_SourceFileLbl.Name = "m_SourceFileLbl";
    this.m_SourceFileLbl.Size = new Size(23, 13);
    this.m_SourceFileLbl.TabIndex = 0;
    this.m_SourceFileLbl.Text = "File";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(590, 399);
    this.Controls.Add((Control) this.m_SourceGroupBox);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_SaveFamilyButton);
    this.Controls.Add((Control) this.m_DestinationGroupBox);
    this.Controls.Add((Control) this.m_DynGroupBox);
    this.MinimumSize = new Size(598, 426);
    this.Name = nameof (PlantMixFamilyManager);
    this.Text = nameof (PlantMixFamilyManager);
    this.FormClosing += new FormClosingEventHandler(this.OnPlantMixFamilyManagerFormClosing);
    this.m_DynGroupBox.ResumeLayout(false);
    this.m_DestinationGroupBox.ResumeLayout(false);
    this.m_DestinationGroupBox.PerformLayout();
    this.m_SourceGroupBox.ResumeLayout(false);
    this.m_SourceGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_SaveFamilyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
