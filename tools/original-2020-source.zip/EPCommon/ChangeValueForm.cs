﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ChangeValueForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ChangeValueForm : EPForm
{
  private Units m_Units;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private UnitType m_UnitType;
  private DecimalSymbol m_DecimalSymbolType;
  private bool m_bIsUnitValue;
  private bool m_bIsRatioValue;
  private IContainer components;
  private Button m_OKButton;
  private Button m_CancelButton;
  private Label m_NewValueLabel;
  private TextBox m_NewFieldTextBox;
  private Label m_CurrentValueLabel;
  private Label m_CurrentFieldLabel;
  private Label m_CurrentValueRatioLabel;
  private Label m_NewValueRatioLabel;

  public ChangeValueForm(
    Document _Document,
    string _strFormTitle,
    string _strCurrentValueLabel,
    string _strNewValueLabel,
    double _dCurrentValue,
    UnitType _UnitType,
    string _contextID)
  {
    this.InitializeComponent();
    this.Text = _strFormTitle;
    this.m_CurrentValueLabel.Text = _strCurrentValueLabel;
    this.m_NewValueLabel.Text = _strNewValueLabel;
    this.m_UnitType = _UnitType;
    this.m_FormatOptions = _Document.GetUnits().GetFormatOptions(this.m_UnitType);
    this.m_DisplayUnitSystem = _Document.DisplayUnitSystem;
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = _Document.GetUnits().DecimalSymbol;
    this.ContextualHelpID = _contextID;
    this.m_bIsUnitValue = true;
    this.m_bIsRatioValue = false;
    this.m_Units = _Document.GetUnits();
    this.InitializeControls(_dCurrentValue);
  }

  public ChangeValueForm(
    Document _Document,
    string _strFormTitle,
    string _strCurrentValueLabel,
    string _strNewValueLabel,
    int _nCurrentValue,
    bool _bIsRatioValue,
    string _contextID)
  {
    this.InitializeComponent();
    this.Text = _strFormTitle;
    this.m_CurrentValueLabel.Text = _strCurrentValueLabel;
    this.m_NewValueLabel.Text = _strNewValueLabel;
    this.ContextualHelpID = _contextID;
    this.m_bIsUnitValue = false;
    this.m_bIsRatioValue = _bIsRatioValue;
    this.m_Units = _Document.GetUnits();
    this.InitializeControls(_nCurrentValue);
  }

  private void InitializeControls(double _dCurrentValue)
  {
    string empty = string.Empty;
    this.GetDialogPosition();
    RevitGeometry.Units_ConvertDoubleToString(_dCurrentValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
    this.m_CurrentFieldLabel.Text = empty;
    this.m_NewFieldTextBox.Text = empty;
    this.m_CurrentValueRatioLabel.Visible = this.m_bIsRatioValue;
    this.m_NewValueRatioLabel.Visible = this.m_bIsRatioValue;
    if (this.m_bIsRatioValue)
      return;
    Point location1 = this.m_CurrentFieldLabel.Location;
    location1.X -= this.m_CurrentValueRatioLabel.Width;
    this.m_CurrentFieldLabel.Location = location1;
    Point location2 = this.m_NewFieldTextBox.Location;
    location2.X -= this.m_CurrentValueRatioLabel.Width;
    this.m_NewFieldTextBox.Location = location2;
    Point location3 = this.m_OKButton.Location;
    location3.X -= this.m_CurrentValueRatioLabel.Width;
    this.m_OKButton.Location = location3;
    Point location4 = this.m_CancelButton.Location;
    location4.X -= this.m_CurrentValueRatioLabel.Width;
    this.m_CancelButton.Location = location4;
    Size size = this.Size;
    size.Width -= this.m_CurrentValueRatioLabel.Width;
    this.Size = size;
  }

  private void InitializeControls(int _nCurrentValue)
  {
    this.GetDialogPosition();
    this.m_CurrentFieldLabel.Text = Convert.ToString(_nCurrentValue);
    this.m_NewFieldTextBox.Text = Convert.ToString(_nCurrentValue);
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnNewFieldTextBoxLeave(object sender, EventArgs e) => this.FormatNewFieldValue();

  private void OnNewFieldTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatNewFieldValue();
  }

  private void FormatNewFieldValue()
  {
    if (!this.m_bIsUnitValue)
      return;
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    bool flag = false;
    UnitType unitType = this.m_UnitType;
    if (unitType != null)
    {
      if (unitType != 3)
      {
        if (unitType == 59)
        {
          flag = RevitGeometry.Units_ConvertStringToDouble(this.m_NewFieldTextBox.Text, this.m_Units, this.m_UnitType, ref _dReturnedDouble);
          if (flag)
            RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
        }
      }
      else if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_FormatOptions.DisplayUnits, RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_NewFieldTextBox.Text), this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_DecimalSymbolType, ref empty) == 0)
        flag = true;
    }
    else
    {
      flag = RevitGeometry.Units_ConvertStringToDouble(this.m_NewFieldTextBox.Text, this.m_Units, this.m_UnitType, ref _dReturnedDouble);
      if (flag)
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
    }
    if (flag)
      this.m_NewFieldTextBox.Text = empty;
    else
      this.m_NewFieldTextBox.Focus();
  }

  private void OnChangeValueClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public double NewUnitFieldValue
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_NewFieldTextBox.Text != string.Empty)
      {
        UnitType unitType = this.m_UnitType;
        if (unitType != null)
        {
          if (unitType != 3)
          {
            if (unitType == 59)
              RevitGeometry.Units_ConvertStringToDouble(this.m_NewFieldTextBox.Text, this.m_Units, this.m_UnitType, ref _dReturnedDouble);
          }
          else
            _dReturnedDouble = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_NewFieldTextBox.Text);
        }
        else
          RevitGeometry.Units_ConvertStringToDouble(this.m_NewFieldTextBox.Text, this.m_Units, this.m_UnitType, ref _dReturnedDouble);
      }
      return _dReturnedDouble;
    }
  }

  public int NewIntegerFieldValue
  {
    get
    {
      int integerFieldValue = 0;
      if (this.m_NewFieldTextBox.Text != string.Empty)
        integerFieldValue = Convert.ToInt32(this.m_NewFieldTextBox.Text);
      return integerFieldValue;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (ChangeValueForm));
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_NewValueLabel = new Label();
    this.m_NewFieldTextBox = new TextBox();
    this.m_CurrentValueLabel = new Label();
    this.m_CurrentFieldLabel = new Label();
    this.m_CurrentValueRatioLabel = new Label();
    this.m_NewValueRatioLabel = new Label();
    this.SuspendLayout();
    this.m_OKButton.Location = new Point(200, 64 /*0x40*/);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 6;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(281, 64 /*0x40*/);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 7;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_NewValueLabel.AutoSize = true;
    this.m_NewValueLabel.Location = new Point(12, 41);
    this.m_NewValueLabel.Name = "m_NewValueLabel";
    this.m_NewValueLabel.Size = new Size(62, 13);
    this.m_NewValueLabel.TabIndex = 3;
    this.m_NewValueLabel.Text = "New Value:";
    this.m_NewFieldTextBox.Location = new Point(136, 38);
    this.m_NewFieldTextBox.Name = "m_NewFieldTextBox";
    this.m_NewFieldTextBox.Size = new Size(220, 20);
    this.m_NewFieldTextBox.TabIndex = 5;
    this.m_NewFieldTextBox.KeyDown += new KeyEventHandler(this.OnNewFieldTextBoxKeyDown);
    this.m_NewFieldTextBox.Leave += new EventHandler(this.OnNewFieldTextBoxLeave);
    this.m_CurrentValueLabel.AutoSize = true;
    this.m_CurrentValueLabel.Location = new Point(12, 15);
    this.m_CurrentValueLabel.Name = "m_CurrentValueLabel";
    this.m_CurrentValueLabel.Size = new Size(74, 13);
    this.m_CurrentValueLabel.TabIndex = 0;
    this.m_CurrentValueLabel.Text = "Current Value:";
    this.m_CurrentFieldLabel.AutoSize = true;
    this.m_CurrentFieldLabel.Location = new Point(133, 15);
    this.m_CurrentFieldLabel.Name = "m_CurrentFieldLabel";
    this.m_CurrentFieldLabel.Size = new Size(34, 13);
    this.m_CurrentFieldLabel.TabIndex = 2;
    this.m_CurrentFieldLabel.Text = "Value";
    this.m_CurrentValueRatioLabel.AutoSize = true;
    this.m_CurrentValueRatioLabel.Location = new Point(117, 15);
    this.m_CurrentValueRatioLabel.Name = "m_CurrentValueRatioLabel";
    this.m_CurrentValueRatioLabel.Size = new Size(19, 13);
    this.m_CurrentValueRatioLabel.TabIndex = 1;
    this.m_CurrentValueRatioLabel.Text = "1 :";
    this.m_NewValueRatioLabel.AutoSize = true;
    this.m_NewValueRatioLabel.Location = new Point(117, 41);
    this.m_NewValueRatioLabel.Name = "m_NewValueRatioLabel";
    this.m_NewValueRatioLabel.Size = new Size(19, 13);
    this.m_NewValueRatioLabel.TabIndex = 4;
    this.m_NewValueRatioLabel.Text = "1 :";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(368, 99);
    this.Controls.Add((Control) this.m_NewValueRatioLabel);
    this.Controls.Add((Control) this.m_CurrentValueRatioLabel);
    this.Controls.Add((Control) this.m_CurrentFieldLabel);
    this.Controls.Add((Control) this.m_CurrentValueLabel);
    this.Controls.Add((Control) this.m_NewValueLabel);
    this.Controls.Add((Control) this.m_NewFieldTextBox);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
    this.Name = nameof (ChangeValueForm);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = "Change Value";
    this.FormClosing += new FormClosingEventHandler(this.OnChangeValueClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
