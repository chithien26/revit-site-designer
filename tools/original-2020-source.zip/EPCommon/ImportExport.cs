﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ImportExport
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

internal class ImportExport
{
  public static bool ImportFileWithSeparator(
    Document _Document,
    string _strNameFileLocation,
    string _strSeparator,
    ref List<FamilyTypeContainer> FamilyImportContainerList)
  {
    StreamReader streamReader = new StreamReader((Stream) new FileStream(_strNameFileLocation, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
    string str1;
    if ((str1 = streamReader.ReadLine()) == null)
      return false;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = 10000;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarImportMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    List<KeyValuePair<string, PlantField>> keyValuePairList = new List<KeyValuePair<string, PlantField>>();
    int length = str1.IndexOf(_strSeparator);
    while (length != -1)
    {
      int num1 = str1.IndexOf("\"");
      if (num1 != -1 && num1 < length)
      {
        int num2 = str1.IndexOf("\"", num1 + 1);
        string str2 = str1.Substring(num1 + 1, num2 - 1);
        keyValuePairList.Add(new KeyValuePair<string, PlantField>(str2, ManagePlants.GetPlantFieldFromParamenter(str2)));
        str1 = num2 + 2 >= str1.Length ? string.Empty : str1.Substring(num2 + 2);
      }
      else
      {
        string str3 = str1.Substring(0, length).Trim();
        keyValuePairList.Add(new KeyValuePair<string, PlantField>(str3, ManagePlants.GetPlantFieldFromParamenter(str3)));
        str1 = str1.Substring(length + 1);
      }
      length = str1.IndexOf(_strSeparator);
      progressBarForm.UpdateProgressBar(1);
    }
    string str4 = str1.Trim().Trim("\""[0]);
    if (str4.Length > 0)
      keyValuePairList.Add(new KeyValuePair<string, PlantField>(str4, ManagePlants.GetPlantFieldFromParamenter(str4)));
    bool _bTypeNamePresent = false;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    bool flag5 = false;
    for (int index = 0; index < keyValuePairList.Count<KeyValuePair<string, PlantField>>(); ++index)
    {
      KeyValuePair<string, PlantField> keyValuePair = keyValuePairList[index];
      if (keyValuePair.Value == PlantField.PlantScientificName)
        flag1 = true;
      else if (keyValuePair.Value == PlantField.PlantCommonName)
        flag2 = true;
      else if (keyValuePair.Value == PlantField.TypeName)
        _bTypeNamePresent = true;
      else if (keyValuePair.Value == PlantField.PlantingSymbol)
        flag3 = true;
      else if (keyValuePair.Value == PlantField.GenericModelSymbol)
        flag4 = true;
      else if (keyValuePair.Value == PlantField.Height || keyValuePair.Value == PlantField.PlantHeight || keyValuePair.Value == PlantField.PlantWidth || keyValuePair.Value == PlantField.CharacteristicsFoliageSize || keyValuePair.Value == PlantField.PlantSpacing)
        flag5 = true;
      progressBarForm.UpdateProgressBar(2);
    }
    DisplayUnitType _DisplayUnitType = _Document.GetUnits().GetFormatOptions((UnitType) 0).DisplayUnits;
    if (!_bTypeNamePresent && (!flag1 || !flag2))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeCommonOrScientificName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      progressBarForm.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm.Close();
      streamReader.Close();
      return false;
    }
    if (flag5)
    {
      List<string> _WarningOptions = new List<string>();
      _WarningOptions.Add(EPShared.LocalRM.GetString("UseFeetUnitsOption"));
      _WarningOptions.Add(EPShared.LocalRM.GetString("UseInchUnitsOption"));
      _WarningOptions.Add(EPShared.LocalRM.GetString("UseMeterUnitsOption"));
      _WarningOptions.Add(EPShared.LocalRM.GetString("UseCentimeterUnitsOption"));
      _WarningOptions.Add(EPShared.LocalRM.GetString("UseMillimeterUnitsOption"));
      int _nDefaultOption = -1;
      switch ((int) _DisplayUnitType)
      {
        case 0:
        case 9:
          _nDefaultOption = 2;
          break;
        case 1:
          _nDefaultOption = 3;
          break;
        case 2:
          _nDefaultOption = 4;
          break;
        case 3:
          _nDefaultOption = 0;
          break;
        case 4:
        case 5:
        case 6:
          _nDefaultOption = 1;
          break;
      }
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(_Document.PathName, "ReadPlantFile", EPShared.LocalRM.GetString("SelectedFileHasLengthMessage"), _WarningOptions, _nDefaultOption);
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK)
      {
        if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseFeetUnitsOption"), true) == 0)
          _DisplayUnitType = (DisplayUnitType) 3;
        else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseInchUnitsOption"), true) == 0)
          _DisplayUnitType = (DisplayUnitType) 6;
        else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseMeterUnitsOption"), true) == 0)
          _DisplayUnitType = (DisplayUnitType) 0;
        else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseCentimeterUnitsOption"), true) == 0)
          _DisplayUnitType = (DisplayUnitType) 1;
        else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseMillimeterUnitsOption"), true) == 0)
          _DisplayUnitType = (DisplayUnitType) 2;
      }
    }
    if (!flag3)
      keyValuePairList.Add(new KeyValuePair<string, PlantField>(ManagePlants.GetPlantParamenterName(PlantField.PlantingSymbol), PlantField.PlantingSymbol));
    if (!flag4)
      keyValuePairList.Add(new KeyValuePair<string, PlantField>(ManagePlants.GetPlantParamenterName(PlantField.GenericModelSymbol), PlantField.GenericModelSymbol));
    string _strFileLine;
    while ((_strFileLine = streamReader.ReadLine()) != null)
    {
      FamilyTypeContainer _FamilyImportContainer = new FamilyTypeContainer();
      if (!ImportExport.PopulatePlantTableFields(_strFileLine, _strSeparator, _bTypeNamePresent, keyValuePairList, _DisplayUnitType, ref _FamilyImportContainer))
      {
        progressBarForm.SetMaxValue();
        Thread.Sleep(300);
        progressBarForm.Close();
        streamReader.Close();
        return false;
      }
      FamilyImportContainerList.Add(_FamilyImportContainer);
      progressBarForm.UpdateProgressBar(2);
    }
    streamReader.Close();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  private static bool PopulatePlantTableFields(
    string _strFileLine,
    string _strSeparator,
    bool _bTypeNamePresent,
    List<KeyValuePair<string, PlantField>> _FieldNames,
    DisplayUnitType _DisplayUnitType,
    ref FamilyTypeContainer _FamilyImportContainer)
  {
    _FamilyImportContainer.FamilyParameterList = new List<FamilyParameterWrapper>();
    for (int index = 0; index < _FieldNames.Count; ++index)
    {
      int length = _strFileLine.IndexOf(_strSeparator);
      int num1 = _strFileLine.IndexOf("\"");
      string str;
      if (length != -1)
      {
        if (num1 != -1 && num1 < length)
        {
          int num2 = _strFileLine.IndexOf("\"", num1 + 1);
          str = _strFileLine.Substring(num1 + 1, num2 - 1);
          _strFileLine = num2 + 2 >= _strFileLine.Length ? string.Empty : _strFileLine.Substring(num2 + 2);
        }
        else
        {
          str = _strFileLine.Substring(0, length).Trim();
          _strFileLine = _strFileLine.Substring(length + 1);
        }
        if (index == _FieldNames.Count - 1 && _strFileLine.IndexOf(_strSeparator) >= 0)
        {
          int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ColumnMisMatchMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
      else
      {
        _strFileLine = _strFileLine.Trim();
        _strFileLine = _strFileLine.Trim('"');
        str = _strFileLine;
      }
      KeyValuePair<string, PlantField> fieldName = _FieldNames[index];
      if (fieldName.Value != PlantField.None)
      {
        StorageType _StorageType = (StorageType) 3;
        if (_bTypeNamePresent && fieldName.Value == PlantField.TypeName)
          _FamilyImportContainer.FamilyTypeWrapper = new FamilyTypeWrapper(str);
        else if (!_bTypeNamePresent && fieldName.Value == PlantField.PlantScientificName)
        {
          if (_FamilyImportContainer.FamilyTypeWrapper == null)
          {
            _FamilyImportContainer.FamilyTypeWrapper = new FamilyTypeWrapper("/" + str);
          }
          else
          {
            FamilyTypeWrapper familyTypeWrapper = _FamilyImportContainer.FamilyTypeWrapper;
            familyTypeWrapper.FamilyTypeName = $"{familyTypeWrapper.FamilyTypeName}/{str}";
          }
        }
        else if (!_bTypeNamePresent && fieldName.Value == PlantField.PlantCommonName)
        {
          if (_FamilyImportContainer.FamilyTypeWrapper == null)
            _FamilyImportContainer.FamilyTypeWrapper = new FamilyTypeWrapper(str);
          else
            _FamilyImportContainer.FamilyTypeWrapper.FamilyTypeName = str + _FamilyImportContainer.FamilyTypeWrapper.FamilyTypeName;
        }
        else if (fieldName.Value == PlantField.Height || fieldName.Value == PlantField.PlantHeight || fieldName.Value == PlantField.PlantWidth || fieldName.Value == PlantField.CharacteristicsFoliageSize || fieldName.Value == PlantField.PlantSpacing || fieldName.Value == PlantField.GrowthServiceLife)
        {
          _StorageType = (StorageType) 2;
          if (fieldName.Value == PlantField.Height || fieldName.Value == PlantField.PlantHeight || fieldName.Value == PlantField.PlantWidth || fieldName.Value == PlantField.CharacteristicsFoliageSize || fieldName.Value == PlantField.PlantSpacing)
          {
            double _dValue = 1.0;
            if (str != string.Empty)
              _dValue = RevitGeometry.ConvertLinearValue(ValueConversion.ToDouble(str), _DisplayUnitType, (DisplayUnitType) 3);
            str = ValueConversion.ToString(_dValue);
          }
        }
        else if (fieldName.Value == PlantField.PlantingSymbol || fieldName.Value == PlantField.GenericModelSymbol)
        {
          _StorageType = (StorageType) 4;
          str = string.Empty;
        }
        FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(fieldName.Key, fieldName.Key, str, _StorageType);
        _FamilyImportContainer.FamilyParameterList.Add(parameterWrapper);
      }
    }
    FamilyParameterWrapperComparer parameterWrapperComparer = new FamilyParameterWrapperComparer();
    _FamilyImportContainer.FamilyParameterList.Sort((IComparer<FamilyParameterWrapper>) parameterWrapperComparer);
    return true;
  }

  public static void ExportToFile(
    Document _Document,
    string _strSeperator,
    string _strExportFileName,
    List<FamilyTypeContainer> _PlantListFamilyTypeList,
    List<ParameterColumn> _ParameterList)
  {
    string empty = string.Empty;
    if (File.Exists(_strExportFileName) && RevitMessageBox.Show(EPShared.LocalRM.GetString("FileExistsOverwriteMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
      return;
    try
    {
      StreamWriter streamWriter = new StreamWriter(_strExportFileName, false, Encoding.ASCII);
      bool flag1 = false;
      List<string> paRowData1 = new List<string>();
      for (int index = 0; index < _ParameterList.Count; ++index)
      {
        if (_ParameterList[index].PlantField == PlantField.Height || _ParameterList[index].PlantField == PlantField.PlantHeight || _ParameterList[index].PlantField == PlantField.PlantWidth || _ParameterList[index].PlantField == PlantField.CharacteristicsFoliageSize || _ParameterList[index].PlantField == PlantField.PlantSpacing)
          flag1 = true;
        paRowData1.Add(ManagePlants.GetPlantParamenterName(_ParameterList[index].PlantField));
      }
      DisplayUnitType _OutputLinearDistanceType = _Document.GetUnits().GetFormatOptions((UnitType) 0).DisplayUnits;
      if (flag1)
      {
        List<string> _WarningOptions = new List<string>();
        _WarningOptions.Add(EPShared.LocalRM.GetString("UseFeetUnitsOption"));
        _WarningOptions.Add(EPShared.LocalRM.GetString("UseInchUnitsOption"));
        _WarningOptions.Add(EPShared.LocalRM.GetString("UseMeterUnitsOption"));
        _WarningOptions.Add(EPShared.LocalRM.GetString("UseCentimeterUnitsOption"));
        _WarningOptions.Add(EPShared.LocalRM.GetString("UseMillimeterUnitsOption"));
        int _nDefaultOption = -1;
        switch ((int) _OutputLinearDistanceType)
        {
          case 0:
          case 9:
            _nDefaultOption = 2;
            break;
          case 1:
            _nDefaultOption = 3;
            break;
          case 2:
            _nDefaultOption = 4;
            break;
          case 3:
            _nDefaultOption = 0;
            break;
          case 4:
          case 5:
          case 6:
            _nDefaultOption = 1;
            break;
        }
        WarningOptionsForm warningOptionsForm = new WarningOptionsForm(_Document.PathName, "WritePlantFile", EPShared.LocalRM.GetString("FieldsFoundWithLengthMessage"), _WarningOptions, _nDefaultOption);
        int num = (int) warningOptionsForm.ShowDialog();
        if (warningOptionsForm.DialogResult == DialogResult.OK)
        {
          if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseFeetUnitsOption"), true) == 0)
            _OutputLinearDistanceType = (DisplayUnitType) 3;
          else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseInchUnitsOption"), true) == 0)
            _OutputLinearDistanceType = (DisplayUnitType) 6;
          else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseMeterUnitsOption"), true) == 0)
            _OutputLinearDistanceType = (DisplayUnitType) 0;
          else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseCentimeterUnitsOption"), true) == 0)
            _OutputLinearDistanceType = (DisplayUnitType) 1;
          else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("UseMillimeterUnitsOption"), true) == 0)
            _OutputLinearDistanceType = (DisplayUnitType) 2;
        }
      }
      string fileLine1 = ImportExport.GetFileLine(paRowData1, _strSeperator);
      streamWriter.WriteLine(fileLine1);
      bool flag2 = false;
      List<string> paRowData2 = new List<string>();
      for (int index1 = 0; index1 < _PlantListFamilyTypeList.Count; ++index1)
      {
        for (int index2 = 0; index2 < paRowData1.Count; ++index2)
        {
          for (int index3 = 0; index3 < _PlantListFamilyTypeList[index1].FamilyParameterList.Count; ++index3)
          {
            FamilyParameterWrapper familyParameter = _PlantListFamilyTypeList[index1].FamilyParameterList[index3];
            if (familyParameter != null && string.Compare(paRowData1[index2], familyParameter.DisplayName, true) == 0)
            {
              if (string.Compare(familyParameter.DisplayName, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) != 0 && string.Compare(familyParameter.DisplayName, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), true) != 0 && string.Compare(familyParameter.DisplayName, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) != 0 && string.Compare(familyParameter.DisplayName, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) != 0 && string.Compare(familyParameter.DisplayName, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), true) != 0)
              {
                paRowData2.Add(familyParameter.Value);
              }
              else
              {
                double _dValue = 0.0;
                if (familyParameter.Value != string.Empty)
                  _dValue = RevitGeometry.ConvertLinearValue(ValueConversion.ToDouble(familyParameter.Value), (DisplayUnitType) 3, _OutputLinearDistanceType);
                paRowData2.Add(ValueConversion.ToString(_dValue));
              }
              flag2 = true;
              break;
            }
          }
          if (!flag2)
            paRowData2.Add(string.Empty);
          else
            flag2 = false;
        }
        string fileLine2 = ImportExport.GetFileLine(paRowData2, _strSeperator);
        streamWriter.WriteLine(fileLine2);
        paRowData2.Clear();
      }
      streamWriter.Close();
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExportCompleteMessage"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
      Process.Start($"\"{_strExportFileName}\"");
    }
    catch (Exception ex)
    {
      int num = (int) RevitMessageBox.Show(ex.Message, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private static string GetFileLine(List<string> paRowData, string szSeperator)
  {
    string fileLine = string.Empty;
    for (int index = 0; index < paRowData.Count; ++index)
    {
      if (index != 0)
        fileLine += szSeperator;
      fileLine = fileLine + "\"" + ImportExport.PadQuotesInString(paRowData[index]) + "\"";
    }
    return fileLine;
  }

  private static string PadQuotesInString(string strToPad)
  {
    string str = string.Empty;
    if (strToPad != null && strToPad != string.Empty)
    {
      int num;
      for (; (num = strToPad.IndexOf("\"")) >= 0; strToPad = strToPad.Substring(num + 1))
        str = str + strToPad.Substring(0, num + 1) + "\"";
    }
    return str + strToPad;
  }

  public static void ExportToFile(
    string _strSeperator,
    string _strExportFileName,
    List<ExportReportLine> _ReportLineList)
  {
    string empty = string.Empty;
    if (File.Exists(_strExportFileName) && RevitMessageBox.Show(EPShared.LocalRM.GetString("FileExistsOverwriteMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
      return;
    try
    {
      StreamWriter streamWriter = new StreamWriter(_strExportFileName, false, Encoding.ASCII);
      List<string> paRowData = new List<string>();
      for (int index = 0; index < _ReportLineList.Count; ++index)
      {
        if (!_ReportLineList[index].BlankLine)
        {
          paRowData.Add(_ReportLineList[index].LevelName);
          paRowData.Add(_ReportLineList[index].Parameter);
          paRowData.Add(_ReportLineList[index].Value);
          string fileLine = ImportExport.GetFileLine(paRowData, _strSeperator);
          streamWriter.WriteLine(fileLine);
          paRowData.Clear();
        }
        else
          streamWriter.WriteLine();
      }
      streamWriter.Close();
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExportCompleteMessage"), EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
      Process.Start($"\"{_strExportFileName}\"");
    }
    catch (Exception ex)
    {
      int num = (int) RevitMessageBox.Show(ex.Message, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }
}
