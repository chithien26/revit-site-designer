using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using SITES.Utilities;

namespace EPCommon;

public class CreatePlantMix
{
	private Document m_Document;

	private List<FamilySymbol> m_ListOfInstance;

	private PlantMixForm m_PlantMixForm;

	private string m_strLandcaddID;

	private string m_strPlantOrPatioWalkText;

	private CreateDialogType m_CreateDialogType;

	private EPTransactionContainer m_TransactionContainer;

	public string LandcaddIDValue => m_strLandcaddID;

	public string PlantOrPatioWalkText => m_strPlantOrPatioWalkText;

	public string FormText => EPShared.LocalRM.GetString("Assign_Message") + m_strPlantOrPatioWalkText;

	public CreateDialogType CreateDialogType => m_CreateDialogType;

	public ReadOnlyCollection<FamilySymbol> PlantMixFamilyList => new ReadOnlyCollection<FamilySymbol>(m_ListOfInstance);

	public Document Document => m_Document;

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public CreatePlantMix(CreateDialogType _CreateDialogType, Document _CurDocument)
	{
		m_CreateDialogType = _CreateDialogType;
		if (m_CreateDialogType == CreateDialogType.PlantMix)
		{
			m_strLandcaddID = Convert.ToInt32(LandcaddID.PlantMix).ToString("000");
			m_strPlantOrPatioWalkText = EPShared.LocalRM.GetString("PlantMixMessage");
		}
		else
		{
			m_strLandcaddID = Convert.ToInt32(LandcaddID.PatioWalk).ToString("000");
			m_strPlantOrPatioWalkText = EPShared.LocalRM.GetString("PatioWalkString");
		}
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_ListOfInstance = new List<FamilySymbol>();
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		PopulateFamilySymbolList();
		if (m_ListOfInstance.Count == 0)
		{
			List<string> list = new List<string>();
			list.Add(EPShared.LocalRM.GetString("LoadDefaultFamilyOption"));
			string empty = string.Empty;
			string empty2 = string.Empty;
			if (m_CreateDialogType == CreateDialogType.PlantMix)
			{
				empty = EPShared.LocalRM.GetString("PlantMixFamilyNotLoadedMessage");
				empty2 = "Sample Plant Mix - Turf mix.rfa";
				list.Add(EPShared.LocalRM.GetString("LaunchPlantMixFamilyManagerOption"));
			}
			else
			{
				empty = EPShared.LocalRM.GetString("PatioWalkFamilyNotLoadedMessage");
				empty2 = "Sample Concrete Patio with Edging.rfa";
				list.Add(EPShared.LocalRM.GetString("LaunchPatioWalkFamilyManagerOption"));
			}
			list.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamilyOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, Enum.GetName(typeof(CreateDialogType), m_CreateDialogType.GetHashCode()).ToUpper(), empty, list);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK)
			{
				if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamilyOption"), ignoreCase: true) == 0)
				{
					Family _Family = null;
					string _strFullFamilyFilename = string.Empty;
					if (RevitUtility.GetFullFamilyFilenameIfExist(empty2, ref _strFullFamilyFilename))
					{
						if (m_CreateDialogType == CreateDialogType.PlantMix)
						{
							m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantMixFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
						}
						else
						{
							m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPatioWalkFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
						}
						RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
						m_TransactionContainer.Commit();
						if (_Family != null && _Family.GetFamilySymbolIds() != null)
						{
							foreach (ElementId familySymbolId in _Family.GetFamilySymbolIds())
							{
								if (m_Document.GetElement(familySymbolId) is FamilySymbol item)
								{
									m_ListOfInstance.Add(item);
								}
							}
						}
					}
				}
				else if (string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LaunchPlantMixFamilyManagerOption"), ignoreCase: true) == 0 || string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LaunchPatioWalkFamilyManagerOption"), ignoreCase: true) == 0)
				{
					DialogType type = DialogType.PlantMix;
					if (m_CreateDialogType == CreateDialogType.PatioWalk)
					{
						type = DialogType.Patio;
					}
					using PlantMixFamilyManager plantMixFamilyManager = new PlantMixFamilyManager(type, m_Document);
					plantMixFamilyManager.ShowDialog();
					PopulateFamilySymbolList();
				}
			}
		}
		if (m_ListOfInstance.Count == 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
		m_PlantMixForm = new PlantMixForm(this);
		m_PlantMixForm.ShowDialog();
		if (m_PlantMixForm.DialogResult != DialogResult.OK)
		{
			return false;
		}
		while (m_PlantMixForm.ApplyStatus)
		{
			if (SelectPlantMix(m_PlantMixForm.RegionName))
			{
				m_TransactionContainer.Commit();
			}
			else
			{
				m_TransactionContainer.Rollback();
			}
			m_PlantMixForm = new PlantMixForm(this);
			m_PlantMixForm.ShowDialog();
			if (m_PlantMixForm.DialogResult != DialogResult.OK)
			{
				return false;
			}
		}
		if (SelectPlantMix(m_PlantMixForm.RegionName))
		{
			m_TransactionContainer.Commit();
		}
		else
		{
			m_TransactionContainer.Rollback();
		}
		return true;
	}

	private bool SelectPlantMix(string _strRegionName)
	{
		string empty = string.Empty;
		List<Element> list = new List<Element>();
		Reference reference = null;
		try
		{
			UIDocument uIDocument = new UIDocument(m_Document);
			reference = uIDocument.Selection.PickObject(ObjectType.Element, EPShared.LocalRM.GetString("PickRegionSubRegionMessage"));
		}
		catch (Autodesk.Revit.Exceptions.OperationCanceledException)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return false;
		}
		if (reference != null && m_Document.GetElement(reference) != null)
		{
			Element element = null;
			element = m_Document.GetElement(reference);
			empty = element.Name;
			if (string.Compare(empty, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), ignoreCase: true) != 0 && string.Compare(empty, EPShared.LocalRM.GetString("SubRegionElement"), ignoreCase: true) != 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRegion"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			string uniqueId = element.UniqueId;
			Parameter LandcaddIDParameter = null;
			FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
			filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_GenericModel);
			FamilyInstance FindFamilyInstance = null;
			IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => (FindFamilyInstance = CurrentElement as FamilyInstance) != null && (LandcaddIDParameter = FindFamilyInstance.Symbol.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), m_strLandcaddID, ignoreCase: true) == 0);
			List<Element> list2 = source.ToList();
			if (m_CreateDialogType == CreateDialogType.PlantMix)
			{
				m_TransactionContainer.Start(EPShared.LocalRM.GetString("AssignPlantMixTransaction"));
			}
			else
			{
				m_TransactionContainer.Start(EPShared.LocalRM.GetString("AssignPatioWalkTransaction"));
			}
			Parameter parameter = null;
			foreach (Element item in list2)
			{
				if (!(item is FamilyInstance { Category: not null } familyInstance) || familyInstance.Category.Id.Value64() != BuiltInCategory.OST_GenericModel.GetHashCode())
				{
					continue;
				}
				LandcaddIDParameter = familyInstance.Symbol.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
				if (LandcaddIDParameter == null || string.Compare(LandcaddIDParameter.AsString(), m_strLandcaddID, ignoreCase: true) != 0)
				{
					continue;
				}
				Parameter parameter2 = familyInstance.LookupParameter(RevitParameters.RegionNameGenericModelFamilyParameter);
				if (parameter2 != null && m_PlantMixForm.AssignRegion && string.Compare(parameter2.AsString(), _strRegionName, ignoreCase: true) == 0)
				{
					RevitMessageBox.Show(_strRegionName + " " + EPShared.LocalRM.GetString("_RegionNameAlreadyAssigned_Message") + " " + element.Name, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				parameter = familyInstance.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
				if (parameter == null || string.Compare(parameter.AsString(), uniqueId, ignoreCase: true) != 0)
				{
					continue;
				}
				if (parameter2 != null)
				{
					empty = parameter2.AsString();
				}
				if (m_PlantMixForm.AssignRegion)
				{
					DialogResult dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("OverWrite_Message") + m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_AssignTo_Message") + empty + "?", EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
					if (dialogResult == DialogResult.No)
					{
						return false;
					}
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(familyInstance.Id);
					m_TransactionContainer.EndTransaction();
					continue;
				}
				DialogResult dialogResult2 = RevitMessageBox.Show(EPShared.LocalRM.GetString("Unassign_Message") + m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_From_Message") + empty + "?", EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
				if (dialogResult2 == DialogResult.Yes)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(familyInstance.Id);
					m_TransactionContainer.EndTransaction();
					return true;
				}
				return false;
			}
			if (m_PlantMixForm.AssignRegion)
			{
				FamilySymbol familySymbol = m_PlantMixForm.SelectedFamilySymbol;
				if (familySymbol == null)
				{
					using OpenFileDialog openFileDialog = new OpenFileDialog();
					openFileDialog.Title = m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyNotLoaded_Message") + m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyFileMessage");
					openFileDialog.RestoreDirectory = true;
					openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
					bool flag = false;
					DialogResult dialogResult3 = DialogResult.OK;
					while (dialogResult3 != DialogResult.Cancel)
					{
						dialogResult3 = openFileDialog.ShowDialog();
						if (dialogResult3 == DialogResult.Cancel)
						{
							continue;
						}
						try
						{
							flag = RevitUtility.LoadFamily(m_Document, openFileDialog.FileName, _bUseFailureHandling: true, ref m_TransactionContainer);
						}
						catch (SEHException ex2)
						{
							flag = false;
							if (string.Compare(ex2.Message, EPShared.LocalRM.GetString("ExternalComponentExceptionMessage"), ignoreCase: true) == 0)
							{
								RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyCannotbeLoadedPickanother_Message") + m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							}
							continue;
						}
						break;
					}
					if (!flag)
					{
						RevitMessageBox.Show(m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_FamilyCannotBePlaceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					familySymbol = FindFamilySymbol();
				}
				if (familySymbol != null)
				{
					int num = 0;
					Parameter parameter3 = familySymbol.LookupParameter(RevitParameters.EdgePathWalkFamilyParameter);
					if (parameter3 != null)
					{
						num = parameter3.AsInteger();
					}
					if (string.Compare(empty, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), ignoreCase: true) == 0 && num == 1)
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("NoLinearFootageMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
					}
				}
				return SetFamilyInstance(element, familySymbol, _strRegionName, uniqueId);
			}
			RevitMessageBox.Show(EPShared.LocalRM.GetString("RegionSelectedNotAssignedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		}
		return true;
	}

	private FamilySymbol FindFamilySymbol()
	{
		FamilySymbol result = null;
		List<FamilySymbol> list = LoadFamilySymbols(_bFindFirstSymbol: true);
		if (list.Count > 0)
		{
			result = list[0];
		}
		return result;
	}

	public void PopulateFamilySymbolList()
	{
		m_ListOfInstance = LoadFamilySymbols(_bFindFirstSymbol: false);
	}

	private List<FamilySymbol> LoadFamilySymbols(bool _bFindFirstSymbol)
	{
		List<FamilySymbol> list = new List<FamilySymbol>();
		Parameter LandcaddIDParameter = null;
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel);
		IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => (LandcaddIDParameter = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), m_strLandcaddID, ignoreCase: true) == 0);
		List<Element> list2 = source.ToList();
		bool flag = false;
		foreach (Element item in list2)
		{
			if (!(item is FamilySymbol { Category: not null, Family: not null } familySymbol) || familySymbol.Category.Id.Value64() != BuiltInCategory.OST_GenericModel.GetHashCode())
			{
				continue;
			}
			LandcaddIDParameter = familySymbol.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
			if (LandcaddIDParameter == null || string.Compare(LandcaddIDParameter.AsString(), m_strLandcaddID, ignoreCase: true) != 0)
			{
				continue;
			}
			flag = false;
			for (int num = 0; num < list.Count; num++)
			{
				FamilySymbol familySymbol2 = list[num];
				if (string.Compare(familySymbol2.Family.Name, familySymbol.Family.Name, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				list.Add(familySymbol);
			}
			if (_bFindFirstSymbol)
			{
				break;
			}
		}
		return list;
	}

	private bool SetFamilyInstance(Element _Element, FamilySymbol _FamilySymobl, string _strRegionName, string _strUniqueID)
	{
		bool result = false;
		Parameter parameter = null;
		Parameter parameter2 = null;
		FamilyInstance familyInstance = null;
		if (_FamilySymobl != null)
		{
			familyInstance = RevitUtility.NewFamilyInstance(m_Document, new XYZ(0.0, 0.0, 0.0), _FamilySymobl, _Element, null, StructuralType.NonStructural, ref m_TransactionContainer);
			ElementSet elementSet = new ElementSet();
			elementSet.Insert(familyInstance);
			m_Document.ActiveView.HideElements(ElementSetConverter.ToIDList(elementSet));
			parameter = familyInstance.LookupParameter(RevitParameters.RegionNameGenericModelFamilyParameter);
			if (parameter != null && !parameter.IsReadOnly)
			{
				parameter.Set(_strRegionName);
			}
			parameter2 = familyInstance.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
			if (parameter2 != null && !parameter2.IsReadOnly)
			{
				parameter2.Set(_strUniqueID);
			}
			result = true;
			RevitMessageBox.Show(m_strPlantOrPatioWalkText + EPShared.LocalRM.GetString("_AssignFor_Message") + _strRegionName, EPShared.LocalRM.GetString("InformationString"), MessageBoxIcon.Asterisk);
		}
		return result;
	}
}
