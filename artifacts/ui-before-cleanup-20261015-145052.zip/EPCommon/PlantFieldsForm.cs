using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EPCommon;

public class PlantFieldsForm : EPForm
{
	private bool m_bIsDisplayFields;

	private string m_strSettingValue = string.Empty;

	private IContainer components;

	private ListBox m_ExistingFieldsListBox;

	private ListBox m_OrderedFieldsListBox;

	private Button m_MoveUpButton;

	private Button m_MoveDownButton;

	private Button m_AddAllButton;

	private Button m_AddButton;

	private Button m_RemoveButton;

	private Button m_RemoveAllButton;

	private Button m_OKButton;

	private Button m_CancelButton;

	private Label m_AvailableParametersLabel;

	private Label m_ParametersUsedLabel;

	public PlantFieldsForm(bool _bIsDisplayFields, string _strSettingValue)
	{
		InitializeComponent();
		m_bIsDisplayFields = _bIsDisplayFields;
		m_strSettingValue = _strSettingValue;
		InitializeControls();
	}

	private void InitializeControls()
	{
		List<string> list = null;
		list = ((!m_bIsDisplayFields) ? ManagePlants.PlantSharedParamenterList() : ManagePlants.PlantAllParamenterList());
		for (int i = 0; i < list.Count; i++)
		{
			if (string.Compare(list[i], EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), ignoreCase: true) != 0)
			{
				m_ExistingFieldsListBox.Items.Add(list[i]);
			}
		}
		if (m_bIsDisplayFields)
		{
			Text = EPShared.LocalRM.GetString("ColumnDisplayFormDialog");
		}
		else
		{
			Text = EPShared.LocalRM.GetString("DestinationPlantFamilyParametersFormDialog");
		}
		m_AvailableParametersLabel.Text = EPShared.LocalRM.GetString("AvailableParametersDialog");
		m_ParametersUsedLabel.Text = EPShared.LocalRM.GetString("ParametersUsedDialog");
		m_AddAllButton.Text = EPShared.LocalRM.GetString("AMP_AddAllDialog");
		m_AddButton.Text = EPShared.LocalRM.GetString("A_AMP_ddDialog");
		m_RemoveButton.Text = EPShared.LocalRM.GetString("AMP_RemoveDialog");
		m_RemoveAllButton.Text = EPShared.LocalRM.GetString("R_AMP_emoveAllDialog");
		m_MoveUpButton.Text = EPShared.LocalRM.GetString("AMP_MoveUpDialog");
		m_MoveDownButton.Text = EPShared.LocalRM.GetString("Mo_AMP_veDownDialog");
		m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		GetDialogPosition();
		List<ParameterColumn> parameterList = ManagePlants.GetParameterList(m_strSettingValue);
		string empty = string.Empty;
		int num = -1;
		for (int j = 0; j < parameterList.Count; j++)
		{
			empty = ManagePlants.GetPlantParamenterName(parameterList[j].PlantField);
			m_OrderedFieldsListBox.Items.Add(empty);
			num = m_ExistingFieldsListBox.Items.IndexOf(empty);
			if (num >= 0 && num < m_ExistingFieldsListBox.Items.Count)
			{
				m_ExistingFieldsListBox.Items.RemoveAt(num);
			}
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		for (num = 0; num < m_OrderedFieldsListBox.Items.Count; num++)
		{
			PlantField plantFieldFromParamenter = ManagePlants.GetPlantFieldFromParamenter((string)m_OrderedFieldsListBox.Items[num]);
			ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingValue + plantFieldFromParamenter.ToString() + EPShared.LocalRM.GetString("ColumnOrderString"), num + 1);
		}
		for (num = 0; num < m_ExistingFieldsListBox.Items.Count; num++)
		{
			PlantField plantFieldFromParamenter = ManagePlants.GetPlantFieldFromParamenter((string)m_ExistingFieldsListBox.Items[num]);
			ApplicationUtility.Settings.eplSetE_DeleteIntegerSetting(m_strSettingValue + plantFieldFromParamenter.ToString() + EPShared.LocalRM.GetString("ColumnOrderString"));
		}
	}

	private void OnAddAllButtonClick(object sender, EventArgs e)
	{
		m_ExistingFieldsListBox.Items.Clear();
		m_OrderedFieldsListBox.Items.Clear();
		List<string> list = null;
		list = ((!m_bIsDisplayFields) ? ManagePlants.PlantSharedParamenterList() : ManagePlants.PlantAllParamenterList());
		for (int i = 0; i < list.Count; i++)
		{
			if (string.Compare(list[i], EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), ignoreCase: true) != 0)
			{
				m_OrderedFieldsListBox.Items.Add(list[i]);
			}
		}
	}

	private void OnAddButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		int num2 = -1;
		if ((num = m_ExistingFieldsListBox.SelectedItems.Count) >= 1)
		{
			for (num2 = 0; num2 < num; num2++)
			{
				m_OrderedFieldsListBox.Items.Add(m_ExistingFieldsListBox.SelectedItems[num2]);
			}
			for (num2 = num - 1; num2 >= 0; num2--)
			{
				m_ExistingFieldsListBox.Items.RemoveAt(m_ExistingFieldsListBox.SelectedIndices[num2]);
			}
		}
	}

	private void OnRemoveButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		int num2 = -1;
		if ((num = m_OrderedFieldsListBox.SelectedItems.Count) >= 1)
		{
			for (num2 = 0; num2 < num; num2++)
			{
				m_ExistingFieldsListBox.Items.Add(m_OrderedFieldsListBox.SelectedItems[num2]);
			}
			for (num2 = num - 1; num2 >= 0; num2--)
			{
				m_OrderedFieldsListBox.Items.RemoveAt(m_OrderedFieldsListBox.SelectedIndices[num2]);
			}
		}
	}

	private void OnRemoveAllButtonClick(object sender, EventArgs e)
	{
		m_ExistingFieldsListBox.Items.Clear();
		m_OrderedFieldsListBox.Items.Clear();
		List<string> list = null;
		list = ((!m_bIsDisplayFields) ? ManagePlants.PlantSharedParamenterList() : ManagePlants.PlantAllParamenterList());
		for (int i = 0; i < list.Count; i++)
		{
			if (string.Compare(list[i], EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(list[i], EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), ignoreCase: true) != 0)
			{
				m_ExistingFieldsListBox.Items.Add(list[i]);
			}
		}
	}

	private void OnMoveUpButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		if (m_OrderedFieldsListBox.SelectedIndex > 0)
		{
			string item = (string)m_OrderedFieldsListBox.Items[m_OrderedFieldsListBox.SelectedIndex - 1];
			num = m_OrderedFieldsListBox.SelectedIndex;
			m_OrderedFieldsListBox.Items.RemoveAt(num - 1);
			m_OrderedFieldsListBox.Items.Insert(num, item);
		}
	}

	private void OnMoveDownButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		if (m_OrderedFieldsListBox.SelectedIndex < m_OrderedFieldsListBox.Items.Count - 1)
		{
			string item = (string)m_OrderedFieldsListBox.Items[m_OrderedFieldsListBox.SelectedIndex + 1];
			num = m_OrderedFieldsListBox.SelectedIndex;
			m_OrderedFieldsListBox.Items.RemoveAt(num + 1);
			m_OrderedFieldsListBox.Items.Insert(num, item);
		}
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	private void OnPlantFieldsFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ExistingFieldsListBox = new System.Windows.Forms.ListBox();
		this.m_OrderedFieldsListBox = new System.Windows.Forms.ListBox();
		this.m_MoveUpButton = new System.Windows.Forms.Button();
		this.m_MoveDownButton = new System.Windows.Forms.Button();
		this.m_AddAllButton = new System.Windows.Forms.Button();
		this.m_AddButton = new System.Windows.Forms.Button();
		this.m_RemoveButton = new System.Windows.Forms.Button();
		this.m_RemoveAllButton = new System.Windows.Forms.Button();
		this.m_OKButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_AvailableParametersLabel = new System.Windows.Forms.Label();
		this.m_ParametersUsedLabel = new System.Windows.Forms.Label();
		base.SuspendLayout();
		this.m_ExistingFieldsListBox.FormattingEnabled = true;
		this.m_ExistingFieldsListBox.Location = new System.Drawing.Point(14, 27);
		this.m_ExistingFieldsListBox.Name = "m_ExistingFieldsListBox";
		this.m_ExistingFieldsListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
		this.m_ExistingFieldsListBox.Size = new System.Drawing.Size(206, 290);
		this.m_ExistingFieldsListBox.Sorted = true;
		this.m_ExistingFieldsListBox.TabIndex = 2;
		this.m_OrderedFieldsListBox.FormattingEnabled = true;
		this.m_OrderedFieldsListBox.Location = new System.Drawing.Point(332, 27);
		this.m_OrderedFieldsListBox.Name = "m_OrderedFieldsListBox";
		this.m_OrderedFieldsListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
		this.m_OrderedFieldsListBox.Size = new System.Drawing.Size(206, 290);
		this.m_OrderedFieldsListBox.TabIndex = 7;
		this.m_MoveUpButton.Location = new System.Drawing.Point(332, 323);
		this.m_MoveUpButton.Name = "m_MoveUpButton";
		this.m_MoveUpButton.Size = new System.Drawing.Size(100, 23);
		this.m_MoveUpButton.TabIndex = 8;
		this.m_MoveUpButton.Text = "&Move Up";
		this.m_MoveUpButton.UseVisualStyleBackColor = true;
		this.m_MoveUpButton.Click += new System.EventHandler(this.OnMoveUpButtonClick);
		this.m_MoveDownButton.Location = new System.Drawing.Point(438, 323);
		this.m_MoveDownButton.Name = "m_MoveDownButton";
		this.m_MoveDownButton.Size = new System.Drawing.Size(100, 23);
		this.m_MoveDownButton.TabIndex = 9;
		this.m_MoveDownButton.Text = "Mo&ve Down";
		this.m_MoveDownButton.UseVisualStyleBackColor = true;
		this.m_MoveDownButton.Click += new System.EventHandler(this.OnMoveDownButtonClick);
		this.m_AddAllButton.Location = new System.Drawing.Point(226, 64);
		this.m_AddAllButton.Name = "m_AddAllButton";
		this.m_AddAllButton.Size = new System.Drawing.Size(100, 23);
		this.m_AddAllButton.TabIndex = 3;
		this.m_AddAllButton.Text = "&Add All >>>";
		this.m_AddAllButton.UseVisualStyleBackColor = true;
		this.m_AddAllButton.Click += new System.EventHandler(this.OnAddAllButtonClick);
		this.m_AddButton.Location = new System.Drawing.Point(226, 93);
		this.m_AddButton.Name = "m_AddButton";
		this.m_AddButton.Size = new System.Drawing.Size(100, 23);
		this.m_AddButton.TabIndex = 4;
		this.m_AddButton.Text = "A&dd -->";
		this.m_AddButton.UseVisualStyleBackColor = true;
		this.m_AddButton.Click += new System.EventHandler(this.OnAddButtonClick);
		this.m_RemoveButton.Location = new System.Drawing.Point(226, 214);
		this.m_RemoveButton.Name = "m_RemoveButton";
		this.m_RemoveButton.Size = new System.Drawing.Size(100, 23);
		this.m_RemoveButton.TabIndex = 5;
		this.m_RemoveButton.Text = "<-- &Remove";
		this.m_RemoveButton.UseVisualStyleBackColor = true;
		this.m_RemoveButton.Click += new System.EventHandler(this.OnRemoveButtonClick);
		this.m_RemoveAllButton.Location = new System.Drawing.Point(226, 243);
		this.m_RemoveAllButton.Name = "m_RemoveAllButton";
		this.m_RemoveAllButton.Size = new System.Drawing.Size(100, 23);
		this.m_RemoveAllButton.TabIndex = 6;
		this.m_RemoveAllButton.Text = "<<< R&emove All";
		this.m_RemoveAllButton.UseVisualStyleBackColor = true;
		this.m_RemoveAllButton.Click += new System.EventHandler(this.OnRemoveAllButtonClick);
		this.m_OKButton.Location = new System.Drawing.Point(382, 352);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 10;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_CancelButton.Location = new System.Drawing.Point(463, 352);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 11;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_AvailableParametersLabel.AutoSize = true;
		this.m_AvailableParametersLabel.Location = new System.Drawing.Point(12, 9);
		this.m_AvailableParametersLabel.Name = "m_AvailableParametersLabel";
		this.m_AvailableParametersLabel.Size = new System.Drawing.Size(106, 13);
		this.m_AvailableParametersLabel.TabIndex = 0;
		this.m_AvailableParametersLabel.Text = "Available Parameters";
		this.m_ParametersUsedLabel.AutoSize = true;
		this.m_ParametersUsedLabel.Location = new System.Drawing.Point(329, 9);
		this.m_ParametersUsedLabel.Name = "m_ParametersUsedLabel";
		this.m_ParametersUsedLabel.Size = new System.Drawing.Size(88, 13);
		this.m_ParametersUsedLabel.TabIndex = 1;
		this.m_ParametersUsedLabel.Text = "Parameters Used";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(550, 387);
		base.Controls.Add(this.m_ParametersUsedLabel);
		base.Controls.Add(this.m_AvailableParametersLabel);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_OKButton);
		base.Controls.Add(this.m_RemoveAllButton);
		base.Controls.Add(this.m_RemoveButton);
		base.Controls.Add(this.m_AddButton);
		base.Controls.Add(this.m_AddAllButton);
		base.Controls.Add(this.m_MoveDownButton);
		base.Controls.Add(this.m_MoveUpButton);
		base.Controls.Add(this.m_OrderedFieldsListBox);
		base.Controls.Add(this.m_ExistingFieldsListBox);
		base.Name = "PlantFieldsForm";
		this.Text = "Plant Parameters";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantFieldsFormClosing);
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_OKButton;
		base.CancelButton = this.m_CancelButton;
	}
}
