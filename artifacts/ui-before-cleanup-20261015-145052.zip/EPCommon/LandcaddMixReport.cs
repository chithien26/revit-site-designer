using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;

namespace EPCommon;

public class LandcaddMixReport : EPForm
{
	public enum RegionEdgingWarning
	{
		RegionEdgingNotFound,
		IssueWarning,
		WarningDisplayed
	}

	private Units m_Units;

	private LandcaddID m_CurrentReportType;

	private Autodesk.Revit.ApplicationServices.Application m_CurApplication;

	private Document m_CurrentDocument;

	private List<FamilyRegionContainer> m_FamilyRegionList;

	private FormatOptions m_LengthFormatOptions;

	private FormatOptions m_AreaFormatOptions;

	private FormatOptions m_VolumeFormatOptions;

	private UnitSymbolType m_LengthUnitSymbolType;

	private UnitSymbolType m_AreaUnitSymbolType;

	private UnitSymbolType m_VolumeUnitSymbolType;

	private List<FamilyParameterTypeWrapper> m_ListOfPlantParameters;

	private bool m_bExportToFile;

	private List<ExportReportLine> m_ReportLineList;

	private string m_strSettingsPrefix;

	private RegionEdgingWarning m_RegionEdgingWarning;

	private EPTransactionContainer m_TransactionContainer;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private GroupBox m_MixReportGroupBox;

	private Button m_CloseButton;

	private Button m_ExportButton;

	private TreeView m_ReportTreeView;

	private ListView m_ReportListView;

	private Button m_ExportFileButton;

	private GroupBox m_ExportOptionsGroupBox;

	private TextBox m_ExportFileTextBox;

	private Label m_ExportFileLabel;

	private CheckBox m_ExportFamilyCheckBox;

	private CheckBox m_ExportRegionCheckBox;

	private CheckBox m_ExportTypeCheckBox;

	private RadioButton m_TabExportRadioButton;

	private RadioButton m_CommaExportRadioButton;

	public LandcaddMixReport(LandcaddID _ReportType, Document _CurDocument, ref bool _bDlgStatus)
	{
		_bDlgStatus = true;
		InitializeComponent();
		EPToolTip.SetToolTip(m_ExportFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
		m_CurApplication = _CurDocument.Application;
		m_CurrentDocument = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_CurrentDocument);
		m_LengthFormatOptions = m_CurrentDocument.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_AreaFormatOptions = m_CurrentDocument.GetUnits().GetFormatOptions(UnitType.UT_Area);
		m_VolumeFormatOptions = m_CurrentDocument.GetUnits().GetFormatOptions(UnitType.UT_Volume);
		m_Units = m_CurrentDocument.GetUnits();
		try
		{
			m_LengthUnitSymbolType = m_LengthFormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_LengthUnitSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_AreaUnitSymbolType = m_AreaFormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_AreaUnitSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_VolumeUnitSymbolType = m_VolumeFormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_VolumeUnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_CurrentDocument.GetUnits().DecimalSymbol;
		m_RegionEdgingWarning = RegionEdgingWarning.RegionEdgingNotFound;
		m_FamilyRegionList = new List<FamilyRegionContainer>();
		m_CurrentReportType = _ReportType;
		if (m_CurrentReportType == LandcaddID.PlantMix)
		{
			Text = EPShared.LocalRM.GetString("PlantMixReportDialog");
		}
		else
		{
			Text = EPShared.LocalRM.GetString("PatioWalkReportDialog");
		}
		m_MixReportGroupBox.Text = Text;
		m_ExportOptionsGroupBox.Text = EPShared.LocalRM.GetString("ExportOptionsDialog");
		m_ExportFamilyCheckBox.Text = EPShared.LocalRM.GetString("E_AMP_xportFamilyInformationDialog");
		m_ExportRegionCheckBox.Text = EPShared.LocalRM.GetString("Export_AMP_RegionInformationDialog");
		m_ExportTypeCheckBox.Text = EPShared.LocalRM.GetString("ExportType_AMP_InformationDialog");
		m_CommaExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
		m_TabExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
		m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_ExportButton.Text = EPShared.LocalRM.GetString("AMP_ExportDialog");
		m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
		m_strSettingsPrefix = Text.Replace(" ", "");
		InitializeControls();
		m_ReportListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"), m_ReportListView.Size.Width / 2 - 2, HorizontalAlignment.Left);
		m_ReportListView.Columns.Add(EPShared.LocalRM.GetString("Value"), m_ReportListView.Size.Width / 2 - 2, HorizontalAlignment.Left);
		m_ListOfPlantParameters = new List<FamilyParameterTypeWrapper>();
		if (m_CurrentReportType == LandcaddID.PlantMix)
		{
			m_ListOfPlantParameters = ManagePlants.PlantMixParamenterList();
		}
		else
		{
			m_ListOfPlantParameters = ManagePlants.PatioWalkParamenterList();
		}
		PopulateReportTree();
		if (m_FamilyRegionList.Count <= 0)
		{
			string strText = EPShared.LocalRM.GetString("PlantMixReportNoFamilyMessage");
			if (m_CurrentReportType == LandcaddID.PatioWalk)
			{
				strText = EPShared.LocalRM.GetString("PatiowalkReportNoFamilyMessage");
			}
			RevitMessageBox.Show(strText, EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			_bDlgStatus = false;
		}
	}

	private void PopulateReportTree()
	{
		List<Element> list = new List<Element>();
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_CurrentDocument);
		IList<Element> list2 = filteredElementCollector.OfClass(typeof(TopographySurface)).OfCategory(BuiltInCategory.OST_Topography).ToElements();
		foreach (Element item in list2)
		{
			if (item != null && string.Compare(item.Name, EPShared.LocalRM.GetString("SubRegionElement"), ignoreCase: true) == 0)
			{
				list.Add(item);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_CurrentDocument);
		list2 = filteredElementCollector.WherePasses(new ElementCategoryFilter(BuiltInCategory.OST_DetailComponents)).ToElements();
		foreach (Element item2 in list2)
		{
			if (item2 != null && string.Compare(item2.Name, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), ignoreCase: true) == 0)
			{
				list.Add(item2);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_CurrentDocument);
		IList<Element> list3 = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_GenericModel).ToElements();
		filteredElementCollector = new FilteredElementCollector(m_CurrentDocument);
		IList<Element> list4 = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel).ToElements();
		string empty = string.Empty;
		bool flag = false;
		foreach (Element item3 in list4)
		{
			FamilySymbol familySymbol = item3 as FamilySymbol;
			for (int i = 0; i < m_FamilyRegionList.Count; i++)
			{
				if (string.Compare(m_FamilyRegionList[i].FamilyName, familySymbol.Family.Name, ignoreCase: true) == 0)
				{
					m_FamilyRegionList[i].FamilySymbolList.Add(familySymbol);
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				List<FamilySymbol> list5 = new List<FamilySymbol>();
				list5.Add(familySymbol);
				m_FamilyRegionList.Add(new FamilyRegionContainer(familySymbol.Family.Name, list5));
			}
			else
			{
				flag = false;
			}
		}
		Parameter parameter = null;
		Parameter parameter2 = null;
		Parameter parameter3 = null;
		string strRegionName = string.Empty;
		Element element = null;
		RegionContainer regionContainer = null;
		Options options = null;
		View3D _ReturnView3D = null;
		bool flag2 = true;
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
		foreach (Element item4 in list3)
		{
			if (!(item4 is FamilyInstance { Category: not null } familyInstance) || familyInstance.Category.Id.Value64() != BuiltInCategory.OST_GenericModel.GetHashCode())
			{
				continue;
			}
			parameter = familyInstance.Symbol.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
			if (parameter == null)
			{
				continue;
			}
			parameter2 = familyInstance.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
			bool flag3 = false;
			if (parameter2 != null)
			{
				foreach (Element item5 in list)
				{
					string uniqueId = item5.UniqueId;
					if (string.Compare(parameter2.AsString(), uniqueId, ignoreCase: true) == 0)
					{
						element = item5;
						flag3 = true;
						break;
					}
				}
			}
			if (string.Compare(parameter.AsString(), Convert.ToInt32(m_CurrentReportType).ToString("000"), ignoreCase: true) != 0)
			{
				continue;
			}
			for (int j = 0; j < m_FamilyRegionList.Count; j++)
			{
				if (string.Compare(m_FamilyRegionList[j].FamilyName, familyInstance.Symbol.Family.Name, ignoreCase: true) != 0)
				{
					continue;
				}
				if (!flag3)
				{
					m_TransactionContainer.BeginTransaction();
					m_CurrentDocument.Delete(familyInstance.Id);
					m_TransactionContainer.EndTransaction();
				}
				else
				{
					if (element == null)
					{
						break;
					}
					parameter3 = familyInstance.LookupParameter(RevitParameters.RegionNameGenericModelFamilyParameter);
					if (parameter3 != null)
					{
						strRegionName = parameter3.AsString();
					}
					regionContainer = new RegionContainer(strRegionName, element);
					if (string.Compare(element.Name, EPShared.LocalRM.GetString("SubRegionElement"), ignoreCase: true) == 0)
					{
						if (options == null)
						{
							flag2 = RevitUtility.CreateTrue3DViewIfNotPresent(m_CurrentDocument, ref _ReturnView3D);
							options = m_CurrentDocument.Application.Create.NewGeometryOptions();
							if (_ReturnView3D != null)
							{
								options.View = _ReturnView3D;
							}
							else
							{
								options.View = m_CurrentDocument.ActiveView;
							}
							options.ComputeReferences = false;
						}
						regionContainer.MeshTriangleList = new MeshTriangleList(element.get_Geometry(options));
					}
					m_FamilyRegionList[j].RegionElementList.Add(regionContainer);
				}
				break;
			}
		}
		if (_ReturnView3D != null && !flag2)
		{
			m_CurrentDocument.Delete(_ReturnView3D.Id);
		}
		m_TransactionContainer.Rollback();
		for (int num = m_FamilyRegionList.Count - 1; num >= 0; num--)
		{
			if (m_FamilyRegionList[num].RegionElementList == null || m_FamilyRegionList[num].RegionElementList.Count == 0)
			{
				m_FamilyRegionList.RemoveAt(num);
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		TreeNode treeNode = null;
		TreeNode treeNode2 = null;
		TreeNode treeNode3 = null;
		Parameter parameter4 = null;
		FamilySymbol familySymbol2 = null;
		for (int k = 0; k < m_FamilyRegionList.Count; k++)
		{
			treeNode = new TreeNode();
			treeNode.Text = m_FamilyRegionList[k].FamilyName;
			for (int l = 0; l < m_FamilyRegionList[k].RegionElementList.Count; l++)
			{
				treeNode2 = new TreeNode();
				treeNode2.Text = m_FamilyRegionList[k].RegionElementList[l].RegionName;
				m_FamilyRegionList[k].FamilySymbolList.Sort(comparer);
				if (m_CurrentReportType == LandcaddID.PatioWalk)
				{
					for (int m = 0; m < m_FamilyRegionList[k].FamilySymbolList.Count; m++)
					{
						familySymbol2 = m_FamilyRegionList[k].FamilySymbolList[m];
						parameter4 = familySymbol2.LookupParameter(RevitParameters.EdgePathWalkFamilyParameter);
						if (parameter4 == null || parameter4.AsInteger() != 1)
						{
							continue;
						}
						parameter4 = familySymbol2.LookupParameter(RevitParameters.MowingStripPathWalkFamilyParameter);
						if (parameter4 != null && parameter4.AsInteger() == 1)
						{
							if (m > 0)
							{
								m_FamilyRegionList[k].FamilySymbolList.RemoveAt(m);
								m_FamilyRegionList[k].FamilySymbolList.Insert(0, familySymbol2);
							}
							break;
						}
					}
				}
				for (int n = 0; n < m_FamilyRegionList[k].FamilySymbolList.Count; n++)
				{
					treeNode3 = new TreeNode();
					treeNode3.Text = m_FamilyRegionList[k].FamilySymbolList[n].Name;
					treeNode2.Nodes.Add(treeNode3);
				}
				treeNode.Nodes.Add(treeNode2);
			}
			m_ReportTreeView.Nodes.Add(treeNode);
		}
	}

	private void OnExportButtonClicked(object sender, EventArgs e)
	{
		if (!ValidateFields())
		{
			return;
		}
		string empty = string.Empty;
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		if (m_ReportLineList == null)
		{
			m_ReportLineList = new List<ExportReportLine>();
		}
		m_bExportToFile = true;
		double _dTotalArea = 0.0;
		for (num = 0; num < m_FamilyRegionList.Count; num++)
		{
			if (m_ExportFamilyCheckBox.Checked)
			{
				if (m_CurrentReportType == LandcaddID.PlantMix)
				{
					empty = EPShared.LocalRM.GetString("PlantMixString");
				}
				else
				{
					empty = EPShared.LocalRM.GetString("PatioWalkString");
				}
				m_ReportLineList.Add(new ExportReportLine(Text, EPShared.LocalRM.GetString("Parameter"), EPShared.LocalRM.GetString("Value")));
				PopulateTotalAreaInList(m_FamilyRegionList[num].RegionElementList, ref _dTotalArea, m_FamilyRegionList[num].FamilyName);
				if (m_CurrentReportType == LandcaddID.PlantMix)
				{
					PopulatePlantQuantityInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList, _dTotalArea);
				}
				else
				{
					PopulatePathWalkVolumeInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList, _dTotalArea);
				}
				AddBlankLine();
				_dTotalArea = 0.0;
			}
			if (m_ExportRegionCheckBox.Checked)
			{
				m_ReportLineList.Add(new ExportReportLine(EPShared.LocalRM.GetString("RegionString"), EPShared.LocalRM.GetString("Parameter"), EPShared.LocalRM.GetString("Value")));
				for (num2 = 0; num2 < m_FamilyRegionList[num].RegionElementList.Count; num2++)
				{
					PopulateTotalAreaInList(m_FamilyRegionList[num].RegionElementList[num2], ref _dTotalArea, m_FamilyRegionList[num].RegionElementList[num2].RegionName);
					if (m_CurrentReportType == LandcaddID.PlantMix)
					{
						PopulatePlantQuantityInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList[num2], _dTotalArea);
					}
					else
					{
						PopulatePathWalkVolumeInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList[num2], _dTotalArea);
					}
					AddBlankLine();
					_dTotalArea = 0.0;
				}
			}
			if (m_ExportTypeCheckBox.Checked)
			{
				empty = ((m_CurrentReportType != LandcaddID.PlantMix) ? EPShared.LocalRM.GetString("MaterialString") : EPShared.LocalRM.GetString("Plant"));
				m_ReportLineList.Add(new ExportReportLine(empty, EPShared.LocalRM.GetString("Parameter"), EPShared.LocalRM.GetString("Value")));
				for (num3 = 0; num3 < m_FamilyRegionList[num].FamilySymbolList.Count; num3++)
				{
					PopulatePlantParametersInList(m_FamilyRegionList[num].FamilySymbolList[num3], m_FamilyRegionList[num].FamilySymbolList[num3].Name);
					AddBlankLine();
				}
			}
		}
		string empty2 = string.Empty;
		empty2 = ((!m_CommaExportRadioButton.Checked) ? "\t" : ",");
		ImportExport.ExportToFile(empty2, m_ExportFileTextBox.Text, m_ReportLineList);
		m_ReportLineList.Clear();
		m_bExportToFile = false;
	}

	private void OnCloseButtonClicked(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
	}

	private int FindRootIndex(TreeNode _RootTreeNode)
	{
		for (int i = 0; i < m_FamilyRegionList.Count; i++)
		{
			if (string.Compare(m_FamilyRegionList[i].FamilyName, _RootTreeNode.Text, ignoreCase: true) == 0)
			{
				return i;
			}
		}
		return -1;
	}

	private int FindRegionIndex(int nRootIndex, TreeNode _RegionTreeNode)
	{
		if (nRootIndex >= 0 && nRootIndex < m_FamilyRegionList.Count)
		{
			for (int i = 0; i < m_FamilyRegionList[nRootIndex].RegionElementList.Count; i++)
			{
				if (string.Compare(m_FamilyRegionList[nRootIndex].RegionElementList[i].RegionName, _RegionTreeNode.Text, ignoreCase: true) == 0)
				{
					return i;
				}
			}
		}
		return -1;
	}

	private int FindPlantIndex(int nRootIndex, TreeNode _PlantTreeNode)
	{
		if (nRootIndex >= 0 && nRootIndex < m_FamilyRegionList.Count)
		{
			for (int i = 0; i < m_FamilyRegionList[nRootIndex].FamilySymbolList.Count; i++)
			{
				if (string.Compare(m_FamilyRegionList[nRootIndex].FamilySymbolList[i].Name, _PlantTreeNode.Text, ignoreCase: true) == 0)
				{
					return i;
				}
			}
		}
		return -1;
	}

	private void ReportTreeViewAfterSelect(object sender, TreeViewEventArgs e)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		m_ReportListView.Items.Clear();
		if (m_ReportTreeView.SelectedNode.Parent == null)
		{
			num = FindRootIndex(m_ReportTreeView.SelectedNode);
			if (num != -1)
			{
				double _dTotalArea = 0.0;
				PopulateTotalAreaInList(m_FamilyRegionList[num].RegionElementList, ref _dTotalArea);
				if (m_CurrentReportType == LandcaddID.PlantMix)
				{
					PopulatePlantQuantityInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList, _dTotalArea);
				}
				else
				{
					PopulatePathWalkVolumeInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList, _dTotalArea);
				}
			}
		}
		else if (m_ReportTreeView.SelectedNode.Parent.Parent == null)
		{
			num = FindRootIndex(m_ReportTreeView.SelectedNode.Parent);
			num2 = FindRegionIndex(num, m_ReportTreeView.SelectedNode);
			if (num2 != -1)
			{
				double _dTotalArea2 = 0.0;
				PopulateTotalAreaInList(m_FamilyRegionList[num].RegionElementList[num2], ref _dTotalArea2);
				if (m_CurrentReportType == LandcaddID.PlantMix)
				{
					PopulatePlantQuantityInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList[num2], _dTotalArea2);
				}
				else
				{
					PopulatePathWalkVolumeInList(m_FamilyRegionList[num].FamilySymbolList, m_FamilyRegionList[num].RegionElementList[num2], _dTotalArea2);
				}
			}
		}
		else
		{
			num = FindRootIndex(m_ReportTreeView.SelectedNode.Parent.Parent);
			num3 = FindPlantIndex(num, m_ReportTreeView.SelectedNode);
			if (num3 != -1)
			{
				PopulatePlantParametersInList(m_FamilyRegionList[num].FamilySymbolList[num3]);
			}
		}
		if (m_RegionEdgingWarning == RegionEdgingWarning.IssueWarning)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoLinearFootageMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			m_RegionEdgingWarning = RegionEdgingWarning.WarningDisplayed;
		}
	}

	private void PopulatePlantParametersInList(FamilySymbol _PlantFamilySymbol)
	{
		PopulatePlantParametersInList(_PlantFamilySymbol, string.Empty);
	}

	private void PopulatePlantParametersInList(FamilySymbol _PlantFamilySymbol, string _strTitle)
	{
		Parameter parameter = null;
		string _strToDisplay = string.Empty;
		for (int i = 0; i < m_ListOfPlantParameters.Count; i++)
		{
			if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
			{
				continue;
			}
			parameter = _PlantFamilySymbol.LookupParameter(m_ListOfPlantParameters[i].ParameterName);
			if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.CostGenericFamilyParameter, ignoreCase: true) == 0)
			{
				_strToDisplay = ValueConversion.Format("{0:f2}", parameter.AsDouble());
			}
			else if (m_CurrentReportType == LandcaddID.PlantMix)
			{
				if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					double dConvertedDouble = 0.0;
					if (parameter != null)
					{
						dConvertedDouble = parameter.AsDouble();
					}
					RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
				}
				else if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					_strToDisplay = ((parameter == null) ? EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular") : parameter.AsString());
				}
				else if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					_strToDisplay = ((parameter == null) ? "0.0" : Convert.ToString(parameter.AsDouble()));
				}
				else if (parameter != null)
				{
					_strToDisplay = parameter.AsString();
				}
			}
			else if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
			{
				double dConvertedDouble2 = 0.0;
				if (parameter != null)
				{
					dConvertedDouble2 = parameter.AsDouble();
				}
				RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble2, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			}
			else if (string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ListOfPlantParameters[i].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
			{
				if (parameter == null)
				{
					_strToDisplay = EPShared.LocalRM.GetString("NoString");
				}
				else
				{
					_strToDisplay = ((parameter.AsInteger() != 0) ? EPShared.LocalRM.GetString("YesString") : EPShared.LocalRM.GetString("NoString"));
				}
			}
			else if (parameter != null)
			{
				_strToDisplay = parameter.AsString();
			}
			PopulateList(_strTitle, m_ListOfPlantParameters[i].ParameterName, _strToDisplay);
			if (_strTitle != string.Empty)
			{
				_strTitle = string.Empty;
			}
			_strToDisplay = string.Empty;
		}
	}

	private void PopulateTotalAreaInList(RegionContainer _RegionContainer, ref double _dTotalArea)
	{
		List<RegionContainer> list = new List<RegionContainer>();
		list.Add(_RegionContainer);
		PopulateTotalAreaInList(list, ref _dTotalArea);
	}

	private void PopulateTotalAreaInList(List<RegionContainer> _ListOfRegions, ref double _dTotalArea)
	{
		PopulateTotalAreaInList(_ListOfRegions, ref _dTotalArea, string.Empty);
	}

	private void PopulateTotalAreaInList(RegionContainer _RegionContainer, ref double _dTotalArea, string _strTitle)
	{
		List<RegionContainer> list = new List<RegionContainer>();
		list.Add(_RegionContainer);
		PopulateTotalAreaInList(list, ref _dTotalArea, _strTitle);
	}

	private void PopulateTotalAreaInList(List<RegionContainer> _ListOfRegions, ref double _dTotalArea, string _strTitle)
	{
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 0.0;
		string _strToDisplay = string.Empty;
		string empty = string.Empty;
		Parameter parameter = null;
		for (int i = 0; i < _ListOfRegions.Count; i++)
		{
			if (string.Compare(_ListOfRegions[i].RegionElement.Name, EPShared.LocalRM.GetString("DetailFilledRegionElementName"), ignoreCase: true) == 0)
			{
				parameter = _ListOfRegions[i].RegionElement.get_Parameter(BuiltInParameter.HOST_AREA_COMPUTED);
				if (parameter != null)
				{
					num += parameter.AsDouble();
				}
			}
			else if (string.Compare(_ListOfRegions[i].RegionElement.Name, EPShared.LocalRM.GetString("SubRegionElement"), ignoreCase: true) == 0)
			{
				parameter = _ListOfRegions[i].RegionElement.get_Parameter(BuiltInParameter.SURFACE_AREA);
				if (parameter != null)
				{
					num3 += parameter.AsDouble();
				}
				parameter = _ListOfRegions[i].RegionElement.get_Parameter(BuiltInParameter.PROJECTED_SURFACE_AREA);
				if (parameter != null)
				{
					num2 += parameter.AsDouble();
				}
			}
		}
		empty = EPShared.LocalRM.GetString("RegionString") + " " + EPShared.LocalRM.GetString("AreaRegionParameter");
		if (RevitDefines.GT(num, 0.0))
		{
			RevitGeometry.Units_ConvertDoubleToString(num, m_AreaFormatOptions.LegacyDisplayUnits(), m_AreaFormatOptions.Accuracy, m_AreaUnitSymbolType, m_Units, ref _strToDisplay);
		}
		else
		{
			_strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
		}
		PopulateList(_strTitle, empty, _strToDisplay);
		empty = EPShared.LocalRM.GetString("SubRegionString") + " " + EPShared.LocalRM.GetString("ProjectedAreaSubRegionParameter");
		if (RevitDefines.GT(num2, 0.0))
		{
			RevitGeometry.Units_ConvertDoubleToString(num2, m_AreaFormatOptions.LegacyDisplayUnits(), m_AreaFormatOptions.Accuracy, m_AreaUnitSymbolType, m_Units, ref _strToDisplay);
		}
		else
		{
			_strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
		}
		PopulateList(empty, _strToDisplay);
		empty = EPShared.LocalRM.GetString("SubRegionString") + " " + EPShared.LocalRM.GetString("SurfaceAreaSubRegionParameter");
		if (RevitDefines.GT(num3, 0.0))
		{
			RevitGeometry.Units_ConvertDoubleToString(num3, m_AreaFormatOptions.LegacyDisplayUnits(), m_AreaFormatOptions.Accuracy, m_AreaUnitSymbolType, m_Units, ref _strToDisplay);
		}
		else
		{
			_strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
		}
		PopulateList(empty, _strToDisplay);
		_dTotalArea = num + num2;
	}

	private void PopulatePathWalkVolumeInList(List<FamilySymbol> _ListOfFamilies, RegionContainer _RegionContainer, double _dTotalArea)
	{
		List<RegionContainer> list = new List<RegionContainer>();
		list.Add(_RegionContainer);
		PopulatePathWalkVolumeInList(_ListOfFamilies, list, _dTotalArea);
	}

	private void PopulatePathWalkVolumeInList(List<FamilySymbol> _ListOfFamilies, List<RegionContainer> _ListOfRegions, double _dTotalArea)
	{
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 0.0;
		double num4 = 0.0;
		double num5 = 0.0;
		double num6 = 0.0;
		double num7 = 0.0;
		double num8 = 0.0;
		double num9 = 0.0;
		int num10 = 0;
		int num11 = 0;
		string _strToDisplay = string.Empty;
		string empty = string.Empty;
		FamilySymbol familySymbol = null;
		Parameter parameter = null;
		for (int i = 0; i < _ListOfFamilies.Count; i++)
		{
			familySymbol = _ListOfFamilies[i];
			if (familySymbol == null)
			{
				continue;
			}
			num10 = familySymbol.LookupParameter(RevitParameters.EdgePathWalkFamilyParameter)?.AsInteger() ?? 0;
			num = familySymbol.LookupParameter(RevitParameters.ThicknessPathWalkFamilyParameter)?.AsDouble() ?? 0.0;
			num2 = _dTotalArea * num;
			if (num10 == 1)
			{
				num11 = familySymbol.LookupParameter(RevitParameters.MowingStripPathWalkFamilyParameter)?.AsInteger() ?? 0;
				if (num11 == 1)
				{
					num4 = familySymbol.LookupParameter(RevitParameters.EdgeWidthPathWalkFamilyParameter)?.AsDouble() ?? 0.0;
				}
			}
			if (num10 == 1)
			{
				for (int j = 0; j < _ListOfRegions.Count; j++)
				{
					if (string.Compare(_ListOfRegions[j].RegionElement.Name, EPShared.LocalRM.GetString("SubRegionElement"), ignoreCase: true) == 0)
					{
						num8 = RevitGeometry.eplGeoE_CalcLegListLength(_ListOfRegions[j].MeshTriangleList.Leg);
						num7 += num8;
						if (RevitDefines.GT(num, 0.0) && RevitDefines.GT(num4, 0.0))
						{
							num6 = _ListOfRegions[j].MeshTriangleList.Area();
							num9 = _ListOfRegions[j].MeshTriangleList.OffsetArea(num4);
							num5 += num6 - num9;
						}
					}
					else if (m_RegionEdgingWarning == RegionEdgingWarning.RegionEdgingNotFound)
					{
						m_RegionEdgingWarning = RegionEdgingWarning.IssueWarning;
					}
				}
				num3 = num5 * num;
				num2 -= num3;
			}
			num11 = 0;
			num4 = 0.0;
			empty = familySymbol.Name + " " + EPShared.LocalRM.GetString("VolumeString");
			if (RevitDefines.GT(num2, 0.0))
			{
				RevitGeometry.Units_ConvertDoubleToString(num2, m_VolumeFormatOptions.LegacyDisplayUnits(), m_VolumeFormatOptions.Accuracy, m_VolumeUnitSymbolType, m_Units, ref _strToDisplay);
			}
			else
			{
				_strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
			}
			PopulateList(empty, _strToDisplay);
		}
		if (RevitDefines.GT(num7, 0.0))
		{
			RevitGeometry.Units_ConvertDoubleToString(num7, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			empty = EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter") + " " + EPShared.LocalRM.GetString("LengthString");
			PopulateList(empty, _strToDisplay);
		}
		if (RevitDefines.GT(num5, 0.0))
		{
			RevitGeometry.Units_ConvertDoubleToString(num5, m_AreaFormatOptions.LegacyDisplayUnits(), m_AreaFormatOptions.Accuracy, m_AreaUnitSymbolType, m_Units, ref _strToDisplay);
			empty = EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter") + " " + EPShared.LocalRM.GetString("AreaString");
			PopulateList(empty, _strToDisplay);
		}
		if (RevitDefines.GT(num3, 0.0))
		{
			RevitGeometry.Units_ConvertDoubleToString(num3, m_VolumeFormatOptions.LegacyDisplayUnits(), m_VolumeFormatOptions.Accuracy, m_VolumeUnitSymbolType, m_Units, ref _strToDisplay);
			empty = EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter") + " " + EPShared.LocalRM.GetString("VolumeString");
			PopulateList(empty, _strToDisplay);
		}
	}

	private void PopulatePlantQuantityInList(List<FamilySymbol> _ListOfFamilies, RegionContainer _RegionContainer, double _dTotalArea)
	{
		List<RegionContainer> list = new List<RegionContainer>();
		list.Add(_RegionContainer);
		PopulatePlantQuantityInList(_ListOfFamilies, list, _dTotalArea);
	}

	private void PopulatePlantQuantityInList(List<FamilySymbol> _ListOfFamilies, List<RegionContainer> _ListOfRegions, double _dTotalArea)
	{
		double num = 0.0;
		double num2 = 0.0;
		string empty = string.Empty;
		int num3 = 0;
		FamilySymbol familySymbol = null;
		Parameter parameter = null;
		for (int i = 0; i < _ListOfFamilies.Count; i++)
		{
			familySymbol = _ListOfFamilies[i];
			if (familySymbol != null)
			{
				num = familySymbol.LookupParameter(RevitParameters.PercentagePlantMixFamilyParameter)?.AsDouble() ?? 0.0;
				num2 = familySymbol.LookupParameter(RevitParameters.PlantSpacingPlantMixFamilyParameter)?.AsDouble() ?? 0.0;
				parameter = familySymbol.LookupParameter(RevitParameters.SpacingMethodPlantMixFamilyParameter);
				empty = ((parameter == null) ? EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular") : parameter.AsString());
				num3 = CalcPlantQuantity(empty, num2, num, _dTotalArea);
				PopulateList(EPShared.LocalRM.GetString("QuantityOfString") + " " + familySymbol.Name, num3.ToString("0"));
			}
		}
	}

	private int CalcPlantQuantity(string _strMethod, double _dSpacing, double _dPercent, double _dTotalArea)
	{
		int num = 1;
		if (string.Compare(_strMethod, EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular"), ignoreCase: true) == 0)
		{
			num = (int)(_dTotalArea / (_dSpacing * 0.87 * _dSpacing));
		}
		else if (string.Compare(_strMethod, EPShared.LocalRM.GetString("PlantMixSpacingMethodSquare"), ignoreCase: true) == 0)
		{
			num = (int)(_dTotalArea / (_dSpacing * _dSpacing));
		}
		else if (string.Compare(_strMethod, EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"), ignoreCase: true) == 0)
		{
			double num2 = _dTotalArea;
			string _strToDisplay = string.Empty;
			RevitGeometry.Units_ConvertDoubleToString(num2, m_AreaFormatOptions.LegacyDisplayUnits(), m_AreaFormatOptions.Accuracy, UnitSymbolType.UST_NONE, m_Units, ref _strToDisplay);
			if (_strToDisplay != string.Empty)
			{
				num2 = ValueConversion.ToDouble(_strToDisplay);
			}
			num = (int)num2;
			if (RevitDefines.GT(num2, num))
			{
				num++;
			}
		}
		num = (int)((double)num * _dPercent * 0.01);
		if (num < 1)
		{
			num = 1;
		}
		return num;
	}

	private void OnExportFileButtonClick(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		if (m_CommaExportRadioButton.Checked)
		{
			saveFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
		}
		else
		{
			saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
		}
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_ExportFileTextBox.Text = saveFileDialog.FileName;
			SiteDesigner.UI.WpfFocus.Focus(m_ExportFileTextBox);
		}
	}

	private void AddBlankLine()
	{
		if (m_bExportToFile)
		{
			m_ReportLineList.Add(new ExportReportLine());
		}
	}

	private void PopulateList(string _strParameter, string _strValue)
	{
		PopulateList(string.Empty, _strParameter, _strValue);
	}

	private void PopulateList(string _strLevel, string _strParameter, string _strValue)
	{
		if (!m_bExportToFile)
		{
			ListViewItem listViewItem = m_ReportListView.Items.Add(_strParameter, _strParameter, string.Empty);
			listViewItem.Tag = _strParameter;
			listViewItem.SubItems.Add(_strValue);
		}
		else
		{
			m_ReportLineList.Add(new ExportReportLine(_strLevel, _strParameter, _strValue));
		}
	}

	private bool ValidateFields()
	{
		string value = m_ExportFileTextBox.Text;
		if (string.IsNullOrEmpty(value))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFolderFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_ExportFileTextBox);
			return false;
		}
		string empty = string.Empty;
		empty = ((!m_CommaExportRadioButton.Checked) ? ".txt" : ".csv");
		if (m_ExportFileTextBox.Text.IndexOf(empty) < 0)
		{
			if (m_ExportFileTextBox.Text.IndexOf("\\") <= 0 && m_ExportFileTextBox.Text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length = -1;
			if (m_ExportFileTextBox.Text.IndexOf("\\") > 0)
			{
				length = m_ExportFileTextBox.Text.LastIndexOf("\\");
			}
			else if (m_ExportFileTextBox.Text.IndexOf("/") > 0)
			{
				length = m_ExportFileTextBox.Text.LastIndexOf("/");
			}
			if (!Directory.Exists(m_ExportFileTextBox.Text.Substring(0, length)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			m_ExportFileTextBox.Text += empty;
		}
		else
		{
			if (m_ExportFileTextBox.Text.IndexOf("\\") <= 0 && m_ExportFileTextBox.Text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length2 = -1;
			if (m_ExportFileTextBox.Text.IndexOf("\\") > 0)
			{
				length2 = m_ExportFileTextBox.Text.LastIndexOf("\\");
			}
			else if (m_ExportFileTextBox.Text.IndexOf("/") > 0)
			{
				length2 = m_ExportFileTextBox.Text.LastIndexOf("/");
			}
			if (!Directory.Exists(m_ExportFileTextBox.Text.Substring(0, length2)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
		}
		return true;
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		m_CommaExportRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ExportOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_CommaExportRadioButton.Checked = true;
			}
			else
			{
				m_TabExportRadioButton.Checked = true;
			}
		}
		m_ExportFamilyCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ExportFamilyOption", ref _nReturnValue) && _nReturnValue == 1)
		{
			m_ExportFamilyCheckBox.Checked = true;
		}
		m_ExportTypeCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ExportTypeOption", ref _nReturnValue) && _nReturnValue == 1)
		{
			m_ExportTypeCheckBox.Checked = true;
		}
		m_ExportRegionCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ExportRegionOption", ref _nReturnValue) && _nReturnValue == 1)
		{
			m_ExportRegionCheckBox.Checked = true;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ExportFileName", ref _strReturnValue))
		{
			m_ExportFileTextBox.Text = _strReturnValue;
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		num = ((!m_CommaExportRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ExportOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ExportFamilyOption", Convert.ToInt32(m_ExportFamilyCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ExportTypeOption", Convert.ToInt32(m_ExportTypeCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ExportRegionOption", Convert.ToInt32(m_ExportRegionCheckBox.Checked));
		if (m_ExportFileTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ExportFileName", m_ExportFileTextBox.Text);
		}
	}

	private void OnLandcaddMixReportClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_MixReportGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ReportListView = new System.Windows.Forms.ListView();
		this.m_ReportTreeView = new System.Windows.Forms.TreeView();
		this.m_CloseButton = new System.Windows.Forms.Button();
		this.m_ExportButton = new System.Windows.Forms.Button();
		this.m_ExportFileButton = new System.Windows.Forms.Button();
		this.m_ExportOptionsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_TabExportRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CommaExportRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ExportTypeCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ExportRegionCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ExportFamilyCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ExportFileTextBox = new System.Windows.Forms.TextBox();
		this.m_ExportFileLabel = new System.Windows.Forms.Label();
		this.m_MixReportGroupBox.SuspendLayout();
		this.m_ExportOptionsGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_MixReportGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_MixReportGroupBox.Controls.Add(this.m_ReportListView);
		this.m_MixReportGroupBox.Controls.Add(this.m_ReportTreeView);
		this.m_MixReportGroupBox.Location = new System.Drawing.Point(12, 5);
		this.m_MixReportGroupBox.Name = "m_MixReportGroupBox";
		this.m_MixReportGroupBox.Size = new System.Drawing.Size(532, 311);
		this.m_MixReportGroupBox.TabIndex = 0;
		this.m_MixReportGroupBox.TabStop = false;
		this.m_MixReportGroupBox.Text = "Plant Mix Report";
		this.m_ReportListView.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_ReportListView.Location = new System.Drawing.Point(214, 16);
		this.m_ReportListView.MultiSelect = false;
		this.m_ReportListView.Name = "m_ReportListView";
		this.m_ReportListView.Size = new System.Drawing.Size(312, 288);
		this.m_ReportListView.TabIndex = 1;
		this.m_ReportListView.UseCompatibleStateImageBehavior = false;
		this.m_ReportListView.View = System.Windows.Forms.View.Details;
		this.m_ReportTreeView.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ReportTreeView.Location = new System.Drawing.Point(6, 16);
		this.m_ReportTreeView.Name = "m_ReportTreeView";
		this.m_ReportTreeView.Size = new System.Drawing.Size(202, 288);
		this.m_ReportTreeView.TabIndex = 0;
		this.m_ReportTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.ReportTreeViewAfterSelect);
		this.m_CloseButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CloseButton.Location = new System.Drawing.Point(468, 419);
		this.m_CloseButton.Name = "m_CloseButton";
		this.m_CloseButton.Size = new System.Drawing.Size(76, 23);
		this.m_CloseButton.TabIndex = 3;
		this.m_CloseButton.Text = "&Close";
		this.m_CloseButton.UseVisualStyleBackColor = true;
		this.m_CloseButton.Click += new System.EventHandler(this.OnCloseButtonClicked);
		this.m_ExportButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportButton.Location = new System.Drawing.Point(386, 419);
		this.m_ExportButton.Name = "m_ExportButton";
		this.m_ExportButton.Size = new System.Drawing.Size(76, 23);
		this.m_ExportButton.TabIndex = 2;
		this.m_ExportButton.Text = "&Export";
		this.m_ExportButton.UseVisualStyleBackColor = true;
		this.m_ExportButton.Click += new System.EventHandler(this.OnExportButtonClicked);
		this.m_ExportFileButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportFileButton.Location = new System.Drawing.Point(502, 64);
		this.m_ExportFileButton.Name = "m_ExportFileButton";
		this.m_ExportFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_ExportFileButton.TabIndex = 7;
		this.m_ExportFileButton.TabStop = false;
		this.m_ExportFileButton.Text = "...";
		this.m_ExportFileButton.UseVisualStyleBackColor = true;
		this.m_ExportFileButton.Click += new System.EventHandler(this.OnExportFileButtonClick);
		this.m_ExportOptionsGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_TabExportRadioButton);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_CommaExportRadioButton);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportTypeCheckBox);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportRegionCheckBox);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFamilyCheckBox);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFileTextBox);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFileButton);
		this.m_ExportOptionsGroupBox.Controls.Add(this.m_ExportFileLabel);
		this.m_ExportOptionsGroupBox.Location = new System.Drawing.Point(12, 320);
		this.m_ExportOptionsGroupBox.Name = "m_ExportOptionsGroupBox";
		this.m_ExportOptionsGroupBox.Size = new System.Drawing.Size(532, 93);
		this.m_ExportOptionsGroupBox.TabIndex = 1;
		this.m_ExportOptionsGroupBox.TabStop = false;
		this.m_ExportOptionsGroupBox.Text = "Export Options";
		this.m_TabExportRadioButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_TabExportRadioButton.AutoSize = true;
		this.m_TabExportRadioButton.Location = new System.Drawing.Point(181, 42);
		this.m_TabExportRadioButton.Name = "m_TabExportRadioButton";
		this.m_TabExportRadioButton.Size = new System.Drawing.Size(139, 17);
		this.m_TabExportRadioButton.TabIndex = 4;
		this.m_TabExportRadioButton.TabStop = true;
		this.m_TabExportRadioButton.Text = "&Tab Delimited (Text File)";
		this.m_TabExportRadioButton.UseVisualStyleBackColor = true;
		this.m_CommaExportRadioButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_CommaExportRadioButton.AutoSize = true;
		this.m_CommaExportRadioButton.Location = new System.Drawing.Point(6, 42);
		this.m_CommaExportRadioButton.Name = "m_CommaExportRadioButton";
		this.m_CommaExportRadioButton.Size = new System.Drawing.Size(155, 17);
		this.m_CommaExportRadioButton.TabIndex = 3;
		this.m_CommaExportRadioButton.TabStop = true;
		this.m_CommaExportRadioButton.Text = "&Comma Delimited (Text File)";
		this.m_CommaExportRadioButton.UseVisualStyleBackColor = true;
		this.m_ExportTypeCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ExportTypeCheckBox.AutoSize = true;
		this.m_ExportTypeCheckBox.Location = new System.Drawing.Point(361, 19);
		this.m_ExportTypeCheckBox.Name = "m_ExportTypeCheckBox";
		this.m_ExportTypeCheckBox.Size = new System.Drawing.Size(138, 17);
		this.m_ExportTypeCheckBox.TabIndex = 2;
		this.m_ExportTypeCheckBox.Text = "Export Type Information";
		this.m_ExportTypeCheckBox.UseVisualStyleBackColor = true;
		this.m_ExportRegionCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ExportRegionCheckBox.AutoSize = true;
		this.m_ExportRegionCheckBox.Location = new System.Drawing.Point(181, 19);
		this.m_ExportRegionCheckBox.Name = "m_ExportRegionCheckBox";
		this.m_ExportRegionCheckBox.Size = new System.Drawing.Size(148, 17);
		this.m_ExportRegionCheckBox.TabIndex = 1;
		this.m_ExportRegionCheckBox.Text = "Export Region Information";
		this.m_ExportRegionCheckBox.UseVisualStyleBackColor = true;
		this.m_ExportFamilyCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ExportFamilyCheckBox.AutoSize = true;
		this.m_ExportFamilyCheckBox.Location = new System.Drawing.Point(6, 19);
		this.m_ExportFamilyCheckBox.Name = "m_ExportFamilyCheckBox";
		this.m_ExportFamilyCheckBox.Size = new System.Drawing.Size(143, 17);
		this.m_ExportFamilyCheckBox.TabIndex = 0;
		this.m_ExportFamilyCheckBox.Text = "Export Family Information";
		this.m_ExportFamilyCheckBox.UseVisualStyleBackColor = true;
		this.m_ExportFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportFileTextBox.Location = new System.Drawing.Point(58, 65);
		this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
		this.m_ExportFileTextBox.Size = new System.Drawing.Size(438, 20);
		this.m_ExportFileTextBox.TabIndex = 6;
		this.m_ExportFileLabel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_ExportFileLabel.AutoSize = true;
		this.m_ExportFileLabel.Location = new System.Drawing.Point(6, 68);
		this.m_ExportFileLabel.Name = "m_ExportFileLabel";
		this.m_ExportFileLabel.Size = new System.Drawing.Size(26, 13);
		this.m_ExportFileLabel.TabIndex = 5;
		this.m_ExportFileLabel.Text = "Fi&le:";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(556, 454);
		base.Controls.Add(this.m_ExportOptionsGroupBox);
		base.Controls.Add(this.m_ExportButton);
		base.Controls.Add(this.m_CloseButton);
		base.Controls.Add(this.m_MixReportGroupBox);
		this.MinimumSize = new System.Drawing.Size(564, 481);
		base.Name = "LandcaddMixReport";
		this.Text = "Plant Mix Report";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnLandcaddMixReportClosing);
		this.m_MixReportGroupBox.ResumeLayout(false);
		this.m_ExportOptionsGroupBox.ResumeLayout(false);
		this.m_ExportOptionsGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.AcceptButton = this.m_ExportButton;
		base.CancelButton = this.m_CloseButton;
	}
}
