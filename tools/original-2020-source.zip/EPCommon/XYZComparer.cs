﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.XYZComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class XYZComparer : IComparer<XYZ>
{
  private bool m_bSortByElevation = true;
  private bool m_bDecendingValues = true;

  int IComparer<XYZ>.Compare(XYZ first, XYZ second)
  {
    int num = 0;
    if (this.m_bSortByElevation)
    {
      if (first != null)
        num = second == null ? -1 : first.Z.CompareTo(second.Z);
      else if (second != null)
        num = 1;
    }
    if (this.m_bDecendingValues)
      num = -num;
    return num;
  }
}
