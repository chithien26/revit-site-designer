﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantGrowthModify
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantGrowthModify : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private DisplayUnit m_DisplayUnitSystem;
  private FormatOptions m_FormatOptions;
  private UnitSymbolType m_UnitSymbolType;
  private List<FamilySymbolContainer> m_FamilySymbolContainerList;
  private PlantGrowthListView m_ParameterListView = new PlantGrowthListView();
  private int m_nTypeIndex = -1;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;
  private Label m_TypeLbl;
  private Label m_lblPlantName;

  public PlantGrowthModify(
    ref List<FamilySymbolContainer> _FamilyTypeContainerList,
    Units _Units,
    DisplayUnit _UnitType,
    FormatOptions _FormatOption,
    UnitSymbolType _UnitSymbolType,
    DecimalSymbol _DecimalSymbolType,
    int _nTypeIndex)
  {
    this.InitializeComponent();
    this.m_FamilySymbolContainerList = _FamilyTypeContainerList;
    this.m_DisplayUnitSystem = _UnitType;
    this.m_FormatOptions = _FormatOption;
    this.m_UnitSymbolType = _UnitSymbolType;
    this.m_DecimalSymbolType = _DecimalSymbolType;
    this.m_nTypeIndex = _nTypeIndex;
    this.m_Units = _Units;
    this.InitializeData();
    this.GetDialogPosition();
    this.m_ParameterListView.OnListViewItemChanged += new ListViewItemChanged(this.ParameterListViewOnListViewItemChanged);
    this.FormClosing += new FormClosingEventHandler(this.PlantGrowthModifyFormClosing);
  }

  private void PlantGrowthModifyFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void ParameterListViewOnListViewItemChanged(int _nChangedIndex)
  {
    int _nReturnedInt = 0;
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (string.Compare(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), text1, true) == 0)
    {
      try
      {
        if (string.Compare(text2, EPShared.LocalRM.GetString("NotAvailableString"), true) == 0 || text2 == string.Empty)
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        else if (RevitGeometry.StrE_GetValidWholeNumber(text2, ref _nReturnedInt))
        {
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _nReturnedInt.ToString();
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        }
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else if (string.Compare($"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter")}", text1, true) == 0)
    {
      try
      {
        double _dReturnedDouble = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
    else
    {
      if (string.Compare($"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter")}", text1, true) != 0)
        return;
      try
      {
        double _dReturnedDouble = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
      }
      catch (Exception ex)
      {
        int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
        this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
        this.m_ParameterListView.SetFocus(_nChangedIndex);
      }
    }
  }

  private void InitializeData()
  {
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ParameterListView.View = View.Details;
    this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
    this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_ParameterListView
    });
    this.m_ParameterListView.Columns[0].Width = 215;
    this.m_ParameterListView.Columns[1].Width = 215;
    ListViewItem listViewItem1 = (ListViewItem) null;
    string empty = string.Empty;
    this.Text = $"{EPShared.LocalRM.GetString("ModifyDialog")} {EPShared.LocalRM.GetString("PlantDialog")}";
    this.m_TypeLbl.Text = $"{EPShared.LocalRM.GetString("FamilyString")} : {((Element) this.m_FamilySymbolContainerList[this.m_nTypeIndex].FamilySymbol.Family).Name}";
    this.m_lblPlantName.Text = $"{EPShared.LocalRM.GetString("PlantTypePlantFamilyParameter")} : {((Element) this.m_FamilySymbolContainerList[this.m_nTypeIndex].FamilySymbol).Name}";
    string serviceLife = EPShared.LocalRM.GetString("NotAvailableString");
    listViewItem1 = new ListViewItem();
    ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), string.Empty);
    if (string.Compare(this.m_FamilySymbolContainerList[this.m_nTypeIndex].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      serviceLife = this.m_FamilySymbolContainerList[this.m_nTypeIndex].ServiceLife;
    listViewItem2.SubItems.Add(serviceLife);
    listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = serviceLife;
    string _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
    listViewItem1 = new ListViewItem();
    ListViewItem listViewItem3 = this.m_ParameterListView.Items.Add($"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter")}", $"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter")}", string.Empty);
    if (string.Compare(this.m_FamilySymbolContainerList[this.m_nTypeIndex].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(this.m_FamilySymbolContainerList[this.m_nTypeIndex].MaxHeight), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
    listViewItem3.SubItems.Add(_strToDisplay);
    listViewItem3.SubItems[listViewItem3.SubItems.Count - 1].Text = _strToDisplay;
    _strToDisplay = EPShared.LocalRM.GetString("NotAvailableString");
    listViewItem1 = new ListViewItem();
    ListViewItem listViewItem4 = this.m_ParameterListView.Items.Add($"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter")}", $"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter")}", string.Empty);
    if (string.Compare(this.m_FamilySymbolContainerList[this.m_nTypeIndex].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(this.m_FamilySymbolContainerList[this.m_nTypeIndex].MaxWidth), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
    listViewItem4.SubItems.Add(_strToDisplay);
    listViewItem4.SubItems[listViewItem4.SubItems.Count - 1].Text = _strToDisplay;
  }

  private void OnButtonOkClicked(object sender, EventArgs e)
  {
    string str1 = string.Empty;
    string str2 = string.Empty;
    this.SetDialogPosition();
    for (int index1 = 0; index1 < this.m_ParameterListView.Items.Count; ++index1)
    {
      str1 = this.m_ParameterListView.Items[index1].SubItems[0].Text;
      str2 = this.m_ParameterListView.Items[index1].SubItems[1].Text;
      string empty = string.Empty;
      for (int index2 = 0; index2 < this.m_ParameterListView.Items.Count; ++index2)
      {
        string text1 = this.m_ParameterListView.Items[index2].SubItems[0].Text;
        string text2 = this.m_ParameterListView.Items[index2].SubItems[1].Text;
        if (string.Compare(text1, EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), true) == 0)
        {
          double _dReturnedDouble = 1.0;
          string str3 = EPShared.LocalRM.GetString("NotAvailableString");
          if (text2 != null && text2 != string.Empty && string.Compare(text2, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0 && RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
            str3 = Convert.ToInt32(_dReturnedDouble).ToString();
          this.m_FamilySymbolContainerList[this.m_nTypeIndex].ServiceLife = str3;
        }
        else if (string.Compare(text1, $"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter")}", true) == 0)
        {
          double _dReturnedDouble = 1.0;
          string str4 = EPShared.LocalRM.GetString("NotAvailableString");
          if (text2 != null && text2 != string.Empty && string.Compare(text2, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0 && RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
            str4 = ValueConversion.ToString(_dReturnedDouble);
          this.m_FamilySymbolContainerList[this.m_nTypeIndex].MaxHeight = str4;
        }
        else if (string.Compare(text1, $"{EPShared.LocalRM.GetString("MaximumString")} {EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter")}", true) == 0)
        {
          double _dReturnedDouble = 1.0;
          string str5 = EPShared.LocalRM.GetString("NotAvailableString");
          if (text2 != null && text2 != string.Empty && string.Compare(text2, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0 && RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
            str5 = ValueConversion.ToString(_dReturnedDouble);
          this.m_FamilySymbolContainerList[this.m_nTypeIndex].MaxWidth = str5;
        }
      }
    }
    this.DialogResult = DialogResult.OK;
  }

  private void OnButtonCancelClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.m_TypeLbl = new Label();
    this.m_lblPlantName = new Label();
    this.SuspendLayout();
    this.m_ButtonOk.Location = new Point(293, 153);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 1;
    this.m_ButtonOk.Text = "&OK";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnButtonOkClicked);
    this.m_ButtonCancel.Location = new Point(374, 153);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 2;
    this.m_ButtonCancel.Text = "&Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnButtonCancelClicked);
    this.m_TypeLbl.AutoSize = true;
    this.m_TypeLbl.Location = new Point(9, 9);
    this.m_TypeLbl.Name = "m_TypeLbl";
    this.m_TypeLbl.Size = new Size(33, 13);
    this.m_TypeLbl.TabIndex = 41;
    this.m_TypeLbl.Text = "LBLT";
    this.m_lblPlantName.AutoSize = true;
    this.m_lblPlantName.Location = new Point(9, 32 /*0x20*/);
    this.m_lblPlantName.Name = "m_lblPlantName";
    this.m_lblPlantName.Size = new Size(33, 13);
    this.m_lblPlantName.TabIndex = 42;
    this.m_lblPlantName.Text = "LBLB";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(452, 183);
    this.Controls.Add((Control) this.m_lblPlantName);
    this.Controls.Add((Control) this.m_TypeLbl);
    this.Controls.Add((Control) this.m_ButtonCancel);
    this.Controls.Add((Control) this.m_ButtonOk);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (PlantGrowthModify);
    this.Text = nameof (PlantGrowthModify);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
