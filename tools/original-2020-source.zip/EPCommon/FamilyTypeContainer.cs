﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyTypeContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FamilyTypeContainer
{
  private FamilyTypeWrapper m_FamilyTypeWrapper;
  private List<FamilyParameterWrapper> m_FamilyParameterList;
  private FamilyParameterWrapperStatus m_Status;

  public FamilyTypeContainer(
    FamilyTypeWrapper _FamilyTypeWrapper,
    List<FamilyParameterWrapper> _FamilyParameterList)
  {
    this.m_Status = FamilyParameterWrapperStatus.Included;
    this.m_FamilyTypeWrapper = _FamilyTypeWrapper;
    this.m_FamilyParameterList = _FamilyParameterList;
    if (this.m_FamilyTypeWrapper == null)
      return;
    double _dValue = 0.0;
    int _nValue = 0;
    string empty = string.Empty;
    ElementId elementId = (ElementId) null;
    for (int index = 0; index < this.m_FamilyParameterList.Count; ++index)
    {
      FamilyParameterWrapper familyParameter = this.m_FamilyParameterList[index];
      if (familyParameter != null && familyParameter.FamilyParameter != null && (familyParameter.FamilyParameter.Formula == null || familyParameter.FamilyParameter.Formula == string.Empty) && this.HasValue(index))
      {
        switch (familyParameter.StorageType - 1)
        {
          case 0:
            if (this.GetIntegerValue(index, ref _nValue))
            {
              familyParameter.IntegerValue = _nValue;
              continue;
            }
            continue;
          case 1:
            if (this.GetDoubleValue(index, ref _dValue))
            {
              familyParameter.DoubleValue = _dValue;
              continue;
            }
            continue;
          case 2:
            if (this.GetStringValue(index, ref empty))
            {
              familyParameter.Value = empty;
              continue;
            }
            continue;
          case 3:
            if (this.GetElementIdValue(index, ref elementId))
            {
              familyParameter.ElementIdValue = elementId;
              continue;
            }
            continue;
          default:
            continue;
        }
      }
    }
  }

  public FamilyTypeContainer() => this.m_Status = FamilyParameterWrapperStatus.Included;

  public bool HasValue(int _nParameterIndex)
  {
    if (_nParameterIndex >= 0 && _nParameterIndex < this.m_FamilyParameterList.Count)
    {
      if (!this.m_FamilyParameterList[_nParameterIndex].InternalValueSet && this.m_FamilyTypeWrapper.FamilyType != null && this.m_FamilyParameterList[_nParameterIndex].FamilyParameter != null)
        return this.m_FamilyTypeWrapper.FamilyType.HasValue(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter);
      if (this.m_FamilyParameterList[_nParameterIndex].Value != null && this.m_FamilyParameterList[_nParameterIndex].Value != string.Empty)
        return true;
    }
    return false;
  }

  public bool GetDoubleValue(int _nParameterIndex, ref double _dValue)
  {
    if (_nParameterIndex >= 0 && _nParameterIndex < this.m_FamilyParameterList.Count)
    {
      if (!this.m_FamilyParameterList[_nParameterIndex].InternalValueSet && this.m_FamilyTypeWrapper.FamilyType != null && this.m_FamilyParameterList[_nParameterIndex].FamilyParameter != null)
      {
        if ((ValueType) this.m_FamilyTypeWrapper.FamilyType.AsDouble(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter) is double)
        {
          _dValue = this.m_FamilyTypeWrapper.FamilyType.AsDouble(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter).Value;
          this.m_FamilyParameterList[_nParameterIndex].Value = ValueConversion.ToString(_dValue);
          return true;
        }
      }
      else if (this.m_FamilyParameterList[_nParameterIndex].Value != null && this.m_FamilyParameterList[_nParameterIndex].Value != string.Empty)
      {
        _dValue = this.m_FamilyParameterList[_nParameterIndex].DoubleValue;
        return true;
      }
    }
    return false;
  }

  public bool GetIntegerValue(int _nParameterIndex, ref int _nValue)
  {
    if (_nParameterIndex >= 0 && _nParameterIndex < this.m_FamilyParameterList.Count)
    {
      if (!this.m_FamilyParameterList[_nParameterIndex].InternalValueSet && this.m_FamilyTypeWrapper.FamilyType != null && this.m_FamilyParameterList[_nParameterIndex].FamilyParameter != null)
      {
        if ((ValueType) this.m_FamilyTypeWrapper.FamilyType.AsInteger(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter) is int)
        {
          _nValue = this.m_FamilyTypeWrapper.FamilyType.AsInteger(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter).Value;
          this.m_FamilyParameterList[_nParameterIndex].Value = Convert.ToString(_nValue);
          return true;
        }
      }
      else if (this.m_FamilyParameterList[_nParameterIndex].Value != null && this.m_FamilyParameterList[_nParameterIndex].Value != string.Empty)
      {
        _nValue = string.Compare(this.m_FamilyParameterList[_nParameterIndex].Value, EPShared.LocalRM.GetString("YesString"), true) != 0 ? (string.Compare(this.m_FamilyParameterList[_nParameterIndex].Value, EPShared.LocalRM.GetString("NoString"), true) != 0 ? this.m_FamilyParameterList[_nParameterIndex].IntegerValue : 0) : 1;
        return true;
      }
    }
    return false;
  }

  public bool GetStringValue(int _nParameterIndex, ref string _strValue)
  {
    if (_nParameterIndex >= 0 && _nParameterIndex < this.m_FamilyParameterList.Count)
    {
      if (!this.m_FamilyParameterList[_nParameterIndex].InternalValueSet && this.m_FamilyTypeWrapper.FamilyType != null && this.m_FamilyParameterList[_nParameterIndex].FamilyParameter != null)
      {
        if (this.m_FamilyTypeWrapper.FamilyType.AsString(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter) != null)
        {
          _strValue = this.m_FamilyTypeWrapper.FamilyType.AsString(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter);
          this.m_FamilyParameterList[_nParameterIndex].Value = _strValue;
          return true;
        }
      }
      else if (this.m_FamilyParameterList[_nParameterIndex].Value != null)
      {
        _strValue = this.m_FamilyParameterList[_nParameterIndex].Value;
        return true;
      }
    }
    return false;
  }

  public bool GetElementIdValue(int _nParameterIndex, ref ElementId _Value)
  {
    if (_nParameterIndex >= 0 && _nParameterIndex < this.m_FamilyParameterList.Count)
    {
      if (!this.m_FamilyParameterList[_nParameterIndex].InternalValueSet && this.m_FamilyTypeWrapper.FamilyType != null && this.m_FamilyParameterList[_nParameterIndex].FamilyParameter != null)
      {
        _Value = this.m_FamilyTypeWrapper.FamilyType.AsElementId(this.m_FamilyParameterList[_nParameterIndex].FamilyParameter);
        this.m_FamilyParameterList[_nParameterIndex].Value = Convert.ToString(_Value.IntegerValue);
        return true;
      }
      if (this.m_FamilyParameterList[_nParameterIndex].Value != null && this.m_FamilyParameterList[_nParameterIndex].Value != string.Empty)
      {
        _Value = this.m_FamilyParameterList[_nParameterIndex].ElementIdValue;
        return true;
      }
    }
    return false;
  }

  public FamilyTypeWrapper FamilyTypeWrapper
  {
    get => this.m_FamilyTypeWrapper;
    set => this.m_FamilyTypeWrapper = value;
  }

  public List<FamilyParameterWrapper> FamilyParameterList
  {
    get => this.m_FamilyParameterList;
    set => this.m_FamilyParameterList = value;
  }

  public FamilyParameterWrapperStatus Status
  {
    get => this.m_Status;
    set => this.m_Status = value;
  }
}
