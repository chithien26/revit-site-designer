﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.BaseArc
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class BaseArc
{
  private Eps_Point m_StartPnt;
  private Eps_Point m_EndPnt;
  private Eps_Point m_RadiusPnt;
  private double m_dDelta;
  private double m_dRadius;
  private int m_nDirection;

  public BaseArc()
  {
    this.m_StartPnt = new Eps_Point();
    this.m_EndPnt = new Eps_Point();
    this.m_RadiusPnt = new Eps_Point();
    this.m_nDirection = -1;
    this.m_dDelta = 0.0;
    this.m_dRadius = 0.0;
  }

  public BaseArc(Arc _Arc)
  {
    if (((Curve) _Arc).IsBound)
    {
      this.m_StartPnt = new Eps_Point(((Curve) _Arc).GetEndPoint(0));
      this.m_EndPnt = new Eps_Point(((Curve) _Arc).GetEndPoint(1));
    }
    else
    {
      IList<XYZ> xyzList = ((Curve) _Arc).Tessellate();
      if (xyzList.Count > 0)
      {
        this.m_StartPnt = new Eps_Point(xyzList[0]);
        this.m_EndPnt = new Eps_Point(xyzList[xyzList.Count - 1]);
      }
    }
    this.m_RadiusPnt = new Eps_Point(_Arc.Center);
    this.m_nDirection = _Arc.Normal.Z <= 0.0 ? -1 : 1;
    this.m_dDelta = ((Curve) _Arc).Length / _Arc.Radius;
    this.m_dRadius = _Arc.Radius;
  }

  public BaseArc(BaseArc _Arc)
  {
    this.m_dDelta = _Arc.Delta;
    this.m_EndPnt = new Eps_Point(_Arc.EndPnt);
    this.m_dRadius = _Arc.Radius;
    this.m_nDirection = _Arc.Direction;
    this.m_RadiusPnt = new Eps_Point(_Arc.RadiusPnt);
    this.m_StartPnt = new Eps_Point(_Arc.StartPnt);
  }

  public bool IsEqual(BaseArc _CompareArc) => this.IsEqual(_CompareArc, false);

  public bool IsEqual(BaseArc _CompareArc, bool _bCompareDirection)
  {
    bool flag = false;
    if ((EPShared.eplGeoE_ArePntsDuplicates2D(this.m_StartPnt, _CompareArc.StartPnt) && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_EndPnt, _CompareArc.EndPnt) && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_RadiusPnt, _CompareArc.RadiusPnt) && this.m_nDirection == _CompareArc.Direction || EPShared.eplGeoE_ArePntsDuplicates2D(this.m_EndPnt, _CompareArc.StartPnt) && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_StartPnt, _CompareArc.EndPnt) && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_RadiusPnt, _CompareArc.RadiusPnt)) && (!_bCompareDirection || this.m_nDirection == _CompareArc.Direction))
      flag = true;
    return flag;
  }

  public Eps_Point StartPnt
  {
    get => this.m_StartPnt;
    set => this.m_StartPnt = value;
  }

  public Eps_Point RadiusPnt
  {
    get => this.m_RadiusPnt;
    set => this.m_RadiusPnt = value;
  }

  public Eps_Point EndPnt
  {
    get => this.m_EndPnt;
    set => this.m_EndPnt = value;
  }

  public int Direction
  {
    get => this.m_nDirection;
    set => this.m_nDirection = value;
  }

  public double Delta
  {
    get => this.m_dDelta;
    set => this.m_dDelta = value;
  }

  public double Radius
  {
    get => this.m_dRadius;
    set => this.m_dRadius = value;
  }
}
