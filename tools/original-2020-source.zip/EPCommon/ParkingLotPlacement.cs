﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParkingLotPlacement
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ParkingLotPlacement
{
  private ParkingLotPlacementForm m_ParkingLotPlacementForm;
  private Document m_Document;
  private List<View> m_ViewList;
  private List<TopographySurfaceContainer> m_SurfaceList;
  private List<FamilyContainer> m_ParkingStallFamilyList;
  private List<FamilyContainer> m_ParkingBumperFamilyList;
  private List<FamilyContainer> m_ADAParkingStallFamilyList;
  private List<FamilyContainer> m_ParkingIslandFamilyList;
  private PlacementSettings m_PlacementSettings;
  private EPTransactionContainer m_TransactionContainer;
  private FamilySymbol m_PlacementSymbol;

  public ParkingLotPlacement(Document _CurDocument)
  {
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_ViewList = new List<View>();
    this.m_SurfaceList = new List<TopographySurfaceContainer>();
    this.m_ParkingStallFamilyList = new List<FamilyContainer>();
    this.m_ParkingBumperFamilyList = new List<FamilyContainer>();
    this.m_ADAParkingStallFamilyList = new List<FamilyContainer>();
    this.m_ParkingIslandFamilyList = new List<FamilyContainer>();
    this.InitializeListData();
  }

  public void PopulateFamilyAndSymbolLists()
  {
    this.PopulateFamilyAndSymbolLists(true, LandcaddID.ParkingStall);
  }

  public void PopulateFamilyAndSymbolLists(LandcaddID _ParkingType)
  {
    this.PopulateFamilyAndSymbolLists(false, _ParkingType);
  }

  private void PopulateFamilyAndSymbolLists(bool _bAllSymbols, LandcaddID _ParkingType)
  {
    if (_bAllSymbols || _ParkingType == LandcaddID.ParkingStall)
      this.m_ParkingStallFamilyList.Clear();
    if (_bAllSymbols || _ParkingType == LandcaddID.ADAParkingStall)
      this.m_ADAParkingStallFamilyList.Clear();
    if (_bAllSymbols || _ParkingType == LandcaddID.ParkingBumper)
      this.m_ParkingBumperFamilyList.Clear();
    if (_bAllSymbols || _ParkingType == LandcaddID.ParkingIsland)
      this.m_ParkingIslandFamilyList.Clear();
    FilteredElementCollector source1 = new FilteredElementCollector(this.m_Document);
    source1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001180);
    List<Element> list1 = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter) != null)).ToList<Element>();
    FamilySymbol familySymbol1 = (FamilySymbol) null;
    foreach (Element element in list1)
    {
      if (element is FamilySymbol _CurFamilySymbol && ((Element) _CurFamilySymbol).Category != null && ((Element) _CurFamilySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001180).GetHashCode())
      {
        Parameter parameter = ((Element) _CurFamilySymbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (parameter != null)
        {
          if (string.Compare(parameter.AsString(), Convert.ToInt32((object) LandcaddID.ParkingStall).ToString("000"), true) == 0)
          {
            if (_bAllSymbols || _ParkingType == LandcaddID.ParkingStall)
              this.PopulateFamilySymbolInList(_CurFamilySymbol, ref this.m_ParkingStallFamilyList);
          }
          else if (string.Compare(parameter.AsString(), Convert.ToInt32((object) LandcaddID.ADAParkingStall).ToString("000"), true) == 0)
          {
            if (_bAllSymbols || _ParkingType == LandcaddID.ADAParkingStall)
              this.PopulateFamilySymbolInList(_CurFamilySymbol, ref this.m_ADAParkingStallFamilyList);
          }
          else if (string.Compare(parameter.AsString(), Convert.ToInt32((object) LandcaddID.ParkingBumper).ToString("000"), true) == 0)
          {
            if (_bAllSymbols || _ParkingType == LandcaddID.ParkingBumper)
              this.PopulateFamilySymbolInList(_CurFamilySymbol, ref this.m_ParkingBumperFamilyList);
          }
          else if (string.Compare(parameter.AsString(), Convert.ToInt32((object) LandcaddID.ParkingIsland).ToString("000"), true) == 0 && (_bAllSymbols || _ParkingType == LandcaddID.ParkingIsland))
            this.PopulateFamilySymbolInList(_CurFamilySymbol, ref this.m_ParkingIslandFamilyList);
        }
      }
    }
    FilteredElementCollector source2 = new FilteredElementCollector(this.m_Document);
    source2.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151);
    Parameter CurLanddCadID = (Parameter) null;
    List<Element> list2 = ((IEnumerable<Element>) source2).Where<Element>((Func<Element, bool>) (CurrentElement => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)).ToList<Element>();
    bool flag = false;
    familySymbol1 = (FamilySymbol) null;
    foreach (Element element in list2)
    {
      if (element is FamilySymbol familySymbol2 && ((Element) familySymbol2).Category != null)
      {
        CurLanddCadID = ((Element) familySymbol2).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)
        {
          this.m_PlacementSymbol = familySymbol2;
          flag = true;
          break;
        }
      }
    }
    if (_bAllSymbols && (this.m_ParkingStallFamilyList.Count == 0 || this.m_ADAParkingStallFamilyList.Count == 0 || this.m_ParkingBumperFamilyList.Count == 0 || this.m_ParkingIslandFamilyList.Count == 0 || !flag))
    {
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(this.m_Document.PathName, "ParkingLot", EPShared.LocalRM.GetString("ParkingFamiliesNotLoadedMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"),
        EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption")
      });
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), true) == 0)
      {
        Family _Family = (Family) null;
        string empty = string.Empty;
        if (this.m_ParkingStallFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Standard Parking.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
                this.PopulateFamilySymbolInList(element, ref this.m_ParkingStallFamilyList);
            }
          }
        }
        if (this.m_ADAParkingStallFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Accessible Parking.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadADAParkingFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
                this.PopulateFamilySymbolInList(element, ref this.m_ADAParkingStallFamilyList);
            }
          }
        }
        if (this.m_ParkingBumperFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Parking Concrete Bumper.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingBumperFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
                this.PopulateFamilySymbolInList(element, ref this.m_ParkingBumperFamilyList);
            }
          }
        }
        if (this.m_ParkingIslandFamilyList.Count == 0 && RevitUtility.GetFullFamilyFilenameIfExist("Parking", "LC Center Parking Island.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadParkingIslandFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
                this.PopulateFamilySymbolInList(element, ref this.m_ParkingIslandFamilyList);
            }
          }
        }
        if (!flag && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            using (IEnumerator<ElementId> enumerator = _Family.GetFamilySymbolIds().GetEnumerator())
            {
              if (enumerator.MoveNext())
              {
                if (this.m_Document.GetElement(enumerator.Current) is FamilySymbol element)
                  this.m_PlacementSymbol = element;
              }
            }
          }
        }
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    if (_bAllSymbols || _ParkingType == LandcaddID.ParkingStall)
    {
      for (int index = 0; index < this.m_ParkingStallFamilyList.Count; ++index)
        this.m_ParkingStallFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
    }
    if (_bAllSymbols || _ParkingType == LandcaddID.ADAParkingStall)
    {
      for (int index = 0; index < this.m_ADAParkingStallFamilyList.Count; ++index)
        this.m_ADAParkingStallFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
    }
    if (_bAllSymbols || _ParkingType == LandcaddID.ParkingBumper)
    {
      for (int index = 0; index < this.m_ParkingBumperFamilyList.Count; ++index)
        this.m_ParkingBumperFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
    }
    if (!_bAllSymbols && _ParkingType != LandcaddID.ParkingIsland)
      return;
    for (int index = 0; index < this.m_ParkingIslandFamilyList.Count; ++index)
      this.m_ParkingIslandFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  private void InitializeListData()
  {
    this.PopulateFamilyAndSymbolLists();
    foreach (View element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (View)).ToElements())
    {
      if (element.GenLevel != null && !this.m_ViewList.Contains(element) && (element.ViewType == 1 || element.ViewType == 115 || element.ViewType == 116) && string.Compare(((Element) element).Name, EPShared.LocalRM.GetString("SiteString"), true) != 0)
      {
        bool flag = false;
        for (int index = 0; index < this.m_ViewList.Count; ++index)
        {
          if (string.Compare(((Element) this.m_ViewList[index].GenLevel).UniqueId, ((Element) element.GenLevel).UniqueId, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          this.m_ViewList.Add(element);
      }
    }
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
      this.m_SurfaceList.Add(new TopographySurfaceContainer(this.m_Document.Application, element as TopographySurface));
  }

  private void PopulateFamilySymbolInList(
    FamilySymbol _CurFamilySymbol,
    ref List<FamilyContainer> _FamilyList)
  {
    bool flag = false;
    for (int index = 0; index < _FamilyList.Count; ++index)
    {
      if (string.Compare(_FamilyList[index].FamilyName, ((Element) _CurFamilySymbol.Family).Name, true) == 0)
      {
        _FamilyList[index].FamilySymbolList.Add(_CurFamilySymbol);
        flag = true;
        break;
      }
    }
    if (flag)
      return;
    _FamilyList.Add(new FamilyContainer(((Element) _CurFamilySymbol.Family).Name)
    {
      FamilySymbolList = {
        _CurFamilySymbol
      }
    });
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    if (this.m_ParkingStallFamilyList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_ParkingLotPlacementForm = new ParkingLotPlacementForm(this))
    {
      while (_DialogResult != DialogResult.Cancel)
      {
        flag = this.ShowDialog(ref _DialogResult);
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    return flag;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    int num1 = (int) this.m_ParkingLotPlacementForm.ShowDialog();
    _DialogResult = this.m_ParkingLotPlacementForm.DialogResult;
    if (_DialogResult == DialogResult.Cancel)
      return false;
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ParkingLotTransaction"));
    List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
    if (this.m_ParkingLotPlacementForm.PickToposurface)
      _SurfaceList.Add(this.m_ParkingLotPlacementForm.Surface);
    this.PopulatePlacementSettingsStructure(_SurfaceList);
    if (!this.m_ParkingLotPlacementForm.ExistingElementChecked)
    {
      string _strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
      ElementSet elm_set = new ElementSet();
      List<ModelCurve> modelCurveList = new List<ModelCurve>();
      Eps_Leg _CurrentLeg = (Eps_Leg) null;
      Eps_Point _Point = (Eps_Point) null;
      Eps_Point epsPoint = (Eps_Point) null;
      bool flag1 = true;
      while (flag1)
      {
        flag1 = RevitUtility.GetPointFromProject(this.m_Document, _strPrompt, ref _Point, false);
        if (flag1)
        {
          if (epsPoint != null)
          {
            Eps_Leg _CompleteLeg = new Eps_Leg();
            _CompleteLeg.Line = new Eps_Line();
            _CompleteLeg.Line.StartPnt = epsPoint;
            _CompleteLeg.Line.EndPnt = _Point;
            if (_CurrentLeg == null)
              _CurrentLeg = Eps_Leg.SingleLeg(_CompleteLeg);
            else
              _CurrentLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
            this.m_TransactionContainer.BeginTransaction();
            modelCurveList.Add(RevitUtility.NewModelCurve(this.m_Document, _CompleteLeg.Line));
            this.m_TransactionContainer.EndTransaction();
            if (!this.m_ParkingLotPlacementForm.ParkingChainChecked || this.m_ParkingLotPlacementForm.ParkingAreaChecked || this.m_PlacementSettings.Parking.PlaceIsland && this.m_ParkingLotPlacementForm.IslandSymbol != null)
              flag1 = false;
          }
          else
            _strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
          epsPoint = _Point;
        }
      }
      for (int index = 0; index < modelCurveList.Count; ++index)
        elm_set.Insert((Element) modelCurveList[index]);
      bool flag2 = true;
      if (_CurrentLeg != null)
      {
        if (this.m_ParkingLotPlacementForm.ParkingChainChecked && !this.m_ParkingLotPlacementForm.ParkingAreaChecked && (!this.m_PlacementSettings.Parking.PlaceIsland || this.m_ParkingLotPlacementForm.IslandSymbol == null))
          flag2 = ParkingLotCommon.PlaceLegList(this.m_Document, this.m_PlacementSettings, _CurrentLeg);
        else if (_CurrentLeg.Line != null)
          flag2 = ParkingLotCommon.PlaceStallsOnLine(this.m_Document, this.m_PlacementSettings, (Element) null, _CurrentLeg.Line, (Eps_Line) null, _CurrentLeg.Line, false);
      }
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
      return flag2;
    }
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
      return false;
    foreach (Element element in _Elements)
    {
      LocationCurve location = element.Location as LocationCurve;
      Curve _Arc = (Curve) null;
      if (location != null)
        _Arc = location.Curve;
      if (GeometryObject.op_Inequality((GeometryObject) _Arc, (GeometryObject) null))
      {
        Eps_Leg epsLeg = (Eps_Leg) null;
        if (location != null && this.m_ParkingLotPlacementForm.ParkingChainChecked && !this.m_ParkingLotPlacementForm.ParkingAreaChecked && (!this.m_PlacementSettings.Parking.PlaceIsland || this.m_ParkingLotPlacementForm.IslandSymbol == null))
          epsLeg = RevitGeometry.GetLegFromElementList((Eps_Leg) null, element);
        if (epsLeg != null)
        {
          if (RevitDefines.GT(this.m_ParkingLotPlacementForm.StartingDistance, RevitGeometry.eplGeoE_CalcLegListLength(epsLeg)))
          {
            int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return false;
          }
          ParkingLotCommon.PlaceLegList(this.m_Document, this.m_PlacementSettings, epsLeg);
        }
        else
        {
          switch (_Arc)
          {
            case Arc _:
              if (RevitDefines.GT(this.m_ParkingLotPlacementForm.StartingDistance, _Arc.Length))
              {
                int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              if (this.m_ParkingLotPlacementForm.ParkingAreaChecked)
              {
                int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoParkingSpacesOnArc"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              if (this.m_PlacementSettings.Parking.PlaceIsland && this.m_ParkingLotPlacementForm.IslandSymbol != null)
              {
                int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoIslandOnArcMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              bool _bPickFirstArc = true;
              Eps_Arc epsArc = new Eps_Arc((Arc) _Arc);
              Eps_Arc _FirstArc = (Eps_Arc) null;
              Eps_Arc _SecondArc = (Eps_Arc) null;
              if (!RevitUtility.BreakApartArc(this.m_Document, this.m_TransactionContainer, this.m_PlacementSettings.Width / 2.0, epsArc, this.m_PlacementSettings.Parking.PromptForDirection, ref _FirstArc, ref _SecondArc, ref _bPickFirstArc))
                return false;
              this.m_PlacementSettings.IsReverse = _bPickFirstArc;
              if (_FirstArc != null && _SecondArc != null)
                this.m_PlacementSettings.Parking.MiddleStallPlacement = true;
              if (!ParkingLotCommon.PlaceStallsOnArc(this.m_Document, this.m_PlacementSettings, element, epsArc, _FirstArc, _SecondArc, _bPickFirstArc))
                return false;
              break;
            case Line _:
              if (RevitDefines.GT(this.m_ParkingLotPlacementForm.StartingDistance, _Arc.Length))
              {
                int num6 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
              bool _bPickFirstLine = true;
              Eps_Line _FirstLine = (Eps_Line) null;
              Eps_Line _SecondLine = (Eps_Line) null;
              Eps_Line _EvalLine = new Eps_Line();
              _EvalLine.StartPnt = new Eps_Point(_Arc.GetEndPoint(0));
              _EvalLine.EndPnt = new Eps_Point(_Arc.GetEndPoint(1));
              if (this.m_ParkingLotPlacementForm.ParkingAreaChecked)
              {
                if (!RevitUtility.EvaluateLine(this.m_Document, this.m_TransactionContainer, this.m_PlacementSettings.Width / 2.0, ref _EvalLine))
                  return false;
                this.m_PlacementSettings.IsReverse = _EvalLine.IsReverse;
                _FirstLine = _EvalLine;
                _SecondLine = _EvalLine;
              }
              else
              {
                if (!RevitUtility.BreakApartLine(this.m_Document, this.m_TransactionContainer, this.m_PlacementSettings.Width / 2.0, _EvalLine, this.m_PlacementSettings.Parking.PromptForDirection, ref _FirstLine, ref _SecondLine, ref _bPickFirstLine))
                  return false;
                this.m_PlacementSettings.IsReverse = _bPickFirstLine;
                if (_FirstLine != null && _SecondLine != null)
                  this.m_PlacementSettings.Parking.MiddleStallPlacement = true;
              }
              if (!ParkingLotCommon.PlaceStallsOnLine(this.m_Document, this.m_PlacementSettings, element, _EvalLine, _FirstLine, _SecondLine, _bPickFirstLine))
                return false;
              break;
            default:
              int num7 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ParkingNotObjectSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
          }
          if (this.m_ParkingLotPlacementForm.DeleteExistingChecked)
          {
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.Delete(element.Id);
            this.m_TransactionContainer.EndTransaction();
          }
        }
      }
    }
    return true;
  }

  private void PopulatePlacementSettingsStructure(List<TopographySurfaceContainer> _SurfaceList)
  {
    this.m_PlacementSettings = new PlacementSettings();
    this.m_PlacementSettings.PlacementType = this.m_ParkingLotPlacementForm.PlacementType;
    this.m_PlacementSettings.TransactionContainer = this.m_TransactionContainer;
    this.m_PlacementSettings.PlacementSymbol = this.m_PlacementSymbol;
    this.m_PlacementSettings.Type = this.m_ParkingLotPlacementForm.ParkingStallSymbol;
    this.m_PlacementSettings.LocateType = LocateType.ParkingLot;
    this.m_PlacementSettings.View = this.m_ParkingLotPlacementForm.View;
    this.m_PlacementSettings.Level = this.m_ParkingLotPlacementForm.Level;
    this.m_PlacementSettings.DeleteExistingChecked = this.m_ParkingLotPlacementForm.DeleteExistingChecked;
    this.m_PlacementSettings.ExistingElementChecked = this.m_ParkingLotPlacementForm.ExistingElementChecked;
    this.m_PlacementSettings.SurfaceList = _SurfaceList;
    this.m_PlacementSettings.Parking.ADAStallSymbol = this.m_ParkingLotPlacementForm.ADAParkingStallSymbol;
    this.m_PlacementSettings.Parking.BumperSymbol = this.m_ParkingLotPlacementForm.BumperSymbol;
    this.m_PlacementSettings.Parking.IslandSymbol = this.m_ParkingLotPlacementForm.IslandSymbol;
    this.m_PlacementSettings.RotationAngle = this.m_ParkingLotPlacementForm.ParkingAngle;
    this.m_PlacementSettings.Parking.StallLength = this.m_ParkingLotPlacementForm.ParkingLength;
    this.m_PlacementSettings.Width = this.m_ParkingLotPlacementForm.ParkingWidth;
    this.m_PlacementSettings.Parking.StallCount = this.m_ParkingLotPlacementForm.ParkingNumberOfSpaces;
    this.m_PlacementSettings.Parking.OptimizeParking = this.m_ParkingLotPlacementForm.ParkingOptimizeChecked;
    if (this.m_ParkingLotPlacementForm.ADAPlaceParkingSpacesChecked)
    {
      this.m_PlacementSettings.Parking.ADAStallWidth = this.m_ParkingLotPlacementForm.ADAParkingWidth;
      this.m_PlacementSettings.Parking.ADAStallCount = this.m_ParkingLotPlacementForm.ADAParkingNumberOfSpaces;
      this.m_PlacementSettings.Parking.ADAStallSharedAccessibleAisle = this.m_ParkingLotPlacementForm.ADASharedAccessibleAisleChecked;
    }
    this.m_PlacementSettings.Parking.PlaceBumper = this.m_ParkingLotPlacementForm.BumperPlaceChecked;
    this.m_PlacementSettings.Parking.BumperWidth = this.m_ParkingLotPlacementForm.BumperWidth;
    this.m_PlacementSettings.Parking.BumperSetback = this.m_ParkingLotPlacementForm.BumperSetback;
    this.m_PlacementSettings.Parking.BumperOffset = this.m_ParkingLotPlacementForm.BumperOffset;
    this.m_PlacementSettings.Parking.BumperHeight = this.m_ParkingLotPlacementForm.BumperHeight;
    this.m_PlacementSettings.Parking.AreaAisleWidth = this.m_ParkingLotPlacementForm.AreaAisleWidth;
    this.m_PlacementSettings.Parking.AreaBiDirectionalAisles = this.m_ParkingLotPlacementForm.AreaBiDirectionalAisles;
    this.m_PlacementSettings.Parking.AreaDistanceBetweenCenterlines = this.m_ParkingLotPlacementForm.AreaDistanceBetweenCenterlines;
    this.m_PlacementSettings.Parking.AreaRowSpacingOptions = this.m_ParkingLotPlacementForm.AreaRowSpacingOptions;
    this.m_PlacementSettings.Parking.AreaRowCount = this.m_ParkingLotPlacementForm.AreaParkingNumberOfRows;
    this.m_PlacementSettings.Parking.PromptForDirection = !this.m_PlacementSettings.Parking.OptimizeParking || this.m_PlacementSettings.Parking.ADAStallCount != 0;
    this.m_PlacementSettings.Parking.PlaceIsland = this.m_ParkingLotPlacementForm.IslandPlaceChecked;
    if (this.m_ParkingLotPlacementForm.IslandPlaceChecked)
    {
      this.m_PlacementSettings.Parking.IslandWidth = this.m_ParkingLotPlacementForm.IslandWidth;
      this.m_PlacementSettings.Parking.IslandHeight = this.m_ParkingLotPlacementForm.IslandHeight;
    }
    this.m_PlacementSettings.StartingDistance = this.m_ParkingLotPlacementForm.StartingDistance;
  }

  public ReadOnlyCollection<View> Views
  {
    get => new ReadOnlyCollection<View>((IList<View>) this.m_ViewList);
  }

  public Document Document => this.m_Document;

  public ReadOnlyCollection<FamilyContainer> ParkingStallFamilyList
  {
    get
    {
      return new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_ParkingStallFamilyList);
    }
  }

  public ReadOnlyCollection<FamilyContainer> ADAParkingStallFamilyList
  {
    get
    {
      return new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_ADAParkingStallFamilyList);
    }
  }

  public ReadOnlyCollection<FamilyContainer> ParkingBumperFamilyList
  {
    get
    {
      return new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_ParkingBumperFamilyList);
    }
  }

  public ReadOnlyCollection<FamilyContainer> ParkingIslandFamilyList
  {
    get
    {
      return new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_ParkingIslandFamilyList);
    }
  }

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }

  public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList
  {
    get
    {
      return new ReadOnlyCollection<TopographySurfaceContainer>((IList<TopographySurfaceContainer>) this.m_SurfaceList);
    }
  }
}
