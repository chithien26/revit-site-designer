﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ManagePlants
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ManagePlants
{
  public static PlantField GetPlantFieldFromParamenter(string _strValue)
  {
    PlantField fieldFromParamenter = PlantField.None;
    if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantScientificNamePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantScientificName;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantCommonNamePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantCommonName;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantCodeNamePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantCodeName;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsAdmirationPointPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsAdmirationPoint;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("TemperatureRangePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.TemperatureRange;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ConditionsSoilConditionPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.ConditionsSoilCondition;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ConditionsExposurePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.ConditionsExposure;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ConditionsMiscellaneousPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.ConditionsMiscellaneous;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ConditionsTolerancesPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.ConditionsTolerances;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantTypePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantType;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GrowthGrowthRatePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.GrowthGrowthRate;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.GrowthServiceLife;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantHeight;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantWidth;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GrowthPatternPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.GrowthPattern;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GrowthFormPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.GrowthForm;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenanceWaterRequirementsPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenanceWaterRequirements;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenanceTransplantPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenanceTransplant;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenanceDetrimentsPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenanceDetriments;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenancePlantingTimePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenancePlantingTime;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenanceTransplantingTimePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenanceTransplantingTime;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenanceFertilizingTimePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenanceFertilizingTime;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("MaintenancePruningTimePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.MaintenancePruningTime;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFoliageSize;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFoliageSurfacePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFoliageSurface;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFoliageColorPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFoliageColor;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFallColorPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFallColor;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsCrownDensityPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsCrownDensity;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsBarkSurfacePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsBarkSurface;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsBarkColorPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsBarkColor;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFruitColorPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFruitColor;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsBloomEffectPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsBloomEffect;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFragrancePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFragrance;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsBloomPeriodPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsBloomPeriod;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CharacteristicsFruitPeriodPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.CharacteristicsFruitPeriod;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantUsesPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantUses;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantClimateAndZonePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantClimateAndZone;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantingSizePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantingSize;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantSpacing;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantCommentsPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantComments;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantingSymbol;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantCount;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.GenericModelSymbol;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.PlantPlacementID;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.Height;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("KeynotePlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.Keynote;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ModelPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.Model;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ManufacturerPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.Manufacturer;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("TypeCommentsPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.TypeComments;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("URLPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.URL;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("DescriptionPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.Description;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("CostPlantFamilyParameter"), true) == 0)
      fieldFromParamenter = PlantField.Cost;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), true) == 0)
      fieldFromParamenter = PlantField.TypeName;
    return fieldFromParamenter;
  }

  public static PlantField GetPlantField(string _strPlantFieldName)
  {
    foreach (int num in Enum.GetValues(typeof (PlantField)))
    {
      if (string.Compare(_strPlantFieldName, Enum.GetName(typeof (PlantField), (object) num), true) == 0)
        return (PlantField) Enum.ToObject(typeof (PlantField), num);
    }
    return PlantField.None;
  }

  public static string GetPlantParamenterName(PlantField _PlantField)
  {
    string empty = string.Empty;
    switch (_PlantField)
    {
      case PlantField.PlantScientificName:
        empty = EPShared.LocalRM.GetString("PlantScientificNamePlantFamilyParameter");
        break;
      case PlantField.PlantCommonName:
        empty = EPShared.LocalRM.GetString("PlantCommonNamePlantFamilyParameter");
        break;
      case PlantField.PlantCodeName:
        empty = EPShared.LocalRM.GetString("PlantCodeNamePlantFamilyParameter");
        break;
      case PlantField.TemperatureRange:
        empty = EPShared.LocalRM.GetString("TemperatureRangePlantFamilyParameter");
        break;
      case PlantField.ConditionsSoilCondition:
        empty = EPShared.LocalRM.GetString("ConditionsSoilConditionPlantFamilyParameter");
        break;
      case PlantField.ConditionsExposure:
        empty = EPShared.LocalRM.GetString("ConditionsExposurePlantFamilyParameter");
        break;
      case PlantField.ConditionsMiscellaneous:
        empty = EPShared.LocalRM.GetString("ConditionsMiscellaneousPlantFamilyParameter");
        break;
      case PlantField.ConditionsTolerances:
        empty = EPShared.LocalRM.GetString("ConditionsTolerancesPlantFamilyParameter");
        break;
      case PlantField.PlantType:
        empty = EPShared.LocalRM.GetString("PlantTypePlantFamilyParameter");
        break;
      case PlantField.GrowthGrowthRate:
        empty = EPShared.LocalRM.GetString("GrowthGrowthRatePlantFamilyParameter");
        break;
      case PlantField.GrowthServiceLife:
        empty = EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter");
        break;
      case PlantField.PlantHeight:
        empty = EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter");
        break;
      case PlantField.PlantWidth:
        empty = EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter");
        break;
      case PlantField.GrowthPattern:
        empty = EPShared.LocalRM.GetString("GrowthPatternPlantFamilyParameter");
        break;
      case PlantField.GrowthForm:
        empty = EPShared.LocalRM.GetString("GrowthFormPlantFamilyParameter");
        break;
      case PlantField.MaintenanceWaterRequirements:
        empty = EPShared.LocalRM.GetString("MaintenanceWaterRequirementsPlantFamilyParameter");
        break;
      case PlantField.MaintenanceTransplant:
        empty = EPShared.LocalRM.GetString("MaintenanceTransplantPlantFamilyParameter");
        break;
      case PlantField.MaintenanceDetriments:
        empty = EPShared.LocalRM.GetString("MaintenanceDetrimentsPlantFamilyParameter");
        break;
      case PlantField.MaintenancePlantingTime:
        empty = EPShared.LocalRM.GetString("MaintenancePlantingTimePlantFamilyParameter");
        break;
      case PlantField.MaintenanceTransplantingTime:
        empty = EPShared.LocalRM.GetString("MaintenanceTransplantingTimePlantFamilyParameter");
        break;
      case PlantField.MaintenanceFertilizingTime:
        empty = EPShared.LocalRM.GetString("MaintenanceFertilizingTimePlantFamilyParameter");
        break;
      case PlantField.MaintenancePruningTime:
        empty = EPShared.LocalRM.GetString("MaintenancePruningTimePlantFamilyParameter");
        break;
      case PlantField.CharacteristicsAdmirationPoint:
        empty = EPShared.LocalRM.GetString("CharacteristicsAdmirationPointPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFoliageSize:
        empty = EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFoliageSurface:
        empty = EPShared.LocalRM.GetString("CharacteristicsFoliageSurfacePlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFoliageColor:
        empty = EPShared.LocalRM.GetString("CharacteristicsFoliageColorPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFallColor:
        empty = EPShared.LocalRM.GetString("CharacteristicsFallColorPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsCrownDensity:
        empty = EPShared.LocalRM.GetString("CharacteristicsCrownDensityPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsBarkSurface:
        empty = EPShared.LocalRM.GetString("CharacteristicsBarkSurfacePlantFamilyParameter");
        break;
      case PlantField.CharacteristicsBarkColor:
        empty = EPShared.LocalRM.GetString("CharacteristicsBarkColorPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFruitColor:
        empty = EPShared.LocalRM.GetString("CharacteristicsFruitColorPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsBloomEffect:
        empty = EPShared.LocalRM.GetString("CharacteristicsBloomEffectPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFragrance:
        empty = EPShared.LocalRM.GetString("CharacteristicsFragrancePlantFamilyParameter");
        break;
      case PlantField.CharacteristicsBloomPeriod:
        empty = EPShared.LocalRM.GetString("CharacteristicsBloomPeriodPlantFamilyParameter");
        break;
      case PlantField.CharacteristicsFruitPeriod:
        empty = EPShared.LocalRM.GetString("CharacteristicsFruitPeriodPlantFamilyParameter");
        break;
      case PlantField.PlantUses:
        empty = EPShared.LocalRM.GetString("PlantUsesPlantFamilyParameter");
        break;
      case PlantField.PlantClimateAndZone:
        empty = EPShared.LocalRM.GetString("PlantClimateAndZonePlantFamilyParameter");
        break;
      case PlantField.PlantingSize:
        empty = EPShared.LocalRM.GetString("PlantingSizePlantFamilyParameter");
        break;
      case PlantField.PlantSpacing:
        empty = EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter");
        break;
      case PlantField.PlantComments:
        empty = EPShared.LocalRM.GetString("PlantCommentsPlantFamilyParameter");
        break;
      case PlantField.Height:
        empty = EPShared.LocalRM.GetString("HeightPlantFamilyParameter");
        break;
      case PlantField.Keynote:
        empty = EPShared.LocalRM.GetString("KeynotePlantFamilyParameter");
        break;
      case PlantField.Model:
        empty = EPShared.LocalRM.GetString("ModelPlantFamilyParameter");
        break;
      case PlantField.Manufacturer:
        empty = EPShared.LocalRM.GetString("ManufacturerPlantFamilyParameter");
        break;
      case PlantField.TypeComments:
        empty = EPShared.LocalRM.GetString("TypeCommentsPlantFamilyParameter");
        break;
      case PlantField.URL:
        empty = EPShared.LocalRM.GetString("URLPlantFamilyParameter");
        break;
      case PlantField.Description:
        empty = EPShared.LocalRM.GetString("DescriptionPlantFamilyParameter");
        break;
      case PlantField.Cost:
        empty = EPShared.LocalRM.GetString("CostPlantFamilyParameter");
        break;
      case PlantField.TypeName:
        empty = EPShared.LocalRM.GetString("TypeNamePlantFamilyType");
        break;
      case PlantField.PlantingSymbol:
        empty = EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter");
        break;
      case PlantField.PlantCount:
        empty = EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter");
        break;
      case PlantField.GenericModelSymbol:
        empty = EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter");
        break;
      case PlantField.PlantPlacementID:
        empty = EPShared.LocalRM.GetString("PlacementIDFamilyParameter");
        break;
    }
    return empty;
  }

  public static List<string> PlantAllParamenterList()
  {
    List<string> stringList1 = ManagePlants.PlantSharedParamenterList();
    List<string> stringList2 = ManagePlants.PlantingCommonParamenterList();
    for (int index = 0; index < stringList2.Count; ++index)
      stringList1.Add(stringList2[index]);
    return stringList1;
  }

  private static List<string> PlantingCommonParamenterList()
  {
    List<BuiltInParameter> _BuiltInParameterList = new List<BuiltInParameter>();
    return ManagePlants.PlantingCommonParamenterList(ref _BuiltInParameterList);
  }

  private static List<string> PlantingCommonParamenterList(
    ref List<BuiltInParameter> _BuiltInParameterList)
  {
    List<string> stringList = new List<string>();
    stringList.Add(EPShared.LocalRM.GetString("HeightPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1005193);
    stringList.Add(EPShared.LocalRM.GetString("KeynotePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1140422);
    stringList.Add(EPShared.LocalRM.GetString("ModelPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1010109);
    stringList.Add(EPShared.LocalRM.GetString("ManufacturerPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1010108);
    stringList.Add(EPShared.LocalRM.GetString("TypeCommentsPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1010105);
    stringList.Add(EPShared.LocalRM.GetString("URLPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1010104);
    stringList.Add(EPShared.LocalRM.GetString("DescriptionPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1010103);
    stringList.Add(EPShared.LocalRM.GetString("CostPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1001205);
    stringList.Add(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    return stringList;
  }

  public static void GenericModelParamenterList(
    ref List<FamilyParameterTypeWrapper> _ReturnParameterList)
  {
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), RevitParameters.KeynoteGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1140422));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), RevitParameters.ModelGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010109));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), RevitParameters.ManufacturerGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010108));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), RevitParameters.TypeCommentsGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010105));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), RevitParameters.URLGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010104));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), RevitParameters.DescriptionGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1010103));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), RevitParameters.CostGenericFamilyParameter, (ParameterType) 1, (BuiltInParameter) -1001205));
  }

  private static void GenericModelUndefinedParamenterList(
    ref List<FamilyParameterTypeWrapper> _ReturnParameterList)
  {
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, (ParameterType) 1));
  }

  public static List<FamilyParameterTypeWrapper> PlantMixParamenterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), RevitParameters.ScientificNamePlantMixFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), RevitParameters.CommonNamePlantMixFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CodeNamePlantMixFamilyParameter"), RevitParameters.CodeNamePlantMixFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("CodeNamePlantMixFamilyParameter"), RevitParameters.CodeNamePlantMixFamilyParameter, (ParameterType) 1));
    ManagePlants.GenericModelUndefinedParamenterList(ref _ReturnParameterList);
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("PlantSizePlantMixFamilyParameter"), RevitParameters.PlantSizePlantMixFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), RevitParameters.SpacingMethodPlantMixFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), RevitParameters.PlantSpacingPlantMixFamilyParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), RevitParameters.PercentagePlantMixFamilyParameter, (ParameterType) 3));
    ManagePlants.GenericModelParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<FamilyParameterTypeWrapper> PatioWalkParamenterList()
  {
    List<FamilyParameterTypeWrapper> _ReturnParameterList = new List<FamilyParameterTypeWrapper>();
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), RevitParameters.MaterialPathWalkFamilyParameter, (ParameterType) 1));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), RevitParameters.MaterialPathWalkFamilyParameter, (ParameterType) 1));
    ManagePlants.GenericModelUndefinedParamenterList(ref _ReturnParameterList);
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), RevitParameters.ThicknessPathWalkFamilyParameter, (ParameterType) 4));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), RevitParameters.EdgePathWalkFamilyParameter, (ParameterType) 10));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), RevitParameters.MowingStripPathWalkFamilyParameter, (ParameterType) 10));
    _ReturnParameterList.Add(new FamilyParameterTypeWrapper(EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), RevitParameters.EdgeWidthPathWalkFamilyParameter, (ParameterType) 4));
    ManagePlants.GenericModelParamenterList(ref _ReturnParameterList);
    return _ReturnParameterList;
  }

  public static List<string> PlantSharedParamenterList()
  {
    List<BuiltInParameter> _BuiltInParameterList = new List<BuiltInParameter>();
    return ManagePlants.PlantSharedParamenterList(ref _BuiltInParameterList);
  }

  public static List<string> PlantSharedParamenterList(
    ref List<BuiltInParameter> _BuiltInParameterList)
  {
    List<string> stringList = new List<string>();
    stringList.Add(EPShared.LocalRM.GetString("PlantScientificNamePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantCommonNamePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantCodeNamePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsAdmirationPointPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("TemperatureRangePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("ConditionsSoilConditionPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("ConditionsExposurePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("ConditionsMiscellaneousPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("ConditionsTolerancesPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantTypePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("GrowthGrowthRatePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("GrowthPatternPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("GrowthFormPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenanceWaterRequirementsPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenanceTransplantPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenanceDetrimentsPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenancePlantingTimePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenanceTransplantingTimePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenanceFertilizingTimePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("MaintenancePruningTimePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFoliageSurfacePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFoliageColorPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFallColorPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsCrownDensityPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsBarkSurfacePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsBarkColorPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFruitColorPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsBloomEffectPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFragrancePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsBloomPeriodPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("CharacteristicsFruitPeriodPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantUsesPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantClimateAndZonePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantingSizePlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantCommentsPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    stringList.Add(EPShared.LocalRM.GetString("PlacementIDFamilyParameter"));
    _BuiltInParameterList.Add((BuiltInParameter) -1);
    return stringList;
  }

  public static PlantFieldsComparisionType FindPlantComparisonType(string _strValue)
  {
    PlantFieldsComparisionType plantComparisonType = PlantFieldsComparisionType.Equal;
    if (string.Compare(_strValue, EPShared.LocalRM.GetString("LessThanComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.LessThan;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("LessThanOrEqualToComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.LessThanOrEqualTo;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GreaterThanComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.GreaterThan;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("GreaterThanOrEqualToComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.GreaterThanOrEqualTo;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("NotEqualComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.NotEqual;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("StartsWithComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.StartsWith;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("EndsWithComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.EndsWith;
    else if (string.Compare(_strValue, EPShared.LocalRM.GetString("ContainsComparator"), true) == 0)
      plantComparisonType = PlantFieldsComparisionType.Contains;
    return plantComparisonType;
  }

  public static List<string> ComparisonList()
  {
    return new List<string>()
    {
      EPShared.LocalRM.GetString("ContainsComparator"),
      EPShared.LocalRM.GetString("EqualComparator"),
      EPShared.LocalRM.GetString("LessThanComparator"),
      EPShared.LocalRM.GetString("LessThanOrEqualToComparator"),
      EPShared.LocalRM.GetString("GreaterThanComparator"),
      EPShared.LocalRM.GetString("GreaterThanOrEqualToComparator"),
      EPShared.LocalRM.GetString("NotEqualComparator"),
      EPShared.LocalRM.GetString("StartsWithComparator"),
      EPShared.LocalRM.GetString("EndsWithComparator")
    };
  }

  private static void ReturnFieldValue(
    string _strCurPlantField,
    List<KeyValuePair<string, SearchPlantParameter>> _SearchParameterResults,
    ref List<SearchPlantParameter> _ReturnComparisionList)
  {
    for (int index = 0; index < _SearchParameterResults.Count; ++index)
    {
      KeyValuePair<string, SearchPlantParameter> searchParameterResult = _SearchParameterResults[index];
      if (string.Compare(searchParameterResult.Key, _strCurPlantField, true) == 0)
        _ReturnComparisionList.Add(searchParameterResult.Value);
    }
  }

  public static bool FindFamilySymbols(
    string _strSearchFormName,
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    List<FamilySymbol> _SymbolList,
    ref List<FamilySymbol> _SearchSymbolList)
  {
    if (_SymbolList.Count == 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantTypePickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    using (PlantSearchForm plantSearchForm = new PlantSearchForm(_strSearchFormName, _Document))
    {
      int num1 = (int) plantSearchForm.ShowDialog();
      if (DialogResult.OK != plantSearchForm.DialogResult)
        return false;
      List<Element> list = new FilteredElementCollector(_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements().ToList<Element>();
      _TransactionContainer.Start(EPShared.LocalRM.GetString("FindFamilySymbolsTransaction"));
      bool flag1 = false;
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      Eps_Point _SecondCheckPnt = new Eps_Point();
      List<KeyValuePair<string, SearchPlantParameter>> parameterResults = plantSearchForm.SearchParameterResults;
      List<SearchPlantParameter> _ReturnComparisionList = new List<SearchPlantParameter>();
      List<string> stringList = ManagePlants.PlantAllParamenterList();
      _SearchSymbolList.Clear();
      int count = _SymbolList.Count;
      for (int index1 = 0; index1 < _SymbolList.Count; ++index1)
      {
        List<Eps_Point> _PointList = (List<Eps_Point>) null;
        foreach (Element element in list)
        {
          if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) _SymbolList[index1]).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
          {
            if (_PointList == null)
              _PointList = new List<Eps_Point>();
            Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
            if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
              _PointList.Add(_FindPoint);
          }
        }
        if (_PointList != null && _PointList.Count > 0)
        {
          bool flag2 = true;
          while (flag2)
          {
            flag2 = false;
            for (int index2 = 0; index2 < _PointList.Count; ++index2)
            {
              if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index2], _SecondCheckPnt))
              {
                ++_SecondCheckPnt.z;
                flag2 = true;
                break;
              }
            }
          }
        }
        FamilyInstance familyInstance1 = RevitUtility.NewFamilyInstance(_Document, _SecondCheckPnt.XYZ, _SymbolList[index1], (Element) null, (Level) null, (StructuralType) 0, ref _TransactionContainer);
        ElementSet elm_set = new ElementSet();
        elm_set.Insert((Element) familyInstance1);
        _Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
        if (familyInstance1 != null && familyInstance1.Symbol != null)
        {
          for (int index3 = 0; index3 < stringList.Count; ++index3)
          {
            _ReturnComparisionList.Clear();
            ManagePlants.ReturnFieldValue(stringList[index3], parameterResults, ref _ReturnComparisionList);
            flag1 = true;
            Parameter parameter1 = ((Element) familyInstance1.Symbol).LookupParameter(stringList[index3]) ?? ((Element) familyInstance1).LookupParameter(stringList[index3]);
            if (parameter1 == null)
            {
              if (_ReturnComparisionList.Count > 0)
                flag1 = false;
            }
            else
            {
              switch (parameter1.StorageType - 1)
              {
                case 0:
                  int num2 = parameter1.AsInteger();
                  using (List<SearchPlantParameter>.Enumerator enumerator = _ReturnComparisionList.GetEnumerator())
                  {
                    while (enumerator.MoveNext())
                    {
                      SearchPlantParameter current = enumerator.Current;
                      if (current.Parameter != string.Empty)
                      {
                        int int32 = Convert.ToInt32(current.Parameter);
                        switch (current.ComparisionType)
                        {
                          case PlantFieldsComparisionType.Equal:
                            if (num2 != int32)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.LessThan:
                            if (num2 >= int32)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.LessThanOrEqualTo:
                            if (num2 > int32)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.GreaterThan:
                            if (num2 <= int32)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.GreaterThanOrEqualTo:
                            if (num2 < int32)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.NotEqual:
                            if (num2 == int32)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.StartsWith:
                            if (!Convert.ToString(num2).StartsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.EndsWith:
                            if (!Convert.ToString(num2).EndsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.Contains:
                            if (!Convert.ToString(num2).Contains(current.Parameter))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                        }
                        if (!flag1)
                          break;
                      }
                    }
                    break;
                  }
                case 1:
                  double num3 = parameter1.AsDouble();
                  using (List<SearchPlantParameter>.Enumerator enumerator = _ReturnComparisionList.GetEnumerator())
                  {
                    while (enumerator.MoveNext())
                    {
                      SearchPlantParameter current = enumerator.Current;
                      if (current.Parameter != string.Empty)
                      {
                        double num4 = ValueConversion.ToDouble(current.Parameter);
                        switch (current.ComparisionType)
                        {
                          case PlantFieldsComparisionType.Equal:
                            if (num3 != num4)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.LessThan:
                            if (num3 >= num4)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.LessThanOrEqualTo:
                            if (num3 > num4)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.GreaterThan:
                            if (num3 <= num4)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.GreaterThanOrEqualTo:
                            if (num3 < num4)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.NotEqual:
                            if (num3 == num4)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.StartsWith:
                            if (!Convert.ToString(num3).StartsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.EndsWith:
                            if (!Convert.ToString(num3).EndsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.Contains:
                            if (!Convert.ToString(num3).Contains(current.Parameter))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                        }
                        if (!flag1)
                          break;
                      }
                    }
                    break;
                  }
                case 2:
                  string strB = parameter1.AsString();
                  using (List<SearchPlantParameter>.Enumerator enumerator = _ReturnComparisionList.GetEnumerator())
                  {
                    while (enumerator.MoveNext())
                    {
                      SearchPlantParameter current = enumerator.Current;
                      if (current.Parameter != string.Empty)
                      {
                        string parameter2 = current.Parameter;
                        switch (current.ComparisionType)
                        {
                          case PlantFieldsComparisionType.Equal:
                            if (string.Compare(parameter2, strB, true) != 0)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.LessThan:
                            if (string.Compare(parameter2, strB, true) != 1)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.LessThanOrEqualTo:
                            if (string.Compare(parameter2, strB, true) == -1)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.GreaterThan:
                            if (string.Compare(parameter2, strB, true) != -1)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.GreaterThanOrEqualTo:
                            if (string.Compare(parameter2, strB, true) == 1)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.NotEqual:
                            if (string.Compare(parameter2, strB, true) == 0)
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.StartsWith:
                            if (!strB.StartsWith(parameter2, StringComparison.CurrentCultureIgnoreCase))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.EndsWith:
                            if (!strB.EndsWith(parameter2, StringComparison.CurrentCultureIgnoreCase))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                          case PlantFieldsComparisionType.Contains:
                            if (!strB.ToLower().Contains(parameter2.ToLower()))
                            {
                              flag1 = false;
                              break;
                            }
                            break;
                        }
                        if (!flag1)
                          break;
                      }
                    }
                    break;
                  }
              }
            }
            if (!flag1)
            {
              if (count > 1)
              {
                --count;
                break;
              }
              int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsMatchingCriteriaMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
          }
          if (flag1)
            _SearchSymbolList.Add(_SymbolList[index1]);
          _TransactionContainer.BeginTransaction();
          _Document.Delete(((Element) familyInstance1).Id);
          _TransactionContainer.EndTransaction();
        }
      }
      _TransactionContainer.Rollback();
      return true;
    }
  }

  public static bool FindFamilyTypes(
    string _strSearchFormName,
    Document _Document,
    ref List<FamilyTypeContainer> _SearchFamilyTypeList)
  {
    using (PlantSearchForm plantSearchForm = new PlantSearchForm(_strSearchFormName, _Document))
    {
      int num = (int) plantSearchForm.ShowDialog();
      return DialogResult.OK == plantSearchForm.DialogResult && ManagePlants.SearchFamilyList(plantSearchForm.SearchParameterResults, ref _SearchFamilyTypeList);
    }
  }

  private static bool SearchFamilyList(
    List<KeyValuePair<string, SearchPlantParameter>> _SearchParameterResults,
    ref List<FamilyTypeContainer> _SearchFamilyTypeList)
  {
    double _dValue = 0.0;
    int _nValue = 0;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    if (_SearchFamilyTypeList.Count == 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsFoundMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
    foreach (FamilyTypeContainer familyTypeContainer1 in _SearchFamilyTypeList)
    {
      FamilyTypeContainer familyTypeContainer2 = new FamilyTypeContainer(familyTypeContainer1.FamilyTypeWrapper, familyTypeContainer1.FamilyParameterList);
      if (familyTypeContainer1.Status == FamilyParameterWrapperStatus.Selected)
        familyTypeContainer2.Status = FamilyParameterWrapperStatus.Selected;
      familyTypeContainerList.Add(familyTypeContainer2);
    }
    int count = familyTypeContainerList.Count;
    List<SearchPlantParameter> _ReturnComparisionList = new List<SearchPlantParameter>();
    for (int index1 = 0; index1 < familyTypeContainerList.Count; ++index1)
    {
      FamilyTypeContainer familyTypeContainer = familyTypeContainerList[index1];
      if (familyTypeContainer.Status == FamilyParameterWrapperStatus.Included)
      {
        for (int index2 = 0; index2 < familyTypeContainer.FamilyParameterList.Count; ++index2)
        {
          FamilyParameterWrapper familyParameter = familyTypeContainer.FamilyParameterList[index2];
          if (familyParameter != null && ManagePlants.GetPlantFieldFromParamenter(familyParameter.ParameterName) != PlantField.None)
          {
            _ReturnComparisionList.Clear();
            ManagePlants.ReturnFieldValue(familyParameter.ParameterName, _SearchParameterResults, ref _ReturnComparisionList);
            bool flag = true;
            if (!familyTypeContainer.HasValue(index2))
            {
              if (_ReturnComparisionList.Count > 0)
                flag = false;
            }
            else
            {
              switch (familyParameter.StorageType - 1)
              {
                case 0:
                  if (familyTypeContainer.GetIntegerValue(index2, ref _nValue))
                  {
                    using (List<SearchPlantParameter>.Enumerator enumerator = _ReturnComparisionList.GetEnumerator())
                    {
                      while (enumerator.MoveNext())
                      {
                        SearchPlantParameter current = enumerator.Current;
                        if (current.Parameter != string.Empty)
                        {
                          int int32 = Convert.ToInt32(current.Parameter);
                          switch (current.ComparisionType)
                          {
                            case PlantFieldsComparisionType.Equal:
                              if (_nValue != int32)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.LessThan:
                              if (_nValue >= int32)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.LessThanOrEqualTo:
                              if (_nValue > int32)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.GreaterThan:
                              if (_nValue <= int32)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.GreaterThanOrEqualTo:
                              if (_nValue < int32)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.NotEqual:
                              if (_nValue == int32)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.StartsWith:
                              if (!Convert.ToString(_nValue).StartsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.EndsWith:
                              if (!Convert.ToString(_nValue).EndsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.Contains:
                              if (!Convert.ToString(_nValue).Contains(current.Parameter))
                              {
                                flag = false;
                                break;
                              }
                              break;
                          }
                          if (!flag)
                            break;
                        }
                      }
                      break;
                    }
                  }
                  break;
                case 1:
                  if (familyTypeContainer.GetDoubleValue(index2, ref _dValue))
                  {
                    using (List<SearchPlantParameter>.Enumerator enumerator = _ReturnComparisionList.GetEnumerator())
                    {
                      while (enumerator.MoveNext())
                      {
                        SearchPlantParameter current = enumerator.Current;
                        if (current.Parameter != string.Empty)
                        {
                          double num = ValueConversion.ToDouble(current.Parameter);
                          switch (current.ComparisionType)
                          {
                            case PlantFieldsComparisionType.Equal:
                              if (_dValue != num)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.LessThan:
                              if (_dValue >= num)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.LessThanOrEqualTo:
                              if (_dValue > num)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.GreaterThan:
                              if (_dValue <= num)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.GreaterThanOrEqualTo:
                              if (_dValue < num)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.NotEqual:
                              if (_dValue == num)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.StartsWith:
                              if (!Convert.ToString(_dValue).StartsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.EndsWith:
                              if (!Convert.ToString(_dValue).EndsWith(current.Parameter, StringComparison.CurrentCultureIgnoreCase))
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.Contains:
                              if (!Convert.ToString(_dValue).Contains(current.Parameter))
                              {
                                flag = false;
                                break;
                              }
                              break;
                          }
                          if (!flag)
                            break;
                        }
                      }
                      break;
                    }
                  }
                  break;
                case 2:
                  if (familyTypeContainer.GetStringValue(index2, ref empty2))
                  {
                    using (List<SearchPlantParameter>.Enumerator enumerator = _ReturnComparisionList.GetEnumerator())
                    {
                      while (enumerator.MoveNext())
                      {
                        SearchPlantParameter current = enumerator.Current;
                        if (current.Parameter != string.Empty)
                        {
                          string parameter = current.Parameter;
                          switch (current.ComparisionType)
                          {
                            case PlantFieldsComparisionType.Equal:
                              if (string.Compare(parameter, empty2, true) != 0)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.LessThan:
                              if (string.Compare(parameter, empty2, true) != 1)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.LessThanOrEqualTo:
                              if (string.Compare(parameter, empty2, true) == -1)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.GreaterThan:
                              if (string.Compare(parameter, empty2, true) != -1)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.GreaterThanOrEqualTo:
                              if (string.Compare(parameter, empty2, true) == 1)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.NotEqual:
                              if (string.Compare(parameter, empty2, true) == 0)
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.StartsWith:
                              if (!empty2.StartsWith(parameter, StringComparison.CurrentCultureIgnoreCase))
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.EndsWith:
                              if (!empty2.EndsWith(parameter, StringComparison.CurrentCultureIgnoreCase))
                              {
                                flag = false;
                                break;
                              }
                              break;
                            case PlantFieldsComparisionType.Contains:
                              if (!empty2.ToLower().Contains(parameter.ToLower()))
                              {
                                flag = false;
                                break;
                              }
                              break;
                          }
                          if (!flag)
                            break;
                        }
                      }
                      break;
                    }
                  }
                  break;
              }
            }
            if (!flag)
            {
              if (count > 1)
              {
                familyTypeContainer.Status = FamilyParameterWrapperStatus.Excluded;
                --count;
                break;
              }
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsMatchingCriteriaMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
          }
        }
      }
    }
    _SearchFamilyTypeList.Clear();
    foreach (FamilyTypeContainer familyTypeContainer in familyTypeContainerList)
      _SearchFamilyTypeList.Add(familyTypeContainer);
    return true;
  }

  public static bool FindTemplateFileName(
    Document _Document,
    ref string _strTemplateFileName,
    bool _bIssueWarning)
  {
    bool templateFileName = false;
    string empty1 = string.Empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(empty1, ref _strTemplateFileName) || !File.Exists(_strTemplateFileName))
    {
      if (_Document != null)
      {
        string searchPattern = string.Empty;
        string empty2 = string.Empty;
        IDictionary<string, string> libraryPaths = _Document.Application.GetLibraryPaths();
        if (libraryPaths != null && libraryPaths.Count > 0)
        {
          foreach (string path in (IEnumerable<string>) libraryPaths.Values)
          {
            DirectoryInfo directoryInfo1 = new DirectoryInfo(path);
            DirectoryInfo directoryInfo2 = (DirectoryInfo) null;
            if (directoryInfo1.Parent != null)
              directoryInfo2 = directoryInfo1.Parent.Parent;
            if (directoryInfo2 != null)
            {
              if (_Document.DisplayUnitSystem == 1)
              {
                if (searchPattern == string.Empty)
                  searchPattern = ApplicationUtility.GetString("PlantingImperialTemplate") + ".rft";
                if (empty2 == string.Empty)
                  empty2 = ApplicationUtility.GetString("ENU-ImperialTemplateFolderName");
              }
              else if (_Document.DisplayUnitSystem == null)
              {
                if (searchPattern == string.Empty)
                  searchPattern = ApplicationUtility.GetString("PlantingMetricTemplate") + ".rft";
                if (empty2 == string.Empty)
                  empty2 = ApplicationUtility.GetString("ENU-MetricTemplateFolderName");
              }
              if (directoryInfo2.Exists)
              {
                try
                {
                  foreach (DirectoryInfo directory in directoryInfo2.GetDirectories(empty2, SearchOption.AllDirectories))
                  {
                    foreach (FileInfo file in directory.GetFiles(searchPattern, SearchOption.AllDirectories))
                    {
                      if (file.Exists)
                      {
                        _strTemplateFileName = file.FullName;
                        templateFileName = true;
                        break;
                      }
                    }
                    if (templateFileName)
                      break;
                  }
                }
                catch (UnauthorizedAccessException ex)
                {
                  continue;
                }
                catch (DirectoryNotFoundException ex)
                {
                  continue;
                }
              }
            }
            if (templateFileName)
              break;
          }
        }
      }
      if (!templateFileName)
      {
        string empty3 = string.Empty;
        string empty4 = string.Empty;
        if (!File.Exists(ApplicationUtility.RevitIniFilename))
        {
          if (_bIssueWarning)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RevitINIFileMissingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
          }
          return false;
        }
        StreamReader streamReader = new StreamReader((Stream) new FileStream(ApplicationUtility.RevitIniFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
        string strA;
        while ((strA = streamReader.ReadLine()) != null)
        {
          if (strA.Contains(ApplicationUtility.GetString("FamilyTemplatePath")))
          {
            string str = string.Empty;
            int num = strA.IndexOf('=');
            if (num >= 0 && num < strA.Length - 1)
            {
              str = strA.Substring(num + 1);
              if (!str.EndsWith("\\"))
                str += "\\";
            }
            _strTemplateFileName = !strA.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str + ApplicationUtility.GetString("PlantingMetricTemplate") : str + ApplicationUtility.GetString("PlantingImperialTemplate");
            _strTemplateFileName += ".rft";
            if (File.Exists(_strTemplateFileName))
            {
              templateFileName = true;
              break;
            }
            _strTemplateFileName = string.Empty;
          }
          else if (string.Compare(strA, ApplicationUtility.GetString("ContentInstalledName"), true) == 0)
          {
            string str1;
            while ((str1 = streamReader.ReadLine()) != null)
            {
              if (str1.Contains(ApplicationUtility.GetString("ImperialTemplateCabName")) || str1.Contains(ApplicationUtility.GetString("MetricTemplateCabName")))
              {
                string str2 = string.Empty;
                int num = str1.IndexOf('=');
                if (num >= 0 && num < str1.Length - 1)
                {
                  str2 = str1.Substring(num + 1);
                  if (!str2.EndsWith("\\"))
                    str2 += "\\";
                }
                _strTemplateFileName = !str1.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str2 + ApplicationUtility.GetString("PlantingMetricTemplate") : str2 + ApplicationUtility.GetString("PlantingImperialTemplate");
                _strTemplateFileName += ".rft";
                if (File.Exists(_strTemplateFileName))
                {
                  templateFileName = true;
                  break;
                }
                _strTemplateFileName = string.Empty;
              }
            }
            break;
          }
        }
        streamReader.Close();
      }
      if (!templateFileName)
      {
        if (!_bIssueWarning)
          return false;
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantingRFTMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
          openFileDialog.Title = EPShared.LocalRM.GetString("TemplateNotLoadedErrorMessage");
          openFileDialog.RestoreDirectory = true;
          openFileDialog.Filter = ApplicationUtility.GetString("TemplateFilePickerFilter");
          if (openFileDialog.ShowDialog() != DialogResult.Cancel)
          {
            _strTemplateFileName = openFileDialog.FileName;
            templateFileName = true;
          }
          else
          {
            int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("TemplateNotPickedFamilyNotCreatedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return false;
          }
        }
      }
      ApplicationUtility.Settings.eplSetE_SetSetting(empty1, _strTemplateFileName);
    }
    else
      templateFileName = true;
    return templateFileName;
  }

  public static bool FindMixTemplateFileName(
    Document _Document,
    ref string _strTemplateFileName,
    bool _bIssueWarning)
  {
    bool templateFileName = false;
    string _strSettingsName = "GenericTemplateFileName";
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName, ref _strTemplateFileName) || !File.Exists(_strTemplateFileName))
    {
      if (_Document != null)
      {
        string searchPattern = string.Empty;
        string empty = string.Empty;
        IDictionary<string, string> libraryPaths = _Document.Application.GetLibraryPaths();
        if (libraryPaths != null && libraryPaths.Count > 0)
        {
          foreach (string path in (IEnumerable<string>) libraryPaths.Values)
          {
            DirectoryInfo directoryInfo1 = new DirectoryInfo(path);
            DirectoryInfo directoryInfo2 = (DirectoryInfo) null;
            if (directoryInfo1.Parent != null)
              directoryInfo2 = directoryInfo1.Parent.Parent;
            if (directoryInfo2 != null)
            {
              if (_Document.DisplayUnitSystem == 1)
              {
                if (searchPattern == string.Empty)
                  searchPattern = ApplicationUtility.GetString("GenericImperialTemplate") + ".rft";
                if (empty == string.Empty)
                  empty = ApplicationUtility.GetString("ENU-ImperialTemplateFolderName");
              }
              else if (_Document.DisplayUnitSystem == null)
              {
                if (searchPattern == string.Empty)
                  searchPattern = ApplicationUtility.GetString("GenericMetricTemplate") + ".rft";
                if (empty == string.Empty)
                  empty = ApplicationUtility.GetString("ENU-MetricTemplateFolderName");
              }
              if (directoryInfo2.Exists)
              {
                try
                {
                  foreach (DirectoryInfo directory in directoryInfo2.GetDirectories(empty, SearchOption.AllDirectories))
                  {
                    foreach (FileInfo file in directory.GetFiles(searchPattern, SearchOption.AllDirectories))
                    {
                      if (file.Exists)
                      {
                        _strTemplateFileName = file.FullName;
                        templateFileName = true;
                        break;
                      }
                    }
                    if (templateFileName)
                      break;
                  }
                }
                catch (UnauthorizedAccessException ex)
                {
                  continue;
                }
                catch (DirectoryNotFoundException ex)
                {
                  continue;
                }
              }
            }
            if (templateFileName)
              break;
          }
        }
      }
      if (!templateFileName)
      {
        string empty1 = string.Empty;
        string empty2 = string.Empty;
        if (!File.Exists(ApplicationUtility.RevitIniFilename))
        {
          if (_bIssueWarning)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RevitINIFileMissingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
          }
          return false;
        }
        StreamReader streamReader = new StreamReader((Stream) new FileStream(ApplicationUtility.RevitIniFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
        string strA;
        while ((strA = streamReader.ReadLine()) != null)
        {
          if (strA.Contains(ApplicationUtility.GetString("FamilyTemplatePath")))
          {
            string str = string.Empty;
            int num = strA.IndexOf('=');
            if (num >= 0 && num < strA.Length - 1)
            {
              str = strA.Substring(num + 1);
              if (!str.EndsWith("\\"))
                str += "\\";
            }
            _strTemplateFileName = !strA.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str + ApplicationUtility.GetString("GenericMetricTemplate") : str + ApplicationUtility.GetString("GenericImperialTemplate");
            _strTemplateFileName += ".rft";
            if (File.Exists(_strTemplateFileName))
            {
              templateFileName = true;
              break;
            }
            _strTemplateFileName = string.Empty;
          }
          else if (string.Compare(strA, ApplicationUtility.GetString("ContentInstalledName"), true) == 0)
          {
            string str1;
            while ((str1 = streamReader.ReadLine()) != null)
            {
              if (str1.Contains(ApplicationUtility.GetString("ImperialTemplateCabName")) || str1.Contains(ApplicationUtility.GetString("MetricTemplateCabName")))
              {
                string str2 = string.Empty;
                int num = str1.IndexOf('=');
                if (num >= 0 && num < str1.Length - 1)
                {
                  str2 = str1.Substring(num + 1);
                  if (!str2.EndsWith("\\"))
                    str2 += "\\";
                }
                _strTemplateFileName = !str1.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str2 + ApplicationUtility.GetString("PlantingMetricTemplate") : str2 + ApplicationUtility.GetString("PlantingImperialTemplate");
                _strTemplateFileName += ".rft";
                if (File.Exists(_strTemplateFileName))
                {
                  templateFileName = true;
                  break;
                }
                _strTemplateFileName = string.Empty;
              }
            }
            break;
          }
        }
        streamReader.Close();
      }
      if (!templateFileName)
      {
        if (!_bIssueWarning)
          return false;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoGenericModelRFTMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
          openFileDialog.Title = EPShared.LocalRM.GetString("TemplateNotLoadedErrorMessage");
          openFileDialog.RestoreDirectory = true;
          openFileDialog.Filter = ApplicationUtility.GetString("TemplateFilePickerFilter");
          if (openFileDialog.ShowDialog() == DialogResult.Cancel)
            return false;
          _strTemplateFileName = openFileDialog.FileName;
          templateFileName = true;
        }
      }
      ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName, _strTemplateFileName);
    }
    else
      templateFileName = true;
    return templateFileName;
  }

  public static bool IsTypeNameDuplicate(List<string> _CurStringList, string _strQueryTypeName)
  {
    foreach (string curString in _CurStringList)
    {
      if (string.Compare(curString, _strQueryTypeName, true) == 0)
        return true;
    }
    return false;
  }

  public static string GetUniqueTypeName(List<string> _CurStringList, string _strQueryTypeName)
  {
    foreach (string curString in _CurStringList)
    {
      if (string.Compare(curString, _strQueryTypeName, true) == 0)
      {
        string str1 = string.Empty;
        string empty = string.Empty;
        int length = _strQueryTypeName.LastIndexOf(" ");
        if (length > 0 && length < _strQueryTypeName.Length - 1)
        {
          str1 = _strQueryTypeName.Substring(0, length);
          int index = length + 1;
          while (length < _strQueryTypeName.Length)
          {
            if (char.IsDigit(_strQueryTypeName[index]))
            {
              empty += _strQueryTypeName[index].ToString();
              ++index;
            }
            else
            {
              empty = string.Empty;
              break;
            }
          }
        }
        string str2;
        if (empty == string.Empty)
        {
          str1 = _strQueryTypeName;
          str2 = "1";
        }
        else
          str2 = Convert.ToString(Convert.ToInt32(empty) + 1);
        return ManagePlants.GetUniqueTypeName(_CurStringList, $"{str1} {str2}");
      }
    }
    return _strQueryTypeName;
  }

  private static bool IsTypeNameDuplicate(FamilyTypeSet _CurFamilyTypeSet, string _strQueryTypeName)
  {
    foreach (FamilyType curFamilyType in _CurFamilyTypeSet)
    {
      if (string.Compare(curFamilyType.Name, _strQueryTypeName, true) == 0)
        return true;
    }
    return false;
  }

  private static void DeleteDuplicateTypeName(
    FamilyManager _CurFamilyManager,
    string _strQueryTypeName)
  {
    foreach (FamilyType type in _CurFamilyManager.Types)
    {
      if (string.Compare(type.Name, _strQueryTypeName, true) == 0)
      {
        _CurFamilyManager.CurrentType = type;
        _CurFamilyManager.DeleteCurrentType();
        break;
      }
    }
  }

  private static string GetUniqueTypeName(FamilyTypeSet _CurFamilyTypeSet, string _strQueryTypeName)
  {
    foreach (FamilyType curFamilyType in _CurFamilyTypeSet)
    {
      if (string.Compare(curFamilyType.Name, _strQueryTypeName, true) == 0)
      {
        string str1 = string.Empty;
        string empty = string.Empty;
        int length = _strQueryTypeName.LastIndexOf(" ");
        if (length > 0 && length < _strQueryTypeName.Length - 1)
        {
          str1 = _strQueryTypeName.Substring(0, length);
          int index = length + 1;
          while (length < _strQueryTypeName.Length)
          {
            if (char.IsDigit(_strQueryTypeName[index]))
            {
              empty += _strQueryTypeName[index].ToString();
              ++index;
            }
            else
            {
              empty = string.Empty;
              break;
            }
          }
        }
        string str2;
        if (empty == string.Empty)
        {
          str1 = _strQueryTypeName;
          str2 = "1";
        }
        else
          str2 = Convert.ToString(Convert.ToInt32(empty) + 1);
        return ManagePlants.GetUniqueTypeName(_CurFamilyTypeSet, $"{str1} {str2}");
      }
    }
    return _strQueryTypeName;
  }

  public static bool CreateNewMixFamilyDocument(
    Document _ActiveDocument,
    List<FamilyTypeContainer> _PlantListFamilyTypeList,
    DialogType _Type,
    string _strNewFilename)
  {
    double _dValue = 0.0;
    string _strValue = string.Empty;
    int _nValue = 0;
    ElementId elementId = (ElementId) null;
    bool _bIsActiveDocument = false;
    bool _bIsDocumentOpen = false;
    Document _CurDocument = _ActiveDocument;
    EPTransactionContainer _TransactionContainer = (EPTransactionContainer) null;
    List<FamilyParameter> _NewFamilyParameterList = new List<FamilyParameter>();
    if (!ManagePlants.SetupMixFamilyDocument(_ActiveDocument, _strNewFilename, _Type, ref _bIsActiveDocument, ref _bIsDocumentOpen, ref _CurDocument, ref _TransactionContainer, ref _NewFamilyParameterList))
      return false;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    string empty = string.Empty;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _PlantListFamilyTypeList.Count;
    if (_PlantListFamilyTypeList.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarCreatingFamilyMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    for (int index1 = 0; index1 < _PlantListFamilyTypeList.Count; ++index1)
    {
      if (_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName != string.Empty)
      {
        if (flag2)
        {
          FamilyType familyType = _CurDocument.FamilyManager.NewType(ManagePlants.GetUniqueTypeName(_CurDocument.FamilyManager.Types, _PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName));
          progressBarForm.Message = $"{EPShared.LocalRM.GetString("CreatingFamilyTypeMessage")} {familyType.Name}";
        }
        else if (ManagePlants.IsTypeNameDuplicate(_CurDocument.FamilyManager.Types, _PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName))
        {
          if (!flag3)
          {
            flag3 = true;
            if (RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateTypeAppendMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
              flag2 = true;
              FamilyType familyType = _CurDocument.FamilyManager.NewType(ManagePlants.GetUniqueTypeName(_CurDocument.FamilyManager.Types, _PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName));
              progressBarForm.Message = $"{EPShared.LocalRM.GetString("CreatingFamilyTypeMessage")} {familyType.Name}";
            }
          }
          else
            continue;
        }
        else
        {
          FamilyType familyType = _CurDocument.FamilyManager.NewType(_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
          progressBarForm.Message = $"{EPShared.LocalRM.GetString("CreatingFamilyTypeMessage")} {familyType.Name}";
        }
        progressBarForm.ResetValue();
        progressBarForm.MinValue = 0;
        progressBarForm.MaxValue = _NewFamilyParameterList.Count * 2;
label_41:
        for (int index2 = 0; index2 < _NewFamilyParameterList.Count; ++index2)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter1 = _NewFamilyParameterList[index2];
          if (familyParameter1 != null)
          {
            for (int index3 = 0; index3 < _PlantListFamilyTypeList[index1].FamilyParameterList.Count; ++index3)
            {
              FamilyParameterWrapper familyParameter2 = _PlantListFamilyTypeList[index1].FamilyParameterList[index3];
              if (familyParameter2 != null && (familyParameter2.FamilyParameter != null && familyParameter2.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter2.FamilyParameter.Id, familyParameter1.Id) || string.Compare(familyParameter2.ParameterName, familyParameter1.Definition.Name, true) == 0) && familyParameter2.StorageType == familyParameter1.StorageType)
              {
                string formula = familyParameter1.Formula;
                if (formula == null || formula == string.Empty)
                {
                  if (_PlantListFamilyTypeList[index1].HasValue(index3))
                  {
                    switch (familyParameter2.StorageType - 1)
                    {
                      case 0:
                        if (_PlantListFamilyTypeList[index1].GetIntegerValue(index3, ref _nValue))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, _nValue);
                          goto label_41;
                        }
                        goto label_41;
                      case 1:
                        if (_PlantListFamilyTypeList[index1].GetDoubleValue(index3, ref _dValue))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, _dValue);
                          goto label_41;
                        }
                        goto label_41;
                      case 2:
                        if (_PlantListFamilyTypeList[index1].GetStringValue(index3, ref _strValue))
                        {
                          if (string.Compare(_PlantListFamilyTypeList[index1].FamilyParameterList[index3].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) == 0)
                            _strValue = _Type != DialogType.PlantMix ? Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000") : Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
                          _CurDocument.FamilyManager.Set(familyParameter1, _strValue);
                          goto label_41;
                        }
                        goto label_41;
                      case 3:
                        if (_PlantListFamilyTypeList[index1].GetElementIdValue(index3, ref elementId))
                        {
                          try
                          {
                            _CurDocument.FamilyManager.Set(familyParameter1, elementId);
                            goto label_41;
                          }
                          catch (ArgumentOutOfRangeException ex)
                          {
                            if (ex.Message.StartsWith(EPShared.LocalRM.GetString("OutOfRangeArgumentMessage")))
                            {
                              flag1 = true;
                              goto label_41;
                            }
                            goto label_41;
                          }
                        }
                        else
                          goto label_41;
                      default:
                        goto label_41;
                    }
                  }
                  else
                  {
                    switch (familyParameter1.StorageType - 1)
                    {
                      case 0:
                        _CurDocument.FamilyManager.Set(familyParameter1, 0);
                        goto label_41;
                      case 1:
                        _CurDocument.FamilyManager.Set(familyParameter1, 0.0);
                        goto label_41;
                      case 2:
                        string str = string.Empty;
                        if (string.Compare(_PlantListFamilyTypeList[index1].FamilyParameterList[index3].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, true) == 0)
                          str = _Type != DialogType.PlantMix ? Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000") : Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000");
                        _CurDocument.FamilyManager.Set(familyParameter1, str);
                        goto label_41;
                      default:
                        goto label_41;
                    }
                  }
                }
              }
            }
          }
        }
        for (int index4 = 0; index4 < _NewFamilyParameterList.Count; ++index4)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter3 = _NewFamilyParameterList[index4];
          if (familyParameter3 != null)
          {
            for (int index5 = 0; index5 < _PlantListFamilyTypeList[index1].FamilyParameterList.Count; ++index5)
            {
              FamilyParameterWrapper familyParameter4 = _PlantListFamilyTypeList[index1].FamilyParameterList[index5];
              if (familyParameter4 != null && (familyParameter4.FamilyParameter != null && familyParameter4.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter4.FamilyParameter.Id, familyParameter3.Id) || string.Compare(familyParameter4.ParameterName, familyParameter3.Definition.Name, true) == 0) && familyParameter4.StorageType == familyParameter3.StorageType)
              {
                string formula = familyParameter3.Formula;
                if (formula != null && formula != string.Empty)
                {
                  if (_PlantListFamilyTypeList[index1].HasValue(index5))
                    _CurDocument.FamilyManager.SetFormula(familyParameter3, formula);
                  _PlantListFamilyTypeList[index1].FamilyParameterList.RemoveAt(index5);
                  _NewFamilyParameterList.RemoveAt(index4);
                  --index4;
                  break;
                }
              }
            }
          }
        }
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    _TransactionContainer.EndTransaction();
    _TransactionContainer.Commit();
    if (!_bIsActiveDocument)
    {
      _CurDocument.SaveAs(_strNewFilename, new SaveAsOptions()
      {
        OverwriteExistingFile = true
      });
      if (!_bIsDocumentOpen)
        _CurDocument.Close(false);
    }
    if (flag1)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("GetNewRevitVersionMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    return true;
  }

  public static bool CreateNewFamilyDocument(
    Document _ActiveDocument,
    List<FamilyTypeContainer> _PlantListFamilyTypeList,
    string _strSymbolFilename,
    string _strSymbolName,
    string _strNewFilename)
  {
    double _dValue = 0.0;
    string empty1 = string.Empty;
    int _nValue = 0;
    ElementId elementId = (ElementId) null;
    bool _bIsActiveDocument = false;
    bool _bIsDocumentOpen = false;
    bool _bCopied = false;
    Document _CurDocument = _ActiveDocument;
    EPTransactionContainer _TransactionContainer = (EPTransactionContainer) null;
    List<FamilyParameter> _NewFamilyParameterList = new List<FamilyParameter>();
    FamilySymbol _PlantingFamilySymbol = (FamilySymbol) null;
    if (!ManagePlants.SetupFamilyDocument(_ActiveDocument, _strSymbolFilename, _strSymbolName, _strNewFilename, ref _bIsActiveDocument, ref _bIsDocumentOpen, ref _CurDocument, ref _TransactionContainer, ref _NewFamilyParameterList, ref _PlantingFamilySymbol, ref _bCopied))
      return false;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    FamilyType familyType1 = (FamilyType) null;
    string empty2 = string.Empty;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _PlantListFamilyTypeList.Count;
    if (_PlantListFamilyTypeList.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarCreatingFamilyMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    string str = EPShared.LocalRM.GetString("CreatingFamilyTypeMessage");
    string _strText = EPShared.LocalRM.GetString("DuplicateTypeAppendMessage");
    string _strCaption = EPShared.LocalRM.GetString("Warning");
    string strB1 = EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter");
    string strB2 = EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter");
    string strB3 = EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter");
    string strB4 = EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter");
    if (_bCopied)
    {
      familyType1 = _CurDocument.FamilyManager.NewType(ManagePlants.GetUniqueTypeName(_CurDocument.FamilyManager.Types, "AddedOnlyToDeleteAllTypes"));
      foreach (FamilyType type in _CurDocument.FamilyManager.Types)
      {
        if (string.Compare(type.Name, "AddedOnlyToDeleteAllTypes", true) != 0)
        {
          _CurDocument.FamilyManager.CurrentType = type;
          _CurDocument.FamilyManager.DeleteCurrentType();
        }
      }
    }
    for (int index1 = 0; index1 < _PlantListFamilyTypeList.Count; ++index1)
    {
      if (_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName != string.Empty)
      {
        if (flag2)
        {
          FamilyType familyType2 = _CurDocument.FamilyManager.NewType(ManagePlants.GetUniqueTypeName(_CurDocument.FamilyManager.Types, _PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName));
          progressBarForm.Message = $"{str} {familyType2.Name}";
        }
        else if (ManagePlants.IsTypeNameDuplicate(_CurDocument.FamilyManager.Types, _PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName))
        {
          if (!flag3)
          {
            flag3 = true;
            if (RevitMessageBox.Show(_strText, _strCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
              flag2 = true;
              FamilyType familyType3 = _CurDocument.FamilyManager.NewType(ManagePlants.GetUniqueTypeName(_CurDocument.FamilyManager.Types, _PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName));
              progressBarForm.Message = $"{str} {familyType3.Name}";
            }
          }
          else
            continue;
        }
        else
        {
          FamilyType familyType4 = _CurDocument.FamilyManager.NewType(_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
          progressBarForm.Message = $"{str} {familyType4.Name}";
        }
        progressBarForm.ResetValue();
        progressBarForm.MinValue = 0;
        progressBarForm.MaxValue = _NewFamilyParameterList.Count * 2;
label_46:
        for (int index2 = 0; index2 < _NewFamilyParameterList.Count; ++index2)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter1 = _NewFamilyParameterList[index2];
          if (familyParameter1 != null)
          {
            for (int index3 = 0; index3 < _PlantListFamilyTypeList[index1].FamilyParameterList.Count; ++index3)
            {
              FamilyParameterWrapper familyParameter2 = _PlantListFamilyTypeList[index1].FamilyParameterList[index3];
              if (familyParameter2 != null && (familyParameter2.FamilyParameter != null && familyParameter2.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter2.FamilyParameter.Id, familyParameter1.Id) || string.Compare(familyParameter2.ParameterName, familyParameter1.Definition.Name, true) == 0) && familyParameter2.StorageType == familyParameter1.StorageType)
              {
                if ((string.Compare(familyParameter2.ParameterName, strB3, true) == 0 || string.Compare(familyParameter2.ParameterName, strB4, true) == 0) && _PlantingFamilySymbol != null && ((Element) _PlantingFamilySymbol).Id.IntegerValue > 0)
                  familyParameter2.ElementIdValue = ((Element) _PlantingFamilySymbol).Id;
                string formula = familyParameter1.Formula;
                if (formula == null || formula == string.Empty)
                {
                  if (_PlantListFamilyTypeList[index1].HasValue(index3))
                  {
                    switch (familyParameter2.StorageType - 1)
                    {
                      case 0:
                        if (_PlantListFamilyTypeList[index1].GetIntegerValue(index3, ref _nValue))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, _nValue);
                          goto label_46;
                        }
                        goto label_46;
                      case 1:
                        if (_PlantListFamilyTypeList[index1].GetDoubleValue(index3, ref _dValue))
                        {
                          if (RevitDefines.LE(_dValue, 0.0) && (string.Compare(familyParameter2.ParameterName, strB1, true) == 0 || string.Compare(familyParameter2.ParameterName, strB2, true) == 0))
                          {
                            _CurDocument.FamilyManager.Set(familyParameter1, 1.0);
                            goto label_46;
                          }
                          _CurDocument.FamilyManager.Set(familyParameter1, _dValue);
                          goto label_46;
                        }
                        goto label_46;
                      case 2:
                        if (_PlantListFamilyTypeList[index1].GetStringValue(index3, ref empty1))
                        {
                          _CurDocument.FamilyManager.Set(familyParameter1, empty1);
                          goto label_46;
                        }
                        goto label_46;
                      case 3:
                        if (string.Compare(familyParameter2.ParameterName, strB3, true) != 0)
                        {
                          try
                          {
                            _CurDocument.FamilyManager.Set(familyParameter1, elementId);
                            goto label_46;
                          }
                          catch (ArgumentOutOfRangeException ex)
                          {
                            if (ex.Message.StartsWith(EPShared.LocalRM.GetString("OutOfRangeArgumentMessage")))
                            {
                              flag1 = true;
                              goto label_46;
                            }
                            goto label_46;
                          }
                        }
                        else
                          goto label_46;
                      default:
                        goto label_46;
                    }
                  }
                  else
                    break;
                }
              }
            }
          }
        }
        for (int index4 = 0; index4 < _NewFamilyParameterList.Count; ++index4)
        {
          progressBarForm.UpdateProgressBar(1);
          FamilyParameter familyParameter3 = _NewFamilyParameterList[index4];
          if (familyParameter3 != null)
          {
            for (int index5 = 0; index5 < _PlantListFamilyTypeList[index1].FamilyParameterList.Count; ++index5)
            {
              FamilyParameterWrapper familyParameter4 = _PlantListFamilyTypeList[index1].FamilyParameterList[index5];
              if (familyParameter4 != null && (familyParameter4.FamilyParameter != null && familyParameter4.FamilyParameter.Id.IntegerValue != -1 && ElementId.op_Equality(familyParameter4.FamilyParameter.Id, familyParameter3.Id) || string.Compare(familyParameter4.ParameterName, familyParameter3.Definition.Name, true) == 0) && familyParameter4.StorageType == familyParameter3.StorageType)
              {
                string formula = familyParameter3.Formula;
                if (formula != null && formula != string.Empty)
                {
                  if (_PlantListFamilyTypeList[index1].HasValue(index5))
                    _CurDocument.FamilyManager.SetFormula(familyParameter3, formula);
                  _NewFamilyParameterList.RemoveAt(index4);
                  --index4;
                  break;
                }
              }
            }
          }
        }
      }
    }
    if (_bCopied)
    {
      foreach (FamilyType type in _CurDocument.FamilyManager.Types)
      {
        if (string.Compare(type.Name, "AddedOnlyToDeleteAllTypes", true) == 0)
        {
          _CurDocument.FamilyManager.CurrentType = type;
          _CurDocument.FamilyManager.DeleteCurrentType();
        }
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    _TransactionContainer.EndTransaction();
    _TransactionContainer.Commit();
    if (!_bIsActiveDocument)
    {
      _CurDocument.SaveAs(_strNewFilename, new SaveAsOptions()
      {
        OverwriteExistingFile = true
      });
      if (!_bIsDocumentOpen)
        _CurDocument.Close(false);
    }
    if (flag1)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("GetNewRevitVersionMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    return true;
  }

  private static bool SetupMixFamilyDocument(
    Document _ActiveDocument,
    string _strNewFilename,
    DialogType _Type,
    ref bool _bIsActiveDocument,
    ref bool _bIsDocumentOpen,
    ref Document _CurDocument,
    ref EPTransactionContainer _TransactionContainer,
    ref List<FamilyParameter> _NewFamilyParameterList)
  {
    _CurDocument = _ActiveDocument;
    if (RevitUtility.CompareFileNames(_ActiveDocument.PathName, _strNewFilename) == 0)
      _bIsActiveDocument = true;
    else if (File.Exists(_strNewFilename))
    {
      _bIsDocumentOpen = ManagePlants.IsDocumentOpen(_ActiveDocument.Application, _strNewFilename, ref _CurDocument);
      if (!_bIsDocumentOpen)
        _CurDocument = _ActiveDocument.Application.OpenDocumentFile(_strNewFilename);
    }
    else
    {
      string empty = string.Empty;
      if (!ManagePlants.FindMixTemplateFileName(_CurDocument, ref empty, true))
        return false;
      _CurDocument = _ActiveDocument.Application.NewFamilyDocument(empty);
    }
    _TransactionContainer = new EPTransactionContainer(_CurDocument);
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList1 = new List<FamilyParameterTypeWrapper>();
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList2;
    if (_Type == DialogType.PlantMix)
    {
      parameterTypeWrapperList2 = ManagePlants.PlantMixParamenterList();
      _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePlantMixFamilyTransaction"));
    }
    else
    {
      parameterTypeWrapperList2 = ManagePlants.PatioWalkParamenterList();
      _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePatioWalkFamilyTransaction"));
    }
    _TransactionContainer.BeginTransaction();
    BuiltInParameterGroup inParameterGroup = (BuiltInParameterGroup) -1;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = parameterTypeWrapperList2.Count;
    if (parameterTypeWrapperList2.Count <= 0)
      progressBarForm.MaxValue = 30;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSettingParametersMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    string modelFamilyParameter1 = RevitParameters.UniqueIDGenericModelFamilyParameter;
    string modelFamilyParameter2 = RevitParameters.RegionNameGenericModelFamilyParameter;
    for (int index = 0; index < parameterTypeWrapperList2.Count; ++index)
    {
      FamilyParameter familyParameter = (FamilyParameter) null;
      if (parameterTypeWrapperList2[index].BuiltInParameter != -1)
        familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList2[index].BuiltInParameter];
      if (familyParameter == null)
        familyParameter = _CurDocument.FamilyManager[parameterTypeWrapperList2[index].ParameterName];
      if (familyParameter != null)
      {
        _NewFamilyParameterList.Add(familyParameter);
      }
      else
      {
        if (parameterTypeWrapperList2[index].ParameterType == 3 || parameterTypeWrapperList2[index].ParameterType == 2 || parameterTypeWrapperList2[index].ParameterType == 4)
          inParameterGroup = (BuiltInParameterGroup) -5000101;
        else if (parameterTypeWrapperList2[index].ParameterType == 1 || parameterTypeWrapperList2[index].ParameterType == 17 || parameterTypeWrapperList2[index].ParameterType == 172)
          inParameterGroup = (BuiltInParameterGroup) -5000100;
        if (string.Compare(parameterTypeWrapperList2[index].ParameterName, modelFamilyParameter1, true) == 0 || string.Compare(parameterTypeWrapperList2[index].ParameterName, modelFamilyParameter2, true) == 0)
          _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList2[index].ParameterName, inParameterGroup, parameterTypeWrapperList2[index].ParameterType, true));
        else
          _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(parameterTypeWrapperList2[index].ParameterName, inParameterGroup, parameterTypeWrapperList2[index].ParameterType, false));
      }
      progressBarForm.UpdateProgressBar(1);
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  private static bool SetupFamilyDocument(
    Document _ActiveDocument,
    string _strSymbolFilename,
    string _strSymbolName,
    string _strNewFilename,
    ref bool _bIsActiveDocument,
    ref bool _bIsDocumentOpen,
    ref Document _CurDocument,
    ref EPTransactionContainer _TransactionContainer,
    ref List<FamilyParameter> _NewFamilyParameterList,
    ref FamilySymbol _PlantingFamilySymbol,
    ref bool _bCopied)
  {
    _CurDocument = _ActiveDocument;
    bool flag1 = false;
    if (string.Compare(_strSymbolName, EPShared.LocalRM.GetString("AllSymbolsString"), true) == 0 || string.Compare(_strSymbolName, EPShared.LocalRM.GetString("AllGeometryStringQuotes"), true) == 0)
      flag1 = true;
    if (RevitUtility.CompareFileNames(_ActiveDocument.PathName, _strNewFilename) == 0)
    {
      _bIsActiveDocument = true;
    }
    else
    {
      _bCopied = false;
      if (!File.Exists(_strNewFilename))
      {
        File.Copy(_strSymbolFilename, _strNewFilename);
        _bCopied = true;
      }
      if (File.Exists(_strNewFilename))
      {
        _bIsDocumentOpen = ManagePlants.IsDocumentOpen(_ActiveDocument.Application, _strNewFilename, ref _CurDocument);
        if (!_bIsDocumentOpen)
          _CurDocument = _ActiveDocument.Application.OpenDocumentFile(_strNewFilename);
      }
      else
      {
        string empty = string.Empty;
        if (!ManagePlants.FindTemplateFileName(_CurDocument, ref empty, true))
          return false;
        _CurDocument = _ActiveDocument.Application.NewFamilyDocument(empty);
      }
    }
    _TransactionContainer = new EPTransactionContainer(_CurDocument);
    _TransactionContainer.Start(EPShared.LocalRM.GetString("CreatePlantFamilyTransaction"));
    _TransactionContainer.BeginTransaction();
    string strPlantingSymbolParameter = EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter");
    if (!_bCopied)
    {
      bool flag2 = false;
      if (RevitUtility.CompareFileNames(_ActiveDocument.PathName, _strSymbolFilename) != 0)
      {
        if (RevitUtility.CompareFileNames(_CurDocument.PathName, _strSymbolFilename) == 0)
        {
          Document CurDocument = (Document) null;
          ManagePlants.IsDocumentOpen(_ActiveDocument.Application, _strSymbolFilename, ref CurDocument);
          if (CurDocument != null)
          {
            if (flag1)
              RevitUtility.LoadFamily(_CurDocument, CurDocument, true, ref _TransactionContainer);
            else
              RevitUtility.LoadFamilySymbol(_CurDocument, CurDocument.PathName, _strSymbolName, true, ref _TransactionContainer);
          }
          else
            flag2 = !flag1 ? RevitUtility.LoadFamilySymbol(_CurDocument, _strSymbolFilename, _strSymbolName, true, ref _TransactionContainer) : RevitUtility.LoadFamily(_CurDocument, _strSymbolFilename, true, ref _TransactionContainer);
        }
        else
          flag2 = !flag1 ? RevitUtility.LoadFamilySymbol(_CurDocument, _strSymbolFilename, _strSymbolName, true, ref _TransactionContainer) : RevitUtility.LoadFamily(_CurDocument, _strSymbolFilename, true, ref _TransactionContainer);
      }
    }
    FileInfo fileInfo = (FileInfo) null;
    if (!string.IsNullOrEmpty(_ActiveDocument.Application.SharedParametersFilename))
      fileInfo = new FileInfo(_ActiveDocument.Application.SharedParametersFilename);
    List<ExternalDefinitionContainer> definitionContainerList = (List<ExternalDefinitionContainer>) null;
    int num = 0;
    if (fileInfo != null && fileInfo.Exists)
    {
      if (_ActiveDocument.Application.OpenSharedParameterFile().Groups[EPShared.LocalRM.GetString("PlantingDefinitionGroup")] == null)
        return false;
      definitionContainerList = ManagePlants.PopulateExternalDefinitionList(new List<Definition>(), ManagePlants.GetParameterList("PlantFields", false));
      num = definitionContainerList.Count;
    }
    List<BuiltInParameter> _BuiltInParameterList = new List<BuiltInParameter>();
    List<string> stringList = ManagePlants.PlantingCommonParamenterList(ref _BuiltInParameterList);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = stringList.Count + num;
    if (stringList.Count + num <= 0)
      progressBarForm.MaxValue = 100;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSettingParametersMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    string strB1 = EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter");
    string strB2 = EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter");
    string strB3 = EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter");
    string strB4 = EPShared.LocalRM.GetString("PlantScientificNamePlantFamilyParameter");
    string strB5 = EPShared.LocalRM.GetString("PlantTypePlantFamilyParameter");
    string strB6 = EPShared.LocalRM.GetString("PlantCommonNamePlantFamilyParameter");
    string strB7 = EPShared.LocalRM.GetString("PlantCodeNamePlantFamilyParameter");
    string strGenericPlantingSymbolParameter = EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter");
    string strB8 = EPShared.LocalRM.GetString("PlacementIDFamilyParameter");
    string strB9 = EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter");
    string strB10 = EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter");
    string str1 = EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter");
    string str2 = EPShared.LocalRM.GetString("LabelFamilyInstanceParameter");
    for (int index = 0; index < stringList.Count; ++index)
    {
      FamilyParameter familyParameter = (FamilyParameter) null;
      if (_BuiltInParameterList[index] != -1)
        familyParameter = _CurDocument.FamilyManager[_BuiltInParameterList[index]];
      if (familyParameter == null)
        familyParameter = _CurDocument.FamilyManager[stringList[index]];
      if (familyParameter != null)
      {
        _NewFamilyParameterList.Add(familyParameter);
      }
      else
      {
        try
        {
          ParameterType parameterType = string.Compare(stringList[index], strB1, true) != 0 ? (ParameterType) 1 : (ParameterType) 4;
          BuiltInParameterGroup inParameterGroup = (BuiltInParameterGroup) -5000100;
          bool flag3 = false;
          _NewFamilyParameterList.Add(_CurDocument.FamilyManager.AddParameter(stringList[index], inParameterGroup, parameterType, flag3));
        }
        catch (InvalidOperationException ex)
        {
          if (string.Compare(((Exception) ex).Message, EPShared.LocalRM.GetString("FailedCreatingSharedParameterMessage"), true) == 0)
            continue;
        }
      }
      progressBarForm.UpdateProgressBar(1);
    }
    FamilyParameter familyParameter1 = (FamilyParameter) null;
    FamilyParameter familyParameter2 = (FamilyParameter) null;
    bool flag4 = false;
    bool flag5 = false;
    for (int index = 0; index < num; ++index)
    {
      ParameterType parameterType = (ParameterType) 1;
      BuiltInParameterGroup inParameterGroup;
      bool flag6;
      if (string.Compare(definitionContainerList[index].Name, strB2, true) == 0 || string.Compare(definitionContainerList[index].Name, strB1, true) == 0)
      {
        parameterType = (ParameterType) 4;
        inParameterGroup = (BuiltInParameterGroup) -5000101;
        flag6 = true;
      }
      else if (string.Compare(definitionContainerList[index].Name, strB3, true) == 0)
      {
        parameterType = (ParameterType) 2;
        inParameterGroup = (BuiltInParameterGroup) -5000100;
        flag6 = true;
      }
      else if (string.Compare(definitionContainerList[index].Name, strB4, true) == 0 || string.Compare(definitionContainerList[index].Name, strB5, true) == 0 || string.Compare(definitionContainerList[index].Name, strB6, true) == 0 || string.Compare(definitionContainerList[index].Name, strB7, true) == 0)
      {
        inParameterGroup = (BuiltInParameterGroup) -5000100;
        flag6 = false;
      }
      else if (string.Compare(definitionContainerList[index].Name, strB9, true) == 0 || string.Compare(definitionContainerList[index].Name, strB10, true) == 0)
      {
        parameterType = (ParameterType) 4;
        inParameterGroup = (BuiltInParameterGroup) -1;
        flag6 = false;
      }
      else if (string.Compare(definitionContainerList[index].Name, strB8, true) == 0)
      {
        inParameterGroup = (BuiltInParameterGroup) -1;
        flag6 = true;
      }
      else
      {
        if (string.Compare(definitionContainerList[index].Name, strPlantingSymbolParameter, true) == 0)
          flag4 = true;
        else if (string.Compare(definitionContainerList[index].Name, strGenericPlantingSymbolParameter, true) == 0)
          flag5 = true;
        inParameterGroup = (BuiltInParameterGroup) -1;
        flag6 = false;
      }
      FamilyParameter familyParameter3 = _CurDocument.FamilyManager[definitionContainerList[index].Name];
      if (familyParameter3 != null)
      {
        _NewFamilyParameterList.Add(familyParameter3);
      }
      else
      {
        try
        {
          if (definitionContainerList[index].ExternalDefinition != null)
          {
            familyParameter3 = _CurDocument.FamilyManager.AddParameter(definitionContainerList[index].ExternalDefinition, inParameterGroup, flag6);
            _NewFamilyParameterList.Add(familyParameter3);
          }
          else
          {
            familyParameter3 = _CurDocument.FamilyManager.AddParameter(definitionContainerList[index].Name, inParameterGroup, parameterType, flag6);
            _NewFamilyParameterList.Add(familyParameter3);
          }
        }
        catch (InvalidOperationException ex)
        {
          if (string.Compare(((Exception) ex).Message, "Shared parameter creation failed.", true) == 0)
          {
            if (string.Compare(definitionContainerList[index].Name, strPlantingSymbolParameter, true) == 0)
            {
              flag4 = false;
              continue;
            }
            if (string.Compare(definitionContainerList[index].Name, strGenericPlantingSymbolParameter, true) == 0)
            {
              flag5 = false;
              continue;
            }
            continue;
          }
        }
      }
      if (string.Compare(definitionContainerList[index].Name, strB1, true) == 0)
        familyParameter1 = familyParameter3;
      else if (string.Compare(definitionContainerList[index].Name, strB2, true) == 0)
        familyParameter2 = familyParameter3;
      progressBarForm.UpdateProgressBar(1);
    }
    FamilyParameterComparer parameterComparer = new FamilyParameterComparer();
    _NewFamilyParameterList.Sort((IComparer<FamilyParameter>) parameterComparer);
    IList<Element> elements1 = new FilteredElementCollector(_CurDocument).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements();
    bool flag7 = false;
    FamilyInstance familyInstance1 = (FamilyInstance) null;
    foreach (Element element in (IEnumerable<Element>) elements1)
    {
      if (element is FamilyInstance familyInstance2 && familyInstance2.Symbol != null && ((Element) familyInstance2.Symbol).Category != null && ((Element) familyInstance2.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
      {
        familyInstance1 = familyInstance2;
        if (flag1 || string.Compare(_strSymbolName, ((Element) familyInstance2.Symbol).Name, true) == 0)
        {
          flag7 = true;
          if (familyParameter1 != null)
          {
            Parameter parameter = ((Element) familyInstance2).LookupParameter(strB1);
            if (parameter != null)
              _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter1);
          }
          if (familyParameter2 != null)
          {
            Parameter parameter = ((Element) familyInstance2).LookupParameter(strB2);
            if (parameter != null)
            {
              _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter2);
              break;
            }
            break;
          }
          break;
        }
      }
    }
    if (familyInstance1 == null)
    {
      IList<Element> elements2 = new FilteredElementCollector(_CurDocument).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151).ToElements();
      bool flag8 = false;
      foreach (Element element in (IEnumerable<Element>) elements2)
      {
        if (element is FamilyInstance familyInstance3 && familyInstance3.Symbol != null && ((Element) familyInstance3.Symbol).Category != null && ((Element) familyInstance3.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
        {
          Parameter parameter1 = ((Element) familyInstance3.Symbol).LookupParameter(str1);
          if (parameter1 != null)
          {
            if (string.Compare(parameter1.AsString(), Convert.ToInt32((object) LandcaddID.Planting).ToString("000"), true) == 0)
              flag8 = true;
            familyInstance1 = familyInstance3;
            if (flag1 || string.Compare(_strSymbolName, ((Element) familyInstance3.Symbol).Name, true) == 0)
            {
              flag7 = true;
              if (familyParameter1 != null)
              {
                Parameter parameter2 = ((Element) familyInstance3).LookupParameter(strB1);
                if (parameter2 != null)
                  _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter2, familyParameter1);
              }
              if (familyParameter2 != null)
              {
                Parameter parameter3 = ((Element) familyInstance3).LookupParameter(strB2);
                if (parameter3 != null)
                {
                  _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter3, familyParameter2);
                  break;
                }
                break;
              }
              break;
            }
          }
        }
      }
      if (familyInstance1 != null && !flag8)
        familyInstance1 = (FamilyInstance) null;
    }
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(_CurDocument).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001360).ToElements())
    {
      if (element is FamilySymbol familySymbol && ((Element) familySymbol).Category != null && ((Element) familySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
      {
        if (flag1 || string.Compare(_strSymbolName, ((Element) familySymbol).Name, true) == 0)
        {
          if (_PlantingFamilySymbol == null)
            _PlantingFamilySymbol = familySymbol;
          if (familyParameter1 != null)
          {
            Parameter parameter = ((Element) familySymbol).LookupParameter(strB1);
            if (parameter != null)
              _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter1);
          }
          if (familyParameter2 != null)
          {
            Parameter parameter = ((Element) familySymbol).LookupParameter(strB2);
            if (parameter != null)
              _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter2);
          }
        }
        else if (!flag4)
          _CurDocument.Delete(((Element) familySymbol).Id);
      }
    }
    if (_PlantingFamilySymbol == null)
    {
      foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(_CurDocument).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151).ToElements())
      {
        if (element is FamilySymbol familySymbol && ((Element) familySymbol).Category != null && ((Element) familySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
        {
          Parameter parameter4 = ((Element) familySymbol).LookupParameter(str1);
          if (parameter4 != null && string.Compare(parameter4.AsString(), Convert.ToInt32((object) LandcaddID.Planting).ToString("000"), true) == 0)
          {
            if (flag1 || string.Compare(_strSymbolName, ((Element) familySymbol).Name, true) == 0)
            {
              if (_PlantingFamilySymbol == null)
                _PlantingFamilySymbol = familySymbol;
              if (familyParameter1 != null)
              {
                Parameter parameter5 = ((Element) familySymbol).LookupParameter(strB1);
                if (parameter5 != null)
                  _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter5, familyParameter1);
              }
              if (familyParameter2 != null)
              {
                Parameter parameter6 = ((Element) familySymbol).LookupParameter(strB2);
                if (parameter6 != null)
                  _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter6, familyParameter2);
              }
            }
            else if (!flag5)
              _CurDocument.Delete(((Element) familySymbol).Id);
          }
        }
      }
    }
    if (_PlantingFamilySymbol != null)
    {
      if (familyInstance1 == null)
      {
        if (!_PlantingFamilySymbol.IsActive)
          _PlantingFamilySymbol.Activate();
        XYZ xyz = new XYZ(0.0, 0.0, 0.0);
        familyInstance1 = ((ItemFactoryBase) _CurDocument.FamilyCreate).NewFamilyInstance(xyz, _PlantingFamilySymbol, (StructuralType) 0);
      }
      else
        familyInstance1.Symbol = _PlantingFamilySymbol;
      Parameter parameter7 = ((Element) familyInstance1).LookupParameter(str2);
      if (parameter7 != null)
      {
        if (flag4)
        {
          foreach (Element element in (IEnumerable<Element>) ((IEnumerable<Element>) new FilteredElementCollector(_CurDocument).WhereElementIsNotElementType()).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.Name == strPlantingSymbolParameter)).ToList<Element>())
          {
            if (element != null && string.Compare(element.Name, strPlantingSymbolParameter, true) == 0)
            {
              ElementId id = element.Id;
              try
              {
                if (parameter7.Set(id))
                  break;
              }
              catch (SEHException ex)
              {
              }
            }
          }
        }
        else if (flag5)
        {
          foreach (Element element in (IEnumerable<Element>) ((IEnumerable<Element>) new FilteredElementCollector(_CurDocument).WhereElementIsNotElementType()).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement.Name == strGenericPlantingSymbolParameter)).ToList<Element>())
          {
            if (element != null && string.Compare(element.Name, strGenericPlantingSymbolParameter, true) == 0)
            {
              ElementId id = element.Id;
              try
              {
                if (parameter7.Set(id))
                  break;
              }
              catch (SEHException ex)
              {
              }
            }
          }
        }
      }
      if (!flag7)
      {
        if (familyParameter1 != null)
        {
          Parameter parameter8 = ((Element) familyInstance1).LookupParameter(strB1);
          if (parameter8 != null && _CurDocument.FamilyManager.CanElementParameterBeAssociated(parameter8))
            _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter8, familyParameter1);
        }
        if (familyParameter2 != null)
        {
          Parameter parameter9 = ((Element) familyInstance1).LookupParameter(strB2);
          if (parameter9 != null && _CurDocument.FamilyManager.CanElementParameterBeAssociated(parameter9))
            _CurDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter9, familyParameter2);
        }
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  public static string GetParameterInformation(Element _Element, Document _CurDocument)
  {
    string parameterInformation = "";
    foreach (Parameter parameter in _Element.Parameters)
    {
      parameterInformation += parameter.Definition.Name;
      switch (parameter.StorageType - 1)
      {
        case 0:
          parameterInformation += " (Integer):\t";
          parameterInformation = 10 != parameter.Definition.ParameterType ? parameterInformation + parameter.AsInteger().ToString() : (parameter.AsInteger() != 0 ? parameterInformation + "True" : parameterInformation + "False");
          break;
        case 1:
          parameterInformation = $"{parameterInformation} (Double):\t{parameter.AsValueString()}";
          break;
        case 2:
          parameterInformation = $"{parameterInformation} (String):\t{parameter.AsString()}";
          break;
        case 3:
          parameterInformation += " (ElementId):\t";
          ElementId elementId = parameter.AsElementId();
          parameterInformation = elementId.IntegerValue < 0 ? parameterInformation + elementId.IntegerValue.ToString() : parameterInformation + _CurDocument.GetElement(elementId).Name;
          break;
        default:
          parameterInformation += " :\tUnexposed parameter.";
          break;
      }
      parameterInformation += "\n";
    }
    return parameterInformation;
  }

  public static List<ExternalDefinitionContainer> PopulateExternalDefinitionList(
    List<Definition> _Definitions)
  {
    return ManagePlants.PopulateExternalDefinitionList(_Definitions, new List<ParameterColumn>());
  }

  public static List<ExternalDefinitionContainer> PopulateExternalDefinitionList(
    List<Definition> _Definitions,
    List<ParameterColumn> _SettingParameterList)
  {
    string strA1 = EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter");
    string strA2 = EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter");
    string strA3 = EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter");
    string strA4 = EPShared.LocalRM.GetString("PlacementIDFamilyParameter");
    List<ExternalDefinitionContainer> definitionContainerList = new List<ExternalDefinitionContainer>();
    string empty = string.Empty;
    foreach (string sharedParamenter in ManagePlants.PlantSharedParamenterList())
    {
      bool flag;
      if (string.Compare(strA1, sharedParamenter, true) == 0 || string.Compare(strA2, sharedParamenter, true) == 0 || string.Compare(strA3, sharedParamenter, true) == 0)
        flag = true;
      else if (string.Compare(strA4, sharedParamenter, true) == 0)
      {
        flag = true;
      }
      else
      {
        flag = false;
        for (int index = 0; index < _SettingParameterList.Count; ++index)
        {
          if (string.Compare(ManagePlants.GetPlantParamenterName(_SettingParameterList[index].PlantField), sharedParamenter, true) == 0)
          {
            flag = true;
            break;
          }
        }
      }
      if (_SettingParameterList.Count == 0 || flag)
      {
        ExternalDefinition _ExternalDefinition = (ExternalDefinition) null;
        foreach (Definition definition in _Definitions)
        {
          if (definition.Name == sharedParamenter)
          {
            _ExternalDefinition = definition as ExternalDefinition;
            break;
          }
        }
        if (_ExternalDefinition != null)
          definitionContainerList.Add(new ExternalDefinitionContainer(_ExternalDefinition));
        else if (string.Compare(strA2, sharedParamenter, true) != 0 && string.Compare(strA3, sharedParamenter, true) != 0)
          definitionContainerList.Add(new ExternalDefinitionContainer(sharedParamenter));
        else if (string.Compare(strA4, sharedParamenter, true) != 0)
          definitionContainerList.Add(new ExternalDefinitionContainer(sharedParamenter));
      }
    }
    return definitionContainerList;
  }

  public static bool IsDocumentOpen(
    Application _CurApplication,
    string _strFilename,
    ref Document CurDocument)
  {
    bool flag = false;
    foreach (Document document in _CurApplication.Documents)
    {
      if (RevitUtility.CompareFileNames(document.PathName, _strFilename) == 0)
      {
        CurDocument = document;
        flag = true;
        break;
      }
    }
    return flag;
  }

  public static List<FamilyParameterWrapper> GetFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager,
    List<ExternalDefinitionContainer> _ExternalDefinitionList)
  {
    List<FamilyParameterWrapper> parameterSetForType = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    List<string> stringList = ManagePlants.PlantingCommonParamenterList();
    for (int index = 0; index < stringList.Count; ++index)
    {
      FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(stringList[index], _FamilyManager[stringList[index]], stringList[index]);
      parameterSetForType.Add(parameterWrapper);
    }
    string strB1 = EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter");
    string strB2 = EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter");
    FamilyParameter _FamilyParameter = (FamilyParameter) null;
    for (int index = 0; index < _ExternalDefinitionList.Count; ++index)
    {
      if (_ExternalDefinitionList[index].ExternalDefinition != null)
        _FamilyParameter = _FamilyManager[(Definition) _ExternalDefinitionList[index].ExternalDefinition];
      if (_FamilyParameter == null)
        _FamilyParameter = _FamilyManager[_ExternalDefinitionList[index].Name];
      FamilyParameterWrapper parameterWrapper = new FamilyParameterWrapper(_ExternalDefinitionList[index].Name, _FamilyParameter, _ExternalDefinitionList[index].Name);
      if (string.Compare(_ExternalDefinitionList[index].Name, strB1, true) == 0 || string.Compare(_ExternalDefinitionList[index].Name, strB2, true) == 0)
        parameterWrapper.StorageType = (StorageType) 4;
      parameterSetForType.Add(parameterWrapper);
    }
    FamilyParameterWrapperComparer parameterWrapperComparer = new FamilyParameterWrapperComparer();
    parameterSetForType.Sort((IComparer<FamilyParameterWrapper>) parameterWrapperComparer);
    return parameterSetForType;
  }

  public static List<ParameterColumn> GetParameterList(string _strSettingName)
  {
    return ManagePlants.GetParameterList(_strSettingName, true);
  }

  public static List<ParameterColumn> GetParameterList(
    string _strSettingName,
    bool _bPopulateDefaultParameters)
  {
    int _nReturnValue = 0;
    List<ParameterColumn> parameterList = new List<ParameterColumn>();
    string str = EPShared.LocalRM.GetString("ColumnOrderString");
    foreach (int num in Enum.GetValues(typeof (PlantField)))
    {
      if ((PlantField) Enum.ToObject(typeof (PlantField), num) != PlantField.None && ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingName + Enum.GetName(typeof (PlantField), (object) num) + str, ref _nReturnValue) && _nReturnValue > 0)
        parameterList.Add(new ParameterColumn((PlantField) Enum.ToObject(typeof (PlantField), num), _nReturnValue));
    }
    if (parameterList.Count > 0)
    {
      ParameterColumnComparer parameterColumnComparer = new ParameterColumnComparer();
      parameterList.Sort((IComparer<ParameterColumn>) parameterColumnComparer);
    }
    else if (_bPopulateDefaultParameters)
    {
      if (string.Compare(_strSettingName, "PlantFields", true) == 0)
      {
        List<string> stringList = ManagePlants.PlantSharedParamenterList();
        for (int index = 0; index < stringList.Count; ++index)
          parameterList.Add(new ParameterColumn(ManagePlants.GetPlantFieldFromParamenter(stringList[index]), index + 1));
      }
      else
      {
        parameterList.Add(new ParameterColumn(PlantField.PlantCommonName, 1));
        parameterList.Add(new ParameterColumn(PlantField.PlantScientificName, 2));
        parameterList.Add(new ParameterColumn(PlantField.PlantType, 3));
        parameterList.Add(new ParameterColumn(PlantField.PlantHeight, 4));
        parameterList.Add(new ParameterColumn(PlantField.PlantWidth, 5));
      }
    }
    return parameterList;
  }

  public static List<FamilyParameterWrapper> GetPlantMixFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.TypeNamePlantFamilyType] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, _FamilyType.Name, (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), _FamilyManager[RevitParameters.TypeNamePlantFamilyType], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.CommonNamePlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), RevitParameters.CommonNamePlantMixFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), _FamilyManager[RevitParameters.CommonNamePlantMixFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.ScientificNamePlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), RevitParameters.ScientificNamePlantMixFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), _FamilyManager[RevitParameters.ScientificNamePlantMixFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.RegionNameGenericModelFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), _FamilyManager[RevitParameters.RegionNameGenericModelFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.UniqueIDGenericModelFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), _FamilyManager[RevitParameters.UniqueIDGenericModelFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.LandcaddIDGenericModelFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), _FamilyManager[RevitParameters.LandcaddIDGenericModelFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    FamilyParameterWrapper parameterWrapper7 = _FamilyManager[RevitParameters.CodeNamePlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CodeNamePlantMixFamilyParameter"), RevitParameters.CodeNamePlantMixFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CodeNamePlantMixFamilyParameter"), _FamilyManager[RevitParameters.CodeNamePlantMixFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper7);
    FamilyParameterWrapper parameterWrapper8 = _FamilyManager[RevitParameters.PlantSizePlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("PlantSizePlantMixFamilyParameter"), RevitParameters.PlantSizePlantMixFamilyParameter, "1", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("PlantSizePlantMixFamilyParameter"), _FamilyManager[RevitParameters.PlantSizePlantMixFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper8);
    FamilyParameterWrapper parameterWrapper9 = _FamilyManager[RevitParameters.SpacingMethodPlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), RevitParameters.SpacingMethodPlantMixFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), _FamilyManager[RevitParameters.SpacingMethodPlantMixFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper9);
    FamilyParameterWrapper parameterWrapper10 = _FamilyManager[RevitParameters.PlantSpacingPlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), RevitParameters.PlantSpacingPlantMixFamilyParameter, "1.0", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), _FamilyManager[RevitParameters.PlantSpacingPlantMixFamilyParameter], EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"));
    _ReturnFamilyParameterSet.Add(parameterWrapper10);
    FamilyParameterWrapper parameterWrapper11 = _FamilyManager[RevitParameters.PercentagePlantMixFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), RevitParameters.PercentagePlantMixFamilyParameter, "1.0", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), _FamilyManager[RevitParameters.PercentagePlantMixFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper11);
    ManagePlants.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }

  public static List<FamilyParameterWrapper> GetPatioWalkFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager)
  {
    List<FamilyParameterWrapper> _ReturnFamilyParameterSet = new List<FamilyParameterWrapper>();
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameterWrapper parameterWrapper1 = _FamilyManager[RevitParameters.TypeNamePlantFamilyType] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), RevitParameters.TypeNamePlantFamilyType, _FamilyType.Name, (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), _FamilyManager[RevitParameters.TypeNamePlantFamilyType], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameterWrapper parameterWrapper2 = _FamilyManager[RevitParameters.RegionNameGenericModelFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), _FamilyManager[EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter")], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameterWrapper parameterWrapper3 = _FamilyManager[RevitParameters.UniqueIDGenericModelFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), _FamilyManager[RevitParameters.UniqueIDGenericModelFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameterWrapper parameterWrapper4 = _FamilyManager[RevitParameters.LandcaddIDGenericModelFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), _FamilyManager[RevitParameters.LandcaddIDGenericModelFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameterWrapper parameterWrapper5 = _FamilyManager[RevitParameters.MaterialPathWalkFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), RevitParameters.MaterialPathWalkFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), _FamilyManager[RevitParameters.MaterialPathWalkFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameterWrapper parameterWrapper6 = _FamilyManager[RevitParameters.ThicknessPathWalkFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), RevitParameters.ThicknessPathWalkFamilyParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), _FamilyManager[RevitParameters.ThicknessPathWalkFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    FamilyParameterWrapper parameterWrapper7 = _FamilyManager[RevitParameters.EdgePathWalkFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), RevitParameters.EdgePathWalkFamilyParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), _FamilyManager[RevitParameters.EdgePathWalkFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper7);
    FamilyParameterWrapper parameterWrapper8 = _FamilyManager[RevitParameters.MowingStripPathWalkFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), RevitParameters.MowingStripPathWalkFamilyParameter, "", (StorageType) 1) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), _FamilyManager[RevitParameters.MowingStripPathWalkFamilyParameter], "");
    _ReturnFamilyParameterSet.Add(parameterWrapper8);
    FamilyParameterWrapper parameterWrapper9 = _FamilyManager[RevitParameters.EdgeWidthPathWalkFamilyParameter] == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), RevitParameters.EdgeWidthPathWalkFamilyParameter, "", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), _FamilyManager[RevitParameters.EdgeWidthPathWalkFamilyParameter], EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"));
    _ReturnFamilyParameterSet.Add(parameterWrapper9);
    ManagePlants.GetGenericModelFamilyParameterSetForType(_FamilyType, _FamilyManager, ref _ReturnFamilyParameterSet);
    return _ReturnFamilyParameterSet;
  }

  public static void GetGenericModelFamilyParameterSetForType(
    FamilyType _FamilyType,
    FamilyManager _FamilyManager,
    ref List<FamilyParameterWrapper> _ReturnFamilyParameterSet)
  {
    _FamilyManager.CurrentType = _FamilyType;
    FamilyParameter _FamilyParameter1 = _FamilyManager[(BuiltInParameter) -1140422] ?? _FamilyManager[RevitParameters.KeynoteGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper1 = _FamilyParameter1 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), RevitParameters.KeynoteGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("KeynoteGenericFamilyParameter"), _FamilyParameter1, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper1);
    FamilyParameter _FamilyParameter2 = _FamilyManager[(BuiltInParameter) -1010109] ?? _FamilyManager[RevitParameters.ModelGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper2 = _FamilyParameter2 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), RevitParameters.ModelGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ModelGenericFamilyParameter"), _FamilyParameter2, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper2);
    FamilyParameter _FamilyParameter3 = _FamilyManager[(BuiltInParameter) -1010108] ?? _FamilyManager[RevitParameters.ManufacturerGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper3 = _FamilyParameter3 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), RevitParameters.ManufacturerGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("ManufacturerGenericFamilyParameter"), _FamilyParameter3, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper3);
    FamilyParameter _FamilyParameter4 = _FamilyManager[(BuiltInParameter) -1010105] ?? _FamilyManager[RevitParameters.TypeCommentsGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper4 = _FamilyParameter4 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), RevitParameters.TypeCommentsGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("TypeCommentsGenericFamilyParameter"), _FamilyParameter4, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper4);
    FamilyParameter _FamilyParameter5 = _FamilyManager[(BuiltInParameter) -1010104] ?? _FamilyManager[RevitParameters.URLGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper5 = _FamilyParameter5 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), RevitParameters.URLGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("URLGenericFamilyParameter"), _FamilyParameter5, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper5);
    FamilyParameter _FamilyParameter6 = _FamilyManager[(BuiltInParameter) -1010103] ?? _FamilyManager[RevitParameters.DescriptionGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper6 = _FamilyParameter6 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), RevitParameters.DescriptionGenericFamilyParameter, "", (StorageType) 3) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("DescriptionGenericFamilyParameter"), _FamilyParameter6, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper6);
    FamilyParameter _FamilyParameter7 = _FamilyManager[(BuiltInParameter) -1001205] ?? _FamilyManager[RevitParameters.CostGenericFamilyParameter];
    FamilyParameterWrapper parameterWrapper7 = _FamilyParameter7 == null ? new FamilyParameterWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), RevitParameters.CostGenericFamilyParameter, "1.0", (StorageType) 2) : new FamilyParameterWrapper(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), _FamilyParameter7, "");
    _ReturnFamilyParameterSet.Add(parameterWrapper7);
  }

  public static void CreateSharedParametersFilename(Document _Document)
  {
    FileInfo fileInfo = (FileInfo) null;
    if (!string.IsNullOrEmpty(_Document.Application.SharedParametersFilename))
      fileInfo = new FileInfo(_Document.Application.SharedParametersFilename);
    if (fileInfo != null && fileInfo.Exists)
      return;
    using (SharedParametersFilenameForm parametersFilenameForm = new SharedParametersFilenameForm())
    {
      string empty = string.Empty;
      parametersFilenameForm.SharedParameterFileName = ApplicationUtility.RegistryPaths.GetSupportPath("LC Shared Parameters.txt", ref empty) != 0 ? _Document.Application.SharedParametersFilename : empty;
      if (parametersFilenameForm.ShowDialog() == DialogResult.Cancel)
        return;
      if (!new FileInfo(parametersFilenameForm.SharedParameterFileName).Exists)
        File.Create(parametersFilenameForm.SharedParameterFileName).Close();
      _Document.Application.SharedParametersFilename = parametersFilenameForm.SharedParameterFileName;
      DefinitionFile _DefinitionFile = _Document.Application.OpenSharedParameterFile();
      DefinitionGroups groups = _DefinitionFile.Groups;
      DefinitionGroup definitionGroup = groups[EPShared.LocalRM.GetString("PlantingDefinitionGroup")] ?? groups.Create(EPShared.LocalRM.GetString("PlantingDefinitionGroup"));
      List<string> parametersNotInList = ManagePlants.FindSharedParametersNotInList(_DefinitionFile, ManagePlants.PlantSharedParamenterList());
      Definitions definitions = definitionGroup.Definitions;
      ManagePlants.VerifySharedParametersAreMissing(_Document.Application, ref parametersNotInList);
      if (parametersNotInList == null || parametersNotInList.Count <= 0)
        return;
      ManagePlants.CreateSharedParameters(_Document, ref definitions, parametersNotInList, (EPTransactionContainer) null);
    }
  }

  public static void CreateSharedParameters(
    Document _Document,
    ref Definitions Definitions,
    List<string> ParameterList,
    EPTransactionContainer _Transaction)
  {
    if (Definitions == null)
      return;
    ExternalDefinition externalDefinition1 = (ExternalDefinition) null;
    ExternalDefinition externalDefinition2 = (ExternalDefinition) null;
    EPTransactionContainer transactionContainer = (EPTransactionContainer) null;
    string strB1 = EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter");
    string strB2 = EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter");
    string strB3 = EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter");
    string strB4 = EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter");
    string strB5 = EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter");
    string strB6 = EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter");
    string strB7 = EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter");
    for (int index = 0; index < ParameterList.Count; ++index)
    {
      ParameterType parameterType = string.Compare(ParameterList[index], strB2, true) == 0 || string.Compare(ParameterList[index], strB1, true) == 0 || string.Compare(ParameterList[index], strB6, true) == 0 || string.Compare(ParameterList[index], strB7, true) == 0 ? (ParameterType) 4 : (string.Compare(ParameterList[index], strB3, true) != 0 ? (string.Compare(ParameterList[index], strB4, true) == 0 || string.Compare(ParameterList[index], strB5, true) == 0 ? (ParameterType) 17 : (ParameterType) 1) : (ParameterType) 2);
      ExternalDefinitionCreationOptions definitionCreationOptions = new ExternalDefinitionCreationOptions(ParameterList[index], parameterType);
      Definition definition = Definitions.Create(definitionCreationOptions);
      if (string.Compare(ParameterList[index], strB4, true) == 0 || string.Compare(ParameterList[index], strB5, true) == 0)
      {
        CategorySet categorySet = _Document.Application.Create.NewCategorySet();
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001360;
        if (string.Compare(ParameterList[index], strB4, true) == 0)
          externalDefinition1 = (ExternalDefinition) definition;
        else if (string.Compare(ParameterList[index], strB5, true) == 0)
        {
          externalDefinition2 = (ExternalDefinition) definition;
          builtInCategory = (BuiltInCategory) -2000151;
        }
        if (transactionContainer == null && _Transaction == null)
        {
          transactionContainer = new EPTransactionContainer(_Document);
          transactionContainer.Start(EPShared.LocalRM.GetString("CreateSharedParametersTransaction"));
        }
        Category category = _Document.Settings.Categories[builtInCategory];
        categorySet.Insert(category);
        TypeBinding typeBinding = _Document.Application.Create.NewTypeBinding(categorySet);
        ((DefinitionBindingMap) _Document.ParameterBindings).Insert(definition, (Binding) typeBinding);
      }
    }
    if (_Transaction == null && transactionContainer != null && transactionContainer.HasStarted())
      transactionContainer.Commit();
    if (externalDefinition1 == null && externalDefinition2 == null)
      return;
    StreamReader streamReader = new StreamReader((Stream) new FileStream(_Document.Application.SharedParametersFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
    List<string> stringList = (List<string>) null;
    string upper = Enum.GetName(typeof (ParameterType), (object) ((ParameterType) 17).GetHashCode()).ToUpper();
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string str1;
    while ((str1 = streamReader.ReadLine()) != null)
    {
      Guid guid;
      if (externalDefinition1 != null)
      {
        string str2 = str1;
        guid = externalDefinition1.GUID;
        string str3 = guid.ToString();
        if (str2.IndexOf(str3) >= 0)
          goto label_20;
      }
      if (externalDefinition2 != null)
      {
        string str4 = str1;
        guid = externalDefinition2.GUID;
        string str5 = guid.ToString();
        if (str4.IndexOf(str5) < 0)
          goto label_24;
      }
      else
        goto label_24;
label_20:
      int num = str1.IndexOf(upper);
      if (num >= 0)
      {
        string str6 = str1.Substring(num + upper.Length);
        string str7 = str1.Substring(0, num + upper.Length);
        int length = str6.IndexOf("-1");
        if (length >= 0)
        {
          string str8 = str7 + str6.Substring(0, length);
          string str9 = str8;
          guid = externalDefinition1.GUID;
          string str10 = guid.ToString();
          str1 = (str9.IndexOf(str10) < 0 ? str8 + Convert.ToString(((BuiltInCategory) -2000151).GetHashCode()) : str8 + Convert.ToString(((BuiltInCategory) -2001360).GetHashCode())) + str6.Substring(length + 2);
        }
        else
          str1 = str7 + str6;
      }
label_24:
      if (stringList == null)
        stringList = new List<string>();
      stringList.Add(str1);
    }
    streamReader.Close();
    if (stringList == null)
      return;
    StreamWriter streamWriter = new StreamWriter((Stream) new FileStream(_Document.Application.SharedParametersFilename, FileMode.Create, FileAccess.Write, FileShare.ReadWrite), Encoding.ASCII);
    for (int index = 0; index < stringList.Count; ++index)
      streamWriter.WriteLine(stringList[index]);
    streamWriter.Close();
  }

  public static List<Definition> GetAllCurPlantingSharedParameters(Application _Application)
  {
    List<Definition> sharedParameters = (List<Definition>) null;
    FileInfo fileInfo = (FileInfo) null;
    if (!string.IsNullOrEmpty(_Application.SharedParametersFilename))
      fileInfo = new FileInfo(_Application.SharedParametersFilename);
    if (fileInfo != null)
    {
      if (fileInfo.Exists)
      {
        try
        {
          sharedParameters = ManagePlants.GetPlantingSharedParameterList(_Application.OpenSharedParameterFile());
        }
        catch (InvalidOperationException ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("TheFile_Message") + _Application.SharedParametersFilename + EPShared.LocalRM.GetString("_CouldNotBeReadMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return (List<Definition>) null;
        }
      }
    }
    return sharedParameters;
  }

  private static List<Definition> GetPlantingSharedParameterList(DefinitionFile _DefinitionFile)
  {
    List<string> stringList = ManagePlants.PlantSharedParamenterList();
    List<Definition> sharedParameterList = new List<Definition>();
    foreach (DefinitionGroup group in _DefinitionFile.Groups)
    {
      if (group.Definitions != null)
      {
        foreach (string str in stringList)
        {
          if (group.Definitions[str] is ExternalDefinition definition)
          {
            try
            {
              sharedParameterList.Add((Definition) definition);
            }
            catch (Exception ex)
            {
            }
          }
        }
      }
    }
    return sharedParameterList;
  }

  private static List<string> FindSharedParametersNotInList(
    DefinitionFile _DefinitionFile,
    List<string> _ParameterList)
  {
    List<string> parametersNotInList1 = (List<string>) null;
    List<string> stringList = (List<string>) null;
    foreach (DefinitionGroup group in _DefinitionFile.Groups)
    {
      if (group.Definitions != null)
      {
        List<string> _ParametersInList = new List<string>();
        List<string> parametersNotInList2 = ManagePlants.FindSharedParametersNotInList(group.Definitions, _ParameterList, ref _ParametersInList);
        if (stringList == null)
        {
          stringList = _ParametersInList;
        }
        else
        {
          for (int index = 0; index < _ParametersInList.Count; ++index)
          {
            if (!stringList.Contains(_ParametersInList[index]))
              stringList.Add(_ParametersInList[index]);
          }
        }
        if (parametersNotInList1 == null)
        {
          parametersNotInList1 = parametersNotInList2;
        }
        else
        {
          for (int index = 0; index < parametersNotInList2.Count; ++index)
          {
            if (!stringList.Contains(parametersNotInList2[index]))
            {
              if (!parametersNotInList1.Contains(parametersNotInList2[index]))
                parametersNotInList1.Add(parametersNotInList2[index]);
            }
            else if (parametersNotInList1.Contains(parametersNotInList2[index]))
              parametersNotInList1.Remove(parametersNotInList2[index]);
          }
        }
      }
    }
    return parametersNotInList1;
  }

  public static List<string> FindSharedParametersNotInList(
    Definitions Definitions,
    List<string> ParameterList)
  {
    List<string> _ParametersInList = new List<string>();
    return ManagePlants.FindSharedParametersNotInList(Definitions, ParameterList, ref _ParametersInList);
  }

  private static List<string> FindSharedParametersNotInList(
    Definitions _Definitions,
    List<string> _ParameterList,
    ref List<string> _ParametersInList)
  {
    List<string> parametersNotInList = (List<string>) null;
    if (_ParameterList != null)
    {
      for (int index = 0; index < _ParameterList.Count; ++index)
      {
        if (_Definitions == null || _Definitions[_ParameterList[index]] == null)
        {
          if (parametersNotInList == null)
            parametersNotInList = new List<string>();
          parametersNotInList.Add(_ParameterList[index]);
        }
        else
          _ParametersInList.Add(_ParameterList[index]);
      }
    }
    return parametersNotInList;
  }

  public static List<string> FilterAllLandcaddPlantingSharedParameters(
    List<string> _FindParameterList)
  {
    List<string> stringList1 = (List<string>) null;
    List<string> stringList2 = ManagePlants.PlantSharedParamenterList();
    for (int index = 0; index < _FindParameterList.Count; ++index)
    {
      if (stringList2.Contains(_FindParameterList[index]))
      {
        if (stringList1 == null)
          stringList1 = new List<string>();
        stringList1.Add(_FindParameterList[index]);
      }
    }
    return stringList1;
  }

  public static void VerifySharedParameters(Document _Document, EPTransactionContainer _Transaction)
  {
    string empty = string.Empty;
    string str = string.Empty;
    if (!string.IsNullOrEmpty(_Document.Application.SharedParametersFilename))
      str = _Document.Application.SharedParametersFilename;
    FileInfo fileInfo1 = new FileInfo(str);
    if (fileInfo1 != null && !fileInfo1.Exists && ApplicationUtility.RegistryPaths.GetSupportPath("LC Shared Parameters.txt", ref empty) == 0)
      File.Copy(empty, str);
    FileInfo fileInfo2 = new FileInfo(str);
    if (fileInfo2 != null && !fileInfo2.Exists)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("TheFile_Message") + _Document.Application.SharedParametersFilename + EPShared.LocalRM.GetString("_CouldNotBeReadMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      List<string> _FindParameterList = new List<string>();
      ManagePlants.VerifySharedParametersAreMissing(_Document.Application, ref _FindParameterList);
      if (_FindParameterList == null || _FindParameterList.Count <= 0)
        return;
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm("MissingSharedParameters", EPShared.LocalRM.GetString("MissingSharedParametersMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("YesString"),
        EPShared.LocalRM.GetString("NoString")
      });
      int num2 = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult != DialogResult.OK || string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("YesString"), true) != 0)
        return;
      DefinitionFile definitionFile = _Document.Application.OpenSharedParameterFile();
      if (definitionFile == null)
        return;
      Definitions definitions = (definitionFile.Groups[EPShared.LocalRM.GetString("PlantingDefinitionGroup")] ?? definitionFile.Groups.Create(EPShared.LocalRM.GetString("PlantingDefinitionGroup"))).Definitions;
      _Transaction.Start("GetFamilyInformationTransaction");
      ManagePlants.CreateSharedParameters(_Document, ref definitions, _FindParameterList, _Transaction);
      _Transaction.Rollback();
    }
  }

  public static void VerifySharedParametersAreMissing(
    Application _Application,
    ref List<string> _FindParameterList)
  {
    _FindParameterList = ManagePlants.PlantSharedParamenterList();
    if (_FindParameterList == null || _FindParameterList.Count <= 0)
      return;
    FileInfo fileInfo = (FileInfo) null;
    if (!string.IsNullOrEmpty(_Application.SharedParametersFilename))
      fileInfo = new FileInfo(_Application.SharedParametersFilename);
    if (fileInfo == null || !fileInfo.Exists)
      return;
    StreamReader streamReader = new StreamReader((Stream) new FileStream(_Application.SharedParametersFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
    string empty = string.Empty;
    string str;
    while ((str = streamReader.ReadLine()) != null)
    {
      for (int index = 0; index < _FindParameterList.Count; ++index)
      {
        if (str.Contains($"\t{_FindParameterList[index]}\t"))
        {
          _FindParameterList.RemoveAt(index);
          break;
        }
      }
    }
    streamReader.Close();
  }
}
