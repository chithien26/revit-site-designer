﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ElementSetConverter
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public static class ElementSetConverter
{
  public static List<ElementId> ToIDList(ElementSet elm_set)
  {
    List<ElementId> idList = new List<ElementId>();
    foreach (Element elm in elm_set)
      idList.Add(elm.Id);
    return idList;
  }

  public static List<GeometryObject> ToGeometryObjectList(IEnumerator<GeometryObject> e)
  {
    List<GeometryObject> geometryObjectList = new List<GeometryObject>();
    e.Reset();
    while (e.MoveNext())
      geometryObjectList.Add(e.Current);
    return geometryObjectList;
  }
}
