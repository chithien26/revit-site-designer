using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using SITES.Utilities;

namespace EPCommon;

public class AddModifyMix : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private DisplayUnit m_DisplayUnitSystem;

	private FormatOptions m_FormatOptions;

	private UnitSymbolType m_UnitSymbolType;

	private List<FamilyTypeContainer> m_FamilyTypeContainerList;

	private int m_nSeletedIndex = -1;

	private List<FamilyParameterTypeWrapper> m_ParameterList = new List<FamilyParameterTypeWrapper>();

	private QuantumListView m_ParameterListView = new QuantumListView();

	private DialogType m_DlgType;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Button m_ButtonOk;

	private Button m_ButtonCancel;

	public AddModifyMix(List<FamilyParameterTypeWrapper> _ParameterList, ref List<FamilyTypeContainer> _FamilyTypeContainerList, Units _Units, DisplayUnit _UnitType, FormatOptions _FormatOption, UnitSymbolType _UnitSymbolType, DecimalSymbol _DecimalSymbolType, int _nSelectedIndex, DialogType _DlgType)
	{
		InitializeComponent();
		m_ParameterList = _ParameterList;
		m_FamilyTypeContainerList = _FamilyTypeContainerList;
		m_DisplayUnitSystem = _UnitType;
		m_FormatOptions = _FormatOption;
		m_UnitSymbolType = _UnitSymbolType;
		m_DecimalSymbolType = _DecimalSymbolType;
		m_nSeletedIndex = _nSelectedIndex;
		m_DlgType = _DlgType;
		m_Units = _Units;
		InitializeData();
		GetDialogPosition();
		m_ParameterListView.OnListViewItemChanged += ParameterListViewOnListViewItemChanged;
		FormClosing += AddModifyMixFormClosing;
	}

	private void AddModifyMixFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void ParameterListViewOnListViewItemChanged(int _nChangedIndex)
	{
		double _dReturnedDouble = 0.0;
		string strB = m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
		string _strToDisplay = m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
		if (m_DlgType == DialogType.PlantMix)
		{
			if (string.Compare(EPShared.LocalRM.GetString("TypeNameGenericModelFamilyParameter"), strB, ignoreCase: true) == 0 || string.Compare(EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), strB, ignoreCase: true) == 0 || string.Compare(EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), strB, ignoreCase: true) == 0 || string.Compare(EPShared.LocalRM.GetString("PlantSizePlantMixFamilyParameter"), strB, ignoreCase: true) == 0)
			{
				return;
			}
			if (string.Compare(EPShared.LocalRM.GetString("SpacingMethodPlantMixFamilyParameter"), strB, ignoreCase: true) == 0)
			{
				if (string.Compare(_strToDisplay, EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"), ignoreCase: true) == 0)
				{
					m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text = EPShared.LocalRM.GetString("NotAvailableString");
				}
				else if (string.Compare(m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) == 0 || m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text == string.Empty)
				{
					_strToDisplay = string.Empty;
					RevitGeometry.Units_ConvertDoubleToString(1.0, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
					m_ParameterListView.Items[_nChangedIndex + 1].SubItems[1].Text = _strToDisplay;
				}
				return;
			}
			if (string.Compare(EPShared.LocalRM.GetString("CostGenericFamilyParameter"), strB, ignoreCase: true) == 0)
			{
				try
				{
					if (!RevitGeometry.StrE_GetValidRealNumber(_strToDisplay, ref _dReturnedDouble))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
					}
					else if (_dReturnedDouble >= 0.0)
					{
						m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", _dReturnedDouble);
					}
					else
					{
						m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = ValueConversion.Format("{0:f2}", 0.0);
					}
					return;
				}
				catch (Exception)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("CostGenericFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
					m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
					m_ParameterListView.SetFocus(_nChangedIndex);
					return;
				}
			}
			if (string.Compare(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), strB, ignoreCase: true) == 0)
			{
				try
				{
					if (!RevitGeometry.StrE_GetValidRealNumber(_strToDisplay, ref _dReturnedDouble) || _dReturnedDouble <= 0.0 || _dReturnedDouble > 100.0)
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = "1";
					}
					else
					{
						m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
					}
					return;
				}
				catch (Exception)
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
					m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
					m_ParameterListView.SetFocus(_nChangedIndex);
					return;
				}
			}
			if (string.Compare(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), strB, ignoreCase: true) != 0)
			{
				return;
			}
			try
			{
				_dReturnedDouble = 0.0;
				RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
				RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
				return;
			}
			catch (Exception)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
				m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
				m_ParameterListView.SetFocus(_nChangedIndex);
				return;
			}
		}
		if (string.Compare(EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), strB, ignoreCase: true) == 0)
		{
			try
			{
				_dReturnedDouble = 0.0;
				RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
				RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
				return;
			}
			catch (Exception)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
				m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
				m_ParameterListView.SetFocus(_nChangedIndex);
				return;
			}
		}
		if (string.Compare(EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), strB, ignoreCase: true) != 0)
		{
			return;
		}
		try
		{
			_dReturnedDouble = 0.0;
			RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			double num = _dReturnedDouble;
			if (num <= 3.0)
			{
				RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
				return;
			}
			RevitGeometry.Units_ConvertDoubleToString(3.0, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidEdgeWidth") + " " + _strToDisplay, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
			m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
			m_ParameterListView.SetFocus(_nChangedIndex);
		}
		catch (Exception)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
			m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
			m_ParameterListView.SetFocus(_nChangedIndex);
		}
	}

	private void InitializeData()
	{
		m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ParameterListView.View = System.Windows.Forms.View.Details;
		m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
		m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
		Controls.AddRange(new System.Windows.Forms.Control[1] { m_ParameterListView });
		m_ParameterListView.Columns[0].Width = 215;
		m_ParameterListView.Columns[1].Width = 215;
		if (m_DlgType == DialogType.PlantMix)
		{
			m_ParameterListView.CmbBox.Items.Add(EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular"));
			m_ParameterListView.CmbBox.Items.Add(EPShared.LocalRM.GetString("PlantMixSpacingMethodSquare"));
			m_ParameterListView.CmbBox.Items.Add(EPShared.LocalRM.GetString("AreaPlantMixFamilyParameter"));
		}
		else
		{
			m_ParameterListView.CmbBox.Items.Add(EPShared.LocalRM.GetString("NoString"));
			m_ParameterListView.CmbBox.Items.Add(EPShared.LocalRM.GetString("YesString"));
		}
		ListViewItem listViewItem = new ListViewItem();
		if (m_nSeletedIndex < 0)
		{
			Text = EPShared.LocalRM.GetString("AddDialog");
			FamilyTypeContainer familyTypeContainer = new FamilyTypeContainer();
			for (int i = 0; i < m_ParameterList.Count; i++)
			{
				string parameterDisplayName = m_ParameterList[i].ParameterDisplayName;
				string parameterName = m_ParameterList[i].ParameterName;
				string _strToDisplay = string.Empty;
				if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) != 0 && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) != 0 && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) != 0 && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) != 0)
				{
					if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						_strToDisplay = EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular");
					}
					else if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						double num = 1.0;
						_strToDisplay = ValueConversion.ToString(m_DecimalSymbolType, num);
					}
					else if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						_strToDisplay = "1";
					}
					else if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
					{
						_strToDisplay = EPShared.LocalRM.GetString("NoString");
					}
					else if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
					{
						RevitGeometry.Units_ConvertDoubleToString(0.0, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
					}
					listViewItem = m_ParameterListView.Items.Add(parameterName, parameterDisplayName, string.Empty);
					listViewItem.SubItems.Add(_strToDisplay);
					listViewItem.SubItems[listViewItem.SubItems.Count - 1].Text = _strToDisplay;
				}
			}
		}
		else
		{
			Text = EPShared.LocalRM.GetString("ModifyDialog");
			for (int j = 0; j < m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList.Count; j++)
			{
				string parameterDisplayName = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].DisplayName;
				string parameterName = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName;
				string _strToDisplay = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].Value;
				if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
				{
					continue;
				}
				if (m_DlgType == DialogType.PlantMix)
				{
					if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						double dConvertedDouble = 1.0;
						if (parameterName != string.Empty && _strToDisplay != null)
						{
							dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
						}
						RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
					}
					else if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						_strToDisplay = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].Value;
						if (_strToDisplay == string.Empty || _strToDisplay == null)
						{
							_strToDisplay = EPShared.LocalRM.GetString("PlantMixSpacingMethodTriangular");
						}
					}
					else if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						if (_strToDisplay == null)
						{
							_strToDisplay = "1.0";
						}
						else if (_strToDisplay != null && _strToDisplay == string.Empty)
						{
							_strToDisplay = "1.0";
						}
					}
				}
				else if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
				{
					double dConvertedDouble2 = 1.0;
					if (parameterName != string.Empty && _strToDisplay != null && _strToDisplay != string.Empty)
					{
						dConvertedDouble2 = ValueConversion.ToDouble(_strToDisplay);
					}
					RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble2, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				}
				else if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
				{
					_strToDisplay = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].Value;
					if (_strToDisplay == string.Empty || _strToDisplay == null)
					{
						_strToDisplay = EPShared.LocalRM.GetString("NoString");
					}
					else if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].Value, "0", ignoreCase: true) == 0)
					{
						_strToDisplay = EPShared.LocalRM.GetString("NoString");
					}
					else if (string.Compare(m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[j].Value, "1", ignoreCase: true) == 0)
					{
						_strToDisplay = EPShared.LocalRM.GetString("YesString");
					}
				}
				listViewItem = m_ParameterListView.Items.Add(parameterName, parameterDisplayName, string.Empty);
				if (_strToDisplay == null)
				{
					_strToDisplay = string.Empty;
				}
				listViewItem.SubItems.Add(_strToDisplay);
				listViewItem.SubItems[listViewItem.SubItems.Count - 1].Text = _strToDisplay;
			}
		}
		if (m_DlgType == DialogType.PlantMix)
		{
			Text = Text + " " + EPShared.LocalRM.GetString("PlantMixDialog");
		}
		else
		{
			Text = Text + " " + EPShared.LocalRM.GetString("PathWalkDialog");
		}
	}

	private void OnButtonOkClicked(object sender, EventArgs e)
	{
		bool flag = false;
		bool flag2 = false;
		bool flag3 = false;
		bool flag4 = false;
		string strFamilyTypeName = string.Empty;
		string empty = string.Empty;
		string empty2 = string.Empty;
		string text = string.Empty;
		string text2 = string.Empty;
		if (m_DlgType == DialogType.PlantMix)
		{
			for (int i = 0; i < m_ParameterListView.Items.Count; i++)
			{
				empty = m_ParameterListView.Items[i].SubItems[0].Text;
				empty2 = m_ParameterListView.Items[i].SubItems[1].Text;
				if (string.Compare(empty, EPShared.LocalRM.GetString("ScientificNamePlantMixFamilyParameter"), ignoreCase: true) == 0)
				{
					if (!string.IsNullOrEmpty(empty2))
					{
						flag = true;
						text2 = empty2;
						if (flag2)
						{
							break;
						}
					}
				}
				else if (string.Compare(empty, EPShared.LocalRM.GetString("CommonNamePlantMixFamilyParameter"), ignoreCase: true) == 0 && !string.IsNullOrEmpty(empty2))
				{
					flag2 = true;
					text = empty2;
					if (flag)
					{
						break;
					}
				}
			}
			if (!flag && !flag2)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeCommonOrScientificName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			for (int j = 0; j < m_ParameterListView.Items.Count; j++)
			{
				empty = m_ParameterListView.Items[j].SubItems[0].Text;
				empty2 = m_ParameterListView.Items[j].SubItems[1].Text;
				if (string.Compare(empty, EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), ignoreCase: true) == 0)
				{
					if (empty2 != string.Empty)
					{
						flag3 = true;
					}
				}
				else if (string.Compare(empty, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), ignoreCase: true) == 0 && empty2 != string.Empty)
				{
					flag4 = true;
				}
			}
			if (!flag3 && !flag4)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter") + " " + EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter") + EPShared.LocalRM.GetString("_And_") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (!flag3)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (!flag4)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter") + EPShared.LocalRM.GetString("ValidFields"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (m_nSeletedIndex < 0)
			{
				FamilyTypeContainer familyTypeContainer = new FamilyTypeContainer();
				familyTypeContainer.FamilyParameterList = new List<FamilyParameterWrapper>();
				string text3 = string.Empty;
				string empty3 = string.Empty;
				string empty4 = string.Empty;
				if ((flag2 || flag) && text3 == string.Empty)
				{
					if (flag2 && flag)
					{
						text3 = text + "/" + text2;
					}
					else if (flag2)
					{
						text3 = text;
					}
					else if (flag)
					{
						text3 = text2;
					}
					if (familyTypeContainer.FamilyTypeWrapper == null)
					{
						familyTypeContainer.FamilyTypeWrapper = new FamilyTypeWrapper(text3);
					}
					else
					{
						familyTypeContainer.FamilyTypeWrapper.FamilyTypeName = text3;
					}
				}
				for (int k = 0; k < m_ParameterListView.Items.Count; k++)
				{
					StorageType storageType = StorageType.String;
					empty4 = m_ParameterListView.Items[k].SubItems[0].Name;
					empty3 = m_ParameterListView.Items[k].SubItems[0].Text;
					text3 = m_ParameterListView.Items[k].SubItems[1].Text;
					if (string.Compare(empty3, EPShared.LocalRM.GetString("PercentagePlantMixFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty3, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), ignoreCase: true) == 0)
					{
						string text4 = m_ParameterListView.Items[k].SubItems[1].Text;
						if (string.Compare(text4, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) == 0)
						{
							text4 = "0.0";
						}
						storageType = StorageType.Double;
						if (string.Compare(empty3, EPShared.LocalRM.GetString("PlantSpacingPlantMixFamilyParameter"), ignoreCase: true) == 0)
						{
							double _dReturnedDouble = 0.0;
							RevitGeometry.Units_ConvertStringToDouble(text4, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
							text3 = ValueConversion.ToString(m_DecimalSymbolType, _dReturnedDouble);
						}
						else
						{
							text3 = text4;
						}
					}
					else if (string.Compare(empty3, EPShared.LocalRM.GetString("CostGenericFamilyParameter"), ignoreCase: true) == 0)
					{
						storageType = StorageType.Double;
						text3 = m_ParameterListView.Items[k].SubItems[1].Text;
					}
					if (string.Compare(empty3, EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty3, EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty3, EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty3, EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), ignoreCase: true) == 0)
					{
						text3 = string.Empty;
					}
					FamilyParameterWrapper item = new FamilyParameterWrapper(empty3, empty4, text3, storageType);
					familyTypeContainer.FamilyParameterList.Add(item);
				}
				if (!FindParameter(RevitParameters.RegionNameGenericModelFamilyParameter, familyTypeContainer))
				{
					FamilyParameterWrapper item2 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", StorageType.String);
					familyTypeContainer.FamilyParameterList.Add(item2);
				}
				if (!FindParameter(RevitParameters.UniqueIDGenericModelFamilyParameter, familyTypeContainer))
				{
					FamilyParameterWrapper item3 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", StorageType.String);
					familyTypeContainer.FamilyParameterList.Add(item3);
				}
				if (!FindParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter, familyTypeContainer))
				{
					FamilyParameterWrapper item4 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, "", StorageType.String);
					familyTypeContainer.FamilyParameterList.Add(item4);
				}
				if (!FindParameter(RevitParameters.AssemblyCodeGenericFamilyParameter, familyTypeContainer))
				{
					FamilyParameterWrapper item5 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), RevitParameters.AssemblyCodeGenericFamilyParameter, "", StorageType.String);
					familyTypeContainer.FamilyParameterList.Add(item5);
				}
				m_FamilyTypeContainerList.Add(familyTypeContainer);
			}
			else
			{
				string text5 = string.Empty;
				if ((flag2 || flag) && text5 == string.Empty)
				{
					if (flag2 && flag)
					{
						text5 = text + "/" + text2;
					}
					else if (flag2)
					{
						text5 = text;
					}
					else if (flag)
					{
						text5 = text2;
					}
					m_FamilyTypeContainerList[m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName = text5;
				}
				for (int l = 0; l < m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList.Count; l++)
				{
					string displayName = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[l].DisplayName;
					string parameterName = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[l].ParameterName;
					if (string.Compare(parameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
					{
						string empty5 = string.Empty;
						m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[l].Value = empty5;
						continue;
					}
					for (int m = 0; m < m_ParameterListView.Items.Count; m++)
					{
						if (string.Compare(displayName, m_ParameterListView.Items[m].SubItems[0].Text, ignoreCase: true) != 0)
						{
							continue;
						}
						string empty5 = m_ParameterListView.Items[m].SubItems[1].Text;
						if (string.Compare(parameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
						{
							double _dReturnedDouble2 = 0.0;
							if (empty5 != null && empty5 != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), empty5, ignoreCase: true) == 0)
							{
								_dReturnedDouble2 = 0.0;
							}
							else if (empty5 != null && empty5 != string.Empty)
							{
								RevitGeometry.Units_ConvertStringToDouble(empty5, m_Units, UnitType.UT_Length, ref _dReturnedDouble2);
							}
							empty5 = ValueConversion.ToString(m_DecimalSymbolType, _dReturnedDouble2);
						}
						if (empty5 == null)
						{
							empty5 = string.Empty;
						}
						m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[l].Value = empty5;
						break;
					}
				}
			}
		}
		else
		{
			bool flag5 = false;
			if (m_nSeletedIndex < 0)
			{
				flag5 = IsDuplicateEdiging();
			}
			bool flag6 = false;
			bool flag7 = false;
			bool flag8 = false;
			bool flag9 = false;
			int index = -1;
			for (int n = 0; n < m_ParameterListView.Items.Count; n++)
			{
				empty = m_ParameterListView.Items[n].SubItems[0].Text;
				empty2 = m_ParameterListView.Items[n].SubItems[1].Text;
				if (string.Compare(empty, EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), ignoreCase: true) == 0)
				{
					if (empty2 != string.Empty)
					{
						strFamilyTypeName = empty2;
						flag9 = true;
					}
				}
				else if (string.Compare(empty, EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), ignoreCase: true) == 0)
				{
					if (empty2 != string.Empty && string.Compare(empty2, EPShared.LocalRM.GetString("YesString"), ignoreCase: true) == 0)
					{
						flag6 = true;
					}
				}
				else if (string.Compare(empty, EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), ignoreCase: true) == 0)
				{
					if (empty2 != string.Empty && string.Compare(empty2, EPShared.LocalRM.GetString("YesString"), ignoreCase: true) == 0)
					{
						flag7 = true;
					}
				}
				else
				{
					if (string.Compare(empty, EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), ignoreCase: true) != 0 || !(empty2 != string.Empty))
					{
						continue;
					}
					try
					{
						double _dReturnedDouble3 = 0.0;
						if (RevitGeometry.Units_ConvertStringToDouble(empty2, m_Units, UnitType.UT_Length, ref _dReturnedDouble3) && _dReturnedDouble3 > 0.0)
						{
							empty2 = ValueConversion.ToString(m_DecimalSymbolType, _dReturnedDouble3);
							flag8 = true;
						}
						index = n;
					}
					catch (Exception)
					{
						flag8 = false;
						index = n;
					}
				}
			}
			if (!flag9)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidTypeName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (flag6 && flag7 && !flag8)
			{
				string _strToDisplay = string.Empty;
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidEdgeWidth"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				RevitGeometry.Units_ConvertDoubleToString(0.0, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_ParameterListView.Items[index].SubItems[1].Text = _strToDisplay;
				return;
			}
			if (!flag6 && !flag7 && flag8)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedEdgeMowingYes"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (!flag6 && flag7)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NoEdgingYesMowingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (flag6 && !flag7 && flag8)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedEdgeMowingYes"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (!flag6 && flag7 && flag8)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NoEdgingYesMowingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (flag6 && flag5)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateEdgeString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return;
			}
			if (m_nSeletedIndex < 0)
			{
				FamilyTypeContainer familyTypeContainer2 = new FamilyTypeContainer();
				familyTypeContainer2.FamilyParameterList = new List<FamilyParameterWrapper>();
				string empty6 = string.Empty;
				string empty7 = string.Empty;
				string empty8 = string.Empty;
				for (int num = 0; num < m_ParameterListView.Items.Count; num++)
				{
					StorageType storageType2 = StorageType.String;
					empty8 = m_ParameterListView.Items[num].SubItems[0].Name;
					empty7 = m_ParameterListView.Items[num].SubItems[0].Text;
					empty6 = m_ParameterListView.Items[num].SubItems[1].Text;
					if (string.Compare(empty7, EPShared.LocalRM.GetString("MaterialPathWalkFamilyParameter"), ignoreCase: true) == 0)
					{
						familyTypeContainer2.FamilyTypeWrapper = new FamilyTypeWrapper(strFamilyTypeName);
					}
					else if (string.Compare(empty7, EPShared.LocalRM.GetString("ThicknessPathWalkFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty7, EPShared.LocalRM.GetString("EdgeWidthPathWalkFamilyParameter"), ignoreCase: true) == 0)
					{
						storageType2 = StorageType.Double;
						double _dReturnedDouble4 = 0.0;
						if (empty6 != null && empty6 != string.Empty)
						{
							RevitGeometry.Units_ConvertStringToDouble(empty6, m_Units, UnitType.UT_Length, ref _dReturnedDouble4);
						}
						empty6 = ValueConversion.ToString(m_DecimalSymbolType, _dReturnedDouble4);
					}
					else if (string.Compare(empty7, EPShared.LocalRM.GetString("EdgePathWalkFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty7, EPShared.LocalRM.GetString("MowingStripPathWalkFamilyParameter"), ignoreCase: true) == 0)
					{
						storageType2 = StorageType.Integer;
						if (string.Compare(empty6, EPShared.LocalRM.GetString("YesString"), ignoreCase: true) == 0)
						{
							empty6 = "1";
						}
						else if (string.Compare(empty6, EPShared.LocalRM.GetString("NoString"), ignoreCase: true) == 0)
						{
							empty6 = "0";
						}
					}
					if (string.Compare(empty7, EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty7, EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty7, EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), ignoreCase: true) == 0 || string.Compare(empty7, EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), ignoreCase: true) == 0)
					{
						empty6 = string.Empty;
					}
					FamilyParameterWrapper item6 = new FamilyParameterWrapper(empty7, empty8, empty6, storageType2);
					familyTypeContainer2.FamilyParameterList.Add(item6);
				}
				if (!FindParameter(RevitParameters.RegionNameGenericModelFamilyParameter, familyTypeContainer2))
				{
					FamilyParameterWrapper item7 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("RegionNameGenericModelFamilyParameter"), RevitParameters.RegionNameGenericModelFamilyParameter, "", StorageType.String);
					familyTypeContainer2.FamilyParameterList.Add(item7);
				}
				if (!FindParameter(RevitParameters.UniqueIDGenericModelFamilyParameter, familyTypeContainer2))
				{
					FamilyParameterWrapper item8 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("UniqueIDGenericModelFamilyParameter"), RevitParameters.UniqueIDGenericModelFamilyParameter, "", StorageType.String);
					familyTypeContainer2.FamilyParameterList.Add(item8);
				}
				if (!FindParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter, familyTypeContainer2))
				{
					FamilyParameterWrapper item9 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("LandcaddIDGenericModelFamilyParameter"), RevitParameters.LandcaddIDGenericModelFamilyParameter, "", StorageType.String);
					familyTypeContainer2.FamilyParameterList.Add(item9);
				}
				if (!FindParameter(RevitParameters.AssemblyCodeGenericFamilyParameter, familyTypeContainer2))
				{
					FamilyParameterWrapper item10 = new FamilyParameterWrapper(EPShared.LocalRM.GetString("AssemblyCodeGenericFamilyParameter"), RevitParameters.AssemblyCodeGenericFamilyParameter, "", StorageType.String);
					familyTypeContainer2.FamilyParameterList.Add(item10);
				}
				m_FamilyTypeContainerList.Add(familyTypeContainer2);
			}
			else
			{
				for (int num2 = 0; num2 < m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList.Count; num2++)
				{
					string displayName2 = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[num2].DisplayName;
					string parameterName2 = m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[num2].ParameterName;
					for (int num3 = 0; num3 < m_ParameterListView.Items.Count; num3++)
					{
						if (string.Compare(displayName2, m_ParameterListView.Items[num3].SubItems[0].Text, ignoreCase: true) != 0)
						{
							continue;
						}
						string text6 = m_ParameterListView.Items[num3].SubItems[1].Text;
						if (string.Compare(parameterName2, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0)
						{
							text6 = string.Empty;
							m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[num2].Value = text6;
							continue;
						}
						if (string.Compare(parameterName2, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName2, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
						{
							double _dReturnedDouble5 = 1.0;
							if (text6 != null && text6 != string.Empty)
							{
								RevitGeometry.Units_ConvertStringToDouble(text6, m_Units, UnitType.UT_Length, ref _dReturnedDouble5);
							}
							text6 = ValueConversion.ToString(m_DecimalSymbolType, _dReturnedDouble5);
						}
						if (string.Compare(parameterName2, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(parameterName2, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
						{
							if (string.Compare(text6, EPShared.LocalRM.GetString("YesString"), ignoreCase: true) == 0)
							{
								text6 = "1";
							}
							else if (string.Compare(text6, EPShared.LocalRM.GetString("NoString"), ignoreCase: true) == 0)
							{
								text6 = "0";
							}
						}
						if (text6 == null)
						{
							text6 = string.Empty;
						}
						if (string.Compare(parameterName2, RevitParameters.MaterialPathWalkFamilyParameter, ignoreCase: true) == 0 && text6 != string.Empty)
						{
							m_FamilyTypeContainerList[m_nSeletedIndex].FamilyTypeWrapper.FamilyTypeName = text6;
						}
						m_FamilyTypeContainerList[m_nSeletedIndex].FamilyParameterList[num2].Value = text6;
						break;
					}
				}
			}
		}
		DialogResult = DialogResult.OK;
	}

	private bool IsDuplicateEdiging()
	{
		for (int i = 0; i < m_FamilyTypeContainerList.Count; i++)
		{
			int count = m_FamilyTypeContainerList[i].FamilyParameterList.Count;
			for (int j = 0; j < count; j++)
			{
				if (string.Compare(m_FamilyTypeContainerList[i].FamilyParameterList[j].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 && string.Compare(m_FamilyTypeContainerList[i].FamilyParameterList[j].Value, "1", ignoreCase: true) == 0)
				{
					return true;
				}
			}
		}
		return false;
	}

	private void OnButtonCancelClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	private bool FindParameter(string _strValue, FamilyTypeContainer _Container)
	{
		string empty = string.Empty;
		for (int i = 0; i < _Container.FamilyParameterList.Count; i++)
		{
			empty = _Container.FamilyParameterList[i].ParameterName;
			if (string.Compare(empty, _strValue, ignoreCase: true) == 0)
			{
				return true;
			}
		}
		return false;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ButtonOk = new System.Windows.Forms.Button();
		this.m_ButtonCancel = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.m_ButtonOk.Location = new System.Drawing.Point(298, 303);
		this.m_ButtonOk.Name = "m_ButtonOk";
		this.m_ButtonOk.Size = new System.Drawing.Size(75, 23);
		this.m_ButtonOk.TabIndex = 0;
		this.m_ButtonOk.Text = "&OK";
		this.m_ButtonOk.UseVisualStyleBackColor = true;
		this.m_ButtonOk.Click += new System.EventHandler(this.OnButtonOkClicked);
		this.m_ButtonCancel.Location = new System.Drawing.Point(379, 303);
		this.m_ButtonCancel.Name = "m_ButtonCancel";
		this.m_ButtonCancel.Size = new System.Drawing.Size(75, 23);
		this.m_ButtonCancel.TabIndex = 1;
		this.m_ButtonCancel.Text = "&Cancel";
		this.m_ButtonCancel.UseVisualStyleBackColor = true;
		this.m_ButtonCancel.Click += new System.EventHandler(this.OnButtonCancelClicked);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(456, 332);
		base.Controls.Add(this.m_ButtonCancel);
		base.Controls.Add(this.m_ButtonOk);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		base.Name = "AddModifyMix";
		this.Text = "AddModifyMix";
		base.ResumeLayout(false);
		base.AcceptButton = this.m_ButtonOk;
		base.CancelButton = this.m_ButtonCancel;
	}
}
