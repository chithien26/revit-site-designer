﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_Line
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class Eps_Line : BaseLine
{
  private bool m_bIsReverse;

  public Eps_Line()
  {
  }

  public Eps_Line(Line _Line)
    : base(_Line)
  {
  }

  public Eps_Line(Eps_Line _Line)
    : base((BaseLine) _Line)
  {
  }

  public Eps_Line(BaseLine _Line)
    : base(_Line)
  {
  }

  public Eps_Line Reverse()
  {
    Eps_Line epsLine = new Eps_Line();
    epsLine.StartPnt = this.EndPnt;
    epsLine.EndPnt = this.StartPnt;
    epsLine.IsReverse = !this.m_bIsReverse;
    return epsLine;
  }

  public Line RevitLine(UIDocument _CurDocument) => this.RevitLine(_CurDocument.Document);

  public Line RevitLine(Document _CurDocument)
  {
    return RevitUtility.CreateLine(this.StartPnt.XYZ, this.EndPnt.XYZ, true);
  }

  public bool IsReverse
  {
    get => this.m_bIsReverse;
    set => this.m_bIsReverse = value;
  }
}
