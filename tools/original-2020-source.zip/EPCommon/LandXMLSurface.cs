﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandXMLSurface
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class LandXMLSurface
{
  private string m_strSurfaceName = string.Empty;
  private string m_strSurfaceDesc = string.Empty;
  private string m_str2DSurfaceArea = string.Empty;
  private string m_str3DSurfaceArea = string.Empty;
  private string m_strElevationMax = string.Empty;
  private string m_strElevationMin = string.Empty;
  private string m_strAreaUnit = string.Empty;
  private string m_strLinearUnit = string.Empty;
  private string m_strVolumeUnit = string.Empty;
  private string m_strSurfacePhase = string.Empty;
  private string m_strXMLSurfaceName = string.Empty;
  private string m_strOverwriteSurfaceID = string.Empty;
  private List<Eps_Point> m_SurfacePoints;
  private int m_nSurfacePointCount;
  private Phase m_Phase;

  public LandXMLSurface() => this.m_SurfacePoints = (List<Eps_Point>) null;

  public string SurfaceName
  {
    get => this.m_strSurfaceName;
    set => this.m_strSurfaceName = value;
  }

  public List<Eps_Point> SurfacePoints
  {
    get => this.m_SurfacePoints;
    set => this.m_SurfacePoints = value;
  }

  public string SurfaceDescription
  {
    get => this.m_strSurfaceDesc;
    set => this.m_strSurfaceDesc = value;
  }

  public string SurfaceArea2D
  {
    get => this.m_str2DSurfaceArea;
    set => this.m_str2DSurfaceArea = value;
  }

  public string SurfaceArea3D
  {
    get => this.m_str3DSurfaceArea;
    set => this.m_str3DSurfaceArea = value;
  }

  public string MaxElevation
  {
    get => this.m_strElevationMax;
    set => this.m_strElevationMax = value;
  }

  public string MinElevation
  {
    get => this.m_strElevationMin;
    set => this.m_strElevationMin = value;
  }

  public string AreaUnit
  {
    get => this.m_strAreaUnit;
    set => this.m_strAreaUnit = value;
  }

  public string LinearUnit
  {
    get => this.m_strLinearUnit;
    set => this.m_strLinearUnit = value;
  }

  public string VolumeUnit
  {
    get => this.m_strVolumeUnit;
    set => this.m_strVolumeUnit = value;
  }

  public string SurfacePhase
  {
    get => this.m_strSurfacePhase;
    set => this.m_strSurfacePhase = value;
  }

  public string OverwriteSurfaceID
  {
    get => this.m_strOverwriteSurfaceID;
    set => this.m_strOverwriteSurfaceID = value;
  }

  public int SurfacePointCount
  {
    get => this.m_nSurfacePointCount;
    set => this.m_nSurfacePointCount = value;
  }

  public string XMLSurfaceName
  {
    get => this.m_strXMLSurfaceName;
    set => this.m_strXMLSurfaceName = value;
  }

  public Phase Phase
  {
    get => this.m_Phase;
    set => this.m_Phase = value;
  }
}
