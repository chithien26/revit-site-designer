using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace EPCommon;

public class ConvertPlantForm : EPForm
{
	private ConvertPlant m_dataBuffer;

	private Autodesk.Revit.DB.View m_CurView;

	private FamilySymbol m_CurType;

	private IContainer components;

	private Button m_SearchButton;

	private ComboBox m_PlantNameComboBox;

	private Label m_PlantNameLabel;

	private ComboBox m_PlantFamilyComboBox;

	private Label m_PlantFamilyLabel;

	private GroupBox m_SelectionMethodsGroupBox;

	private RadioButton m_AllCirclesRadioButton;

	private RadioButton m_WindowSelectRadioButton;

	private RadioButton m_SelectionSetRadioButton;

	private GroupBox m_PlaceTagGroupBox;

	private CheckBox m_LeaderedTagCheckBox;

	private CheckBox m_CreatePlantGroupTagCheckBox;

	private CheckBox m_DeleteExistingCheckBox;

	private Button m_InsertButton;

	private Button m_CancelButton;

	private ComboBox m_LevelComboBox;

	private Label m_LevelLabel;

	private Button m_LoadFamilyButton;

	public bool SelectionSetChecked => m_SelectionSetRadioButton.Checked;

	public bool WindowSelectChecked => m_WindowSelectRadioButton.Checked;

	public bool AllCirclesChecked => m_AllCirclesRadioButton.Checked;

	public bool DeleteExistingChecked => m_DeleteExistingCheckBox.Checked;

	public bool PlaceGroupTagChecked => m_CreatePlantGroupTagCheckBox.Checked;

	public bool LeaderedTagChecked => m_LeaderedTagCheckBox.Checked;

	public Level Level => m_CurView.GenLevel;

	public Autodesk.Revit.DB.View View => m_CurView;

	public FamilySymbol Type => m_CurType;

	public ConvertPlantForm(ConvertPlant _dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("ConvertPlantsDialog");
		m_PlantFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_PlantFamilyDialog");
		m_PlantNameLabel.Text = EPShared.LocalRM.GetString("P_AMP_lantNameDialog");
		m_SearchButton.Text = EPShared.LocalRM.GetString("Sea_AMP_rchDialog");
		m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
		m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
		m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
		m_AllCirclesRadioButton.Text = EPShared.LocalRM.GetString("AMP_AllCirclesDialog");
		m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
		m_PlaceTagGroupBox.Text = EPShared.LocalRM.GetString("PlaceTagDialog");
		m_CreatePlantGroupTagCheckBox.Text = EPShared.LocalRM.GetString("CreatePlant_AMP_GroupTagDialog");
		m_LeaderedTagCheckBox.Text = EPShared.LocalRM.GetString("Lea_AMP_deredTagDialog");
		m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
		m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		EPToolTip.SetToolTip(m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		m_dataBuffer = _dataBuffer;
		InitializeControls();
		ManagePlants.VerifySharedParameters(m_dataBuffer.Document, m_dataBuffer.TransactionContainer);
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		m_SelectionSetRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsSelectMethodOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_SelectionSetRadioButton.Checked = true;
				break;
			case 1:
				m_WindowSelectRadioButton.Checked = true;
				break;
			default:
				m_AllCirclesRadioButton.Checked = true;
				break;
			}
		}
		m_CreatePlantGroupTagCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsCreatePlantGroupTag", ref _nReturnValue))
		{
			m_CreatePlantGroupTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_LeaderedTagCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsCreateLeaderedTag", ref _nReturnValue))
		{
			m_LeaderedTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_DeleteExistingCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsDeleteExisting", ref _nReturnValue))
		{
			m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_PlantFamilyComboBox.DataSource = m_dataBuffer.PlantFamilyList;
		m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ConvertPlantsFamilyName", ref _strReturnValue))
		{
			FamilyContainer familyContainer = null;
			for (int i = 0; i < m_PlantFamilyComboBox.Items.Count; i++)
			{
				if (m_PlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strReturnValue, ignoreCase: true) == 0)
				{
					m_PlantFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ConvertPlantsPlantName", ref _strReturnValue))
		{
			FamilySymbol familySymbol = null;
			for (int j = 0; j < m_PlantNameComboBox.Items.Count; j++)
			{
				if (m_PlantNameComboBox.Items[j] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strReturnValue, ignoreCase: true) == 0)
				{
					m_PlantNameComboBox.SelectedIndex = j;
					break;
				}
			}
		}
		m_LevelComboBox.DataSource = m_dataBuffer.Views;
		m_LevelComboBox.DisplayMember = EPShared.LocalRM.GetString("ViewNameString");
		if (!ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "ConvertPlantsViewName", ref _strReturnValue))
		{
			return;
		}
		Autodesk.Revit.DB.View view = null;
		for (int k = 0; k < m_LevelComboBox.Items.Count; k++)
		{
			if (m_LevelComboBox.Items[k] is Autodesk.Revit.DB.View view2 && string.Compare(view2.Name, _strReturnValue, ignoreCase: true) == 0)
			{
				m_LevelComboBox.SelectedIndex = k;
				break;
			}
		}
	}

	private void OnPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_PlantNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnSearchButtonClick(object sender, EventArgs e)
	{
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			List<FamilySymbol> _SearchSymbolList = new List<FamilySymbol>();
			if (ManagePlants.FindFamilySymbols(EPShared.LocalRM.GetString("ConvertPlantSearchTitle"), m_dataBuffer.Document, m_dataBuffer.TransactionContainer, familyContainer.FamilySymbolList, ref _SearchSymbolList))
			{
				m_PlantNameComboBox.DataSource = _SearchSymbolList;
				m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
			}
		}
	}

	private void OnCreatePlantGroupCheckBoxChecked(object sender, EventArgs e)
	{
		m_LeaderedTagCheckBox.Enabled = m_CreatePlantGroupTagCheckBox.Checked;
	}

	private void OnInsertButtonClick(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void SaveSettings()
	{
		m_CurView = m_LevelComboBox.SelectedItem as Autodesk.Revit.DB.View;
		if (m_CurView == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		m_CurType = m_PlantNameComboBox.SelectedItem as FamilySymbol;
		if (m_CurType == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Revit"), MessageBoxIcon.Hand);
			return;
		}
		int num = 0;
		num = ((!m_SelectionSetRadioButton.Checked) ? (m_WindowSelectRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsSelectMethodOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsCreatePlantGroupTag", Convert.ToInt32(m_CreatePlantGroupTagCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsCreateLeaderedTag", Convert.ToInt32(m_LeaderedTagCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsDeleteExisting", Convert.ToInt32(m_DeleteExistingCheckBox.Checked));
		if (m_PlantFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ConvertPlantsFamilyName", familyContainer.FamilyName);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ConvertPlantsPlantName", m_CurType.Name);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "ConvertPlantsViewName", m_CurView.Name);
	}

	private void OnConvertPlantFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnLoadFamilyButtonClick(object sender, EventArgs e)
	{
		int count = m_PlantFamilyComboBox.Items.Count;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		FamilyContainer familyContainer = null;
		Family _Family = null;
		openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectPlantingFamilyFileMessage");
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				try
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + openFileDialog.SafeFileName);
					EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
					flag = RevitUtility.LoadFamily(m_dataBuffer.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
					m_dataBuffer.TransactionContainer = _TransactionContainer;
					m_dataBuffer.TransactionContainer.Commit();
				}
				catch (SEHException)
				{
					m_dataBuffer.TransactionContainer.Rollback();
					flag = false;
					RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					continue;
				}
				break;
			}
		}
		if (!flag)
		{
			if (count == 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_dataBuffer.PopulateFamilyAndSymbolLists();
		m_PlantFamilyComboBox.DataSource = m_dataBuffer.PlantFamilyList;
		m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (_Family != null)
		{
			for (int i = 0; i < m_PlantFamilyComboBox.Items.Count; i++)
			{
				if (m_PlantFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _Family.Name, ignoreCase: true) == 0)
				{
					m_PlantFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (m_PlantFamilyComboBox.Items.Count == count)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_SearchButton = new System.Windows.Forms.Button();
		this.m_PlantNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_PlantNameLabel = new System.Windows.Forms.Label();
		this.m_PlantFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_PlantFamilyLabel = new System.Windows.Forms.Label();
		this.m_SelectionMethodsGroupBox = new System.Windows.Forms.GroupBox();
		this.m_AllCirclesRadioButton = new System.Windows.Forms.RadioButton();
		this.m_WindowSelectRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SelectionSetRadioButton = new System.Windows.Forms.RadioButton();
		this.m_PlaceTagGroupBox = new System.Windows.Forms.GroupBox();
		this.m_LeaderedTagCheckBox = new System.Windows.Forms.CheckBox();
		this.m_CreatePlantGroupTagCheckBox = new System.Windows.Forms.CheckBox();
		this.m_DeleteExistingCheckBox = new System.Windows.Forms.CheckBox();
		this.m_InsertButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_LevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelLabel = new System.Windows.Forms.Label();
		this.m_LoadFamilyButton = new System.Windows.Forms.Button();
		this.m_SelectionMethodsGroupBox.SuspendLayout();
		this.m_PlaceTagGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_SearchButton.Location = new System.Drawing.Point(335, 37);
		this.m_SearchButton.Name = "m_SearchButton";
		this.m_SearchButton.Size = new System.Drawing.Size(75, 23);
		this.m_SearchButton.TabIndex = 5;
		this.m_SearchButton.Text = "Sea&rch";
		this.m_SearchButton.UseVisualStyleBackColor = true;
		this.m_SearchButton.Click += new System.EventHandler(this.OnSearchButtonClick);
		this.m_PlantNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantNameComboBox.FormattingEnabled = true;
		this.m_PlantNameComboBox.Location = new System.Drawing.Point(115, 39);
		this.m_PlantNameComboBox.Name = "m_PlantNameComboBox";
		this.m_PlantNameComboBox.Size = new System.Drawing.Size(214, 21);
		this.m_PlantNameComboBox.TabIndex = 4;
		this.m_PlantNameLabel.AutoSize = true;
		this.m_PlantNameLabel.Location = new System.Drawing.Point(12, 43);
		this.m_PlantNameLabel.Name = "m_PlantNameLabel";
		this.m_PlantNameLabel.Size = new System.Drawing.Size(65, 13);
		this.m_PlantNameLabel.TabIndex = 3;
		this.m_PlantNameLabel.Text = "P&lant Name:";
		this.m_PlantFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_PlantFamilyComboBox.FormattingEnabled = true;
		this.m_PlantFamilyComboBox.Location = new System.Drawing.Point(115, 12);
		this.m_PlantFamilyComboBox.Name = "m_PlantFamilyComboBox";
		this.m_PlantFamilyComboBox.Size = new System.Drawing.Size(214, 21);
		this.m_PlantFamilyComboBox.TabIndex = 1;
		this.m_PlantFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnPlantFamilyComboBoxSelectedIndexChanged);
		this.m_PlantFamilyLabel.AutoSize = true;
		this.m_PlantFamilyLabel.Location = new System.Drawing.Point(12, 15);
		this.m_PlantFamilyLabel.Name = "m_PlantFamilyLabel";
		this.m_PlantFamilyLabel.Size = new System.Drawing.Size(66, 13);
		this.m_PlantFamilyLabel.TabIndex = 0;
		this.m_PlantFamilyLabel.Text = "&Plant Family:";
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_AllCirclesRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_WindowSelectRadioButton);
		this.m_SelectionMethodsGroupBox.Controls.Add(this.m_SelectionSetRadioButton);
		this.m_SelectionMethodsGroupBox.Location = new System.Drawing.Point(12, 66);
		this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
		this.m_SelectionMethodsGroupBox.Size = new System.Drawing.Size(398, 43);
		this.m_SelectionMethodsGroupBox.TabIndex = 6;
		this.m_SelectionMethodsGroupBox.TabStop = false;
		this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
		this.m_AllCirclesRadioButton.AutoSize = true;
		this.m_AllCirclesRadioButton.Location = new System.Drawing.Point(286, 19);
		this.m_AllCirclesRadioButton.Name = "m_AllCirclesRadioButton";
		this.m_AllCirclesRadioButton.Size = new System.Drawing.Size(70, 17);
		this.m_AllCirclesRadioButton.TabIndex = 2;
		this.m_AllCirclesRadioButton.TabStop = true;
		this.m_AllCirclesRadioButton.Text = "&All Circles";
		this.m_AllCirclesRadioButton.UseVisualStyleBackColor = true;
		this.m_WindowSelectRadioButton.AutoSize = true;
		this.m_WindowSelectRadioButton.Location = new System.Drawing.Point(144, 19);
		this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
		this.m_WindowSelectRadioButton.Size = new System.Drawing.Size(97, 17);
		this.m_WindowSelectRadioButton.TabIndex = 1;
		this.m_WindowSelectRadioButton.TabStop = true;
		this.m_WindowSelectRadioButton.Text = "&Window Select";
		this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
		this.m_SelectionSetRadioButton.AutoSize = true;
		this.m_SelectionSetRadioButton.Location = new System.Drawing.Point(6, 19);
		this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
		this.m_SelectionSetRadioButton.Size = new System.Drawing.Size(88, 17);
		this.m_SelectionSetRadioButton.TabIndex = 0;
		this.m_SelectionSetRadioButton.TabStop = true;
		this.m_SelectionSetRadioButton.Text = "&Selection Set";
		this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
		this.m_PlaceTagGroupBox.Controls.Add(this.m_LeaderedTagCheckBox);
		this.m_PlaceTagGroupBox.Controls.Add(this.m_CreatePlantGroupTagCheckBox);
		this.m_PlaceTagGroupBox.Location = new System.Drawing.Point(12, 142);
		this.m_PlaceTagGroupBox.Name = "m_PlaceTagGroupBox";
		this.m_PlaceTagGroupBox.Size = new System.Drawing.Size(399, 66);
		this.m_PlaceTagGroupBox.TabIndex = 9;
		this.m_PlaceTagGroupBox.TabStop = false;
		this.m_PlaceTagGroupBox.Text = "Place Tag";
		this.m_LeaderedTagCheckBox.AutoSize = true;
		this.m_LeaderedTagCheckBox.Enabled = false;
		this.m_LeaderedTagCheckBox.Location = new System.Drawing.Point(22, 42);
		this.m_LeaderedTagCheckBox.Name = "m_LeaderedTagCheckBox";
		this.m_LeaderedTagCheckBox.Size = new System.Drawing.Size(93, 17);
		this.m_LeaderedTagCheckBox.TabIndex = 1;
		this.m_LeaderedTagCheckBox.Text = "Lea&dered Tag";
		this.m_LeaderedTagCheckBox.UseVisualStyleBackColor = true;
		this.m_CreatePlantGroupTagCheckBox.AutoSize = true;
		this.m_CreatePlantGroupTagCheckBox.Location = new System.Drawing.Point(6, 19);
		this.m_CreatePlantGroupTagCheckBox.Name = "m_CreatePlantGroupTagCheckBox";
		this.m_CreatePlantGroupTagCheckBox.Size = new System.Drawing.Size(138, 17);
		this.m_CreatePlantGroupTagCheckBox.TabIndex = 0;
		this.m_CreatePlantGroupTagCheckBox.Text = "Create Plant Group Tag";
		this.m_CreatePlantGroupTagCheckBox.UseVisualStyleBackColor = true;
		this.m_CreatePlantGroupTagCheckBox.CheckStateChanged += new System.EventHandler(this.OnCreatePlantGroupCheckBoxChecked);
		this.m_DeleteExistingCheckBox.AutoSize = true;
		this.m_DeleteExistingCheckBox.Location = new System.Drawing.Point(12, 214);
		this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
		this.m_DeleteExistingCheckBox.Size = new System.Drawing.Size(137, 17);
		this.m_DeleteExistingCheckBox.TabIndex = 10;
		this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
		this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
		this.m_InsertButton.Location = new System.Drawing.Point(254, 237);
		this.m_InsertButton.Name = "m_InsertButton";
		this.m_InsertButton.Size = new System.Drawing.Size(75, 23);
		this.m_InsertButton.TabIndex = 11;
		this.m_InsertButton.Text = "&Insert";
		this.m_InsertButton.UseVisualStyleBackColor = true;
		this.m_InsertButton.Click += new System.EventHandler(this.OnInsertButtonClick);
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(335, 237);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 12;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_LevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LevelComboBox.FormattingEnabled = true;
		this.m_LevelComboBox.Location = new System.Drawing.Point(115, 115);
		this.m_LevelComboBox.Name = "m_LevelComboBox";
		this.m_LevelComboBox.Size = new System.Drawing.Size(214, 21);
		this.m_LevelComboBox.TabIndex = 8;
		this.m_LevelLabel.AutoSize = true;
		this.m_LevelLabel.Location = new System.Drawing.Point(12, 118);
		this.m_LevelLabel.Name = "m_LevelLabel";
		this.m_LevelLabel.Size = new System.Drawing.Size(36, 13);
		this.m_LevelLabel.TabIndex = 7;
		this.m_LevelLabel.Text = "&Level:";
		this.m_LoadFamilyButton.Location = new System.Drawing.Point(335, 13);
		this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
		this.m_LoadFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadFamilyButton.TabIndex = 2;
		this.m_LoadFamilyButton.TabStop = false;
		this.m_LoadFamilyButton.Text = "...";
		this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Click += new System.EventHandler(this.OnLoadFamilyButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(422, 272);
		base.Controls.Add(this.m_LoadFamilyButton);
		base.Controls.Add(this.m_LevelComboBox);
		base.Controls.Add(this.m_LevelLabel);
		base.Controls.Add(this.m_PlaceTagGroupBox);
		base.Controls.Add(this.m_DeleteExistingCheckBox);
		base.Controls.Add(this.m_InsertButton);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_SelectionMethodsGroupBox);
		base.Controls.Add(this.m_SearchButton);
		base.Controls.Add(this.m_PlantNameComboBox);
		base.Controls.Add(this.m_PlantNameLabel);
		base.Controls.Add(this.m_PlantFamilyComboBox);
		base.Controls.Add(this.m_PlantFamilyLabel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "ConvertPlantForm";
		this.Text = "Convert Plants";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnConvertPlantFormClosing);
		this.m_SelectionMethodsGroupBox.ResumeLayout(false);
		this.m_SelectionMethodsGroupBox.PerformLayout();
		this.m_PlaceTagGroupBox.ResumeLayout(false);
		this.m_PlaceTagGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_InsertButton;
		base.CancelButton = this.m_CancelButton;
	}
}
