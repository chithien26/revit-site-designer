﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyParameterTypeWrapper
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class FamilyParameterTypeWrapper
{
  private string m_parameterDisplayName;
  private string m_parameterName;
  private ParameterType m_parameterType;
  private BuiltInParameter m_builtInParameter;

  public FamilyParameterTypeWrapper(
    string parameterDisplayName,
    string parameterName,
    ParameterType parameterType)
  {
    this.m_parameterDisplayName = parameterDisplayName;
    this.m_parameterName = parameterName;
    this.m_parameterType = parameterType;
    this.m_builtInParameter = (BuiltInParameter) -1;
  }

  public FamilyParameterTypeWrapper(
    string parameterDisplayName,
    string parameterName,
    ParameterType parameterType,
    BuiltInParameter builtInParameter)
  {
    this.m_parameterDisplayName = parameterDisplayName;
    this.m_parameterName = parameterName;
    this.m_parameterType = parameterType;
    this.m_builtInParameter = builtInParameter;
  }

  public string ParameterDisplayName
  {
    get => this.m_parameterDisplayName;
    set => this.m_parameterDisplayName = value;
  }

  public string ParameterName
  {
    get => this.m_parameterName;
    set => this.m_parameterName = value;
  }

  public ParameterType ParameterType
  {
    get => this.m_parameterType;
    set => this.m_parameterType = value;
  }

  public BuiltInParameter BuiltInParameter
  {
    get => this.m_builtInParameter;
    set => this.m_builtInParameter = value;
  }
}
