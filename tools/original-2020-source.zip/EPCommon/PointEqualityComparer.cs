﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PointEqualityComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class PointEqualityComparer : IEqualityComparer<Eps_Point>
{
  bool IEqualityComparer<Eps_Point>.Equals(Eps_Point x, Eps_Point y)
  {
    return x != null && y != null && EPShared.eplGeoE_ArePntsDuplicates2D(x, y);
  }

  int IEqualityComparer<Eps_Point>.GetHashCode(Eps_Point obj)
  {
    double x = obj.x;
    double y = obj.y;
    double z = obj.z;
    return x.GetHashCode() + y.GetHashCode() + z.GetHashCode();
  }
}
