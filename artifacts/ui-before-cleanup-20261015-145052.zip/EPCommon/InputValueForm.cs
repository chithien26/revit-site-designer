using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EPCommon;

public class InputValueForm : SiteDesigner.UI.WpfForm
{
	private IContainer components;

	private Button m_OKButton;

	private Button m_CancelButton;

	private TextBox m_WarningMessageTextBox;

	private Label m_FieldLabel;

	private TextBox m_FieldTextBox;

	public string FieldValue
	{
		get
		{
			return m_FieldTextBox.Text;
		}
		set
		{
			m_FieldTextBox.Text = value;
		}
	}

	public InputValueForm(string _strFormTitle, string _strWarningText, string _strFieldLabel)
	{
		InitializeComponent();
		Text = _strFormTitle;
		m_WarningMessageTextBox.Text = _strWarningText;
		m_FieldLabel.Text = _strFieldLabel;
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EPCommon.InputValueForm));
		this.m_OKButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_WarningMessageTextBox = new System.Windows.Forms.TextBox();
		this.m_FieldLabel = new System.Windows.Forms.Label();
		this.m_FieldTextBox = new System.Windows.Forms.TextBox();
		base.SuspendLayout();
		this.m_OKButton.Location = new System.Drawing.Point(181, 95);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 3;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_CancelButton.Location = new System.Drawing.Point(262, 95);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_WarningMessageTextBox.BackColor = System.Drawing.SystemColors.Control;
		this.m_WarningMessageTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.m_WarningMessageTextBox.Location = new System.Drawing.Point(12, 12);
		this.m_WarningMessageTextBox.Multiline = true;
		this.m_WarningMessageTextBox.Name = "m_WarningMessageTextBox";
		this.m_WarningMessageTextBox.Size = new System.Drawing.Size(324, 51);
		this.m_WarningMessageTextBox.TabIndex = 0;
		this.m_WarningMessageTextBox.TabStop = false;
		this.m_FieldLabel.AutoSize = true;
		this.m_FieldLabel.Location = new System.Drawing.Point(12, 72);
		this.m_FieldLabel.Name = "m_FieldLabel";
		this.m_FieldLabel.Size = new System.Drawing.Size(38, 13);
		this.m_FieldLabel.TabIndex = 1;
		this.m_FieldLabel.Text = "Name:";
		this.m_FieldTextBox.Location = new System.Drawing.Point(117, 69);
		this.m_FieldTextBox.Name = "m_FieldTextBox";
		this.m_FieldTextBox.Size = new System.Drawing.Size(220, 20);
		this.m_FieldTextBox.TabIndex = 2;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(349, 130);
		base.Controls.Add(this.m_FieldLabel);
		base.Controls.Add(this.m_FieldTextBox);
		base.Controls.Add(this.m_WarningMessageTextBox);
		base.Controls.Add(this.m_OKButton);
		base.Controls.Add(this.m_CancelButton);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Icon = (System.Drawing.Icon)EPCommon.SafeResources.GetObject(resources, "$this.Icon");
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "InputValueForm";
		base.ShowInTaskbar = false;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "InputValueForm";
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_OKButton;
		base.CancelButton = this.m_CancelButton;
	}
}
