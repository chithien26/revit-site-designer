﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.StringTableModule
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class StringTableModule
{
  private Hashtable m_HTStringTable = new Hashtable();

  public StringTableModule(RevitProduct _RevitProduct) => this.ReadLanguageFile(_RevitProduct);

  protected void ReadStringEntry(ref StringTableInfo _StringEntry, XmlElementInfo _XMLElement)
  {
    _StringEntry.strID = _XMLElement.GetAttribute("id");
    _StringEntry.strValue = _XMLElement.GetAttribute("value");
  }

  private void ReadLanguageFile(RevitProduct _RevitProduct)
  {
    StringTableInfo _StringEntry = new StringTableInfo();
    string empty = string.Empty;
    if (_RevitProduct == RevitProduct.LANDCADD)
    {
      ApplicationUtility.RegistryPaths.GetSupportPath($"LANDCADD_{ApplicationUtility.ThreeLetterWindowsLanguageName}.xml", ref empty);
      if (!File.Exists(empty))
        ApplicationUtility.RegistryPaths.GetSupportPath("LANDCADD_enu.xml", ref empty);
    }
    else
    {
      ApplicationUtility.RegistryPaths.GetSupportPath($"SITEDESIGNER_{ApplicationUtility.ThreeLetterWindowsLanguageName}.xml", ref empty);
      if (!File.Exists(empty))
        ApplicationUtility.RegistryPaths.GetSupportPath("SITEDESIGNER_enu.xml", ref empty);
    }
    XmlEngine xmlEngine = new XmlEngine();
    xmlEngine.Read(empty);
    XmlElementInfo element1 = xmlEngine.GetElement("StringTable");
    if (element1 == null)
      return;
    this.m_HTStringTable.Clear();
    for (int _nElement = 0; _nElement < element1.ElementCount; ++_nElement)
    {
      XmlElementInfo element2 = element1.GetElement(_nElement);
      if (element2 != null)
      {
        this.ReadStringEntry(ref _StringEntry, element2);
        if (_StringEntry.strID != null)
        {
          if (this.m_HTStringTable.ContainsKey((object) _StringEntry.strID))
          {
            int num1 = (int) MessageBox.Show($"Duplicate String ID: {_StringEntry.strID} in file: {xmlEngine.FileName}");
          }
          else if (!_StringEntry.Equals((object) string.Empty))
          {
            this.m_HTStringTable.Add((object) _StringEntry.strID, (object) _StringEntry);
          }
          else
          {
            int num2 = (int) MessageBox.Show($"Empty value: {_StringEntry.strID} in file: {xmlEngine.FileName}");
          }
        }
      }
    }
  }

  public string GetString(string _strID) => this.GetString(string.Empty, _strID);

  public string GetString(string _strWindowsLanguageName, string _strID)
  {
    string str = string.Empty;
    if (_strWindowsLanguageName != string.Empty && this.m_HTStringTable.ContainsKey((object) $"{_strWindowsLanguageName}-{_strID}"))
    {
      StringTableInfo stringTableInfo = (StringTableInfo) this.m_HTStringTable[(object) $"{_strWindowsLanguageName}-{_strID}"];
      if (string.Compare(stringTableInfo.strID, $"{_strWindowsLanguageName}-{_strID}", true) == 0)
        str = stringTableInfo.strValue;
    }
    if (str == string.Empty && this.m_HTStringTable.ContainsKey((object) _strID))
    {
      StringTableInfo stringTableInfo = (StringTableInfo) this.m_HTStringTable[(object) _strID];
      if (string.Compare(stringTableInfo.strID, _strID, true) == 0)
        str = stringTableInfo.strValue;
    }
    if (str == string.Empty)
    {
      if (Debugger.IsAttached)
      {
        Debugger.Break();
      }
      else
      {
        int num = (int) MessageBox.Show("Missing string label:  " + _strID, "XML Error");
      }
    }
    return str;
  }
}
