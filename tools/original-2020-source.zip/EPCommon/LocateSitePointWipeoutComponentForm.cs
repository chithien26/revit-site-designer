﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LocateSitePointWipeoutComponentForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LocateSitePointWipeoutComponentForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private SiteComponentCreation m_dataBuffer;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private CheckBox m_CreateCopyCheckBox;
  private Panel m_HostLineSelectionPanel;
  private RadioButton m_UseExistingHostLineRadioButton;
  private RadioButton m_DrawHostLineRadioButton;
  private Label m_RadiusLabel;
  private TextBox m_RadiusTextBox;
  private Panel m_MoveablePanel;
  private Button m_CloseButton;
  private Button m_InsertButton;
  private CheckBox m_ShowAffectedPointsCheckBox;

  public LocateSitePointWipeoutComponentForm(SiteComponentCreation dataBuffer)
  {
    this.InitializeComponent();
    this.SetStrings();
    this.ContextualHelpID = "HID_SDpointWipeoutCreate";
    this.m_dataBuffer = dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
  }

  private void SetStrings()
  {
    this.Text = EPShared.LocalRM.GetString("LocatePointWipeoutDialog");
    this.m_CreateCopyCheckBox.Text = EPShared.LocalRM.GetString("Create_AMP_ACopyDialog");
    this.m_UseExistingHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_UseExistingHostLineDialog");
    this.m_DrawHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_DrawHostLineDialog");
    this.m_RadiusLabel.Text = EPShared.LocalRM.GetString("AMP_RadiusDialog");
    this.m_ShowAffectedPointsCheckBox.Text = EPShared.LocalRM.GetString("S_AMP_howAffectedPointsDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
  }

  private void OnHostLineSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_RadiusLabel.Enabled = this.m_DrawHostLineRadioButton.Checked;
    this.m_RadiusTextBox.Enabled = this.m_DrawHostLineRadioButton.Checked;
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_UseExistingHostLineRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocatePointWipeoutHostLineSelectionOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_UseExistingHostLineRadioButton.Checked = true;
      else
        this.m_DrawHostLineRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocatePointWipeoutRadius", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
    this.m_RadiusTextBox.Text = empty;
    this.m_CreateCopyCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocatePointWipeoutCreateVisibleCopy", ref _nReturnValue))
      this.m_CreateCopyCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ShowAffectedPointsCheckBox.Checked = false;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocatePointWipeoutShowAffectedPoints", ref _nReturnValue))
      return;
    this.m_ShowAffectedPointsCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
  }

  private void SaveSettings()
  {
    double _dReturnedDouble = 0.0;
    ApplicationUtility.Settings.eplSetE_SetSetting("LocatePointWipeoutHostLineSelectionOption", !this.m_UseExistingHostLineRadioButton.Checked ? 1 : 0);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocatePointWipeoutRadius", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting("LocatePointWipeoutCreateVisibleCopy", Convert.ToInt32(this.m_CreateCopyCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("LocatePointWipeoutShowAffectedPoints", Convert.ToInt32(this.m_ShowAffectedPointsCheckBox.Checked));
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCloseButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void FormatRadiusValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      if (_dReturnedDouble < 0.0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusValueString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_RadiusTextBox.Text = string.Empty;
      }
      else
      {
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
        this.m_RadiusTextBox.Text = empty;
      }
    }
    else
      this.m_RadiusTextBox.Focus();
  }

  private void OnRadiusKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatRadiusValue();
  }

  private void OnRadiusTextBoxLeave(object sender, EventArgs e) => this.FormatRadiusValue();

  private void OnLocateSitePointWipeoutComponentClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public bool ExistingHostLineChecked => this.m_UseExistingHostLineRadioButton.Checked;

  public double Radius
  {
    get
    {
      if (this.m_UseExistingHostLineRadioButton.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_RadiusTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool CreateCopyChecked => this.m_CreateCopyCheckBox.Checked;

  public bool ShowAffectedPointsChecked => this.m_ShowAffectedPointsCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_CreateCopyCheckBox = new CheckBox();
    this.m_HostLineSelectionPanel = new Panel();
    this.m_UseExistingHostLineRadioButton = new RadioButton();
    this.m_DrawHostLineRadioButton = new RadioButton();
    this.m_RadiusLabel = new Label();
    this.m_RadiusTextBox = new TextBox();
    this.m_MoveablePanel = new Panel();
    this.m_CloseButton = new Button();
    this.m_InsertButton = new Button();
    this.m_ShowAffectedPointsCheckBox = new CheckBox();
    this.m_HostLineSelectionPanel.SuspendLayout();
    this.m_MoveablePanel.SuspendLayout();
    this.SuspendLayout();
    this.m_CreateCopyCheckBox.AutoSize = true;
    this.m_CreateCopyCheckBox.Location = new Point(12, 12);
    this.m_CreateCopyCheckBox.Name = "m_CreateCopyCheckBox";
    this.m_CreateCopyCheckBox.Size = new Size(94, 17);
    this.m_CreateCopyCheckBox.TabIndex = 0;
    this.m_CreateCopyCheckBox.Text = "Create A Copy";
    this.m_CreateCopyCheckBox.UseVisualStyleBackColor = true;
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_UseExistingHostLineRadioButton);
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_DrawHostLineRadioButton);
    this.m_HostLineSelectionPanel.Location = new Point(12, 35);
    this.m_HostLineSelectionPanel.Name = "m_HostLineSelectionPanel";
    this.m_HostLineSelectionPanel.Size = new Size(304, 41);
    this.m_HostLineSelectionPanel.TabIndex = 1;
    this.m_UseExistingHostLineRadioButton.AutoSize = true;
    this.m_UseExistingHostLineRadioButton.Location = new Point(0, 0);
    this.m_UseExistingHostLineRadioButton.Name = "m_UseExistingHostLineRadioButton";
    this.m_UseExistingHostLineRadioButton.Size = new Size(146, 17);
    this.m_UseExistingHostLineRadioButton.TabIndex = 0;
    this.m_UseExistingHostLineRadioButton.Text = "&Use an Existing Host Line";
    this.m_UseExistingHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_UseExistingHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_DrawHostLineRadioButton.AutoSize = true;
    this.m_DrawHostLineRadioButton.Location = new Point(0, 23);
    this.m_DrawHostLineRadioButton.Name = "m_DrawHostLineRadioButton";
    this.m_DrawHostLineRadioButton.Size = new Size(228, 17);
    this.m_DrawHostLineRadioButton.TabIndex = 1;
    this.m_DrawHostLineRadioButton.Text = "&Draw Host Line (Click Escape to Complete)";
    this.m_DrawHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_DrawHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_RadiusLabel.AutoSize = true;
    this.m_RadiusLabel.Enabled = false;
    this.m_RadiusLabel.Location = new Point(27, 84);
    this.m_RadiusLabel.Name = "m_RadiusLabel";
    this.m_RadiusLabel.Size = new Size(43, 13);
    this.m_RadiusLabel.TabIndex = 2;
    this.m_RadiusLabel.Text = "Radius:";
    this.m_RadiusTextBox.Enabled = false;
    this.m_RadiusTextBox.Location = new Point(216, 81);
    this.m_RadiusTextBox.Name = "m_RadiusTextBox";
    this.m_RadiusTextBox.Size = new Size(100, 20);
    this.m_RadiusTextBox.TabIndex = 3;
    this.m_RadiusTextBox.KeyDown += new KeyEventHandler(this.OnRadiusKeyDown);
    this.m_RadiusTextBox.Leave += new EventHandler(this.OnRadiusTextBoxLeave);
    this.m_MoveablePanel.Controls.Add((Control) this.m_CloseButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Location = new Point(9, 130);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(307, 23);
    this.m_MoveablePanel.TabIndex = 5;
    this.m_CloseButton.DialogResult = DialogResult.Cancel;
    this.m_CloseButton.Location = new Point(231, 0);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 1;
    this.m_CloseButton.Text = "&Cancel";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClick);
    this.m_InsertButton.Location = new Point(150, 0);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 0;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_ShowAffectedPointsCheckBox.AutoSize = true;
    this.m_ShowAffectedPointsCheckBox.Location = new Point(12, 107);
    this.m_ShowAffectedPointsCheckBox.Name = "m_ShowAffectedPointsCheckBox";
    this.m_ShowAffectedPointsCheckBox.Size = new Size(134, 17);
    this.m_ShowAffectedPointsCheckBox.TabIndex = 4;
    this.m_ShowAffectedPointsCheckBox.Text = "Show Affected Point(s)";
    this.m_ShowAffectedPointsCheckBox.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(328, 165);
    this.Controls.Add((Control) this.m_ShowAffectedPointsCheckBox);
    this.Controls.Add((Control) this.m_CreateCopyCheckBox);
    this.Controls.Add((Control) this.m_HostLineSelectionPanel);
    this.Controls.Add((Control) this.m_RadiusLabel);
    this.Controls.Add((Control) this.m_RadiusTextBox);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (LocateSitePointWipeoutComponentForm);
    this.Text = "Locate Point Wipeout";
    this.FormClosing += new FormClosingEventHandler(this.OnLocateSitePointWipeoutComponentClosing);
    this.m_HostLineSelectionPanel.ResumeLayout(false);
    this.m_HostLineSelectionPanel.PerformLayout();
    this.m_MoveablePanel.ResumeLayout(false);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
