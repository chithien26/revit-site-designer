﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.CgPoint
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class CgPoint
{
  private int m_nName = -1;
  private string m_strCode = string.Empty;
  private string m_strDesc = string.Empty;
  private string m_strNameUnit = string.Empty;
  private Eps_Point m_CgPnt = new Eps_Point();

  public CgPoint(
    int _nName,
    string _strCode,
    string _strDesc,
    string _strNameUnit,
    Eps_Point _CgPnt)
  {
    this.m_nName = _nName;
    this.m_strCode = _strCode;
    this.m_strDesc = _strDesc;
    this.m_strNameUnit = _strNameUnit;
    this.m_CgPnt = _CgPnt;
  }

  public int Name
  {
    get => this.m_nName;
    set => this.m_nName = value;
  }

  public string Code
  {
    get => this.m_strCode;
    set => this.m_strCode = value;
  }

  public string Desc
  {
    get => this.m_strDesc;
    set => this.m_strDesc = value;
  }

  public string NameUnit
  {
    get => this.m_strNameUnit;
    set => this.m_strNameUnit = value;
  }

  public Eps_Point CgPnt
  {
    get => this.m_CgPnt;
    set => this.m_CgPnt = value;
  }
}
