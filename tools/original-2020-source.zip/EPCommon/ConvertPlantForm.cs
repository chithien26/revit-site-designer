﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ConvertPlantForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ConvertPlantForm : EPForm
{
  private ConvertPlant m_dataBuffer;
  private View m_CurView;
  private FamilySymbol m_CurType;
  private IContainer components;
  private Button m_SearchButton;
  private ComboBox m_PlantNameComboBox;
  private Label m_PlantNameLabel;
  private ComboBox m_PlantFamilyComboBox;
  private Label m_PlantFamilyLabel;
  private GroupBox m_SelectionMethodsGroupBox;
  private RadioButton m_AllCirclesRadioButton;
  private RadioButton m_WindowSelectRadioButton;
  private RadioButton m_SelectionSetRadioButton;
  private GroupBox m_PlaceTagGroupBox;
  private CheckBox m_LeaderedTagCheckBox;
  private CheckBox m_CreatePlantGroupTagCheckBox;
  private CheckBox m_DeleteExistingCheckBox;
  private Button m_InsertButton;
  private Button m_CancelButton;
  private ComboBox m_LevelComboBox;
  private Label m_LevelLabel;
  private Button m_LoadFamilyButton;

  public ConvertPlantForm(ConvertPlant _dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ConvertPlantsDialog");
    this.m_PlantFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_PlantFamilyDialog");
    this.m_PlantNameLabel.Text = EPShared.LocalRM.GetString("P_AMP_lantNameDialog");
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("Sea_AMP_rchDialog");
    this.m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
    this.m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
    this.m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
    this.m_AllCirclesRadioButton.Text = EPShared.LocalRM.GetString("AMP_AllCirclesDialog");
    this.m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
    this.m_PlaceTagGroupBox.Text = EPShared.LocalRM.GetString("PlaceTagDialog");
    this.m_CreatePlantGroupTagCheckBox.Text = EPShared.LocalRM.GetString("CreatePlant_AMP_GroupTagDialog");
    this.m_LeaderedTagCheckBox.Text = EPShared.LocalRM.GetString("Lea_AMP_deredTagDialog");
    this.m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.m_dataBuffer = _dataBuffer;
    this.InitializeControls();
    ManagePlants.VerifySharedParameters(this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer);
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_SelectionSetRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsSelectMethodOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_SelectionSetRadioButton.Checked = true;
          break;
        case 1:
          this.m_WindowSelectRadioButton.Checked = true;
          break;
        default:
          this.m_AllCirclesRadioButton.Checked = true;
          break;
      }
    }
    this.m_CreatePlantGroupTagCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsCreatePlantGroupTag", ref _nReturnValue))
      this.m_CreatePlantGroupTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_LeaderedTagCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsCreateLeaderedTag", ref _nReturnValue))
      this.m_LeaderedTagCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_DeleteExistingCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ConvertPlantsDeleteExisting", ref _nReturnValue))
      this.m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_PlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.PlantFamilyList;
    this.m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ConvertPlantsFamilyName", ref empty))
    {
      for (int index = 0; index < this.m_PlantFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_PlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty, true) == 0)
        {
          this.m_PlantFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ConvertPlantsPlantName", ref empty))
    {
      for (int index = 0; index < this.m_PlantNameComboBox.Items.Count; ++index)
      {
        if (this.m_PlantNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty, true) == 0)
        {
          this.m_PlantNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_LevelComboBox.DataSource = (object) this.m_dataBuffer.Views;
    this.m_LevelComboBox.DisplayMember = EPShared.LocalRM.GetString("ViewNameString");
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "ConvertPlantsViewName", ref empty))
      return;
    for (int index = 0; index < this.m_LevelComboBox.Items.Count; ++index)
    {
      if (this.m_LevelComboBox.Items[index] is View view && string.Compare(((Element) view).Name, empty, true) == 0)
      {
        this.m_LevelComboBox.SelectedIndex = index;
        break;
      }
    }
  }

  private void OnPlantFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_PlantNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnSearchButtonClick(object sender, EventArgs e)
  {
    if (!(this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    List<FamilySymbol> _SearchSymbolList = new List<FamilySymbol>();
    if (!ManagePlants.FindFamilySymbols(EPShared.LocalRM.GetString("ConvertPlantSearchTitle"), this.m_dataBuffer.Document, this.m_dataBuffer.TransactionContainer, selectedItem.FamilySymbolList, ref _SearchSymbolList))
      return;
    this.m_PlantNameComboBox.DataSource = (object) _SearchSymbolList;
    this.m_PlantNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnCreatePlantGroupCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_LeaderedTagCheckBox.Enabled = this.m_CreatePlantGroupTagCheckBox.Checked;
  }

  private void OnInsertButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void SaveSettings()
  {
    this.m_CurView = this.m_LevelComboBox.SelectedItem as View;
    if (this.m_CurView == null)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.m_CurType = this.m_PlantNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_CurType == null)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Revit"), MessageBoxIcon.Hand);
      }
      else
      {
        ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsSelectMethodOption", !this.m_SelectionSetRadioButton.Checked ? (!this.m_WindowSelectRadioButton.Checked ? 2 : 1) : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsCreatePlantGroupTag", Convert.ToInt32(this.m_CreatePlantGroupTagCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsCreateLeaderedTag", Convert.ToInt32(this.m_LeaderedTagCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("ConvertPlantsDeleteExisting", Convert.ToInt32(this.m_DeleteExistingCheckBox.Checked));
        if (this.m_PlantFamilyComboBox.SelectedItem is FamilyContainer selectedItem)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ConvertPlantsFamilyName", selectedItem.FamilyName);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ConvertPlantsPlantName", ((Element) this.m_CurType).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "ConvertPlantsViewName", ((Element) this.m_CurView).Name);
      }
    }
  }

  private void OnConvertPlantFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_PlantFamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectPlantingFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            this.m_dataBuffer.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_PlantFamilyComboBox.DataSource = (object) this.m_dataBuffer.PlantFamilyList;
        this.m_PlantFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_PlantFamilyComboBox.Items.Count; ++index)
          {
            if (this.m_PlantFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_PlantFamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_PlantFamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  public bool SelectionSetChecked => this.m_SelectionSetRadioButton.Checked;

  public bool WindowSelectChecked => this.m_WindowSelectRadioButton.Checked;

  public bool AllCirclesChecked => this.m_AllCirclesRadioButton.Checked;

  public bool DeleteExistingChecked => this.m_DeleteExistingCheckBox.Checked;

  public bool PlaceGroupTagChecked => this.m_CreatePlantGroupTagCheckBox.Checked;

  public bool LeaderedTagChecked => this.m_LeaderedTagCheckBox.Checked;

  public Level Level => this.m_CurView.GenLevel;

  public View View => this.m_CurView;

  public FamilySymbol Type => this.m_CurType;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_SearchButton = new Button();
    this.m_PlantNameComboBox = new ComboBox();
    this.m_PlantNameLabel = new Label();
    this.m_PlantFamilyComboBox = new ComboBox();
    this.m_PlantFamilyLabel = new Label();
    this.m_SelectionMethodsGroupBox = new GroupBox();
    this.m_AllCirclesRadioButton = new RadioButton();
    this.m_WindowSelectRadioButton = new RadioButton();
    this.m_SelectionSetRadioButton = new RadioButton();
    this.m_PlaceTagGroupBox = new GroupBox();
    this.m_LeaderedTagCheckBox = new CheckBox();
    this.m_CreatePlantGroupTagCheckBox = new CheckBox();
    this.m_DeleteExistingCheckBox = new CheckBox();
    this.m_InsertButton = new Button();
    this.m_CancelButton = new Button();
    this.m_LevelComboBox = new ComboBox();
    this.m_LevelLabel = new Label();
    this.m_LoadFamilyButton = new Button();
    this.m_SelectionMethodsGroupBox.SuspendLayout();
    this.m_PlaceTagGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_SearchButton.Location = new Point(335, 37);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(75, 23);
    this.m_SearchButton.TabIndex = 5;
    this.m_SearchButton.Text = "Sea&rch";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButtonClick);
    this.m_PlantNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantNameComboBox.FormattingEnabled = true;
    this.m_PlantNameComboBox.Location = new Point(115, 39);
    this.m_PlantNameComboBox.Name = "m_PlantNameComboBox";
    this.m_PlantNameComboBox.Size = new Size(214, 21);
    this.m_PlantNameComboBox.TabIndex = 4;
    this.m_PlantNameLabel.AutoSize = true;
    this.m_PlantNameLabel.Location = new Point(12, 43);
    this.m_PlantNameLabel.Name = "m_PlantNameLabel";
    this.m_PlantNameLabel.Size = new Size(65, 13);
    this.m_PlantNameLabel.TabIndex = 3;
    this.m_PlantNameLabel.Text = "P&lant Name:";
    this.m_PlantFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantFamilyComboBox.FormattingEnabled = true;
    this.m_PlantFamilyComboBox.Location = new Point(115, 12);
    this.m_PlantFamilyComboBox.Name = "m_PlantFamilyComboBox";
    this.m_PlantFamilyComboBox.Size = new Size(214, 21);
    this.m_PlantFamilyComboBox.TabIndex = 1;
    this.m_PlantFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnPlantFamilyComboBoxSelectedIndexChanged);
    this.m_PlantFamilyLabel.AutoSize = true;
    this.m_PlantFamilyLabel.Location = new Point(12, 15);
    this.m_PlantFamilyLabel.Name = "m_PlantFamilyLabel";
    this.m_PlantFamilyLabel.Size = new Size(66, 13);
    this.m_PlantFamilyLabel.TabIndex = 0;
    this.m_PlantFamilyLabel.Text = "&Plant Family:";
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_AllCirclesRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_WindowSelectRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_SelectionSetRadioButton);
    this.m_SelectionMethodsGroupBox.Location = new Point(12, 66);
    this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
    this.m_SelectionMethodsGroupBox.Size = new Size(398, 43);
    this.m_SelectionMethodsGroupBox.TabIndex = 6;
    this.m_SelectionMethodsGroupBox.TabStop = false;
    this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
    this.m_AllCirclesRadioButton.AutoSize = true;
    this.m_AllCirclesRadioButton.Location = new Point(286, 19);
    this.m_AllCirclesRadioButton.Name = "m_AllCirclesRadioButton";
    this.m_AllCirclesRadioButton.Size = new Size(70, 17);
    this.m_AllCirclesRadioButton.TabIndex = 2;
    this.m_AllCirclesRadioButton.TabStop = true;
    this.m_AllCirclesRadioButton.Text = "&All Circles";
    this.m_AllCirclesRadioButton.UseVisualStyleBackColor = true;
    this.m_WindowSelectRadioButton.AutoSize = true;
    this.m_WindowSelectRadioButton.Location = new Point(144 /*0x90*/, 19);
    this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
    this.m_WindowSelectRadioButton.Size = new Size(97, 17);
    this.m_WindowSelectRadioButton.TabIndex = 1;
    this.m_WindowSelectRadioButton.TabStop = true;
    this.m_WindowSelectRadioButton.Text = "&Window Select";
    this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionSetRadioButton.AutoSize = true;
    this.m_SelectionSetRadioButton.Location = new Point(6, 19);
    this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
    this.m_SelectionSetRadioButton.Size = new Size(88, 17);
    this.m_SelectionSetRadioButton.TabIndex = 0;
    this.m_SelectionSetRadioButton.TabStop = true;
    this.m_SelectionSetRadioButton.Text = "&Selection Set";
    this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
    this.m_PlaceTagGroupBox.Controls.Add((Control) this.m_LeaderedTagCheckBox);
    this.m_PlaceTagGroupBox.Controls.Add((Control) this.m_CreatePlantGroupTagCheckBox);
    this.m_PlaceTagGroupBox.Location = new Point(12, 142);
    this.m_PlaceTagGroupBox.Name = "m_PlaceTagGroupBox";
    this.m_PlaceTagGroupBox.Size = new Size(399, 66);
    this.m_PlaceTagGroupBox.TabIndex = 9;
    this.m_PlaceTagGroupBox.TabStop = false;
    this.m_PlaceTagGroupBox.Text = "Place Tag";
    this.m_LeaderedTagCheckBox.AutoSize = true;
    this.m_LeaderedTagCheckBox.Enabled = false;
    this.m_LeaderedTagCheckBox.Location = new Point(22, 42);
    this.m_LeaderedTagCheckBox.Name = "m_LeaderedTagCheckBox";
    this.m_LeaderedTagCheckBox.Size = new Size(93, 17);
    this.m_LeaderedTagCheckBox.TabIndex = 1;
    this.m_LeaderedTagCheckBox.Text = "Lea&dered Tag";
    this.m_LeaderedTagCheckBox.UseVisualStyleBackColor = true;
    this.m_CreatePlantGroupTagCheckBox.AutoSize = true;
    this.m_CreatePlantGroupTagCheckBox.Location = new Point(6, 19);
    this.m_CreatePlantGroupTagCheckBox.Name = "m_CreatePlantGroupTagCheckBox";
    this.m_CreatePlantGroupTagCheckBox.Size = new Size(138, 17);
    this.m_CreatePlantGroupTagCheckBox.TabIndex = 0;
    this.m_CreatePlantGroupTagCheckBox.Text = "Create Plant Group Tag";
    this.m_CreatePlantGroupTagCheckBox.UseVisualStyleBackColor = true;
    this.m_CreatePlantGroupTagCheckBox.CheckStateChanged += new EventHandler(this.OnCreatePlantGroupCheckBoxChecked);
    this.m_DeleteExistingCheckBox.AutoSize = true;
    this.m_DeleteExistingCheckBox.Location = new Point(12, 214);
    this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
    this.m_DeleteExistingCheckBox.Size = new Size(137, 17);
    this.m_DeleteExistingCheckBox.TabIndex = 10;
    this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
    this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
    this.m_InsertButton.Location = new Point(254, 237);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 11;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnInsertButtonClick);
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(335, 237);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 12;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_LevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LevelComboBox.FormattingEnabled = true;
    this.m_LevelComboBox.Location = new Point(115, 115);
    this.m_LevelComboBox.Name = "m_LevelComboBox";
    this.m_LevelComboBox.Size = new Size(214, 21);
    this.m_LevelComboBox.TabIndex = 8;
    this.m_LevelLabel.AutoSize = true;
    this.m_LevelLabel.Location = new Point(12, 118);
    this.m_LevelLabel.Name = "m_LevelLabel";
    this.m_LevelLabel.Size = new Size(36, 13);
    this.m_LevelLabel.TabIndex = 7;
    this.m_LevelLabel.Text = "&Level:";
    this.m_LoadFamilyButton.Location = new Point(335, 13);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(422, 272);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_LevelComboBox);
    this.Controls.Add((Control) this.m_LevelLabel);
    this.Controls.Add((Control) this.m_PlaceTagGroupBox);
    this.Controls.Add((Control) this.m_DeleteExistingCheckBox);
    this.Controls.Add((Control) this.m_InsertButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_SelectionMethodsGroupBox);
    this.Controls.Add((Control) this.m_SearchButton);
    this.Controls.Add((Control) this.m_PlantNameComboBox);
    this.Controls.Add((Control) this.m_PlantNameLabel);
    this.Controls.Add((Control) this.m_PlantFamilyComboBox);
    this.Controls.Add((Control) this.m_PlantFamilyLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ConvertPlantForm);
    this.Text = "Convert Plants";
    this.FormClosing += new FormClosingEventHandler(this.OnConvertPlantFormClosing);
    this.m_SelectionMethodsGroupBox.ResumeLayout(false);
    this.m_SelectionMethodsGroupBox.PerformLayout();
    this.m_PlaceTagGroupBox.ResumeLayout(false);
    this.m_PlaceTagGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
