﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SearchPlantParameter
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class SearchPlantParameter
{
  private string m_strParameter;
  private PlantFieldsComparisionType m_ComparisionType;

  public SearchPlantParameter(PlantFieldsComparisionType _ComparisionType, string _strParameter)
  {
    this.m_strParameter = _strParameter;
    this.m_ComparisionType = _ComparisionType;
  }

  public string Parameter
  {
    get => this.m_strParameter;
    set => this.m_strParameter = value;
  }

  public PlantFieldsComparisionType ComparisionType
  {
    get => this.m_ComparisionType;
    set => this.m_ComparisionType = value;
  }
}
