﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ProjectSettingContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;

#nullable disable
namespace EPCommon;

public class ProjectSettingContainer
{
  private string m_strAppName;
  private DateTime m_CurrentDateTime;

  public ProjectSettingContainer(string _strAppName, DateTime _CurrentDateTime)
  {
    this.m_strAppName = _strAppName;
    this.m_CurrentDateTime = _CurrentDateTime;
  }

  public string AppName
  {
    get => this.m_strAppName;
    set => this.m_strAppName = value;
  }

  public DateTime CurrentDateTime
  {
    get => this.m_CurrentDateTime;
    set => this.m_CurrentDateTime = value;
  }
}
