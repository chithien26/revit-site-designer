﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.TopographySurfaceManagement
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using Autodesk.Revit.UI;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class TopographySurfaceManagement
{
  private static double m_dCurbElevation;

  private static void SetTopoDrawOrder(Document _Document, ref int _TopoDrawOrder)
  {
    if (_TopoDrawOrder == -1)
      _TopoDrawOrder = RevitUtility.FindMaxTopoDrawOrderFromSiteComponents(_Document);
    ++_TopoDrawOrder;
  }

  public static bool VerifyUserCanManipulateElements(Document _Document, List<Element> _ElementList)
  {
    List<KeyValuePair<string, Element>> keyValuePairList = new List<KeyValuePair<string, Element>>();
    if (_Document.IsWorkshared && _ElementList != null && _ElementList.Count > 0)
    {
      string empty1 = string.Empty;
      string username = _Document.Application.Username;
      if (username == null || username == string.Empty)
      {
        string[] strArray = WindowsIdentity.GetCurrent().Name.Split('\\');
        if (strArray.Length > 1)
          username = strArray[1];
      }
      string empty2 = string.Empty;
      for (int index = 0; index < _ElementList.Count; ++index)
      {
        if (_ElementList[index] != null && _ElementList[index][(BuiltInParameter) -1002053] != null)
        {
          Parameter parameter = _ElementList[index][(BuiltInParameter) -1002067];
          if (parameter != null)
          {
            string str = parameter.AsString();
            if (string.Compare(str, username, true) != 0)
            {
              if (str != string.Empty)
                keyValuePairList.Add(new KeyValuePair<string, Element>(str, _ElementList[index]));
              else if (!File.Exists(ModelPathUtils.ConvertModelPathToUserVisiblePath(_Document.GetWorksharingCentralModelPath())))
              {
                int num = (int) RevitMessageBox.Show(string.Format(EPShared.LocalRM.GetString("CantObtainPermissionToEditElementMessage"), (object) ModelPathUtils.ConvertModelPathToUserVisiblePath(_Document.GetWorksharingCentralModelPath())), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
            }
          }
        }
      }
    }
    if (keyValuePairList == null || keyValuePairList.Count <= 0)
      return true;
    keyValuePairList.Sort((Comparison<KeyValuePair<string, Element>>) ((p1, p2) => p1.Key.CompareTo(p2.Key)));
    string text1 = string.Empty;
    TreeNode _CurrentNode = new TreeNode(EPShared.LocalRM.GetString("Error"));
    for (int index = 0; index < keyValuePairList.Count; ++index)
    {
      KeyValuePair<string, Element> keyValuePair;
      TreeNode node1;
      if (_CurrentNode.Nodes.Count != 0)
      {
        string text2 = _CurrentNode.Nodes[_CurrentNode.Nodes.Count - 1].Text;
        keyValuePair = keyValuePairList[index];
        string key = keyValuePair.Key;
        if (text2.Contains(key))
        {
          node1 = _CurrentNode.Nodes[_CurrentNode.Nodes.Count - 1];
          goto label_20;
        }
      }
      string format = EPShared.LocalRM.GetString("CantEditElementsUntilUserResavesMessage");
      keyValuePair = keyValuePairList[index];
      string key1 = keyValuePair.Key;
      node1 = new TreeNode(string.Format(format, (object) key1));
      _CurrentNode.Nodes.Add(node1);
label_20:
      keyValuePair = keyValuePairList[index];
      if (keyValuePair.Value.Category != null)
      {
        keyValuePair = keyValuePairList[index];
        text1 = keyValuePair.Value.Category.Name + ": ";
      }
      string[] strArray = new string[6];
      strArray[0] = text1;
      keyValuePair = keyValuePairList[index];
      strArray[1] = keyValuePair.Value.Name;
      strArray[2] = ": ";
      strArray[3] = EPShared.LocalRM.GetString("IDString");
      strArray[4] = " ";
      keyValuePair = keyValuePairList[index];
      strArray[5] = Convert.ToString(keyValuePair.Value.Id.IntegerValue);
      text1 = string.Concat(strArray);
      TreeNode node2 = new TreeNode(text1);
      TreeNode treeNode = node2;
      keyValuePair = keyValuePairList[index];
      Element element = keyValuePair.Value;
      treeNode.Tag = (object) element;
      node1.Nodes.Add(node2);
    }
    int num1 = (int) new ErrorTreeListForm(_Document, EPShared.LocalRM.GetString("WorksetPermissionErrorDialog"), _CurrentNode).ShowDialog();
    return false;
  }

  public static bool CreateTopographySurfaceUpdate(
    Document _Document,
    Eps_Leg _CurrentLeg,
    SitePlacementSettings _PlacementSettings,
    double _dArcPointInterval,
    List<Element> _LineElementList,
    ref TopographySurfaceContainer _ProposedSurface,
    ref FamilyInstance _TopoPlacementFamilyInstance,
    ref int _nTopoDrawOrder)
  {
    return TopographySurfaceManagement.CreateTopographySurfaceUpdate(_Document, _CurrentLeg, _PlacementSettings, _dArcPointInterval, _LineElementList, ref _ProposedSurface, ref _TopoPlacementFamilyInstance, ref _nTopoDrawOrder, (List<Element>) null);
  }

  public static bool CreateTopographySurfaceUpdate(
    Document _Document,
    Eps_Leg _CurrentLeg,
    SitePlacementSettings _PlacementSettings,
    double _dArcPointInterval,
    List<Element> _LineElementList,
    ref TopographySurfaceContainer _ProposedSurface,
    ref FamilyInstance _TopoPlacementFamilyInstance,
    ref int _nTopoDrawOrder,
    List<Element> _VerifyElementList)
  {
    int nLineCount1 = 0;
    int nArcCount1 = 0;
    Eps_Line[] aLines1 = (Eps_Line[]) null;
    Eps_Arc[] aArcs1 = (Eps_Arc[]) null;
    int[] aLegOrder1 = (int[]) null;
    int nLineCount2 = 0;
    int nArcCount2 = 0;
    Eps_Line[] aLines2 = (Eps_Line[]) null;
    Eps_Arc[] aArcs2 = (Eps_Arc[]) null;
    int[] aLegOrder2 = (int[]) null;
    Eps_Leg ppOffsetLegList1 = (Eps_Leg) null;
    Eps_Leg ppOffsetLegList2 = (Eps_Leg) null;
    List<XYZ> xyzList1 = new List<XYZ>();
    List<XYZ> xyzList2 = new List<XYZ>();
    List<Eps_Point> _AddPointList = new List<Eps_Point>();
    Parameter parameter1 = (Parameter) null;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    List<IntersectionContainer> _IntersectionContainers = new List<IntersectionContainer>();
    List<IntersectionStationContainer> _LeftIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _RightIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _CenterIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> stationContainerList1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> stationContainerList2 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> stationContainerList3 = new List<IntersectionStationContainer>();
    List<OffsetLegWrapper> _OffsetLegWrappers = new List<OffsetLegWrapper>();
    List<Eps_Point> epsPointList1 = new List<Eps_Point>();
    List<Eps_Point> collection = new List<Eps_Point>();
    List<Eps_Point> _CrownPointList = new List<Eps_Point>();
    double num1 = 0.0;
    bool _bUseToposurfaceElevation = _PlacementSettings.IsRelativeElevation;
    double _dElevation = _PlacementSettings.Elevation;
    double num2 = _PlacementSettings.Grade;
    double _dStation1 = 0.0;
    double _dOffset = 0.0;
    double dCutSlope = 3.0;
    double dFillSlope = 3.0;
    double num3 = 15.0;
    double num4 = 3.0;
    double num5 = 0.0;
    double num6 = 0.0;
    double dBoulevardWidth = 0.0;
    double num7 = 0.0;
    double _dExistingAdjustSubgradeElev = 0.0;
    double _dExistingOffset = 0.0;
    bool bIsCrownPresent = false;
    bool bIsProjectLegToTopo = false;
    bool _bUseConstantElevation = !_bUseToposurfaceElevation;
    double _dStreetEdgeAdjustElev = 0.0;
    double dLeftEdgeAdjustElev = 0.0;
    double dRightEdgeAdjustElev = 0.0;
    double dLeftSubgradeAdjustElev = 0.0;
    double dRightSubgradeAdjustElev = 0.0;
    double num8 = _dElevation;
    List<Element> _ElementList = new List<Element>();
    if (_ProposedSurface.TopographySurface != null)
      _ElementList.Add((Element) _ProposedSurface.TopographySurface);
    if (_PlacementSettings.Type != null)
      _ElementList.Add((Element) _PlacementSettings.Type);
    if (_PlacementSettings.PlacementSymbol != null)
      _ElementList.Add((Element) _PlacementSettings.PlacementSymbol);
    if (_PlacementSettings.IntersectionPlacementSymbol != null)
      _ElementList.Add((Element) _PlacementSettings.IntersectionPlacementSymbol);
    if (_VerifyElementList != null && _VerifyElementList.Count > 0)
      _ElementList.AddRange((IEnumerable<Element>) _VerifyElementList);
    if (!TopographySurfaceManagement.VerifyUserCanManipulateElements(_Document, _ElementList))
      return false;
    TopographySurfaceManagement.SetTopoDrawOrder(_Document, ref _nTopoDrawOrder);
    _PlacementSettings.TopoDrawOrder = _nTopoDrawOrder;
    int _nReturnValue = 0;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("MassCreationOnlyMode", ref _nReturnValue))
      ApplicationUtility.Settings.eplSetE_SetSetting("MassCreationOnlyMode", 0);
    if (_nReturnValue == 0)
      epsPointList1 = _ProposedSurface.GetAllVertices();
    List<XYZ> removePointList = new List<XYZ>();
    removePointList.AddRange((IEnumerable<XYZ>) _ProposedSurface.TopographySurface.GetBoundaryPoints().ToList<XYZ>());
    Eps_Leg _OriginaltLeg = Eps_Leg.CopyLeg(_CurrentLeg);
    int num9;
    switch (_PlacementSettings.LocateType)
    {
      case LandcaddID.SoftTerrain:
        Parameter parameter2 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainCutSlopeParameter);
        if (parameter2 != null)
          dCutSlope = 1.0 / parameter2.AsDouble();
        Parameter parameter3 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainFillSlopeParameter);
        if (parameter3 != null)
          dFillSlope = 1.0 / parameter3.AsDouble();
        Parameter parameter4 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainLeftOffsetWidthParameter);
        if (parameter4 != null)
          num5 = parameter4.AsDouble();
        Parameter parameter5 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainRightOffsetWidthParameter);
        if (parameter5 != null)
        {
          num6 = parameter5.AsDouble();
          break;
        }
        break;
      case LandcaddID.Street:
        Parameter parameter6 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCutSlopeParameter);
        if (parameter6 != null)
          dCutSlope = 1.0 / parameter6.AsDouble();
        Parameter parameter7 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetFillSlopeParameter);
        if (parameter7 != null)
          dFillSlope = 1.0 / parameter7.AsDouble();
        double num10 = 0.0;
        Parameter parameter8 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetLaneWidthParameter);
        if (parameter8 != null)
          num10 = parameter8.AsDouble();
        Parameter parameter9 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
        if (parameter9 != null)
        {
          num5 = num10 * (double) parameter9.AsInteger() / 2.0;
          num6 = num10 * (double) parameter9.AsInteger() / 2.0;
        }
        Parameter parameter10 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
        if (parameter10 != null)
        {
          dLeftEdgeAdjustElev = -num5 * parameter10.AsDouble();
          dRightEdgeAdjustElev = -num6 * parameter10.AsDouble();
          _dStreetEdgeAdjustElev = -(num5 + num6) / 2.0 * parameter10.AsDouble();
        }
        Parameter parameter11 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
        if (parameter11 != null && parameter11.AsInteger() != 0)
        {
          double num11 = 0.0;
          double num12 = 0.0;
          double num13 = 0.0;
          Parameter parameter12 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterWidthParameter);
          if (parameter12 != null)
          {
            num11 = parameter12.AsDouble();
            num5 += num11;
            num6 += num11;
            num1 = num11;
          }
          Parameter parameter13 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbWidthParameter);
          if (parameter13 != null)
          {
            num5 += parameter13.AsDouble();
            num6 += parameter13.AsDouble();
            num1 += parameter13.AsDouble();
          }
          Parameter parameter14 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbHeightParameter);
          if (parameter14 != null)
            num13 = parameter14.AsDouble();
          Parameter parameter15 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterSlopeParameter);
          if (parameter15 != null)
            num12 = parameter15.AsDouble();
          dLeftEdgeAdjustElev += num13 - num11 * num12;
          dRightEdgeAdjustElev += num13 - num11 * num12;
          dLeftSubgradeAdjustElev = num13;
          dRightSubgradeAdjustElev = num13;
        }
        Parameter parameter16 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetPavementDepthParameter);
        if (parameter16 != null)
          num7 = -parameter16.AsDouble();
        Parameter parameter17 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetBoulevardWidthParameter);
        if (parameter17 != null)
        {
          dBoulevardWidth = parameter17.AsDouble();
          num5 += dBoulevardWidth;
          num6 += dBoulevardWidth;
          num1 += dBoulevardWidth;
        }
        bIsCrownPresent = true;
        Document _Document1 = _Document;
        EPTransactionContainer transactionContainer1 = _PlacementSettings.TransactionContainer;
        num9 = Convert.ToInt32((object) LandcaddID.Street);
        string _strLandcaddID1 = num9.ToString("000");
        List<FamilyInstanceComponentWrapper> categoryComponents1 = RevitUtility.FindSiteCategoryComponents(_Document1, transactionContainer1, _strLandcaddID1);
        for (int index1 = 0; index1 < categoryComponents1.Count; num9 = index1++)
        {
          if (index1 == 0)
          {
            ppOffsetLegList1 = new Eps_Leg();
            RevitGeometry.OffsetLegList(_CurrentLeg, num6 - num1, 1, ref ppOffsetLegList1, true);
            ppOffsetLegList2 = new Eps_Leg();
            RevitGeometry.OffsetLegList(_CurrentLeg, num5 - num1, 2, ref ppOffsetLegList2, true);
          }
          if (categoryComponents1[index1].InstanceLeg == null)
            categoryComponents1[index1].CreateOriginalLeg(_ProposedSurface);
          if (categoryComponents1[index1].InstanceLeg != null)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents1[index1].InstanceLeg.LegStartPnt, _CurrentLeg.LegStartPnt, num5))
              EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents1[index1].InstanceLeg.LegEndPnt, _CurrentLeg.LegStartPnt, num5);
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents1[index1].InstanceLeg.LegEndPnt, _CurrentLeg.LegEndPnt, num5))
              EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents1[index1].InstanceLeg.LegStartPnt, _CurrentLeg.LegEndPnt, num5);
            int pNumberOfIntersections = 0;
            if (RevitGeometry.eplGeoE_IntersectTwoLegLists(categoryComponents1[index1].InstanceLeg, _CurrentLeg, ref ppPointList, ref pNumberOfIntersections, num5) == 0 && pNumberOfIntersections > 0)
            {
              FamilyInstance existingFamilyInstance = categoryComponents1[index1].GetFirstExistingFamilyInstance();
              if (existingFamilyInstance != null)
              {
                FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance, _PlacementSettings.LocateType);
                if (familyTypeSymbol != null)
                {
                  categoryComponents1[index1].ProposedFamilySymbol = familyTypeSymbol;
                  double num14 = 0.0;
                  Parameter parameter18 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
                  if (parameter18 != null)
                    num14 = parameter18.AsDouble();
                  Parameter parameter19 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
                  if (parameter19 != null)
                    _dExistingOffset = num14 * (double) parameter19.AsInteger();
                  Parameter parameter20 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
                  if (parameter20 != null)
                    _dExistingAdjustSubgradeElev = -_dExistingOffset / 2.0 * parameter20.AsDouble();
                  if (_dExistingOffset > 0.0)
                  {
                    double _dReturnValue1 = 0.0;
                    double _dReturnValue2 = 0.0;
                    bool setting1 = ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultRadius", ref _dReturnValue1);
                    bool setting2 = ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultTransitioningDistance", ref _dReturnValue2);
                    if (!setting1 && !setting2)
                      _dReturnValue1 = 5.0;
                    FamilyInstanceComponentWrapper _CurFamilyInstanceComponentWrapper = categoryComponents1[index1];
                    TopographySurfaceManagement.SetupIntersectionContainersForSiteComponent(_Document, _PlacementSettings.TransactionContainer, _ProposedSurface, categoryComponents1, ref _CurFamilyInstanceComponentWrapper);
                    categoryComponents1[index1] = _CurFamilyInstanceComponentWrapper;
                    Eps_Leg ppOffsetLegList3 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(categoryComponents1[index1].InstanceLeg, _dExistingOffset / 2.0, 1, ref ppOffsetLegList3, true);
                    Eps_Leg ppOffsetLegList4 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(categoryComponents1[index1].InstanceLeg, _dExistingOffset / 2.0, 2, ref ppOffsetLegList4, true);
                    if (!TopographySurfaceManagement.FindIntersectionStationAndProfiles(_CurrentLeg, ppOffsetLegList2, ppOffsetLegList1, categoryComponents1[index1].InstanceLeg, ppOffsetLegList4, ppOffsetLegList3, _dExistingOffset, _dExistingAdjustSubgradeElev, _dReturnValue1, _dReturnValue2, true, true, num1, _Document, _PlacementSettings.TransactionContainer, _PlacementSettings.LocateType, ref _LeftIntersectionStations, ref _CenterIntersectionStations, ref _RightIntersectionStations))
                    {
                      _nTopoDrawOrder = -1;
                      return false;
                    }
                    List<Eps_Point> paPntList = new List<Eps_Point>();
                    paPntList.AddRange((IEnumerable<Eps_Point>) epsPointList1);
                    Eps_Leg ppOffsetLegList5 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(categoryComponents1[index1].InstanceLeg, 0.01, 1, ref ppOffsetLegList5, true);
                    Eps_Leg ppOffsetLegList6 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(categoryComponents1[index1].InstanceLeg, 0.01, 2, ref ppOffsetLegList6, true);
                    Eps_Leg pLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(new List<Eps_Leg>()
                    {
                      ppOffsetLegList5,
                      ppOffsetLegList6
                    });
                    if (pLeg != null && paPntList.Count > 0)
                    {
                      RevitGeometry.GetAllPointsInBoundary(ref paPntList, pLeg, (List<Eps_Leg>) null);
                      collection.AddRange((IEnumerable<Eps_Point>) paPntList);
                    }
                    int _nIntersectionSWStreetMassLastIndex = 0;
                    parameter1 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
                    string _strSiteComponentName = string.Empty;
                    Parameter parameter21 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
                    if (parameter21 != null)
                    {
                      DirectShape directShape = RevitUtility.FindDirectShape(_Document, parameter21.AsString(), ref _nIntersectionSWStreetMassLastIndex);
                      if (directShape != null)
                      {
                        _strSiteComponentName = ((Element) directShape).Name;
                        _Document.Delete(((Element) directShape).Id);
                      }
                      else
                      {
                        FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(_Document, parameter21.AsString(), ref _nIntersectionSWStreetMassLastIndex);
                        if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                        {
                          _strSiteComponentName = ((Element) massFamilyInstance.Symbol.Family).Name;
                          _Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
                        }
                      }
                    }
                    Parameter parameter22 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
                    if (parameter22 != null)
                    {
                      DirectShape directShape = RevitUtility.FindDirectShape(_Document, parameter22.AsString());
                      if (directShape != null)
                      {
                        if (_strSiteComponentName == string.Empty)
                          _strSiteComponentName = ((Element) directShape).Name;
                        _Document.Delete(((Element) directShape).Id);
                      }
                      else
                      {
                        FamilyInstance massFamilyInstance = RevitUtility.FindMassFamilyInstance(_Document, parameter22.AsString());
                        if (massFamilyInstance != null && massFamilyInstance.Symbol != null && massFamilyInstance.Symbol.Family != null)
                        {
                          if (_strSiteComponentName == string.Empty)
                            _strSiteComponentName = ((Element) massFamilyInstance.Symbol.Family).Name;
                          _Document.Delete(((Element) massFamilyInstance.Symbol.Family).Id);
                        }
                      }
                    }
                    if (_strSiteComponentName == string.Empty)
                    {
                      num9 = _nIntersectionSWStreetMassLastIndex++;
                      _strSiteComponentName = $"{EPShared.LocalRM.GetString("IntersectionSWStreetMass")} {Convert.ToString(_nIntersectionSWStreetMassLastIndex)}";
                    }
                    IntersectionContainerComparer containerComparer1 = new IntersectionContainerComparer(true);
                    if (_LeftIntersectionStations.Count > 0 && _LeftIntersectionStations.Count == _RightIntersectionStations.Count)
                    {
                      for (int index2 = 0; index2 < _LeftIntersectionStations.Count; num9 = index2++)
                      {
                        _LeftIntersectionStations[index2].PrimaryPlacementId = ((Element) existingFamilyInstance).UniqueId;
                        _RightIntersectionStations[index2].PrimaryPlacementId = ((Element) existingFamilyInstance).UniqueId;
                        if (_LeftIntersectionStations[index2].IntersectionStations.Count == _RightIntersectionStations[index2].IntersectionStations.Count)
                        {
                          for (int index3 = 0; index3 < _LeftIntersectionStations[index2].IntersectionStations.Count; num9 = index3++)
                          {
                            IntersectionContainer intersectionContainer1 = new IntersectionContainer();
                            intersectionContainer1.StartingIntersection = true;
                            ProfileContainer profileContainer1 = new ProfileContainer();
                            bool isPrimaryLeft1;
                            if (_LeftIntersectionStations[index2].IntersectionStations[index3].PrimaryStation <= _RightIntersectionStations[index2].IntersectionStations[index3].PrimaryStation)
                            {
                              isPrimaryLeft1 = _LeftIntersectionStations[index2].IntersectionStations[index3].IsPrimaryLeft;
                              Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_LeftIntersectionStations, index2, index3, false);
                              profileContainer1.Station = intersectionStationPoint != null && isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList4, ref _dStation1, ref _dOffset) == 1700 || !isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList3, ref _dStation1, ref _dOffset) == 1700 ? _dStation1 : _LeftIntersectionStations[index2].IntersectionStations[index3].PrimaryStation;
                            }
                            else
                            {
                              isPrimaryLeft1 = _RightIntersectionStations[index2].IntersectionStations[index3].IsPrimaryLeft;
                              Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_RightIntersectionStations, index2, index3, false);
                              profileContainer1.Station = intersectionStationPoint != null && isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList4, ref _dStation1, ref _dOffset) == 1700 || !isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList3, ref _dStation1, ref _dOffset) == 1700 ? _dStation1 : _RightIntersectionStations[index2].IntersectionStations[index3].PrimaryStation;
                            }
                            intersectionContainer1.Profiles.Add(profileContainer1);
                            intersectionContainer1.ProfileUsage = !isPrimaryLeft1 ? ProfileUsage.RightOnly : ProfileUsage.LeftOnly;
                            _IntersectionContainers.Add(intersectionContainer1);
                            IntersectionContainer intersectionContainer2 = new IntersectionContainer();
                            intersectionContainer2.StartingIntersection = false;
                            ProfileContainer profileContainer2 = new ProfileContainer();
                            bool isPrimaryLeft2;
                            if (_LeftIntersectionStations[index2].IntersectionStations[index3].PrimaryStation <= _RightIntersectionStations[index2].IntersectionStations[index3].PrimaryStation)
                            {
                              isPrimaryLeft2 = _RightIntersectionStations[index2].IntersectionStations[index3].IsPrimaryLeft;
                              Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_RightIntersectionStations, index2, index3, false);
                              profileContainer2.Station = intersectionStationPoint != null && isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList4, ref _dStation1, ref _dOffset) == 1700 || !isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList3, ref _dStation1, ref _dOffset) == 1700 ? _dStation1 : _RightIntersectionStations[index2].IntersectionStations[index3].PrimaryStation;
                            }
                            else
                            {
                              isPrimaryLeft2 = _LeftIntersectionStations[index2].IntersectionStations[index3].IsPrimaryLeft;
                              Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_LeftIntersectionStations, index2, index3, false);
                              profileContainer2.Station = intersectionStationPoint != null && isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList4, ref _dStation1, ref _dOffset) == 1700 || !isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, ppOffsetLegList3, ref _dStation1, ref _dOffset) == 1700 ? _dStation1 : _LeftIntersectionStations[index2].IntersectionStations[index3].PrimaryStation;
                            }
                            intersectionContainer2.Profiles.Add(profileContainer2);
                            intersectionContainer2.ProfileUsage = !isPrimaryLeft2 ? ProfileUsage.RightOnly : ProfileUsage.LeftOnly;
                            _IntersectionContainers.Add(intersectionContainer2);
                          }
                        }
                      }
                      if (_IntersectionContainers != null && _IntersectionContainers.Count > 0)
                        _IntersectionContainers.Sort((IComparer<IntersectionContainer>) containerComparer1);
                    }
                    if (_IntersectionContainers.Count > 0)
                    {
                      if (categoryComponents1[index1].IntersectionContainerList == null)
                        categoryComponents1[index1].IntersectionContainerList = new List<IntersectionContainer>();
                      categoryComponents1[index1].IntersectionContainerList.AddRange((IEnumerable<IntersectionContainer>) _IntersectionContainers);
                      _IntersectionContainers.Clear();
                    }
                    if (categoryComponents1[index1].IntersectionContainerList != null && categoryComponents1[index1].IntersectionContainerList.Count > 0)
                      categoryComponents1[index1].IntersectionContainerList.Sort((IComparer<IntersectionContainer>) containerComparer1);
                    StreetForm streetForm = new StreetForm(familyTypeSymbol, categoryComponents1[index1].InstanceLeg);
                    streetForm.IntersectionContainers = categoryComponents1[index1].IntersectionContainerList;
                    string empty = string.Empty;
                    string form = streetForm.CreateForm(_Document, _strSiteComponentName, ref empty);
                    if (form != string.Empty && parameter21 != null)
                      parameter21.Set(form);
                    if (empty != string.Empty && parameter22 != null)
                      parameter22.Set(empty);
                    stationContainerList1.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
                    stationContainerList3.AddRange((IEnumerable<IntersectionStationContainer>) _CenterIntersectionStations);
                    stationContainerList2.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
                    IntersectionStationContainerComparer containerComparer2 = new IntersectionStationContainerComparer(true);
                    if (stationContainerList1 != null && stationContainerList1.Count > 0)
                      stationContainerList1.Sort((IComparer<IntersectionStationContainer>) containerComparer2);
                    if (stationContainerList3 != null && stationContainerList3.Count > 0)
                      stationContainerList3.Sort((IComparer<IntersectionStationContainer>) containerComparer2);
                    if (stationContainerList2 != null && stationContainerList2.Count > 0)
                      stationContainerList2.Sort((IComparer<IntersectionStationContainer>) containerComparer2);
                    _LeftIntersectionStations.Clear();
                    _CenterIntersectionStations.Clear();
                    _RightIntersectionStations.Clear();
                  }
                }
              }
            }
          }
        }
        break;
      case LandcaddID.Curb:
        double num15 = 0.0;
        double num16 = 0.0;
        double num17 = 0.0;
        double num18 = 0.0;
        double num19 = 0.0;
        Parameter parameter23 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterWidthParameter);
        if (parameter23 != null)
          num17 = parameter23.AsDouble();
        Parameter parameter24 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbWidthParameter);
        if (parameter24 != null)
          num15 = parameter24.AsDouble();
        if (_PlacementSettings.UseRightSide)
        {
          num6 = num17 + num15;
          num5 = 0.0;
        }
        else
        {
          num5 = num17 + num15;
          num6 = 0.0;
        }
        Parameter parameter25 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbHeightParameter);
        if (parameter25 != null)
          num18 = parameter25.AsDouble();
        Parameter parameter26 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.CurbGutterHeightParameter);
        if (parameter26 != null)
          num16 = parameter26.AsDouble();
        Parameter parameter27 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterSlopeParameter);
        if (parameter27 != null)
          num19 = parameter27.AsDouble();
        if (num6 == 0.0)
        {
          dRightSubgradeAdjustElev = num16 + (num15 + num17) * num19;
          dLeftSubgradeAdjustElev = num16;
        }
        else if (num5 == 0.0)
        {
          dLeftSubgradeAdjustElev = num16 + (num15 + num17) * num19;
          dRightSubgradeAdjustElev = num16;
        }
        _bUseToposurfaceElevation = true;
        _bUseConstantElevation = false;
        num8 = 0.0;
        TopographySurfaceManagement.m_dCurbElevation = num18 - num17 * num19;
        _PlacementSettings.ProjectInnerSlopes = 5;
        break;
      case LandcaddID.Sidewalk:
        Parameter parameter28 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkCutSlopeParameter);
        if (parameter28 != null)
          dCutSlope = 1.0 / parameter28.AsDouble();
        Parameter parameter29 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkFillSlopeParameter);
        if (parameter29 != null)
          dFillSlope = 1.0 / parameter29.AsDouble();
        Parameter parameter30 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkWidthParameter);
        if (parameter30 != null)
        {
          double num20 = parameter30.AsDouble();
          num5 = num20 / 2.0;
          num6 = num20 / 2.0;
        }
        Parameter parameter31 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkPavementDepthParameter);
        if (parameter31 != null)
          num7 = -parameter31.AsDouble();
        Document _Document2 = _Document;
        EPTransactionContainer transactionContainer2 = _PlacementSettings.TransactionContainer;
        num9 = Convert.ToInt32((object) LandcaddID.Sidewalk);
        string _strLandcaddID2 = num9.ToString("000");
        List<FamilyInstanceComponentWrapper> categoryComponents2 = RevitUtility.FindSiteCategoryComponents(_Document2, transactionContainer2, _strLandcaddID2);
        for (int index4 = 0; index4 < categoryComponents2.Count; num9 = index4++)
        {
          if (index4 == 0)
          {
            ppOffsetLegList1 = new Eps_Leg();
            RevitGeometry.OffsetLegList(_CurrentLeg, num6, 1, ref ppOffsetLegList1, true);
            ppOffsetLegList2 = new Eps_Leg();
            RevitGeometry.OffsetLegList(_CurrentLeg, num5, 2, ref ppOffsetLegList2, true);
          }
          if (categoryComponents2[index4].InstanceLeg == null)
            categoryComponents2[index4].CreateOriginalLeg(_ProposedSurface);
          if (categoryComponents2[index4].InstanceLeg != null)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents2[index4].InstanceLeg.LegStartPnt, _CurrentLeg.LegStartPnt, num5))
              EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents2[index4].InstanceLeg.LegEndPnt, _CurrentLeg.LegStartPnt, num5);
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents2[index4].InstanceLeg.LegEndPnt, _CurrentLeg.LegEndPnt, num5))
              EPShared.eplGeoE_ArePntsDuplicates2D(categoryComponents2[index4].InstanceLeg.LegStartPnt, _CurrentLeg.LegEndPnt, num5);
            int pNumberOfIntersections = 0;
            if (RevitGeometry.eplGeoE_IntersectTwoLegLists(categoryComponents2[index4].InstanceLeg, _CurrentLeg, ref ppPointList, ref pNumberOfIntersections, num5) == 0 && pNumberOfIntersections > 0)
            {
              FamilyInstance existingFamilyInstance = categoryComponents2[index4].GetFirstExistingFamilyInstance();
              if (existingFamilyInstance != null)
              {
                FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance, _PlacementSettings.LocateType);
                if (familyTypeSymbol != null)
                {
                  categoryComponents2[index4].ProposedFamilySymbol = familyTypeSymbol;
                  Parameter parameter32 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
                  if (parameter32 != null)
                    _dExistingOffset = parameter32.AsDouble();
                  if (_dExistingOffset > 0.0)
                  {
                    double _dReturnValue3 = 0.0;
                    double _dReturnValue4 = 0.0;
                    bool setting3 = ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultRadius", ref _dReturnValue3);
                    bool setting4 = ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultTransitioningDistance", ref _dReturnValue4);
                    if (!setting3 && !setting4)
                      _dReturnValue3 = 5.0;
                    FamilyInstanceComponentWrapper _CurFamilyInstanceComponentWrapper = categoryComponents2[index4];
                    TopographySurfaceManagement.SetupIntersectionContainersForSiteComponent(_Document, _PlacementSettings.TransactionContainer, _ProposedSurface, categoryComponents2, ref _CurFamilyInstanceComponentWrapper);
                    categoryComponents2[index4] = _CurFamilyInstanceComponentWrapper;
                    if (!TopographySurfaceManagement.FindIntersectionStationAndProfiles(_CurrentLeg, ppOffsetLegList2, ppOffsetLegList1, categoryComponents2[index4].InstanceLeg, _dExistingOffset, 0.0, _dReturnValue3, _dReturnValue4, _Document, _PlacementSettings.TransactionContainer, _PlacementSettings.LocateType, ref _LeftIntersectionStations, ref _CenterIntersectionStations, ref _RightIntersectionStations))
                    {
                      _nTopoDrawOrder = -1;
                      return false;
                    }
                  }
                  if (_LeftIntersectionStations.Count > 0 && _LeftIntersectionStations.Count == _RightIntersectionStations.Count)
                  {
                    for (int index5 = 0; index5 < _LeftIntersectionStations.Count; num9 = index5++)
                    {
                      _LeftIntersectionStations[index5].PrimaryPlacementId = ((Element) existingFamilyInstance).UniqueId;
                      _RightIntersectionStations[index5].PrimaryPlacementId = ((Element) existingFamilyInstance).UniqueId;
                    }
                  }
                  stationContainerList1.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
                  stationContainerList3.AddRange((IEnumerable<IntersectionStationContainer>) _CenterIntersectionStations);
                  stationContainerList2.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
                  IntersectionStationContainerComparer containerComparer = new IntersectionStationContainerComparer(true);
                  if (stationContainerList1 != null && stationContainerList1.Count > 0)
                    stationContainerList1.Sort((IComparer<IntersectionStationContainer>) containerComparer);
                  if (stationContainerList3 != null && stationContainerList3.Count > 0)
                    stationContainerList3.Sort((IComparer<IntersectionStationContainer>) containerComparer);
                  if (stationContainerList2 != null && stationContainerList2.Count > 0)
                    stationContainerList2.Sort((IComparer<IntersectionStationContainer>) containerComparer);
                  _LeftIntersectionStations.Clear();
                  _CenterIntersectionStations.Clear();
                  _RightIntersectionStations.Clear();
                }
              }
            }
          }
        }
        break;
      case LandcaddID.RetainingWall:
        Parameter parameter33 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallCutSlopeParameter);
        if (parameter33 != null)
          dCutSlope = 1.0 / parameter33.AsDouble();
        Parameter parameter34 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallFillSlopeParameter);
        if (parameter34 != null)
          dFillSlope = 1.0 / parameter34.AsDouble();
        Parameter parameter35 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallWidthParameter);
        if (parameter35 != null)
        {
          double num21 = parameter35.AsDouble();
          num5 = num21 / 2.0;
          num6 = num21 / 2.0;
        }
        bool flag1 = false;
        double num22 = 0.0;
        Parameter parameter36 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallSlopeProjectionParameter);
        if (parameter36 != null)
          flag1 = parameter36.AsInteger() == 1;
        Parameter parameter37 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallHeightParameter);
        if (parameter37 != null)
          num22 = parameter37.AsDouble();
        if (flag1)
        {
          if (_PlacementSettings.UseRightSide)
          {
            dRightEdgeAdjustElev = !_bUseToposurfaceElevation ? num22 : _dElevation;
            _PlacementSettings.ProjectInnerSlopes = 3;
          }
          else
          {
            dLeftEdgeAdjustElev = !_bUseToposurfaceElevation ? num22 : _dElevation;
            _PlacementSettings.ProjectInnerSlopes = 2;
          }
        }
        else
          _PlacementSettings.ProjectInnerSlopes = 4;
        dLeftSubgradeAdjustElev = dLeftEdgeAdjustElev;
        dRightSubgradeAdjustElev = dRightEdgeAdjustElev;
        bIsProjectLegToTopo = !_bUseToposurfaceElevation;
        if (_bUseToposurfaceElevation)
        {
          num7 = -(num22 - _dElevation);
          num8 = 0.0;
          break;
        }
        num8 -= num22;
        _dElevation = num22;
        break;
      case LandcaddID.ParkingLot:
        ppOffsetLegList1 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 1, ref ppOffsetLegList1, true);
        Eps_Leg ppOffsetLegList7 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 2, ref ppOffsetLegList7, true);
        _CurrentLeg = RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList7) <= RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1) ? ppOffsetLegList1 : ppOffsetLegList7;
        Parameter parameter38 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.ParkingLotPavementDepthParameter);
        if (parameter38 != null)
        {
          dLeftSubgradeAdjustElev = parameter38.AsDouble();
          dRightSubgradeAdjustElev = parameter38.AsDouble();
        }
        dCutSlope = 0.01;
        dFillSlope = 0.01;
        bIsProjectLegToTopo = true;
        _PlacementSettings.ProjectInnerSlopes = 1;
        break;
    }
    Eps_Leg epsLeg1;
    if (RevitDefines.EQ(num6 + num5, 0.0))
    {
      epsLeg1 = Eps_Leg.CopyLeg(_CurrentLeg);
    }
    else
    {
      ppOffsetLegList1 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, num6, 1, ref ppOffsetLegList1, true);
      Eps_Leg ppOffsetLegList8 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, num5, 2, ref ppOffsetLegList8, true);
      epsLeg1 = Eps_Leg.CopyLeg(ppOffsetLegList1.Reverse());
      Eps_Leg _CompleteLeg1 = new Eps_Leg();
      _CompleteLeg1.Line = new Eps_Line();
      _CompleteLeg1.Line.StartPnt = ppOffsetLegList1.LegEndPnt;
      _CompleteLeg1.Line.EndPnt = ppOffsetLegList8.LegEndPnt;
      epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
      epsLeg1.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList8);
      Eps_Leg _CompleteLeg2 = new Eps_Leg();
      _CompleteLeg2.Line = new Eps_Line();
      _CompleteLeg2.Line.StartPnt = ppOffsetLegList8.LegStartPnt;
      _CompleteLeg2.Line.EndPnt = ppOffsetLegList1.LegStartPnt;
      epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
    }
    if (epsLeg1 != null)
    {
      List<Eps_Point> pointsAtIntervals = epsLeg1.GetPointsAtIntervals(1.0, 1.0);
      for (int index = 0; index < pointsAtIntervals.Count; num9 = index++)
      {
        TopographySurfaceContainer containerContainingPoint = _ProposedSurface.GetSurfaceContainerContainingPoint(pointsAtIntervals[index]);
        if (containerContainingPoint == null)
        {
          epsLeg1.ConvertLegToLineArcArrays(ref aLines2, ref nLineCount2, ref aArcs2, ref nArcCount2, ref aLegOrder2, false);
          int nLineCount3 = 0;
          int nArcCount3 = 0;
          Eps_Line[] aLines3 = (Eps_Line[]) null;
          Eps_Arc[] aArcs3 = (Eps_Arc[]) null;
          int[] aLegOrder3 = (int[]) null;
          if (_ProposedSurface.BoundaryLeg != null)
          {
            _ProposedSurface.BoundaryLeg.ConvertLegToLineArcArrays(ref aLines3, ref nLineCount3, ref aArcs3, ref nArcCount3, ref aLegOrder3, false);
            if (!EPShared.eplGeoE_IsLegListInsideLegList(aLines2, nLineCount2, aArcs2, nArcCount2, aLegOrder2, aLines3, nLineCount3, aArcs3, nArcCount3, aLegOrder3, 1E-05))
            {
              int num23 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("LineSegmentsOutsideToposurfaceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              _nTopoDrawOrder = -1;
              return false;
            }
          }
        }
        else if (containerContainingPoint.TopographySurfaceType == TopographySurfaceType.BuildingPad)
        {
          int num24 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("LineSegmentsInsideBuildingPadMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          _nTopoDrawOrder = -1;
          return false;
        }
      }
    }
    List<double> _Stations = new List<double>();
    List<Eps_Point> _ApplySurfaceElevationPoints = new List<Eps_Point>();
    if (stationContainerList3.Count > 0)
    {
      for (int index6 = 0; index6 < stationContainerList3.Count; num9 = index6++)
      {
        for (int index7 = 0; index7 < stationContainerList3[index6].IntersectionStations.Count; num9 = index7++)
        {
          _Stations.Add(stationContainerList3[index6].IntersectionStations[index7].Station);
          Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(stationContainerList3, index6, index7, false);
          if (intersectionStationPoint != null)
            _ApplySurfaceElevationPoints.Add(intersectionStationPoint);
        }
      }
    }
    _CurrentLeg = _CurrentLeg.SplitLegAtStations(_Stations);
    if (_PlacementSettings.LocateType != LandcaddID.FeatureLine && _PlacementSettings.LocateType != LandcaddID.PointWipeout)
    {
      Parameter parameter39 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.LinearIncrementParameter);
      if (parameter39 != null)
        num3 = parameter39.AsDouble();
      if (RevitDefines.LT(num3, 0.0833333))
        num3 = 0.0833333;
      Parameter parameter40 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.CurveIncrementParameter);
      if (parameter40 != null)
        num4 = RevitGeometry.RadiansToDecimalDegrees(EPShared.eplGeoE_NormalizeRadians(parameter40.AsDouble()));
      if (RevitDefines.LT(num4, 1.0))
        num4 = 1.0;
      _CurrentLeg.ConvertLegToLineArcArrays(ref aLines1, ref nLineCount1, ref aArcs1, ref nArcCount1, ref aLegOrder1, _ProposedSurface, _bUseToposurfaceElevation, _bUseConstantElevation, num8, true, _ApplySurfaceElevationPoints);
    }
    else if (_PlacementSettings.LocateType == LandcaddID.FeatureLine)
    {
      num3 = _PlacementSettings.LinearPointInterval;
      if (RevitDefines.LT(num3, 0.0833333))
        num3 = 0.0833333;
    }
    if (_PlacementSettings.LocateType == LandcaddID.Curb)
    {
      _CurrentLeg = _CurrentLeg.ApplyElevationsToLeg(_ProposedSurface, _bUseToposurfaceElevation, _bUseConstantElevation, TopographySurfaceManagement.m_dCurbElevation);
    }
    else
    {
      _CurrentLeg = !RevitDefines.EQ(num2, 0.0) ? _CurrentLeg.ApplyElevationsToLeg(num8, num2) : _CurrentLeg.ApplyElevationsToLeg(_ProposedSurface, _bUseToposurfaceElevation, _bUseConstantElevation, num8, _ApplySurfaceElevationPoints);
      if (_PlacementSettings.LocateType == LandcaddID.FeatureLine && _bUseToposurfaceElevation)
      {
        Eps_Point legStartPnt = _CurrentLeg.LegStartPnt;
        Eps_Point legEndPnt = _CurrentLeg.LegEndPnt;
        for (Eps_Leg epsLeg2 = _CurrentLeg; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
          legEndPnt = epsLeg2.LegEndPnt;
        _PlacementSettings.Grade = num2 = (legEndPnt.z - legStartPnt.z) / RevitGeometry.eplGeoE_CalcLegListLength(_CurrentLeg);
      }
    }
    TopographySurfaceManagement.FindOffsetLegWrappers(_OriginaltLeg, _CurrentLeg, stationContainerList1, stationContainerList3, stationContainerList2, _PlacementSettings.LocateType, num5, num6, num1, num7, _dStreetEdgeAdjustElev, ref _OffsetLegWrappers, ref _IntersectionContainers);
    if (stationContainerList1.Count > 0 && stationContainerList1.Count == stationContainerList2.Count)
    {
      if (_PlacementSettings.IntersectionStations == null)
        _PlacementSettings.IntersectionStations = new List<IntersectionStationContainer>();
      _PlacementSettings.IntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) stationContainerList1);
      _PlacementSettings.IntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) stationContainerList2);
    }
    if (ApplicationUtility.UseMass && _PlacementSettings.LocateType != LandcaddID.SoftTerrain && _PlacementSettings.LocateType != LandcaddID.ParkingLot && _PlacementSettings.LocateType != LandcaddID.FeatureLine && _PlacementSettings.LocateType != LandcaddID.PointWipeout)
    {
      Category category = _Document.Settings.Categories[(BuiltInCategory) -2003400];
      if (category != null && !category[_Document.ActiveView])
      {
        WarningOptionsForm warningOptionsForm = new WarningOptionsForm(EPShared.LocalRM.GetString("InformationString"), _Document.PathName, "MassVisibility", EPShared.LocalRM.GetString("PickViewOptionForMassMessage"), new List<string>()
        {
          EPShared.LocalRM.GetString("ShowMassInAllViewsOption"),
          EPShared.LocalRM.GetString("ShowMassInActiveViewOption")
        }, -1, true);
        int num25 = (int) warningOptionsForm.ShowDialog();
        if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("ShowMassInAllViewsOption"), true) == 0)
        {
          RevitUtility.ShowCategoryInAllViews(_Document, (BuiltInCategory) -2003400);
        }
        else
        {
          try
          {
            category[_Document.ActiveView] = true;
          }
          catch
          {
            ElementId viewTemplateId = _Document.ActiveView.ViewTemplateId;
            if (ElementId.op_Inequality(viewTemplateId, ElementId.InvalidElementId))
            {
              ViewPlan element1 = _Document.GetElement(viewTemplateId) as ViewPlan;
              List<ElementId> list = ElementTransformUtils.CopyElement(_Document, viewTemplateId, XYZ.Zero).ToList<ElementId>();
              if (list.Count > 0)
              {
                ViewPlan element2 = _Document.GetElement(list[0]) as ViewPlan;
                string str = ((Element) element1).Name + "-Site Designer";
                FilteredElementCollector source = new FilteredElementCollector(_Document).OfClass(typeof (View));
                int num26 = 0;
                string testViewName = str;
                while (((IEnumerable) source).Cast<View>().Where<View>((Func<View, bool>) (f => f.IsTemplate && ((Element) f).Name.Equals(testViewName))).Count<View>() > 0)
                {
                  ++num26;
                  testViewName = str + num26.ToString();
                }
                if (num26 > 0)
                  str += num26.ToString();
                ((Element) element2).Name = str;
                _Document.ActiveView.ViewTemplateId = ((Element) element2).Id;
                category[(View) element2] = true;
              }
            }
          }
        }
      }
    }
    switch (_PlacementSettings.LocateType)
    {
      case LandcaddID.Street:
        StreetForm streetForm1 = new StreetForm(_PlacementSettings.Type, _CurrentLeg);
        streetForm1.IntersectionContainers = _IntersectionContainers;
        string empty1 = string.Empty;
        _PlacementSettings.LoftFormID = streetForm1.CreateForm(_Document, _PlacementSettings.Name, ref empty1);
        _PlacementSettings.AdditionalLoftFormID = empty1;
        if (_PlacementSettings.LoftFormID == null || _PlacementSettings.LoftFormID == string.Empty)
        {
          _nTopoDrawOrder = -1;
          return false;
        }
        break;
      case LandcaddID.Curb:
        CurbForm curbForm = new CurbForm(_PlacementSettings.Type, _CurrentLeg, false, _PlacementSettings.UseRightSide);
        _PlacementSettings.LoftFormID = curbForm.CreateForm(_Document, _PlacementSettings.Name, false, 0.0);
        if (_PlacementSettings.LoftFormID == null || _PlacementSettings.LoftFormID == string.Empty)
        {
          _nTopoDrawOrder = -1;
          return false;
        }
        break;
      case LandcaddID.Sidewalk:
        SidewalkForm sidewalkForm = new SidewalkForm(_PlacementSettings.Type, _CurrentLeg);
        sidewalkForm.IntersectionContainers = _IntersectionContainers;
        _PlacementSettings.LoftFormID = sidewalkForm.CreateForm(_Document, _PlacementSettings.Name);
        if (_PlacementSettings.LoftFormID == null || _PlacementSettings.LoftFormID == string.Empty)
        {
          _nTopoDrawOrder = -1;
          return false;
        }
        break;
      case LandcaddID.RetainingWall:
        RetainingWallForm retainingWallForm = new RetainingWallForm(_PlacementSettings.Type, _CurrentLeg, _dElevation);
        _PlacementSettings.LoftFormID = retainingWallForm.CreateForm(_Document, _PlacementSettings.Name);
        if (_PlacementSettings.LoftFormID == null || _PlacementSettings.LoftFormID == string.Empty)
        {
          _nTopoDrawOrder = -1;
          return false;
        }
        break;
    }
    if (_nReturnValue == 0)
    {
      ProgressBarForm _ProgressFrm = new ProgressBarForm();
      _ProgressFrm.ShowForm();
      _ProgressFrm.Refresh();
      _ProgressFrm.MinValue = 0;
      _ProgressFrm.MaxValue = 5;
      _ProgressFrm.Message = EPShared.LocalRM.GetString("ProgressBarGradingToposurfaceMessage");
      Eps_Leg _CatchLineLeg = (Eps_Leg) null;
      Eps_Leg _FeatureLineLeg = (Eps_Leg) null;
      Eps_Leg _OriginalBoundaryLeg = (Eps_Leg) null;
      bool flag2 = false;
      if (epsPointList1.Count == 0)
      {
        Eps_Point pMinPnt = new Eps_Point();
        Eps_Point epsPoint = new Eps_Point();
        RevitGeometry.eplGeoE_FindMinMaxOfLineArcList(aLines1, nLineCount1, aArcs1, nArcCount1, ref pMinPnt, ref epsPoint);
        Eps_Point _NewPnt = new Eps_Point(pMinPnt.x, pMinPnt.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z);
        epsPoint = new Eps_Point(epsPoint.x, epsPoint.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z);
        double num27 = num5;
        if (num27 < num6)
          num27 = num6;
        double num28 = dCutSlope;
        if (num28 > dFillSlope)
          num28 = dFillSlope;
        double num29 = 100.0 / num28;
        double num30 = 0.0;
        for (int index = 0; index < nLineCount1; num9 = index++)
        {
          if (aLines1[index].StartPnt.z > num30)
            num30 = aLines1[index].StartPnt.z;
          if (aLines1[index].EndPnt.z > num30)
            num30 = aLines1[index].EndPnt.z;
        }
        for (int index = 0; index < nArcCount1; num9 = index++)
        {
          if (aArcs1[index].StartPnt.z > num30)
            num30 = aArcs1[index].StartPnt.z;
          if (aArcs1[index].EndPnt.z > num30)
            num30 = aArcs1[index].EndPnt.z;
        }
        double num31 = num30 * num29;
        double _dDirection = 0.0;
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_NewPnt, epsPoint, ref _dDirection);
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), num31 + num27 + 1.0, ref _NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, _dDirection, num31 + num27 + 1.0, ref epsPoint);
        epsPointList1.Add(_NewPnt);
        epsPointList1.Add(new Eps_Point(_NewPnt.x, epsPoint.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z));
        epsPointList1.Add(epsPoint);
        epsPointList1.Add(new Eps_Point(epsPoint.x, _NewPnt.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z));
      }
      else
        flag2 = true;
      if (_PlacementSettings.LocateType != LandcaddID.FeatureLine && _PlacementSettings.LocateType != LandcaddID.PointWipeout)
      {
        SDTimer sdTimer = new SDTimer("Cal_TIN", _Document.Application);
        sdTimer.Start();
        TopographySurfaceManagement.GetToposurfacePoints(_CurrentLeg, aLines1, nLineCount1, aArcs1, nArcCount1, aLegOrder1, _OffsetLegWrappers, _Document.PathName, epsPointList1, num3, num4, _dArcPointInterval, num5, num6, dBoulevardWidth, dCutSlope, dFillSlope, _PlacementSettings.ProjectInnerSlopes, num7, bIsCrownPresent, bIsProjectLegToTopo, dLeftEdgeAdjustElev, dRightEdgeAdjustElev, dLeftSubgradeAdjustElev, dRightSubgradeAdjustElev, ref _AddPointList, ref _FeatureLineLeg, ref _CatchLineLeg, ref _OriginalBoundaryLeg, ref _CrownPointList, _ProgressFrm);
        sdTimer.Stop();
      }
      else if (_PlacementSettings.LocateType == LandcaddID.FeatureLine)
      {
        _ProgressFrm.UpdateProgressBar(1);
        double _dDistance = 0.0;
        double num32 = 0.0;
        Eps_Point _StaOffPnt = (Eps_Point) null;
        for (Eps_Leg epsLeg3 = _CurrentLeg; epsLeg3 != null; epsLeg3 = epsLeg3.Next)
        {
          double _dStation2 = 0.0;
          if (epsLeg3.Line != null)
          {
            EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg3.Line.StartPnt, epsLeg3.Line.EndPnt, ref _dDistance);
            for (; _dStation2 < _dDistance; _dStation2 += num3)
            {
              EPShared.eplGeoE_FindStaOffPointAlongLine(epsLeg3.Line, _dStation2, 0.0, ref _StaOffPnt);
              double num33 = num2 * (num32 + _dStation2);
              _StaOffPnt.z = _CurrentLeg.LegStartPnt.z + num33;
              _AddPointList.Add(_StaOffPnt);
            }
          }
          else if (epsLeg3.Arc != null)
          {
            for (_dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg3.Arc.Radius, epsLeg3.Arc.Delta); _dStation2 < _dDistance; _dStation2 += num3)
            {
              EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg3.Arc, _dStation2, 0.0, ref _StaOffPnt);
              double num34 = num2 * (num32 + _dStation2);
              _StaOffPnt.z = _CurrentLeg.LegStartPnt.z + num34;
              _AddPointList.Add(_StaOffPnt);
            }
          }
          num32 += _dDistance;
          if (epsLeg3.Next == null)
          {
            _StaOffPnt = _CurrentLeg.LegEndPnt;
            double num35 = num2 * num32;
            _StaOffPnt.z = _CurrentLeg.LegStartPnt.z + num35;
            _AddPointList.Add(_StaOffPnt);
          }
        }
      }
      _ProgressFrm.SetMaxValue();
      Thread.Sleep(300);
      _ProgressFrm.Close();
      ProgressBarForm progressBarForm = new ProgressBarForm();
      progressBarForm.ShowForm();
      progressBarForm.Refresh();
      progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarUpdatingModelMessage");
      progressBarForm.MinValue = 0;
      progressBarForm.MaxValue = 15;
      List<FamilyInstance> placementFamilyInstances = TopographySurfaceManagement.GetSiteComponentPlacementFamilyInstances(_Document, ((Element) _ProposedSurface.TopographySurface).UniqueId);
      List<Eps_Point> epsPointList2 = new List<Eps_Point>();
      _PlacementSettings.TransactionContainer.BeginTransaction();
      List<Eps_Point> list;
      if (flag2)
      {
        if (_PlacementSettings.LocateType == LandcaddID.PointWipeout)
          _CatchLineLeg = Eps_Leg.CopyLeg(_CurrentLeg);
        TopographySurfaceContainer surfaceContainer = _ProposedSurface;
        progressBarForm.UpdateProgressBar(3);
        List<Eps_Point> allVertices = surfaceContainer.GetAllVertices();
        RevitGeometry.RemoveAllPointsInBoundary(ref allVertices, _FeatureLineLeg);
        RevitGeometry.RemoveAllPointsInBoundary(ref allVertices, _CatchLineLeg);
        RevitGeometry.RemoveAllPointsInBoundary(ref allVertices, _OriginalBoundaryLeg);
        if (_PlacementSettings.ProjectInnerSlopes == 1)
          RevitGeometry.RemoveAllPointsInBoundary(ref allVertices, _CurrentLeg);
        if (_AddPointList.Count > 0)
          allVertices.AddRange((IEnumerable<Eps_Point>) _AddPointList);
        if (_CrownPointList != null && _CrownPointList.Count > 0)
          allVertices.AddRange((IEnumerable<Eps_Point>) _CrownPointList);
        if (collection != null && collection.Count > 0)
          allVertices.AddRange((IEnumerable<Eps_Point>) collection);
        progressBarForm.UpdateProgressBar(1);
        list = allVertices.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
        bool flag3 = false;
        bool flag4 = false;
        for (int index8 = 0; index8 < list.Count; num9 = index8++)
        {
          if (list[index8] != null)
          {
            for (int index9 = 0; index9 < surfaceContainer.SubregionBuildingPadList.Count; num9 = index9++)
            {
              if (surfaceContainer.SubregionBuildingPadList[index9] != null)
              {
                if (surfaceContainer.SubregionBuildingPadList[index9].BoundaryLeg != null && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(list[index8], surfaceContainer.SubregionBuildingPadList[index9].BoundaryLeg, ref _dStation1, ref _dOffset) == 1700 && Math.Abs(_dOffset) <= 0.001)
                {
                  flag4 = true;
                  break;
                }
                if (surfaceContainer.SubregionBuildingPadList[index9].GetSurfaceContainerContainingPoint(list[index8]) != null)
                {
                  if (surfaceContainer.SubregionBuildingPadList[index9].TopographySurfaceType == TopographySurfaceType.Subregion)
                  {
                    flag3 = true;
                    break;
                  }
                  flag4 = true;
                  break;
                }
              }
            }
            if (flag3)
              xyzList2.Add(list[index8].XYZ);
            else if (!flag4)
              xyzList1.Add(list[index8].XYZ);
          }
          flag4 = false;
          flag3 = false;
        }
        progressBarForm.UpdateProgressBar(1);
        if (xyzList1.Count > 0)
        {
          TopographySurfaceManagement.RemoveDuplicateXY(ref xyzList1);
          TopographySurfaceManagement.RemoveOriginalTopoPoints(removePointList, ref xyzList1);
          _PlacementSettings.TransactionContainer.EndTransaction();
          string name = _PlacementSettings.TransactionContainer.GetName();
          _PlacementSettings.TransactionContainer.Commit();
          IList<XYZ> interiorPoints = _ProposedSurface.TopographySurface.GetInteriorPoints();
          SDTimer sdTimer1 = new SDTimer("StartTopographyEditScope", _Document.Application);
          sdTimer1.Start();
          _PlacementSettings.TransactionContainer.StartTopographyEditScope(name, ((Element) _ProposedSurface.TopographySurface).Id);
          sdTimer1.Stop();
          SDTimer sdTimer2 = new SDTimer("Point_Update_Create", _Document.Application);
          sdTimer2.Start();
          SDTimer sdTimer3 = new SDTimer("Traverse_Point", _Document.Application);
          sdTimer3.Start();
          HashSet<XYZ> xyzSet = new HashSet<XYZ>((IEnumerable<XYZ>) interiorPoints, (IEqualityComparer<XYZ>) new XYZEqualityComparer());
          for (int index = xyzList1.Count - 1; index >= 0; num9 = index--)
          {
            if (xyzSet.Contains(xyzList1[index]))
            {
              xyzSet.Remove(xyzList1[index]);
              xyzList1.RemoveAt(index);
            }
          }
          sdTimer3.Stop();
          _PlacementSettings.TransactionContainer.Start("Update Topo Points");
          try
          {
            if (xyzSet.Count <= xyzList1.Count)
            {
              int index = 0;
              foreach (XYZ xyz in xyzSet)
              {
                _ProposedSurface.TopographySurface.MovePoint(xyz, xyzList1[index]);
                num9 = index++;
              }
              List<XYZ> xyzList3 = new List<XYZ>();
              for (; index < xyzList1.Count; ++index)
                xyzList3.Add(xyzList1[index]);
              if (xyzList3.Count > 0)
                _ProposedSurface.TopographySurface.AddPoints((IList<XYZ>) xyzList3);
            }
            else
            {
              int index = 0;
              int count = xyzList1.Count;
              List<XYZ> xyzList4 = new List<XYZ>();
              foreach (XYZ xyz in xyzSet)
              {
                if (index < count)
                  _ProposedSurface.TopographySurface.MovePoint(xyz, xyzList1[index]);
                else
                  xyzList4.Add(xyz);
                num9 = index++;
              }
              if (xyzList4.Count > 0)
                _ProposedSurface.TopographySurface.DeletePoints((IList<XYZ>) xyzList4);
            }
          }
          catch (Exception ex)
          {
            TaskDialog.Show("Exception", EPShared.LocalRM.GetString("RevitExceptionError"));
          }
          _PlacementSettings.TransactionContainer.Commit();
          sdTimer2.Stop();
          TopographyEditFailuresPreprocessor failuresPreprocessor = new TopographyEditFailuresPreprocessor();
          SDTimer sdTimer4 = new SDTimer("CommitTopographyEditScope", _Document.Application);
          sdTimer4.Start();
          _PlacementSettings.TransactionContainer.CommitTopographyEditScope(ref failuresPreprocessor);
          sdTimer4.Stop();
          _PlacementSettings.TransactionContainer.Start(name);
          _PlacementSettings.TransactionContainer.BeginTransaction();
          _ProposedSurface.Refresh();
          _Document.Regenerate();
          progressBarForm.UpdateProgressBar(7);
          if (_TopoPlacementFamilyInstance != null)
          {
            Parameter parameter41 = ((Element) _TopoPlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
            if (parameter41 != null && !((APIObject) parameter41).IsReadOnly)
              parameter41.Set(((Element) _ProposedSurface.TopographySurface).UniqueId);
          }
        }
        if (surfaceContainer.SubregionBuildingPadList != null && surfaceContainer.SubregionBuildingPadList.Count > 0)
        {
          List<TopographySurfaceContainer> allMainSurfaces = TopographySurfaceManagement.FindAllMainSurfaces(_Document, true);
          Eps_Point toposurfaceAdjustmentPoint = TopographySurfaceManagement.FindToposurfaceAdjustmentPoint(_ProposedSurface, allMainSurfaces);
          ElementTransformUtils.MoveElement(_Document, ((Element) _ProposedSurface.TopographySurface).Id, toposurfaceAdjustmentPoint.XY);
          List<TopographySurfaceContainer> _SubregionList = new List<TopographySurfaceContainer>();
          List<ElementId> elementIdList = new List<ElementId>();
          for (int index = 0; index < surfaceContainer.SubregionBuildingPadList.Count; num9 = index++)
          {
            if (surfaceContainer.SubregionBuildingPadList[index] != null)
            {
              if (surfaceContainer.SubregionBuildingPadList[index].TopographySurface != null)
              {
                elementIdList.Add(((Element) surfaceContainer.SubregionBuildingPadList[index].TopographySurface).Id);
                if (surfaceContainer.SubregionBuildingPadList[index].TopographySurfaceType == TopographySurfaceType.Subregion)
                  _SubregionList.Add(surfaceContainer.SubregionBuildingPadList[index]);
              }
              else if (surfaceContainer.SubregionBuildingPadList[index].BuildingPad != null)
                elementIdList.Add(((Element) surfaceContainer.SubregionBuildingPadList[index].BuildingPad).Id);
            }
          }
          List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>> genericModelList = TopographySurfaceManagement.FindPlantMixGenericModelList(_Document, _SubregionList);
          List<ElementId> _NewElementIds = (List<ElementId>) null;
          try
          {
            _NewElementIds = LinearArray.ArrayElementsWithoutAssociation(_Document, _Document.ActiveView, (ICollection<ElementId>) elementIdList.ToArray(), 2, toposurfaceAdjustmentPoint.XY, (ArrayAnchorMember) 0).ToList<ElementId>();
          }
          catch (Exception ex)
          {
            switch (ex)
            {
              case AccessViolationException _:
              case InvalidOperationException _:
                _PlacementSettings.TransactionContainer.EndTransaction();
                progressBarForm.SetMaxValue();
                Thread.Sleep(300);
                progressBarForm.Close();
                int num36 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SubregionBuildingPadBoundaryErrorMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                _nTopoDrawOrder = -1;
                return false;
            }
          }
          _Document.Delete(((Element) surfaceContainer.TopographySurface).Id);
          ElementTransformUtils.MoveElement(_Document, ((Element) _ProposedSurface.TopographySurface).Id, new XYZ(-toposurfaceAdjustmentPoint.x, -toposurfaceAdjustmentPoint.y, 0.0));
          if (xyzList2.Count > 0)
            _ProposedSurface.TopographySurface.AddPoints((IList<XYZ>) xyzList2);
          List<TopographySurfaceContainer> surfaceContainers = TopographySurfaceManagement.FindNewTopographySurfaceContainers(_Document, _NewElementIds);
          TopographySurfaceManagement.UpdatePlantMixGenericModelList(genericModelList, surfaceContainers);
          if (surfaceContainers != null && surfaceContainers.Count > 0)
            _ProposedSurface.SubregionBuildingPadList.AddRange((IEnumerable<TopographySurfaceContainer>) surfaceContainers);
        }
        xyzList1.Clear();
        progressBarForm.UpdateProgressBar(3);
        progressBarForm.SetMaxValue();
        Thread.Sleep(300);
        progressBarForm.Close();
      }
      else
      {
        list = _AddPointList.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
        for (int index = 0; index < list.Count; num9 = index++)
          xyzList1.Add(_AddPointList[index].XYZ);
        progressBarForm.UpdateProgressBar(1);
        if (xyzList1.Count > 0)
        {
          TopographySurfaceManagement.RemoveDuplicateXY(ref xyzList1);
          _Document.Regenerate();
          progressBarForm.UpdateProgressBar(14);
        }
        progressBarForm.SetMaxValue();
        Thread.Sleep(300);
        progressBarForm.Close();
      }
      for (int index = 0; index < placementFamilyInstances.Count; num9 = index++)
      {
        FamilyInstance familyInstance = placementFamilyInstances[index];
        if (familyInstance != null)
        {
          LandcaddID landcaddId = LandcaddID.SoftTerrain;
          Parameter parameter42 = ((Element) familyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
          if (parameter42 != null)
          {
            foreach (int num37 in Enum.GetValues(typeof (LandcaddID)))
            {
              if (string.Compare(parameter42.AsString(), num37.ToString("000"), true) == 0)
              {
                landcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num37);
                break;
              }
            }
          }
          switch (landcaddId)
          {
            case LandcaddID.Curb:
              Parameter parameter43 = ((Element) familyInstance).LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
              if (parameter43 != null)
              {
                parameter43.Set(((Element) _ProposedSurface.TopographySurface).UniqueId);
                continue;
              }
              continue;
            case LandcaddID.ParkingLot:
              Parameter parameter44 = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
              if (parameter44 != null)
              {
                parameter44.Set(((Element) _ProposedSurface.TopographySurface).UniqueId);
                continue;
              }
              continue;
            default:
              continue;
          }
        }
      }
      if (_PlacementSettings.LocateType == LandcaddID.Curb)
        _PlacementSettings.ParentTopoSurfaceID = ((Element) _ProposedSurface.TopographySurface).UniqueId;
      if ((_PlacementSettings.LocateType == LandcaddID.Curb || _PlacementSettings.LocateType == LandcaddID.ParkingLot) && _CurrentLeg.IsLegClosed())
      {
        List<Eps_Point> epsPointList3 = new List<Eps_Point>();
        if (_PlacementSettings.LocateType == LandcaddID.Curb)
        {
          List<Eps_Point> pointsAtIntervals = _CurrentLeg.GetPointsAtIntervals(num3, 1.0);
          TopographySurface additionalTopoSurface = TopographySurfaceManagement.CreateAdditionalTopoSurface(_Document, _PlacementSettings, pointsAtIntervals, _ProposedSurface);
          if (additionalTopoSurface != null)
            _PlacementSettings.IslandSurfaceID = ((Element) additionalTopoSurface).UniqueId;
        }
        else if (_PlacementSettings.LocateType == LandcaddID.ParkingLot)
        {
          ppOffsetLegList1 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 1, ref ppOffsetLegList1, true);
          Eps_Leg ppOffsetLegList9 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 2, ref ppOffsetLegList9, true);
          _CurrentLeg = RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList9) >= RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1) ? ppOffsetLegList1 : ppOffsetLegList9;
          List<Eps_Point> topoSurfacePoints = TopographySurfaceManagement.GetParkingLotTopoSurfacePoints(_CurrentLeg, list, num3, num4, _dArcPointInterval, _Document.PathName, _ProposedSurface);
          TopographySurface additionalTopoSurface = TopographySurfaceManagement.CreateAdditionalTopoSurface(_Document, _PlacementSettings, topoSurfacePoints, _ProposedSurface);
          if (additionalTopoSurface != null)
            _PlacementSettings.ParkingLotSurfaceID = ((Element) additionalTopoSurface).UniqueId;
        }
      }
    }
    _PlacementSettings.BeginningElevationList.Clear();
    _PlacementSettings.EndingElevationList.Clear();
    bool flag5 = false;
    bool flag6 = false;
    Eps_Point epsPoint1 = (Eps_Point) null;
    Eps_Point epsPoint2 = (Eps_Point) null;
    for (Eps_Leg epsLeg4 = _CurrentLeg; epsLeg4 != null; epsLeg4 = epsLeg4.Next)
    {
      if (epsLeg4.Line != null)
      {
        epsPoint1 = epsLeg4.Line.StartPnt;
        epsPoint2 = epsLeg4.Line.EndPnt;
      }
      else if (epsLeg4.Arc != null)
      {
        epsPoint1 = epsLeg4.Arc.StartPnt;
        epsPoint2 = epsLeg4.Arc.EndPnt;
      }
      for (int index = 0; index < _ApplySurfaceElevationPoints.Count; num9 = index++)
      {
        if (epsPoint1.IsEqual(_ApplySurfaceElevationPoints[index]))
        {
          flag5 = true;
          if (flag6)
            break;
        }
        else if (epsPoint2.IsEqual(_ApplySurfaceElevationPoints[index]))
        {
          flag6 = true;
          if (flag5)
            break;
        }
      }
      if (epsPoint1 != null && !flag5)
        _PlacementSettings.BeginningElevationList.Add(epsPoint1.z);
      if (epsPoint2 != null && !flag6)
        _PlacementSettings.EndingElevationList.Add(epsPoint2.z);
      flag5 = false;
      flag6 = false;
    }
    RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, _LineElementList);
    _PlacementSettings.TransactionContainer.EndTransaction();
    return true;
  }

  public static void RemoveOriginalTopoPoints(List<XYZ> removePointList, ref List<XYZ> pointXYZList)
  {
    for (int index = 0; index < pointXYZList.Count - 1; ++index)
    {
      Eps_Point epsPoint = new Eps_Point(pointXYZList[index]);
      foreach (XYZ removePoint in removePointList)
      {
        if (new Eps_Point(removePoint).XYZ.IsAlmostEqualTo(epsPoint.XYZ))
        {
          pointXYZList.RemoveAt(index);
          --index;
        }
      }
    }
  }

  private static Eps_Point GetIntersectionStationPoint(
    List<IntersectionStationContainer> _IntersectionStations,
    int nIntIndex,
    int nStaIndex,
    bool _bFindEndsOfIntersection)
  {
    Eps_Point intersectionStationPoint = (Eps_Point) null;
    if (nIntIndex < 0 || nIntIndex >= _IntersectionStations.Count || nStaIndex < 0 || nStaIndex >= _IntersectionStations[nIntIndex].IntersectionStations.Count || _IntersectionStations[nIntIndex].IntersectionStations[nStaIndex].IntersectionLeg == null)
      return intersectionStationPoint;
    if (_IntersectionStations[nIntIndex].IntersectionStations[nStaIndex].IntersectionLeg.Line != null)
    {
      Eps_Line line = _IntersectionStations[nIntIndex].IntersectionStations[nStaIndex].IntersectionLeg.Line;
      intersectionStationPoint = !_IntersectionStations[nIntIndex].IntersectionStations[nStaIndex].StartingIntersection ? line.StartPnt : line.EndPnt;
    }
    else
    {
      Eps_Arc arc = _IntersectionStations[nIntIndex].IntersectionStations[nStaIndex].IntersectionLeg.Arc;
      intersectionStationPoint = !_IntersectionStations[nIntIndex].IntersectionStations[nStaIndex].StartingIntersection ? arc.StartPnt : arc.EndPnt;
    }
    return intersectionStationPoint;
  }

  private static void FindOffsetLegWrappers(
    Eps_Leg _OriginaltLeg,
    Eps_Leg _CurrentLeg,
    List<IntersectionStationContainer> _LeftIntersectionStations,
    List<IntersectionStationContainer> _CenterIntersectionStations,
    List<IntersectionStationContainer> _RightIntersectionStations,
    LandcaddID _LocateType,
    double _dLeftOffsetWidth,
    double _dRightOffsetWidth,
    double _dAdditionalOffsetWidth,
    double _dAdjustSubgradeElev,
    double _dStreetEdgeAdjustElev,
    ref List<OffsetLegWrapper> _OffsetLegWrappers,
    ref List<IntersectionContainer> _IntersectionContainers)
  {
    Eps_Point Pnt = (Eps_Point) null;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    int pNumberOfIntersections = 0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    int num1 = 10;
    if (_LeftIntersectionStations != null && _RightIntersectionStations != null && _CenterIntersectionStations != null && _LeftIntersectionStations.Count > 0 && _LeftIntersectionStations.Count == _RightIntersectionStations.Count && _LeftIntersectionStations.Count == _CenterIntersectionStations.Count)
    {
      Eps_Leg ppOffsetLegList1 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_OriginaltLeg, _dRightOffsetWidth - _dAdditionalOffsetWidth, 1, ref ppOffsetLegList1, true);
      Eps_Leg ppOffsetLegList2 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_OriginaltLeg, _dLeftOffsetWidth - _dAdditionalOffsetWidth, 2, ref ppOffsetLegList2, true);
      Eps_Leg ppOffsetLegList3 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, _dRightOffsetWidth - _dAdditionalOffsetWidth, 1, ref ppOffsetLegList3, true);
      Eps_Leg ppOffsetLegList4 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, _dLeftOffsetWidth - _dAdditionalOffsetWidth, 2, ref ppOffsetLegList4, true);
      for (int index1 = 0; index1 < _CenterIntersectionStations.Count; ++index1)
      {
        if (_LeftIntersectionStations[index1].IntersectionStations.Count == _RightIntersectionStations[index1].IntersectionStations.Count)
        {
          bool flag1 = false;
          List<double> _OffsetStations1 = new List<double>();
          List<double> _OffsetStations2 = new List<double>();
          List<double> _CenterIntStations = new List<double>();
          List<Eps_Leg> _AddLegs1 = new List<Eps_Leg>();
          List<Eps_Leg> _AddLegs2 = new List<Eps_Leg>();
          for (int index2 = 0; index2 < _CenterIntersectionStations[index1].IntersectionStations.Count; ++index2)
          {
            IntersectionContainer intersectionContainer = new IntersectionContainer();
            intersectionContainer.StartingIntersection = _CenterIntersectionStations[index1].IntersectionStations[index2].StartingIntersection;
            if (index2 == 0)
              flag1 = intersectionContainer.StartingIntersection;
            bool flag2 = false;
            double num2 = 0.0;
            if (_CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg != null)
            {
              Eps_Line epsLine;
              Eps_Point _Point;
              Eps_Arc epsArc;
              if (_CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Line != null)
              {
                epsLine = _CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Line;
                _Point = intersectionContainer.StartingIntersection ? epsLine.StartPnt : epsLine.EndPnt;
                epsArc = (Eps_Arc) null;
              }
              else
              {
                epsArc = _CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Arc;
                _Point = intersectionContainer.StartingIntersection ? epsArc.StartPnt : epsArc.EndPnt;
                epsLine = (Eps_Line) null;
              }
              Pnt = new Eps_Point();
              if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _CurrentLeg, ref _dStation, ref _dOffset) == 1700 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentLeg, _dStation, _dOffset, ref Pnt) == 0)
              {
                flag2 = true;
                num2 = Pnt.z;
                if (epsLine != null)
                {
                  if (!intersectionContainer.StartingIntersection)
                    epsLine.EndPnt.z = num2;
                  else
                    epsLine.StartPnt.z = num2;
                }
                if (epsArc != null)
                {
                  if (!intersectionContainer.StartingIntersection)
                    epsArc.EndPnt.z = num2;
                  else
                    epsArc.StartPnt.z = num2;
                  epsArc.RadiusPnt.z = (epsArc.StartPnt.z + epsArc.EndPnt.z) / 2.0;
                }
              }
              _CenterIntStations.Add(_CenterIntersectionStations[index1].IntersectionStations[index2].Station);
            }
            if (_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg != null)
            {
              Eps_Line epsLine;
              Eps_Point _Point;
              Eps_Arc epsArc;
              if (_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Line != null)
              {
                epsLine = _LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Line;
                _Point = intersectionContainer.StartingIntersection ? epsLine.StartPnt : epsLine.EndPnt;
                epsArc = (Eps_Arc) null;
              }
              else
              {
                epsArc = _LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Arc;
                _Point = intersectionContainer.StartingIntersection ? epsArc.StartPnt : epsArc.EndPnt;
                epsLine = (Eps_Line) null;
              }
              if (!flag2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, ppOffsetLegList4, ref _dStation, ref _dOffset) == 1700)
              {
                Pnt = new Eps_Point();
                if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(ppOffsetLegList4, _dStation, _dOffset, ref Pnt) == 0)
                  num2 = Pnt.z;
              }
              if (epsLine != null)
              {
                if (!intersectionContainer.StartingIntersection)
                  epsLine.EndPnt.z = num2 + _dStreetEdgeAdjustElev;
                else
                  epsLine.StartPnt.z = num2 + _dStreetEdgeAdjustElev;
              }
              if (epsArc != null)
              {
                if (!intersectionContainer.StartingIntersection)
                  epsArc.EndPnt.z = num2 + _dStreetEdgeAdjustElev;
                else
                  epsArc.StartPnt.z = num2 + _dStreetEdgeAdjustElev;
                epsArc.RadiusPnt.z = (epsArc.StartPnt.z + epsArc.EndPnt.z) / 2.0;
              }
              intersectionContainer.LeftOffsetLeg = _LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg;
              if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionContainer.LeftOffsetLeg.LegStartPnt, ppOffsetLegList2, ref _dStation, ref _dOffset, true) == 1700)
                _OffsetStations1.Add(_dStation);
              else if (_dStation < 0.0)
                _OffsetStations1.Add(0.0);
              else if (_dStation > RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2))
                _OffsetStations1.Add(RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2));
              _AddLegs1.Add(intersectionContainer.LeftOffsetLeg.MoveLeg(0.0, 0.0, -_dStreetEdgeAdjustElev));
              double num3 = RevitGeometry.eplGeoE_CalcLegLength(_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg) / (double) (num1 - 1);
              for (int index3 = 0; index3 < num1; ++index3)
              {
                _dOffset = 0.0;
                if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg, num3 * (double) index3, _dOffset, ref Pnt) == 0)
                  intersectionContainer.Profiles.Add(new ProfileContainer()
                  {
                    Points = {
                      Pnt,
                      new Eps_Point(Pnt.x, Pnt.y, Pnt.z + _dAdjustSubgradeElev)
                    }
                  });
              }
            }
            if (_RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg != null)
            {
              Eps_Line epsLine;
              Eps_Point _Point;
              Eps_Arc epsArc;
              if (_RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Line != null)
              {
                epsLine = _RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Line;
                _Point = intersectionContainer.StartingIntersection ? epsLine.StartPnt : epsLine.EndPnt;
                epsArc = (Eps_Arc) null;
              }
              else
              {
                epsArc = _RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.Arc;
                _Point = intersectionContainer.StartingIntersection ? epsArc.StartPnt : epsArc.EndPnt;
                epsLine = (Eps_Line) null;
              }
              if (!flag2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, ppOffsetLegList3, ref _dStation, ref _dOffset) == 1700)
              {
                Pnt = new Eps_Point();
                if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(ppOffsetLegList3, _dStation, _dOffset, ref Pnt) == 0)
                  num2 = Pnt.z;
              }
              if (epsLine != null)
              {
                if (!intersectionContainer.StartingIntersection)
                  epsLine.EndPnt.z = num2 + _dStreetEdgeAdjustElev;
                else
                  epsLine.StartPnt.z = num2 + _dStreetEdgeAdjustElev;
              }
              if (epsArc != null)
              {
                if (!intersectionContainer.StartingIntersection)
                  epsArc.EndPnt.z = num2 + _dStreetEdgeAdjustElev;
                else
                  epsArc.StartPnt.z = num2 + _dStreetEdgeAdjustElev;
                epsArc.RadiusPnt.z = (epsArc.StartPnt.z + epsArc.EndPnt.z) / 2.0;
              }
              intersectionContainer.RightOffsetLeg = _RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg;
              if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionContainer.RightOffsetLeg.LegStartPnt, ppOffsetLegList1, ref _dStation, ref _dOffset, true) == 1700)
                _OffsetStations2.Add(_dStation);
              else if (_dStation < 0.0)
                _OffsetStations2.Add(0.0);
              else if (_dStation > RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1))
                _OffsetStations2.Add(RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1));
              _AddLegs2.Add(intersectionContainer.RightOffsetLeg.MoveLeg(0.0, 0.0, -_dStreetEdgeAdjustElev));
              double num4 = RevitGeometry.eplGeoE_CalcLegLength(_RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg) / (double) (num1 - 1);
              for (int index4 = 0; index4 < num1; ++index4)
              {
                _dOffset = 0.0;
                if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg, num4 * (double) index4, _dOffset, ref Pnt) == 0)
                {
                  intersectionContainer.Profiles[index4].Points.Add(new Eps_Point(Pnt.x, Pnt.y, Pnt.z + _dAdjustSubgradeElev));
                  intersectionContainer.Profiles[index4].Points.Add(Pnt);
                  Eps_Leg pSecondLeg = new Eps_Leg();
                  pSecondLeg.Line = new Eps_Line();
                  pSecondLeg.Line.StartPnt = intersectionContainer.Profiles[index4].Points[0];
                  pSecondLeg.Line.EndPnt = intersectionContainer.Profiles[index4].Points[intersectionContainer.Profiles[index4].Points.Count - 1];
                  if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CurrentLeg, pSecondLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[0], _CurrentLeg, ref _dStation, ref _dOffset) == 1700)
                    intersectionContainer.Profiles[index4].Station = _dStation;
                }
              }
            }
            if (_LocateType == LandcaddID.Street && _CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg != null)
            {
              RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.LegStartPnt, _CurrentLeg, ref _dStation, ref _dOffset);
              for (int index5 = 0; index5 < intersectionContainer.Profiles.Count; ++index5)
              {
                _dOffset = 0.0;
                if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CenterIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg, intersectionContainer.Profiles[index5].Station - _dStation, _dOffset, ref Pnt) == 0)
                {
                  intersectionContainer.Profiles[index5].Points.Insert(2, new Eps_Point(Pnt.x, Pnt.y, Pnt.z + _dAdjustSubgradeElev));
                  intersectionContainer.Profiles[index5].Points.Add(Pnt);
                }
              }
            }
            _IntersectionContainers.Add(intersectionContainer);
          }
          Eps_Leg ppOffsetLegList5;
          if (_AddLegs1.Count > 0)
          {
            _OffsetLegWrappers = RevitGeometry.InsertLegsAtStations(ppOffsetLegList4, _OffsetStations1, _AddLegs1, _CenterIntStations, !flag1);
            for (int index6 = 0; index6 < _OffsetLegWrappers.Count; ++index6)
            {
              ppOffsetLegList5 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_OffsetLegWrappers[index6].OriginalLeg, _dAdditionalOffsetWidth, 2, ref ppOffsetLegList5, true);
              _OffsetLegWrappers[index6].OffsetLeg = ppOffsetLegList5;
              _OffsetLegWrappers[index6].IsLeft = true;
              _OffsetLegWrappers[index6].AdditionalOffsetWidth = _dAdditionalOffsetWidth;
            }
            _OffsetLegWrappers.Reverse();
          }
          if (_AddLegs2.Count > 0)
          {
            List<OffsetLegWrapper> collection = RevitGeometry.InsertLegsAtStations(ppOffsetLegList3, _OffsetStations2, _AddLegs2, _CenterIntStations, !flag1);
            for (int index7 = 0; index7 < collection.Count; ++index7)
            {
              ppOffsetLegList5 = new Eps_Leg();
              RevitGeometry.OffsetLegList(collection[index7].OriginalLeg, _dAdditionalOffsetWidth, 1, ref ppOffsetLegList5, true);
              collection[index7].OffsetLeg = ppOffsetLegList5;
              collection[index7].IsLeft = false;
              collection[index7].AdditionalOffsetWidth = _dAdditionalOffsetWidth;
            }
            _OffsetLegWrappers.AddRange((IEnumerable<OffsetLegWrapper>) collection);
          }
        }
      }
    }
    IntersectionContainerComparer containerComparer = new IntersectionContainerComparer(true);
    if (_IntersectionContainers == null || _IntersectionContainers.Count <= 0)
      return;
    _IntersectionContainers.Sort((IComparer<IntersectionContainer>) containerComparer);
  }

  private static void GetToposurfacePoints(
    Eps_Leg _CurrentLeg,
    Eps_Line[] aLines,
    int nLineCount,
    Eps_Arc[] aArcs,
    int nArcCount,
    int[] aLegOrder,
    List<OffsetLegWrapper> _OffsetLegWrappers,
    string _strPathName,
    List<Eps_Point> TopoPointList,
    double dLinearInterval,
    double dRadialInterval,
    double _dArcPointInterval,
    double dLeftOffsetWidth,
    double dRightOffsetWidth,
    double dBoulevardWidth,
    double dCutSlope,
    double dFillSlope,
    int _nProjectInnerSlopes,
    double dAdjustSubgradeElev,
    bool bIsCrownPresent,
    bool bIsProjectLegToTopo,
    double dLeftEdgeAdjustElev,
    double dRightEdgeAdjustElev,
    double dLeftSubgradeAdjustElev,
    double dRightSubgradeAdjustElev,
    ref List<Eps_Point> _AddPointList,
    ref Eps_Leg _FeatureLineLeg,
    ref Eps_Leg _CatchLineLeg,
    ref Eps_Leg _OriginalBoundaryLeg,
    ref List<Eps_Point> _CrownPointList,
    ProgressBarForm _ProgressFrm)
  {
    List<Eps_Leg> _CatchLinesLegLists1 = new List<Eps_Leg>();
    Eps_Point[] array = TopoPointList.ToArray();
    int count = TopoPointList.Count;
    _CatchLineLeg = (Eps_Leg) null;
    if (_OffsetLegWrappers == null || _OffsetLegWrappers.Count == 0)
    {
      Eps_Point[] _aCutFillPoints = (Eps_Point[]) null;
      int _nNumCutFillPoints = 0;
      Eps_Line[] _aLeftCatchLines = (Eps_Line[]) null;
      int _nNumLeftCatchLines = 0;
      Eps_Line[] _aRightCatchLines = (Eps_Line[]) null;
      int _nNumRightCatchLines = 0;
      Eps_Line[] _aLeftCutFillLines = (Eps_Line[]) null;
      int _nNumLeftCutFillLines = 0;
      Eps_Line[] _aRightCutFillLines = (Eps_Line[]) null;
      int _nNumRightCutFillLines = 0;
      EPSharedExternal.CreateCutAndFillFromTopo(_strPathName, aLines, nLineCount, aArcs, nArcCount, aLegOrder, array, count, dLinearInterval, dRadialInterval, _dArcPointInterval, dLeftOffsetWidth, dRightOffsetWidth, dBoulevardWidth, dCutSlope, dFillSlope, _nProjectInnerSlopes, dAdjustSubgradeElev, bIsCrownPresent, bIsProjectLegToTopo, dLeftEdgeAdjustElev, dRightEdgeAdjustElev, dLeftSubgradeAdjustElev, dRightSubgradeAdjustElev, ref _aCutFillPoints, ref _nNumCutFillPoints, ref _aLeftCatchLines, ref _nNumLeftCatchLines, ref _aRightCatchLines, ref _nNumRightCatchLines, ref _aLeftCutFillLines, ref _nNumLeftCutFillLines, ref _aRightCutFillLines, ref _nNumRightCutFillLines);
      _ProgressFrm?.UpdateProgressBar(1);
      if (_aCutFillPoints != null)
        _AddPointList = ((IEnumerable<Eps_Point>) _aCutFillPoints).ToList<Eps_Point>();
      int[] aLegOrder1 = new int[_nNumLeftCatchLines];
      for (int index = 0; index < _nNumLeftCatchLines; ++index)
      {
        if (index == 0)
          _AddPointList.Add(_aLeftCatchLines[index].StartPnt);
        _AddPointList.Add(_aLeftCatchLines[index].EndPnt);
        aLegOrder1[index] = 0;
      }
      _ProgressFrm?.UpdateProgressBar(1);
      int[] aLegOrder2 = new int[_nNumRightCatchLines];
      for (int index = 0; index < _nNumRightCatchLines; ++index)
      {
        if (index == 0)
          _AddPointList.Add(_aRightCatchLines[index].StartPnt);
        _AddPointList.Add(_aRightCatchLines[index].EndPnt);
        aLegOrder2[index] = 0;
      }
      _ProgressFrm?.UpdateProgressBar(1);
      int[] aLegOrder3 = new int[_nNumLeftCutFillLines];
      for (int index = 0; index < _nNumLeftCutFillLines; ++index)
      {
        if (index == 0)
          _AddPointList.Add(_aLeftCutFillLines[index].StartPnt);
        _AddPointList.Add(_aLeftCutFillLines[index].EndPnt);
        aLegOrder3[index] = 0;
      }
      _ProgressFrm?.UpdateProgressBar(1);
      int[] aLegOrder4 = new int[_nNumRightCutFillLines];
      for (int index = 0; index < _nNumRightCutFillLines; ++index)
      {
        if (index == 0)
          _AddPointList.Add(_aRightCutFillLines[index].StartPnt);
        _AddPointList.Add(_aRightCutFillLines[index].EndPnt);
        aLegOrder4[index] = 0;
      }
      _ProgressFrm?.UpdateProgressBar(1);
      Eps_Leg leg1 = Eps_Leg.ConvertLineArcArraysToLeg(_aLeftCatchLines, _nNumLeftCatchLines, new Eps_Arc[0], 0, aLegOrder1);
      Eps_Leg leg2 = Eps_Leg.ConvertLineArcArraysToLeg(_aRightCatchLines, _nNumRightCatchLines, new Eps_Arc[0], 0, aLegOrder2);
      Eps_Leg leg3 = Eps_Leg.ConvertLineArcArraysToLeg(_aLeftCutFillLines, _nNumLeftCutFillLines, new Eps_Arc[0], 0, aLegOrder3);
      _CatchLinesLegLists1.Add(leg3);
      Eps_Leg leg4 = Eps_Leg.ConvertLineArcArraysToLeg(_aRightCutFillLines, _nNumRightCutFillLines, new Eps_Arc[0], 0, aLegOrder4);
      _CatchLinesLegLists1.Add(leg4);
      _CatchLineLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(leg1, leg2, leg3, leg4, _CurrentLeg.IsLegClosed());
      if (bIsCrownPresent)
      {
        List<Eps_Point> paPntList = new List<Eps_Point>();
        paPntList.AddRange((IEnumerable<Eps_Point>) _aCutFillPoints);
        Eps_Leg ppOffsetLegList1 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, 0.01, 1, ref ppOffsetLegList1, true);
        Eps_Leg ppOffsetLegList2 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, 0.01, 2, ref ppOffsetLegList2, true);
        Eps_Leg pLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(new List<Eps_Leg>()
        {
          ppOffsetLegList1,
          ppOffsetLegList2
        });
        if (pLeg != null && paPntList.Count > 0)
        {
          RevitGeometry.GetAllPointsInBoundary(ref paPntList, pLeg, (List<Eps_Leg>) null);
          _CrownPointList.AddRange((IEnumerable<Eps_Point>) paPntList);
        }
      }
    }
    else
    {
      Eps_Leg ppOffsetLegList3 = (Eps_Leg) null;
      List<Eps_Leg> _CatchLinesLegLists2 = new List<Eps_Leg>();
      List<Eps_Leg> _CatchLinesLegLists3 = new List<Eps_Leg>();
      double _dStation = 0.0;
      double _dOffset = 0.0;
      for (int index1 = 0; index1 < _OffsetLegWrappers.Count; ++index1)
      {
        Eps_Line[] aLines1 = (Eps_Line[]) null;
        Eps_Arc[] aArcs1 = (Eps_Arc[]) null;
        int[] aLegOrder5 = (int[]) null;
        int nLineCount1 = 0;
        int nArcCount1 = 0;
        Eps_Leg ppOffsetLegList4 = new Eps_Leg();
        Eps_Leg epsLeg1;
        Eps_Leg epsLeg2;
        if (_OffsetLegWrappers[index1].IsLeft)
        {
          epsLeg1 = _OffsetLegWrappers[index1].OffsetLeg.MoveLeg(0.0, 0.0, dLeftEdgeAdjustElev);
          epsLeg2 = _OffsetLegWrappers[index1].OriginalLeg.MoveLeg(0.0, 0.0, dLeftEdgeAdjustElev);
          if (dBoulevardWidth > 0.0)
          {
            ppOffsetLegList3 = new Eps_Leg();
            RevitGeometry.OffsetLegList(epsLeg2, _OffsetLegWrappers[index1].AdditionalOffsetWidth - dBoulevardWidth, 2, ref ppOffsetLegList3, true);
            RevitGeometry.OffsetLegList(ppOffsetLegList3, 0.01, 1, ref ppOffsetLegList4, true);
          }
          else
            RevitGeometry.OffsetLegList(epsLeg1, 0.01, 1, ref ppOffsetLegList4, true);
          ppOffsetLegList4 = ppOffsetLegList4.MoveLeg(0.0, 0.0, dAdjustSubgradeElev - dLeftSubgradeAdjustElev);
        }
        else
        {
          epsLeg1 = _OffsetLegWrappers[index1].OffsetLeg.MoveLeg(0.0, 0.0, dRightEdgeAdjustElev);
          epsLeg2 = _OffsetLegWrappers[index1].OriginalLeg.MoveLeg(0.0, 0.0, dRightEdgeAdjustElev);
          if (dBoulevardWidth > 0.0)
          {
            ppOffsetLegList3 = new Eps_Leg();
            RevitGeometry.OffsetLegList(epsLeg2, _OffsetLegWrappers[index1].AdditionalOffsetWidth - dBoulevardWidth, 1, ref ppOffsetLegList3, true);
            RevitGeometry.OffsetLegList(ppOffsetLegList3, 0.01, 2, ref ppOffsetLegList4, true);
          }
          else
            RevitGeometry.OffsetLegList(epsLeg1, 0.01, 2, ref ppOffsetLegList4, true);
          ppOffsetLegList4 = ppOffsetLegList4.MoveLeg(0.0, 0.0, dAdjustSubgradeElev - dRightSubgradeAdjustElev);
        }
        ppOffsetLegList4 = ppOffsetLegList4.ExtendLegList(true, -0.005);
        ppOffsetLegList4 = ppOffsetLegList4.ExtendLegList(false, -0.005);
        epsLeg1.ConvertLegToLineArcArrays(ref aLines1, ref nLineCount1, ref aArcs1, ref nArcCount1, ref aLegOrder5, false);
        Eps_Line[] _aCatchLines = (Eps_Line[]) null;
        int _nNumCatchLines = 0;
        Eps_Line[] _aFeatureLines = (Eps_Line[]) null;
        int _nNumFeatureLines = 0;
        EPSharedExternal.CreateCatchLinesAndFeatureLinesFromTopo(_strPathName, aLines1, nLineCount1, aArcs1, nArcCount1, aLegOrder5, array, count, dLinearInterval, dRadialInterval, _dArcPointInterval, dCutSlope, dFillSlope, _OffsetLegWrappers[index1].IsLeft, ref _aCatchLines, ref _nNumCatchLines, ref _aFeatureLines, ref _nNumFeatureLines);
        _ProgressFrm?.UpdateProgressBar(1);
        if (_AddPointList == null)
          _AddPointList = new List<Eps_Point>();
        int[] aLegOrder6 = new int[_nNumCatchLines];
        for (int index2 = 0; index2 < _nNumCatchLines; ++index2)
        {
          if (index2 == 0)
            _AddPointList.Add(_aCatchLines[index2].StartPnt);
          _AddPointList.Add(_aCatchLines[index2].EndPnt);
          aLegOrder6[index2] = 0;
        }
        _ProgressFrm?.UpdateProgressBar(1);
        int[] aLegOrder7 = new int[_nNumFeatureLines];
        for (int index3 = 0; index3 < _nNumFeatureLines; ++index3)
        {
          if (index3 == 0)
            _AddPointList.Add(_aFeatureLines[index3].StartPnt);
          _AddPointList.Add(_aFeatureLines[index3].EndPnt);
          aLegOrder7[index3] = 0;
        }
        _ProgressFrm?.UpdateProgressBar(1);
        Eps_Leg leg5 = Eps_Leg.ConvertLineArcArraysToLeg(_aCatchLines, _nNumCatchLines, new Eps_Arc[0], 0, aLegOrder6);
        _CatchLinesLegLists2.Add(leg5);
        Eps_Point Pnt;
        if (bIsCrownPresent)
        {
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CurrentLeg.LegStartPnt, _CurrentLeg, ref _dStation, ref _dOffset) == 1700 && _dStation >= _OffsetLegWrappers[index1].Station && _dStation <= _OffsetLegWrappers[index1].EndingStation)
          {
            _AddPointList.Add(_CurrentLeg.LegStartPnt);
            Pnt = _CurrentLeg.ExtendLegList(true, -0.005).LegStartPnt;
            Pnt.z += dAdjustSubgradeElev;
            _AddPointList.Add(Pnt);
            _CrownPointList.Add(Pnt);
          }
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CurrentLeg.LegEndPnt, _CurrentLeg, ref _dStation, ref _dOffset) == 1700 && _dStation >= _OffsetLegWrappers[index1].Station && _dStation <= _OffsetLegWrappers[index1].EndingStation)
          {
            _AddPointList.Add(_CurrentLeg.LegEndPnt);
            Pnt = _CurrentLeg.ExtendLegList(false, -0.005).LegEndPnt;
            Pnt.z += dAdjustSubgradeElev;
            _AddPointList.Add(Pnt);
            _CrownPointList.Add(Pnt);
          }
        }
        Eps_Leg leg6 = Eps_Leg.ConvertLineArcArraysToLeg(_aFeatureLines, _nNumFeatureLines, new Eps_Arc[0], 0, aLegOrder7);
        if (leg6 != null)
        {
          for (Eps_Leg epsLeg3 = leg6; epsLeg3 != null; epsLeg3 = epsLeg3.Next)
          {
            if (epsLeg3.Line != null || epsLeg3.Arc != null)
            {
              if (epsLeg3.LegStartPnt != null)
              {
                _AddPointList.Add(epsLeg3.LegStartPnt);
                if (ppOffsetLegList4 != null)
                {
                  Pnt = new Eps_Point();
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg3.LegStartPnt, ppOffsetLegList4, ref _dStation, ref _dOffset) == 1700 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(ppOffsetLegList4, _dStation, 0.0, ref Pnt) == 0)
                    _AddPointList.Add(Pnt);
                }
                if (bIsCrownPresent)
                {
                  Pnt = new Eps_Point();
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg3.LegStartPnt, _CurrentLeg, ref _dStation, ref _dOffset) == 1700 && _dStation >= _OffsetLegWrappers[index1].Station && _dStation <= _OffsetLegWrappers[index1].EndingStation && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentLeg, _dStation, 0.0, ref Pnt) == 0)
                  {
                    Pnt.z += dAdjustSubgradeElev;
                    _AddPointList.Add(Pnt);
                    _CrownPointList.Add(Pnt);
                  }
                }
                if (dBoulevardWidth > 0.0 && ppOffsetLegList3 != null)
                {
                  Pnt = new Eps_Point();
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg3.LegStartPnt, ppOffsetLegList3, ref _dStation, ref _dOffset) == 1700 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(ppOffsetLegList3, _dStation, 0.0, ref Pnt) == 0)
                    _AddPointList.Add(Pnt);
                }
              }
              if (epsLeg3.LegEndPnt != null && epsLeg3.Next == null)
              {
                _AddPointList.Add(epsLeg3.LegEndPnt);
                if (ppOffsetLegList4 != null)
                {
                  Pnt = new Eps_Point();
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg3.LegEndPnt, ppOffsetLegList4, ref _dStation, ref _dOffset) == 1700 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(ppOffsetLegList4, _dStation, 0.0, ref Pnt) == 0)
                    _AddPointList.Add(Pnt);
                }
                if (bIsCrownPresent)
                {
                  Pnt = new Eps_Point();
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg3.LegEndPnt, _CurrentLeg, ref _dStation, ref _dOffset) == 1700 && _dStation >= _OffsetLegWrappers[index1].Station && _dStation <= _OffsetLegWrappers[index1].EndingStation && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentLeg, _dStation, 0.0, ref Pnt) == 0)
                  {
                    Pnt.z += dAdjustSubgradeElev;
                    _AddPointList.Add(Pnt);
                    _CrownPointList.Add(Pnt);
                  }
                }
                if (dBoulevardWidth > 0.0 && ppOffsetLegList3 != null)
                {
                  Pnt = new Eps_Point();
                  if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg3.LegEndPnt, ppOffsetLegList3, ref _dStation, ref _dOffset) == 1700 && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(ppOffsetLegList3, _dStation, 0.0, ref Pnt) == 0)
                    _AddPointList.Add(Pnt);
                }
              }
            }
          }
          if (_OffsetLegWrappers[index1].AdditionalOffsetWidth > 0.0)
          {
            Eps_Leg ppOffsetLegList5 = new Eps_Leg();
            if (_OffsetLegWrappers[index1].IsLeft)
              RevitGeometry.OffsetLegList(leg6, _OffsetLegWrappers[index1].AdditionalOffsetWidth, 1, ref ppOffsetLegList5, true);
            else
              RevitGeometry.OffsetLegList(leg6, _OffsetLegWrappers[index1].AdditionalOffsetWidth, 2, ref ppOffsetLegList5, true);
            Eps_Leg _AddLeg1 = new Eps_Leg();
            _AddLeg1.Line = new Eps_Line();
            _AddLeg1.Line.StartPnt = ppOffsetLegList5.LegStartPnt;
            _AddLeg1.Line.EndPnt = leg6.LegStartPnt;
            Eps_Leg.InsertLeg(ref leg6, _AddLeg1);
            Eps_Leg _AddLeg2 = new Eps_Leg();
            _AddLeg2.Line = new Eps_Line();
            _AddLeg2.Line.StartPnt = ppOffsetLegList5.LegEndPnt;
            _AddLeg2.Line.EndPnt = leg6.LegEndPnt;
            Eps_Leg.InsertLeg(ref leg6, _AddLeg2);
          }
          _CatchLinesLegLists1.Add(leg6);
        }
        if (epsLeg2 != null)
        {
          Eps_Leg _CurrentLeg1 = Eps_Leg.CopyLeg(epsLeg2);
          if (_OffsetLegWrappers[index1].AdditionalOffsetWidth - dBoulevardWidth > 0.0)
          {
            if (dBoulevardWidth > 0.0 && ppOffsetLegList3 != null)
            {
              _CurrentLeg1 = Eps_Leg.CopyLeg(ppOffsetLegList3);
              if (_CurrentLeg1.Arc != null && _OffsetLegWrappers[index1].OffsetLeg.Arc == null)
              {
                Eps_Leg epsLeg4 = Eps_Leg.SingleLeg(_CurrentLeg1);
                _AddPointList.AddRange((IEnumerable<Eps_Point>) epsLeg4.GetPointsAtIntervals(_dArcPointInterval, _dArcPointInterval));
                if (ppOffsetLegList4.Arc != null)
                {
                  Eps_Leg epsLeg5 = Eps_Leg.SingleLeg(ppOffsetLegList4);
                  _AddPointList.AddRange((IEnumerable<Eps_Point>) epsLeg5.GetPointsAtIntervals(_dArcPointInterval, _dArcPointInterval));
                }
              }
              if (_CurrentLeg1.Last.Arc != null && _OffsetLegWrappers[index1].OffsetLeg.Last.Arc == null)
              {
                _AddPointList.AddRange((IEnumerable<Eps_Point>) _CurrentLeg1.Last.GetPointsAtIntervals(_dArcPointInterval, _dArcPointInterval));
                if (ppOffsetLegList4.Last.Arc != null)
                  _AddPointList.AddRange((IEnumerable<Eps_Point>) ppOffsetLegList4.Last.GetPointsAtIntervals(_dArcPointInterval, _dArcPointInterval));
              }
            }
            else
              _CurrentLeg1 = Eps_Leg.CopyLeg(epsLeg1);
            Eps_Leg _AddLeg3 = new Eps_Leg();
            _AddLeg3.Line = new Eps_Line();
            _AddLeg3.Line.StartPnt = epsLeg2.LegStartPnt;
            _AddLeg3.Line.EndPnt = _CurrentLeg1.LegStartPnt;
            Eps_Leg.InsertLeg(ref _CurrentLeg1, _AddLeg3);
            Eps_Leg _AddLeg4 = new Eps_Leg();
            _AddLeg4.Line = new Eps_Line();
            _AddLeg4.Line.StartPnt = epsLeg2.LegEndPnt;
            _AddLeg4.Line.EndPnt = _CurrentLeg1.LegEndPnt;
            Eps_Leg.InsertLeg(ref _CurrentLeg1, _AddLeg4);
          }
          _CatchLinesLegLists3.Add(_CurrentLeg1);
        }
      }
      if (_CatchLinesLegLists2.Count > 0)
        _CatchLineLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(_CatchLinesLegLists2);
      if (_CatchLinesLegLists3.Count > 0)
        _OriginalBoundaryLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(_CatchLinesLegLists3);
    }
    if (_CatchLinesLegLists1.Count <= 0)
      return;
    _FeatureLineLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(_CatchLinesLegLists1);
  }

  private static void TrimOrExtendOffsetLegs(
    bool _IsStart,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    double _dExistingOffset,
    ref Eps_Leg _OffsetLeg)
  {
    double _dOffset1 = 0.0;
    double _dOffset2 = 0.0;
    double _dStation1 = 0.0;
    double _dStation2 = 0.0;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    int pNumberOfIntersections = 0;
    Eps_Point _Point = !_IsStart ? _OffsetLeg.LegEndPnt : _OffsetLeg.LegStartPnt;
    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _LeftExistingOffsetLeg, ref _dStation1, ref _dOffset1) != 1700 || RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _RightExistingOffsetLeg, ref _dStation2, ref _dOffset2) != 1700)
      return;
    if (_dOffset1 > 0.0 && _dOffset2 >= 0.0)
    {
      if (RevitGeometry.eplGeoE_IntersectTwoLegLists(!_IsStart ? _OffsetLeg.Last : Eps_Leg.SingleLeg(_OffsetLeg), _LeftExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
      {
        if (_IsStart)
          RevitGeometry.TrimStartOfLeg(ref _OffsetLeg, ppPointList[0]);
        else
          RevitGeometry.TrimEndOfLeg(ref _OffsetLeg, ppPointList[pNumberOfIntersections - 1]);
      }
      else
      {
        while (_dOffset2 > 0.0)
        {
          _OffsetLeg = _OffsetLeg.ExtendLegList(_IsStart, _dExistingOffset);
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(!_IsStart ? _OffsetLeg.LegEndPnt : _OffsetLeg.LegStartPnt, _RightExistingOffsetLeg, ref _dStation2, ref _dOffset2) == 1700 && _dOffset2 < 0.0 && RevitGeometry.eplGeoE_IntersectTwoLegLists(!_IsStart ? _OffsetLeg.Last : Eps_Leg.SingleLeg(_OffsetLeg), _RightExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
          {
            if (_IsStart)
              RevitGeometry.TrimStartOfLeg(ref _OffsetLeg, ppPointList[0]);
            else
              RevitGeometry.TrimEndOfLeg(ref _OffsetLeg, ppPointList[pNumberOfIntersections - 1]);
          }
        }
      }
    }
    else
    {
      if (_dOffset1 > 0.0 || _dOffset2 >= 0.0)
        return;
      if (RevitGeometry.eplGeoE_IntersectTwoLegLists(!_IsStart ? _OffsetLeg.Last : Eps_Leg.SingleLeg(_OffsetLeg), _RightExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
      {
        if (_IsStart)
          RevitGeometry.TrimStartOfLeg(ref _OffsetLeg, ppPointList[0]);
        else
          RevitGeometry.TrimEndOfLeg(ref _OffsetLeg, ppPointList[pNumberOfIntersections - 1]);
      }
      else
      {
        while (_dOffset1 < 0.0)
        {
          _OffsetLeg = _OffsetLeg.ExtendLegList(_IsStart, _dExistingOffset);
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(!_IsStart ? _OffsetLeg.LegEndPnt : _OffsetLeg.LegStartPnt, _LeftExistingOffsetLeg, ref _dStation1, ref _dOffset1) == 1700 && _dOffset1 > 0.0 && RevitGeometry.eplGeoE_IntersectTwoLegLists(!_IsStart ? _OffsetLeg.Last : Eps_Leg.SingleLeg(_OffsetLeg), _LeftExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
          {
            if (_IsStart)
              RevitGeometry.TrimStartOfLeg(ref _OffsetLeg, ppPointList[0]);
            else
              RevitGeometry.TrimEndOfLeg(ref _OffsetLeg, ppPointList[pNumberOfIntersections - 1]);
          }
        }
      }
    }
  }

  private static bool UpdateRadiusAndTransitionalDistanceForIntersectionStations(
    List<IntersectionStationContainer> _PrevIntersectionStations,
    ref List<IntersectionStationContainer> _IntersectionStations)
  {
    double num1 = double.MaxValue;
    int index1 = -1;
    bool flag = false;
    if (_PrevIntersectionStations.Count != _IntersectionStations.Count)
      return false;
    for (int index2 = 0; index2 < _PrevIntersectionStations.Count; ++index2)
    {
      if (_PrevIntersectionStations[index2].IntersectionStations.Count != _IntersectionStations[index2].IntersectionStations.Count)
        return false;
      for (int index3 = 0; index3 < _PrevIntersectionStations[index2].IntersectionStations.Count; ++index3)
      {
        for (int index4 = 0; index4 < _IntersectionStations[index2].IntersectionStations.Count; ++index4)
        {
          if (_PrevIntersectionStations[index2].IntersectionStations[index3].IsPrimaryLeft == _IntersectionStations[index2].IntersectionStations[index4].IsPrimaryLeft && _PrevIntersectionStations[index2].IntersectionStations[index3].IsLeft == _IntersectionStations[index2].IntersectionStations[index4].IsLeft)
          {
            double num2 = Math.Abs(_PrevIntersectionStations[index2].IntersectionStations[index3].Station - _IntersectionStations[index2].IntersectionStations[index4].Station);
            if (num2 < num1)
            {
              num1 = num2;
              index1 = index4;
            }
            double num3 = Math.Abs(_PrevIntersectionStations[index2].IntersectionStations[index3].PrimaryStation - _IntersectionStations[index2].IntersectionStations[index4].PrimaryStation);
            if (num3 < num1)
            {
              num1 = num3;
              index1 = index4;
            }
            if (num3 == 0.0)
              break;
          }
        }
        if (index1 >= 0 && index1 < _IntersectionStations[index2].IntersectionStations.Count)
        {
          flag = true;
          _IntersectionStations[index2].IntersectionStations[index1].Radius = _PrevIntersectionStations[index2].IntersectionStations[index3].Radius;
          _IntersectionStations[index2].IntersectionStations[index1].TransitioningDistance = _PrevIntersectionStations[index2].IntersectionStations[index3].TransitioningDistance;
        }
        num1 = double.MaxValue;
        index1 = -1;
      }
    }
    return flag;
  }

  private static bool FindIntersectionStationAndProfiles(
    Eps_Leg _CurrentLeg,
    Eps_Leg _LeftOffsetLeg,
    Eps_Leg _RightOffsetLeg,
    Eps_Leg _ExistingOffsetLeg,
    double _dExistingOffset,
    double _dExistingAdjustSubgradeElev,
    double _dIntersectionRadius,
    double _dIntersectionTransitioningDistance,
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    LandcaddID _LocateType,
    ref List<IntersectionStationContainer> _LeftIntersectionStations,
    ref List<IntersectionStationContainer> _CenterIntersectionStations,
    ref List<IntersectionStationContainer> _RightIntersectionStations)
  {
    Eps_Leg ppOffsetLegList1 = new Eps_Leg();
    RevitGeometry.OffsetLegList(_ExistingOffsetLeg, _dExistingOffset / 2.0, 1, ref ppOffsetLegList1, true);
    Eps_Leg ppOffsetLegList2 = new Eps_Leg();
    RevitGeometry.OffsetLegList(_ExistingOffsetLeg, _dExistingOffset / 2.0, 2, ref ppOffsetLegList2, true);
    return TopographySurfaceManagement.FindIntersectionStationAndProfiles(_CurrentLeg, _LeftOffsetLeg, _RightOffsetLeg, _ExistingOffsetLeg, ppOffsetLegList2, ppOffsetLegList1, _dExistingOffset, _dExistingAdjustSubgradeElev, _dIntersectionRadius, _dIntersectionTransitioningDistance, true, true, 0.0, _Document, _TransactionContainer, _LocateType, ref _LeftIntersectionStations, ref _CenterIntersectionStations, ref _RightIntersectionStations);
  }

  private static bool FindIntersectionStationAndProfiles(
    Eps_Leg _CurrentLeg,
    Eps_Leg _LeftOffsetLeg,
    Eps_Leg _RightOffsetLeg,
    Eps_Leg _ExistingOffsetLeg,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    double _dExistingOffset,
    double _dExistingAdjustSubgradeElev,
    double _dIntersectionRadius,
    double _dIntersectionTransitioningDistance,
    bool _bFindIntersectionStations,
    bool _bDisplayPromptWhenNecessary,
    double _dMinimumRadius,
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    LandcaddID _LocateType,
    ref List<IntersectionStationContainer> _LeftIntersectionStations,
    ref List<IntersectionStationContainer> _CenterIntersectionStations,
    ref List<IntersectionStationContainer> _RightIntersectionStations)
  {
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    int pNumberOfIntersections = 0;
    double _dStation = 0.0;
    double _dOffset1 = 0.0;
    bool _bIsFirstIntersectionFourWay = true;
    double _dOffset2 = 0.0;
    double _dOffset3 = 0.0;
    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CurrentLeg.LegStartPnt, _LeftExistingOffsetLeg, ref _dStation, ref _dOffset2) == 1700 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CurrentLeg.LegStartPnt, _RightExistingOffsetLeg, ref _dStation, ref _dOffset3) == 1700 && RevitDefines.GE(_dOffset2, 0.0) && RevitDefines.LE(_dOffset3, 0.0))
      _bIsFirstIntersectionFourWay = false;
    if (!_bIsFirstIntersectionFourWay)
    {
      TopographySurfaceManagement.TrimOrExtendOffsetLegs(true, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _dExistingOffset, ref _LeftOffsetLeg);
      TopographySurfaceManagement.TrimOrExtendOffsetLegs(true, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _dExistingOffset, ref _RightOffsetLeg);
    }
    bool flag1 = true;
    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CurrentLeg.LegEndPnt, _LeftExistingOffsetLeg, ref _dStation, ref _dOffset2) == 1700 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_CurrentLeg.LegEndPnt, _RightExistingOffsetLeg, ref _dStation, ref _dOffset3) == 1700 && RevitDefines.GE(_dOffset2, 0.0) && RevitDefines.LE(_dOffset3, 0.0))
      flag1 = false;
    if (!flag1)
    {
      TopographySurfaceManagement.TrimOrExtendOffsetLegs(false, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _dExistingOffset, ref _LeftOffsetLeg);
      TopographySurfaceManagement.TrimOrExtendOffsetLegs(false, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _dExistingOffset, ref _RightOffsetLeg);
    }
    if (_bFindIntersectionStations)
    {
      List<IntersectionStationContainer> _PrevIntersectionStations1 = new List<IntersectionStationContainer>();
      List<IntersectionStationContainer> _PrevIntersectionStations2 = new List<IntersectionStationContainer>();
      _PrevIntersectionStations1.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
      _PrevIntersectionStations2.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
      _LeftIntersectionStations.Clear();
      _RightIntersectionStations.Clear();
      if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_LeftOffsetLeg, _LeftExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
      {
        for (int index1 = 0; index1 < pNumberOfIntersections; ++index1)
        {
          RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index1], _LeftOffsetLeg, ref _dStation, ref _dOffset1, true);
          int index2 = 0;
          int index3 = 0;
          bool flag2 = false;
          if (_LeftIntersectionStations.Count == 0)
          {
            _LeftIntersectionStations.Add(new IntersectionStationContainer(_dStation));
          }
          else
          {
            for (index2 = 0; index2 < _LeftIntersectionStations.Count; ++index2)
            {
              for (index3 = 0; index3 < _LeftIntersectionStations[index2].IntersectionStations.Count; ++index3)
              {
                if (_dStation < _LeftIntersectionStations[index2].IntersectionStations[index3].Station)
                {
                  _LeftIntersectionStations[index2].IntersectionStations.Insert(index3, new IntersectionStation(_dStation));
                  flag2 = true;
                  break;
                }
              }
              if (!flag2)
              {
                if (index3 == _LeftIntersectionStations[index2].IntersectionStations.Count)
                {
                  _LeftIntersectionStations[index2].IntersectionStations.Add(new IntersectionStation(_dStation));
                  break;
                }
              }
              else
                break;
            }
          }
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index1], _LeftExistingOffsetLeg, ref _dStation, ref _dOffset1) == 1700)
          {
            _LeftIntersectionStations[index2].IntersectionStations[index3].IsPrimaryLeft = true;
            _LeftIntersectionStations[index2].IntersectionStations[index3].PrimaryStation = _dStation;
          }
          _LeftIntersectionStations[index2].IntersectionStations[index3].IsLeft = true;
          _LeftIntersectionStations[index2].IntersectionStations[index3].Radius = _dIntersectionRadius;
          _LeftIntersectionStations[index2].IntersectionStations[index3].TransitioningDistance = _dIntersectionTransitioningDistance;
        }
      }
      if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_LeftOffsetLeg, _RightExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
      {
        for (int index4 = 0; index4 < pNumberOfIntersections; ++index4)
        {
          RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index4], _LeftOffsetLeg, ref _dStation, ref _dOffset1);
          int index5 = 0;
          int index6 = 0;
          bool flag3 = false;
          if (_LeftIntersectionStations.Count == 0)
          {
            _LeftIntersectionStations.Add(new IntersectionStationContainer(_dStation));
          }
          else
          {
            for (index5 = 0; index5 < _LeftIntersectionStations.Count; ++index5)
            {
              for (index6 = 0; index6 < _LeftIntersectionStations[index5].IntersectionStations.Count; ++index6)
              {
                if (_dStation < _LeftIntersectionStations[index5].IntersectionStations[index6].Station)
                {
                  _LeftIntersectionStations[index5].IntersectionStations.Insert(index6, new IntersectionStation(_dStation));
                  flag3 = true;
                  break;
                }
              }
              if (!flag3)
              {
                if (index6 == _LeftIntersectionStations[index5].IntersectionStations.Count)
                {
                  _LeftIntersectionStations[index5].IntersectionStations.Add(new IntersectionStation(_dStation));
                  break;
                }
              }
              else
                break;
            }
          }
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index4], _RightExistingOffsetLeg, ref _dStation, ref _dOffset1) == 1700)
          {
            _LeftIntersectionStations[index5].IntersectionStations[index6].IsPrimaryLeft = false;
            _LeftIntersectionStations[index5].IntersectionStations[index6].PrimaryStation = _dStation;
          }
          _LeftIntersectionStations[index5].IntersectionStations[index6].IsLeft = true;
          _LeftIntersectionStations[index5].IntersectionStations[index6].Radius = _dIntersectionRadius;
          _LeftIntersectionStations[index5].IntersectionStations[index6].TransitioningDistance = _dIntersectionTransitioningDistance;
        }
      }
      if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_RightOffsetLeg, _LeftExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
      {
        for (int index7 = 0; index7 < pNumberOfIntersections; ++index7)
        {
          RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index7], _RightOffsetLeg, ref _dStation, ref _dOffset1);
          int index8 = 0;
          int index9 = 0;
          bool flag4 = false;
          if (_RightIntersectionStations.Count == 0)
          {
            _RightIntersectionStations.Add(new IntersectionStationContainer(_dStation));
          }
          else
          {
            for (index8 = 0; index8 < _RightIntersectionStations.Count; ++index8)
            {
              for (index9 = 0; index9 < _RightIntersectionStations[index8].IntersectionStations.Count; ++index9)
              {
                if (_dStation < _RightIntersectionStations[index8].IntersectionStations[index9].Station)
                {
                  _RightIntersectionStations[index8].IntersectionStations.Insert(index9, new IntersectionStation(_dStation));
                  flag4 = true;
                  break;
                }
              }
              if (!flag4)
              {
                if (index9 == _RightIntersectionStations[index8].IntersectionStations.Count)
                {
                  _RightIntersectionStations[index8].IntersectionStations.Add(new IntersectionStation(_dStation));
                  break;
                }
              }
              else
                break;
            }
          }
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index7], _LeftExistingOffsetLeg, ref _dStation, ref _dOffset1) == 1700)
          {
            _RightIntersectionStations[index8].IntersectionStations[index9].IsPrimaryLeft = true;
            _RightIntersectionStations[index8].IntersectionStations[index9].PrimaryStation = _dStation;
          }
          _RightIntersectionStations[index8].IntersectionStations[index9].IsLeft = false;
          _RightIntersectionStations[index8].IntersectionStations[index9].Radius = _dIntersectionRadius;
          _RightIntersectionStations[index8].IntersectionStations[index9].TransitioningDistance = _dIntersectionTransitioningDistance;
        }
      }
      if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_RightOffsetLeg, _RightExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
      {
        for (int index10 = 0; index10 < pNumberOfIntersections; ++index10)
        {
          RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index10], _RightOffsetLeg, ref _dStation, ref _dOffset1);
          int index11 = 0;
          int index12 = 0;
          bool flag5 = false;
          if (_RightIntersectionStations.Count == 0)
          {
            _RightIntersectionStations.Add(new IntersectionStationContainer(_dStation));
          }
          else
          {
            for (index11 = 0; index11 < _RightIntersectionStations.Count; ++index11)
            {
              for (index12 = 0; index12 < _RightIntersectionStations[index11].IntersectionStations.Count; ++index12)
              {
                if (_dStation < _RightIntersectionStations[index11].IntersectionStations[index12].Station)
                {
                  _RightIntersectionStations[index11].IntersectionStations.Insert(index12, new IntersectionStation(_dStation));
                  flag5 = true;
                  break;
                }
              }
              if (!flag5)
              {
                if (index12 == _RightIntersectionStations[index11].IntersectionStations.Count)
                {
                  _RightIntersectionStations[index11].IntersectionStations.Add(new IntersectionStation(_dStation));
                  break;
                }
              }
              else
                break;
            }
          }
          if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index10], _RightExistingOffsetLeg, ref _dStation, ref _dOffset1) == 1700)
          {
            _RightIntersectionStations[index11].IntersectionStations[index12].IsPrimaryLeft = false;
            _RightIntersectionStations[index11].IntersectionStations[index12].PrimaryStation = _dStation;
          }
          _RightIntersectionStations[index11].IntersectionStations[index12].IsLeft = false;
          _RightIntersectionStations[index11].IntersectionStations[index12].Radius = _dIntersectionRadius;
          _RightIntersectionStations[index11].IntersectionStations[index12].TransitioningDistance = _dIntersectionTransitioningDistance;
        }
      }
      _bFindIntersectionStations = !TopographySurfaceManagement.UpdateRadiusAndTransitionalDistanceForIntersectionStations(_PrevIntersectionStations1, ref _LeftIntersectionStations);
      if (!_bFindIntersectionStations)
        _bFindIntersectionStations = !TopographySurfaceManagement.UpdateRadiusAndTransitionalDistanceForIntersectionStations(_PrevIntersectionStations2, ref _RightIntersectionStations);
    }
    _CenterIntersectionStations.Clear();
    if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CurrentLeg, _LeftExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
    {
      for (int index13 = 0; index13 < pNumberOfIntersections; ++index13)
      {
        RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index13], _CurrentLeg, ref _dStation, ref _dOffset1);
        int index14 = 0;
        int index15 = 0;
        bool flag6 = false;
        if (_CenterIntersectionStations.Count == 0)
        {
          _CenterIntersectionStations.Add(new IntersectionStationContainer(_dStation));
        }
        else
        {
          for (index14 = 0; index14 < _CenterIntersectionStations.Count; ++index14)
          {
            for (index15 = 0; index15 < _CenterIntersectionStations[index14].IntersectionStations.Count; ++index15)
            {
              if (_dStation < _CenterIntersectionStations[index14].IntersectionStations[index15].Station)
              {
                _CenterIntersectionStations[index14].IntersectionStations.Insert(index15, new IntersectionStation(_dStation));
                flag6 = true;
                break;
              }
            }
            if (!flag6)
            {
              if (index15 == _CenterIntersectionStations[index14].IntersectionStations.Count)
              {
                _CenterIntersectionStations[index14].IntersectionStations.Add(new IntersectionStation(_dStation));
                break;
              }
            }
            else
              break;
          }
        }
        if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index13], _LeftExistingOffsetLeg, ref _dStation, ref _dOffset1) == 1700)
        {
          _CenterIntersectionStations[index14].IntersectionStations[index15].IsPrimaryLeft = true;
          _CenterIntersectionStations[index14].IntersectionStations[index15].PrimaryStation = _dStation;
        }
      }
    }
    if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CurrentLeg, _RightExistingOffsetLeg, ref ppPointList, ref pNumberOfIntersections, 1E-05) == 0 && pNumberOfIntersections > 0)
    {
      for (int index16 = 0; index16 < pNumberOfIntersections; ++index16)
      {
        RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index16], _CurrentLeg, ref _dStation, ref _dOffset1);
        int index17 = 0;
        int index18 = 0;
        bool flag7 = false;
        if (_CenterIntersectionStations.Count == 0)
        {
          _CenterIntersectionStations.Add(new IntersectionStationContainer(_dStation));
        }
        else
        {
          for (index17 = 0; index17 < _CenterIntersectionStations.Count; ++index17)
          {
            for (index18 = 0; index18 < _CenterIntersectionStations[index17].IntersectionStations.Count; ++index18)
            {
              if (_dStation < _CenterIntersectionStations[index17].IntersectionStations[index18].Station)
              {
                _CenterIntersectionStations[index17].IntersectionStations.Insert(index18, new IntersectionStation(_dStation));
                flag7 = true;
                break;
              }
            }
            if (!flag7)
            {
              if (index18 == _CenterIntersectionStations[index17].IntersectionStations.Count)
              {
                _CenterIntersectionStations[index17].IntersectionStations.Add(new IntersectionStation(_dStation));
                break;
              }
            }
            else
              break;
          }
        }
        if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(ppPointList[index16], _RightExistingOffsetLeg, ref _dStation, ref _dOffset1) == 1700)
        {
          _CenterIntersectionStations[index17].IntersectionStations[index18].IsPrimaryLeft = false;
          _CenterIntersectionStations[index17].IntersectionStations[index18].PrimaryStation = _dStation;
        }
      }
    }
    if (_bDisplayPromptWhenNecessary && (_LeftIntersectionStations.Count == 0 || _LeftIntersectionStations.Count != _RightIntersectionStations.Count || _LeftIntersectionStations.Count != _CenterIntersectionStations.Count))
    {
      if (_LocateType == LandcaddID.Street)
      {
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StreetIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SidewalkIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      return false;
    }
    DialogResult dialogResult = DialogResult.Ignore;
    if (_bFindIntersectionStations && _bDisplayPromptWhenNecessary)
    {
      dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("IntersectionDetectedMessage"), EPShared.LocalRM.GetString("InformationString"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk);
      if (dialogResult == DialogResult.Cancel)
        return false;
    }
    bool _bSurpressError = !_bDisplayPromptWhenNecessary;
    bool intersectionProfiles1 = TopographySurfaceManagement.GetIntersectionProfiles(_LocateType, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _LeftOffsetLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, _bSurpressError, _RightIntersectionStations, ref _LeftIntersectionStations);
    if (intersectionProfiles1)
      _bSurpressError = true;
    bool intersectionProfiles2 = TopographySurfaceManagement.GetIntersectionProfiles(_LocateType, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _RightOffsetLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, _bSurpressError, _LeftIntersectionStations, ref _RightIntersectionStations);
    if ((dialogResult == DialogResult.Yes || intersectionProfiles1 || intersectionProfiles2) && _bDisplayPromptWhenNecessary)
    {
      ChangeIntersectionRadiusForm intersectionRadiusForm = new ChangeIntersectionRadiusForm(_Document, _TransactionContainer, _LocateType, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _LeftOffsetLeg, _RightOffsetLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, _dMinimumRadius);
      intersectionRadiusForm.LeftIntersectionStations = _LeftIntersectionStations;
      intersectionRadiusForm.RightIntersectionStations = _RightIntersectionStations;
      intersectionRadiusForm.Draw();
      DialogResult _DialogResult = DialogResult.Retry;
      while (_DialogResult == DialogResult.Retry)
      {
        intersectionRadiusForm.ShowDialog(ref _DialogResult);
        if (_DialogResult == DialogResult.Cancel)
          return false;
        if (_DialogResult == DialogResult.Retry)
        {
          Eps_Point _UsePoint = new Eps_Point();
          if (RevitUtility.PickSide(_Document, _TransactionContainer, 10.0, intersectionRadiusForm.MidPointList, ref _UsePoint))
          {
            int _nStationContainerIndex = -1;
            int _nStationIndex = -1;
            if (TopographySurfaceManagement.FindPointInList(_LeftIntersectionStations, _UsePoint, ref _nStationContainerIndex, ref _nStationIndex))
            {
              intersectionRadiusForm.RightSide = false;
              intersectionRadiusForm.IntersectStationContainerIndex = _nStationContainerIndex;
              intersectionRadiusForm.IntersectStationIndex = _nStationIndex;
              intersectionRadiusForm.SetNewRadius(_LeftIntersectionStations[_nStationContainerIndex].IntersectionStations[_nStationIndex].Radius);
            }
            else if (TopographySurfaceManagement.FindPointInList(_RightIntersectionStations, _UsePoint, ref _nStationContainerIndex, ref _nStationIndex))
            {
              intersectionRadiusForm.RightSide = true;
              intersectionRadiusForm.IntersectStationContainerIndex = _nStationContainerIndex;
              intersectionRadiusForm.IntersectStationIndex = _nStationIndex;
              intersectionRadiusForm.SetNewRadius(_RightIntersectionStations[_nStationContainerIndex].IntersectionStations[_nStationIndex].Radius);
            }
          }
        }
        else if (_DialogResult == DialogResult.Ignore)
        {
          intersectionRadiusForm.Draw();
          _DialogResult = DialogResult.Retry;
        }
      }
    }
    else if (dialogResult == DialogResult.No)
    {
      _LeftIntersectionStations.Clear();
      _RightIntersectionStations.Clear();
      _CenterIntersectionStations.Clear();
    }
    return TopographySurfaceManagement.GetIntersectionProfiles(_LeftExistingOffsetLeg, _RightExistingOffsetLeg, _CurrentLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, _LeftIntersectionStations, _RightIntersectionStations, ref _CenterIntersectionStations);
  }

  private static bool FindPointInList(
    List<IntersectionStationContainer> _IntersectionStations,
    Eps_Point _Point,
    ref int _nStationContainerIndex,
    ref int _nStationIndex)
  {
    int num1 = 0;
    int num2 = 0;
    foreach (IntersectionStationContainer intersectionStation1 in _IntersectionStations)
    {
      foreach (IntersectionStation intersectionStation2 in intersectionStation1.IntersectionStations)
      {
        if (intersectionStation2.InvalidIntersectionPnt == null)
        {
          if (intersectionStation2.IntersectionLeg != null)
          {
            if (intersectionStation2.IntersectionLeg.Arc != null)
            {
              if (EPShared.eplGeoE_IsPointOnArc2D(_Point, intersectionStation2.IntersectionLeg.Arc, 0.01))
              {
                _nStationContainerIndex = num1;
                _nStationIndex = num2;
                return true;
              }
            }
            else if (intersectionStation2.IntersectionLeg.Line != null && EPShared.eplGeoE_IsPointOnLine2D(_Point, intersectionStation2.IntersectionLeg.Line, 0.01))
            {
              _nStationContainerIndex = num1;
              _nStationIndex = num2;
              return true;
            }
          }
        }
        else if (_Point.IsEqual(intersectionStation2.InvalidIntersectionPnt))
        {
          _nStationContainerIndex = num1;
          _nStationIndex = num2;
          return true;
        }
        ++num2;
      }
      ++num1;
    }
    return false;
  }

  private static bool GetIntersectionProfiles(
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    Eps_Leg _CurrentOffsetLeg,
    double _dExistingAdjustSubgradeElev,
    bool _bIsFirstIntersectionFourWay,
    List<IntersectionStationContainer> _LeftIntersectionStations,
    List<IntersectionStationContainer> _RightIntersectionStations,
    ref List<IntersectionStationContainer> _IntersectionStations)
  {
    Eps_Point Pnt = (Eps_Point) null;
    double _dStation1 = 0.0;
    double _dStation2 = 0.0;
    double _dOffset = 0.0;
    if (_LeftIntersectionStations.Count != _RightIntersectionStations.Count)
      return false;
    for (int index1 = 0; index1 < _IntersectionStations.Count; ++index1)
    {
      bool flag = _bIsFirstIntersectionFourWay;
      if (_LeftIntersectionStations[index1].IntersectionStations.Count == _RightIntersectionStations[index1].IntersectionStations.Count)
      {
        for (int index2 = 0; index2 < _IntersectionStations[index1].IntersectionStations.Count; ++index2)
        {
          Eps_Leg StartOfLegList = _IntersectionStations[index1].IntersectionStations[index2].IsPrimaryLeft ? _LeftExistingOffsetLeg : _RightExistingOffsetLeg;
          if (_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg != null && _RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg != null && RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(StartOfLegList, _IntersectionStations[index1].IntersectionStations[index2].PrimaryStation, 0.0, ref Pnt) == 0)
          {
            Pnt.z += _dExistingAdjustSubgradeElev;
            Eps_Leg epsLeg = new Eps_Leg();
            epsLeg.Line = new Eps_Line();
            if (flag)
            {
              epsLeg.Line.EndPnt = Pnt;
              RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.LegStartPnt, _CurrentOffsetLeg, ref _dStation1, ref _dOffset, true);
              RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.LegStartPnt, _CurrentOffsetLeg, ref _dStation2, ref _dOffset, true);
              if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentOffsetLeg, (_dStation1 + _dStation2) / 2.0, 0.0, ref Pnt) == 0)
                epsLeg.Line.StartPnt = Pnt;
            }
            else
            {
              epsLeg.Line.StartPnt = Pnt;
              RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_LeftIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.LegEndPnt, _CurrentOffsetLeg, ref _dStation1, ref _dOffset, true);
              RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_RightIntersectionStations[index1].IntersectionStations[index2].IntersectionLeg.LegEndPnt, _CurrentOffsetLeg, ref _dStation2, ref _dOffset, true);
              if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentOffsetLeg, (_dStation1 + _dStation2) / 2.0, 0.0, ref Pnt) == 0)
                epsLeg.Line.EndPnt = Pnt;
            }
            _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = epsLeg;
            _IntersectionStations[index1].IntersectionStations[index2].StartingIntersection = flag;
            flag = !flag;
          }
        }
      }
    }
    return true;
  }

  public static bool GetIntersectionProfiles(
    LandcaddID _LocateType,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    Eps_Leg _CurrentOffsetLeg,
    double _dExistingAdjustSubgradeElev,
    bool _bIsFirstIntersectionFourWay,
    List<IntersectionStationContainer> _OtherSideExistingStations,
    ref List<IntersectionStationContainer> _IntersectionStations)
  {
    return TopographySurfaceManagement.GetIntersectionProfiles(_LocateType, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _CurrentOffsetLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, -1, -1, false, _OtherSideExistingStations, ref _IntersectionStations);
  }

  public static bool GetIntersectionProfiles(
    LandcaddID _LocateType,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    Eps_Leg _CurrentOffsetLeg,
    double _dExistingAdjustSubgradeElev,
    bool _bIsFirstIntersectionFourWay,
    bool _bSurpressError,
    List<IntersectionStationContainer> _OtherSideExistingStations,
    ref List<IntersectionStationContainer> _IntersectionStations)
  {
    return TopographySurfaceManagement.GetIntersectionProfiles(_LocateType, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _CurrentOffsetLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, -1, -1, _bSurpressError, _OtherSideExistingStations, ref _IntersectionStations);
  }

  public static bool GetIntersectionProfiles(
    LandcaddID _LocateType,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    Eps_Leg _CurrentOffsetLeg,
    double _dExistingAdjustSubgradeElev,
    bool _bIsFirstIntersectionFourWay,
    int _nIntersectionContainerIndex,
    int _nIntersectionStationIndex,
    List<IntersectionStationContainer> _OtherSideExistingStations,
    ref List<IntersectionStationContainer> _IntersectionStations)
  {
    return TopographySurfaceManagement.GetIntersectionProfiles(_LocateType, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _CurrentOffsetLeg, _dExistingAdjustSubgradeElev, _bIsFirstIntersectionFourWay, _nIntersectionContainerIndex, _nIntersectionStationIndex, false, _OtherSideExistingStations, ref _IntersectionStations);
  }

  public static bool GetIntersectionProfiles(
    LandcaddID _LocateType,
    Eps_Leg _LeftExistingOffsetLeg,
    Eps_Leg _RightExistingOffsetLeg,
    Eps_Leg _CurrentOffsetLeg,
    double _dExistingAdjustSubgradeElev,
    bool _bIsFirstIntersectionFourWay,
    int _nIntersectionContainerIndex,
    int _nIntersectionStationIndex,
    bool _bSurpressError,
    List<IntersectionStationContainer> _OtherSideExistingStations,
    ref List<IntersectionStationContainer> _IntersectionStations)
  {
    Eps_Leg Leg = (Eps_Leg) null;
    Eps_Point _Point = (Eps_Point) null;
    Eps_Point Pnt1 = (Eps_Point) null;
    Eps_Point Pnt2 = (Eps_Point) null;
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    bool flag1 = false;
    bool intersectionProfiles = false;
    bool flag2 = _bSurpressError;
    if (_IntersectionStations.Count != _OtherSideExistingStations.Count)
      return false;
    int num1 = 0;
    int index1;
    int num2;
    if (_nIntersectionContainerIndex >= 0 && _nIntersectionContainerIndex < _IntersectionStations.Count)
    {
      index1 = _nIntersectionContainerIndex;
      num2 = index1 + 1;
    }
    else
    {
      index1 = 0;
      num2 = _IntersectionStations.Count;
    }
    for (; index1 < num2; ++index1)
    {
      bool flag3 = _bIsFirstIntersectionFourWay;
      if (_IntersectionStations[index1].IntersectionStations.Count == _OtherSideExistingStations[index1].IntersectionStations.Count)
      {
        int index2;
        if (_nIntersectionStationIndex >= 0 && _nIntersectionStationIndex < _IntersectionStations[index1].IntersectionStations.Count)
        {
          index2 = _nIntersectionStationIndex;
          num1 = index2 + 1;
        }
        else
        {
          index2 = 0;
          num1 = _IntersectionStations[index1].IntersectionStations.Count;
        }
        for (; index2 < _IntersectionStations[index1].IntersectionStations.Count; ++index2)
        {
          Eps_Leg epsLeg = _IntersectionStations[index1].IntersectionStations[index2].IsPrimaryLeft ? _LeftExistingOffsetLeg : _RightExistingOffsetLeg;
          if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(epsLeg, _IntersectionStations[index1].IntersectionStations[index2].PrimaryStation, 0.0, ref Pnt2, ref Leg) == 0)
          {
            if (_IntersectionStations[index1].IntersectionStations[index2].Radius > 0.0)
            {
              if (Leg.Line != null)
              {
                Eps_Line _pOut = new Eps_Line();
                _pOut.StartPnt = Pnt2;
                if (_IntersectionStations[index1].IntersectionStations[index2].PrimaryStation < _OtherSideExistingStations[index1].IntersectionStations[index2].PrimaryStation)
                {
                  EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(Leg.Line.StartPnt, Pnt2, ref _dDistance);
                  if (_dDistance < _IntersectionStations[index1].IntersectionStations[index2].Radius)
                  {
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Pnt2, Leg.Line.StartPnt, ref _dDirection);
                    _Point = new Eps_Point();
                    EPShared.eplGeoE_CalcPolarToXY(Pnt2, _dDirection, _IntersectionStations[index1].IntersectionStations[index2].Radius, ref _Point);
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, epsLeg, ref _dStation, ref _dOffset) != 1700 || !RevitDefines.EQ(_dOffset, 0.0))
                      flag1 = true;
                    _pOut.EndPnt = _Point;
                  }
                  else
                    _pOut.EndPnt = Leg.Line.StartPnt;
                }
                else
                {
                  EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(Leg.Line.EndPnt, Pnt2, ref _dDistance);
                  if (_dDistance < _IntersectionStations[index1].IntersectionStations[index2].Radius)
                  {
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Pnt2, Leg.Line.EndPnt, ref _dDirection);
                    _Point = new Eps_Point();
                    EPShared.eplGeoE_CalcPolarToXY(Pnt2, _dDirection, _IntersectionStations[index1].IntersectionStations[index2].Radius, ref _Point);
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, epsLeg, ref _dStation, ref _dOffset) != 1700 || !RevitDefines.EQ(_dOffset, 0.0))
                      flag1 = true;
                    _pOut.EndPnt = _Point;
                  }
                  else
                    _pOut.EndPnt = Leg.Line.EndPnt;
                }
                _Point = new Eps_Point();
                if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentOffsetLeg, _IntersectionStations[index1].IntersectionStations[index2].Station, 0.0, ref _Point, ref Leg) == 0)
                {
                  if (Leg.Line != null)
                  {
                    Eps_Line _pIn = new Eps_Line();
                    _pIn.EndPnt = Pnt2;
                    if (flag3)
                    {
                      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(Leg.Line.StartPnt, Pnt2, ref _dDistance);
                      if (_dDistance < _IntersectionStations[index1].IntersectionStations[index2].Radius)
                      {
                        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Pnt2, Leg.Line.StartPnt, ref _dDirection);
                        _Point = new Eps_Point();
                        EPShared.eplGeoE_CalcPolarToXY(Pnt2, _dDirection, _IntersectionStations[index1].IntersectionStations[index2].Radius, ref _Point);
                        if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _CurrentOffsetLeg, ref _dStation, ref _dOffset) != 1700 || !RevitDefines.EQ(_dOffset, 0.0))
                          flag1 = true;
                        _pIn.StartPnt = _Point;
                      }
                      else
                        _pIn.StartPnt = Leg.Line.StartPnt;
                    }
                    else
                    {
                      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(Leg.Line.EndPnt, Pnt2, ref _dDistance);
                      if (_dDistance < _IntersectionStations[index1].IntersectionStations[index2].Radius)
                      {
                        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Pnt2, Leg.Line.EndPnt, ref _dDirection);
                        _Point = new Eps_Point();
                        EPShared.eplGeoE_CalcPolarToXY(Pnt2, _dDirection, _IntersectionStations[index1].IntersectionStations[index2].Radius, ref _Point);
                        if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _CurrentOffsetLeg, ref _dStation, ref _dOffset) != 1700 || !RevitDefines.EQ(_dOffset, 0.0))
                          flag1 = true;
                        _pIn.StartPnt = _Point;
                      }
                      else
                        _pIn.StartPnt = Leg.Line.EndPnt;
                    }
                    Eps_Arc _pArc = new Eps_Arc();
                    if (RevitGeometry.SolveArcFromTangentLines(_pIn, _pOut, _IntersectionStations[index1].IntersectionStations[index2].Radius, ref _pArc, false) != 0)
                      flag1 = true;
                    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_pArc.EndPnt, epsLeg, ref _dStation, ref _dOffset) != 1700)
                      flag1 = true;
                    if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(epsLeg, _dStation, 0.0, ref Pnt1) != 0)
                      flag1 = true;
                    Pnt1.z += _dExistingAdjustSubgradeElev;
                    Leg = new Eps_Leg();
                    Leg.Arc = _pArc;
                    Leg.Arc.EndPnt = Pnt1;
                    if (!flag3)
                      Leg = Leg.Reverse();
                    if (flag1)
                    {
                      if (!intersectionProfiles)
                      {
                        if (!flag2)
                        {
                          int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RadiusMakesArcLengthMoreThanHostLineMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                        }
                        intersectionProfiles = true;
                      }
                      _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = Pnt2;
                      _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = (Eps_Leg) null;
                    }
                    else
                    {
                      _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = (Eps_Point) null;
                      _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = Leg;
                    }
                    _IntersectionStations[index1].IntersectionStations[index2].StartingIntersection = flag3;
                    flag3 = !flag3;
                  }
                  else
                  {
                    if (!intersectionProfiles)
                    {
                      if (!flag2)
                      {
                        if (_LocateType == LandcaddID.Street)
                        {
                          int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StreetIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                        }
                        else
                        {
                          int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SidewalkIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                        }
                      }
                      intersectionProfiles = true;
                    }
                    _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = Pnt2;
                    _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = (Eps_Leg) null;
                  }
                }
              }
              else
              {
                if (!intersectionProfiles)
                {
                  if (!flag2)
                  {
                    if (_LocateType == LandcaddID.Street)
                    {
                      int num6 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StreetIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                    }
                    else
                    {
                      int num7 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SidewalkIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                    }
                  }
                  intersectionProfiles = true;
                }
                _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = Pnt2;
                _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = (Eps_Leg) null;
              }
            }
            else if (_IntersectionStations[index1].IntersectionStations[index2].TransitioningDistance > 0.0)
            {
              if (Leg.Line != null)
              {
                Pnt2.z += _dExistingAdjustSubgradeElev;
                Leg = new Eps_Leg();
                Leg.Line = new Eps_Line();
                if (flag3)
                {
                  if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentOffsetLeg, _IntersectionStations[index1].IntersectionStations[index2].Station - _IntersectionStations[index1].IntersectionStations[index2].TransitioningDistance, 0.0, ref _Point) != 0)
                    flag1 = true;
                  Leg.Line.StartPnt = _Point;
                  Leg.Line.EndPnt = Pnt2;
                }
                else
                {
                  Leg.Line.StartPnt = Pnt2;
                  if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentOffsetLeg, _IntersectionStations[index1].IntersectionStations[index2].Station + _IntersectionStations[index1].IntersectionStations[index2].TransitioningDistance, 0.0, ref _Point) != 0)
                    flag1 = true;
                  Leg.Line.EndPnt = _Point;
                }
                if (flag1)
                {
                  if (!intersectionProfiles)
                  {
                    if (!flag2)
                    {
                      int num8 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("TransitioningDistanceMakesDistanceMoreThanHostLineMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                    }
                    intersectionProfiles = true;
                  }
                  _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = Pnt2;
                  _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = (Eps_Leg) null;
                }
                else
                {
                  _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = (Eps_Point) null;
                  _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = Leg;
                }
                _IntersectionStations[index1].IntersectionStations[index2].StartingIntersection = flag3;
                flag3 = !flag3;
              }
              else
              {
                if (!intersectionProfiles)
                {
                  if (!flag2)
                  {
                    if (_LocateType == LandcaddID.Street)
                    {
                      int num9 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StreetIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                    }
                    else
                    {
                      int num10 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SidewalkIntersectionNotOnStraightLinesMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                    }
                  }
                  intersectionProfiles = true;
                }
                _IntersectionStations[index1].IntersectionStations[index2].InvalidIntersectionPnt = Pnt2;
                _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = (Eps_Leg) null;
              }
            }
            else
            {
              if (!intersectionProfiles)
              {
                if (!flag2)
                {
                  int num11 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("TransitioningDistanceAndRadiusInvalidMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                }
                intersectionProfiles = true;
              }
              _IntersectionStations[index1].IntersectionStations[index2].IntersectionLeg = (Eps_Leg) null;
            }
          }
          flag1 = false;
        }
      }
    }
    return intersectionProfiles;
  }

  private static List<FamilyInstance> GetSiteComponentPlacementFamilyInstances(
    Document _Document,
    string _strTopoSurfaceId)
  {
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    List<FamilyInstance> placementFamilyInstances = new List<FamilyInstance>();
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    foreach (Element element in list)
    {
      if (element is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
      {
        SiteworksIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (SiteworksIDParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
        {
          LandcaddID landcaddId = LandcaddID.SoftTerrain;
          Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
          if (parameter1 != null)
          {
            foreach (int num in Enum.GetValues(typeof (LandcaddID)))
            {
              if (string.Compare(parameter1.AsString(), num.ToString("000"), true) == 0)
              {
                landcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
                break;
              }
            }
          }
          switch (landcaddId)
          {
            case LandcaddID.Curb:
              Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
              if (parameter2 != null && string.Compare(_strTopoSurfaceId, parameter2.AsString(), false) == 0)
              {
                placementFamilyInstances.Add(familyInstance);
                continue;
              }
              continue;
            case LandcaddID.ParkingLot:
              Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
              if (parameter3 != null && string.Compare(_strTopoSurfaceId, parameter3.AsString(), false) == 0)
              {
                placementFamilyInstances.Add(familyInstance);
                continue;
              }
              continue;
            default:
              continue;
          }
        }
      }
    }
    return placementFamilyInstances;
  }

  private static List<Eps_Point> GetParkingLotTopoSurfacePoints(
    Eps_Leg _CurrentLeg,
    List<Eps_Point> _TopoPointList,
    double _dLinearInterval,
    double _dRadialInterval,
    double _dArcPointInterval,
    string _strPathName,
    TopographySurfaceContainer _ProposedSurface)
  {
    int nLineCount = 0;
    int nArcCount = 0;
    Eps_Line[] aLines = (Eps_Line[]) null;
    Eps_Arc[] aArcs = (Eps_Arc[]) null;
    int[] aLegOrder = (int[]) null;
    Eps_Point[] _aCutFillPoints = (Eps_Point[]) null;
    int _nNumCutFillPoints = 0;
    List<Eps_Point> topoSurfacePoints = new List<Eps_Point>();
    Eps_Line[] _aLeftCatchLines = (Eps_Line[]) null;
    int _nNumLeftCatchLines = 0;
    Eps_Line[] _aRightCatchLines = (Eps_Line[]) null;
    int _nNumRightCatchLines = 0;
    Eps_Line[] _aLeftCutFillLines = (Eps_Line[]) null;
    int _nNumLeftCutFillLines = 0;
    Eps_Line[] _aRightCutFillLines = (Eps_Line[]) null;
    int _nNumRightCutFillLines = 0;
    _CurrentLeg.ConvertLegToLineArcArrays(ref aLines, ref nLineCount, ref aArcs, ref nArcCount, ref aLegOrder, _ProposedSurface, false, false, 0.0, false);
    Eps_Point[] array = _TopoPointList.ToArray();
    int count = _TopoPointList.Count;
    EPSharedExternal.CreateCutAndFillFromTopo(_strPathName, aLines, nLineCount, aArcs, nArcCount, aLegOrder, array, count, _dLinearInterval, _dRadialInterval, _dArcPointInterval, 0.0, 0.0, 0.0, 0.01, 0.01, 1, 0.0, false, true, 0.0, 0.0, 0.0, 0.0, ref _aCutFillPoints, ref _nNumCutFillPoints, ref _aLeftCatchLines, ref _nNumLeftCatchLines, ref _aRightCatchLines, ref _nNumRightCatchLines, ref _aLeftCutFillLines, ref _nNumLeftCutFillLines, ref _aRightCutFillLines, ref _nNumRightCutFillLines);
    if (_aCutFillPoints != null)
      topoSurfacePoints = ((IEnumerable<Eps_Point>) _aCutFillPoints).ToList<Eps_Point>();
    for (int index = 0; index < _nNumLeftCatchLines; ++index)
    {
      topoSurfacePoints.Add(_aLeftCatchLines[index].StartPnt);
      topoSurfacePoints.Add(_aLeftCatchLines[index].EndPnt);
    }
    for (int index = 0; index < _nNumRightCatchLines; ++index)
    {
      topoSurfacePoints.Add(_aRightCatchLines[index].StartPnt);
      topoSurfacePoints.Add(_aRightCatchLines[index].EndPnt);
    }
    for (int index = 0; index < _nNumLeftCutFillLines; ++index)
    {
      topoSurfacePoints.Add(_aLeftCutFillLines[index].StartPnt);
      topoSurfacePoints.Add(_aLeftCutFillLines[index].EndPnt);
    }
    for (int index = 0; index < _nNumRightCutFillLines; ++index)
    {
      topoSurfacePoints.Add(_aRightCutFillLines[index].StartPnt);
      topoSurfacePoints.Add(_aRightCutFillLines[index].EndPnt);
    }
    return topoSurfacePoints;
  }

  private static TopographySurface CreateAdditionalTopoSurface(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    List<Eps_Point> _NewSurfacePoints,
    TopographySurfaceContainer _ProposedSurface)
  {
    int _nReturnValue = -1;
    if (_PlacementSettings.LocateType == LandcaddID.Curb)
    {
      if (ApplicationUtility.Settings.eplSetE_GetSetting(_Document.PathName, "ParkingLotIslandToposurfaceMaterialParameter", ref _nReturnValue))
      {
        ElementId elementId = new ElementId(_nReturnValue);
        bool flag = false;
        foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(_Document).OfClass(typeof (Material)).OfCategory((BuiltInCategory) -2000700).ToElements())
        {
          if (ElementId.op_Equality(element.Id, elementId))
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          _nReturnValue = -1;
      }
      if (_nReturnValue == -1)
      {
        Parameter parameter = ((Element) _ProposedSurface.TopographySurface)[(BuiltInParameter) -1002107];
        if (parameter != null)
          _nReturnValue = parameter.AsElementId().IntegerValue;
      }
    }
    else if (_PlacementSettings.LocateType == LandcaddID.ParkingLot)
    {
      Parameter parameter = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.ParkingLotParkingPavementSurfaceParameter);
      if (parameter != null)
        _nReturnValue = parameter.AsInteger();
    }
    return TopographySurfaceManagement.CreateAdditionalTopoSurface(_Document, _PlacementSettings, _NewSurfacePoints, _ProposedSurface, _nReturnValue);
  }

  private static TopographySurface CreateAdditionalTopoSurface(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    List<Eps_Point> _NewSurfacePoints,
    TopographySurfaceContainer _ProposedSurface,
    int _nMaterialId)
  {
    TopographySurface additionalTopoSurface = (TopographySurface) null;
    if (_NewSurfacePoints != null && _NewSurfacePoints.Count > 0)
    {
      List<XYZ> PointXYZList = new List<XYZ>();
      for (int index = 0; index < _NewSurfacePoints.Count; ++index)
        PointXYZList.Add(_NewSurfacePoints[index].XYZ);
      if (PointXYZList.Count > 0)
      {
        TopographySurfaceManagement.RemoveDuplicateXY(ref PointXYZList);
        additionalTopoSurface = TopographySurface.Create(_Document, (IList<XYZ>) PointXYZList);
        _Document.Regenerate();
      }
      if (additionalTopoSurface != null)
      {
        if (_PlacementSettings.LocateType == LandcaddID.Curb)
        {
          Parameter parameter1 = ((Element) additionalTopoSurface)[(BuiltInParameter) -1002107];
          if (parameter1 != null && !((APIObject) parameter1).IsReadOnly && _nMaterialId != -1)
          {
            ElementId elementId = new ElementId(_nMaterialId);
            parameter1.Set(elementId);
          }
          int nBeginningIndex = 0;
          string empty = string.Empty;
          string str = !TopographySurfaceManagement.GetIslandFamiliesCount(_Document, _PlacementSettings.Name, ref nBeginningIndex) ? _PlacementSettings.Name : $"{_PlacementSettings.Name}-{nBeginningIndex.ToString()}";
          Parameter parameter2 = ((Element) additionalTopoSurface)[(BuiltInParameter) -1006900];
          if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
            parameter2.Set(str);
        }
        else if (_PlacementSettings.LocateType == LandcaddID.ParkingLot)
        {
          Parameter parameter3 = ((Element) additionalTopoSurface)[(BuiltInParameter) -1002107];
          if (parameter3 != null && !((APIObject) parameter3).IsReadOnly && _nMaterialId != -1)
          {
            ElementId elementId = new ElementId(_nMaterialId);
            parameter3.Set(elementId);
          }
          Parameter parameter4 = ((Element) additionalTopoSurface)[(BuiltInParameter) -1006900];
          if (parameter4 != null && !((APIObject) parameter4).IsReadOnly)
            parameter4.Set(_PlacementSettings.Name);
        }
        foreach (Phase phase in _Document.Phases)
        {
          if (_Document.DisplayUnitSystem == 1 && ((Element) phase).Id.IntegerValue == 118390 || _Document.DisplayUnitSystem == null && ((Element) phase).Id.IntegerValue == 86961 || string.Compare(((Element) phase).Name, EPShared.LocalRM.GetString("NewConstructionString"), true) == 0)
          {
            Parameter parameter = ((Element) additionalTopoSurface)[(BuiltInParameter) -1012100];
            if (parameter != null && !((APIObject) parameter).IsReadOnly)
            {
              ElementId id = ((Element) phase).Id;
              parameter.Set(id);
            }
          }
        }
      }
    }
    return additionalTopoSurface;
  }

  private static bool GetIslandFamiliesCount(
    Document _Document,
    string _strFindName,
    ref int nBeginningIndex)
  {
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    List<string> stringList = new List<string>();
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements();
    string empty1 = string.Empty;
    foreach (Element element1 in (IEnumerable<Element>) elements)
    {
      if (element1 != null && element1.Category != null)
      {
        int integerValue1 = element1.Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001340;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1)
        {
          string uniqueId = element1.UniqueId;
          foreach (Element element2 in list)
          {
            if (element2 is FamilyInstance familyInstance && ((Element) familyInstance).Category != null)
            {
              int integerValue2 = ((Element) familyInstance).Category.Id.IntegerValue;
              builtInCategory = (BuiltInCategory) -2001260;
              int hashCode2 = builtInCategory.GetHashCode();
              if (integerValue2 == hashCode2)
              {
                SiteworksIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
                if (SiteworksIDParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
                {
                  Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.IslandSurfaceIdFamilyParameter);
                  if (parameter1 != null && string.Compare(uniqueId, parameter1.AsString(), false) == 0)
                  {
                    Parameter parameter2 = element1[(BuiltInParameter) -1006900];
                    if (parameter2 != null && parameter2.AsString() != null && parameter2.AsString() != string.Empty)
                    {
                      stringList.Add(parameter2.AsString());
                      break;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    nBeginningIndex = 0;
    string str1 = "-";
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    bool flag = true;
    bool islandFamiliesCount = false;
    for (int index1 = 0; index1 < stringList.Count; ++index1)
    {
      string strA = stringList[index1];
      int startIndex = strA.LastIndexOf(str1);
      if (startIndex >= 0 && startIndex < strA.Length)
      {
        string str2 = strA.Substring(startIndex);
        if (str2.StartsWith(str1) && str2.Length > str1.Length)
        {
          string str3 = str2.Substring(str1.Length);
          for (int index2 = 0; index2 < str3.Length; ++index2)
          {
            if (!char.IsDigit(str3[index2]))
            {
              flag = false;
              break;
            }
          }
          if (flag)
          {
            islandFamiliesCount = true;
            int int32 = Convert.ToInt32(str3);
            if (int32 > nBeginningIndex)
              nBeginningIndex = int32;
          }
          else
            flag = true;
        }
      }
      else if (string.Compare(strA, _strFindName, true) == 0)
        islandFamiliesCount = true;
    }
    ++nBeginningIndex;
    return islandFamiliesCount;
  }

  public static bool RebuildProposedTopographySurface(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    double _dArcPointInterval,
    Eps_Leg _CurrentLeg,
    TopographySurfaceContainer _ProposedSurface,
    List<Element> _ElementList,
    bool _bDrawForm,
    List<Eps_Leg> _ParkingLotBreaklineList,
    List<Element> _ParkingLotBreaklineElementList,
    List<double> _dParkingLotBreaklineLinearPointIntervals,
    List<IntersectionStationContainer> _LeftIntersectionStations,
    List<IntersectionStationContainer> _CenterIntersectionStations,
    List<IntersectionStationContainer> _RightIntersectionStations,
    List<IntersectionContainer> _IntersectionContainers,
    ref List<Eps_Point> _TopoPointList)
  {
    TopographySurfaceContainer _ParkingLotSurface = (TopographySurfaceContainer) null;
    List<Eps_Point> _ParkingLotTopoPointList = (List<Eps_Point>) null;
    List<Eps_Point> _CrownPointList = new List<Eps_Point>();
    List<FamilyInstance> _FamilyInstanceList = (List<FamilyInstance>) null;
    return TopographySurfaceManagement.RebuildProposedTopographySurface(_Document, _PlacementSettings, _dArcPointInterval, _CurrentLeg, _ProposedSurface, _ElementList, _bDrawForm, _ParkingLotBreaklineList, _ParkingLotBreaklineElementList, _dParkingLotBreaklineLinearPointIntervals, _LeftIntersectionStations, _CenterIntersectionStations, _RightIntersectionStations, _IntersectionContainers, ref _TopoPointList, ref _CrownPointList, ref _ParkingLotSurface, ref _ParkingLotTopoPointList, ref _FamilyInstanceList);
  }

  public static bool RebuildProposedTopographySurface(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    double _dArcPointInterval,
    Eps_Leg _CurrentLeg,
    TopographySurfaceContainer _ProposedSurface,
    List<Element> _ElementList,
    bool _bDrawForm,
    List<Eps_Leg> _ParkingLotBreaklineList,
    List<Element> _ParkingLotBreaklineElementList,
    List<double> _dParkingLotBreaklineLinearPointIntervals,
    List<IntersectionStationContainer> _LeftIntersectionStations,
    List<IntersectionStationContainer> _CenterIntersectionStations,
    List<IntersectionStationContainer> _RightIntersectionStations,
    List<IntersectionContainer> _IntersectionContainers,
    ref List<Eps_Point> _TopoPointList,
    ref List<Eps_Point> _CrownPointList)
  {
    TopographySurfaceContainer _ParkingLotSurface = (TopographySurfaceContainer) null;
    List<Eps_Point> _ParkingLotTopoPointList = (List<Eps_Point>) null;
    List<FamilyInstance> _FamilyInstanceList = (List<FamilyInstance>) null;
    return TopographySurfaceManagement.RebuildProposedTopographySurface(_Document, _PlacementSettings, _dArcPointInterval, _CurrentLeg, _ProposedSurface, _ElementList, _bDrawForm, _ParkingLotBreaklineList, _ParkingLotBreaklineElementList, _dParkingLotBreaklineLinearPointIntervals, _LeftIntersectionStations, _CenterIntersectionStations, _RightIntersectionStations, _IntersectionContainers, ref _TopoPointList, ref _CrownPointList, ref _ParkingLotSurface, ref _ParkingLotTopoPointList, ref _FamilyInstanceList);
  }

  private static bool hasContainer(
    List<IntersectionContainer> containers,
    IntersectionContainer container)
  {
    foreach (IntersectionContainer container1 in containers)
    {
      if (container1.IsEqual(container))
        return true;
    }
    return false;
  }

  public static bool RebuildProposedTopographySurface(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    double _dArcPointInterval,
    Eps_Leg _CurrentLeg,
    TopographySurfaceContainer _ProposedSurface,
    List<Element> _ElementList,
    bool _bModifiedSiteComponent,
    List<Eps_Leg> _ParkingLotBreaklineList,
    List<Element> _ParkingLotBreaklineElementList,
    List<double> _dParkingLotBreaklineLinearPointIntervals,
    List<IntersectionStationContainer> _LeftIntersectionStations,
    List<IntersectionStationContainer> _CenterIntersectionStations,
    List<IntersectionStationContainer> _RightIntersectionStations,
    List<IntersectionContainer> _IntersectionContainers,
    ref List<Eps_Point> _TopoPointList,
    ref List<Eps_Point> _CrownPointList,
    ref TopographySurfaceContainer _ParkingLotSurface,
    ref List<Eps_Point> _ParkingLotTopoPointList,
    ref List<FamilyInstance> _FamilyInstanceList)
  {
    List<Eps_Point> _AddPointList = new List<Eps_Point>();
    int nLineCount1 = 0;
    int nArcCount1 = 0;
    Eps_Line[] aLines1 = (Eps_Line[]) null;
    Eps_Arc[] aArcs1 = (Eps_Arc[]) null;
    int[] aLegOrder1 = (int[]) null;
    List<OffsetLegWrapper> _OffsetLegWrappers = new List<OffsetLegWrapper>();
    List<Eps_Point> epsPointList1 = new List<Eps_Point>();
    int nLineCount2 = 0;
    int nArcCount2 = 0;
    Eps_Line[] aLines2 = (Eps_Line[]) null;
    Eps_Arc[] aArcs2 = (Eps_Arc[]) null;
    int[] aLegOrder2 = (int[]) null;
    bool _bUseToposurfaceElevation = false;
    bool _bUseConstantElevation = false;
    double _dElevation1 = 0.0;
    double _dElevation2 = 0.0;
    double _dAdditionalOffsetWidth = 0.0;
    double dCutSlope = 3.0;
    double dFillSlope = 3.0;
    double num1 = 15.0;
    double num2 = 3.0;
    double num3 = 0.0;
    double num4 = 0.0;
    double dBoulevardWidth = 0.0;
    double dLeftSubgradeAdjustElev = 0.0;
    double dRightSubgradeAdjustElev = 0.0;
    double num5 = 0.0;
    bool bIsCrownPresent = false;
    bool bIsProjectLegToTopo = false;
    double dLeftEdgeAdjustElev = 0.0;
    double dRightEdgeAdjustElev = 0.0;
    double num6 = 0.0;
    double _dStreetEdgeAdjustElev = 0.0;
    Eps_Leg _OriginaltLeg = Eps_Leg.CopyLeg(_CurrentLeg);
    if (_PlacementSettings.Type != null)
    {
      switch (_PlacementSettings.LocateType)
      {
        case LandcaddID.SoftTerrain:
          Parameter parameter1 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainCutSlopeParameter);
          if (parameter1 != null)
            dCutSlope = 1.0 / parameter1.AsDouble();
          Parameter parameter2 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainFillSlopeParameter);
          if (parameter2 != null)
            dFillSlope = 1.0 / parameter2.AsDouble();
          Parameter parameter3 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainLeftOffsetWidthParameter);
          if (parameter3 != null)
            num3 = parameter3.AsDouble();
          Parameter parameter4 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SoftTerrainRightOffsetWidthParameter);
          if (parameter4 != null)
          {
            num4 = parameter4.AsDouble();
            break;
          }
          break;
        case LandcaddID.Street:
          Parameter parameter5 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCutSlopeParameter);
          if (parameter5 != null)
            dCutSlope = 1.0 / parameter5.AsDouble();
          Parameter parameter6 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetFillSlopeParameter);
          if (parameter6 != null)
            dFillSlope = 1.0 / parameter6.AsDouble();
          double num7 = 0.0;
          Parameter parameter7 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetLaneWidthParameter);
          if (parameter7 != null)
            num7 = parameter7.AsDouble();
          Parameter parameter8 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
          if (parameter8 != null)
          {
            num3 = num7 * (double) parameter8.AsInteger() / 2.0;
            num4 = num7 * (double) parameter8.AsInteger() / 2.0;
          }
          Parameter parameter9 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
          if (parameter9 != null)
          {
            dLeftEdgeAdjustElev = -num3 * parameter9.AsDouble();
            dRightEdgeAdjustElev = -num4 * parameter9.AsDouble();
            _dStreetEdgeAdjustElev = -(num3 + num4) / 2.0 * parameter9.AsDouble();
          }
          Parameter parameter10 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
          if (parameter10 != null && parameter10.AsInteger() != 0)
          {
            double num8 = 0.0;
            double num9 = 0.0;
            double num10 = 0.0;
            Parameter parameter11 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterWidthParameter);
            if (parameter11 != null)
            {
              num8 = parameter11.AsDouble();
              num3 += num8;
              num4 += num8;
              _dAdditionalOffsetWidth = num8;
            }
            Parameter parameter12 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbWidthParameter);
            if (parameter12 != null)
            {
              num3 += parameter12.AsDouble();
              num4 += parameter12.AsDouble();
              _dAdditionalOffsetWidth += parameter12.AsDouble();
            }
            Parameter parameter13 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbHeightParameter);
            if (parameter13 != null)
              num10 = parameter13.AsDouble();
            Parameter parameter14 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterSlopeParameter);
            if (parameter14 != null)
              num9 = parameter14.AsDouble();
            dLeftEdgeAdjustElev += num10 - num8 * num9;
            dRightEdgeAdjustElev += num10 - num8 * num9;
            dLeftSubgradeAdjustElev = num10;
            dRightSubgradeAdjustElev = num10;
          }
          Parameter parameter15 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetPavementDepthParameter);
          if (parameter15 != null)
            num5 = -parameter15.AsDouble();
          Parameter parameter16 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetBoulevardWidthParameter);
          if (parameter16 != null)
          {
            dBoulevardWidth = parameter16.AsDouble();
            num3 += dBoulevardWidth;
            num4 += dBoulevardWidth;
            _dAdditionalOffsetWidth += dBoulevardWidth;
          }
          bIsCrownPresent = true;
          break;
        case LandcaddID.Curb:
          double num11 = 0.0;
          double num12 = 0.0;
          double num13 = 0.0;
          double num14 = 0.0;
          double num15 = 0.0;
          Parameter parameter17 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterWidthParameter);
          if (parameter17 != null)
            num13 = parameter17.AsDouble();
          Parameter parameter18 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbWidthParameter);
          if (parameter18 != null)
            num11 = parameter18.AsDouble();
          if (_PlacementSettings.UseRightSide)
          {
            num4 = num13 + num11;
            num3 = 0.0;
          }
          else
          {
            num3 = num13 + num11;
            num4 = 0.0;
          }
          Parameter parameter19 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetCurbHeightParameter);
          if (parameter19 != null)
            num14 = parameter19.AsDouble();
          Parameter parameter20 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.CurbGutterHeightParameter);
          if (parameter20 != null)
            num12 = parameter20.AsDouble();
          Parameter parameter21 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.StreetGutterSlopeParameter);
          if (parameter21 != null)
            num15 = parameter21.AsDouble();
          if (num4 == 0.0)
          {
            dRightSubgradeAdjustElev = num12 + (num11 + num13) * num15;
            dLeftSubgradeAdjustElev = num12;
          }
          else if (num3 == 0.0)
          {
            dLeftSubgradeAdjustElev = num12 + (num11 + num13) * num15;
            dRightSubgradeAdjustElev = num12;
          }
          _bUseToposurfaceElevation = true;
          _bUseConstantElevation = false;
          TopographySurfaceManagement.m_dCurbElevation = num14 - num13 * num15;
          _dElevation1 = -TopographySurfaceManagement.m_dCurbElevation;
          _PlacementSettings.ProjectInnerSlopes = 5;
          break;
        case LandcaddID.Sidewalk:
          Parameter parameter22 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkCutSlopeParameter);
          if (parameter22 != null)
            dCutSlope = 1.0 / parameter22.AsDouble();
          Parameter parameter23 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkFillSlopeParameter);
          if (parameter23 != null)
            dFillSlope = 1.0 / parameter23.AsDouble();
          Parameter parameter24 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkWidthParameter);
          if (parameter24 != null)
          {
            double num16 = parameter24.AsDouble();
            num3 = num16 / 2.0;
            num4 = num16 / 2.0;
          }
          Parameter parameter25 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.SideWalkPavementDepthParameter);
          if (parameter25 != null)
          {
            num5 = -parameter25.AsDouble();
            break;
          }
          break;
        case LandcaddID.RetainingWall:
          Parameter parameter26 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallCutSlopeParameter);
          if (parameter26 != null)
            dCutSlope = 1.0 / parameter26.AsDouble();
          Parameter parameter27 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallFillSlopeParameter);
          if (parameter27 != null)
            dFillSlope = 1.0 / parameter27.AsDouble();
          Parameter parameter28 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallWidthParameter);
          if (parameter28 != null)
          {
            double num17 = parameter28.AsDouble();
            num3 = num17 / 2.0;
            num4 = num17 / 2.0;
          }
          bool flag = false;
          double num18 = 0.0;
          Parameter parameter29 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallSlopeProjectionParameter);
          if (parameter29 != null)
            flag = parameter29.AsInteger() == 1;
          Parameter parameter30 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.RetainingWallHeightParameter);
          if (parameter30 != null)
            num18 = parameter30.AsDouble();
          if (_PlacementSettings.IsRelativeElevation)
          {
            num5 = -(num18 - _PlacementSettings.Elevation);
            _bUseToposurfaceElevation = true;
            _bUseConstantElevation = false;
            _dElevation2 = _PlacementSettings.Elevation;
          }
          else
          {
            _dElevation1 = _PlacementSettings.Elevation - num18;
            _bUseToposurfaceElevation = false;
            _bUseConstantElevation = true;
            _dElevation2 = num18;
            num6 = _dElevation1;
          }
          if (flag)
          {
            if (_PlacementSettings.UseRightSide)
            {
              dRightEdgeAdjustElev = !_PlacementSettings.IsRelativeElevation ? num18 : _PlacementSettings.Elevation;
              _PlacementSettings.ProjectInnerSlopes = 3;
            }
            else
            {
              dLeftEdgeAdjustElev = !_PlacementSettings.IsRelativeElevation ? num18 : _PlacementSettings.Elevation;
              _PlacementSettings.ProjectInnerSlopes = 2;
            }
          }
          else
            _PlacementSettings.ProjectInnerSlopes = 4;
          bIsProjectLegToTopo = !_PlacementSettings.IsRelativeElevation;
          dLeftSubgradeAdjustElev = dLeftEdgeAdjustElev;
          dRightSubgradeAdjustElev = dRightEdgeAdjustElev;
          break;
        case LandcaddID.ParkingLot:
          Eps_Leg ppOffsetLegList1 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 1, ref ppOffsetLegList1, true);
          Eps_Leg ppOffsetLegList2 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 2, ref ppOffsetLegList2, true);
          _CurrentLeg = RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2) <= RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1) ? ppOffsetLegList1 : ppOffsetLegList2;
          Parameter parameter31 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.ParkingLotPavementDepthParameter);
          if (parameter31 != null)
          {
            dLeftSubgradeAdjustElev = parameter31.AsDouble();
            dRightSubgradeAdjustElev = parameter31.AsDouble();
          }
          dCutSlope = 0.01;
          dFillSlope = 0.01;
          bIsProjectLegToTopo = true;
          _PlacementSettings.ProjectInnerSlopes = 1;
          break;
      }
      Parameter parameter32 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.LinearIncrementParameter);
      if (parameter32 != null)
        num1 = parameter32.AsDouble();
      if (RevitDefines.LT(num1, 0.0833333))
        num1 = 0.0833333;
      Parameter parameter33 = ((Element) _PlacementSettings.Type).LookupParameter(RevitParameters.CurveIncrementParameter);
      if (parameter33 != null)
        num2 = RevitGeometry.RadiansToDecimalDegrees(EPShared.eplGeoE_NormalizeRadians(parameter33.AsDouble()));
      if (RevitDefines.LT(num2, 1.0))
        num2 = 1.0;
    }
    List<double> _Stations = new List<double>();
    List<Eps_Point> _ApplySurfaceElevationPoints = new List<Eps_Point>();
    if (_CenterIntersectionStations != null && _CenterIntersectionStations.Count > 0)
    {
      for (int index1 = 0; index1 < _CenterIntersectionStations.Count; ++index1)
      {
        for (int index2 = 0; index2 < _CenterIntersectionStations[index1].IntersectionStations.Count; ++index2)
        {
          _Stations.Add(_CenterIntersectionStations[index1].IntersectionStations[index2].Station);
          Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_CenterIntersectionStations, index1, index2, false);
          if (intersectionStationPoint != null)
            _ApplySurfaceElevationPoints.Add(intersectionStationPoint);
        }
      }
    }
    _CurrentLeg = _CurrentLeg.SplitLegAtStations(_Stations);
    if (_PlacementSettings.LocateType != LandcaddID.FeatureLine && _PlacementSettings.LocateType != LandcaddID.PointWipeout)
      _CurrentLeg.ConvertLegToLineArcArrays(ref aLines2, ref nLineCount2, ref aArcs2, ref nArcCount2, ref aLegOrder2, (TopographySurfaceContainer) null, _bUseToposurfaceElevation, _bUseConstantElevation, _dElevation1, true, _ApplySurfaceElevationPoints);
    else if (_PlacementSettings.LocateType == LandcaddID.FeatureLine)
    {
      num1 = _PlacementSettings.LinearPointInterval;
      if (RevitDefines.LT(num1, 0.0833333))
        num1 = 0.0833333;
    }
    double _dConstElevation = _PlacementSettings.LocateType != LandcaddID.RetainingWall ? 0.0 : num6;
    _CurrentLeg = _CurrentLeg.ApplyElevationsToLeg((TopographySurfaceContainer) null, _bUseToposurfaceElevation, _bUseConstantElevation, _dConstElevation, _ApplySurfaceElevationPoints);
    List<IntersectionContainer> _IntersectionContainers1 = new List<IntersectionContainer>();
    TopographySurfaceManagement.FindOffsetLegWrappers(_OriginaltLeg, _CurrentLeg, _LeftIntersectionStations, _CenterIntersectionStations, _RightIntersectionStations, _PlacementSettings.LocateType, num3, num4, _dAdditionalOffsetWidth, num5, _dStreetEdgeAdjustElev, ref _OffsetLegWrappers, ref _IntersectionContainers1);
    foreach (IntersectionContainer container in _IntersectionContainers1)
    {
      if (!TopographySurfaceManagement.hasContainer(_IntersectionContainers, container))
        _IntersectionContainers.Add(container);
    }
    IntersectionContainerComparer containerComparer = new IntersectionContainerComparer(true);
    if (_IntersectionContainers != null && _IntersectionContainers.Count > 0)
      _IntersectionContainers.Sort((IComparer<IntersectionContainer>) containerComparer);
    Eps_Leg ppOffsetLegList3;
    if (_bModifiedSiteComponent)
    {
      Eps_Leg epsLeg;
      if (RevitDefines.EQ(num4 + num3, 0.0))
      {
        epsLeg = Eps_Leg.CopyLeg(_CurrentLeg);
      }
      else
      {
        ppOffsetLegList3 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, num4, 1, ref ppOffsetLegList3, true);
        Eps_Leg ppOffsetLegList4 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, num3, 2, ref ppOffsetLegList4, true);
        epsLeg = Eps_Leg.CopyLeg(ppOffsetLegList3.Reverse());
        Eps_Leg _CompleteLeg1 = new Eps_Leg();
        _CompleteLeg1.Line = new Eps_Line();
        _CompleteLeg1.Line.StartPnt = ppOffsetLegList3.LegEndPnt;
        _CompleteLeg1.Line.EndPnt = ppOffsetLegList4.LegEndPnt;
        epsLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
        epsLeg.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList4);
        Eps_Leg _CompleteLeg2 = new Eps_Leg();
        _CompleteLeg2.Line = new Eps_Line();
        _CompleteLeg2.Line.StartPnt = ppOffsetLegList4.LegStartPnt;
        _CompleteLeg2.Line.EndPnt = ppOffsetLegList3.LegStartPnt;
        epsLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
      }
      if (epsLeg != null)
      {
        List<Eps_Point> pointsAtIntervals = epsLeg.GetPointsAtIntervals(1.0, 1.0);
        for (int index = 0; index < pointsAtIntervals.Count; ++index)
        {
          TopographySurfaceContainer containerContainingPoint = _ProposedSurface.GetSurfaceContainerContainingPoint(pointsAtIntervals[index]);
          if (containerContainingPoint == null)
          {
            epsLeg.ConvertLegToLineArcArrays(ref aLines1, ref nLineCount1, ref aArcs1, ref nArcCount1, ref aLegOrder1, false);
            int nLineCount3 = 0;
            int nArcCount3 = 0;
            Eps_Line[] aLines3 = (Eps_Line[]) null;
            Eps_Arc[] aArcs3 = (Eps_Arc[]) null;
            int[] aLegOrder3 = (int[]) null;
            if (_ProposedSurface.BoundaryLeg != null)
            {
              _ProposedSurface.BoundaryLeg.ConvertLegToLineArcArrays(ref aLines3, ref nLineCount3, ref aArcs3, ref nArcCount3, ref aLegOrder3, false);
              if (!EPShared.eplGeoE_IsLegListInsideLegList(aLines1, nLineCount1, aArcs1, nArcCount1, aLegOrder1, aLines3, nLineCount3, aArcs3, nArcCount3, aLegOrder3, 1E-05))
              {
                int num19 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("LineSegmentsOutsideToposurfaceMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return false;
              }
            }
          }
          else if (containerContainingPoint.TopographySurfaceType == TopographySurfaceType.BuildingPad)
          {
            int num20 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("LineSegmentsInsideBuildingPadMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return false;
          }
        }
      }
      if (_LeftIntersectionStations != null && _RightIntersectionStations != null && _LeftIntersectionStations.Count > 0 && _LeftIntersectionStations.Count == _RightIntersectionStations.Count)
      {
        if (_PlacementSettings.IntersectionStations == null)
          _PlacementSettings.IntersectionStations = new List<IntersectionStationContainer>();
        _PlacementSettings.IntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
        _PlacementSettings.IntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
      }
      switch (_PlacementSettings.LocateType)
      {
        case LandcaddID.Street:
          StreetForm streetForm = new StreetForm(_PlacementSettings.Type, _CurrentLeg);
          streetForm.IntersectionContainers = _IntersectionContainers;
          string empty = string.Empty;
          _PlacementSettings.LoftFormID = streetForm.CreateForm(_Document, _PlacementSettings.Name, ref empty);
          _PlacementSettings.AdditionalLoftFormID = empty;
          if (_PlacementSettings.LoftFormID == string.Empty)
            return false;
          break;
        case LandcaddID.Curb:
          CurbForm curbForm = new CurbForm(_PlacementSettings.Type, _CurrentLeg, false, _PlacementSettings.UseRightSide);
          _PlacementSettings.LoftFormID = curbForm.CreateForm(_Document, _PlacementSettings.Name, false, 0.0);
          if (_PlacementSettings.LoftFormID == string.Empty)
            return false;
          break;
        case LandcaddID.Sidewalk:
          SidewalkForm sidewalkForm = new SidewalkForm(_PlacementSettings.Type, _CurrentLeg);
          sidewalkForm.IntersectionContainers = _IntersectionContainers;
          _PlacementSettings.LoftFormID = sidewalkForm.CreateForm(_Document, _PlacementSettings.Name);
          if (_PlacementSettings.LoftFormID == string.Empty)
            return false;
          break;
        case LandcaddID.RetainingWall:
          RetainingWallForm retainingWallForm = new RetainingWallForm(_PlacementSettings.Type, _CurrentLeg, _dElevation2);
          _PlacementSettings.LoftFormID = retainingWallForm.CreateForm(_Document, _PlacementSettings.Name);
          if (_PlacementSettings.LoftFormID == string.Empty)
            return false;
          break;
      }
    }
    int _nReturnValue = 0;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("MassCreationOnlyMode", ref _nReturnValue))
      ApplicationUtility.Settings.eplSetE_SetSetting("MassCreationOnlyMode", 0);
    if (_nReturnValue == 0)
    {
      ProgressBarForm _ProgressFrm = (ProgressBarForm) null;
      Eps_Leg _CatchLineLeg = (Eps_Leg) null;
      Eps_Leg _FeatureLineLeg = (Eps_Leg) null;
      Eps_Leg _OriginalBoundaryLeg = (Eps_Leg) null;
      bool flag1 = false;
      if (_TopoPointList.Count == 0)
      {
        Eps_Point pMinPnt = new Eps_Point();
        Eps_Point epsPoint = new Eps_Point();
        RevitGeometry.eplGeoE_FindMinMaxOfLineArcList(aLines2, nLineCount2, aArcs2, nArcCount2, ref pMinPnt, ref epsPoint);
        Eps_Point _NewPnt = new Eps_Point(pMinPnt.x, pMinPnt.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z);
        epsPoint = new Eps_Point(epsPoint.x, epsPoint.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z);
        double num21 = num3;
        if (num21 < num4)
          num21 = num4;
        double num22 = dCutSlope;
        if (num22 > dFillSlope)
          num22 = dFillSlope;
        double num23 = 100.0 / num22;
        double num24 = 0.0;
        for (int index = 0; index < nLineCount2; ++index)
        {
          if (aLines2[index].StartPnt.z > num24)
            num24 = aLines2[index].StartPnt.z;
          if (aLines2[index].EndPnt.z > num24)
            num24 = aLines2[index].EndPnt.z;
        }
        for (int index = 0; index < nArcCount2; ++index)
        {
          if (aArcs2[index].StartPnt.z > num24)
            num24 = aArcs2[index].StartPnt.z;
          if (aArcs2[index].EndPnt.z > num24)
            num24 = aArcs2[index].EndPnt.z;
        }
        double num25 = num24 * num23;
        double _dDirection = 0.0;
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_NewPnt, epsPoint, ref _dDirection);
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), num25 + num21 + 1.0, ref _NewPnt);
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, _dDirection, num25 + num21 + 1.0, ref epsPoint);
        _TopoPointList.Add(_NewPnt);
        _TopoPointList.Add(new Eps_Point(_NewPnt.x, epsPoint.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z));
        _TopoPointList.Add(epsPoint);
        _TopoPointList.Add(new Eps_Point(epsPoint.x, _NewPnt.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z));
      }
      else
        flag1 = true;
      if (_PlacementSettings.LocateType != LandcaddID.FeatureLine && _PlacementSettings.LocateType != LandcaddID.PointWipeout)
      {
        if (_bModifiedSiteComponent)
        {
          _ProgressFrm = new ProgressBarForm();
          _ProgressFrm.ShowForm();
          _ProgressFrm.Refresh();
          _ProgressFrm.MinValue = 0;
          _ProgressFrm.MaxValue = 8;
          _ProgressFrm.Message = EPShared.LocalRM.GetString("ProgressBarProcessingSelectedSiteComponentPointsMessage");
        }
        TopographySurfaceManagement.GetToposurfacePoints(_CurrentLeg, aLines2, nLineCount2, aArcs2, nArcCount2, aLegOrder2, _OffsetLegWrappers, _Document.PathName, _TopoPointList, num1, num2, _dArcPointInterval, num3, num4, dBoulevardWidth, dCutSlope, dFillSlope, _PlacementSettings.ProjectInnerSlopes, num5, bIsCrownPresent, bIsProjectLegToTopo, dLeftEdgeAdjustElev, dRightEdgeAdjustElev, dLeftSubgradeAdjustElev, dRightSubgradeAdjustElev, ref _AddPointList, ref _FeatureLineLeg, ref _CatchLineLeg, ref _OriginalBoundaryLeg, ref _CrownPointList, _ProgressFrm);
      }
      else if (_PlacementSettings.LocateType == LandcaddID.FeatureLine)
      {
        double _dDistance = 0.0;
        Eps_Point _StaOffPnt = (Eps_Point) null;
        for (Eps_Leg epsLeg = _CurrentLeg; epsLeg != null; epsLeg = epsLeg.Next)
        {
          double _dStation = 0.0;
          if (epsLeg.Line != null)
          {
            EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
            double num26 = (epsLeg.Line.EndPnt.z - epsLeg.Line.StartPnt.z) / _dDistance;
            for (; _dStation < _dDistance; _dStation += num1)
            {
              EPShared.eplGeoE_FindStaOffPointAlongLine(epsLeg.Line, _dStation, 0.0, ref _StaOffPnt);
              double num27 = num26 * _dStation;
              _StaOffPnt.z = epsLeg.Line.StartPnt.z + num27;
              _AddPointList.Add(_StaOffPnt);
            }
          }
          else if (epsLeg.Arc != null)
          {
            _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta);
            double num28 = (epsLeg.Arc.EndPnt.z - epsLeg.Arc.StartPnt.z) / _dDistance;
            for (; _dStation < _dDistance; _dStation += num1)
            {
              EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dStation, 0.0, ref _StaOffPnt);
              double num29 = num28 * _dStation;
              _StaOffPnt.z = epsLeg.Arc.StartPnt.z + num29;
              _AddPointList.Add(_StaOffPnt);
            }
          }
          if (epsLeg.Next == null)
            _AddPointList.Add(_CurrentLeg.LegEndPnt);
        }
      }
      if (flag1)
      {
        if (_PlacementSettings.LocateType == LandcaddID.PointWipeout)
          _CatchLineLeg = Eps_Leg.CopyLeg(_CurrentLeg);
        RevitGeometry.RemoveAllPointsInBoundary(ref _TopoPointList, _FeatureLineLeg);
        RevitGeometry.RemoveAllPointsInBoundary(ref _TopoPointList, _CatchLineLeg);
        RevitGeometry.RemoveAllPointsInBoundary(ref _TopoPointList, _OriginalBoundaryLeg);
        if (_PlacementSettings.ProjectInnerSlopes == 1)
          RevitGeometry.RemoveAllPointsInBoundary(ref _TopoPointList, _CurrentLeg);
      }
      _ProgressFrm?.UpdateProgressBar(1);
      if (_TopoPointList.Count > 0)
        _AddPointList.AddRange((IEnumerable<Eps_Point>) _TopoPointList);
      _ProgressFrm?.UpdateProgressBar(1);
      if (_bModifiedSiteComponent)
      {
        if ((_PlacementSettings.LocateType == LandcaddID.Curb || _PlacementSettings.LocateType == LandcaddID.ParkingLot) && _CurrentLeg.IsLegClosed())
        {
          List<Eps_Point> epsPointList2 = new List<Eps_Point>();
          if (_PlacementSettings.LocateType == LandcaddID.Curb)
          {
            List<Eps_Point> pointsAtIntervals = _CurrentLeg.GetPointsAtIntervals(num1, 1.0);
            TopographySurface additionalTopoSurface = TopographySurfaceManagement.CreateAdditionalTopoSurface(_Document, _PlacementSettings, pointsAtIntervals, _ProposedSurface);
            if (additionalTopoSurface != null)
              _PlacementSettings.IslandSurfaceID = ((Element) additionalTopoSurface).UniqueId;
          }
          else if (_PlacementSettings.LocateType == LandcaddID.ParkingLot)
          {
            ppOffsetLegList3 = new Eps_Leg();
            RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 1, ref ppOffsetLegList3, true);
            Eps_Leg ppOffsetLegList5 = new Eps_Leg();
            RevitGeometry.OffsetLegList(_CurrentLeg, 0.02, 2, ref ppOffsetLegList5, true);
            _CurrentLeg = RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList5) >= RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList3) ? ppOffsetLegList3 : ppOffsetLegList5;
            List<Eps_Point> topoSurfacePoints = TopographySurfaceManagement.GetParkingLotTopoSurfacePoints(_CurrentLeg, _TopoPointList, num1, num2, _dArcPointInterval, _Document.PathName, _ProposedSurface);
            if (_ParkingLotBreaklineList != null)
            {
              for (int index = 0; index < _ParkingLotBreaklineList.Count; ++index)
              {
                double num30 = RevitGeometry.eplGeoE_CalcLegListLength(_ParkingLotBreaklineList[index]);
                double num31 = (_ParkingLotBreaklineList[index].LegEndPnt.z - _ParkingLotBreaklineList[index].LegStartPnt.z) / num30;
                double num32 = 0.0;
                Eps_Point _StaOffPnt = (Eps_Point) null;
                double _dDistance = 0.0;
                double intervalFromList = TopographySurfaceManagement.FindBreaklineIntervalFromList(_ParkingLotBreaklineList[index], _ParkingLotBreaklineElementList, _dParkingLotBreaklineLinearPointIntervals);
                for (Eps_Leg epsLeg = _ParkingLotBreaklineList[index]; epsLeg != null; epsLeg = epsLeg.Next)
                {
                  double _dStation = 0.0;
                  if (epsLeg.Line != null)
                  {
                    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
                    for (; _dStation < _dDistance; _dStation += intervalFromList)
                    {
                      EPShared.eplGeoE_FindStaOffPointAlongLine(epsLeg.Line, _dStation, 0.0, ref _StaOffPnt);
                      double num33 = num31 * (num32 + _dStation);
                      _StaOffPnt.z = _ParkingLotBreaklineList[index].LegStartPnt.z + num33;
                      topoSurfacePoints.Add(_StaOffPnt);
                      _StaOffPnt = new Eps_Point(_StaOffPnt);
                      _StaOffPnt.z -= dLeftSubgradeAdjustElev;
                      _AddPointList.Add(_StaOffPnt);
                    }
                  }
                  else if (epsLeg.Arc != null)
                  {
                    for (_dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta); _dStation < _dDistance; _dStation += intervalFromList)
                    {
                      EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dStation, 0.0, ref _StaOffPnt);
                      double num34 = num31 * (num32 + _dStation);
                      _StaOffPnt.z = _ParkingLotBreaklineList[index].LegStartPnt.z + num34;
                      topoSurfacePoints.Add(_StaOffPnt);
                      _StaOffPnt = new Eps_Point(_StaOffPnt);
                      _StaOffPnt.z -= dLeftSubgradeAdjustElev;
                      _AddPointList.Add(_StaOffPnt);
                    }
                  }
                  if (epsLeg.Next == null)
                  {
                    topoSurfacePoints.Add(_ParkingLotBreaklineList[index].LegEndPnt);
                    _StaOffPnt = new Eps_Point(_ParkingLotBreaklineList[index].LegEndPnt);
                    _StaOffPnt.z -= dLeftSubgradeAdjustElev;
                    _AddPointList.Add(_StaOffPnt);
                  }
                  num32 += _dDistance;
                }
              }
            }
            _ParkingLotTopoPointList = topoSurfacePoints;
            TopographySurface additionalTopoSurface = TopographySurfaceManagement.CreateAdditionalTopoSurface(_Document, _PlacementSettings, topoSurfacePoints, _ProposedSurface);
            if (additionalTopoSurface != null)
            {
              _PlacementSettings.ParkingLotSurfaceID = ((Element) additionalTopoSurface).UniqueId;
              _ParkingLotSurface = new TopographySurfaceContainer(_Document.Application, additionalTopoSurface, true);
            }
          }
        }
        if (_PlacementSettings.LocateType == LandcaddID.Curb)
          _PlacementSettings.ParentTopoSurfaceID = ((Element) _ProposedSurface.TopographySurface).UniqueId;
        _PlacementSettings.BeginningElevationList.Clear();
        _PlacementSettings.EndingElevationList.Clear();
        bool flag2 = false;
        bool flag3 = false;
        Eps_Point epsPoint1 = (Eps_Point) null;
        Eps_Point epsPoint2 = (Eps_Point) null;
        for (Eps_Leg epsLeg = _CurrentLeg; epsLeg != null; epsLeg = epsLeg.Next)
        {
          if (epsLeg.Line != null)
          {
            epsPoint1 = epsLeg.Line.StartPnt;
            epsPoint2 = epsLeg.Line.EndPnt;
          }
          else if (epsLeg.Arc != null)
          {
            epsPoint1 = epsLeg.Arc.StartPnt;
            epsPoint2 = epsLeg.Arc.EndPnt;
          }
          for (int index = 0; index < _ApplySurfaceElevationPoints.Count; ++index)
          {
            if (epsPoint1.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag2 = true;
              if (flag3)
                break;
            }
            else if (epsPoint2.IsEqual(_ApplySurfaceElevationPoints[index]))
            {
              flag3 = true;
              if (flag2)
                break;
            }
          }
          if (epsPoint1 != null && !flag2)
            _PlacementSettings.BeginningElevationList.Add(epsPoint1.z);
          if (epsPoint2 != null && !flag3)
            _PlacementSettings.EndingElevationList.Add(epsPoint2.z);
          flag2 = false;
          flag3 = false;
        }
        Guid _ChainID = Guid.NewGuid();
        _FamilyInstanceList = RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, _ElementList, _ChainID);
        _PlacementSettings.BeginningElevationList.Clear();
        _PlacementSettings.EndingElevationList.Clear();
        if (_PlacementSettings.LocateType == LandcaddID.ParkingLot && _FamilyInstanceList != null && _FamilyInstanceList.Count > 0)
          RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, _ParkingLotBreaklineElementList, _dParkingLotBreaklineLinearPointIntervals, _ChainID, true);
      }
      IEnumerable<Eps_Point> source = (IEnumerable<Eps_Point>) _AddPointList;
      _TopoPointList = source.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
      if (_ProgressFrm != null)
      {
        _ProgressFrm.SetMaxValue();
        Thread.Sleep(300);
        _ProgressFrm.Close();
      }
    }
    return true;
  }

  public static void FindAllGradeAndElevationPointsInIntersection(
    Document _Document,
    TopographySurfaceContainer _ProposedSurface,
    EPTransactionContainer _TransactionContainer,
    bool _bFindIntersectionStations,
    FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper,
    List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers,
    ref List<Eps_Point> _GradeAndElevationPnts)
  {
    List<IntersectionContainer> intersectionContainerList = new List<IntersectionContainer>();
    List<IntersectionStationContainer> _LeftIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _RightIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _CenterIntersectionStations = new List<IntersectionStationContainer>();
    LandcaddID _LocateType1 = LandcaddID.Sidewalk;
    LandcaddID _LocateType2 = LandcaddID.Sidewalk;
    Eps_Leg ppOffsetLegList1 = (Eps_Leg) null;
    Eps_Leg ppOffsetLegList2 = (Eps_Leg) null;
    Eps_Leg Leg = (Eps_Leg) null;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    double num4 = 0.0;
    double num5 = 0.0;
    double _dReturnValue1 = 0.0;
    double _dReturnValue2 = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    List<double> doubleList1 = new List<double>();
    List<double> doubleList2 = new List<double>();
    bool flag = false;
    bool _bFindIntersectionStations1 = true;
    FamilyInstance existingFamilyInstance1 = _CurrentFamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance1 != null)
    {
      Parameter parameter = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
      if (parameter != null)
      {
        foreach (int num6 in Enum.GetValues(typeof (LandcaddID)))
        {
          if (string.Compare(parameter.AsString(), num6.ToString("000"), true) == 0)
          {
            _LocateType1 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num6);
            break;
          }
        }
      }
      if (_CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol == null)
      {
        FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance1, _LocateType1);
        if (familyTypeSymbol != null)
          _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol = familyTypeSymbol;
      }
    }
    if (_LocateType1 != LandcaddID.Street && _LocateType1 != LandcaddID.Sidewalk)
      return;
    switch (_LocateType1)
    {
      case LandcaddID.Street:
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
          _dReturnValue1 = 5.0;
        Parameter parameter1 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
        if (parameter1 != null)
          num5 = parameter1.AsDouble();
        Parameter parameter2 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
        if (parameter2 != null)
          num1 = num5 * (double) parameter2.AsInteger();
        Parameter parameter3 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
        if (parameter3 != null)
        {
          num3 = -num2 / 2.0 * parameter3.AsDouble();
          break;
        }
        break;
      case LandcaddID.Sidewalk:
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
          _dReturnValue1 = 5.0;
        Parameter parameter4 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
        if (parameter4 != null)
        {
          num1 = parameter4.AsDouble();
          break;
        }
        break;
    }
    if (_CommonFamilyInstanceComponentWrappers == null)
      return;
    for (int index1 = 0; index1 < _CommonFamilyInstanceComponentWrappers.Count; ++index1)
    {
      if (!(_CurrentFamilyInstanceComponentWrapper.ChainID == _CommonFamilyInstanceComponentWrappers[index1].ChainID))
      {
        if (index1 == 0)
        {
          if (_CurrentFamilyInstanceComponentWrapper.InstanceLeg == null)
            _CurrentFamilyInstanceComponentWrapper.CreateProposedLeg(_ProposedSurface);
          ppOffsetLegList1 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, num1 / 2.0, 1, ref ppOffsetLegList1, true);
          ppOffsetLegList2 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, num1 / 2.0, 2, ref ppOffsetLegList2, true);
        }
        FamilyInstance existingFamilyInstance2 = _CommonFamilyInstanceComponentWrappers[index1].GetFirstExistingFamilyInstance();
        if (existingFamilyInstance2 != null)
        {
          Parameter parameter5 = ((Element) existingFamilyInstance2).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
          if (parameter5 != null)
          {
            foreach (int num7 in Enum.GetValues(typeof (LandcaddID)))
            {
              if (string.Compare(parameter5.AsString(), num7.ToString("000"), true) == 0)
              {
                _LocateType2 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num7);
                break;
              }
            }
          }
          if (_LocateType1 == _LocateType2)
          {
            if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg == null)
              _CommonFamilyInstanceComponentWrappers[index1].CreateProposedLeg(_ProposedSurface);
            if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg != null)
            {
              if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegStartPnt, num1 / 2.0))
                EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegStartPnt, num1 / 2.0);
              if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegEndPnt, num1 / 2.0))
                EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegEndPnt, num1 / 2.0);
              int pNumberOfIntersections = 0;
              if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, _CurrentFamilyInstanceComponentWrapper.InstanceLeg, ref ppPointList, ref pNumberOfIntersections, num1 / 2.0) == 0 && pNumberOfIntersections > 0)
              {
                FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance2, _LocateType2);
                if (familyTypeSymbol != null)
                {
                  _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol = familyTypeSymbol;
                  switch (_LocateType2)
                  {
                    case LandcaddID.Street:
                      double num8 = 0.0;
                      Parameter parameter6 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
                      if (parameter6 != null)
                        num8 = parameter6.AsDouble();
                      Parameter parameter7 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
                      if (parameter7 != null)
                        num2 = num8 * (double) parameter7.AsInteger();
                      Parameter parameter8 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
                      if (parameter8 != null)
                      {
                        num4 = -num2 / 2.0 * parameter8.AsDouble();
                        break;
                      }
                      break;
                    case LandcaddID.Sidewalk:
                      Parameter parameter9 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
                      if (parameter9 != null)
                      {
                        num2 = parameter9.AsDouble();
                        break;
                      }
                      break;
                  }
                  if (num2 > 0.0)
                  {
                    Eps_Leg ppOffsetLegList3 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num2 / 2.0, 1, ref ppOffsetLegList3, true);
                    Eps_Leg ppOffsetLegList4 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num2 / 2.0, 2, ref ppOffsetLegList4, true);
                    for (int index2 = _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.Count - 1; index2 >= 0; --index2)
                    {
                      if (string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].SecondaryPlacementId, true) == 0)
                      {
                        flag = false;
                        _bFindIntersectionStations1 = _bFindIntersectionStations;
                        _LeftIntersectionStations.Add(_CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2]);
                      }
                      else if (string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].SecondaryPlacementId, true) == 0)
                      {
                        flag = true;
                        break;
                      }
                    }
                    if (!flag)
                    {
                      for (int index3 = _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.Count - 1; index3 >= 0; --index3)
                      {
                        if (string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].SecondaryPlacementId, true) == 0)
                        {
                          flag = false;
                          _bFindIntersectionStations1 = _bFindIntersectionStations;
                          _RightIntersectionStations.Add(_CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3]);
                        }
                        else if (string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].SecondaryPlacementId, true) == 0)
                        {
                          flag = true;
                          break;
                        }
                      }
                      if (!flag)
                      {
                        Eps_Leg instanceLeg1 = _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg;
                        Eps_Leg _LeftExistingOffsetLeg = ppOffsetLegList4;
                        Eps_Leg _RightExistingOffsetLeg = ppOffsetLegList3;
                        Eps_Leg instanceLeg2 = _CurrentFamilyInstanceComponentWrapper.InstanceLeg;
                        Eps_Leg _LeftOffsetLeg = ppOffsetLegList2;
                        Eps_Leg _RightOffsetLeg = ppOffsetLegList1;
                        double _dExistingOffset = num2;
                        double _dExistingAdjustSubgradeElev = num4;
                        if (!TopographySurfaceManagement.FindIntersectionStationAndProfiles(instanceLeg2, _LeftOffsetLeg, _RightOffsetLeg, instanceLeg1, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _dExistingOffset, _dExistingAdjustSubgradeElev, _dReturnValue1, _dReturnValue2, _bFindIntersectionStations1, false, 0.0, _Document, _TransactionContainer, _LocateType2, ref _LeftIntersectionStations, ref _CenterIntersectionStations, ref _RightIntersectionStations))
                          break;
                        _bFindIntersectionStations1 = true;
                        IntersectionStationContainerComparer containerComparer = new IntersectionStationContainerComparer(true);
                        if (_CenterIntersectionStations != null && _CenterIntersectionStations.Count > 0)
                          _CenterIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer);
                        for (int index4 = 0; index4 < _CenterIntersectionStations.Count; ++index4)
                        {
                          for (int index5 = 0; index5 < _CenterIntersectionStations[index4].IntersectionStations.Count; ++index5)
                          {
                            if (_CenterIntersectionStations[index4].IntersectionStations[index5].StartingIntersection)
                            {
                              doubleList1.Add(_CenterIntersectionStations[index4].IntersectionStations[index5].Station);
                              if (index5 == _CenterIntersectionStations[index4].IntersectionStations.Count - 1)
                                doubleList2.Add(RevitGeometry.eplGeoE_CalcLegListLength(_CurrentFamilyInstanceComponentWrapper.InstanceLeg));
                            }
                            else
                            {
                              if (index5 == 0)
                                doubleList1.Add(0.0);
                              doubleList2.Add(_CenterIntersectionStations[index4].IntersectionStations[index5].Station);
                            }
                          }
                        }
                        for (int index6 = 0; index6 < doubleList1.Count; ++index6)
                        {
                          Eps_Point Pnt1 = new Eps_Point();
                          if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, doubleList1[index6], 0.0, ref Pnt1, ref Leg) == 0)
                          {
                            Eps_Point _FirstCheckPnt = new Eps_Point();
                            double num9 = RevitGeometry.eplGeoE_CalcLegLength(Leg);
                            if (Leg.Line != null)
                              EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(Leg.Line.StartPnt, Leg.Line.EndPnt, ref _FirstCheckPnt);
                            else if (Leg.Arc != null)
                              EPShared.eplGeoE_FindStaOffPointAlongArc(Leg.Arc, num9 / 2.0, 0.0, ref _FirstCheckPnt);
                            int index7 = 0;
                            while (index7 < _GradeAndElevationPnts.Count && !EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt, _GradeAndElevationPnts[index7]))
                              ++index7;
                            if (index7 == _GradeAndElevationPnts.Count)
                              _GradeAndElevationPnts.Add(_FirstCheckPnt);
                          }
                          Eps_Point Pnt2 = new Eps_Point();
                          if (RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, doubleList2[index6], 0.0, ref Pnt2, ref Leg) == 0)
                          {
                            Eps_Point _FirstCheckPnt = new Eps_Point();
                            double num10 = RevitGeometry.eplGeoE_CalcLegLength(Leg);
                            if (Leg.Line != null)
                              EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(Leg.Line.StartPnt, Leg.Line.EndPnt, ref _FirstCheckPnt);
                            else if (Leg.Arc != null)
                              EPShared.eplGeoE_FindStaOffPointAlongArc(Leg.Arc, num10 / 2.0, 0.0, ref _FirstCheckPnt);
                            int index8 = 0;
                            while (index8 < _GradeAndElevationPnts.Count && !EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt, _GradeAndElevationPnts[index8]))
                              ++index8;
                            if (index8 == _GradeAndElevationPnts.Count)
                              _GradeAndElevationPnts.Add(_FirstCheckPnt);
                            for (Eps_Leg epsLeg = _CurrentFamilyInstanceComponentWrapper.InstanceLeg; epsLeg != null; epsLeg = epsLeg.Next)
                            {
                              if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg, ref _dStation, ref _dOffset) == 1700 && _dStation >= doubleList1[index6] && _dStation <= doubleList2[index6])
                              {
                                int index9 = 0;
                                while (index9 < _GradeAndElevationPnts.Count && !EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg.LegStartPnt, _GradeAndElevationPnts[index9]))
                                  ++index9;
                                if (index9 == _GradeAndElevationPnts.Count)
                                  _GradeAndElevationPnts.Add(epsLeg.LegStartPnt);
                              }
                              if (epsLeg.Next == null && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(epsLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg, ref _dStation, ref _dOffset) == 1700 && _dStation >= doubleList1[index6] && _dStation <= doubleList2[index6])
                              {
                                int index10 = 0;
                                while (index10 < _GradeAndElevationPnts.Count && !EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg.LegEndPnt, _GradeAndElevationPnts[index10]))
                                  ++index10;
                                if (index10 == _GradeAndElevationPnts.Count)
                                  _GradeAndElevationPnts.Add(epsLeg.LegEndPnt);
                              }
                            }
                          }
                        }
                        _LeftIntersectionStations.Clear();
                        _CenterIntersectionStations.Clear();
                        _RightIntersectionStations.Clear();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  public static void RemoveAllIntersectionStationsForCommonSiteComponents(
    ref List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers)
  {
    for (int index = 0; index < _CommonFamilyInstanceComponentWrappers.Count; ++index)
    {
      _CommonFamilyInstanceComponentWrappers[index].LeftIntersectionStations.Clear();
      _CommonFamilyInstanceComponentWrappers[index].RightIntersectionStations.Clear();
      _CommonFamilyInstanceComponentWrappers[index].CenterIntersectionStations.Clear();
      _CommonFamilyInstanceComponentWrappers[index].IntersectionContainerList.Clear();
    }
  }

  public static void SetupAllIntersectionStationsForSelectedSiteComponent(
    Document _Document,
    TopographySurfaceContainer _ProposedSurface,
    EPTransactionContainer _TransactionContainer,
    bool _bFindIntersectionStations,
    ref FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper,
    ref List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers)
  {
    List<IntersectionContainer> collection = new List<IntersectionContainer>();
    List<IntersectionStationContainer> _LeftIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _RightIntersectionStations = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _CenterIntersectionStations = new List<IntersectionStationContainer>();
    LandcaddID _LocateType1 = LandcaddID.Sidewalk;
    LandcaddID _LocateType2 = LandcaddID.Sidewalk;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    double num4 = 0.0;
    double num5 = 0.0;
    double _dReturnValue1 = 0.0;
    double _dReturnValue2 = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    bool flag1 = false;
    bool _bFindIntersectionStations1 = true;
    FamilyInstance existingFamilyInstance1 = _CurrentFamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance1 != null)
    {
      Parameter parameter = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
      if (parameter != null)
      {
        foreach (int num6 in Enum.GetValues(typeof (LandcaddID)))
        {
          if (string.Compare(parameter.AsString(), num6.ToString("000"), true) == 0)
          {
            _LocateType1 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num6);
            break;
          }
        }
      }
      if (_CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol == null)
      {
        FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance1, _LocateType1);
        if (familyTypeSymbol != null)
          _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol = familyTypeSymbol;
      }
    }
    if (_LocateType1 != LandcaddID.Street && _LocateType1 != LandcaddID.Sidewalk)
      return;
    switch (_LocateType1)
    {
      case LandcaddID.Street:
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
          _dReturnValue1 = 5.0;
        Parameter parameter1 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
        if (parameter1 != null)
          num5 = parameter1.AsDouble();
        Parameter parameter2 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
        if (parameter2 != null)
          num1 = num5 * (double) parameter2.AsInteger();
        Parameter parameter3 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
        if (parameter3 != null)
        {
          num3 = -num1 / 2.0 * parameter3.AsDouble();
          break;
        }
        break;
      case LandcaddID.Sidewalk:
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
          _dReturnValue1 = 5.0;
        Parameter parameter4 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
        if (parameter4 != null)
        {
          num1 = parameter4.AsDouble();
          break;
        }
        break;
    }
    if (_CommonFamilyInstanceComponentWrappers != null)
    {
      if (_CurrentFamilyInstanceComponentWrapper.InstanceLeg == null)
      {
        _CurrentFamilyInstanceComponentWrapper.CreateProposedLeg(_ProposedSurface);
        if (_CurrentFamilyInstanceComponentWrapper.InstanceLeg == null)
          return;
      }
      Eps_Leg ppOffsetLegList1 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, num1 / 2.0, 1, ref ppOffsetLegList1, true);
      Eps_Leg ppOffsetLegList2 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, num1 / 2.0, 2, ref ppOffsetLegList2, true);
      for (int index1 = 0; index1 < _CommonFamilyInstanceComponentWrappers.Count; ++index1)
      {
        if (!(_CurrentFamilyInstanceComponentWrapper.ChainID == _CommonFamilyInstanceComponentWrappers[index1].ChainID))
        {
          FamilyInstance existingFamilyInstance2 = _CommonFamilyInstanceComponentWrappers[index1].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance2 != null)
          {
            Parameter parameter5 = ((Element) existingFamilyInstance2).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (parameter5 != null)
            {
              foreach (int num7 in Enum.GetValues(typeof (LandcaddID)))
              {
                if (string.Compare(parameter5.AsString(), num7.ToString("000"), true) == 0)
                {
                  _LocateType2 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num7);
                  break;
                }
              }
            }
            if (_LocateType1 == _LocateType2)
            {
              if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg == null)
              {
                _CommonFamilyInstanceComponentWrappers[index1].CreateProposedLeg(_ProposedSurface);
                if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg == null)
                  continue;
              }
              if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg != null)
              {
                if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegStartPnt, num1 / 2.0))
                  EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegStartPnt, num1 / 2.0);
                if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegEndPnt, num1 / 2.0))
                  EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegEndPnt, num1 / 2.0);
                int pNumberOfIntersections = 0;
                if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, _CurrentFamilyInstanceComponentWrapper.InstanceLeg, ref ppPointList, ref pNumberOfIntersections, num1 / 2.0) == 0 && pNumberOfIntersections > 0)
                {
                  FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance2, _LocateType2);
                  if (familyTypeSymbol != null)
                  {
                    _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol = familyTypeSymbol;
                    switch (_LocateType2)
                    {
                      case LandcaddID.Street:
                        double num8 = 0.0;
                        Parameter parameter6 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
                        if (parameter6 != null)
                          num8 = parameter6.AsDouble();
                        Parameter parameter7 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
                        if (parameter7 != null)
                          num2 = num8 * (double) parameter7.AsInteger();
                        Parameter parameter8 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
                        if (parameter8 != null)
                        {
                          num4 = -num2 / 2.0 * parameter8.AsDouble();
                          break;
                        }
                        break;
                      case LandcaddID.Sidewalk:
                        Parameter parameter9 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
                        if (parameter9 != null)
                        {
                          num2 = parameter9.AsDouble();
                          break;
                        }
                        break;
                    }
                    if (num2 > 0.0)
                    {
                      Eps_Leg ppOffsetLegList3 = new Eps_Leg();
                      RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num2 / 2.0, 1, ref ppOffsetLegList3, true);
                      Eps_Leg ppOffsetLegList4 = new Eps_Leg();
                      RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num2 / 2.0, 2, ref ppOffsetLegList4, true);
                      for (int index2 = _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.Count - 1; index2 >= 0; --index2)
                      {
                        if (string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].SecondaryPlacementId, true) == 0)
                        {
                          flag1 = false;
                          _bFindIntersectionStations1 = _bFindIntersectionStations;
                          _LeftIntersectionStations.Add(_CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2]);
                          if (_bFindIntersectionStations1)
                            _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.RemoveAt(index2);
                        }
                        else if (string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2].SecondaryPlacementId, true) == 0)
                        {
                          flag1 = true;
                          _bFindIntersectionStations1 = _bFindIntersectionStations;
                          _LeftIntersectionStations.Add(_CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations[index2]);
                          _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.RemoveAt(index2);
                        }
                      }
                      for (int index3 = _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.Count - 1; index3 >= 0; --index3)
                      {
                        if (string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].SecondaryPlacementId, true) == 0)
                        {
                          flag1 = false;
                          _bFindIntersectionStations1 = _bFindIntersectionStations;
                          _RightIntersectionStations.Add(_CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3]);
                          if (_bFindIntersectionStations1)
                            _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.RemoveAt(index3);
                        }
                        else if (string.Compare(((Element) existingFamilyInstance1).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance2).UniqueId, _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3].SecondaryPlacementId, true) == 0)
                        {
                          flag1 = true;
                          _bFindIntersectionStations1 = _bFindIntersectionStations;
                          _RightIntersectionStations.Add(_CurrentFamilyInstanceComponentWrapper.RightIntersectionStations[index3]);
                          _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.RemoveAt(index3);
                        }
                      }
                      bool flag2 = false;
                      if (_LocateType2 == LandcaddID.Street)
                      {
                        Parameter parameter10 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
                        if (parameter10 != null)
                          flag2 = Convert.ToBoolean(parameter10.AsInteger());
                      }
                      if (_CurrentFamilyInstanceComponentWrapper.ProposedElementSet == null)
                      {
                        _CommonFamilyInstanceComponentWrappers[index1].LeftIntersectionStations.Clear();
                        _CommonFamilyInstanceComponentWrappers[index1].CenterIntersectionStations.Clear();
                        _CommonFamilyInstanceComponentWrappers[index1].RightIntersectionStations.Clear();
                        _CommonFamilyInstanceComponentWrappers[index1].IntersectionContainerList.Clear();
                        if (flag1 || flag2)
                          _CommonFamilyInstanceComponentWrappers[index1].RedrawForm = true;
                      }
                      else
                      {
                        Eps_Leg instanceLeg1;
                        Eps_Leg epsLeg1;
                        Eps_Leg epsLeg2;
                        Eps_Leg instanceLeg2;
                        Eps_Leg _LeftOffsetLeg;
                        Eps_Leg _RightOffsetLeg;
                        double _dExistingOffset;
                        double _dExistingAdjustSubgradeElev;
                        if (flag1)
                        {
                          instanceLeg1 = _CurrentFamilyInstanceComponentWrapper.InstanceLeg;
                          epsLeg1 = ppOffsetLegList2;
                          epsLeg2 = ppOffsetLegList1;
                          instanceLeg2 = _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg;
                          _LeftOffsetLeg = ppOffsetLegList4;
                          _RightOffsetLeg = ppOffsetLegList3;
                          _dExistingOffset = num1;
                          _dExistingAdjustSubgradeElev = num3;
                        }
                        else
                        {
                          FamilyInstanceComponentWrapper _CurFamilyInstanceComponentWrapper = _CommonFamilyInstanceComponentWrappers[index1];
                          TopographySurfaceManagement.SetupIntersectionContainersForSiteComponent(_Document, _TransactionContainer, _ProposedSurface, _CurrentFamilyInstanceComponentWrapper.ChainID, _CommonFamilyInstanceComponentWrappers, ref _CurFamilyInstanceComponentWrapper);
                          _CommonFamilyInstanceComponentWrappers[index1] = _CurFamilyInstanceComponentWrapper;
                          instanceLeg1 = _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg;
                          epsLeg1 = ppOffsetLegList4;
                          epsLeg2 = ppOffsetLegList3;
                          instanceLeg2 = _CurrentFamilyInstanceComponentWrapper.InstanceLeg;
                          _LeftOffsetLeg = ppOffsetLegList2;
                          _RightOffsetLeg = ppOffsetLegList1;
                          _dExistingOffset = num2;
                          _dExistingAdjustSubgradeElev = num4;
                        }
                        if (!TopographySurfaceManagement.FindIntersectionStationAndProfiles(instanceLeg2, _LeftOffsetLeg, _RightOffsetLeg, instanceLeg1, epsLeg1, epsLeg2, _dExistingOffset, _dExistingAdjustSubgradeElev, _dReturnValue1, _dReturnValue2, _bFindIntersectionStations1, true, 0.0, _Document, _TransactionContainer, _LocateType2, ref _LeftIntersectionStations, ref _CenterIntersectionStations, ref _RightIntersectionStations))
                          return;
                        IntersectionStationContainerComparer containerComparer1 = new IntersectionStationContainerComparer(true);
                        if (_LeftIntersectionStations != null && _LeftIntersectionStations.Count > 0)
                          _LeftIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
                        if (_CenterIntersectionStations != null && _CenterIntersectionStations.Count > 0)
                          _CenterIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
                        if (_RightIntersectionStations != null && _RightIntersectionStations.Count > 0)
                          _RightIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
                        if (flag1)
                        {
                          _CommonFamilyInstanceComponentWrappers[index1].LeftIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
                          _CommonFamilyInstanceComponentWrappers[index1].CenterIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _CenterIntersectionStations);
                          _CommonFamilyInstanceComponentWrappers[index1].RightIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
                          _CommonFamilyInstanceComponentWrappers[index1].RedrawForm = true;
                        }
                        else
                        {
                          _CurrentFamilyInstanceComponentWrapper.CenterIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _CenterIntersectionStations);
                          if (_bFindIntersectionStations1)
                          {
                            _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations);
                            _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations);
                          }
                        }
                        _bFindIntersectionStations1 = true;
                        if (_LeftIntersectionStations.Count > 0 && _LeftIntersectionStations.Count == _RightIntersectionStations.Count)
                        {
                          for (int index4 = 0; index4 < _LeftIntersectionStations.Count; ++index4)
                          {
                            _LeftIntersectionStations[index4].PrimaryPlacementId = ((Element) existingFamilyInstance2).UniqueId;
                            _RightIntersectionStations[index4].PrimaryPlacementId = ((Element) existingFamilyInstance2).UniqueId;
                            if (_LeftIntersectionStations[index4].IntersectionStations.Count == _RightIntersectionStations[index4].IntersectionStations.Count)
                            {
                              for (int index5 = 0; index5 < _LeftIntersectionStations[index4].IntersectionStations.Count; ++index5)
                              {
                                IntersectionContainer intersectionContainer1 = new IntersectionContainer();
                                intersectionContainer1.StartingIntersection = true;
                                ProfileContainer profileContainer1 = new ProfileContainer();
                                bool isPrimaryLeft1;
                                if (_LeftIntersectionStations[index4].IntersectionStations[index5].PrimaryStation <= _RightIntersectionStations[index4].IntersectionStations[index5].PrimaryStation)
                                {
                                  isPrimaryLeft1 = _LeftIntersectionStations[index4].IntersectionStations[index5].IsPrimaryLeft;
                                  Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_LeftIntersectionStations, index4, index5, false);
                                  profileContainer1.Station = intersectionStationPoint != null && isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _LeftIntersectionStations[index4].IntersectionStations[index5].PrimaryStation;
                                }
                                else
                                {
                                  isPrimaryLeft1 = _RightIntersectionStations[index4].IntersectionStations[index5].IsPrimaryLeft;
                                  Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_RightIntersectionStations, index4, index5, false);
                                  profileContainer1.Station = intersectionStationPoint != null && isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _RightIntersectionStations[index4].IntersectionStations[index5].PrimaryStation;
                                }
                                intersectionContainer1.Profiles.Add(profileContainer1);
                                intersectionContainer1.ProfileUsage = !isPrimaryLeft1 ? ProfileUsage.RightOnly : ProfileUsage.LeftOnly;
                                collection.Add(intersectionContainer1);
                                IntersectionContainer intersectionContainer2 = new IntersectionContainer();
                                intersectionContainer2.StartingIntersection = false;
                                ProfileContainer profileContainer2 = new ProfileContainer();
                                bool isPrimaryLeft2;
                                if (_LeftIntersectionStations[index4].IntersectionStations[index5].PrimaryStation <= _RightIntersectionStations[index4].IntersectionStations[index5].PrimaryStation)
                                {
                                  isPrimaryLeft2 = _RightIntersectionStations[index4].IntersectionStations[index5].IsPrimaryLeft;
                                  Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_RightIntersectionStations, index4, index5, false);
                                  profileContainer2.Station = intersectionStationPoint != null && isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _RightIntersectionStations[index4].IntersectionStations[index5].PrimaryStation;
                                }
                                else
                                {
                                  isPrimaryLeft2 = _LeftIntersectionStations[index4].IntersectionStations[index5].IsPrimaryLeft;
                                  Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_LeftIntersectionStations, index4, index5, false);
                                  profileContainer2.Station = intersectionStationPoint != null && isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _LeftIntersectionStations[index4].IntersectionStations[index5].PrimaryStation;
                                }
                                intersectionContainer2.Profiles.Add(profileContainer2);
                                intersectionContainer2.ProfileUsage = !isPrimaryLeft2 ? ProfileUsage.RightOnly : ProfileUsage.LeftOnly;
                                collection.Add(intersectionContainer2);
                              }
                            }
                          }
                          IntersectionContainerComparer containerComparer2 = new IntersectionContainerComparer(true);
                          if (collection != null && collection.Count > 0)
                            collection.Sort((IComparer<IntersectionContainer>) containerComparer2);
                          if (flag1)
                          {
                            _CurrentFamilyInstanceComponentWrapper.IntersectionContainerList.AddRange((IEnumerable<IntersectionContainer>) collection);
                          }
                          else
                          {
                            _CommonFamilyInstanceComponentWrappers[index1].IntersectionContainerList.AddRange((IEnumerable<IntersectionContainer>) collection);
                            _CommonFamilyInstanceComponentWrappers[index1].IntersectionContainerList.Sort((IComparer<IntersectionContainer>) containerComparer2);
                            _CommonFamilyInstanceComponentWrappers[index1].RedrawForm = true;
                          }
                          collection.Clear();
                        }
                        _LeftIntersectionStations.Clear();
                        _CenterIntersectionStations.Clear();
                        _RightIntersectionStations.Clear();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if (_CurrentFamilyInstanceComponentWrapper.ProposedElementSet != null)
      return;
    _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.Clear();
    _CurrentFamilyInstanceComponentWrapper.CenterIntersectionStations.Clear();
    _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.Clear();
    _CurrentFamilyInstanceComponentWrapper.IntersectionContainerList.Clear();
    _CurrentFamilyInstanceComponentWrapper.ProposedLeg = (Eps_Leg) null;
  }

  public static void SetupAllIntersectionStationsForAllSiteComponents(
    Document _Document,
    TopographySurfaceContainer _ProposedSurface,
    EPTransactionContainer _TransactionContainer,
    string _IgnoreChainID,
    ref List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers)
  {
    List<IntersectionStationContainer> stationContainerList1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> stationContainerList2 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _LeftIntersectionStations1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _RightIntersectionStations1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _CenterIntersectionStations = new List<IntersectionStationContainer>();
    LandcaddID _LocateType1 = LandcaddID.Sidewalk;
    LandcaddID _LocateType2 = LandcaddID.Sidewalk;
    Eps_Leg ppOffsetLegList1 = (Eps_Leg) null;
    Eps_Leg ppOffsetLegList2 = (Eps_Leg) null;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    double num4 = 0.0;
    double num5 = 0.0;
    double _dReturnValue1 = 0.0;
    double _dReturnValue2 = 0.0;
    if (_CommonFamilyInstanceComponentWrappers == null)
      return;
    for (int index1 = 0; index1 < _CommonFamilyInstanceComponentWrappers.Count; ++index1)
    {
      if (string.Compare(_CommonFamilyInstanceComponentWrappers[index1].ChainID, _IgnoreChainID, true) != 0)
      {
        FamilyInstance existingFamilyInstance1 = _CommonFamilyInstanceComponentWrappers[index1].GetFirstExistingFamilyInstance();
        if (existingFamilyInstance1 != null)
        {
          Parameter parameter = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
          if (parameter != null)
          {
            foreach (int num6 in Enum.GetValues(typeof (LandcaddID)))
            {
              if (string.Compare(parameter.AsString(), num6.ToString("000"), true) == 0)
              {
                _LocateType1 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num6);
                break;
              }
            }
          }
          if (_LocateType1 == LandcaddID.Street || _LocateType1 == LandcaddID.Sidewalk)
          {
            if (_CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol == null)
            {
              FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance1, _LocateType1);
              if (familyTypeSymbol != null)
                _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol = familyTypeSymbol;
            }
          }
          else
            continue;
        }
        switch (_LocateType1)
        {
          case LandcaddID.Street:
            if (!ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
              _dReturnValue1 = 5.0;
            Parameter parameter1 = ((Element) _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
            if (parameter1 != null)
              num5 = parameter1.AsDouble();
            Parameter parameter2 = ((Element) _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
            if (parameter2 != null)
              num1 = num5 * (double) parameter2.AsInteger();
            Parameter parameter3 = ((Element) _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
            if (parameter3 != null)
            {
              num3 = -num2 / 2.0 * parameter3.AsDouble();
              break;
            }
            break;
          case LandcaddID.Sidewalk:
            if (!ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
              _dReturnValue1 = 5.0;
            Parameter parameter4 = ((Element) _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
            if (parameter4 != null)
            {
              num1 = parameter4.AsDouble();
              break;
            }
            break;
        }
        if (num1 > 0.0)
        {
          if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg == null)
          {
            _CommonFamilyInstanceComponentWrappers[index1].CreateProposedLeg(_ProposedSurface);
            if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg == null)
              continue;
          }
          ppOffsetLegList1 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num1 / 2.0, 1, ref ppOffsetLegList1, true);
          ppOffsetLegList2 = new Eps_Leg();
          RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num1 / 2.0, 2, ref ppOffsetLegList2, true);
        }
        ElementSet instanceElementSet = _CommonFamilyInstanceComponentWrappers[index1].GetFamilyInstanceElementSet();
        if (instanceElementSet != null && instanceElementSet.Size > 0)
        {
          List<IntersectionStationContainer> _LeftIntersectionStations2 = (List<IntersectionStationContainer>) null;
          List<IntersectionStationContainer> _RightIntersectionStations2 = (List<IntersectionStationContainer>) null;
          List<FamilyInstance> _SiteFamilyInstanceList = (List<FamilyInstance>) null;
          foreach (Element element in instanceElementSet)
          {
            TopographySurfaceManagement.GetIntersections(_Document, element.UniqueId, true, ref _SiteFamilyInstanceList, ref _LeftIntersectionStations2, ref _RightIntersectionStations2);
            if (_SiteFamilyInstanceList != null && _SiteFamilyInstanceList.Count > 0)
            {
              _CommonFamilyInstanceComponentWrappers[index1].AddIntersectionFamilyInstances(_SiteFamilyInstanceList);
              _CommonFamilyInstanceComponentWrappers[index1].IntersectionFamilySymbol = _SiteFamilyInstanceList[0].Symbol;
            }
            if (_LeftIntersectionStations2 != null && _LeftIntersectionStations2.Count > 0)
              stationContainerList1.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations2);
            if (_RightIntersectionStations2 != null && _RightIntersectionStations2.Count > 0)
              stationContainerList2.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations2);
          }
        }
        if (stationContainerList1.Count != 0 && stationContainerList2.Count != 0)
        {
          for (int index2 = 0; index2 < _CommonFamilyInstanceComponentWrappers.Count; ++index2)
          {
            if (index1 != index2 && string.Compare(_CommonFamilyInstanceComponentWrappers[index2].ChainID, _IgnoreChainID, true) != 0)
            {
              FamilyInstance existingFamilyInstance2 = _CommonFamilyInstanceComponentWrappers[index2].GetFirstExistingFamilyInstance();
              if (existingFamilyInstance2 != null)
              {
                Parameter parameter5 = ((Element) existingFamilyInstance2).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
                if (parameter5 != null)
                {
                  foreach (int num7 in Enum.GetValues(typeof (LandcaddID)))
                  {
                    if (string.Compare(parameter5.AsString(), num7.ToString("000"), true) == 0)
                    {
                      _LocateType2 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num7);
                      break;
                    }
                  }
                }
                if (_LocateType1 == _LocateType2)
                {
                  if (_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg == null)
                  {
                    _CommonFamilyInstanceComponentWrappers[index2].CreateProposedLeg(_ProposedSurface);
                    if (_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg == null)
                      continue;
                  }
                  if (_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg != null)
                  {
                    if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg.LegStartPnt, _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, num1 / 2.0))
                      EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg.LegEndPnt, _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, num1 / 2.0);
                    if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg.LegEndPnt, _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, num1 / 2.0))
                      EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg.LegStartPnt, _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, num1 / 2.0);
                    int pNumberOfIntersections = 0;
                    if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg, _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, ref ppPointList, ref pNumberOfIntersections, num1 / 2.0) == 0 && pNumberOfIntersections > 0)
                    {
                      FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance2, _LocateType2);
                      if (familyTypeSymbol != null)
                      {
                        _CommonFamilyInstanceComponentWrappers[index2].ProposedFamilySymbol = familyTypeSymbol;
                        switch (_LocateType2)
                        {
                          case LandcaddID.Street:
                            num5 = 0.0;
                            Parameter parameter6 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
                            if (parameter6 != null)
                              num5 = parameter6.AsDouble();
                            Parameter parameter7 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
                            if (parameter7 != null)
                              num2 = num5 * (double) parameter7.AsInteger();
                            Parameter parameter8 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
                            if (parameter8 != null)
                            {
                              num4 = -num2 / 2.0 * parameter8.AsDouble();
                              break;
                            }
                            break;
                          case LandcaddID.Sidewalk:
                            Parameter parameter9 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
                            if (parameter9 != null)
                            {
                              num2 = parameter9.AsDouble();
                              break;
                            }
                            break;
                        }
                        if (num2 > 0.0)
                        {
                          Eps_Leg ppOffsetLegList3 = new Eps_Leg();
                          RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg, num2 / 2.0, 1, ref ppOffsetLegList3, true);
                          Eps_Leg ppOffsetLegList4 = new Eps_Leg();
                          RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index2].InstanceLeg, num2 / 2.0, 2, ref ppOffsetLegList4, true);
                          for (int index3 = stationContainerList1.Count - 1; index3 >= 0; --index3)
                          {
                            if (string.Compare(((Element) existingFamilyInstance2).UniqueId, stationContainerList1[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, stationContainerList1[index3].SecondaryPlacementId, true) == 0)
                              _LeftIntersectionStations1.Add(stationContainerList1[index3]);
                          }
                          for (int index4 = stationContainerList2.Count - 1; index4 >= 0; --index4)
                          {
                            if (string.Compare(((Element) existingFamilyInstance2).UniqueId, stationContainerList2[index4].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, stationContainerList2[index4].SecondaryPlacementId, true) == 0)
                              _RightIntersectionStations1.Add(stationContainerList2[index4]);
                          }
                          if (_LeftIntersectionStations1.Count > 0 && _RightIntersectionStations1.Count == _LeftIntersectionStations1.Count)
                          {
                            Eps_Leg instanceLeg1 = _CommonFamilyInstanceComponentWrappers[index2].InstanceLeg;
                            Eps_Leg _LeftExistingOffsetLeg = ppOffsetLegList4;
                            Eps_Leg _RightExistingOffsetLeg = ppOffsetLegList3;
                            Eps_Leg instanceLeg2 = _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg;
                            Eps_Leg _LeftOffsetLeg = ppOffsetLegList2;
                            Eps_Leg _RightOffsetLeg = ppOffsetLegList1;
                            double _dExistingOffset = num2;
                            double _dExistingAdjustSubgradeElev = num4;
                            if (!TopographySurfaceManagement.FindIntersectionStationAndProfiles(instanceLeg2, _LeftOffsetLeg, _RightOffsetLeg, instanceLeg1, _LeftExistingOffsetLeg, _RightExistingOffsetLeg, _dExistingOffset, _dExistingAdjustSubgradeElev, _dReturnValue1, _dReturnValue2, false, false, 0.0, _Document, _TransactionContainer, _LocateType2, ref _LeftIntersectionStations1, ref _CenterIntersectionStations, ref _RightIntersectionStations1))
                              return;
                            _CommonFamilyInstanceComponentWrappers[index1].CenterIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _CenterIntersectionStations);
                            _CommonFamilyInstanceComponentWrappers[index1].LeftIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations1);
                            _CommonFamilyInstanceComponentWrappers[index1].RightIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations1);
                            _LeftIntersectionStations1.Clear();
                            _CenterIntersectionStations.Clear();
                            _RightIntersectionStations1.Clear();
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          IntersectionStationContainerComparer containerComparer = new IntersectionStationContainerComparer(true);
          if (_CommonFamilyInstanceComponentWrappers[index1].LeftIntersectionStations != null && _CommonFamilyInstanceComponentWrappers[index1].LeftIntersectionStations.Count > 0)
            _CommonFamilyInstanceComponentWrappers[index1].LeftIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer);
          if (_CommonFamilyInstanceComponentWrappers[index1].CenterIntersectionStations != null && _CommonFamilyInstanceComponentWrappers[index1].CenterIntersectionStations.Count > 0)
            _CommonFamilyInstanceComponentWrappers[index1].CenterIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer);
          if (_CommonFamilyInstanceComponentWrappers[index1].RightIntersectionStations != null && _CommonFamilyInstanceComponentWrappers[index1].RightIntersectionStations.Count > 0)
            _CommonFamilyInstanceComponentWrappers[index1].RightIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer);
          stationContainerList1.Clear();
          stationContainerList2.Clear();
        }
      }
    }
  }

  public static void SetupIntersectionStationsOnlyForSelectedSiteComponent(
    Document _Document,
    TopographySurfaceContainer _ProposedSurface,
    EPTransactionContainer _TransactionContainer,
    bool _bFindIntersectionStations,
    List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers,
    ref FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper)
  {
    TopographySurfaceManagement.SetupIntersectionStationsOnlyForSelectedSiteComponent(_Document, _ProposedSurface, _TransactionContainer, string.Empty, _CommonFamilyInstanceComponentWrappers, ref _CurrentFamilyInstanceComponentWrapper);
  }

  private static void SetupIntersectionStationsOnlyForSelectedSiteComponent(
    Document _Document,
    TopographySurfaceContainer _ProposedSurface,
    EPTransactionContainer _TransactionContainer,
    string _IgnoreChainID,
    List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers,
    ref FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper)
  {
    List<IntersectionContainer> collection = new List<IntersectionContainer>();
    List<IntersectionStationContainer> stationContainerList1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> stationContainerList2 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _LeftIntersectionStations1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _RightIntersectionStations1 = new List<IntersectionStationContainer>();
    List<IntersectionStationContainer> _CenterIntersectionStations = new List<IntersectionStationContainer>();
    LandcaddID _LocateType1 = LandcaddID.Sidewalk;
    LandcaddID _LocateType2 = LandcaddID.Sidewalk;
    Eps_Leg ppOffsetLegList1 = (Eps_Leg) null;
    Eps_Leg ppOffsetLegList2 = (Eps_Leg) null;
    List<Eps_Point> ppPointList = new List<Eps_Point>();
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    double num4 = 0.0;
    double num5 = 0.0;
    double _dReturnValue1 = 0.0;
    double _dReturnValue2 = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    FamilyInstance existingFamilyInstance1 = _CurrentFamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance1 != null)
    {
      Parameter parameter = ((Element) existingFamilyInstance1).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
      if (parameter != null)
      {
        foreach (int num6 in Enum.GetValues(typeof (LandcaddID)))
        {
          if (string.Compare(parameter.AsString(), num6.ToString("000"), true) == 0)
          {
            _LocateType1 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num6);
            break;
          }
        }
      }
      if (_CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol == null)
      {
        FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance1, _LocateType1);
        if (familyTypeSymbol != null)
          _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol = familyTypeSymbol;
      }
    }
    if (_LocateType1 != LandcaddID.Street && _LocateType1 != LandcaddID.Sidewalk)
      return;
    switch (_LocateType1)
    {
      case LandcaddID.Street:
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("StreetIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
          _dReturnValue1 = 5.0;
        Parameter parameter1 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
        if (parameter1 != null)
          num5 = parameter1.AsDouble();
        Parameter parameter2 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
        if (parameter2 != null)
          num1 = num5 * (double) parameter2.AsInteger();
        Parameter parameter3 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
        if (parameter3 != null)
        {
          num3 = -num1 / 2.0 * parameter3.AsDouble();
          break;
        }
        break;
      case LandcaddID.Sidewalk:
        if (!ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultRadius", ref _dReturnValue1) && !ApplicationUtility.Settings.eplSetE_GetSetting("SideWalkIntersectionDefaultTransitioningDistance", ref _dReturnValue2))
          _dReturnValue1 = 5.0;
        Parameter parameter4 = ((Element) _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
        if (parameter4 != null)
        {
          num1 = parameter4.AsDouble();
          break;
        }
        break;
    }
    if (num1 > 0.0)
    {
      if (_CurrentFamilyInstanceComponentWrapper.InstanceLeg == null)
        _CurrentFamilyInstanceComponentWrapper.CreateProposedLeg(_ProposedSurface);
      ppOffsetLegList1 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, num1 / 2.0, 1, ref ppOffsetLegList1, true);
      ppOffsetLegList2 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.InstanceLeg, num1 / 2.0, 2, ref ppOffsetLegList2, true);
    }
    ElementSet instanceElementSet = _CurrentFamilyInstanceComponentWrapper.GetFamilyInstanceElementSet();
    if (instanceElementSet != null && instanceElementSet.Size > 0)
    {
      List<IntersectionStationContainer> _LeftIntersectionStations2 = (List<IntersectionStationContainer>) null;
      List<IntersectionStationContainer> _RightIntersectionStations2 = (List<IntersectionStationContainer>) null;
      List<FamilyInstance> _SiteFamilyInstanceList = (List<FamilyInstance>) null;
      foreach (Element element in instanceElementSet)
      {
        TopographySurfaceManagement.GetIntersections(_Document, element.UniqueId, ref _SiteFamilyInstanceList, ref _LeftIntersectionStations2, ref _RightIntersectionStations2);
        if (_SiteFamilyInstanceList != null && _SiteFamilyInstanceList.Count > 0)
        {
          _CurrentFamilyInstanceComponentWrapper.AddIntersectionFamilyInstances(_SiteFamilyInstanceList);
          _CurrentFamilyInstanceComponentWrapper.IntersectionFamilySymbol = _SiteFamilyInstanceList[0].Symbol;
        }
        if (_LeftIntersectionStations2 != null && _LeftIntersectionStations2.Count > 0)
          stationContainerList1.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations2);
        if (_RightIntersectionStations2 != null && _RightIntersectionStations2.Count > 0)
          stationContainerList2.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations2);
      }
    }
    if (stationContainerList1.Count == 0 || stationContainerList2.Count == 0 || _CommonFamilyInstanceComponentWrappers == null)
      return;
    IntersectionStationContainerComparer containerComparer1 = new IntersectionStationContainerComparer(true);
    for (int index1 = 0; index1 < _CommonFamilyInstanceComponentWrappers.Count; ++index1)
    {
      if (string.Compare(_CurrentFamilyInstanceComponentWrapper.ChainID, _CommonFamilyInstanceComponentWrappers[index1].ChainID, true) != 0 && string.Compare(_CommonFamilyInstanceComponentWrappers[index1].ChainID, _IgnoreChainID, true) != 0)
      {
        FamilyInstance existingFamilyInstance2 = _CommonFamilyInstanceComponentWrappers[index1].GetFirstExistingFamilyInstance();
        if (existingFamilyInstance2 != null)
        {
          Parameter parameter5 = ((Element) existingFamilyInstance2).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
          if (parameter5 != null)
          {
            foreach (int num7 in Enum.GetValues(typeof (LandcaddID)))
            {
              if (string.Compare(parameter5.AsString(), num7.ToString("000"), true) == 0)
              {
                _LocateType2 = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num7);
                break;
              }
            }
          }
          if (_LocateType1 == _LocateType2)
          {
            if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg == null)
              _CommonFamilyInstanceComponentWrappers[index1].CreateProposedLeg(_ProposedSurface);
            if (_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg != null)
            {
              if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegStartPnt, num1 / 2.0))
                EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegStartPnt, num1 / 2.0);
              if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegEndPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegEndPnt, num1 / 2.0))
                EPShared.eplGeoE_ArePntsDuplicates2D(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg.LegStartPnt, _CurrentFamilyInstanceComponentWrapper.InstanceLeg.LegEndPnt, num1 / 2.0);
              int pNumberOfIntersections = 0;
              if (RevitGeometry.eplGeoE_IntersectTwoLegLists(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, _CurrentFamilyInstanceComponentWrapper.InstanceLeg, ref ppPointList, ref pNumberOfIntersections, num1 / 2.0) == 0 && pNumberOfIntersections > 0)
              {
                FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance2, _LocateType2);
                if (familyTypeSymbol != null)
                {
                  _CommonFamilyInstanceComponentWrappers[index1].ProposedFamilySymbol = familyTypeSymbol;
                  switch (_LocateType2)
                  {
                    case LandcaddID.Street:
                      double num8 = 0.0;
                      Parameter parameter6 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
                      if (parameter6 != null)
                        num8 = parameter6.AsDouble();
                      Parameter parameter7 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
                      if (parameter7 != null)
                        num2 = num8 * (double) parameter7.AsInteger();
                      Parameter parameter8 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
                      if (parameter8 != null)
                      {
                        num4 = -num2 / 2.0 * parameter8.AsDouble();
                        break;
                      }
                      break;
                    case LandcaddID.Sidewalk:
                      Parameter parameter9 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
                      if (parameter9 != null)
                      {
                        num2 = parameter9.AsDouble();
                        break;
                      }
                      break;
                  }
                  if (num2 > 0.0)
                  {
                    Eps_Leg ppOffsetLegList3 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num2 / 2.0, 1, ref ppOffsetLegList3, true);
                    Eps_Leg ppOffsetLegList4 = new Eps_Leg();
                    RevitGeometry.OffsetLegList(_CommonFamilyInstanceComponentWrappers[index1].InstanceLeg, num2 / 2.0, 2, ref ppOffsetLegList4, true);
                    for (int index2 = stationContainerList1.Count - 1; index2 >= 0; --index2)
                    {
                      if (string.Compare(((Element) existingFamilyInstance2).UniqueId, stationContainerList1[index2].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, stationContainerList1[index2].SecondaryPlacementId, true) == 0)
                      {
                        flag1 = false;
                        flag2 = true;
                        _LeftIntersectionStations1.Add(stationContainerList1[index2]);
                        stationContainerList1.RemoveAt(index2);
                      }
                      else if (string.Compare(((Element) existingFamilyInstance1).UniqueId, stationContainerList1[index2].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance2).UniqueId, stationContainerList1[index2].SecondaryPlacementId, true) == 0)
                      {
                        flag1 = true;
                        flag2 = true;
                        _LeftIntersectionStations1.Add(stationContainerList1[index2]);
                        stationContainerList1.RemoveAt(index2);
                      }
                    }
                    for (int index3 = stationContainerList2.Count - 1; index3 >= 0; --index3)
                    {
                      if (string.Compare(((Element) existingFamilyInstance2).UniqueId, stationContainerList2[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance1).UniqueId, stationContainerList2[index3].SecondaryPlacementId, true) == 0)
                      {
                        flag1 = false;
                        flag2 = true;
                        _RightIntersectionStations1.Add(stationContainerList2[index3]);
                        stationContainerList2.RemoveAt(index3);
                      }
                      else if (string.Compare(((Element) existingFamilyInstance1).UniqueId, stationContainerList2[index3].PrimaryPlacementId, true) == 0 && string.Compare(((Element) existingFamilyInstance2).UniqueId, stationContainerList2[index3].SecondaryPlacementId, true) == 0)
                      {
                        flag1 = true;
                        flag2 = true;
                        _RightIntersectionStations1.Add(stationContainerList2[index3]);
                        stationContainerList2.RemoveAt(index3);
                      }
                    }
                    if (flag2)
                    {
                      flag3 = false;
                      if (_LocateType2 == LandcaddID.Street)
                      {
                        Parameter parameter10 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
                        if (parameter10 != null)
                          flag3 = Convert.ToBoolean(parameter10.AsInteger());
                      }
                      Eps_Leg instanceLeg1;
                      Eps_Leg epsLeg1;
                      Eps_Leg epsLeg2;
                      Eps_Leg instanceLeg2;
                      Eps_Leg _LeftOffsetLeg;
                      Eps_Leg _RightOffsetLeg;
                      double _dExistingOffset;
                      double _dExistingAdjustSubgradeElev;
                      if (flag1)
                      {
                        instanceLeg1 = _CurrentFamilyInstanceComponentWrapper.InstanceLeg;
                        epsLeg1 = ppOffsetLegList2;
                        epsLeg2 = ppOffsetLegList1;
                        instanceLeg2 = _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg;
                        _LeftOffsetLeg = ppOffsetLegList4;
                        _RightOffsetLeg = ppOffsetLegList3;
                        _dExistingOffset = num1;
                        _dExistingAdjustSubgradeElev = num3;
                      }
                      else
                      {
                        instanceLeg1 = _CommonFamilyInstanceComponentWrappers[index1].InstanceLeg;
                        epsLeg1 = ppOffsetLegList4;
                        epsLeg2 = ppOffsetLegList3;
                        instanceLeg2 = _CurrentFamilyInstanceComponentWrapper.InstanceLeg;
                        _LeftOffsetLeg = ppOffsetLegList2;
                        _RightOffsetLeg = ppOffsetLegList1;
                        _dExistingOffset = num2;
                        _dExistingAdjustSubgradeElev = num4;
                      }
                      if (!TopographySurfaceManagement.FindIntersectionStationAndProfiles(instanceLeg2, _LeftOffsetLeg, _RightOffsetLeg, instanceLeg1, epsLeg1, epsLeg2, _dExistingOffset, _dExistingAdjustSubgradeElev, _dReturnValue1, _dReturnValue2, false, false, 0.0, _Document, _TransactionContainer, _LocateType2, ref _LeftIntersectionStations1, ref _CenterIntersectionStations, ref _RightIntersectionStations1))
                        return;
                      if (_LeftIntersectionStations1 != null && _LeftIntersectionStations1.Count > 0)
                        _LeftIntersectionStations1.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
                      if (_CenterIntersectionStations != null && _CenterIntersectionStations.Count > 0)
                        _CenterIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
                      if (_RightIntersectionStations1 != null && _RightIntersectionStations1.Count > 0)
                        _RightIntersectionStations1.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
                      if (!flag1)
                      {
                        _CurrentFamilyInstanceComponentWrapper.CenterIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _CenterIntersectionStations);
                        _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _LeftIntersectionStations1);
                        _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.AddRange((IEnumerable<IntersectionStationContainer>) _RightIntersectionStations1);
                      }
                      if (flag1 && _LeftIntersectionStations1.Count > 0 && _LeftIntersectionStations1.Count == _RightIntersectionStations1.Count)
                      {
                        for (int index4 = 0; index4 < _LeftIntersectionStations1.Count; ++index4)
                        {
                          _LeftIntersectionStations1[index4].PrimaryPlacementId = ((Element) existingFamilyInstance2).UniqueId;
                          _RightIntersectionStations1[index4].PrimaryPlacementId = ((Element) existingFamilyInstance2).UniqueId;
                          if (_LeftIntersectionStations1[index4].IntersectionStations.Count == _RightIntersectionStations1[index4].IntersectionStations.Count)
                          {
                            for (int index5 = 0; index5 < _LeftIntersectionStations1[index4].IntersectionStations.Count; ++index5)
                            {
                              IntersectionContainer intersectionContainer1 = new IntersectionContainer();
                              intersectionContainer1.StartingIntersection = true;
                              ProfileContainer profileContainer1 = new ProfileContainer();
                              bool isPrimaryLeft1;
                              if (_LeftIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation <= _RightIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation)
                              {
                                isPrimaryLeft1 = _LeftIntersectionStations1[index4].IntersectionStations[index5].IsPrimaryLeft;
                                Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_LeftIntersectionStations1, index4, index5, false);
                                profileContainer1.Station = intersectionStationPoint != null && isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _LeftIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation;
                              }
                              else
                              {
                                isPrimaryLeft1 = _RightIntersectionStations1[index4].IntersectionStations[index5].IsPrimaryLeft;
                                Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_RightIntersectionStations1, index4, index5, false);
                                profileContainer1.Station = intersectionStationPoint != null && isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft1 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _RightIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation;
                              }
                              intersectionContainer1.Profiles.Add(profileContainer1);
                              intersectionContainer1.ProfileUsage = !isPrimaryLeft1 ? ProfileUsage.RightOnly : ProfileUsage.LeftOnly;
                              collection.Add(intersectionContainer1);
                              IntersectionContainer intersectionContainer2 = new IntersectionContainer();
                              intersectionContainer2.StartingIntersection = false;
                              ProfileContainer profileContainer2 = new ProfileContainer();
                              bool isPrimaryLeft2;
                              if (_LeftIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation <= _RightIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation)
                              {
                                isPrimaryLeft2 = _RightIntersectionStations1[index4].IntersectionStations[index5].IsPrimaryLeft;
                                Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_RightIntersectionStations1, index4, index5, false);
                                profileContainer2.Station = intersectionStationPoint != null && isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _RightIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation;
                              }
                              else
                              {
                                isPrimaryLeft2 = _LeftIntersectionStations1[index4].IntersectionStations[index5].IsPrimaryLeft;
                                Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_LeftIntersectionStations1, index4, index5, false);
                                profileContainer2.Station = intersectionStationPoint != null && isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg1, ref _dStation, ref _dOffset) == 1700 || !isPrimaryLeft2 && RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(intersectionStationPoint, epsLeg2, ref _dStation, ref _dOffset) == 1700 ? _dStation : _LeftIntersectionStations1[index4].IntersectionStations[index5].PrimaryStation;
                              }
                              intersectionContainer2.Profiles.Add(profileContainer2);
                              intersectionContainer2.ProfileUsage = !isPrimaryLeft2 ? ProfileUsage.RightOnly : ProfileUsage.LeftOnly;
                              collection.Add(intersectionContainer2);
                            }
                          }
                        }
                        IntersectionContainerComparer containerComparer2 = new IntersectionContainerComparer(true);
                        if (collection != null && collection.Count > 0)
                          collection.Sort((IComparer<IntersectionContainer>) containerComparer2);
                        _CurrentFamilyInstanceComponentWrapper.IntersectionContainerList.AddRange((IEnumerable<IntersectionContainer>) collection);
                        collection.Clear();
                      }
                      flag2 = false;
                      _LeftIntersectionStations1.Clear();
                      _CenterIntersectionStations.Clear();
                      _RightIntersectionStations1.Clear();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if (_CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations != null && _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.Count > 0)
      _CurrentFamilyInstanceComponentWrapper.LeftIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
    if (_CurrentFamilyInstanceComponentWrapper.CenterIntersectionStations != null && _CurrentFamilyInstanceComponentWrapper.CenterIntersectionStations.Count > 0)
      _CurrentFamilyInstanceComponentWrapper.CenterIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
    if (_CurrentFamilyInstanceComponentWrapper.RightIntersectionStations == null || _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.Count <= 0)
      return;
    _CurrentFamilyInstanceComponentWrapper.RightIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer1);
  }

  private static void SetupIntersectionContainersForSiteComponent(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    TopographySurfaceContainer _ProposedSurface,
    List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers,
    ref FamilyInstanceComponentWrapper _CurFamilyInstanceComponentWrapper)
  {
    TopographySurfaceManagement.SetupIntersectionContainersForSiteComponent(_Document, _TransactionContainer, _ProposedSurface, string.Empty, _CommonFamilyInstanceComponentWrappers, ref _CurFamilyInstanceComponentWrapper);
  }

  private static void SetupIntersectionContainersForSiteComponent(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    TopographySurfaceContainer _ProposedSurface,
    string _IgnoreChainID,
    List<FamilyInstanceComponentWrapper> _CommonFamilyInstanceComponentWrappers,
    ref FamilyInstanceComponentWrapper _CurFamilyInstanceComponentWrapper)
  {
    List<IntersectionContainer> _IntersectionContainers = new List<IntersectionContainer>();
    List<OffsetLegWrapper> _OffsetLegWrappers = new List<OffsetLegWrapper>();
    List<double> _Stations = new List<double>();
    List<Eps_Point> _ApplySurfaceElevationPoints = new List<Eps_Point>();
    _CurFamilyInstanceComponentWrapper.IntersectionContainerList = new List<IntersectionContainer>();
    FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper = _CurFamilyInstanceComponentWrapper;
    TopographySurfaceManagement.SetupIntersectionStationsOnlyForSelectedSiteComponent(_Document, _ProposedSurface, _TransactionContainer, _IgnoreChainID, _CommonFamilyInstanceComponentWrappers, ref _CurrentFamilyInstanceComponentWrapper);
    _CurFamilyInstanceComponentWrapper = _CurrentFamilyInstanceComponentWrapper;
    Eps_Leg _OriginaltLeg = Eps_Leg.CopyLeg(_CurFamilyInstanceComponentWrapper.InstanceLeg);
    if (_CurFamilyInstanceComponentWrapper.CenterIntersectionStations.Count > 0)
    {
      for (int index1 = 0; index1 < _CurFamilyInstanceComponentWrapper.CenterIntersectionStations.Count; ++index1)
      {
        for (int index2 = 0; index2 < _CurFamilyInstanceComponentWrapper.CenterIntersectionStations[index1].IntersectionStations.Count; ++index2)
        {
          _Stations.Add(_CurFamilyInstanceComponentWrapper.CenterIntersectionStations[index1].IntersectionStations[index2].Station);
          Eps_Point intersectionStationPoint = TopographySurfaceManagement.GetIntersectionStationPoint(_CurFamilyInstanceComponentWrapper.CenterIntersectionStations, index1, index2, false);
          if (intersectionStationPoint != null)
            _ApplySurfaceElevationPoints.Add(intersectionStationPoint);
        }
      }
    }
    _CurFamilyInstanceComponentWrapper.InstanceLeg = _CurFamilyInstanceComponentWrapper.InstanceLeg.SplitLegAtStations(_Stations);
    _CurFamilyInstanceComponentWrapper.InstanceLeg = _CurFamilyInstanceComponentWrapper.InstanceLeg.ApplyElevationsToLeg((TopographySurfaceContainer) null, false, false, 0.0, _ApplySurfaceElevationPoints);
    double _dAdjustSubgradeElev = 0.0;
    double _dStreetEdgeAdjustElev = 0.0;
    double num1 = 0.0;
    LandcaddID _LocateType = LandcaddID.Sidewalk;
    FamilyInstance existingFamilyInstance = _CurFamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance != null)
    {
      Parameter parameter1 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
      if (parameter1 != null)
      {
        foreach (int num2 in Enum.GetValues(typeof (LandcaddID)))
        {
          if (string.Compare(parameter1.AsString(), num2.ToString("000"), true) == 0)
          {
            _LocateType = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num2);
            break;
          }
        }
      }
      FamilySymbol familyTypeSymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance, _LocateType);
      if (familyTypeSymbol != null)
      {
        _CurFamilyInstanceComponentWrapper.ProposedFamilySymbol = familyTypeSymbol;
        switch (_LocateType)
        {
          case LandcaddID.Street:
            double num3 = 0.0;
            Parameter parameter2 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
            if (parameter2 != null)
              num3 = parameter2.AsDouble();
            Parameter parameter3 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
            if (parameter3 != null)
              num1 = num3 * (double) parameter3.AsInteger();
            Parameter parameter4 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
            if (parameter4 != null)
              _dStreetEdgeAdjustElev = -num1 / 2.0 * parameter4.AsDouble();
            Parameter parameter5 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.StreetPavementDepthParameter);
            if (parameter5 != null)
            {
              _dAdjustSubgradeElev = -parameter5.AsDouble();
              break;
            }
            break;
          case LandcaddID.Sidewalk:
            Parameter parameter6 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
            if (parameter6 != null)
              num1 = parameter6.AsDouble();
            Parameter parameter7 = ((Element) familyTypeSymbol).LookupParameter(RevitParameters.SideWalkPavementDepthParameter);
            if (parameter7 != null)
            {
              _dAdjustSubgradeElev = -parameter7.AsDouble();
              break;
            }
            break;
        }
      }
    }
    TopographySurfaceManagement.FindOffsetLegWrappers(_OriginaltLeg, _CurFamilyInstanceComponentWrapper.InstanceLeg, _CurFamilyInstanceComponentWrapper.LeftIntersectionStations, _CurFamilyInstanceComponentWrapper.CenterIntersectionStations, _CurFamilyInstanceComponentWrapper.RightIntersectionStations, _LocateType, num1 / 2.0, num1 / 2.0, 0.0, _dAdjustSubgradeElev, _dStreetEdgeAdjustElev, ref _OffsetLegWrappers, ref _IntersectionContainers);
    _OffsetLegWrappers.Clear();
    if (_IntersectionContainers.Count <= 0)
      return;
    _CurFamilyInstanceComponentWrapper.IntersectionContainerList.AddRange((IEnumerable<IntersectionContainer>) _IntersectionContainers);
    _IntersectionContainers.Clear();
  }

  public static TopographySurfaceContainer FindParentSurfaceAndRemovePointsForSelectedCurbComponent(
    Document _Document,
    TopographySurfaceContainer _ProposedSurface,
    FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper,
    ref List<Eps_Point> _TopoPointList)
  {
    TopographySurfaceContainer _Surface = (TopographySurfaceContainer) null;
    LandcaddID landcaddId = LandcaddID.Curb;
    string str = string.Empty;
    string empty = string.Empty;
    FamilyInstance existingFamilyInstance = _CurrentFamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance != null)
    {
      Parameter parameter1 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
      if (parameter1 != null)
      {
        foreach (int num in Enum.GetValues(typeof (LandcaddID)))
        {
          if (string.Compare(parameter1.AsString(), num.ToString("000"), true) == 0)
          {
            landcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
            break;
          }
        }
      }
      Parameter parameter2 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
      if (parameter2 != null)
        str = parameter2.AsString();
    }
    if (landcaddId != LandcaddID.Curb || str == string.Empty || _ProposedSurface == null || _ProposedSurface.TopographySurface == null || string.Compare(((Element) _ProposedSurface.TopographySurface).UniqueId, str, true) == 0)
      return (TopographySurfaceContainer) null;
    TopographySurface topoSurfaceInstance = TopographySurfaceManagement.FindTopoSurfaceInstance(_Document, str);
    if (topoSurfaceInstance != null)
      _Surface = new TopographySurfaceContainer(_Document.Application, topoSurfaceInstance, true);
    if (_Surface != null && existingFamilyInstance != null)
    {
      double num1 = 0.02;
      double num2 = 0.0;
      double num3 = 0.0;
      bool flag = false;
      if (_CurrentFamilyInstanceComponentWrapper.OriginalFamilySymbol != null)
      {
        Parameter parameter3 = ((Element) _CurrentFamilyInstanceComponentWrapper.OriginalFamilySymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
        if (parameter3 != null)
          num3 = parameter3.AsDouble();
        Parameter parameter4 = ((Element) _CurrentFamilyInstanceComponentWrapper.OriginalFamilySymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
        if (parameter4 != null)
          num2 = parameter4.AsDouble();
      }
      if (_CurrentFamilyInstanceComponentWrapper.OriginalLeg == null)
        _CurrentFamilyInstanceComponentWrapper.CreateOriginalLeg(_Surface);
      Eps_Leg pLeg;
      if (_CurrentFamilyInstanceComponentWrapper.OriginalLeg != null && _CurrentFamilyInstanceComponentWrapper.OriginalLeg.IsLegClosed())
      {
        Eps_Leg ppOffsetLegList1 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.OriginalLeg, num1 + num2 + num3, 1, ref ppOffsetLegList1, true);
        Eps_Leg ppOffsetLegList2 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.OriginalLeg, num1 + num2 + num3, 2, ref ppOffsetLegList2, true);
        pLeg = RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList2) >= RevitGeometry.eplGeoE_CalcLegListLength(ppOffsetLegList1) ? Eps_Leg.CopyLeg(ppOffsetLegList2) : Eps_Leg.CopyLeg(ppOffsetLegList1);
      }
      else
      {
        Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
        if (parameter != null)
          flag = Convert.ToBoolean(parameter.AsInteger());
        Eps_Leg ppOffsetLegList3 = new Eps_Leg();
        Eps_Leg ppOffsetLegList4 = new Eps_Leg();
        Eps_Leg pLegListToOffset;
        if (flag)
        {
          RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.OriginalLeg, num1, 2, ref ppOffsetLegList3, true);
          pLegListToOffset = ppOffsetLegList3.ExtendLegList(true, num1).ExtendLegList(false, num1);
          RevitGeometry.OffsetLegList(pLegListToOffset, 2.0 * num1 + num2 + num3, 1, ref ppOffsetLegList4, true);
        }
        else
        {
          RevitGeometry.OffsetLegList(_CurrentFamilyInstanceComponentWrapper.OriginalLeg, num1, 1, ref ppOffsetLegList3, true);
          pLegListToOffset = ppOffsetLegList3.ExtendLegList(true, num1).ExtendLegList(false, num1);
          RevitGeometry.OffsetLegList(pLegListToOffset, 2.0 * num1 + num2 + num3, 2, ref ppOffsetLegList4, true);
        }
        pLeg = TopographySurfaceManagement.FitCorrectLegListsAtGaps(new List<Eps_Leg>()
        {
          pLegListToOffset,
          ppOffsetLegList4
        });
      }
      _TopoPointList = _Surface.GetAllVertices();
      if (pLeg != null && _TopoPointList.Count > 0)
        RevitGeometry.RemoveAllPointsInBoundary(ref _TopoPointList, pLeg);
    }
    return _Surface;
  }

  private static double FindBreaklineIntervalFromList(
    Eps_Leg _ParkingLotBreaklineLeg,
    List<Element> _ParkingLotBreaklineElementList,
    List<double> _dParkingLotBreaklineLinearPointIntervals)
  {
    if (_dParkingLotBreaklineLinearPointIntervals.Count != _ParkingLotBreaklineElementList.Count)
      return 5.0;
    for (Eps_Leg epsLeg1 = _ParkingLotBreaklineLeg; epsLeg1 != null; epsLeg1 = epsLeg1.Next)
    {
      for (int index = _ParkingLotBreaklineElementList.Count - 1; index >= 0; --index)
      {
        Element breaklineElement = _ParkingLotBreaklineElementList[index];
        if (breaklineElement != null && breaklineElement.Location is LocationCurve location)
        {
          Curve curve = location.Curve;
          if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
          {
            switch (curve)
            {
              case Arc _ when epsLeg1.Arc != null:
                if (new Eps_Arc((Arc) curve).IsEqual((BaseArc) epsLeg1.Arc))
                {
                  if (RevitDefines.LT(_dParkingLotBreaklineLinearPointIntervals[index], 0.0833333))
                    _dParkingLotBreaklineLinearPointIntervals[index] = 0.0833333;
                  return _dParkingLotBreaklineLinearPointIntervals[index];
                }
                continue;
              case Line _ when epsLeg1.Line != null:
                if (new Eps_Line((Line) curve).IsEqual((BaseLine) epsLeg1.Line))
                {
                  if (RevitDefines.LT(_dParkingLotBreaklineLinearPointIntervals[index], 0.0833333))
                    _dParkingLotBreaklineLinearPointIntervals[index] = 0.0833333;
                  return _dParkingLotBreaklineLinearPointIntervals[index];
                }
                continue;
              case Ellipse _:
              case NurbSpline _:
              case HermiteSpline _:
                for (Eps_Leg epsLeg2 = RevitGeometry.GetLegFromSpline(breaklineElement, curve, false); epsLeg2 != null; epsLeg2 = epsLeg2.Next)
                {
                  if (epsLeg2.Line != null && epsLeg1.Line != null)
                  {
                    if (epsLeg2.Line.IsEqual((BaseLine) epsLeg1.Line))
                    {
                      if (RevitDefines.LT(_dParkingLotBreaklineLinearPointIntervals[index], 0.0833333))
                        _dParkingLotBreaklineLinearPointIntervals[index] = 0.0833333;
                      return _dParkingLotBreaklineLinearPointIntervals[index];
                    }
                  }
                  else if (epsLeg2.Arc != null && epsLeg1.Arc != null && epsLeg2.Arc.IsEqual((BaseArc) epsLeg1.Arc))
                  {
                    if (RevitDefines.LT(_dParkingLotBreaklineLinearPointIntervals[index], 0.0833333))
                      _dParkingLotBreaklineLinearPointIntervals[index] = 0.0833333;
                    return _dParkingLotBreaklineLinearPointIntervals[index];
                  }
                }
                continue;
              default:
                continue;
            }
          }
        }
      }
    }
    return 5.0;
  }

  private static void CombineLegListsAtGaps(ref Eps_Leg _CombinedLegList, Eps_Leg _AddLegList)
  {
    if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CombinedLegList.LegEndPnt, _AddLegList.LegStartPnt))
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      _CompleteLeg.Line = new Eps_Line();
      _CompleteLeg.Line.StartPnt = _CombinedLegList.LegEndPnt;
      _CompleteLeg.Line.EndPnt = _AddLegList.LegStartPnt;
      _CombinedLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    _CombinedLegList.Last.Next = Eps_Leg.CopyLeg(_AddLegList);
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_CombinedLegList.LegStartPnt, _AddLegList.LegEndPnt))
      return;
    Eps_Leg _CompleteLeg1 = new Eps_Leg();
    _CompleteLeg1.Line = new Eps_Line();
    _CompleteLeg1.Line.StartPnt = _AddLegList.LegEndPnt;
    _CompleteLeg1.Line.EndPnt = _CombinedLegList.LegStartPnt;
    _CombinedLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
  }

  private static Eps_Leg FitCorrectLegListsAtGaps(
    Eps_Leg _LeftCatchLinesLeg,
    Eps_Leg _RightCatchLinesLeg,
    Eps_Leg _LeftCutFillLinesLeg,
    Eps_Leg _RightCutFillLinesLeg,
    bool _bIsOriginalLegClosed)
  {
    Eps_Leg _CombinedLegList = (Eps_Leg) null;
    if (_LeftCatchLinesLeg != null && _LeftCatchLinesLeg.IsLegClosed())
      return _LeftCatchLinesLeg;
    if (_RightCatchLinesLeg != null && _RightCatchLinesLeg.IsLegClosed())
      return _RightCatchLinesLeg;
    bool flag = false;
    if (_LeftCatchLinesLeg != null && _LeftCatchLinesLeg.LegCount > 0 && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(_LeftCatchLinesLeg), 0.0))
      _CombinedLegList = Eps_Leg.CopyLeg(_LeftCatchLinesLeg);
    if (_RightCatchLinesLeg != null && _RightCatchLinesLeg.LegCount > 0 && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(_RightCatchLinesLeg), 0.0))
    {
      flag = true;
      if (_CombinedLegList == null)
      {
        _CombinedLegList = Eps_Leg.CopyLeg(_RightCatchLinesLeg);
      }
      else
      {
        TopographySurfaceManagement.CombineLegListsAtGaps(ref _CombinedLegList, _RightCatchLinesLeg);
        return _CombinedLegList;
      }
    }
    if ((flag || _CombinedLegList == null) && _LeftCutFillLinesLeg != null && _LeftCutFillLinesLeg.LegCount > 0 && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(_LeftCutFillLinesLeg), 0.0))
    {
      if (_CombinedLegList == null)
      {
        _CombinedLegList = Eps_Leg.CopyLeg(_LeftCutFillLinesLeg);
      }
      else
      {
        TopographySurfaceManagement.CombineLegListsAtGaps(ref _CombinedLegList, _LeftCutFillLinesLeg);
        return _CombinedLegList;
      }
    }
    if (_RightCutFillLinesLeg != null && _RightCutFillLinesLeg.LegCount > 0 && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(_RightCutFillLinesLeg), 0.0))
    {
      if (_CombinedLegList == null)
        _CombinedLegList = Eps_Leg.CopyLeg(_RightCutFillLinesLeg);
      else
        TopographySurfaceManagement.CombineLegListsAtGaps(ref _CombinedLegList, _RightCutFillLinesLeg);
    }
    if (_bIsOriginalLegClosed && _CombinedLegList != null && !_CombinedLegList.IsLegClosed())
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      _CompleteLeg.Line = new Eps_Line();
      _CompleteLeg.Line.StartPnt = _CombinedLegList.LegEndPnt;
      _CompleteLeg.Line.EndPnt = _CombinedLegList.LegStartPnt;
      _CombinedLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return _CombinedLegList;
  }

  private static Eps_Leg FitCorrectLegListsAtGaps(List<Eps_Leg> _CatchLinesLegLists)
  {
    Eps_Leg _CombinedLegList = (Eps_Leg) null;
    if (_CatchLinesLegLists == null || _CatchLinesLegLists.Count == 0)
      return (Eps_Leg) null;
    if (_CatchLinesLegLists.Count > 0 && _CatchLinesLegLists[0] != null && _CatchLinesLegLists[0].IsLegClosed())
      return _CatchLinesLegLists[0];
    if (_CatchLinesLegLists.Count > 1 && _CatchLinesLegLists[1] != null && _CatchLinesLegLists[1].IsLegClosed())
      return _CatchLinesLegLists[1];
    for (int index = 0; index < _CatchLinesLegLists.Count; ++index)
    {
      if (_CatchLinesLegLists[index] != null && _CatchLinesLegLists[index].LegCount > 0 && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(_CatchLinesLegLists[index]), 0.0))
      {
        if (_CombinedLegList == null)
          _CombinedLegList = Eps_Leg.CopyLeg(_CatchLinesLegLists[index]);
        else
          Eps_Leg.CombineLegListsAtShortestGaps(ref _CombinedLegList, _CatchLinesLegLists[index]);
      }
    }
    if (_CombinedLegList != null && !_CombinedLegList.IsLegClosed())
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      _CompleteLeg.Line = new Eps_Line();
      _CompleteLeg.Line.StartPnt = _CombinedLegList.LegEndPnt;
      _CompleteLeg.Line.EndPnt = _CombinedLegList.LegStartPnt;
      _CombinedLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return _CombinedLegList;
  }

  public static void RefreshSurface(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    ref TopographySurfaceContainer _NewPointsSurface,
    ref FamilyInstance _PlacementFamilyInstance)
  {
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarUpdatingModelMessage");
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = 12;
    List<Eps_Point> allVertices = _NewPointsSurface.GetAllVertices();
    List<XYZ> PointXYZList = new List<XYZ>();
    for (int index = 0; index < allVertices.Count; ++index)
      PointXYZList.Add(allVertices[index].XYZ);
    progressBarForm.UpdateProgressBar(1);
    if (PointXYZList.Count > 0)
    {
      _TransactionContainer.BeginTransaction();
      TopographySurfaceManagement.RemoveDuplicateXY(ref PointXYZList);
      TopographySurface _TopographySurface = TopographySurface.Create(_Document, (IList<XYZ>) PointXYZList);
      _Document.Regenerate();
      progressBarForm.UpdateProgressBar(7);
      Parameter parameter1 = ((Element) _NewPointsSurface.TopographySurface)[(BuiltInParameter) -1002107];
      if (parameter1 != null && ElementId.op_Inequality(parameter1.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter1.AsElementId(), ElementId.InvalidElementId))
      {
        Parameter parameter2 = ((Element) _TopographySurface)[(BuiltInParameter) -1002107];
        if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
        {
          ElementId elementId = parameter1.AsElementId();
          parameter2.Set(elementId);
        }
      }
      Parameter parameter3 = ((Element) _NewPointsSurface.TopographySurface)[(BuiltInParameter) -1012100];
      if (parameter3 != null && ElementId.op_Inequality(parameter3.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter3.AsElementId(), ElementId.InvalidElementId))
      {
        Parameter parameter4 = ((Element) _TopographySurface)[(BuiltInParameter) -1012100];
        if (parameter4 != null && !((APIObject) parameter4).IsReadOnly)
        {
          ElementId elementId = parameter3.AsElementId();
          parameter4.Set(elementId);
        }
      }
      Parameter parameter5 = ((Element) _NewPointsSurface.TopographySurface)[(BuiltInParameter) -1012101];
      if (parameter5 != null && ElementId.op_Inequality(parameter5.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter5.AsElementId(), ElementId.InvalidElementId))
      {
        Parameter parameter6 = ((Element) _TopographySurface)[(BuiltInParameter) -1012101];
        if (parameter6 != null && !((APIObject) parameter6).IsReadOnly)
        {
          ElementId elementId = parameter5.AsElementId();
          parameter6.Set(elementId);
        }
      }
      Parameter parameter7 = ((Element) _NewPointsSurface.TopographySurface)[(BuiltInParameter) -1006900];
      if (parameter7 != null && parameter7.AsString() != null && parameter7.AsString() != string.Empty)
      {
        Parameter parameter8 = ((Element) _TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter8 != null && !((APIObject) parameter8).IsReadOnly)
          parameter8.Set(parameter7.AsString());
      }
      _Document.Delete(((Element) _NewPointsSurface.TopographySurface).Id);
      progressBarForm.UpdateProgressBar(3);
      _NewPointsSurface = new TopographySurfaceContainer(_Document.Application, _TopographySurface, true);
      if (_PlacementFamilyInstance != null)
      {
        Parameter parameter9 = ((Element) _PlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
        if (parameter9 != null && !((APIObject) parameter9).IsReadOnly)
          parameter9.Set(((Element) _TopographySurface).UniqueId);
      }
      _TransactionContainer.EndTransaction();
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void CreateProposedSurface(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilySymbol _PlacementSymbol,
    List<Eps_Point> _PointList,
    string _strToposurfaceName,
    ElementId _MaterialId,
    ElementId _PhaseCreated,
    ElementId _PhaseDemolished)
  {
    TopographySurface _ProposedTopographySurface = (TopographySurface) null;
    FamilyInstance _PlacementFamilyInstance = (FamilyInstance) null;
    TopographySurfaceManagement.CreateProposedSurface(_Document, _TransactionContainer, _PlacementSymbol, _PointList, _strToposurfaceName, _MaterialId, _PhaseCreated, _PhaseDemolished, ref _ProposedTopographySurface, ref _PlacementFamilyInstance);
  }

  public static void CreateProposedSurface(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilySymbol _PlacementSymbol,
    List<Eps_Point> _PointList,
    ElementId _MaterialId,
    ref TopographySurface _ProposedTopographySurface,
    ref FamilyInstance _PlacementFamilyInstance)
  {
    ElementId _PhaseCreated = (ElementId) null;
    ElementId _PhaseDemolished = (ElementId) null;
    TopographySurfaceManagement.CreateProposedSurface(_Document, _TransactionContainer, _PlacementSymbol, _PointList, string.Empty, _MaterialId, _PhaseCreated, _PhaseDemolished, ref _ProposedTopographySurface, ref _PlacementFamilyInstance);
  }

  public static void CreateProposedSurface(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilySymbol _PlacementSymbol,
    List<Eps_Point> _PointList,
    string _strToposurfaceName,
    ElementId _MaterialId,
    ElementId _PhaseCreated,
    ElementId _PhaseDemolished,
    ref TopographySurface _ProposedTopographySurface,
    ref FamilyInstance _PlacementFamilyInstance)
  {
    List<XYZ> PointXYZList = new List<XYZ>();
    for (int index = 0; index < _PointList.Count; ++index)
      PointXYZList.Add(_PointList[index].XYZ);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingNewProposedToposurfaceMessage");
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(2);
    progressBarForm.UpdateProgressBar(1);
    _TransactionContainer.BeginTransaction();
    TopographySurfaceManagement.RemoveDuplicateXY(ref PointXYZList);
    _ProposedTopographySurface = TopographySurface.Create(_Document, (IList<XYZ>) PointXYZList);
    _Document.Regenerate();
    if (ElementId.op_Inequality(_MaterialId, (ElementId) null))
      ((Element) _ProposedTopographySurface)[(BuiltInParameter) -1002107]?.Set(_MaterialId);
    if (ElementId.op_Inequality(_PhaseCreated, (ElementId) null))
      ((Element) _ProposedTopographySurface)[(BuiltInParameter) -1012100]?.Set(_PhaseCreated);
    if (ElementId.op_Inequality(_PhaseDemolished, (ElementId) null))
      ((Element) _ProposedTopographySurface)[(BuiltInParameter) -1012101]?.Set(_PhaseDemolished);
    Parameter parameter1 = ((Element) _ProposedTopographySurface)[(BuiltInParameter) -1006900];
    if (parameter1 != null && !((APIObject) parameter1).IsReadOnly)
    {
      if (_strToposurfaceName != string.Empty)
        parameter1.Set(_strToposurfaceName);
      else
        parameter1.Set(EPShared.LocalRM.GetString("ProposedToposurfaceString"));
    }
    ElementSet _ElementSet = new ElementSet();
    if (_PlacementSymbol != null)
    {
      _PlacementFamilyInstance = RevitUtility.NewFamilyInstance(_Document, new XYZ(0.0, 0.0, 0.0), _PlacementSymbol, (Element) _ProposedTopographySurface, _Document.ActiveView.GenLevel, (StructuralType) 0, ref _TransactionContainer);
      Parameter parameter2 = ((Element) _PlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
      if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
        parameter2.Set(((Element) _ProposedTopographySurface).UniqueId);
      Parameter parameter3 = ((Element) _PlacementFamilyInstance).LookupParameter(RevitParameters.IsProposedSurfaceFamilyParameter);
      if (parameter3 != null && !((APIObject) parameter3).IsReadOnly)
        parameter3.Set(Convert.ToInt32(true));
      _ElementSet.Insert((Element) _PlacementFamilyInstance);
    }
    RevitUtility.HideElementsInAllViews(_Document, _ElementSet);
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    _TransactionContainer.EndTransaction();
  }

  public static void FindAndCreateProposedLandcaddTopographySurface(
    Document _Document,
    ref TopographySurfaceContainer _BaseSurfaceContainer,
    ref FamilyInstance _BasePlacementFamilyInstance,
    ref TopographySurfaceContainer _ProposedSurfaceContainer,
    ref FamilyInstance _ProposedPlacementFamilyInstance)
  {
    TopographySurfaceManagement.FindBaseLandcaddTopographySurface(_Document, ref _BaseSurfaceContainer, ref _BasePlacementFamilyInstance, ref _ProposedSurfaceContainer, ref _ProposedPlacementFamilyInstance);
    if (_ProposedSurfaceContainer != null && _ProposedPlacementFamilyInstance != null)
      return;
    EPTransactionContainer _TransactionContainer = new EPTransactionContainer(_Document);
    _TransactionContainer.Start(EPShared.LocalRM.GetString("SurfaceCleanUpTransaction"));
    RevitUtility.RemoveAllSiteComponents(_Document, _TransactionContainer);
    if (_BaseSurfaceContainer != null && _BasePlacementFamilyInstance != null)
    {
      if (_ProposedPlacementFamilyInstance != null)
      {
        _TransactionContainer.BeginTransaction();
        _Document.Delete(((Element) _ProposedPlacementFamilyInstance).Id);
        _TransactionContainer.EndTransaction();
      }
      ElementId _MaterialId = (ElementId) null;
      Parameter parameter = ((Element) _BaseSurfaceContainer.TopographySurface)[(BuiltInParameter) -1002107];
      if (parameter != null)
        _MaterialId = parameter.AsElementId();
      TopographySurface _ProposedTopographySurface = (TopographySurface) null;
      TopographySurfaceManagement.CreateProposedSurface(_Document, _TransactionContainer, _BasePlacementFamilyInstance.Symbol, _BaseSurfaceContainer.GetAllVertices(), _MaterialId, ref _ProposedTopographySurface, ref _ProposedPlacementFamilyInstance);
      _ProposedSurfaceContainer = new TopographySurfaceContainer(_Document.Application, _ProposedTopographySurface, true);
    }
    else if (_ProposedPlacementFamilyInstance != null || _BasePlacementFamilyInstance != null)
    {
      if (_ProposedPlacementFamilyInstance != null)
      {
        _TransactionContainer.BeginTransaction();
        _Document.Delete(((Element) _ProposedPlacementFamilyInstance).Id);
        _TransactionContainer.EndTransaction();
      }
      if (_BasePlacementFamilyInstance != null)
      {
        _TransactionContainer.BeginTransaction();
        _Document.Delete(((Element) _BasePlacementFamilyInstance).Id);
        _TransactionContainer.EndTransaction();
      }
    }
    _TransactionContainer.Commit();
  }

  public static void FindBaseLandcaddTopographySurface(
    Document _Document,
    bool _bIsProposedSurface,
    ref TopographySurfaceContainer _SiteTopographySurfaceContainer,
    ref FamilyInstance _TopoPlacementFamilyInstance)
  {
    TopographySurfaceContainer _BaseTopographySurfaceContainer = (TopographySurfaceContainer) null;
    TopographySurfaceContainer _ProposedTopographySurfaceContainer = (TopographySurfaceContainer) null;
    FamilyInstance _BasePlacementFamilyInstance = (FamilyInstance) null;
    FamilyInstance _ProposedPlacementFamilyInstance = (FamilyInstance) null;
    TopographySurfaceManagement.FindBaseLandcaddTopographySurface(_Document, ref _BaseTopographySurfaceContainer, ref _BasePlacementFamilyInstance, ref _ProposedTopographySurfaceContainer, ref _ProposedPlacementFamilyInstance);
    if (_bIsProposedSurface)
    {
      _SiteTopographySurfaceContainer = _ProposedTopographySurfaceContainer;
      _TopoPlacementFamilyInstance = _ProposedPlacementFamilyInstance;
    }
    else
    {
      _SiteTopographySurfaceContainer = _BaseTopographySurfaceContainer;
      _TopoPlacementFamilyInstance = _BasePlacementFamilyInstance;
    }
  }

  public static void FindBaseLandcaddTopographySurface(
    Document _Document,
    ref TopographySurfaceContainer _BaseTopographySurfaceContainer,
    ref FamilyInstance _BasePlacementFamilyInstance,
    ref TopographySurfaceContainer _ProposedTopographySurfaceContainer,
    ref FamilyInstance _ProposedPlacementFamilyInstance)
  {
    TopographySurfaceManagement.FindBaseLandcaddTopographySurface(_Document, ref _BaseTopographySurfaceContainer, ref _BasePlacementFamilyInstance, ref _ProposedTopographySurfaceContainer, ref _ProposedPlacementFamilyInstance, (EPTransactionContainer) null);
  }

  public static void FindBaseLandcaddTopographySurface(
    Document _Document,
    ref TopographySurfaceContainer _BaseTopographySurfaceContainer,
    ref FamilyInstance _BasePlacementFamilyInstance,
    ref TopographySurfaceContainer _ProposedTopographySurfaceContainer,
    ref FamilyInstance _ProposedPlacementFamilyInstance,
    EPTransactionContainer _TransactionContainer)
  {
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.TopoSurfacePlacement).ToString("000"), true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    IList<Element> elements1 = new FilteredElementCollector(_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements();
    IList<Element> elements2 = new FilteredElementCollector(_Document).OfClass(typeof (CeilingAndFloor)).OfCategory((BuiltInCategory) -2001263).ToElements();
    List<TopographySurfaceContainer> _SubRegionBuildingPadList = new List<TopographySurfaceContainer>();
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    bool flag5 = false;
    bool flag6 = false;
    ElementSet elm_set1 = new ElementSet();
    ElementSet elm_set2 = new ElementSet();
    EPTransactionContainer _TransactionContainer1;
    if (_TransactionContainer != null)
    {
      _TransactionContainer1 = _TransactionContainer;
    }
    else
    {
      _TransactionContainer1 = new EPTransactionContainer(_Document);
      _TransactionContainer1.Start(EPShared.LocalRM.GetString("RelinkSurfacesTransaction"));
    }
    foreach (Element element in (IEnumerable<Element>) elements1)
    {
      if (element != null && element.Category != null)
      {
        int integerValue1 = element.Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001340;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1 && element is TopographySurface _TopographySurface)
        {
          for (int index = list.Count - 1; index >= 0; --index)
          {
            if (list[index] is FamilyInstance familyInstance && ((Element) familyInstance).Category != null)
            {
              int integerValue2 = ((Element) familyInstance).Category.Id.IntegerValue;
              builtInCategory = (BuiltInCategory) -2001260;
              int hashCode2 = builtInCategory.GetHashCode();
              if (integerValue2 == hashCode2)
              {
                SiteworksIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
                if (SiteworksIDParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.TopoSurfacePlacement).ToString("000"), true) == 0)
                {
                  Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.IsProposedSurfaceFamilyParameter);
                  if (parameter1 != null)
                  {
                    Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
                    if (parameter2 != null && parameter2.AsString() != string.Empty)
                    {
                      if (string.Compare(parameter2.AsString(), ((Element) _TopographySurface).UniqueId, true) == 0)
                      {
                        if (!Convert.ToBoolean(parameter1.AsInteger()))
                        {
                          _BasePlacementFamilyInstance = familyInstance;
                          _BaseTopographySurfaceContainer = new TopographySurfaceContainer(_Document.Application, _TopographySurface, true);
                          flag2 = true;
                        }
                        else
                        {
                          _ProposedPlacementFamilyInstance = familyInstance;
                          _ProposedTopographySurfaceContainer = new TopographySurfaceContainer(_Document.Application, _TopographySurface, true);
                          flag3 = true;
                        }
                        list.RemoveAt(index);
                        flag1 = true;
                        break;
                      }
                      Parameter parameter3 = ((Element) _TopographySurface)[(BuiltInParameter) -1006900];
                      if (parameter3 != null && parameter3.AsString() != null && parameter3.AsString() != string.Empty)
                      {
                        if (!flag2 && !Convert.ToBoolean(parameter1.AsInteger()) && parameter3.AsString().ToLower().Contains(EPShared.LocalRM.GetString("BaseToposurfaceString").ToLower()))
                        {
                          if (elm_set1.Size == 0)
                          {
                            _BasePlacementFamilyInstance = familyInstance;
                            _BaseTopographySurfaceContainer = new TopographySurfaceContainer(_Document.Application, _TopographySurface, true);
                          }
                          elm_set1.Insert((Element) familyInstance);
                          flag4 = true;
                        }
                        else if (!flag3 && Convert.ToBoolean(parameter1.AsInteger()) && parameter3.AsString().ToLower().Contains(EPShared.LocalRM.GetString("ProposedToposurfaceString").ToLower()))
                        {
                          if (elm_set2.Size == 0)
                          {
                            _ProposedPlacementFamilyInstance = familyInstance;
                            _ProposedTopographySurfaceContainer = new TopographySurfaceContainer(_Document.Application, _TopographySurface, true);
                          }
                          elm_set2.Insert((Element) familyInstance);
                          flag4 = true;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          if (!flag1 && !flag4)
          {
            TopographySurfaceType topographySurfaceType = TopographySurfaceContainer.FindTopographySurfaceType(_Document.Application, _TopographySurface);
            switch (topographySurfaceType)
            {
              case TopographySurfaceType.Subregion:
              case TopographySurfaceType.BuildingPad:
                _SubRegionBuildingPadList.Add(new TopographySurfaceContainer(_Document.Application, _TopographySurface, true, topographySurfaceType));
                continue;
              default:
                continue;
            }
          }
          else
          {
            flag1 = false;
            flag4 = false;
          }
        }
      }
    }
    foreach (Element element in (IEnumerable<Element>) elements2)
    {
      if (element is CeilingAndFloor _BuildingPad)
        _SubRegionBuildingPadList.Add(new TopographySurfaceContainer(_Document.Application, _BuildingPad, true));
    }
    if (!flag2 || !flag3)
    {
      if (elm_set1.Size > 0)
      {
        if (elm_set1.Size == 1)
        {
          if (_BasePlacementFamilyInstance != null && _BaseTopographySurfaceContainer != null)
          {
            Parameter parameter = ((Element) _BasePlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
            if (parameter != null && !((APIObject) parameter).IsReadOnly)
            {
              parameter.Set(((Element) _BaseTopographySurfaceContainer.TopographySurface).UniqueId);
              flag5 = true;
            }
          }
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BaseSurfaceLinkBrokenMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          SetBaseToposurface setBaseToposurface = new SetBaseToposurface(_Document, true);
          if (setBaseToposurface.Run())
          {
            foreach (Element instance in setBaseToposurface.InstanceSet)
            {
              if (instance is TopographySurface topographySurface)
              {
                _BaseTopographySurfaceContainer = new TopographySurfaceContainer(_Document.Application, topographySurface, true);
                if (_BasePlacementFamilyInstance != null && _BasePlacementFamilyInstance.Symbol != null)
                {
                  _BasePlacementFamilyInstance = RevitUtility.NewFamilyInstance(_Document, new XYZ(0.0, 0.0, 0.0), _BasePlacementFamilyInstance.Symbol, (Element) topographySurface, _Document.ActiveView.GenLevel, (StructuralType) 0, ref _TransactionContainer1);
                  Parameter parameter4 = ((Element) _BasePlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
                  if (parameter4 != null && !((APIObject) parameter4).IsReadOnly)
                    parameter4.Set(((Element) topographySurface).UniqueId);
                  Parameter parameter5 = ((Element) _BasePlacementFamilyInstance).LookupParameter(RevitParameters.IsProposedSurfaceFamilyParameter);
                  if (parameter5 != null && !((APIObject) parameter5).IsReadOnly)
                    parameter5.Set(Convert.ToInt32(false));
                  if (elm_set1.Size > 0)
                  {
                    _TransactionContainer1.BeginTransaction();
                    _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set1));
                    _TransactionContainer1.EndTransaction();
                  }
                  flag5 = true;
                }
              }
            }
          }
        }
        elm_set1.Clear();
      }
      else if (elm_set2.Size > 0)
      {
        if (elm_set2.Size == 1)
        {
          if (_ProposedPlacementFamilyInstance != null && _ProposedTopographySurfaceContainer != null)
          {
            Parameter parameter = ((Element) _ProposedPlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
            if (parameter != null && !((APIObject) parameter).IsReadOnly)
            {
              parameter.Set(((Element) _ProposedTopographySurfaceContainer.TopographySurface).UniqueId);
              flag6 = true;
            }
          }
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ProposedSurfaceLinkBrokenMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          SetBaseToposurface setBaseToposurface = new SetBaseToposurface(_Document, true);
          if (setBaseToposurface.Run())
          {
            foreach (Element instance in setBaseToposurface.InstanceSet)
            {
              if (instance is TopographySurface topographySurface)
              {
                _ProposedTopographySurfaceContainer = new TopographySurfaceContainer(_Document.Application, topographySurface, true);
                if (_ProposedPlacementFamilyInstance != null && _ProposedPlacementFamilyInstance.Symbol != null)
                {
                  _ProposedPlacementFamilyInstance = RevitUtility.NewFamilyInstance(_Document, new XYZ(0.0, 0.0, 0.0), _ProposedPlacementFamilyInstance.Symbol, (Element) topographySurface, _Document.ActiveView.GenLevel, (StructuralType) 0, ref _TransactionContainer1);
                  Parameter parameter6 = ((Element) _ProposedPlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
                  if (parameter6 != null && !((APIObject) parameter6).IsReadOnly)
                    parameter6.Set(((Element) topographySurface).UniqueId);
                  Parameter parameter7 = ((Element) _ProposedPlacementFamilyInstance).LookupParameter(RevitParameters.IsProposedSurfaceFamilyParameter);
                  if (parameter7 != null && !((APIObject) parameter7).IsReadOnly)
                    parameter7.Set(Convert.ToInt32(true));
                  if (elm_set2.Size > 0)
                  {
                    _TransactionContainer1.BeginTransaction();
                    _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set2));
                    _TransactionContainer1.EndTransaction();
                  }
                  flag6 = true;
                }
              }
            }
          }
        }
        elm_set2.Clear();
      }
    }
    if (_TransactionContainer != null)
      return;
    bool _bAddBuildingPadsIfPresent = false;
    bool _bIssueBuildingPadWarning = true;
    if (_BasePlacementFamilyInstance != null && _BaseTopographySurfaceContainer != null)
    {
      _bAddBuildingPadsIfPresent = TopographySurfaceManagement.AddSubRegionBuildingPadsToMainSurface(_Document, _SubRegionBuildingPadList, ref _BaseTopographySurfaceContainer, false, ref _bIssueBuildingPadWarning);
      if (_bAddBuildingPadsIfPresent)
      {
        _TransactionContainer1.SetName(EPShared.LocalRM.GetString("AddBuildingPadsToSurfaceTransaction"));
        List<TopographySurfaceContainer> subregionBuildingPadList = _BaseTopographySurfaceContainer.SubregionBuildingPadList;
        TopographySurfaceManagement.RefreshSurface(_Document, _TransactionContainer1, ref _BaseTopographySurfaceContainer, ref _BasePlacementFamilyInstance);
        for (int index = subregionBuildingPadList.Count - 1; index >= 0; --index)
        {
          if (subregionBuildingPadList[index].TopographySurfaceType == TopographySurfaceType.BuildingPad)
          {
            if (subregionBuildingPadList[index].TopographySurface != null)
            {
              try
              {
                string uniqueId = ((Element) subregionBuildingPadList[index].TopographySurface).UniqueId;
                _Document.Delete(((Element) subregionBuildingPadList[index].TopographySurface).Id);
              }
              catch (InvalidObjectException ex)
              {
              }
            }
          }
        }
      }
    }
    bool flag7 = false;
    if (_ProposedPlacementFamilyInstance != null && _ProposedTopographySurfaceContainer != null)
    {
      flag7 = TopographySurfaceManagement.AddSubRegionBuildingPadsToMainSurface(_Document, _SubRegionBuildingPadList, ref _ProposedTopographySurfaceContainer, _bAddBuildingPadsIfPresent, ref _bIssueBuildingPadWarning);
      if (flag7)
      {
        _TransactionContainer1.SetName(EPShared.LocalRM.GetString("AddBuildingPadsToSurfaceTransaction"));
        ElementSet _ElementSet = new ElementSet();
        List<Element> _CurveElementList = new List<Element>();
        FamilySymbol componentPlacementSymbol = TopographySurfaceManagement.GetSiteComponentPlacementSymbol(_Document, _TransactionContainer1);
        FamilySymbol siteComponentSymbol = TopographySurfaceManagement.GetSiteComponentSymbol(_Document, _TransactionContainer1, LandcaddID.SoftTerrain, "Building Pads", "no slope", "Building Pads.rfa");
        for (int index = _ProposedTopographySurfaceContainer.SubregionBuildingPadList.Count - 1; index >= 0; --index)
        {
          if (_ProposedTopographySurfaceContainer.SubregionBuildingPadList[index].TopographySurfaceType == TopographySurfaceType.BuildingPad && _ProposedTopographySurfaceContainer.SubregionBuildingPadList[index].TopographySurface != null)
          {
            if (componentPlacementSymbol != null)
            {
              _TransactionContainer1.BeginTransaction();
              foreach (ModelCurve newModelCurve in RevitUtility.NewModelCurveArray(_Document, _ProposedTopographySurfaceContainer.SubregionBuildingPadList[index].BuildingPadLeg))
              {
                _ElementSet.Insert((Element) newModelCurve);
                _CurveElementList.Add((Element) newModelCurve);
              }
              if (_ElementSet.Size > 0)
              {
                RevitUtility.HideElementsInAllViews(_Document, _ElementSet);
                _ElementSet.Clear();
              }
              _TransactionContainer1.EndTransaction();
              int _nTopoDrawOrder = TopographySurfaceManagement.GetMaxExistingTopoDrawOrder(_Document) + 1;
              RevitUtility.CreatePlacementSiteComponent(_Document, new SitePlacementSettings(LandcaddID.SoftTerrain, _Document.ActiveView.GenLevel, siteComponentSymbol, componentPlacementSymbol, EPShared.LocalRM.GetString("BuildingPadString"), _nTopoDrawOrder, _TransactionContainer1)
              {
                ProjectInnerSlopes = 1
              }, _CurveElementList);
              _CurveElementList.Clear();
            }
            try
            {
              string uniqueId = ((Element) _ProposedTopographySurfaceContainer.SubregionBuildingPadList[index].TopographySurface).UniqueId;
              _Document.Delete(((Element) _ProposedTopographySurfaceContainer.SubregionBuildingPadList[index].TopographySurface).Id);
            }
            catch (InvalidObjectException ex)
            {
            }
          }
        }
        TopographySurfaceManagement.RefreshSurface(_Document, _TransactionContainer1, ref _ProposedTopographySurfaceContainer, ref _ProposedPlacementFamilyInstance);
      }
    }
    if (_bAddBuildingPadsIfPresent || flag7 || flag5 || flag6)
      _TransactionContainer1.Commit();
    else
      _TransactionContainer1.Rollback();
  }

  private static FamilySymbol GetSiteComponentSymbol(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    LandcaddID _LandcaddID,
    string _strFamilyName,
    string _strFamilySymbolName,
    string _strSampleFileName)
  {
    Parameter CurSiteworksID = (Parameter) null;
    FamilySymbol familySymbol = (FamilySymbol) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurSiteworksID = CurrentElement.LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(CurSiteworksID.AsString(), Convert.ToInt32((object) _LandcaddID).ToString("000"), true) == 0)).ToList<Element>();
    familySymbol = (FamilySymbol) null;
    foreach (Element element in list)
    {
      if (element is FamilySymbol siteComponentSymbol && ((Element) siteComponentSymbol).Category != null)
      {
        CurSiteworksID = ((Element) siteComponentSymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (CurSiteworksID != null && string.Compare(CurSiteworksID.AsString(), Convert.ToInt32((object) _LandcaddID).ToString("000"), true) == 0 && string.Compare(((Element) siteComponentSymbol.Family).Name, _strFamilyName, true) == 0 && string.Compare(((Element) siteComponentSymbol).Name, _strFamilySymbolName, true) == 0)
          return siteComponentSymbol;
      }
    }
    string empty = string.Empty;
    if (RevitUtility.GetFullFamilyFilenameIfExist(_strSampleFileName, ref empty))
    {
      Family _Family = (Family) null;
      int num1 = empty.LastIndexOf("\\");
      int num2 = empty.LastIndexOf(".");
      empty.Substring(num1 + 1, num2 - num1 - 1);
      _TransactionContainer.BeginTransaction();
      _TransactionContainer.BeginTransaction();
      RevitUtility.LoadFamily(_Document, empty, out _Family, true, ref _TransactionContainer);
      _TransactionContainer.EndTransaction();
      if (_Family != null && _Family.GetFamilySymbolIds() != null)
      {
        foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
        {
          if (_Document.GetElement(familySymbolId) is FamilySymbol element)
          {
            Parameter parameter = ((Element) element).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
            if (parameter != null && string.Compare(parameter.AsString(), Convert.ToInt32((object) _LandcaddID).ToString("000"), true) == 0 && string.Compare(((Element) element.Family).Name, _strFamilyName, true) == 0 && string.Compare(((Element) element).Name, _strFamilySymbolName, true) == 0)
              return element;
          }
        }
      }
    }
    return (FamilySymbol) null;
  }

  private static FamilySymbol GetSiteComponentPlacementSymbol(
    Document _Document,
    EPTransactionContainer _TransactionContainer)
  {
    Parameter CurSiteworksID = (Parameter) null;
    FamilySymbol familySymbol1 = (FamilySymbol) null;
    FamilySymbol componentPlacementSymbol = (FamilySymbol) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260);
    CurSiteworksID = (Parameter) null;
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurSiteworksID = CurrentElement.LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(CurSiteworksID.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)).ToList<Element>();
    bool flag = false;
    familySymbol1 = (FamilySymbol) null;
    foreach (Element element in list)
    {
      if (element is FamilySymbol familySymbol2 && ((Element) familySymbol2).Category != null)
      {
        CurSiteworksID = ((Element) familySymbol2).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (CurSiteworksID != null && string.Compare(CurSiteworksID.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
        {
          componentPlacementSymbol = familySymbol2;
          flag = true;
          break;
        }
      }
    }
    string empty = string.Empty;
    Family _Family = (Family) null;
    if (!flag && RevitUtility.GetFullFamilyFilenameIfExist("Site Component Placement.rfa", ref empty))
    {
      _TransactionContainer.BeginTransaction();
      RevitUtility.LoadFamily(_Document, empty, out _Family, true, ref _TransactionContainer);
      _TransactionContainer.EndTransaction();
      if (_Family != null && _Family.GetFamilySymbolIds() != null)
      {
        using (IEnumerator<ElementId> enumerator = _Family.GetFamilySymbolIds().GetEnumerator())
        {
          if (enumerator.MoveNext())
          {
            ElementId current = enumerator.Current;
            if (_Document.GetElement(current) is FamilySymbol element)
              componentPlacementSymbol = element;
          }
        }
      }
    }
    return componentPlacementSymbol;
  }

  private static int GetMaxExistingTopoDrawOrder(Document _Document)
  {
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    Parameter LocateTypeParameter = (Parameter) null;
    int existingTopoDrawOrder = -1;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && (LocateTypeParameter = ((Element) FindFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter)) != null && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051).ToElements();
    foreach (Element element1 in list)
    {
      if (element1 is FamilyInstance familyInstance && ((Element) familyInstance).Category != null)
      {
        int integerValue1 = ((Element) familyInstance).Category.Id.IntegerValue;
        BuiltInCategory builtInCategory = (BuiltInCategory) -2001260;
        int hashCode1 = builtInCategory.GetHashCode();
        if (integerValue1 == hashCode1)
        {
          SiteworksIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
          if (SiteworksIDParameter != null)
          {
            LocateTypeParameter = ((Element) familyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (LocateTypeParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
            {
              Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
              if (parameter1 != null)
              {
                Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
                if (parameter2 != null && parameter2.AsString() != string.Empty)
                {
                  for (int index = 0; index < elements.Count; ++index)
                  {
                    Element element2 = elements[index];
                    if (element2 != null && element2.Category != null)
                    {
                      int integerValue2 = element2.Category.Id.IntegerValue;
                      builtInCategory = (BuiltInCategory) -2000051;
                      int hashCode2 = builtInCategory.GetHashCode();
                      if (integerValue2 == hashCode2 && string.Compare(parameter1.AsString(), element2.UniqueId, true) == 0)
                      {
                        Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
                        if (parameter3 != null && existingTopoDrawOrder < parameter3.AsInteger())
                          existingTopoDrawOrder = parameter3.AsInteger();
                        elements.RemoveAt(index);
                        break;
                      }
                    }
                  }
                  if (elements.Count == 0)
                    break;
                }
              }
            }
          }
        }
      }
    }
    return existingTopoDrawOrder;
  }

  public static TopographySurface FindTopoSurfaceInstance(
    Document _Document,
    string _strFormUniqueId)
  {
    TopographySurface topographySurface = (TopographySurface) null;
    List<Element> list = ((IEnumerable<Element>) new FilteredElementCollector(_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340)).ToList<Element>();
    topographySurface = (TopographySurface) null;
    foreach (Element element in list)
    {
      if (element is TopographySurface topoSurfaceInstance && ((Element) topoSurfaceInstance).Category != null && string.Compare(_strFormUniqueId, ((Element) topoSurfaceInstance).UniqueId, true) == 0)
        return topoSurfaceInstance;
    }
    return (TopographySurface) null;
  }

  public static bool AddSubRegionBuildingPadsToMainSurface(
    Document _Document,
    List<TopographySurfaceContainer> _SubRegionBuildingPadList,
    ref TopographySurfaceContainer _SurfaceContainer,
    bool _bAddBuildingPadsIfPresent,
    ref bool _bIssueBuildingPadWarning)
  {
    return TopographySurfaceManagement.AddSubRegionBuildingPadsToMainSurfaceList(_Document, _SubRegionBuildingPadList, ref new List<TopographySurfaceContainer>()
    {
      _SurfaceContainer
    }, _bAddBuildingPadsIfPresent, ref _bIssueBuildingPadWarning);
  }

  public static bool AddSubRegionBuildingPadsToMainSurfaceList(
    Document _Document,
    List<TopographySurfaceContainer> _SubRegionBuildingPadList,
    ref List<TopographySurfaceContainer> _SurfaceList)
  {
    bool _bIssueBuildingPadWarning = false;
    return TopographySurfaceManagement.AddSubRegionBuildingPadsToMainSurfaceList(_Document, _SubRegionBuildingPadList, ref _SurfaceList, true, ref _bIssueBuildingPadWarning);
  }

  public static bool AddSubRegionBuildingPadsToMainSurfaceList(
    Document _Document,
    List<TopographySurfaceContainer> _SubRegionBuildingPadList,
    ref List<TopographySurfaceContainer> _SurfaceList,
    bool _bAddBuildingPadsIfPresent,
    ref bool _bIssueBuildingPadWarning)
  {
    bool mainSurfaceList = _bAddBuildingPadsIfPresent;
    if (_SurfaceList != null && _SurfaceList.Count > 0 && _SubRegionBuildingPadList != null && _SubRegionBuildingPadList.Count > 0)
    {
      List<TopographySurfaceContainer> surfaceContainerList1 = (List<TopographySurfaceContainer>) null;
      ElementId elementId1 = (ElementId) null;
      ElementId elementId2 = (ElementId) null;
      List<TopographySurfaceContainer> surfaceContainerList2 = new List<TopographySurfaceContainer>();
      surfaceContainerList2.AddRange((IEnumerable<TopographySurfaceContainer>) _SubRegionBuildingPadList);
      for (int index1 = 0; index1 < surfaceContainerList2.Count; ++index1)
      {
        if (surfaceContainerList2[index1].TopographySurface != null)
        {
          elementId1 = ((Element) surfaceContainerList2[index1].TopographySurface).CreatedPhaseId;
          elementId2 = ((Element) surfaceContainerList2[index1].TopographySurface).DemolishedPhaseId;
        }
        else if (surfaceContainerList2[index1].BuildingPad != null)
        {
          elementId1 = ((Element) surfaceContainerList2[index1].BuildingPad).CreatedPhaseId;
          elementId2 = ((Element) surfaceContainerList2[index1].BuildingPad).DemolishedPhaseId;
        }
        for (int index2 = 0; index2 < surfaceContainerList2[index1].Vertices.Count; ++index2)
        {
          surfaceContainerList1 = TopographySurfaceManagement.GetSurfaceContainerListContainingPoint(surfaceContainerList2[index1].Vertices[index2], _SurfaceList);
          if (surfaceContainerList1 != null && surfaceContainerList1.Count > 0)
          {
            for (int index3 = 0; index3 < surfaceContainerList1.Count; ++index3)
            {
              if ((ElementId.op_Equality(elementId1, (ElementId) null) || surfaceContainerList1[index3].TopographySurface != null && ElementId.op_Inequality(((Element) surfaceContainerList1[index3].TopographySurface).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) surfaceContainerList1[index3].TopographySurface).CreatedPhaseId, elementId1) || surfaceContainerList1[index3].BuildingPad != null && ElementId.op_Inequality(((Element) surfaceContainerList1[index3].BuildingPad).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) surfaceContainerList1[index3].BuildingPad).CreatedPhaseId, elementId1)) && (ElementId.op_Equality(elementId2, (ElementId) null) || surfaceContainerList1[index3].TopographySurface != null && ElementId.op_Inequality(((Element) surfaceContainerList1[index3].TopographySurface).DemolishedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) surfaceContainerList1[index3].TopographySurface).DemolishedPhaseId, elementId2) || surfaceContainerList1[index3].BuildingPad != null && ElementId.op_Inequality(((Element) surfaceContainerList1[index3].BuildingPad).DemolishedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) surfaceContainerList1[index3].BuildingPad).DemolishedPhaseId, elementId2)))
                surfaceContainerList1[index3].SubregionBuildingPadList.Add(surfaceContainerList2[index1]);
              else if (surfaceContainerList2[index1].TopographySurfaceType == TopographySurfaceType.BuildingPad)
              {
                surfaceContainerList1[index3].BuildingPadPresentInDiffentPhase = true;
                surfaceContainerList1[index3].BuildingPadPresentInDifferentPhaseList.Add(surfaceContainerList2[index1]);
              }
            }
            surfaceContainerList2.RemoveAt(index1);
            --index1;
            break;
          }
        }
      }
      if (!_bIssueBuildingPadWarning)
      {
        bool flag = false;
        for (int index4 = 0; index4 < surfaceContainerList1.Count; ++index4)
        {
          if (surfaceContainerList1[index4].BuildingPadPresentInDiffentPhase)
          {
            List<TopographySurfaceContainer> differentPhaseList = surfaceContainerList1[index4].BuildingPadPresentInDifferentPhaseList;
            for (int index5 = 0; index5 < differentPhaseList.Count; ++index5)
            {
              for (int index6 = 0; index6 < differentPhaseList[index5].Vertices.Count; ++index6)
              {
                Eps_Point vertex = differentPhaseList[index5].Vertices[index6];
                for (int index7 = surfaceContainerList1[index4].SubregionBuildingPadList.Count - 1; index7 >= 0; --index7)
                {
                  if (surfaceContainerList1[index4].SubregionBuildingPadList[index7].TopographySurfaceType == TopographySurfaceType.BuildingPad && surfaceContainerList1[index4].SubregionBuildingPadList[index7].GetSurfaceContainerContainingPoint(vertex) != null)
                  {
                    surfaceContainerList1[index4].SubregionBuildingPadList.RemoveAt(index7);
                    flag = true;
                    break;
                  }
                }
                if (flag)
                {
                  flag = false;
                  break;
                }
              }
            }
            differentPhaseList.Clear();
          }
        }
      }
    }
    return mainSurfaceList;
  }

  public static TopographySurfaceContainer GetSurfaceContainerContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList)
  {
    return TopographySurfaceManagement.GetSurfaceContainerContainingPoint(_FindPoint, _SurfaceList, (Phase) null, (Phase) null);
  }

  public static TopographySurfaceContainer GetSurfaceContainerContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _PhaseCreated)
  {
    return TopographySurfaceManagement.GetSurfaceContainerContainingPoint(_FindPoint, _SurfaceList, _PhaseCreated, (Phase) null);
  }

  public static TopographySurfaceContainer GetSurfaceContainerContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _PhaseCreated,
    Phase _PhaseDemolished)
  {
    if (_SurfaceList != null && _SurfaceList.Count > 0)
    {
      for (int index = 0; index < _SurfaceList.Count; ++index)
      {
        TopographySurfaceContainer containerContainingPoint = _SurfaceList[index].GetSurfaceContainerContainingPoint(_FindPoint, _PhaseCreated, _PhaseDemolished);
        if (containerContainingPoint != null)
          return containerContainingPoint;
      }
    }
    return (TopographySurfaceContainer) null;
  }

  public static List<Eps_Point> GetSurfacePoints(List<TopographySurfaceContainer> _SurfaceList)
  {
    List<Eps_Point> surfacePoints = new List<Eps_Point>();
    if (_SurfaceList != null && _SurfaceList.Count > 0)
    {
      List<Eps_Point> source = new List<Eps_Point>();
      for (int index = 0; index < _SurfaceList.Count; ++index)
        source.AddRange((IEnumerable<Eps_Point>) _SurfaceList[index].Vertices);
      surfacePoints = source.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
    }
    return surfacePoints;
  }

  public static List<Eps_Point> GetAllDistinctSurfacePoints(
    List<TopographySurfaceContainer> _SurfaceList)
  {
    return TopographySurfaceManagement.GetAllDistinctSurfacePoints(_SurfaceList, (Phase) null);
  }

  public static List<Eps_Point> GetAllDistinctSurfacePoints(
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase)
  {
    List<Eps_Point> distinctSurfacePoints = new List<Eps_Point>();
    if (_SurfaceList != null && _SurfaceList.Count > 0)
    {
      List<Eps_Point> source = new List<Eps_Point>();
      for (int index = 0; index < _SurfaceList.Count; ++index)
      {
        if (_CurPhase == null || _SurfaceList[index].TopographySurface != null && ElementId.op_Inequality(((Element) _SurfaceList[index].TopographySurface).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) _SurfaceList[index].TopographySurface).CreatedPhaseId, ((Element) _CurPhase).Id) || _SurfaceList[index].BuildingPad != null && ElementId.op_Inequality(((Element) _SurfaceList[index].BuildingPad).CreatedPhaseId, (ElementId) null) && ElementId.op_Equality(((Element) _SurfaceList[index].BuildingPad).CreatedPhaseId, ((Element) _CurPhase).Id))
          source.AddRange((IEnumerable<Eps_Point>) _SurfaceList[index].GetAllVertices());
      }
      distinctSurfacePoints = source.Distinct<Eps_Point>((IEqualityComparer<Eps_Point>) new PointEqualityComparer()).ToList<Eps_Point>();
    }
    return distinctSurfacePoints;
  }

  public static List<TopographySurfaceContainer> GetSurfaceContainerListContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList)
  {
    return TopographySurfaceManagement.GetSurfaceContainerListContainingPoint(_FindPoint, _SurfaceList, (Phase) null, (Phase) null);
  }

  public static List<TopographySurfaceContainer> GetSurfaceContainerListContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _PhaseCreated)
  {
    return TopographySurfaceManagement.GetSurfaceContainerListContainingPoint(_FindPoint, _SurfaceList, _PhaseCreated, (Phase) null);
  }

  public static List<TopographySurfaceContainer> GetSurfaceContainerListContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _PhaseCreated,
    Phase _PhaseDemolished)
  {
    List<TopographySurfaceContainer> listContainingPoint = (List<TopographySurfaceContainer>) null;
    if (_SurfaceList != null && _SurfaceList.Count > 0)
    {
      for (int index = 0; index < _SurfaceList.Count; ++index)
      {
        TopographySurfaceContainer containerContainingPoint = _SurfaceList[index].GetSurfaceContainerContainingPoint(_FindPoint, _PhaseCreated, _PhaseDemolished);
        if (containerContainingPoint != null)
        {
          if (listContainingPoint == null)
            listContainingPoint = new List<TopographySurfaceContainer>();
          listContainingPoint.Add(containerContainingPoint);
        }
      }
    }
    return listContainingPoint;
  }

  public static void GetIntersections(
    Document _Document,
    string _strPlacementId,
    ref List<FamilyInstance> _SiteFamilyInstanceList,
    ref List<IntersectionStationContainer> _LeftIntersectionStations,
    ref List<IntersectionStationContainer> _RightIntersectionStations)
  {
    TopographySurfaceManagement.GetIntersections(_Document, _strPlacementId, false, ref _SiteFamilyInstanceList, ref _LeftIntersectionStations, ref _RightIntersectionStations);
  }

  public static void GetIntersections(
    Document _Document,
    string _strPlacementId,
    bool _bOnlyFindSecondaryFamilies,
    ref List<FamilyInstance> _SiteFamilyInstanceList,
    ref List<IntersectionStationContainer> _LeftIntersectionStations,
    ref List<IntersectionStationContainer> _RightIntersectionStations)
  {
    FindFamilyInstance2 = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    Parameter PrimaryIdParameter = (Parameter) null;
    Parameter SecondaryIdParameter = (Parameter) null;
    _LeftIntersectionStations = new List<IntersectionStationContainer>();
    _RightIntersectionStations = new List<IntersectionStationContainer>();
    _SiteFamilyInstanceList = new List<FamilyInstance>();
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    foreach (Element element in ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement =>
    {
      if (!(CurrentElement is FamilyInstance FindFamilyInstance2) || (SiteworksIDParameter = ((Element) FindFamilyInstance2.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) == null || string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.IntersectionPlacement).ToString("000"), true) != 0 || (PrimaryIdParameter = ((Element) FindFamilyInstance2).LookupParameter(RevitParameters.PrimaryPlacementIDParameter)) == null || (SecondaryIdParameter = ((Element) FindFamilyInstance2).LookupParameter(RevitParameters.SecondaryPlacementIDParameter)) == null)
        return false;
      return string.Compare(PrimaryIdParameter.AsString(), _strPlacementId, true) == 0 && !_bOnlyFindSecondaryFamilies || string.Compare(SecondaryIdParameter.AsString(), _strPlacementId, true) == 0;
    })).ToList<Element>())
    {
      if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
      {
        SiteworksIDParameter = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (SiteworksIDParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.IntersectionPlacement).ToString("000"), true) == 0)
        {
          PrimaryIdParameter = ((Element) familyInstance).LookupParameter(RevitParameters.PrimaryPlacementIDParameter);
          if (PrimaryIdParameter != null && (!_bOnlyFindSecondaryFamilies || string.Compare(PrimaryIdParameter.AsString(), _strPlacementId, true) != 0))
          {
            SecondaryIdParameter = ((Element) familyInstance).LookupParameter(RevitParameters.SecondaryPlacementIDParameter);
            if (SecondaryIdParameter != null)
            {
              _SiteFamilyInstanceList.Add(familyInstance);
              IntersectionStation intersectionStation = new IntersectionStation();
              Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.IsStartingParameter);
              if (parameter1 != null)
                intersectionStation.StartingIntersection = Convert.ToBoolean(parameter1.AsInteger());
              Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.RadiusParameter);
              if (parameter2 != null)
                intersectionStation.Radius = parameter2.AsDouble();
              Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.SecondaryStationParameter);
              if (parameter3 != null)
                intersectionStation.Station = parameter3.AsDouble();
              Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.PrimaryStationParameter);
              if (parameter4 != null)
                intersectionStation.PrimaryStation = parameter4.AsDouble();
              Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.IsSecondaryLeftParameter);
              if (parameter5 != null)
                intersectionStation.IsLeft = Convert.ToBoolean(parameter5.AsInteger());
              Parameter parameter6 = ((Element) familyInstance).LookupParameter(RevitParameters.IsPrimaryLeftParameter);
              if (parameter6 != null)
                intersectionStation.IsPrimaryLeft = Convert.ToBoolean(parameter6.AsInteger());
              Parameter parameter7 = ((Element) familyInstance).LookupParameter(RevitParameters.TransitioningDistanceParameter);
              if (parameter7 != null)
                intersectionStation.TransitioningDistance = parameter7.AsDouble();
              if (intersectionStation.IsLeft)
              {
                int index;
                for (index = 0; index < _LeftIntersectionStations.Count; ++index)
                {
                  if (string.Compare(PrimaryIdParameter.AsString(), _LeftIntersectionStations[index].PrimaryPlacementId, true) == 0 && string.Compare(SecondaryIdParameter.AsString(), _LeftIntersectionStations[index].SecondaryPlacementId, true) == 0)
                  {
                    _LeftIntersectionStations[index].IntersectionStations.Add(intersectionStation);
                    break;
                  }
                }
                if (index == _LeftIntersectionStations.Count)
                  _LeftIntersectionStations.Add(new IntersectionStationContainer()
                  {
                    PrimaryPlacementId = PrimaryIdParameter.AsString(),
                    SecondaryPlacementId = SecondaryIdParameter.AsString(),
                    IntersectionStations = {
                      intersectionStation
                    }
                  });
              }
              else
              {
                int index;
                for (index = 0; index < _RightIntersectionStations.Count; ++index)
                {
                  if (string.Compare(PrimaryIdParameter.AsString(), _RightIntersectionStations[index].PrimaryPlacementId, true) == 0 && string.Compare(SecondaryIdParameter.AsString(), _RightIntersectionStations[index].SecondaryPlacementId, true) == 0)
                  {
                    _RightIntersectionStations[index].IntersectionStations.Add(intersectionStation);
                    break;
                  }
                }
                if (index == _RightIntersectionStations.Count)
                  _RightIntersectionStations.Add(new IntersectionStationContainer()
                  {
                    PrimaryPlacementId = PrimaryIdParameter.AsString(),
                    SecondaryPlacementId = SecondaryIdParameter.AsString(),
                    IntersectionStations = {
                      intersectionStation
                    }
                  });
              }
            }
          }
        }
      }
    }
    IntersectionStationContainerComparer containerComparer = new IntersectionStationContainerComparer(true);
    if (_LeftIntersectionStations != null && _LeftIntersectionStations.Count > 0)
      _LeftIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer);
    if (_RightIntersectionStations == null || _RightIntersectionStations.Count <= 0)
      return;
    _RightIntersectionStations.Sort((IComparer<IntersectionStationContainer>) containerComparer);
  }

  public static void InvokeUpdaters(
    string strOldSurfaceId,
    string strNewSurfaceId,
    Document _Document)
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    ApplicationUtility.RegistryPaths.GetProgramPath(string.Empty, ref empty1);
    if (string.IsNullOrEmpty(empty1))
      return;
    foreach (FileSystemInfo file in new DirectoryInfo(empty1).GetFiles("*.dll"))
      file.Name.Contains("LANDCADDWrapper");
    if (!(empty2 != string.Empty))
      return;
    foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
    {
      if (empty2.Contains(assembly.GetName().Name))
      {
        MethodInfo method = assembly.GetType("LANDCADD.ExternalApplication").GetMethod("UpdateGenericModelElementList");
        if (method != (MethodInfo) null)
          method.Invoke(assembly.CreateInstance("LANDCADD.ExternalApplication"), new object[3]
          {
            (object) strOldSurfaceId,
            (object) strNewSurfaceId,
            (object) _Document
          });
      }
    }
  }

  private static bool RefreshAllSiteComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    List<FamilyInstanceComponentWrapper> _AllSiteComponentList,
    TopographySurfaceContainer _BaseSurface,
    TopographySurfaceContainer _ProposedSurface,
    FamilyInstance _TopoPlacementFamilyInstance)
  {
    double _dReturnValue = 0.0;
    bool flag = false;
    string empty = string.Empty;
    Eps_Leg _CurrentLeg = (Eps_Leg) null;
    if (_AllSiteComponentList != null)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("TopographySurfaceArcPointInterval", ref _dReturnValue))
      {
        _dReturnValue = 1.0;
        ApplicationUtility.Settings.eplSetE_SetSetting("TopographySurfaceArcPointInterval", _dReturnValue);
      }
      SitePlacementSettings _PlacementSettings = new SitePlacementSettings();
      FamilyInstanceComponentWrapperComparer componentWrapperComparer = new FamilyInstanceComponentWrapperComparer();
      if (_AllSiteComponentList.Count > 0)
        _AllSiteComponentList.Sort((IComparer<FamilyInstanceComponentWrapper>) componentWrapperComparer);
      List<Eps_Point> epsPointList = new List<Eps_Point>();
      List<Eps_Point> _CrownPointList = new List<Eps_Point>();
      TopographySurfaceManagement.SetupAllIntersectionStationsForAllSiteComponents(_Document, _ProposedSurface, _TransactionContainer, string.Empty, ref _AllSiteComponentList);
      List<Eps_Point> allVertices = _BaseSurface.GetAllVertices();
      for (int index = 0; index < _AllSiteComponentList.Count; ++index)
      {
        ElementSet instanceElementSet = _AllSiteComponentList[index].GetFamilyInstanceElementSet();
        if (instanceElementSet != null && instanceElementSet.Size != 0)
        {
          FamilyInstance existingFamilyInstance = _AllSiteComponentList[index].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance != null && existingFamilyInstance.Symbol != null)
          {
            _PlacementSettings.PlacementSymbol = existingFamilyInstance.Symbol;
            Parameter parameter1 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.ProjectInnerSlopesFamilyParameter);
            if (parameter1 != null)
              _PlacementSettings.ProjectInnerSlopes = parameter1.AsInteger();
            Parameter parameter2 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
            if (parameter2 != null)
              _PlacementSettings.Name = parameter2.AsString();
            Parameter parameter3 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (parameter3 != null)
            {
              foreach (int num in Enum.GetValues(typeof (LandcaddID)))
              {
                if (string.Compare(parameter3.AsString(), num.ToString("000"), true) == 0)
                {
                  _PlacementSettings.LocateType = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
                  break;
                }
              }
            }
            Parameter parameter4 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.ElevationFamilyParameter);
            if (parameter4 != null)
              _PlacementSettings.Elevation = parameter4.AsDouble();
            Parameter parameter5 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentIsRelativeElevationParameter);
            if (parameter5 != null)
            {
              _PlacementSettings.IsRelativeElevation = false;
              if (parameter5.AsInteger() == 1)
                _PlacementSettings.IsRelativeElevation = true;
            }
            _PlacementSettings.Type = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance, _PlacementSettings.LocateType);
            Parameter parameter6 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
            if (parameter6 != null && !((APIObject) parameter6).IsReadOnly)
              _PlacementSettings.UseRightSide = parameter6.AsInteger() == 1;
            Parameter parameter7 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LinearPointIntervalParameter);
            if (parameter7 != null)
              _PlacementSettings.LinearPointInterval = parameter7.AsDouble();
            foreach (Element element in instanceElementSet)
            {
              Parameter parameter8 = element.LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
              if (parameter8 != null)
                _PlacementSettings.LoftFormID = parameter8.AsString();
              Parameter parameter9 = element.LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
              if (parameter9 != null)
                _PlacementSettings.AdditionalLoftFormID = parameter9.AsString();
              Parameter parameter10 = element.LookupParameter(RevitParameters.IslandSurfaceIdFamilyParameter);
              if (parameter10 != null)
                _PlacementSettings.IslandSurfaceID = parameter10.AsString();
              Parameter parameter11 = element.LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
              if (parameter11 != null)
                _PlacementSettings.ParkingLotSurfaceID = parameter11.AsString();
              Parameter parameter12 = element.LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
              if (parameter12 != null)
                _PlacementSettings.ParentTopoSurfaceID = parameter12.AsString();
            }
            Parameter parameter13 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
            if (parameter13 != null)
              _PlacementSettings.TopoDrawOrder = parameter13.AsInteger();
          }
          _PlacementSettings.Level = _Document.ActiveView.GenLevel;
          _PlacementSettings.TransactionContainer = _TransactionContainer;
          List<Element> _ElementList = new List<Element>();
          bool _bDrawForm = false;
          if (_PlacementSettings.LocateType == LandcaddID.Curb && _PlacementSettings.ParentTopoSurfaceID != string.Empty && string.Compare(_PlacementSettings.ParentTopoSurfaceID, ((Element) _ProposedSurface.TopographySurface).UniqueId, true) != 0)
          {
            _PlacementSettings.LoftFormID = string.Empty;
            _PlacementSettings.IslandSurfaceID = string.Empty;
            _PlacementSettings.ParkingLotSurfaceID = string.Empty;
          }
          else
          {
            if (_AllSiteComponentList[index].OriginalLeg == null && _AllSiteComponentList[index].ProposedLeg == null)
              _AllSiteComponentList[index].CreateOriginalLeg(_ProposedSurface);
            if (_AllSiteComponentList[index].OriginalLeg != null || _AllSiteComponentList[index].ProposedLeg != null)
            {
              if (_AllSiteComponentList[index].ProposedFamilySymbol == null)
                _AllSiteComponentList[index].ProposedFamilySymbol = _PlacementSettings.Type;
              if (_AllSiteComponentList[index].ProposedLeg != null)
                _CurrentLeg = Eps_Leg.CopyLeg(_AllSiteComponentList[index].ProposedLeg);
              else if (_AllSiteComponentList[index].OriginalLeg != null)
                _CurrentLeg = Eps_Leg.CopyLeg(_AllSiteComponentList[index].OriginalLeg);
            }
            _PlacementSettings.IntersectionPlacementSymbol = _AllSiteComponentList[index].IntersectionFamilySymbol;
            List<IntersectionStationContainer> intersectionStations1 = _AllSiteComponentList[index].LeftIntersectionStations;
            List<IntersectionStationContainer> intersectionStations2 = _AllSiteComponentList[index].CenterIntersectionStations;
            List<IntersectionStationContainer> intersectionStations3 = _AllSiteComponentList[index].RightIntersectionStations;
            List<IntersectionContainer> intersectionContainerList = _AllSiteComponentList[index].IntersectionContainerList;
            if (_CurrentLeg != null && _CurrentLeg.LegCount > 0)
            {
              if (!TopographySurfaceManagement.RebuildProposedTopographySurface(_Document, _PlacementSettings, _dReturnValue, _CurrentLeg, _ProposedSurface, _ElementList, _bDrawForm, _AllSiteComponentList[index].ParkingLotBreaklineList, _AllSiteComponentList[index].ParkingLotBreaklineElementList, _AllSiteComponentList[index].ParkingLotBreaklineLinearPointIntervals, intersectionStations1, intersectionStations2, intersectionStations3, intersectionContainerList, ref allVertices, ref _CrownPointList))
                return false;
              _CurrentLeg = (Eps_Leg) null;
            }
            _PlacementSettings.LoftFormID = string.Empty;
            _PlacementSettings.IslandSurfaceID = string.Empty;
            _PlacementSettings.ParkingLotSurfaceID = string.Empty;
          }
        }
      }
      if (_CrownPointList != null && _CrownPointList.Count > 0)
        allVertices.AddRange((IEnumerable<Eps_Point>) _CrownPointList);
      ProgressBarForm progressBarForm = new ProgressBarForm();
      progressBarForm.ShowForm();
      progressBarForm.Refresh();
      progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarUpdatingModelMessage");
      progressBarForm.MinValue = 0;
      progressBarForm.MaxValue = 12;
      List<XYZ> PointXYZList = new List<XYZ>();
      for (int index = 0; index < allVertices.Count; ++index)
        PointXYZList.Add(allVertices[index].XYZ);
      progressBarForm.UpdateProgressBar(1);
      if (PointXYZList.Count > 0)
      {
        TopographySurfaceManagement.RemoveDuplicateXY(ref PointXYZList);
        TopographySurface _TopographySurface = TopographySurface.Create(_Document, (IList<XYZ>) PointXYZList);
        _Document.Regenerate();
        progressBarForm.UpdateProgressBar(7);
        Parameter parameter14 = ((Element) _ProposedSurface.TopographySurface)[(BuiltInParameter) -1002107];
        if (parameter14 != null && ElementId.op_Inequality(parameter14.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter14.AsElementId(), ElementId.InvalidElementId))
        {
          Parameter parameter15 = ((Element) _TopographySurface)[(BuiltInParameter) -1002107];
          if (parameter15 != null && !((APIObject) parameter15).IsReadOnly)
          {
            ElementId elementId = parameter14.AsElementId();
            parameter15.Set(elementId);
          }
        }
        Parameter parameter16 = ((Element) _ProposedSurface.TopographySurface)[(BuiltInParameter) -1012100];
        if (parameter16 != null && ElementId.op_Inequality(parameter16.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter16.AsElementId(), ElementId.InvalidElementId))
        {
          Parameter parameter17 = ((Element) _TopographySurface)[(BuiltInParameter) -1012100];
          if (parameter17 != null && !((APIObject) parameter17).IsReadOnly)
          {
            ElementId elementId = parameter16.AsElementId();
            parameter17.Set(elementId);
          }
        }
        Parameter parameter18 = ((Element) _ProposedSurface.TopographySurface)[(BuiltInParameter) -1012101];
        if (parameter18 != null && ElementId.op_Inequality(parameter18.AsElementId(), (ElementId) null) && ElementId.op_Inequality(parameter18.AsElementId(), ElementId.InvalidElementId))
        {
          Parameter parameter19 = ((Element) _TopographySurface)[(BuiltInParameter) -1012101];
          if (parameter19 != null && !((APIObject) parameter19).IsReadOnly)
          {
            ElementId elementId = parameter18.AsElementId();
            parameter19.Set(elementId);
          }
        }
        Parameter parameter20 = ((Element) _ProposedSurface.TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter20 != null && parameter20.AsString() != null && parameter20.AsString() != string.Empty)
        {
          Parameter parameter21 = ((Element) _TopographySurface)[(BuiltInParameter) -1006900];
          if (parameter21 != null && !((APIObject) parameter21).IsReadOnly)
            parameter21.Set(parameter20.AsString());
        }
        TopographySurfaceManagement.InvokeUpdaters(((Element) _ProposedSurface.TopographySurface).UniqueId, ((Element) _TopographySurface).UniqueId, _Document);
        _Document.Delete(((Element) _ProposedSurface.TopographySurface).Id);
        progressBarForm.UpdateProgressBar(3);
        _ProposedSurface = new TopographySurfaceContainer(_Document.Application, _TopographySurface, true);
        if (_TopoPlacementFamilyInstance != null)
        {
          Parameter parameter22 = ((Element) _TopoPlacementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter22 != null && !((APIObject) parameter22).IsReadOnly)
            parameter22.Set(((Element) _TopographySurface).UniqueId);
        }
      }
      progressBarForm.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm.Close();
    }
    return flag;
  }

  public static List<TopographySurfaceContainer> FindAllMainSurfaces(
    Document _Document,
    bool _bFindMinMaxPoints)
  {
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements();
    List<TopographySurface> topographySurfaceList = new List<TopographySurface>();
    List<TopographySurfaceContainer> allMainSurfaces = new List<TopographySurfaceContainer>();
    foreach (Element element in (IEnumerable<Element>) elements)
    {
      TopographySurface topographySurface = element as TopographySurface;
      topographySurfaceList.Add(topographySurface);
    }
    for (int index = 0; index < topographySurfaceList.Count; ++index)
    {
      if (TopographySurfaceContainer.FindTopographySurfaceType(_Document.Application, topographySurfaceList[index]) == TopographySurfaceType.MainSurface)
        allMainSurfaces.Add(new TopographySurfaceContainer(_Document.Application, topographySurfaceList[index], _bFindMinMaxPoints));
    }
    return allMainSurfaces;
  }

  public static Eps_Point FindToposurfaceAdjustmentPoint(
    TopographySurfaceContainer _CurTopoSurfaceContainer,
    List<TopographySurfaceContainer> _SurfaceList)
  {
    double _dAdjustmentX = 2.0 * (_CurTopoSurfaceContainer.MaxRightPoint.x + (_CurTopoSurfaceContainer.MaxRightPoint.x - _CurTopoSurfaceContainer.MinLeftPoint.x));
    double _dAdjustmentY = 2.0 * (_CurTopoSurfaceContainer.MaxRightPoint.y + (_CurTopoSurfaceContainer.MaxRightPoint.y - _CurTopoSurfaceContainer.MinLeftPoint.y));
    return TopographySurfaceManagement.FindToposurfaceAdjustmentPoint(_CurTopoSurfaceContainer, _SurfaceList, _dAdjustmentX, _dAdjustmentY);
  }

  public static Eps_Point FindToposurfaceAdjustmentPoint(
    TopographySurfaceContainer _CurTopoSurfaceContainer,
    List<TopographySurfaceContainer> _SurfaceList,
    double _dAdjustmentX,
    double _dAdjustmentY)
  {
    bool flag = true;
    int num1 = 5;
    int num2 = 1;
    while (flag)
    {
      flag = false;
      for (int index = 0; index < _SurfaceList.Count; ++index)
      {
        Eps_Point _FindPoint1 = new Eps_Point(_CurTopoSurfaceContainer.MaxRightPoint.x + _dAdjustmentX, _CurTopoSurfaceContainer.MaxRightPoint.y + _dAdjustmentY, 0.0);
        if (_SurfaceList[index].IsPointWithinSurfaceBounds(_FindPoint1))
        {
          flag = true;
          break;
        }
        Eps_Point _FindPoint2 = new Eps_Point(_CurTopoSurfaceContainer.MaxLeftPoint.x + _dAdjustmentX, _CurTopoSurfaceContainer.MaxLeftPoint.y + _dAdjustmentY, 0.0);
        if (_SurfaceList[index].IsPointWithinSurfaceBounds(_FindPoint2))
        {
          flag = true;
          break;
        }
        Eps_Point _FindPoint3 = new Eps_Point(_CurTopoSurfaceContainer.MinLeftPoint.x + _dAdjustmentX, _CurTopoSurfaceContainer.MinLeftPoint.y + _dAdjustmentY, 0.0);
        if (_SurfaceList[index].IsPointWithinSurfaceBounds(_FindPoint3))
        {
          flag = true;
          break;
        }
        Eps_Point _FindPoint4 = new Eps_Point(_CurTopoSurfaceContainer.MinRightPoint.x + _dAdjustmentX, _CurTopoSurfaceContainer.MinRightPoint.y + _dAdjustmentY, 0.0);
        if (_SurfaceList[index].IsPointWithinSurfaceBounds(_FindPoint4))
        {
          flag = true;
          break;
        }
      }
      if (flag)
      {
        if (num2 == num1)
          flag = false;
        if (_dAdjustmentX > 0.0)
        {
          if (_dAdjustmentY < 0.0)
          {
            _dAdjustmentX *= 2.0;
            _dAdjustmentY *= -2.0;
            ++num2;
          }
          else
            _dAdjustmentX = -_dAdjustmentX;
        }
        else if (_dAdjustmentY > 0.0)
          _dAdjustmentY = -_dAdjustmentY;
        else if (_dAdjustmentX < 0.0)
          _dAdjustmentX = -_dAdjustmentX;
      }
    }
    return new Eps_Point(_dAdjustmentX, _dAdjustmentY, 0.0);
  }

  public static List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>> FindPlantMixGenericModelList(
    Document _Document,
    List<TopographySurfaceContainer> _SubregionList)
  {
    List<Element> elementList = new List<Element>();
    FindFamilyInstance2 = (FamilyInstance) null;
    Parameter LandcaddIDParameter = (Parameter) null;
    if (_SubregionList.Count == 0)
      return (List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>>) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2000151);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement =>
    {
      if (CurrentElement is FamilyInstance FindFamilyInstance2 && (LandcaddIDParameter = ((Element) FindFamilyInstance2.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null)
      {
        string strA1 = LandcaddIDParameter.AsString();
        int int32 = Convert.ToInt32((object) LandcaddID.PlantMix);
        string strB1 = int32.ToString("000");
        if (string.Compare(strA1, strB1, true) != 0)
        {
          string strA2 = LandcaddIDParameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.PatioWalk);
          string strB2 = int32.ToString("000");
          if (string.Compare(strA2, strB2, true) != 0)
            goto label_4;
        }
        return CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null;
      }
label_4:
      return false;
    })).ToList<Element>();
    List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>> genericModelList = new List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>>();
    foreach (Element element in list)
    {
      if (element is FamilyInstance key && ((Element) key).Category != null && ((Element) key).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode())
      {
        LandcaddIDParameter = ((Element) key.Symbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (LandcaddIDParameter != null && (string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.PlantMix).ToString("000"), true) == 0 || string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.PatioWalk).ToString("000"), true) == 0))
        {
          Parameter parameter = ((Element) key).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter != null)
          {
            for (int index = _SubregionList.Count - 1; index >= 0; --index)
            {
              if (string.Compare(parameter.AsString(), ((Element) _SubregionList[index].TopographySurface).UniqueId, true) == 0)
              {
                genericModelList.Add(new KeyValuePair<FamilyInstance, TopographySurfaceContainer>(key, _SubregionList[index]));
                _SubregionList.RemoveAt(index);
                break;
              }
            }
            if (_SubregionList.Count == 0)
              break;
          }
        }
      }
    }
    return genericModelList;
  }

  public static List<TopographySurfaceContainer> FindNewTopographySurfaceContainers(
    Document _Document,
    List<ElementId> _NewElementIds)
  {
    List<TopographySurfaceContainer> surfaceContainers = new List<TopographySurfaceContainer>();
    foreach (ElementId newElementId in _NewElementIds)
    {
      Element element = _Document.GetElement(newElementId);
      if (element != null)
      {
        if (element is TopographySurface _TopographySurface)
        {
          try
          {
            string uniqueId = ((Element) _TopographySurface).UniqueId;
            surfaceContainers.Add(new TopographySurfaceContainer(_Document.Application, _TopographySurface, true));
          }
          catch (InvalidObjectException ex)
          {
          }
        }
        else if (element is CeilingAndFloor _BuildingPad)
        {
          try
          {
            string uniqueId = ((Element) _BuildingPad).UniqueId;
            surfaceContainers.Add(new TopographySurfaceContainer(_Document.Application, _BuildingPad, true));
          }
          catch (InvalidObjectException ex)
          {
          }
        }
      }
    }
    return surfaceContainers;
  }

  public static void UpdatePlantMixGenericModelList(
    List<KeyValuePair<FamilyInstance, TopographySurfaceContainer>> _UpdateGenericModelList,
    List<TopographySurfaceContainer> NewToposurfaceList)
  {
    if (_UpdateGenericModelList == null || _UpdateGenericModelList.Count <= 0)
      return;
    bool flag = false;
label_17:
    for (int index1 = 0; index1 < _UpdateGenericModelList.Count; ++index1)
    {
      KeyValuePair<FamilyInstance, TopographySurfaceContainer> updateGenericModel = _UpdateGenericModelList[index1];
      if (updateGenericModel.Value != null)
      {
        int index2 = 0;
        while (true)
        {
          int num = index2;
          updateGenericModel = _UpdateGenericModelList[index1];
          int count = updateGenericModel.Value.Vertices.Count;
          if (num < count)
          {
            updateGenericModel = _UpdateGenericModelList[index1];
            Eps_Point vertex = updateGenericModel.Value.Vertices[index2];
            for (int index3 = NewToposurfaceList.Count - 1; index3 >= 0; --index3)
            {
              if (NewToposurfaceList[index3].TopographySurface != null && NewToposurfaceList[index3].GetSurfaceContainerContainingPoint(vertex) != null)
              {
                updateGenericModel = _UpdateGenericModelList[index1];
                if (updateGenericModel.Key != null)
                {
                  updateGenericModel = _UpdateGenericModelList[index1];
                  Parameter parameter = ((Element) updateGenericModel.Key).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
                  if (parameter != null && !((APIObject) parameter).IsReadOnly)
                    parameter.Set(((Element) NewToposurfaceList[index3].TopographySurface).UniqueId);
                }
                flag = true;
                NewToposurfaceList.RemoveAt(index3);
                break;
              }
            }
            if (!flag)
              ++index2;
            else
              break;
          }
          else
            goto label_17;
        }
        flag = false;
      }
    }
  }

  public static void RemoveDuplicateXY(ref List<XYZ> PointXYZList)
  {
    List<XYZ> xyzList = new List<XYZ>();
    if (TopographySurface.ArePointsDistinct((IList<XYZ>) PointXYZList))
      return;
    for (int index1 = 0; index1 < PointXYZList.Count - 1; ++index1)
    {
      for (int index2 = index1 + 1; index2 < PointXYZList.Count; ++index2)
      {
        if (Math.Abs(PointXYZList[index1].X - PointXYZList[index2].X) < 1E-06 && Math.Abs(PointXYZList[index1].Y - PointXYZList[index2].Y) < 1E-06)
        {
          xyzList.Add(PointXYZList[index1]);
          xyzList.Add(PointXYZList[index2]);
          if (Math.Abs(PointXYZList[index1].Z - PointXYZList[index2].Z) < 1E-06)
          {
            PointXYZList.RemoveAt(index2);
            --index2;
          }
          else
          {
            PointXYZList.RemoveAt(index2);
            --index2;
          }
        }
      }
    }
  }
}
