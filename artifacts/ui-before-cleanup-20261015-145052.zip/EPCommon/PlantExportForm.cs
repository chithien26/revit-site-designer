using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace EPCommon;

public class PlantExportForm : EPForm
{
	private List<FamilyTypeContainer> m_PlantListFamilyTypeList;

	private List<ParameterColumn> m_ParameterList;

	private Document m_Document;

	private IContainer components;

	private TextBox m_ExportFileTextBox;

	private Button m_ExportFileButton;

	private Label m_ExportFileLabel;

	private RadioButton m_TabExportRadioButton;

	private RadioButton m_CommaExportRadioButton;

	private Button m_CancelButton;

	private Button m_OKButton;

	public PlantExportForm(Document _Document, List<FamilyTypeContainer> _PlantListFamilyTypeList, List<ParameterColumn> _ParameterList)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("PlantExportDialog");
		m_CommaExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
		m_TabExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
		m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_PlantListFamilyTypeList = _PlantListFamilyTypeList;
		m_ParameterList = _ParameterList;
		m_Document = _Document;
		InitializeControls();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		m_CommaExportRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantExportOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_CommaExportRadioButton.Checked = true;
			}
			else
			{
				m_TabExportRadioButton.Checked = true;
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantExportFileName", ref _strReturnValue))
		{
			m_ExportFileTextBox.Text = _strReturnValue;
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		num = ((!m_CommaExportRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantExportOption", num);
		if (m_ExportFileTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantExportFileName", m_ExportFileTextBox.Text);
		}
	}

	private void OnExportFileButtonClick(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		if (m_CommaExportRadioButton.Checked)
		{
			saveFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
		}
		else
		{
			saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
		}
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_ExportFileTextBox.Text = saveFileDialog.FileName;
			SiteDesigner.UI.WpfFocus.Focus(m_ExportFileTextBox);
		}
	}

	private bool ValidateFields()
	{
		string value = m_ExportFileTextBox.Text;
		if (string.IsNullOrEmpty(value))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFolderFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_ExportFileTextBox);
			return false;
		}
		string empty = string.Empty;
		empty = ((!m_CommaExportRadioButton.Checked) ? ".txt" : ".csv");
		if (m_ExportFileTextBox.Text.IndexOf(empty) < 0)
		{
			if (m_ExportFileTextBox.Text.IndexOf("\\") <= 0 && m_ExportFileTextBox.Text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length = -1;
			if (m_ExportFileTextBox.Text.IndexOf("\\") > 0)
			{
				length = m_ExportFileTextBox.Text.LastIndexOf("\\");
			}
			else if (m_ExportFileTextBox.Text.IndexOf("/") > 0)
			{
				length = m_ExportFileTextBox.Text.LastIndexOf("/");
			}
			if (!Directory.Exists(m_ExportFileTextBox.Text.Substring(0, length)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			m_ExportFileTextBox.Text += empty;
		}
		else
		{
			if (m_ExportFileTextBox.Text.IndexOf("\\") <= 0 && m_ExportFileTextBox.Text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length2 = -1;
			if (m_ExportFileTextBox.Text.IndexOf("\\") > 0)
			{
				length2 = m_ExportFileTextBox.Text.LastIndexOf("\\");
			}
			else if (m_ExportFileTextBox.Text.IndexOf("/") > 0)
			{
				length2 = m_ExportFileTextBox.Text.LastIndexOf("/");
			}
			if (!Directory.Exists(m_ExportFileTextBox.Text.Substring(0, length2)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
		}
		return true;
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		if (ValidateFields())
		{
			SaveSettings();
			string empty = string.Empty;
			ImportExport.ExportToFile(_strSeperator: (!m_CommaExportRadioButton.Checked) ? "\t" : ",", _Document: m_Document, _strExportFileName: m_ExportFileTextBox.Text, _PlantListFamilyTypeList: m_PlantListFamilyTypeList, _ParameterList: m_ParameterList);
			DialogResult = DialogResult.OK;
			Close();
		}
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void OnPlantExportFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ExportFileTextBox = new System.Windows.Forms.TextBox();
		this.m_ExportFileButton = new System.Windows.Forms.Button();
		this.m_ExportFileLabel = new System.Windows.Forms.Label();
		this.m_TabExportRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CommaExportRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_OKButton = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.m_ExportFileTextBox.Location = new System.Drawing.Point(60, 35);
		this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
		this.m_ExportFileTextBox.Size = new System.Drawing.Size(361, 20);
		this.m_ExportFileTextBox.TabIndex = 3;
		this.m_ExportFileButton.Location = new System.Drawing.Point(427, 35);
		this.m_ExportFileButton.Name = "m_ExportFileButton";
		this.m_ExportFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_ExportFileButton.TabIndex = 4;
		this.m_ExportFileButton.TabStop = false;
		this.m_ExportFileButton.Text = "...";
		this.m_ExportFileButton.UseVisualStyleBackColor = true;
		this.m_ExportFileButton.Click += new System.EventHandler(this.OnExportFileButtonClick);
		this.m_ExportFileLabel.AutoSize = true;
		this.m_ExportFileLabel.Location = new System.Drawing.Point(12, 38);
		this.m_ExportFileLabel.Name = "m_ExportFileLabel";
		this.m_ExportFileLabel.Size = new System.Drawing.Size(26, 13);
		this.m_ExportFileLabel.TabIndex = 2;
		this.m_ExportFileLabel.Text = "Fi&le:";
		this.m_TabExportRadioButton.AutoSize = true;
		this.m_TabExportRadioButton.Location = new System.Drawing.Point(243, 12);
		this.m_TabExportRadioButton.Name = "m_TabExportRadioButton";
		this.m_TabExportRadioButton.Size = new System.Drawing.Size(139, 17);
		this.m_TabExportRadioButton.TabIndex = 1;
		this.m_TabExportRadioButton.TabStop = true;
		this.m_TabExportRadioButton.Text = "&Tab Delimited (Text File)";
		this.m_TabExportRadioButton.UseVisualStyleBackColor = true;
		this.m_CommaExportRadioButton.AutoSize = true;
		this.m_CommaExportRadioButton.Location = new System.Drawing.Point(12, 12);
		this.m_CommaExportRadioButton.Name = "m_CommaExportRadioButton";
		this.m_CommaExportRadioButton.Size = new System.Drawing.Size(155, 17);
		this.m_CommaExportRadioButton.TabIndex = 0;
		this.m_CommaExportRadioButton.TabStop = true;
		this.m_CommaExportRadioButton.Text = "&Comma Delimited (Text File)";
		this.m_CommaExportRadioButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Location = new System.Drawing.Point(376, 61);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 6;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_OKButton.Location = new System.Drawing.Point(295, 61);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 5;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(463, 96);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_OKButton);
		base.Controls.Add(this.m_TabExportRadioButton);
		base.Controls.Add(this.m_CommaExportRadioButton);
		base.Controls.Add(this.m_ExportFileTextBox);
		base.Controls.Add(this.m_ExportFileButton);
		base.Controls.Add(this.m_ExportFileLabel);
		base.Name = "PlantExportForm";
		this.Text = "Plant Export";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantExportFormClosing);
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_OKButton;
		base.CancelButton = this.m_CancelButton;
	}
}
