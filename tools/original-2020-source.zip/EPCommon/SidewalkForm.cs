﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SidewalkForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class SidewalkForm : BaseForm
{
  private double m_dSubgradeDepth;
  private double m_dWidth;
  private FamilySymbol m_SidewalkFamilySymbol;

  public SidewalkForm(FamilySymbol _FamilySymbol, Eps_Leg _CurrentLeg)
    : base(_CurrentLeg)
  {
    this.m_dSubgradeDepth = 0.0;
    this.m_dWidth = 0.0;
    this.m_SidewalkFamilySymbol = _FamilySymbol;
    if (_FamilySymbol == null)
      return;
    Parameter parameter1 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
    if (parameter1 != null)
      this.m_dWidth = parameter1.AsDouble();
    Parameter parameter2 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.SideWalkPavementDepthParameter);
    if (parameter2 == null)
      return;
    this.m_dSubgradeDepth = parameter2.AsDouble();
  }

  private List<Form> CreateLoftForm()
  {
    List<Form> loftForm = new List<Form>();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingSidewalkMassMessage");
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 0;
    List<ReferenceArrayArray> referenceArrayArray = this.GetReferenceArrayArray();
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = referenceArrayArray.Count;
    for (int index = 0; index < referenceArrayArray.Count; ++index)
    {
      if (referenceArrayArray[index] != null && referenceArrayArray[index].Size > 0)
      {
        string empty = string.Empty;
        Form form = this.NewLoftForm(referenceArrayArray[index], index, ref empty);
        if (form == null)
        {
          this.m_TransactionContainer.AbortTransaction();
          this.m_TransactionContainer.BeginTransaction();
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          loftForm.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return loftForm;
        }
        loftForm.Add(form);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return loftForm;
  }

  private List<Solid> CreateBlends()
  {
    List<Solid> blends = new List<Solid>();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingSidewalkMassMessage");
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 0;
    List<List<CurveLoop>> curveLoopArrayArray = this.GetCurveLoopArrayArray();
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = curveLoopArrayArray.Count;
    for (int index = 0; index < curveLoopArrayArray.Count; ++index)
    {
      if (curveLoopArrayArray[index] != null && curveLoopArrayArray[index].Count > 0)
      {
        string empty = string.Empty;
        Solid solid = this.NewBlend(curveLoopArrayArray[index], index, ref empty);
        if (GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          blends.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return blends;
        }
        blends.Add(solid);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return blends;
  }

  private Form NewLoftForm(
    ReferenceArrayArray _SidewalkReferenceArrayArray,
    int _nProcessLegSegment,
    ref string _strErrorMessage)
  {
    Form form = (Form) null;
    try
    {
      form = this.m_MassDocument.FamilyCreate.NewLoftForm(true, _SidewalkReferenceArrayArray);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (InvalidOperationException ex)
    {
      if (string.Compare(((Exception) ex).Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("SidewalkTemplateNotMassTypeMessage");
        return (Form) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<ReferenceArrayArray> referenceArrayArray = this.GetReferenceArrayArray(_nProcessLegSegment);
        if (referenceArrayArray.Count > 0)
          form = this.NewLoftForm(referenceArrayArray[0], _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCreateMassMessage");
    }
    return form;
  }

  private Solid NewBlend(
    List<CurveLoop> _SidewalkCurveLoopArray,
    int _nProcessLegSegment,
    ref string _strErrorMessage)
  {
    Solid solid = (Solid) null;
    try
    {
      SolidOptions solidOptions = (SolidOptions) null;
      Parameter parameter = ((Element) this.SidewalkFamilySymbol).LookupParameter(RevitParameters.SideWalkPavementSurfaceParameter);
      if (parameter != null)
        solidOptions = new SolidOptions(new ElementId(parameter.AsInteger()), ElementId.InvalidElementId);
      solid = GeometryCreationUtilities.CreateLoftGeometry((IList<CurveLoop>) _SidewalkCurveLoopArray, solidOptions);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (InvalidOperationException ex)
    {
      if (string.Compare(((Exception) ex).Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("SidewalkTemplateNotMassTypeMessage");
        return (Solid) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<List<CurveLoop>> curveLoopArrayArray = this.GetCurveLoopArrayArray(_nProcessLegSegment);
        if (curveLoopArrayArray.Count > 0)
          solid = this.NewBlend(curveLoopArrayArray[0], _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCreateBlendGeometry");
    }
    return solid;
  }

  public override string CreateElement(
    Document doc,
    ref string _strAdditionalLoftID,
    string _strSiteComponentName,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseInternalPoint)
  {
    List<Solid> blends = this.CreateBlends();
    List<GeometryObject> geometryObjectList = new List<GeometryObject>();
    foreach (Solid solid in blends)
      geometryObjectList.Add((GeometryObject) solid);
    if (geometryObjectList.Count == 0)
      return string.Empty;
    Guid guid = doc.Application.ActiveAddInId.GetGUID();
    DirectShape element = DirectShape.CreateElement(doc, new ElementId((BuiltInCategory) -2001220));
    element.ApplicationId = guid.ToString();
    element.SetShape((IList<GeometryObject>) geometryObjectList);
    string uniqueId = ((Element) element).UniqueId;
    ElementTransformUtils.MoveElement(doc, ((Element) element).Id, this.m_LegInsertPoint.XYZ);
    ((Element) element).Name = _strSiteComponentName;
    return uniqueId;
  }

  public List<Form> CreateLoftFormWithParameters()
  {
    List<Form> loftForm = this.CreateLoftForm();
    string empty = string.Empty;
    Category category = (Category) null;
    Category familyCategory = this.m_MassDocument.OwnerFamily.FamilyCategory;
    if (familyCategory != null && familyCategory.SubCategories != null && familyCategory.SubCategories.Size > 0)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("SidewalkMassSubCategoryName", ref empty) && !ApplicationUtility.Settings.eplSetE_GetSetting("SidewalkMassSubCatergoryName", ref empty))
      {
        empty = EPShared.LocalRM.GetString("SWSidewalkLineNameString");
        ApplicationUtility.Settings.eplSetE_SetSetting("SidewalkMassSubCategoryName", empty);
      }
      if (familyCategory.SubCategories.Contains(empty))
        category = familyCategory.SubCategories[empty];
    }
    if (loftForm != null && loftForm.Count > 0)
    {
      if (category == null)
        category = this.m_MassDocument.Settings.Categories.NewSubcategory(familyCategory, empty);
      FamilyParameter familyParameter = (FamilyParameter) null;
      for (int index = 0; index < loftForm.Count; ++index)
      {
        if (index == 0)
          familyParameter = this.m_MassDocument.FamilyManager.AddParameter(RevitParameters.SideWalkPavementSurfaceParameter, (BuiltInParameterGroup) -5000105, (ParameterType) 9, true);
        try
        {
          Parameter parameter = ((Element) loftForm[index])[(BuiltInParameter) -1002107];
          if (parameter != null)
            this.m_MassDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter);
          if (category != null)
            ((GenericForm) loftForm[index]).Subcategory = category;
        }
        catch (InvalidOperationException ex)
        {
        }
      }
    }
    return loftForm;
  }

  private List<ReferenceArrayArray> GetReferenceArrayArray() => this.GetReferenceArrayArray(-1);

  private List<List<CurveLoop>> GetCurveLoopArrayArray() => this.GetCurveLoopArrayArray(-1);

  private List<List<CurveLoop>> GetCurveLoopArrayArray(int _nProcessLegSegment)
  {
    List<List<CurveLoop>> curveLoopArrayArray = new List<List<CurveLoop>>();
    List<CurveLoop> curveLoopList = (List<CurveLoop>) null;
    CurveLoop curveLoop1 = (CurveLoop) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    double _dStation1 = 0.0;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    double _dX = 0.0;
    double num1 = 0.0;
    double num2 = 0.0;
    double _dAdjustDistance = 0.0;
    bool flag1 = false;
    int _nDocIndex = 0;
    int index1 = 0;
    int index2 = 0;
    bool flag2 = true;
    if (this.m_MassLeg != null)
    {
      if (this.m_IntersectionContainers != null && this.m_IntersectionContainers.Count > 0)
        flag2 = this.m_IntersectionContainers[0].StartingIntersection;
      for (Eps_Leg _Leg = this.m_MassLeg; _Leg != null; _Leg = _Leg.Next)
      {
        if (_nProcessLegSegment > -1)
        {
          if (_nDocIndex <= _nProcessLegSegment)
          {
            if (_nDocIndex < _nProcessLegSegment)
            {
              ++_nDocIndex;
              continue;
            }
          }
          else
            break;
        }
        if (_nDocIndex == 0 || flag2)
          curveLoopList = new List<CurveLoop>();
        double num3 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
        if (_Leg.Arc != null)
        {
          Arc arc = _Leg.Arc.RevitArc(this.m_MassDocument);
          double _dStation2 = 0.0;
          double _dOffset = 0.0;
          double _dStation3 = 0.0;
          int index3 = 0;
          List<XYZ> list = ((Curve) arc).Tessellate().ToList<XYZ>();
          int count = list.Count;
          for (int index4 = 0; index4 < count; ++index4)
          {
            Eps_Point _Point = new Eps_Point(list[index4]);
            if (index4 % 5 == 0 || index4 == 1 || index4 == count - 1)
            {
              EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation2, ref _dOffset);
              if (flag2)
              {
                if (_nDocIndex > 0 && index4 == 0)
                  _dStation2 += dOffsetAdjust;
                if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null && index4 == count - 1)
                  _dStation2 -= dOffsetAdjust;
                CurveLoop profileAtStation;
                if (index4 == count - 1 && _Leg.Next != null && _Leg.Next.Line != null)
                {
                  EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Arc, ref _dX);
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                  int ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Next.Line.EndPnt);
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    double num4 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                    double SweepAngle = 0.0;
                    RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                    num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                    if (!RevitDefines.EQ(_dX, num1))
                    {
                      flag1 = true;
                      _dAdjustDistance = Math.Abs(Math.Cos(num4 / 2.0));
                      profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2, true, num1, _dAdjustDistance);
                    }
                    else
                      profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                  }
                  else
                    profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                }
                else if (flag1)
                {
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance);
                  flag1 = false;
                }
                else
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                if (profileAtStation != null)
                {
                  curveLoopList.Add(profileAtStation);
                  curveLoop1 = (CurveLoop) null;
                }
              }
              switch (index4)
              {
                case 0:
                  index3 = 1;
                  break;
                case 1:
                  index3 = 5;
                  break;
                default:
                  index3 += 5;
                  break;
              }
              if (index3 > count - 1)
                index3 = count - 1;
              EPShared.eplGeoE_CalcStationOffsetAlongArc(new Eps_Point(list[index3]), _Leg.Arc, ref _dStation3, ref _dOffset);
            }
          }
          _dStation1 += num3;
        }
        else
        {
          if (flag2)
          {
            CurveLoop profileAtStation;
            if (_nDocIndex == 0)
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1);
            else if (flag1)
            {
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance);
              flag1 = false;
            }
            else
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust);
            if (profileAtStation != null)
            {
              curveLoopList.Add(profileAtStation);
              curveLoop1 = (CurveLoop) null;
            }
          }
          if (this.m_IntersectionContainers != null)
          {
            while (index1 < this.m_IntersectionContainers.Count && index2 < this.m_IntersectionContainers[index1].Profiles.Count && this.m_IntersectionContainers[index1].Profiles[index2].Station <= _dStation1 + num3)
            {
              if (this.m_IntersectionContainers[index1].Profiles[index2].Station >= _dStation1)
              {
                if (flag2 && this.m_IntersectionContainers[index1].StartingIntersection && index2 == 0 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 4)
                {
                  Eps_Point point1 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                  Eps_Point point2 = this.m_IntersectionContainers[index1].Profiles[index2].Points[this.m_IntersectionContainers[index1].Profiles[index2].Points.Count - 1];
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
                  _dX = EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI / 2.0);
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point2, point1, ref num2);
                  CurveLoop profileAtStation;
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                    profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust, true, num2, _dAdjustDistance);
                  }
                  else
                    profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust);
                  if (profileAtStation != null)
                  {
                    curveLoopList.Add(profileAtStation);
                    curveLoop1 = (CurveLoop) null;
                  }
                  if (curveLoopList != null)
                  {
                    curveLoopArrayArray.Add(curveLoopList);
                    curveLoopList = new List<CurveLoop>();
                  }
                }
                CurveLoop curveLoop2 = this.ApplyCurveLoopProfile(this.m_IntersectionContainers[index1].Profiles[index2].Points);
                if (curveLoop2 != null)
                {
                  curveLoopList.Add(curveLoop2);
                  curveLoop1 = (CurveLoop) null;
                }
                if (this.m_IntersectionContainers[index1].StartingIntersection)
                {
                  if (index2 == 0)
                    flag2 = false;
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1 && curveLoopList != null)
                  {
                    curveLoopArrayArray.Add(curveLoopList);
                    curveLoopList = new List<CurveLoop>();
                  }
                }
                else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                {
                  flag2 = true;
                  if (curveLoopList != null)
                  {
                    curveLoopArrayArray.Add(curveLoopList);
                    curveLoopList = new List<CurveLoop>();
                  }
                  if (this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust < _dStation1 + num3 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 4)
                  {
                    Eps_Point point3 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                    Eps_Point point4 = this.m_IntersectionContainers[index1].Profiles[index2].Points[this.m_IntersectionContainers[index1].Profiles[index2].Points.Count - 1];
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.EndPnt, _Leg.Line.StartPnt, ref _dX);
                    _dX = EPShared.eplGeoE_NormalizeRadians(_dX - Math.PI / 2.0);
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point4, point3, ref num2);
                    CurveLoop profileAtStation;
                    if (!RevitDefines.EQ(_dX, num2))
                    {
                      _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                      profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust, true, num2, _dAdjustDistance);
                    }
                    else
                      profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust);
                    if (profileAtStation != null)
                    {
                      curveLoopList.Add(profileAtStation);
                      curveLoop1 = (CurveLoop) null;
                    }
                  }
                }
              }
              ++index2;
              if (index2 == this.m_IntersectionContainers[index1].Profiles.Count)
              {
                index2 = 0;
                ++index1;
              }
              flag1 = false;
            }
          }
          _dStation1 += num3;
          if (flag2)
          {
            if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null)
              _dStation1 -= dOffsetAdjust;
            CurveLoop profileAtStation;
            if (_Leg.Next != null)
            {
              int ArcDir = 0;
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
              if (_Leg.Next.Line != null)
              {
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Line.EndPnt);
              }
              else if (_Leg.Next.Arc != null)
              {
                EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Next.Arc, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Arc.EndPnt);
              }
              if (!RevitDefines.EQ(_dX, num2))
              {
                double num5 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                double SweepAngle = 0.0;
                RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                if (!RevitDefines.EQ(_dX, num1))
                {
                  flag1 = true;
                  _dAdjustDistance = Math.Abs(Math.Cos(num5 / 2.0));
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, true, num1, _dAdjustDistance);
                }
                else
                  profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1);
              }
              else
                profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1);
            }
            else
              profileAtStation = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1);
            if (profileAtStation != null)
            {
              curveLoopList.Add(profileAtStation);
              curveLoop1 = (CurveLoop) null;
            }
          }
        }
        if (flag2 && curveLoopList != null)
          curveLoopArrayArray.Add(curveLoopList);
        ++_nDocIndex;
      }
    }
    return curveLoopArrayArray;
  }

  private List<ReferenceArrayArray> GetReferenceArrayArray(int _nProcessLegSegment)
  {
    List<ReferenceArrayArray> referenceArrayArray1 = new List<ReferenceArrayArray>();
    ReferenceArrayArray referenceArrayArray2 = (ReferenceArrayArray) null;
    ReferenceArray referenceArray1 = (ReferenceArray) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    double _dStation1 = 0.0;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    double _dX = 0.0;
    double num1 = 0.0;
    double num2 = 0.0;
    double _dAdjustDistance = 0.0;
    bool flag1 = false;
    int _nDocIndex = 0;
    int index1 = 0;
    int index2 = 0;
    bool flag2 = true;
    if (this.m_MassLeg != null)
    {
      if (this.m_IntersectionContainers != null && this.m_IntersectionContainers.Count > 0)
        flag2 = this.m_IntersectionContainers[0].StartingIntersection;
      for (Eps_Leg _Leg = this.m_MassLeg; _Leg != null; _Leg = _Leg.Next)
      {
        if (_nProcessLegSegment > -1)
        {
          if (_nDocIndex <= _nProcessLegSegment)
          {
            if (_nDocIndex < _nProcessLegSegment)
            {
              ++_nDocIndex;
              continue;
            }
          }
          else
            break;
        }
        if (_nDocIndex == 0 || flag2)
          referenceArrayArray2 = new ReferenceArrayArray();
        double num3 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
        if (_Leg.Arc != null)
        {
          Arc arc = _Leg.Arc.RevitArc(this.m_MassDocument);
          double _dStation2 = 0.0;
          double _dOffset = 0.0;
          double _dStation3 = 0.0;
          int index3 = 0;
          List<XYZ> list = ((Curve) arc).Tessellate().ToList<XYZ>();
          int count = list.Count;
          for (int index4 = 0; index4 < count; ++index4)
          {
            Eps_Point _Point = new Eps_Point(list[index4]);
            if (index4 % 5 == 0 || index4 == 1 || index4 == count - 1)
            {
              EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation2, ref _dOffset);
              if (flag2)
              {
                if (_nDocIndex > 0 && index4 == 0)
                  _dStation2 += dOffsetAdjust;
                if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null && index4 == count - 1)
                  _dStation2 -= dOffsetAdjust;
                ReferenceArray profileAtStation;
                if (index4 == count - 1 && _Leg.Next != null && _Leg.Next.Line != null)
                {
                  EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Arc, ref _dX);
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                  int ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Next.Line.EndPnt);
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    double num4 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                    double SweepAngle = 0.0;
                    RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                    num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                    if (!RevitDefines.EQ(_dX, num1))
                    {
                      flag1 = true;
                      _dAdjustDistance = Math.Abs(Math.Cos(num4 / 2.0));
                      profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2, true, num1, _dAdjustDistance);
                    }
                    else
                      profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                  }
                  else
                    profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                }
                else if (flag1)
                {
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance);
                  flag1 = false;
                }
                else
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                if (profileAtStation != null && profileAtStation.Size > 0)
                {
                  referenceArrayArray2.Append(profileAtStation);
                  referenceArray1 = (ReferenceArray) null;
                }
              }
              switch (index4)
              {
                case 0:
                  index3 = 1;
                  break;
                case 1:
                  index3 = 5;
                  break;
                default:
                  index3 += 5;
                  break;
              }
              if (index3 > count - 1)
                index3 = count - 1;
              EPShared.eplGeoE_CalcStationOffsetAlongArc(new Eps_Point(list[index3]), _Leg.Arc, ref _dStation3, ref _dOffset);
            }
          }
          _dStation1 += num3;
        }
        else
        {
          if (flag2)
          {
            ReferenceArray profileAtStation;
            if (_nDocIndex == 0)
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1);
            else if (flag1)
            {
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance);
              flag1 = false;
            }
            else
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust);
            if (profileAtStation != null && profileAtStation.Size > 0)
            {
              referenceArrayArray2.Append(profileAtStation);
              referenceArray1 = (ReferenceArray) null;
            }
          }
          if (this.m_IntersectionContainers != null)
          {
            while (index1 < this.m_IntersectionContainers.Count && index2 < this.m_IntersectionContainers[index1].Profiles.Count && this.m_IntersectionContainers[index1].Profiles[index2].Station <= _dStation1 + num3)
            {
              if (this.m_IntersectionContainers[index1].Profiles[index2].Station >= _dStation1)
              {
                if (flag2 && this.m_IntersectionContainers[index1].StartingIntersection && index2 == 0 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 4)
                {
                  Eps_Point point1 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                  Eps_Point point2 = this.m_IntersectionContainers[index1].Profiles[index2].Points[this.m_IntersectionContainers[index1].Profiles[index2].Points.Count - 1];
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
                  _dX = EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI / 2.0);
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point2, point1, ref num2);
                  ReferenceArray profileAtStation;
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                    profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust, true, num2, _dAdjustDistance);
                  }
                  else
                    profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station - dOffsetAdjust);
                  if (profileAtStation != null && profileAtStation.Size > 0)
                  {
                    referenceArrayArray2.Append(profileAtStation);
                    referenceArray1 = (ReferenceArray) null;
                  }
                  if (referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
                  {
                    referenceArrayArray1.Add(referenceArrayArray2);
                    referenceArrayArray2 = new ReferenceArrayArray();
                  }
                }
                ReferenceArray referenceArray2 = this.ApplyReferenceArrayProfile(this.m_IntersectionContainers[index1].Profiles[index2].Points);
                if (referenceArray2 != null && referenceArray2.Size > 0)
                {
                  referenceArrayArray2.Append(referenceArray2);
                  referenceArray1 = (ReferenceArray) null;
                }
                if (this.m_IntersectionContainers[index1].StartingIntersection)
                {
                  if (index2 == 0)
                    flag2 = false;
                  else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1 && referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
                  {
                    referenceArrayArray1.Add(referenceArrayArray2);
                    referenceArrayArray2 = new ReferenceArrayArray();
                  }
                }
                else if (index2 == this.m_IntersectionContainers[index1].Profiles.Count - 1)
                {
                  flag2 = true;
                  if (referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
                  {
                    referenceArrayArray1.Add(referenceArrayArray2);
                    referenceArrayArray2 = new ReferenceArrayArray();
                  }
                  if (this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust < _dStation1 + num3 && this.m_IntersectionContainers[index1].Profiles[index2].Points.Count == 4)
                  {
                    Eps_Point point3 = this.m_IntersectionContainers[index1].Profiles[index2].Points[0];
                    Eps_Point point4 = this.m_IntersectionContainers[index1].Profiles[index2].Points[this.m_IntersectionContainers[index1].Profiles[index2].Points.Count - 1];
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.EndPnt, _Leg.Line.StartPnt, ref _dX);
                    _dX = EPShared.eplGeoE_NormalizeRadians(_dX - Math.PI / 2.0);
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(point4, point3, ref num2);
                    ReferenceArray profileAtStation;
                    if (!RevitDefines.EQ(_dX, num2))
                    {
                      _dAdjustDistance = Math.Abs(Math.Cos(EPShared.eplGeoE_NormalizeRadians(num2 - _dX)));
                      profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust, true, num2, _dAdjustDistance);
                    }
                    else
                      profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, this.m_IntersectionContainers[index1].Profiles[index2].Station + dOffsetAdjust);
                    if (profileAtStation != null && profileAtStation.Size > 0)
                    {
                      referenceArrayArray2.Append(profileAtStation);
                      referenceArray1 = (ReferenceArray) null;
                    }
                  }
                }
              }
              ++index2;
              if (index2 == this.m_IntersectionContainers[index1].Profiles.Count)
              {
                index2 = 0;
                ++index1;
              }
              flag1 = false;
            }
          }
          _dStation1 += num3;
          if (flag2)
          {
            if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null)
              _dStation1 -= dOffsetAdjust;
            ReferenceArray profileAtStation;
            if (_Leg.Next != null)
            {
              int ArcDir = 0;
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
              if (_Leg.Next.Line != null)
              {
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Line.EndPnt);
              }
              else if (_Leg.Next.Arc != null)
              {
                EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Next.Arc, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Arc.EndPnt);
              }
              if (!RevitDefines.EQ(_dX, num2))
              {
                double num5 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                double SweepAngle = 0.0;
                RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                if (!RevitDefines.EQ(_dX, num1))
                {
                  flag1 = true;
                  _dAdjustDistance = Math.Abs(Math.Cos(num5 / 2.0));
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, true, num1, _dAdjustDistance);
                }
                else
                  profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1);
              }
              else
                profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1);
            }
            else
              profileAtStation = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1);
            if (profileAtStation != null && profileAtStation.Size > 0)
            {
              referenceArrayArray2.Append(profileAtStation);
              referenceArray1 = (ReferenceArray) null;
            }
          }
        }
        if (flag2 && referenceArrayArray2 != null && referenceArrayArray2.Size > 0)
          referenceArrayArray1.Add(referenceArrayArray2);
        ++_nDocIndex;
      }
    }
    return referenceArrayArray1;
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(int _nDocIndex, double _dStation)
  {
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, false, 0.0, 1.0);
  }

  private CurveLoop FindCurveLoopProfileAtStation(int _nDocIndex, double _dStation)
  {
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, false, 0.0, 1.0);
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    CurveLoop profileAtStation = new CurveLoop();
    CurveArray curveArray = new CurveArray();
    try
    {
      Eps_Point epsPoint1 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.LeftEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint2 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.RightEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint3 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.LeftSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint4 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.RightSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, epsPoint3, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint1.XYZ, epsPoint3.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint3, epsPoint4, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint3.XYZ, epsPoint4.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint4, epsPoint2, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint4.XYZ, epsPoint2.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint2, epsPoint1, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint2.XYZ, epsPoint1.XYZ, true);
        curveArray.Append((Curve) line);
      }
      foreach (Curve curve in curveArray)
        profileAtStation.Append(curve);
    }
    catch (Exception ex)
    {
    }
    return profileAtStation;
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    ReferenceArray profileAtStation = new ReferenceArray();
    CurveArray curveArray = new CurveArray();
    try
    {
      Eps_Point epsPoint1 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.LeftEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint2 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.RightEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint3 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.LeftSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint4 = this.CalcTemplateOffsets(SidewalkForm.SidewalkOffsetPoint.RightSubgradeEdge, _dStation, _bUseDirection, _dDirection, _dAdjustDistance);
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, epsPoint3, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint1.XYZ, epsPoint3.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint3, epsPoint4, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint3.XYZ, epsPoint4.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint4, epsPoint2, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint4.XYZ, epsPoint2.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint2, epsPoint1, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint2.XYZ, epsPoint1.XYZ, true);
        curveArray.Append((Curve) line);
      }
      CurveLoop curveLoop = new CurveLoop();
      foreach (Curve curve in curveArray)
        curveLoop.Append(curve);
      SketchPlane sketchPlane = SketchPlane.Create(this.m_MassDocument, curveLoop.GetPlane());
      foreach (Curve curve in curveArray)
      {
        ModelCurve modelCurve = ((ItemFactoryBase) this.m_MassDocument.FamilyCreate).NewModelCurve(curve, sketchPlane);
        profileAtStation.Append(((CurveElement) modelCurve).GeometryCurve.Reference);
      }
    }
    catch (Exception ex)
    {
    }
    return profileAtStation;
  }

  private Eps_Point CalcTemplateOffsets(
    SidewalkForm.SidewalkOffsetPoint _SidewalkOffsetPoint,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    Eps_Point epsPoint = new Eps_Point();
    double num1 = this.m_dWidth / _dAdjustDistance;
    double num2 = 0.0;
    double num3 = 0.0;
    switch (_SidewalkOffsetPoint)
    {
      case SidewalkForm.SidewalkOffsetPoint.LeftEdge:
        num2 = -num1 / 2.0;
        break;
      case SidewalkForm.SidewalkOffsetPoint.LeftSubgradeEdge:
        num2 = -num1 / 2.0;
        num3 = -this.m_dSubgradeDepth;
        break;
      case SidewalkForm.SidewalkOffsetPoint.RightEdge:
        num2 = num1 / 2.0;
        break;
      case SidewalkForm.SidewalkOffsetPoint.RightSubgradeEdge:
        num2 = num1 / 2.0;
        num3 = -this.m_dSubgradeDepth;
        break;
    }
    if (!_bUseDirection)
    {
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation, num2, ref epsPoint);
    }
    else
    {
      Eps_Point Pnt = new Eps_Point();
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation, 0.0, ref Pnt);
      if (num2 < 0.0)
      {
        num2 = Math.Abs(num2);
        _dDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI);
      }
      EPShared.eplGeoE_CalcPolarToXY(Pnt, _dDirection, num2, ref epsPoint);
    }
    epsPoint.z += num3;
    return epsPoint;
  }

  public FamilySymbol SidewalkFamilySymbol => this.m_SidewalkFamilySymbol;

  private enum SidewalkOffsetPoint
  {
    LeftEdge,
    LeftSubgradeEdge,
    RightEdge,
    RightSubgradeEdge,
  }
}
