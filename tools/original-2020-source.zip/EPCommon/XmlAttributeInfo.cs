﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.XmlAttributeInfo
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class XmlAttributeInfo
{
  private string m_strName;
  private string m_strValue;

  public XmlAttributeInfo(string _strName, string _strValue)
  {
    this.m_strName = _strName;
    this.m_strValue = _strValue;
  }

  public XmlAttributeInfo()
  {
  }

  public string Name
  {
    get => this.m_strName;
    set => this.m_strName = value;
  }

  public string Value
  {
    get => this.m_strValue;
    set => this.m_strValue = value;
  }
}
