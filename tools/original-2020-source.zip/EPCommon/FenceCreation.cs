﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FenceCreation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class FenceCreation
{
  private Document m_Document;
  private List<View> m_ViewList;
  private LocateFenceForm m_DisplayForm;
  private List<TopographySurfaceContainer> m_SurfaceList;
  private List<FamilyContainer> m_FamilyList;
  private List<BuiltInCategory> m_CategoryList;
  private EPTransactionContainer m_TransactionContainer;
  private FamilySymbol m_PlacementSymbol;

  public FenceCreation(Document _CurDocument)
  {
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_ViewList = new List<View>();
    this.m_SurfaceList = new List<TopographySurfaceContainer>();
    this.m_FamilyList = new List<FamilyContainer>();
    this.m_CategoryList = new List<BuiltInCategory>();
    this.m_CategoryList.Add((BuiltInCategory) -2000151);
    this.InitializeListData();
  }

  public void PopulateFamilyAndSymbolLists() => this.PopulateFamilyAndSymbolLists(false);

  private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
  {
    this.m_FamilyList.Clear();
    Parameter CurLanddCadID = (Parameter) null;
    FamilySymbol familySymbol1 = (FamilySymbol) null;
    for (int index1 = 0; index1 < this.m_CategoryList.Count; ++index1)
    {
      FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
      source.OfClass(typeof (FamilySymbol)).OfCategory(this.m_CategoryList.ElementAt<BuiltInCategory>(index1));
      List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.Fence).ToString("000"), true) == 0)).ToList<Element>();
      familySymbol1 = (FamilySymbol) null;
      foreach (Element element in list)
      {
        if (element is FamilySymbol familySymbol2 && ((Element) familySymbol2).Category != null && this.m_CategoryList.ElementAt<BuiltInCategory>(index1) == -2000151)
        {
          CurLanddCadID = ((Element) familySymbol2).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
          if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.Fence).ToString("000"), true) == 0)
          {
            bool flag = false;
            for (int index2 = 0; index2 < this.m_FamilyList.Count; ++index2)
            {
              if (string.Compare(this.m_FamilyList[index2].FamilyName, ((Element) familySymbol2.Family).Name, true) == 0)
              {
                this.m_FamilyList[index2].FamilySymbolList.Add(familySymbol2);
                flag = true;
                break;
              }
            }
            if (!flag)
              this.m_FamilyList.Add(new FamilyContainer(((Element) familySymbol2.Family).Name)
              {
                FamilySymbolList = {
                  familySymbol2
                }
              });
          }
        }
      }
    }
    FilteredElementCollector source1 = new FilteredElementCollector(this.m_Document);
    source1.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151);
    CurLanddCadID = (Parameter) null;
    List<Element> list1 = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)).ToList<Element>();
    bool flag1 = false;
    familySymbol1 = (FamilySymbol) null;
    foreach (Element element in list1)
    {
      if (element is FamilySymbol familySymbol3 && ((Element) familySymbol3).Category != null)
      {
        CurLanddCadID = ((Element) familySymbol3).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
        if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) LandcaddID.FamilyInstancePlacement).ToString("000"), true) == 0)
        {
          this.m_PlacementSymbol = familySymbol3;
          flag1 = true;
          break;
        }
      }
    }
    string empty = string.Empty;
    if (_bCheckForFamily && (this.m_FamilyList.Count == 0 || !flag1))
    {
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(this.m_Document.PathName, "LocateFence", EPShared.LocalRM.GetString("FenceFamilyNotLoadedMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("LoadDefaultFamilyOption"),
        EPShared.LocalRM.GetString("ContinueWOLoadFamilyOption")
      });
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamilyOption"), true) == 0)
      {
        Family _Family = (Family) null;
        if (RevitUtility.GetFullFamilyFilenameIfExist("Fence", "Picket Fence.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadFenceFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
            {
              FamilySymbol element = this.m_Document.GetElement(familySymbolId) as FamilySymbol;
              bool flag2 = false;
              for (int index = 0; index < this.m_FamilyList.Count; ++index)
              {
                if (string.Compare(this.m_FamilyList[index].FamilyName, ((Element) element.Family).Name, true) == 0)
                {
                  this.m_FamilyList[index].FamilySymbolList.Add(element);
                  flag2 = true;
                  break;
                }
              }
              if (!flag2)
                this.m_FamilyList.Add(new FamilyContainer(((Element) element.Family).Name)
                {
                  FamilySymbolList = {
                    element
                  }
                });
            }
          }
        }
        if (!flag1 && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
          if (_Family != null && _Family.GetFamilySymbolIds() != null)
          {
            using (IEnumerator<ElementId> enumerator = _Family.GetFamilySymbolIds().GetEnumerator())
            {
              if (enumerator.MoveNext())
                this.m_PlacementSymbol = this.m_Document.GetElement(enumerator.Current) as FamilySymbol;
            }
          }
        }
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index = 0; index < this.m_FamilyList.Count; ++index)
      this.m_FamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  private void InitializeListData()
  {
    this.PopulateFamilyAndSymbolLists(true);
    foreach (View element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (View)).ToElements())
    {
      if (element.GenLevel != null && !this.m_ViewList.Contains(element) && (element.ViewType == 1 || element.ViewType == 115 || element.ViewType == 116) && string.Compare(((Element) element).Name, EPShared.LocalRM.GetString("SiteString"), true) != 0)
      {
        bool flag = false;
        for (int index = 0; index < this.m_ViewList.Count; ++index)
        {
          if (this.m_ViewList[index].ViewType == element.ViewType && string.Compare(((Element) this.m_ViewList[index].GenLevel).UniqueId, ((Element) element.GenLevel).UniqueId, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          this.m_ViewList.Add(element);
      }
    }
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
      this.m_SurfaceList.Add(new TopographySurfaceContainer(this.m_Document.Application, element as TopographySurface));
  }

  private FamilyInstance PlaceSingleOnPoint(
    Eps_Point originPoint,
    List<TopographySurfaceContainer> _SurfaceList)
  {
    this.m_TransactionContainer.BeginTransaction();
    FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(this.m_Document, originPoint.XY, this.m_DisplayForm.Type, RevitUtility.GetSurfaceContainingPoint(originPoint, _SurfaceList), this.m_DisplayForm.Level, (StructuralType) 0, ref this.m_TransactionContainer);
    if (Math.Abs(this.m_DisplayForm.FenceHeight) > 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.FenceFamilyHeightParameter)?.Set(this.m_DisplayForm.FenceHeight);
    if (Math.Abs(this.m_DisplayForm.FenceSpan) > 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.FenceFamilySpanParameter)?.Set(this.m_DisplayForm.FenceSpan);
    Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.FenceRightVisiability);
    Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.FenceLeftVisiability);
    if (parameter1 != null && parameter2 != null)
    {
      parameter1.Set(Convert.ToInt32(true));
      parameter2.Set(Convert.ToInt32(true));
    }
    this.m_TransactionContainer.EndTransaction();
    return familyInstance;
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    if (this.m_FamilyList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_DisplayForm = new LocateFenceForm(this))
    {
      while (_DialogResult == DialogResult.OK)
      {
        flag = this.ShowDialog(ref _DialogResult);
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    return flag;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    int num1 = (int) this.m_DisplayForm.ShowDialog();
    _DialogResult = this.m_DisplayForm.DialogResult;
    if (_DialogResult != DialogResult.OK)
      return false;
    List<TopographySurfaceContainer> _SurfaceList = new List<TopographySurfaceContainer>();
    if (this.m_DisplayForm.PickToposurface)
      _SurfaceList.Add(this.m_DisplayForm.Surface);
    PlacementSettings _PlacementSettings = new PlacementSettings(LocateType.Fence, PlacementType.HedgeRowCenter, this.m_DisplayForm.DeleteExistingChecked, this.m_DisplayForm.ExistingElementChecked, false, this.m_DisplayForm.Level, this.m_DisplayForm.View, this.m_DisplayForm.Type, _SurfaceList, this.m_DisplayForm.SetbackSpacing, this.m_DisplayForm.FenceHeight, 0.0, this.m_DisplayForm.FenceSpan, 0.0, this.m_DisplayForm.FenceSpan, 0.0, this.m_DisplayForm.StartingDistance, this.m_PlacementSymbol, this.m_TransactionContainer);
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocateFenceTransaction"));
    ElementSet _Elements = (ElementSet) null;
    string empty = string.Empty;
    if (!this.m_DisplayForm.ExistingElementChecked)
    {
      string _strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
      ElementSet elm_set = new ElementSet();
      List<ModelCurve> modelCurveList = new List<ModelCurve>();
      Eps_Leg _CurrentLeg = (Eps_Leg) null;
      Eps_Point _Point = (Eps_Point) null;
      Eps_Point epsPoint = (Eps_Point) null;
      bool flag1 = true;
      while (flag1)
      {
        flag1 = RevitUtility.GetPointFromProject(this.m_Document, _strPrompt, ref _Point, false);
        if (flag1)
        {
          if (epsPoint != null)
          {
            Eps_Leg _CompleteLeg = new Eps_Leg();
            _CompleteLeg.Line = new Eps_Line();
            _CompleteLeg.Line.StartPnt = epsPoint;
            _CompleteLeg.Line.EndPnt = _Point;
            if (_CurrentLeg == null)
              _CurrentLeg = Eps_Leg.SingleLeg(_CompleteLeg);
            else
              _CurrentLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
            this.m_TransactionContainer.BeginTransaction();
            modelCurveList.Add(RevitUtility.NewModelCurve(this.m_Document, _CompleteLeg.Line));
            this.m_TransactionContainer.EndTransaction();
            if (this.m_DisplayForm.SegmentChecked)
              flag1 = false;
          }
          else
            _strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
          epsPoint = _Point;
        }
        this.m_Document.Regenerate();
      }
      for (int index = 0; index < modelCurveList.Count; ++index)
        elm_set.Insert((Element) modelCurveList[index]);
      bool flag2 = true;
      if (_CurrentLeg != null)
        flag2 = FenceCommon.PlaceLegList(this.m_Document, _PlacementSettings, _CurrentLeg);
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.EndTransaction();
      return flag2;
    }
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickObjectMessage"), ref _Elements))
      return false;
    foreach (Element element in _Elements)
    {
      LocationCurve location1 = element.Location as LocationCurve;
      Curve _Arc = (Curve) null;
      if (location1 != null)
        _Arc = location1.Curve;
      if (GeometryObject.op_Inequality((GeometryObject) _Arc, (GeometryObject) null))
      {
        Eps_Leg epsLeg1 = (Eps_Leg) null;
        if (location1 != null && this.m_DisplayForm.ChainChecked)
          epsLeg1 = RevitGeometry.GetLegFromElementList((Eps_Leg) null, element);
        if (epsLeg1 != null)
        {
          if (!RevitDefines.GT(this.m_DisplayForm.StartingDistance, RevitGeometry.eplGeoE_CalcLegListLength(epsLeg1)))
            return FenceCommon.PlaceLegList(this.m_Document, _PlacementSettings, epsLeg1);
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
        switch (_Arc)
        {
          case Arc _:
            if (RevitDefines.GT(this.m_DisplayForm.StartingDistance, _Arc.Length))
            {
              int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
            Eps_Arc _EvalArc = new Eps_Arc((Arc) _Arc);
            if (!RevitUtility.EvaluateArc(this.m_Document, this.m_TransactionContainer, this.m_DisplayForm.FenceSpan, ref _EvalArc))
              return false;
            _PlacementSettings.IsReverse = _EvalArc.IsReverse;
            if (RevitDefines.EQ(this.m_DisplayForm.SetbackSpacing, 0.0))
            {
              FenceCommon.PlaceCenterRowOnArc(this.m_Document, _PlacementSettings, element, _EvalArc);
              break;
            }
            Eps_Arc _OffsetArc1 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, this.m_DisplayForm.SetbackSpacing, 1, ref _OffsetArc1);
            Eps_Arc _OffsetArc2 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, this.m_DisplayForm.SetbackSpacing, 2, ref _OffsetArc2);
            ElementSet elm_set1 = new ElementSet();
            if (_OffsetArc1.Radius > 0.0)
            {
              this.m_TransactionContainer.BeginTransaction();
              ModelCurve modelCurve = RevitUtility.NewModelCurve(this.m_Document, _OffsetArc1);
              this.m_TransactionContainer.EndTransaction();
              elm_set1.Insert((Element) modelCurve);
            }
            if (_OffsetArc2.Radius > 0.0)
            {
              this.m_TransactionContainer.BeginTransaction();
              ModelCurve modelCurve = RevitUtility.NewModelCurve(this.m_Document, _OffsetArc2);
              this.m_TransactionContainer.EndTransaction();
              elm_set1.Insert((Element) modelCurve);
            }
            bool _UseRightSide1 = true;
            bool flag3 = RevitUtility.PickSideArc(this.m_Document, _EvalArc, ref _UseRightSide1);
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set1));
            this.m_TransactionContainer.EndTransaction();
            if (!flag3)
              return false;
            _PlacementSettings.UseRightSide = _UseRightSide1;
            if (_UseRightSide1)
            {
              FenceCommon.PlaceCenterRowOnArc(this.m_Document, _PlacementSettings, element, _OffsetArc1);
              break;
            }
            FenceCommon.PlaceCenterRowOnArc(this.m_Document, _PlacementSettings, element, _OffsetArc2);
            break;
          case Line _:
            if (RevitDefines.GT(this.m_DisplayForm.StartingDistance, _Arc.Length))
            {
              int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
            Eps_Line _EvalLine = new Eps_Line();
            _EvalLine.StartPnt = new Eps_Point(_Arc.GetEndPoint(0));
            _EvalLine.EndPnt = new Eps_Point(_Arc.GetEndPoint(1));
            if (!RevitUtility.EvaluateLine(this.m_Document, this.m_TransactionContainer, this.m_DisplayForm.FenceSpan, ref _EvalLine))
              return false;
            _PlacementSettings.IsReverse = _EvalLine.IsReverse;
            if (this.m_DisplayForm.SetbackSpacing == 0.0)
            {
              FenceCommon.PlaceCenterRowOnLine(this.m_Document, _PlacementSettings, element, _EvalLine);
              break;
            }
            Eps_Line _OffsetLine1 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, this.m_DisplayForm.SetbackSpacing, 1, ref _OffsetLine1);
            Eps_Line _OffsetLine2 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, this.m_DisplayForm.SetbackSpacing, 2, ref _OffsetLine2);
            this.m_TransactionContainer.BeginTransaction();
            ModelCurve modelCurve1 = RevitUtility.NewModelCurve(this.m_Document, _OffsetLine1);
            ModelCurve modelCurve2 = RevitUtility.NewModelCurve(this.m_Document, _OffsetLine2);
            this.m_TransactionContainer.EndTransaction();
            this.m_Document.Regenerate();
            bool _UseRightSide2 = true;
            bool flag4 = RevitUtility.PickSideLine(this.m_Document, _EvalLine, ref _UseRightSide2);
            ElementSet elm_set2 = new ElementSet();
            elm_set2.Insert((Element) modelCurve1);
            elm_set2.Insert((Element) modelCurve2);
            this.m_TransactionContainer.BeginTransaction();
            this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set2));
            this.m_TransactionContainer.EndTransaction();
            if (!flag4)
              return false;
            _PlacementSettings.UseRightSide = _UseRightSide2;
            if (_UseRightSide2)
            {
              FenceCommon.PlaceCenterRowOnLine(this.m_Document, _PlacementSettings, element, _OffsetLine1);
              break;
            }
            FenceCommon.PlaceCenterRowOnLine(this.m_Document, _PlacementSettings, element, _OffsetLine2);
            break;
          case Ellipse _:
          case NurbSpline _:
          case HermiteSpline _:
            IList<XYZ> xyzList = _Arc.Tessellate();
            int count = xyzList.Count;
            if (count > 1)
            {
              Eps_Point epsPoint1 = new Eps_Point();
              Eps_Point epsPoint2 = new Eps_Point();
              epsLeg1 = (Eps_Leg) null;
              int index;
              for (index = 0; index < count; index += 2)
              {
                Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
                if (index > 0)
                {
                  Eps_Leg epsLeg2 = new Eps_Leg();
                  epsLeg2.Line = new Eps_Line();
                  epsLeg2.Line.StartPnt = epsPoint1;
                  epsLeg2.Line.EndPnt = epsPoint3;
                  if (epsLeg1 == null)
                  {
                    epsLeg1 = epsLeg2;
                    epsLeg1.Element = element;
                  }
                  else
                  {
                    epsLeg1.Last.Next = epsLeg2;
                    epsLeg1.Last.Element = element;
                  }
                }
                epsPoint1 = epsPoint3;
              }
              if (index == count)
              {
                Eps_Leg epsLeg3 = new Eps_Leg();
                epsLeg3.Line = new Eps_Line();
                epsLeg3.Line.StartPnt = epsPoint1;
                epsLeg3.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
                if (epsLeg1 == null)
                {
                  epsLeg1 = epsLeg3;
                  epsLeg1.Element = element;
                }
                else
                {
                  epsLeg1.Last.Next = epsLeg3;
                  epsLeg1.Last.Element = element;
                }
              }
            }
            if (RevitDefines.GT(this.m_DisplayForm.StartingDistance, RevitGeometry.eplGeoE_CalcLegListLength(epsLeg1)))
            {
              int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return false;
            }
            if (!FenceCommon.PlaceLegList(this.m_Document, _PlacementSettings, epsLeg1))
              return false;
            break;
          default:
            int num6 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return false;
        }
        if (this.m_DisplayForm.DeleteExistingChecked)
        {
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete(element.Id);
          this.m_TransactionContainer.EndTransaction();
        }
      }
      else if (element.Location is LocationPoint location2)
      {
        this.PlaceSingleOnPoint(new Eps_Point(location2.Point), _PlacementSettings.SurfaceList);
        if (this.m_DisplayForm.DeleteExistingChecked)
        {
          this.m_TransactionContainer.BeginTransaction();
          this.m_Document.Delete(element.Id);
          this.m_TransactionContainer.EndTransaction();
        }
      }
      else
      {
        int num7 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    return true;
  }

  public ReadOnlyCollection<View> Views
  {
    get => new ReadOnlyCollection<View>((IList<View>) this.m_ViewList);
  }

  public Document Document => this.m_Document;

  public ReadOnlyCollection<FamilyContainer> FamilyList
  {
    get => new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_FamilyList);
  }

  public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList
  {
    get
    {
      return new ReadOnlyCollection<TopographySurfaceContainer>((IList<TopographySurfaceContainer>) this.m_SurfaceList);
    }
  }

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }
}
