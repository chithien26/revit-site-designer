using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;

namespace EPCommon;

public class ConvertPlant
{
	private Document m_Document;

	private List<Autodesk.Revit.DB.View> m_ViewList;

	private ConvertPlantForm m_DisplayForm;

	private List<TopographySurfaceContainer> m_SurfaceList;

	private List<FamilyContainer> m_PlantFamilyList;

	private EPTransactionContainer m_TransactionContainer;

	public ReadOnlyCollection<Autodesk.Revit.DB.View> Views => new ReadOnlyCollection<Autodesk.Revit.DB.View>(m_ViewList);

	public Document Document => m_Document;

	public ReadOnlyCollection<FamilyContainer> PlantFamilyList => new ReadOnlyCollection<FamilyContainer>(m_PlantFamilyList);

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public ConvertPlant(Document _CurDocument)
	{
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_ViewList = new List<Autodesk.Revit.DB.View>();
		m_SurfaceList = new List<TopographySurfaceContainer>();
		m_PlantFamilyList = new List<FamilyContainer>();
		InitializeListData();
	}

	public void PopulateFamilyAndSymbolLists()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: false);
	}

	public void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
	{
		int num = 0;
		m_PlantFamilyList.Clear();
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		FilteredElementIterator elementIterator = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_Planting).GetElementIterator();
		filteredElementCollector = new FilteredElementCollector(m_Document);
		List<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements()
			.ToList();
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
		Eps_Point eps_Point = new Eps_Point();
		FamilySymbol familySymbol = null;
		FamilyInstance familyInstance = null;
		List<Eps_Point> list2 = null;
		LocationPoint locationPoint = null;
		Eps_Point eps_Point2 = null;
		elementIterator.Reset();
		while (elementIterator.MoveNext())
		{
			if (!(elementIterator.Current is FamilySymbol { Category: not null } familySymbol2) || familySymbol2.Category.Id.Value64() != BuiltInCategory.OST_Planting.GetHashCode())
			{
				continue;
			}
			list2 = null;
			foreach (Element item in list)
			{
				if (item is FamilyInstance { Symbol: not null } familyInstance2 && familyInstance2.Symbol.Category != null && familyInstance2.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(familySymbol2.UniqueId, familyInstance2.Symbol.UniqueId, ignoreCase: true) == 0)
				{
					if (list2 == null)
					{
						list2 = new List<Eps_Point>();
					}
					locationPoint = familyInstance2.Location as LocationPoint;
					eps_Point2 = new Eps_Point(locationPoint.Point);
					if (!RevitUtility.IsPointInPointList(eps_Point2, list2))
					{
						list2.Add(eps_Point2);
					}
				}
			}
			if (list2 != null && list2.Count > 0)
			{
				bool flag = true;
				while (flag)
				{
					flag = false;
					for (int i = 0; i < list2.Count; i++)
					{
						if (EPShared.eplGeoE_ArePntsDuplicates3D(list2[i], eps_Point))
						{
							eps_Point.z++;
							flag = true;
							break;
						}
					}
				}
			}
			bool flag2 = false;
			for (num = 0; num < m_PlantFamilyList.Count; num++)
			{
				if (string.Compare(m_PlantFamilyList[num].FamilyName, familySymbol2.Family.Name, ignoreCase: true) == 0)
				{
					m_PlantFamilyList[num].FamilySymbolList.Add(familySymbol2);
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				FamilyContainer familyContainer = new FamilyContainer(familySymbol2.Family.Name);
				familyContainer.FamilySymbolList.Add(familySymbol2);
				m_PlantFamilyList.Add(familyContainer);
			}
		}
		m_TransactionContainer.Rollback();
		filteredElementCollector = new FilteredElementCollector(m_Document);
		elementIterator = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_PlantingTags).GetElementIterator();
		bool flag3 = false;
		elementIterator.Reset();
		while (elementIterator.MoveNext())
		{
			if (elementIterator.Current is FamilySymbol { Category: not null } familySymbol3 && familySymbol3.Category.Id.Value64() == BuiltInCategory.OST_PlantingTags.GetHashCode())
			{
				flag3 = true;
				break;
			}
		}
		string _strFullFamilyFilename = string.Empty;
		if (_bCheckForFamily && (m_PlantFamilyList.Count == 0 || !flag3))
		{
			List<string> list3 = new List<string>();
			list3.Add(EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"));
			list3.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, "ConvertPlants", EPShared.LocalRM.GetString("PlantingTagFamiliesNotLoadedMessage"), list3);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), ignoreCase: true) == 0)
			{
				if (m_PlantFamilyList.Count == 0)
				{
					Family _Family = null;
					if (RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Conifer", "LC Conifers.rfa", ref _strFullFamilyFilename))
					{
						m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
						RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
						m_TransactionContainer.Commit();
						if (_Family != null && _Family.GetFamilySymbolIds() != null)
						{
							foreach (ElementId familySymbolId in _Family.GetFamilySymbolIds())
							{
								if (!(m_Document.GetElement(familySymbolId) is FamilySymbol familySymbol4))
								{
									continue;
								}
								bool flag4 = false;
								for (num = 0; num < m_PlantFamilyList.Count; num++)
								{
									if (string.Compare(m_PlantFamilyList[num].FamilyName, familySymbol4.Family.Name, ignoreCase: true) == 0)
									{
										m_PlantFamilyList[num].FamilySymbolList.Add(familySymbol4);
										flag4 = true;
										break;
									}
								}
								if (!flag4)
								{
									FamilyContainer familyContainer2 = new FamilyContainer(familySymbol4.Family.Name);
									familyContainer2.FamilySymbolList.Add(familySymbol4);
									m_PlantFamilyList.Add(familyContainer2);
								}
							}
						}
					}
				}
				if (!flag3 && RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Tags", "LC Plant Tags - Single Line.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantingTagFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
				}
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		for (num = 0; num < m_PlantFamilyList.Count; num++)
		{
			m_PlantFamilyList[num].FamilySymbolList.Sort(comparer);
		}
	}

	private void InitializeListData()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: true);
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(Autodesk.Revit.DB.View)).ToElements();
		foreach (Autodesk.Revit.DB.View item in list)
		{
			if (item.GenLevel == null || m_ViewList.Contains(item) || (item.ViewType != ViewType.FloorPlan && item.ViewType != ViewType.EngineeringPlan && item.ViewType != ViewType.AreaPlan) || string.Compare(item.Name, EPShared.LocalRM.GetString("SiteString"), ignoreCase: true) == 0)
			{
				continue;
			}
			bool flag = false;
			for (int i = 0; i < m_ViewList.Count; i++)
			{
				if (string.Compare(m_ViewList[i].GenLevel.UniqueId, item.GenLevel.UniqueId, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				m_ViewList.Add(item);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list2 = filteredElementCollector.OfClass(typeof(TopographySurface)).OfCategory(BuiltInCategory.OST_Topography).ToElements();
		foreach (Element item2 in list2)
		{
			TopographySurface topographySurface = item2 as TopographySurface;
			m_SurfaceList.Add(new TopographySurfaceContainer(m_Document.Application, topographySurface));
		}
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		bool flag = false;
		if (m_PlantFamilyList.Count <= 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new ConvertPlantForm(this))
		{
			while (_DialogResult == DialogResult.OK)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool GetSinglePoint(ref ElementSet _ArcSet, ref List<Eps_Arc> _ArcList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickCircleMessage"), ref _Elements, _bDisplayError: true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		m_Document.Regenerate();
		foreach (Element item in _Elements)
		{
			if (!(item.Location is LocationCurve { Curve: var curve }))
			{
				continue;
			}
			if ((curve is Arc || curve is Ellipse) && !curve.IsBound)
			{
				Eps_Arc eps_Arc = null;
				if (curve is Arc)
				{
					Arc arc = (Arc)curve;
					eps_Arc = new Eps_Arc(arc);
				}
				else if (curve is Ellipse)
				{
					Ellipse ellipse = (Ellipse)curve;
					eps_Arc = new Eps_Arc();
					IList<XYZ> list = ellipse.Tessellate();
					if (list.Count > 0)
					{
						eps_Arc.StartPnt = new Eps_Point(list[0]);
						eps_Arc.EndPnt = new Eps_Point(list[list.Count - 1]);
					}
					eps_Arc.RadiusPnt = new Eps_Point(ellipse.Center);
					if (ellipse.Normal.Z > 0.0)
					{
						eps_Arc.Direction = 1;
					}
					else
					{
						eps_Arc.Direction = -1;
					}
					if (ellipse.RadiusX < ellipse.RadiusY)
					{
						eps_Arc.Radius = ellipse.RadiusX;
					}
					else
					{
						eps_Arc.Radius = ellipse.RadiusY;
					}
					eps_Arc.Delta = ellipse.Length / eps_Arc.Radius;
				}
				if (!RevitUtility.IsArcInArcList(eps_Arc, _ArcList))
				{
					_ArcList.Add(eps_Arc);
					_ArcSet.Insert(item);
				}
				else
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("CircleAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				}
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportConvertPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		if (_ArcList == null || _ArcList.Count == 0)
		{
			return false;
		}
		return true;
	}

	private bool GetWindowPoints(ref ElementSet _ArcSet, ref List<Eps_Arc> _ArcList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickCircleMessage"), ref _Elements, _bDisplayError: true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		m_Document.Regenerate();
		foreach (Element item in _Elements)
		{
			if (!(item.Location is LocationCurve { Curve: var curve }) || (!(curve is Arc) && !(curve is Ellipse)) || curve.IsBound)
			{
				continue;
			}
			Eps_Arc eps_Arc = null;
			if (curve is Arc)
			{
				Arc arc = (Arc)curve;
				eps_Arc = new Eps_Arc(arc);
			}
			else if (curve is Ellipse)
			{
				Ellipse ellipse = (Ellipse)curve;
				eps_Arc = new Eps_Arc();
				IList<XYZ> list = ellipse.Tessellate();
				if (list.Count > 0)
				{
					eps_Arc.StartPnt = new Eps_Point(list[0]);
					eps_Arc.EndPnt = new Eps_Point(list[list.Count - 1]);
				}
				eps_Arc.RadiusPnt = new Eps_Point(ellipse.Center);
				if (ellipse.Normal.Z > 0.0)
				{
					eps_Arc.Direction = 1;
				}
				else
				{
					eps_Arc.Direction = -1;
				}
				if (ellipse.RadiusX < ellipse.RadiusY)
				{
					eps_Arc.Radius = ellipse.RadiusX;
				}
				else
				{
					eps_Arc.Radius = ellipse.RadiusY;
				}
				eps_Arc.Delta = ellipse.Length / eps_Arc.Radius;
			}
			if (!RevitUtility.IsArcInArcList(eps_Arc, _ArcList))
			{
				_ArcList.Add(eps_Arc);
				_ArcSet.Insert(item);
			}
		}
		if (_ArcList == null || _ArcList.Count == 0)
		{
			return false;
		}
		return true;
	}

	private bool GetAllPoints(ref ElementSet _ArcSet, ref List<Eps_Arc> _ArcList)
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(CurveElement)).OfCategory(BuiltInCategory.OST_Lines).ToElements();
		if (list == null || list.Count == 0)
		{
			return false;
		}
		m_Document.Regenerate();
		foreach (Element item in list)
		{
			if (!(item.Location is LocationCurve { Curve: var curve }) || (!(curve is Arc) && !(curve is Ellipse)) || curve.IsBound)
			{
				continue;
			}
			Eps_Arc eps_Arc = null;
			if (curve is Arc)
			{
				Arc arc = (Arc)curve;
				eps_Arc = new Eps_Arc(arc);
			}
			else if (curve is Ellipse)
			{
				Ellipse ellipse = (Ellipse)curve;
				eps_Arc = new Eps_Arc();
				IList<XYZ> list2 = ellipse.Tessellate();
				if (list2.Count > 0)
				{
					eps_Arc.StartPnt = new Eps_Point(list2[0]);
					eps_Arc.EndPnt = new Eps_Point(list2[list2.Count - 1]);
				}
				eps_Arc.RadiusPnt = new Eps_Point(ellipse.Center);
				if (ellipse.Normal.Z > 0.0)
				{
					eps_Arc.Direction = 1;
				}
				else
				{
					eps_Arc.Direction = -1;
				}
				if (ellipse.RadiusX < ellipse.RadiusY)
				{
					eps_Arc.Radius = ellipse.RadiusX;
				}
				else
				{
					eps_Arc.Radius = ellipse.RadiusY;
				}
				eps_Arc.Delta = ellipse.Length / eps_Arc.Radius;
			}
			if (!RevitUtility.IsArcInArcList(eps_Arc, _ArcList))
			{
				_ArcList.Add(eps_Arc);
				_ArcSet.Insert(item);
			}
		}
		if (_ArcList == null || _ArcList.Count == 0)
		{
			return false;
		}
		return true;
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult != DialogResult.OK)
		{
			return false;
		}
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("ConvertPlantsTransaction"));
		ElementSet _ArcSet = new ElementSet();
		List<Eps_Arc> _ArcList = new List<Eps_Arc>();
		if (m_DisplayForm.SelectionSetChecked)
		{
			if (!GetSinglePoint(ref _ArcSet, ref _ArcList))
			{
				return false;
			}
		}
		else if (m_DisplayForm.WindowSelectChecked)
		{
			if (!GetWindowPoints(ref _ArcSet, ref _ArcList))
			{
				return false;
			}
		}
		else if (m_DisplayForm.AllCirclesChecked && !GetAllPoints(ref _ArcSet, ref _ArcList))
		{
			return false;
		}
		bool flag = true;
		ElementSet elementSet = new ElementSet();
		ProgressBarForm progressBarForm = new ProgressBarForm();
		progressBarForm.MinValue = 0;
		progressBarForm.MaxValue = _ArcList.Count;
		if (_ArcList.Count <= 0)
		{
			progressBarForm.MaxValue = 10000;
		}
		progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarConvertingPlantsMessage");
		progressBarForm.ShowForm();
		progressBarForm.Refresh();
		double num = 0.0;
		m_TransactionContainer.BeginTransaction();
		for (int i = 0; i < _ArcList.Count; i++)
		{
			FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(m_Document, _ArcList[i].RadiusPnt.XY, m_DisplayForm.Type, RevitUtility.GetSurfaceContainingPoint(_ArcList[i].RadiusPnt, m_SurfaceList), m_DisplayForm.Level, StructuralType.NonStructural, ref m_TransactionContainer);
			if (2.0 * _ArcList[i].Radius > 0.0 && flag)
			{
				Parameter parameter = familyInstance.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
				if (parameter != null)
				{
					parameter.Set(2.0 * _ArcList[i].Radius);
				}
				else
				{
					flag = false;
				}
			}
			if (num < 4.0 * _ArcList[i].Radius)
			{
				num = 4.0 * _ArcList[i].Radius;
			}
			elementSet.Insert(familyInstance);
			progressBarForm.UpdateProgressBar(1);
		}
		m_TransactionContainer.EndTransaction();
		if (m_DisplayForm.DeleteExistingChecked)
		{
			m_TransactionContainer.BeginTransaction();
			m_Document.Delete(ElementSetConverter.ToIDList(_ArcSet));
			m_TransactionContainer.EndTransaction();
		}
		if (!elementSet.IsEmpty)
		{
			PlantCommon.CreateTag(m_Document, m_TransactionContainer, m_DisplayForm.View, elementSet, num, m_DisplayForm.PlaceGroupTagChecked, m_DisplayForm.LeaderedTagChecked, _bCreateTag: true);
		}
		progressBarForm.SetMaxValue();
		Thread.Sleep(300);
		progressBarForm.Close();
		return true;
	}
}
