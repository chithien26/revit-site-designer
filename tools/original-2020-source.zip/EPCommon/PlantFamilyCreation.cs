﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantFamilyCreation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantFamilyCreation
{
  private Document m_CurDocument;

  public PlantFamilyCreation(Document _CurDocument) => this.m_CurDocument = _CurDocument;

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    using (PlantViewForm plantViewForm = new PlantViewForm(this.m_CurDocument))
    {
      int num = (int) plantViewForm.ShowDialog();
      return DialogResult.OK == plantViewForm.DialogResult;
    }
  }
}
