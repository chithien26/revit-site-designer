﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantGrowthListView
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantGrowthListView : ListView
{
  private ListViewItem m_ListItem;
  private int m_nX;
  private int m_nY;
  private string m_strSubItemText;
  private int m_nSubItemSelected;
  private TextBox m_EditBox = new TextBox();
  private ComboBox m_CmbBox = new ComboBox();
  private bool m_bKeyBoard;
  private bool m_bHandleListViewItem = true;

  public event ListViewItemChanged OnListViewItemChanged;

  public PlantGrowthListView()
  {
    this.Dock = DockStyle.None;
    this.FullRowSelect = true;
    this.MaximumSize = new Size(430, 94);
    this.Name = nameof (PlantGrowthListView);
    this.Size = new Size(430, 94);
    this.Location = new Point(9, 54);
    this.TabIndex = 0;
    this.View = View.Details;
    this.MouseDown += new MouseEventHandler(this.ListViewMouseDown);
    this.KeyDown += new KeyEventHandler(this.ListViewKeyDown);
    this.Click += new EventHandler(this.ListViewSingleClick);
    this.GridLines = true;
    this.Scrollable = false;
    this.OwnerDraw = false;
    this.m_EditBox.Size = new Size(0, 0);
    this.m_EditBox.Location = new Point(0, 0);
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_EditBox
    });
    this.m_EditBox.KeyPress += new KeyPressEventHandler(this.EditOver);
    this.m_EditBox.LostFocus += new EventHandler(this.FocusOver);
    this.m_EditBox.BackColor = Color.White;
    this.m_EditBox.BorderStyle = BorderStyle.Fixed3D;
    this.m_EditBox.Hide();
    this.m_EditBox.Text = "";
    this.Controls.AddRange(new Control[1]
    {
      (Control) this.m_CmbBox
    });
    this.m_CmbBox.SelectedIndexChanged += new EventHandler(this.CmbSelected);
    this.m_CmbBox.LostFocus += new EventHandler(this.CmbFocusOver);
    this.m_CmbBox.KeyPress += new KeyPressEventHandler(this.CmbKeyPress);
    this.m_CmbBox.BackColor = Color.White;
    this.m_CmbBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_CmbBox.Hide();
  }

  private void EditOver(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar == '\r')
    {
      e.Handled = true;
      if (this.m_bHandleListViewItem)
      {
        this.m_bHandleListViewItem = false;
        this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_EditBox.Text;
        if (this.OnListViewItemChanged != null)
          this.OnListViewItemChanged(this.m_ListItem.Index);
        this.m_EditBox.Hide();
        this.m_bHandleListViewItem = true;
      }
    }
    else if (e.KeyChar == '\t' && this.m_bHandleListViewItem)
    {
      this.m_bHandleListViewItem = false;
      this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_EditBox.Text;
      if (this.OnListViewItemChanged != null)
        this.OnListViewItemChanged(this.m_ListItem.Index);
      this.m_EditBox.Hide();
      this.m_bHandleListViewItem = true;
    }
    if (e.KeyChar != '\u001B')
      return;
    this.m_EditBox.Hide();
  }

  private void FocusOver(object sender, EventArgs e)
  {
    if (!this.m_bHandleListViewItem)
      return;
    this.m_bHandleListViewItem = false;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_EditBox.Text;
    if (this.OnListViewItemChanged != null)
      this.OnListViewItemChanged(this.m_ListItem.Index);
    this.m_EditBox.Hide();
    this.Refresh();
    this.FocusedItem = this.SelectedItems[0];
    this.Focus();
    this.m_bHandleListViewItem = true;
  }

  public void ListViewSingleClick(object sender, EventArgs e) => this.Draw();

  private void Draw()
  {
    int num = 0;
    int width1 = this.Columns[0].Width;
    if (!this.m_bKeyBoard)
    {
      int nX = this.m_nX;
      for (int index = 0; index < this.Columns.Count; ++index)
      {
        if (nX > num && nX < width1)
        {
          this.m_nSubItemSelected = index;
          break;
        }
        num = width1;
        width1 += this.Columns[index].Width;
      }
      if (this.m_nSubItemSelected == 0)
        return;
    }
    else
    {
      num = width1;
      width1 += this.Columns[1].Width;
      this.m_nSubItemSelected = 1;
    }
    if (string.Compare(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"), this.m_ListItem.SubItems[0].Text, true) == 0 || string.Compare(string.Empty, this.m_ListItem.SubItems[0].Text, true) == 0)
      return;
    this.m_strSubItemText = this.m_ListItem.SubItems[this.m_nSubItemSelected].Text;
    string text1 = this.Columns[this.m_nSubItemSelected].Text;
    string text2 = this.m_ListItem.SubItems[0].Text;
    Rectangle rectangle;
    ref Rectangle local = ref rectangle;
    int x1 = num;
    Rectangle bounds = this.m_ListItem.Bounds;
    int y1 = bounds.Y;
    int width2 = width1;
    bounds = this.m_ListItem.Bounds;
    int bottom = bounds.Bottom;
    local = new Rectangle(x1, y1, width2, bottom);
    this.m_EditBox.Size = new Size(this.Columns[this.m_nSubItemSelected].Width, rectangle.Height);
    TextBox editBox = this.m_EditBox;
    int x2 = num;
    bounds = this.m_ListItem.Bounds;
    int y2 = bounds.Y - 4;
    Point point = new Point(x2, y2);
    editBox.Location = point;
    this.m_EditBox.Show();
    this.m_EditBox.Text = this.m_strSubItemText;
    this.m_EditBox.SelectAll();
    this.m_EditBox.Focus();
  }

  public void SetFocus(int _nIndex)
  {
    this.Refresh();
    Rectangle rectangle;
    ref Rectangle local = ref rectangle;
    Rectangle bounds1 = this.m_ListItem.SubItems[1].Bounds;
    int x1 = bounds1.X;
    bounds1 = this.m_ListItem.SubItems[1].Bounds;
    int y1 = bounds1.Y;
    int width = this.Columns[0].Width + this.Columns[this.m_nSubItemSelected].Width;
    bounds1 = this.m_ListItem.SubItems[1].Bounds;
    int bottom = bounds1.Bottom;
    local = new Rectangle(x1, y1, width, bottom);
    this.m_EditBox.Size = new Size(this.Columns[this.m_nSubItemSelected].Width, rectangle.Height);
    TextBox editBox = this.m_EditBox;
    Rectangle bounds2 = this.m_ListItem.SubItems[1].Bounds;
    int x2 = bounds2.X;
    bounds2 = this.m_ListItem.SubItems[1].Bounds;
    int y2 = bounds2.Y - 4;
    Point point = new Point(x2, y2);
    editBox.Location = point;
    this.m_EditBox.Text = string.Empty;
    this.m_EditBox.Show();
    this.m_EditBox.SelectAll();
    this.m_EditBox.Focus();
  }

  public void ListViewMouseDown(object sender, MouseEventArgs e)
  {
    this.m_ListItem = this.GetItemAt(e.X, e.Y);
    this.m_nX = e.X;
    this.m_nY = e.Y;
    this.m_bKeyBoard = false;
  }

  private void ListViewKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    this.m_bKeyBoard = true;
    Rectangle itemRect = this.GetItemRect(this.SelectedIndices[0]);
    this.m_nX = itemRect.X + this.Columns[1].Width;
    this.m_nY = itemRect.Y;
    this.m_ListItem = this.FindItemWithText(this.SelectedItems[0].Text);
    this.Draw();
  }

  private void CmbKeyPress(object sender, KeyPressEventArgs e)
  {
    if (e.KeyChar != '\r' && e.KeyChar != '\u001B')
      return;
    this.m_CmbBox.Hide();
  }

  private void CmbSelected(object sender, EventArgs e)
  {
    int selectedIndex = this.m_CmbBox.SelectedIndex;
    if (selectedIndex < 0)
      return;
    this.m_ListItem.SubItems[this.m_nSubItemSelected].Text = this.m_CmbBox.Items[selectedIndex].ToString();
    this.m_CmbBox.Hide();
    if (this.OnListViewItemChanged == null)
      return;
    this.OnListViewItemChanged(this.m_ListItem.Index);
  }

  private void CmbFocusOver(object sender, EventArgs e)
  {
    this.m_CmbBox.Hide();
    this.Focus();
  }

  public ComboBox CmbBox
  {
    get => this.m_CmbBox;
    set => this.m_CmbBox = value;
  }

  public ListViewItem CurrListItem
  {
    get => this.m_ListItem;
    set => this.m_ListItem = value;
  }
}
