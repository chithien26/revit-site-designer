﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.MathUtil
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public static class MathUtil
{
  public static XYZ[] MultiCross(XYZ[] m1, XYZ[] m2)
  {
    XYZ[] xyzArray = new XYZ[3];
    for (int index = 0; index < 3; ++index)
      xyzArray[index] = new XYZ();
    for (int index1 = 0; index1 < 3; ++index1)
    {
      for (int index2 = 0; index2 < 3; ++index2)
      {
        for (int index3 = 0; index3 < 3; ++index3)
        {
          switch (index2)
          {
            case 0:
              xyzArray[index1] = new XYZ(xyzArray[index1].X + m1[index1][index3] * m2[index3][index2], xyzArray[index1].Y, xyzArray[index1].Z);
              break;
            case 1:
              xyzArray[index1] = new XYZ(xyzArray[index1].X, xyzArray[index1].Y + m1[index1][index3] * m2[index3][index2], xyzArray[index1].Z);
              break;
            case 2:
              xyzArray[index1] = new XYZ(xyzArray[index1].X, xyzArray[index1].Y, xyzArray[index1].Z + m1[index1][index3] * m2[index3][index2]);
              break;
          }
        }
      }
    }
    return xyzArray;
  }

  public static XYZ SubXYZ(XYZ lhs, XYZ rhs)
  {
    return new XYZ(lhs.X - rhs.X, lhs.Y - rhs.Y, lhs.Z - rhs.Z);
  }

  public static XYZ AddXYZ(XYZ lhs, XYZ rhs)
  {
    return new XYZ(lhs.X + rhs.X, lhs.Y + rhs.Y, lhs.Z + rhs.Z);
  }

  public static XYZ DivideXYZ(XYZ lhs, double rhs)
  {
    return new XYZ(lhs.X / rhs, lhs.Y / rhs, lhs.Z / rhs);
  }

  public static XYZ GetBasis(XYZ point, Transform transform)
  {
    double x = point.X;
    double y = point.Y;
    double z = point.Z;
    XYZ xyz1 = transform[0];
    XYZ xyz2 = transform[1];
    XYZ xyz3 = transform[2];
    XYZ origin = transform.Origin;
    return new XYZ(x * xyz1.X + y * xyz2.X + z * xyz3.X + origin.X, x * xyz1.Y + y * xyz2.Y + z * xyz3.Y + origin.Y, x * xyz1.Z + y * xyz2.Z + z * xyz3.Z + origin.Z);
  }

  public static XYZ Vector2XYZ(Vector v) => new XYZ(v.X, v.Y, v.Z);

  public static Vector XYZ2Vector(XYZ pnt) => new Vector(pnt.X, pnt.Y, pnt.Z);
}
