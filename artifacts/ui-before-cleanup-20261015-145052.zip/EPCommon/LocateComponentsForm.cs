using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class LocateComponentsForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private ComponentCreation m_dataBuffer;

	private Autodesk.Revit.DB.View m_CurView;

	private FamilySymbol m_CurType;

	private FormatOptions m_FormatOptions;

	private FormatOptions m_AngularOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private UnitSymbolType m_AngularSymbolType;

	private DecimalSymbol m_DecimalSymbolType;

	private double m_dAngularRounding;

	private IContainer components;

	private Label m_ComponentFamilyLabel;

	private ComboBox m_ComponentFamilyComboBox;

	private ComboBox m_LevelComboBox;

	private Label m_LevelLabel;

	private RadioButton m_HedgeRowRadioButton;

	private Label m_ComponentNameLabel;

	private ComboBox m_ComponentNameComboBox;

	private Label m_ComponentSpacingLabel;

	private TextBox m_PlantSpacingTextBox;

	private Label m_SetbackLabel;

	private TextBox m_SetbackTextBox;

	private RadioButton m_GroveRadioButton;

	private System.Windows.Forms.Panel m_HedgeRowPanel;

	private RadioButton m_SideHedgeRadioButton;

	private RadioButton m_AlternateHedgeRadioButton;

	private RadioButton m_CenterHedgeRadioButton;

	private System.Windows.Forms.Panel m_GrovePanel;

	private RadioButton m_SquareRadioButton;

	private RadioButton m_TriangularRadioButton;

	private Label m_RotationLabel;

	private TextBox m_RotationTextBox;

	private CheckBox m_AlignToCheckBox;

	private Button m_LoadFamilyButton;

	private CheckBox m_ExistingElementCheckBox;

	private System.Windows.Forms.Panel m_MoveablePanel;

	private CheckBox m_DeleteExistingCheckBox;

	private Button m_CancelButton;

	private Button m_InsertButton;

	private RadioButton m_ChainRadioButton;

	private RadioButton m_SegmentRadioButton;

	private Label m_StartingDistanceLabel;

	private TextBox m_StartingDistanceTextBox;

	private System.Windows.Forms.Panel m_ToposurfacePickerPanel;

	private Label m_SelectedSurfaceLabel;

	private CheckBox m_ToposurfaceCheckBox;

	private ComboBox m_SurfaceList;

	private System.Windows.Forms.Panel m_SegmentChainPanel;

	public bool HedgeRowChecked => m_HedgeRowRadioButton.Checked;

	public bool GroveChecked => m_GroveRadioButton.Checked;

	public bool TriangularGroveChecked => m_TriangularRadioButton.Checked;

	public bool SquareGroveChecked => m_SquareRadioButton.Checked;

	public bool CenteredHedgeRowChecked => m_CenterHedgeRadioButton.Checked;

	public bool AlternateHedgeRowChecked => m_AlternateHedgeRadioButton.Checked;

	public bool SideHedgeRadioButton => m_SideHedgeRadioButton.Checked;

	public bool ExistingElementChecked => m_ExistingElementCheckBox.Checked;

	public bool DeleteExistingChecked
	{
		get
		{
			if (!m_ExistingElementCheckBox.Checked)
			{
				return false;
			}
			return m_DeleteExistingCheckBox.Checked;
		}
	}

	public double StartingDistance
	{
		get
		{
			if (!m_HedgeRowRadioButton.Checked || !m_ExistingElementCheckBox.Checked)
			{
				return 0.0;
			}
			double _dReturnedDouble = 0.0;
			if (m_StartingDistanceTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool AlignTo => m_AlignToCheckBox.Checked;

	public Level Level => m_CurView.GenLevel;

	public Autodesk.Revit.DB.View View => m_CurView;

	public FamilySymbol Type => m_CurType;

	public double RotationAngle
	{
		get
		{
			double result = 0.0;
			if (m_RotationTextBox.Text != string.Empty)
			{
				result = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_RotationTextBox.Text);
			}
			return result;
		}
	}

	public double ComponentSpacing
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_PlantSpacingTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double SetbackSpacing
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_SetbackTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool SegmentChecked => m_SegmentRadioButton.Checked;

	public bool ChainChecked => m_ChainRadioButton.Checked;

	public PlacementType PlacementType
	{
		get
		{
			if (m_HedgeRowRadioButton.Checked)
			{
				if (m_CenterHedgeRadioButton.Checked)
				{
					return PlacementType.HedgeRowCenter;
				}
				if (m_AlternateHedgeRadioButton.Checked)
				{
					return PlacementType.HedgeRowAlternate;
				}
				return PlacementType.HedgeRowSide;
			}
			if (m_TriangularRadioButton.Checked)
			{
				return PlacementType.GroveTrianglular;
			}
			return PlacementType.GroveSquare;
		}
	}

	public TopographySurfaceContainer Surface
	{
		get
		{
			TopographySurfaceContainer result = null;
			if (m_SurfaceList.SelectedItem is ToposurfaceItem toposurfaceItem)
			{
				result = toposurfaceItem.Value;
			}
			return result;
		}
	}

	public bool PickToposurface => m_ToposurfaceCheckBox.Checked;

	public LocateComponentsForm(ComponentCreation dataBuffer)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("LocateComponentsDialog");
		m_ComponentFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_ComponentFamilyDialog");
		m_ComponentNameLabel.Text = EPShared.LocalRM.GetString("C_AMP_omponentNameDialog");
		m_ComponentSpacingLabel.Text = EPShared.LocalRM.GetString("Component_AMP_SpacingDialog");
		m_HedgeRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_PlaceAlongDialog");
		m_CenterHedgeRadioButton.Text = EPShared.LocalRM.GetString("C_AMP_enterDialog");
		m_AlternateHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_AlternateDialog");
		m_SideHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_SideDialog");
		m_AlignToCheckBox.Text = EPShared.LocalRM.GetString("Ali_AMP_gnToDialog");
		m_GroveRadioButton.Text = EPShared.LocalRM.GetString("PlaceIn_AMP_AreaDialog");
		m_TriangularRadioButton.Text = EPShared.LocalRM.GetString("Triang_AMP_ularDialog");
		m_SquareRadioButton.Text = EPShared.LocalRM.GetString("S_AMP_quareDialog");
		m_RotationLabel.Text = EPShared.LocalRM.GetString("R_AMP_otationDialog");
		m_SetbackLabel.Text = EPShared.LocalRM.GetString("Set_AMP_backDialog");
		m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
		m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
		m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
		m_ExistingElementCheckBox.Text = EPShared.LocalRM.GetString("ExistingEle_AMP_mentDialog");
		m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
		m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
		m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
		m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
		m_ToposurfaceCheckBox.Checked = false;
		m_SurfaceList.Enabled = false;
		EPToolTip.SetToolTip(m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		ContextualHelpID = "HID_SDaaa";
		m_dataBuffer = dataBuffer;
		m_FormatOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_AngularOptions = m_dataBuffer.Document.GetUnits().GetFormatOptions(UnitType.UT_Angle);
		m_DisplayUnitSystem = m_dataBuffer.Document.DisplayUnitSystem;
		m_Units = m_dataBuffer.Document.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_AngularSymbolType = m_AngularOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_AngularSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_dAngularRounding = m_AngularOptions.Accuracy;
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_dAngularRounding = 1.0;
		}
		m_DecimalSymbolType = m_dataBuffer.Document.GetUnits().DecimalSymbol;
		InitializeControls();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		double _dReturnValue = 0.0;
		string _strAngleStr = string.Empty;
		GetDialogPosition();
		m_HedgeRowRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsPlacementOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_HedgeRowRadioButton.Checked = true;
			}
			else
			{
				m_GroveRadioButton.Checked = true;
			}
		}
		m_CenterHedgeRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsHedgeRowOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_CenterHedgeRadioButton.Checked = true;
				break;
			case 1:
				m_AlternateHedgeRadioButton.Checked = true;
				break;
			default:
				m_SideHedgeRadioButton.Checked = true;
				break;
			}
		}
		m_TriangularRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsGroveRowOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_TriangularRadioButton.Checked = true;
			}
			else
			{
				m_SquareRadioButton.Checked = true;
			}
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsGroveRotation", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.eplStrE_ConvertRadiansToAngleStr(m_AngularOptions.LegacyDisplayUnits(), _dReturnValue, m_dAngularRounding, m_AngularSymbolType, m_DecimalSymbolType, ref _strAngleStr);
		m_RotationTextBox.Text = _strAngleStr;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsSpacing", ref _dReturnValue))
		{
			_dReturnValue = 5.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_PlantSpacingTextBox.Text = _strAngleStr;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsSetback", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_SetbackTextBox.Text = _strAngleStr;
		m_ExistingElementCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsExistingElement", ref _nReturnValue))
		{
			m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_DeleteExistingCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsDeleteExisting", ref _nReturnValue))
		{
			m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsStartingDistance", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strAngleStr);
		m_StartingDistanceTextBox.Text = _strAngleStr;
		m_AlignToCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsAllignTo", ref _nReturnValue))
		{
			m_AlignToCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_ComponentFamilyComboBox.DataSource = m_dataBuffer.FamilyList;
		m_ComponentFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateComponentsFamilyName", ref _strAngleStr))
		{
			FamilyContainer familyContainer = null;
			for (int i = 0; i < m_ComponentFamilyComboBox.Items.Count; i++)
			{
				if (m_ComponentFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strAngleStr, ignoreCase: true) == 0)
				{
					m_ComponentFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateComponentsPlantName", ref _strAngleStr))
		{
			FamilySymbol familySymbol = null;
			for (int j = 0; j < m_ComponentNameComboBox.Items.Count; j++)
			{
				if (m_ComponentNameComboBox.Items[j] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strAngleStr, ignoreCase: true) == 0)
				{
					m_ComponentNameComboBox.SelectedIndex = j;
					break;
				}
			}
		}
		for (int k = 0; k < m_dataBuffer.Views.Count; k++)
		{
			m_LevelComboBox.Items.Add(m_dataBuffer.Views[k].ViewType.ToString() + "-" + m_dataBuffer.Views[k].Name);
		}
		if (m_LevelComboBox.Items.Count > 0)
		{
			m_LevelComboBox.SelectedIndex = 0;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateComponentsViewName", ref _strAngleStr))
		{
			Autodesk.Revit.DB.View view = null;
			for (int l = 0; l < m_LevelComboBox.Items.Count; l++)
			{
				if (view != null && string.Compare(Convert.ToString(m_LevelComboBox.Items[l]), _strAngleStr, ignoreCase: true) == 0)
				{
					m_LevelComboBox.SelectedIndex = l;
					break;
				}
			}
		}
		m_SegmentRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsSegmentChainOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_SegmentRadioButton.Checked = true;
			}
			else
			{
				m_ChainRadioButton.Checked = true;
			}
		}
		m_ToposurfaceCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsPickToposurface", ref _nReturnValue))
		{
			m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		Parameter parameter = null;
		string text = string.Empty;
		if (m_dataBuffer.SurfaceList.Count > 0)
		{
			int num = 1;
			foreach (TopographySurfaceContainer surface in m_dataBuffer.SurfaceList)
			{
				parameter = ((Element)surface.TopographySurface).get_Parameter(BuiltInParameter.ROOM_NAME);
				if (parameter != null)
				{
					text = parameter.AsString();
				}
				if (text == null || text == string.Empty)
				{
					text = "<" + EPShared.LocalRM.GetString("UnnamedSurfaceDialog") + " " + Convert.ToString(num) + ">";
					num++;
				}
				m_SurfaceList.Items.Add(new ToposurfaceItem(text, surface));
			}
		}
		else
		{
			m_ToposurfaceCheckBox.Checked = false;
			m_ToposurfaceCheckBox.Enabled = false;
			m_SurfaceList.Enabled = false;
		}
		parameter = null;
		text = string.Empty;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_dataBuffer.Document.PathName, "LocateComponentsSurfaceName", ref _strAngleStr))
		{
			for (int m = 0; m < m_SurfaceList.Items.Count; m++)
			{
				if (m_SurfaceList.Items[m] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, _strAngleStr, ignoreCase: true) == 0)
				{
					m_SurfaceList.SelectedIndex = m;
					break;
				}
			}
		}
		if (m_SurfaceList.Items.Count > 0 && m_SurfaceList.SelectedIndex == -1)
		{
			m_SurfaceList.SelectedIndex = 0;
		}
	}

	private Autodesk.Revit.DB.View GetCurrentView()
	{
		Autodesk.Revit.DB.View view = null;
		bool flag = false;
		for (int i = 0; i < m_dataBuffer.Views.Count; i++)
		{
			view = m_dataBuffer.Views[i];
			string strB = view.ViewType.ToString() + "-" + view.Name;
			if (view != null && string.Compare(Convert.ToString(m_LevelComboBox.Items[m_LevelComboBox.SelectedIndex]), strB, ignoreCase: true) == 0)
			{
				flag = true;
				break;
			}
			if (flag)
			{
				break;
			}
		}
		return view;
	}

	private void SaveSettings()
	{
		m_CurView = GetCurrentView();
		if (m_CurView == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		m_CurType = m_ComponentNameComboBox.SelectedItem as FamilySymbol;
		if (m_CurType == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		int num = 0;
		num = ((!m_HedgeRowRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsPlacementOption", num);
		num = ((!m_CenterHedgeRadioButton.Checked) ? (m_AlternateHedgeRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsHedgeRowOption", num);
		num = ((!m_TriangularRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsGroveRowOption", num);
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsSpacing", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsSetback", _dReturnedDouble);
		}
		_dReturnedDouble = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_RotationTextBox.Text);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsGroveRotation", _dReturnedDouble);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsExistingElement", Convert.ToInt32(m_ExistingElementCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsDeleteExisting", Convert.ToInt32(m_DeleteExistingCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsStartingDistance", _dReturnedDouble);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsAllignTo", Convert.ToInt32(m_AlignToCheckBox.Checked));
		if (m_ComponentFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateComponentsFamilyName", familyContainer.FamilyName);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateComponentsPlantName", m_CurType.Name);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateComponentsViewName", Convert.ToString(m_LevelComboBox.SelectedItem));
		num = ((!m_SegmentRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsSegmentChainOption", num);
		ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsPickToposurface", Convert.ToInt32(m_ToposurfaceCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting(m_dataBuffer.Document.PathName, "LocateComponentsSurfaceName", Convert.ToString(m_SurfaceList.SelectedItem));
	}

	private bool ValidateFields()
	{
		double _dReturnedDouble = 0.0;
		string value = m_PlantSpacingTextBox.Text;
		if (string.IsNullOrEmpty(value))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoComponentSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_PlantSpacingTextBox);
			return false;
		}
		if (!RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidComponentSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_PlantSpacingTextBox);
			return false;
		}
		if (m_HedgeRowRadioButton.Checked && !m_CenterHedgeRadioButton.Checked && (!RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
			return false;
		}
		return true;
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		if (ValidateFields())
		{
			SaveSettings();
			DialogResult = DialogResult.OK;
			Close();
		}
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void OnHedgeRowGroveOptionChecked(object sender, EventArgs e)
	{
		m_CenterHedgeRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_AlternateHedgeRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_SideHedgeRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_AlignToCheckBox.Enabled = m_HedgeRowRadioButton.Checked;
		m_TriangularRadioButton.Enabled = !m_HedgeRowRadioButton.Checked;
		m_SquareRadioButton.Enabled = !m_HedgeRowRadioButton.Checked;
		m_RotationLabel.Enabled = !m_HedgeRowRadioButton.Checked;
		m_RotationTextBox.Enabled = !m_HedgeRowRadioButton.Checked;
		m_SegmentRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_ChainRadioButton.Enabled = m_HedgeRowRadioButton.Checked;
		m_StartingDistanceLabel.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
		m_StartingDistanceTextBox.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
		OnHedgeRowOptionChecked(sender, e);
	}

	private void OnHedgeRowOptionChecked(object sender, EventArgs e)
	{
		if (m_HedgeRowRadioButton.Checked)
		{
			m_SetbackLabel.Enabled = !m_CenterHedgeRadioButton.Checked;
			m_SetbackTextBox.Enabled = !m_CenterHedgeRadioButton.Checked;
		}
		else
		{
			m_SetbackLabel.Enabled = true;
			m_SetbackTextBox.Enabled = true;
		}
	}

	private void FormatPlantSpacingValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_PlantSpacingTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_PlantSpacingTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_PlantSpacingTextBox);
		}
	}

	private void OnPlantSpacingTextBoxLeave(object sender, EventArgs e)
	{
		FormatPlantSpacingValue();
	}

	private void FormatSetbackValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_SetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_SetbackTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_SetbackTextBox);
		}
	}

	private void OnSetbackTextBoxLeave(object sender, EventArgs e)
	{
		FormatSetbackValue();
	}

	private void FormatRotationValue()
	{
		string _strAngleStr = string.Empty;
		double num = 0.0;
		num = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_RotationTextBox.Text);
		if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(m_AngularOptions.LegacyDisplayUnits(), num, m_dAngularRounding, m_AngularSymbolType, m_DecimalSymbolType, ref _strAngleStr) == 0)
		{
			m_RotationTextBox.Text = _strAngleStr;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_RotationTextBox);
		}
	}

	private void OnRotationTextBoxLeave(object sender, EventArgs e)
	{
		FormatRotationValue();
	}

	private void OnPlantSpacingTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatPlantSpacingValue();
		}
	}

	private void OnRotationTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatRotationValue();
		}
	}

	private void OnSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatSetbackValue();
		}
	}

	private void OnComponentNameComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
	}

	private void OnLocateComponentsClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnComponentFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_ComponentFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_ComponentNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_ComponentNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnLoadFamilyButtonClick(object sender, EventArgs e)
	{
		int count = m_ComponentFamilyComboBox.Items.Count;
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		FamilyContainer familyContainer = null;
		Family _Family = null;
		openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectComponentFamilyFileMessage");
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				try
				{
					m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadComponentFamilyTransaction") + openFileDialog.SafeFileName);
					EPTransactionContainer _TransactionContainer = m_dataBuffer.TransactionContainer;
					flag = RevitUtility.LoadFamily(m_dataBuffer.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
					m_dataBuffer.TransactionContainer = _TransactionContainer;
					m_dataBuffer.TransactionContainer.Commit();
				}
				catch (SEHException)
				{
					m_dataBuffer.TransactionContainer.Rollback();
					flag = false;
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ComponentFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					continue;
				}
				break;
			}
		}
		if (!flag)
		{
			if (count == 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ComponentFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_dataBuffer.PopulateFamilyAndSymbolLists();
		m_ComponentFamilyComboBox.DataSource = m_dataBuffer.FamilyList;
		m_ComponentFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (_Family != null)
		{
			for (int i = 0; i < m_ComponentFamilyComboBox.Items.Count; i++)
			{
				if (m_ComponentFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _Family.Name, ignoreCase: true) == 0)
				{
					m_ComponentFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (m_ComponentFamilyComboBox.Items.Count == count)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotComponentMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
	{
		m_DeleteExistingCheckBox.Enabled = m_ExistingElementCheckBox.Checked;
		m_StartingDistanceLabel.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
		m_StartingDistanceTextBox.Enabled = m_ExistingElementCheckBox.Checked && m_HedgeRowRadioButton.Checked;
	}

	private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyData == Keys.Return)
		{
			FormatStartingDistanceValue();
		}
	}

	private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
	{
		FormatStartingDistanceValue();
	}

	private void FormatStartingDistanceValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
			m_StartingDistanceTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_StartingDistanceTextBox);
		}
	}

	private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
	{
		m_SurfaceList.Enabled = m_ToposurfaceCheckBox.Checked;
		m_SelectedSurfaceLabel.Enabled = m_ToposurfaceCheckBox.Checked;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ComponentFamilyLabel = new System.Windows.Forms.Label();
		this.m_ComponentFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelLabel = new System.Windows.Forms.Label();
		this.m_HedgeRowRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ComponentNameLabel = new System.Windows.Forms.Label();
		this.m_ComponentNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_ComponentSpacingLabel = new System.Windows.Forms.Label();
		this.m_PlantSpacingTextBox = new System.Windows.Forms.TextBox();
		this.m_SetbackLabel = new System.Windows.Forms.Label();
		this.m_SetbackTextBox = new System.Windows.Forms.TextBox();
		this.m_GroveRadioButton = new System.Windows.Forms.RadioButton();
		this.m_HedgeRowPanel = new System.Windows.Forms.Panel();
		this.m_SideHedgeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_AlternateHedgeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CenterHedgeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_GrovePanel = new System.Windows.Forms.Panel();
		this.m_SquareRadioButton = new System.Windows.Forms.RadioButton();
		this.m_TriangularRadioButton = new System.Windows.Forms.RadioButton();
		this.m_RotationLabel = new System.Windows.Forms.Label();
		this.m_RotationTextBox = new System.Windows.Forms.TextBox();
		this.m_AlignToCheckBox = new System.Windows.Forms.CheckBox();
		this.m_LoadFamilyButton = new System.Windows.Forms.Button();
		this.m_ExistingElementCheckBox = new System.Windows.Forms.CheckBox();
		this.m_MoveablePanel = new System.Windows.Forms.Panel();
		this.m_StartingDistanceLabel = new System.Windows.Forms.Label();
		this.m_StartingDistanceTextBox = new System.Windows.Forms.TextBox();
		this.m_DeleteExistingCheckBox = new System.Windows.Forms.CheckBox();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_InsertButton = new System.Windows.Forms.Button();
		this.m_ChainRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SegmentRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ToposurfacePickerPanel = new System.Windows.Forms.Panel();
		this.m_SurfaceList = new System.Windows.Forms.ComboBox();
		this.m_SelectedSurfaceLabel = new System.Windows.Forms.Label();
		this.m_ToposurfaceCheckBox = new System.Windows.Forms.CheckBox();
		this.m_SegmentChainPanel = new System.Windows.Forms.Panel();
		this.m_HedgeRowPanel.SuspendLayout();
		this.m_GrovePanel.SuspendLayout();
		this.m_MoveablePanel.SuspendLayout();
		this.m_ToposurfacePickerPanel.SuspendLayout();
		this.m_SegmentChainPanel.SuspendLayout();
		base.SuspendLayout();
		this.m_ComponentFamilyLabel.AutoSize = true;
		this.m_ComponentFamilyLabel.Location = new System.Drawing.Point(12, 15);
		this.m_ComponentFamilyLabel.Name = "m_ComponentFamilyLabel";
		this.m_ComponentFamilyLabel.Size = new System.Drawing.Size(96, 13);
		this.m_ComponentFamilyLabel.TabIndex = 0;
		this.m_ComponentFamilyLabel.Text = "&Component Family:";
		this.m_ComponentFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ComponentFamilyComboBox.FormattingEnabled = true;
		this.m_ComponentFamilyComboBox.Location = new System.Drawing.Point(130, 12);
		this.m_ComponentFamilyComboBox.Name = "m_ComponentFamilyComboBox";
		this.m_ComponentFamilyComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_ComponentFamilyComboBox.TabIndex = 1;
		this.m_ComponentFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnComponentFamilyComboBoxSelectedIndexChanged);
		this.m_LevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LevelComboBox.FormattingEnabled = true;
		this.m_LevelComboBox.Location = new System.Drawing.Point(130, 276);
		this.m_LevelComboBox.Name = "m_LevelComboBox";
		this.m_LevelComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_LevelComboBox.TabIndex = 17;
		this.m_LevelLabel.AutoSize = true;
		this.m_LevelLabel.Location = new System.Drawing.Point(12, 279);
		this.m_LevelLabel.Name = "m_LevelLabel";
		this.m_LevelLabel.Size = new System.Drawing.Size(36, 13);
		this.m_LevelLabel.TabIndex = 16;
		this.m_LevelLabel.Text = "&Level:";
		this.m_HedgeRowRadioButton.AutoSize = true;
		this.m_HedgeRowRadioButton.Location = new System.Drawing.Point(12, 97);
		this.m_HedgeRowRadioButton.Name = "m_HedgeRowRadioButton";
		this.m_HedgeRowRadioButton.Size = new System.Drawing.Size(82, 17);
		this.m_HedgeRowRadioButton.TabIndex = 7;
		this.m_HedgeRowRadioButton.TabStop = true;
		this.m_HedgeRowRadioButton.Text = "&Place Along";
		this.m_HedgeRowRadioButton.UseVisualStyleBackColor = true;
		this.m_HedgeRowRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowGroveOptionChecked);
		this.m_ComponentNameLabel.AutoSize = true;
		this.m_ComponentNameLabel.Location = new System.Drawing.Point(12, 43);
		this.m_ComponentNameLabel.Name = "m_ComponentNameLabel";
		this.m_ComponentNameLabel.Size = new System.Drawing.Size(95, 13);
		this.m_ComponentNameLabel.TabIndex = 3;
		this.m_ComponentNameLabel.Text = "C&omponent Name:";
		this.m_ComponentNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ComponentNameComboBox.FormattingEnabled = true;
		this.m_ComponentNameComboBox.Location = new System.Drawing.Point(130, 39);
		this.m_ComponentNameComboBox.Name = "m_ComponentNameComboBox";
		this.m_ComponentNameComboBox.Size = new System.Drawing.Size(215, 21);
		this.m_ComponentNameComboBox.TabIndex = 4;
		this.m_ComponentNameComboBox.SelectedIndexChanged += new System.EventHandler(this.OnComponentNameComboBoxSelectedIndexChanged);
		this.m_ComponentSpacingLabel.AutoSize = true;
		this.m_ComponentSpacingLabel.Location = new System.Drawing.Point(12, 69);
		this.m_ComponentSpacingLabel.Name = "m_ComponentSpacingLabel";
		this.m_ComponentSpacingLabel.Size = new System.Drawing.Size(106, 13);
		this.m_ComponentSpacingLabel.TabIndex = 5;
		this.m_ComponentSpacingLabel.Text = "Component &Spacing:";
		this.m_PlantSpacingTextBox.Location = new System.Drawing.Point(130, 66);
		this.m_PlantSpacingTextBox.Name = "m_PlantSpacingTextBox";
		this.m_PlantSpacingTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_PlantSpacingTextBox.TabIndex = 6;
		this.m_PlantSpacingTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnPlantSpacingTextBoxKeyDown);
		this.m_PlantSpacingTextBox.Leave += new System.EventHandler(this.OnPlantSpacingTextBoxLeave);
		this.m_SetbackLabel.AutoSize = true;
		this.m_SetbackLabel.Location = new System.Drawing.Point(12, 253);
		this.m_SetbackLabel.Name = "m_SetbackLabel";
		this.m_SetbackLabel.Size = new System.Drawing.Size(50, 13);
		this.m_SetbackLabel.TabIndex = 14;
		this.m_SetbackLabel.Text = "Set&back:";
		this.m_SetbackTextBox.Location = new System.Drawing.Point(130, 250);
		this.m_SetbackTextBox.Name = "m_SetbackTextBox";
		this.m_SetbackTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_SetbackTextBox.TabIndex = 15;
		this.m_SetbackTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnSetbackTextBoxKeyDown);
		this.m_SetbackTextBox.Leave += new System.EventHandler(this.OnSetbackTextBoxLeave);
		this.m_GroveRadioButton.AutoSize = true;
		this.m_GroveRadioButton.Location = new System.Drawing.Point(12, 171);
		this.m_GroveRadioButton.Name = "m_GroveRadioButton";
		this.m_GroveRadioButton.Size = new System.Drawing.Size(88, 17);
		this.m_GroveRadioButton.TabIndex = 10;
		this.m_GroveRadioButton.TabStop = true;
		this.m_GroveRadioButton.Text = "Place in &Area";
		this.m_GroveRadioButton.UseVisualStyleBackColor = true;
		this.m_GroveRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowGroveOptionChecked);
		this.m_HedgeRowPanel.Controls.Add(this.m_SideHedgeRadioButton);
		this.m_HedgeRowPanel.Controls.Add(this.m_AlternateHedgeRadioButton);
		this.m_HedgeRowPanel.Controls.Add(this.m_CenterHedgeRadioButton);
		this.m_HedgeRowPanel.Location = new System.Drawing.Point(29, 120);
		this.m_HedgeRowPanel.Name = "m_HedgeRowPanel";
		this.m_HedgeRowPanel.Size = new System.Drawing.Size(316, 24);
		this.m_HedgeRowPanel.TabIndex = 8;
		this.m_SideHedgeRadioButton.AutoSize = true;
		this.m_SideHedgeRadioButton.Location = new System.Drawing.Point(253, 4);
		this.m_SideHedgeRadioButton.Name = "m_SideHedgeRadioButton";
		this.m_SideHedgeRadioButton.Size = new System.Drawing.Size(46, 17);
		this.m_SideHedgeRadioButton.TabIndex = 2;
		this.m_SideHedgeRadioButton.TabStop = true;
		this.m_SideHedgeRadioButton.Text = "&Side";
		this.m_SideHedgeRadioButton.UseVisualStyleBackColor = true;
		this.m_SideHedgeRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowOptionChecked);
		this.m_AlternateHedgeRadioButton.AutoSize = true;
		this.m_AlternateHedgeRadioButton.Location = new System.Drawing.Point(119, 3);
		this.m_AlternateHedgeRadioButton.Name = "m_AlternateHedgeRadioButton";
		this.m_AlternateHedgeRadioButton.Size = new System.Drawing.Size(67, 17);
		this.m_AlternateHedgeRadioButton.TabIndex = 1;
		this.m_AlternateHedgeRadioButton.TabStop = true;
		this.m_AlternateHedgeRadioButton.Text = "&Alternate";
		this.m_AlternateHedgeRadioButton.UseVisualStyleBackColor = true;
		this.m_AlternateHedgeRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowOptionChecked);
		this.m_CenterHedgeRadioButton.AutoSize = true;
		this.m_CenterHedgeRadioButton.Location = new System.Drawing.Point(3, 4);
		this.m_CenterHedgeRadioButton.Name = "m_CenterHedgeRadioButton";
		this.m_CenterHedgeRadioButton.Size = new System.Drawing.Size(56, 17);
		this.m_CenterHedgeRadioButton.TabIndex = 0;
		this.m_CenterHedgeRadioButton.TabStop = true;
		this.m_CenterHedgeRadioButton.Text = "C&enter";
		this.m_CenterHedgeRadioButton.UseVisualStyleBackColor = true;
		this.m_CenterHedgeRadioButton.CheckedChanged += new System.EventHandler(this.OnHedgeRowOptionChecked);
		this.m_GrovePanel.Controls.Add(this.m_SquareRadioButton);
		this.m_GrovePanel.Controls.Add(this.m_TriangularRadioButton);
		this.m_GrovePanel.Location = new System.Drawing.Point(29, 194);
		this.m_GrovePanel.Name = "m_GrovePanel";
		this.m_GrovePanel.Size = new System.Drawing.Size(316, 24);
		this.m_GrovePanel.TabIndex = 11;
		this.m_SquareRadioButton.AutoSize = true;
		this.m_SquareRadioButton.Location = new System.Drawing.Point(119, 4);
		this.m_SquareRadioButton.Name = "m_SquareRadioButton";
		this.m_SquareRadioButton.Size = new System.Drawing.Size(59, 17);
		this.m_SquareRadioButton.TabIndex = 1;
		this.m_SquareRadioButton.TabStop = true;
		this.m_SquareRadioButton.Text = "S&quare";
		this.m_SquareRadioButton.UseVisualStyleBackColor = true;
		this.m_TriangularRadioButton.AutoSize = true;
		this.m_TriangularRadioButton.Location = new System.Drawing.Point(3, 3);
		this.m_TriangularRadioButton.Name = "m_TriangularRadioButton";
		this.m_TriangularRadioButton.Size = new System.Drawing.Size(72, 17);
		this.m_TriangularRadioButton.TabIndex = 0;
		this.m_TriangularRadioButton.TabStop = true;
		this.m_TriangularRadioButton.Text = "Triang&ular";
		this.m_TriangularRadioButton.UseVisualStyleBackColor = true;
		this.m_RotationLabel.AutoSize = true;
		this.m_RotationLabel.Enabled = false;
		this.m_RotationLabel.Location = new System.Drawing.Point(31, 227);
		this.m_RotationLabel.Name = "m_RotationLabel";
		this.m_RotationLabel.Size = new System.Drawing.Size(50, 13);
		this.m_RotationLabel.TabIndex = 12;
		this.m_RotationLabel.Text = "R&otation:";
		this.m_RotationTextBox.Enabled = false;
		this.m_RotationTextBox.Location = new System.Drawing.Point(130, 224);
		this.m_RotationTextBox.Name = "m_RotationTextBox";
		this.m_RotationTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_RotationTextBox.TabIndex = 13;
		this.m_RotationTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnRotationTextBoxKeyDown);
		this.m_RotationTextBox.Leave += new System.EventHandler(this.OnRotationTextBoxLeave);
		this.m_AlignToCheckBox.AutoSize = true;
		this.m_AlignToCheckBox.Location = new System.Drawing.Point(32, 150);
		this.m_AlignToCheckBox.Name = "m_AlignToCheckBox";
		this.m_AlignToCheckBox.Size = new System.Drawing.Size(65, 17);
		this.m_AlignToCheckBox.TabIndex = 9;
		this.m_AlignToCheckBox.Text = "Ali&gn To";
		this.m_AlignToCheckBox.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Location = new System.Drawing.Point(351, 13);
		this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
		this.m_LoadFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadFamilyButton.TabIndex = 2;
		this.m_LoadFamilyButton.TabStop = false;
		this.m_LoadFamilyButton.Text = "...";
		this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadFamilyButton.Click += new System.EventHandler(this.OnLoadFamilyButtonClick);
		this.m_ExistingElementCheckBox.AutoSize = true;
		this.m_ExistingElementCheckBox.Location = new System.Drawing.Point(12, 376);
		this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
		this.m_ExistingElementCheckBox.Size = new System.Drawing.Size(103, 17);
		this.m_ExistingElementCheckBox.TabIndex = 20;
		this.m_ExistingElementCheckBox.Text = "Existing Ele&ment";
		this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
		this.m_ExistingElementCheckBox.CheckedChanged += new System.EventHandler(this.OnExistingElementCheckBoxChecked);
		this.m_MoveablePanel.Controls.Add(this.m_StartingDistanceLabel);
		this.m_MoveablePanel.Controls.Add(this.m_StartingDistanceTextBox);
		this.m_MoveablePanel.Controls.Add(this.m_DeleteExistingCheckBox);
		this.m_MoveablePanel.Controls.Add(this.m_CancelButton);
		this.m_MoveablePanel.Controls.Add(this.m_InsertButton);
		this.m_MoveablePanel.Location = new System.Drawing.Point(12, 399);
		this.m_MoveablePanel.Name = "m_MoveablePanel";
		this.m_MoveablePanel.Size = new System.Drawing.Size(363, 72);
		this.m_MoveablePanel.TabIndex = 21;
		this.m_StartingDistanceLabel.AutoSize = true;
		this.m_StartingDistanceLabel.Enabled = false;
		this.m_StartingDistanceLabel.Location = new System.Drawing.Point(20, 26);
		this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
		this.m_StartingDistanceLabel.Size = new System.Drawing.Size(91, 13);
		this.m_StartingDistanceLabel.TabIndex = 1;
		this.m_StartingDistanceLabel.Text = "Starting Distance:";
		this.m_StartingDistanceTextBox.Enabled = false;
		this.m_StartingDistanceTextBox.Location = new System.Drawing.Point(118, 23);
		this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
		this.m_StartingDistanceTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_StartingDistanceTextBox.TabIndex = 2;
		this.m_StartingDistanceTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
		this.m_StartingDistanceTextBox.Leave += new System.EventHandler(this.OnStartingDistanceTextBoxLeave);
		this.m_DeleteExistingCheckBox.AutoSize = true;
		this.m_DeleteExistingCheckBox.Enabled = false;
		this.m_DeleteExistingCheckBox.Location = new System.Drawing.Point(20, 0);
		this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
		this.m_DeleteExistingCheckBox.Size = new System.Drawing.Size(137, 17);
		this.m_DeleteExistingCheckBox.TabIndex = 0;
		this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
		this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(287, 49);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(76, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_InsertButton.Location = new System.Drawing.Point(206, 49);
		this.m_InsertButton.Name = "m_InsertButton";
		this.m_InsertButton.Size = new System.Drawing.Size(75, 23);
		this.m_InsertButton.TabIndex = 3;
		this.m_InsertButton.Text = "&Insert";
		this.m_InsertButton.UseVisualStyleBackColor = true;
		this.m_InsertButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_ChainRadioButton.AutoSize = true;
		this.m_ChainRadioButton.Location = new System.Drawing.Point(118, 0);
		this.m_ChainRadioButton.Name = "m_ChainRadioButton";
		this.m_ChainRadioButton.Size = new System.Drawing.Size(52, 17);
		this.m_ChainRadioButton.TabIndex = 1;
		this.m_ChainRadioButton.Text = "&Chain";
		this.m_ChainRadioButton.UseVisualStyleBackColor = true;
		this.m_SegmentRadioButton.AutoSize = true;
		this.m_SegmentRadioButton.Checked = true;
		this.m_SegmentRadioButton.Location = new System.Drawing.Point(0, 0);
		this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
		this.m_SegmentRadioButton.Size = new System.Drawing.Size(67, 17);
		this.m_SegmentRadioButton.TabIndex = 0;
		this.m_SegmentRadioButton.TabStop = true;
		this.m_SegmentRadioButton.Text = "&Segment";
		this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
		this.m_ToposurfacePickerPanel.Controls.Add(this.m_SurfaceList);
		this.m_ToposurfacePickerPanel.Controls.Add(this.m_SelectedSurfaceLabel);
		this.m_ToposurfacePickerPanel.Controls.Add(this.m_ToposurfaceCheckBox);
		this.m_ToposurfacePickerPanel.Location = new System.Drawing.Point(12, 303);
		this.m_ToposurfacePickerPanel.Name = "m_ToposurfacePickerPanel";
		this.m_ToposurfacePickerPanel.Size = new System.Drawing.Size(363, 44);
		this.m_ToposurfacePickerPanel.TabIndex = 18;
		this.m_SurfaceList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_SurfaceList.Enabled = false;
		this.m_SurfaceList.FormattingEnabled = true;
		this.m_SurfaceList.Location = new System.Drawing.Point(118, 23);
		this.m_SurfaceList.Name = "m_SurfaceList";
		this.m_SurfaceList.Size = new System.Drawing.Size(215, 21);
		this.m_SurfaceList.TabIndex = 2;
		this.m_SelectedSurfaceLabel.AutoSize = true;
		this.m_SelectedSurfaceLabel.Enabled = false;
		this.m_SelectedSurfaceLabel.Location = new System.Drawing.Point(0, 26);
		this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
		this.m_SelectedSurfaceLabel.Size = new System.Drawing.Size(44, 13);
		this.m_SelectedSurfaceLabel.TabIndex = 1;
		this.m_SelectedSurfaceLabel.Text = "Surface";
		this.m_ToposurfaceCheckBox.AutoSize = true;
		this.m_ToposurfaceCheckBox.Location = new System.Drawing.Point(0, 0);
		this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
		this.m_ToposurfaceCheckBox.Size = new System.Drawing.Size(119, 17);
		this.m_ToposurfaceCheckBox.TabIndex = 0;
		this.m_ToposurfaceCheckBox.Text = "Toposurface Picker";
		this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
		this.m_ToposurfaceCheckBox.CheckStateChanged += new System.EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
		this.m_SegmentChainPanel.Controls.Add(this.m_SegmentRadioButton);
		this.m_SegmentChainPanel.Controls.Add(this.m_ChainRadioButton);
		this.m_SegmentChainPanel.Location = new System.Drawing.Point(12, 353);
		this.m_SegmentChainPanel.Name = "m_SegmentChainPanel";
		this.m_SegmentChainPanel.Size = new System.Drawing.Size(363, 17);
		this.m_SegmentChainPanel.TabIndex = 19;
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(387, 483);
		base.Controls.Add(this.m_SegmentChainPanel);
		base.Controls.Add(this.m_ToposurfacePickerPanel);
		base.Controls.Add(this.m_MoveablePanel);
		base.Controls.Add(this.m_ExistingElementCheckBox);
		base.Controls.Add(this.m_LoadFamilyButton);
		base.Controls.Add(this.m_AlignToCheckBox);
		base.Controls.Add(this.m_RotationLabel);
		base.Controls.Add(this.m_RotationTextBox);
		base.Controls.Add(this.m_GrovePanel);
		base.Controls.Add(this.m_HedgeRowPanel);
		base.Controls.Add(this.m_GroveRadioButton);
		base.Controls.Add(this.m_SetbackLabel);
		base.Controls.Add(this.m_SetbackTextBox);
		base.Controls.Add(this.m_ComponentSpacingLabel);
		base.Controls.Add(this.m_PlantSpacingTextBox);
		base.Controls.Add(this.m_ComponentNameComboBox);
		base.Controls.Add(this.m_ComponentNameLabel);
		base.Controls.Add(this.m_HedgeRowRadioButton);
		base.Controls.Add(this.m_LevelComboBox);
		base.Controls.Add(this.m_LevelLabel);
		base.Controls.Add(this.m_ComponentFamilyComboBox);
		base.Controls.Add(this.m_ComponentFamilyLabel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "LocateComponentsForm";
		this.Text = "Locate Components";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnLocateComponentsClosing);
		this.m_HedgeRowPanel.ResumeLayout(false);
		this.m_HedgeRowPanel.PerformLayout();
		this.m_GrovePanel.ResumeLayout(false);
		this.m_GrovePanel.PerformLayout();
		this.m_MoveablePanel.ResumeLayout(false);
		this.m_MoveablePanel.PerformLayout();
		this.m_ToposurfacePickerPanel.ResumeLayout(false);
		this.m_ToposurfacePickerPanel.PerformLayout();
		this.m_SegmentChainPanel.ResumeLayout(false);
		this.m_SegmentChainPanel.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_InsertButton;
		base.CancelButton = this.m_CancelButton;
	}
}
