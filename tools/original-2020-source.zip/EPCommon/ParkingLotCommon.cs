﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParkingLotCommon
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Threading;

#nullable disable
namespace EPCommon;

public class ParkingLotCommon
{
  private static FamilyInstance DrawStall(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Point _InsertPoint,
    FamilySymbol _StallSymbol,
    double _dDirection,
    double _dStallLength,
    double _dStallWidth,
    double _dStallAngle,
    bool _bHideLeftStripe,
    bool _bHideRightStripe,
    ref List<FamilyInstance> _ExistingParkingStallList)
  {
    return ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, _InsertPoint, _StallSymbol, _dDirection, _dStallLength, _dStallWidth, _dStallAngle, _bHideLeftStripe, _bHideRightStripe, false, false, ref _ExistingParkingStallList);
  }

  private static FamilyInstance DrawStall(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Point _InsertPoint,
    FamilySymbol _StallSymbol,
    double _dDirection,
    double _dStallLength,
    double _dStallWidth,
    double _dStallAngle,
    bool _bHideLeftStripe,
    bool _bHideRightStripe,
    bool _bIsHCapStall,
    bool _bRightAisle,
    ref List<FamilyInstance> _ExistingParkingStallList)
  {
    if (_StallSymbol != null)
    {
      _Document.GetUnits().GetFormatOptions((UnitType) 0);
      double _dAngle = 0.0;
      Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_InsertPoint, _PlacementSettings.SurfaceList);
      FamilyInstance familyInstance;
      if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
      {
        familyInstance = _ExistingParkingStallList[0];
        if (((Element) familyInstance).Location is LocationPoint location)
        {
          if (!EPShared.eplGeoE_ArePntsDuplicates3D(_InsertPoint, new Eps_Point(location.Point)))
          {
            XYZ xyz = new XYZ(_InsertPoint.XYZ.X - location.Point.X, _InsertPoint.XYZ.Y - location.Point.Y, 0.0);
            ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
          }
          _dAngle = location.Rotation;
        }
        _ExistingParkingStallList.RemoveAt(0);
      }
      else
      {
        bool _bUseFailureHandling = true;
        if (_PlacementSettings.TransactionContainer == null)
          _bUseFailureHandling = false;
        EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
        familyInstance = RevitUtility.NewFamilyInstance(_Document, _InsertPoint.XY, _StallSymbol, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
        _PlacementSettings.TransactionContainer = transactionContainer;
      }
      if (_dStallLength > 0.0)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotLength);
        if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _dStallLength))
          parameter.Set(_dStallLength);
      }
      if (_dStallWidth > 0.0)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotWidth);
        if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _dStallWidth))
          parameter.Set(_dStallWidth);
      }
      if (_dStallAngle >= 0.0)
        ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotAngle)?.Set(EPShared.eplGeoE_NormalizeRadians(_dStallAngle));
      if (_bIsHCapStall)
        ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotRightAisle)?.Set(Convert.ToInt32(_bRightAisle));
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotLeftStripeVisible)?.Set(Convert.ToInt32(_bHideLeftStripe));
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotRightStripeVisible)?.Set(Convert.ToInt32(_bHideRightStripe));
      if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
      {
        XYZ xyz = new XYZ(_InsertPoint.x, _InsertPoint.y, _InsertPoint.z + 1.0);
        Line bound = Line.CreateBound(_InsertPoint.XYZ, xyz);
        ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
      }
      if (_Element != null && _PlacementSettings.GenericModelIDList != null)
      {
        int index1 = -1;
        for (int index2 = 0; index2 < _PlacementSettings.GenericModelIDList.Count; ++index2)
        {
          if (string.Compare(_PlacementSettings.GenericModelIDList[index2].Key, _Element.UniqueId, true) == 0)
          {
            index1 = index2;
            break;
          }
        }
        if (index1 >= 0 && index1 < _PlacementSettings.GenericModelIDList.Count)
          ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter)?.Set(_PlacementSettings.GenericModelIDList[index1].Value);
      }
      if (!_bHideRightStripe)
        return familyInstance;
    }
    return (FamilyInstance) null;
  }

  private static void DrawBumper(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Point _InsertPoint,
    double _dParkingWidth,
    double _dDirection,
    ref List<FamilyInstance> _ExistingBumperList)
  {
    if (_PlacementSettings.Parking.BumperSymbol == null)
      return;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    double _dAngle = 0.0;
    Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_InsertPoint, _PlacementSettings.SurfaceList);
    FamilyInstance familyInstance;
    if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingBumperList != null && _ExistingBumperList.Count > 0)
    {
      familyInstance = _ExistingBumperList[0];
      if (((Element) familyInstance).Location is LocationPoint location)
      {
        if (!EPShared.eplGeoE_ArePntsDuplicates3D(_InsertPoint, new Eps_Point(location.Point)))
        {
          XYZ xyz = new XYZ(_InsertPoint.XYZ.X - location.Point.X, _InsertPoint.XYZ.Y - location.Point.Y, 0.0);
          ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
        }
        _dAngle = location.Rotation;
      }
      _ExistingBumperList.RemoveAt(0);
    }
    else
    {
      bool _bUseFailureHandling = true;
      if (_PlacementSettings.TransactionContainer == null)
        _bUseFailureHandling = false;
      EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
      familyInstance = RevitUtility.NewFamilyInstance(_Document, _InsertPoint.XY, _PlacementSettings.Parking.BumperSymbol, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
      _PlacementSettings.TransactionContainer = transactionContainer;
    }
    if (_dParkingWidth - 2.0 * _PlacementSettings.Parking.BumperOffset > 0.0)
    {
      Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotLength);
      if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _dParkingWidth - 2.0 * _PlacementSettings.Parking.BumperOffset))
        parameter.Set(_dParkingWidth - 2.0 * _PlacementSettings.Parking.BumperOffset);
    }
    if (_PlacementSettings.Parking.BumperWidth > 0.0)
    {
      Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotWidth);
      if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Parking.BumperWidth))
        parameter.Set(_PlacementSettings.Parking.BumperWidth);
    }
    if (_PlacementSettings.Parking.BumperHeight > 0.0)
    {
      Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotHeight);
      if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Parking.BumperHeight))
        parameter.Set(_PlacementSettings.Parking.BumperHeight);
    }
    if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
    {
      XYZ xyz = new XYZ(_InsertPoint.x, _InsertPoint.y, _InsertPoint.z + 1.0);
      Line bound = Line.CreateBound(_InsertPoint.XYZ, xyz);
      ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
    }
    if (_Element == null || _PlacementSettings.GenericModelIDList == null)
      return;
    int index1 = -1;
    for (int index2 = 0; index2 < _PlacementSettings.GenericModelIDList.Count; ++index2)
    {
      if (string.Compare(_PlacementSettings.GenericModelIDList[index2].Key, _Element.UniqueId, true) == 0)
      {
        index1 = index2;
        break;
      }
    }
    if (index1 < 0 || index1 >= _PlacementSettings.GenericModelIDList.Count)
      return;
    ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter)?.Set(_PlacementSettings.GenericModelIDList[index1].Value);
  }

  private static void DrawIsland(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Point _InsertPoint,
    double _dIslandWidth,
    double _dIslandAngle,
    double _dStallLength,
    double _dDirection,
    ref List<FamilyInstance> _ExistingIslandList)
  {
    ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, _InsertPoint, 0.0, _dIslandWidth, _dIslandAngle, _dStallLength, _dDirection, ref _ExistingIslandList);
  }

  private static void DrawIsland(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Point _InsertPoint,
    double _dIslandLength,
    double _dIslandWidth,
    double _dIslandAngle,
    double _dStallLength,
    double _dDirection,
    ref List<FamilyInstance> _ExistingIslandList)
  {
    if (_PlacementSettings.Parking.IslandSymbol == null)
      return;
    double _dAngle = 0.0;
    Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_InsertPoint, _PlacementSettings.SurfaceList);
    FamilyInstance familyInstance;
    if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingIslandList != null && _ExistingIslandList.Count > 0)
    {
      familyInstance = _ExistingIslandList[0];
      if (((Element) familyInstance).Location is LocationPoint location)
      {
        if (!EPShared.eplGeoE_ArePntsDuplicates3D(_InsertPoint, new Eps_Point(location.Point)))
        {
          XYZ xyz = new XYZ(_InsertPoint.XYZ.X - location.Point.X, _InsertPoint.XYZ.Y - location.Point.Y, 0.0);
          ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
        }
        _dAngle = location.Rotation;
      }
      _ExistingIslandList.RemoveAt(0);
    }
    else
    {
      bool _bUseFailureHandling = true;
      if (_PlacementSettings.TransactionContainer == null)
        _bUseFailureHandling = false;
      EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
      familyInstance = RevitUtility.NewFamilyInstance(_Document, _InsertPoint.XY, _PlacementSettings.Parking.IslandSymbol, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
      _PlacementSettings.TransactionContainer = transactionContainer;
    }
    if (_dIslandLength > 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotLength)?.Set(_dIslandLength);
    if (_dIslandWidth > 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotWidth)?.Set(_dIslandWidth);
    if (_PlacementSettings.Parking.IslandHeight > 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotHeight)?.Set(_PlacementSettings.Parking.IslandHeight);
    if (_dIslandAngle >= 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotAngle)?.Set(_dIslandAngle);
    if (_dStallLength > 0.0)
      ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotStallLength)?.Set(_dStallLength);
    if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
    {
      XYZ xyz = new XYZ(_InsertPoint.x, _InsertPoint.y, _InsertPoint.z + 1.0);
      Line bound = Line.CreateBound(_InsertPoint.XYZ, xyz);
      ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
    }
    if (_Element == null || _PlacementSettings.GenericModelIDList == null)
      return;
    int index1 = -1;
    KeyValuePair<string, string> genericModelId;
    for (int index2 = 0; index2 < _PlacementSettings.GenericModelIDList.Count; ++index2)
    {
      genericModelId = _PlacementSettings.GenericModelIDList[index2];
      if (string.Compare(genericModelId.Key, _Element.UniqueId, true) == 0)
      {
        index1 = index2;
        break;
      }
    }
    if (index1 < 0 || index1 >= _PlacementSettings.GenericModelIDList.Count)
      return;
    Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
    if (parameter1 == null)
      return;
    Parameter parameter2 = parameter1;
    genericModelId = _PlacementSettings.GenericModelIDList[index1];
    string str = genericModelId.Value;
    parameter2.Set(str);
  }

  private static void GetIslandParameters(
    Document _Document,
    ref PlacementSettings _PlacementSettings)
  {
    if (_PlacementSettings.Parking.IslandSymbol == null || _PlacementSettings.Parking.IslandWidth <= 0.0)
      return;
    Eps_Point epsPoint = new Eps_Point();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.TransactionContainer == null)
      _bUseFailureHandling = false;
    EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
    FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Parking.IslandSymbol, (Element) null, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
    _PlacementSettings.TransactionContainer = transactionContainer;
    if (familyInstance == null)
      return;
    Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotCenterIsland);
    if (parameter1 != null)
      _PlacementSettings.Parking.CenterIsland = Convert.ToBoolean(parameter1.AsInteger());
    Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotHasSides);
    if (parameter2 != null)
      _PlacementSettings.Parking.SidesOnIsland = Convert.ToBoolean(parameter2.AsInteger());
    if (_PlacementSettings.TransactionContainer != null)
      _PlacementSettings.TransactionContainer.BeginTransaction();
    _Document.Delete(((Element) familyInstance).Id);
    if (_PlacementSettings.TransactionContainer == null)
      return;
    _PlacementSettings.TransactionContainer.EndTransaction();
  }

  private static void GetAisleWidthAdjustment(
    Document _Document,
    ref PlacementSettings _PlacementSettings)
  {
    if (!_PlacementSettings.Parking.GetAisleWidthAdjustment && _PlacementSettings.Parking.ADAStallCount > 0 && _PlacementSettings.Parking.ADAStallSymbol != null)
    {
      Eps_Point epsPoint = new Eps_Point();
      bool _bUseFailureHandling = true;
      if (_PlacementSettings.TransactionContainer == null)
        _bUseFailureHandling = false;
      EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
      FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlacementSettings.Parking.ADAStallSymbol, (Element) null, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
      _PlacementSettings.TransactionContainer = transactionContainer;
      if (familyInstance != null)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotAisleWidth);
        if (parameter != null)
          _PlacementSettings.Parking.AdjustAisleWidth = parameter.AsDouble();
        if (_PlacementSettings.TransactionContainer != null)
          _PlacementSettings.TransactionContainer.BeginTransaction();
        _Document.Delete(((Element) familyInstance).Id);
        if (_PlacementSettings.TransactionContainer != null)
          _PlacementSettings.TransactionContainer.EndTransaction();
      }
    }
    _PlacementSettings.Parking.GetAisleWidthAdjustment = true;
  }

  private static int CalculateNumberOfStalls(
    ref PlacementSettings _PlacementSettings,
    Eps_Line _CurLine,
    bool _bDoubleRowStallAdjustment)
  {
    int result = 0;
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CurLine.StartPnt, _CurLine.EndPnt, ref _dDistance);
    _PlacementSettings.Parking.CurrentADAStallCount = 0;
    _PlacementSettings.Parking.CurrentStallCount = 0;
    double num1 = !_PlacementSettings.Parking.ADAStallSharedAccessibleAisle ? _PlacementSettings.Parking.ADAStallAdjustWidth : (_PlacementSettings.Parking.ADAStallAdjustWidth + _PlacementSettings.Parking.ADAStallWidth) / 2.0;
    if (_PlacementSettings.Parking.ADAStallCount >= 1)
    {
      int a = (int) (_dDistance / num1);
      if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
      {
        int num2 = Math.DivRem(a, 2, out result);
        if (result > 0 && _dDistance < _PlacementSettings.Parking.ADAStallWidth * (double) num2 + _PlacementSettings.Parking.ADAStallAdjustWidth * (double) (num2 + 1))
          --a;
      }
      if (_bDoubleRowStallAdjustment)
      {
        if (2 * a < _PlacementSettings.Parking.ADAStallCount)
          _PlacementSettings.Parking.CurrentADAStallCount = a;
        else if (_PlacementSettings.Parking.ADAStallCount > 0)
        {
          _PlacementSettings.Parking.CurrentADAStallCount = Math.DivRem(_PlacementSettings.Parking.ADAStallCount, 2, out result);
          if (result > 0)
            _PlacementSettings.Parking.CurrentADAStallCount += result;
        }
      }
      else
        _PlacementSettings.Parking.CurrentADAStallCount = a >= _PlacementSettings.Parking.ADAStallCount ? _PlacementSettings.Parking.ADAStallCount : a;
      if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
      {
        int num3 = Math.DivRem(_PlacementSettings.Parking.CurrentADAStallCount, 2, out result);
        if (result > 0)
          _dDistance -= _PlacementSettings.Parking.ADAStallWidth * (double) num3 + _PlacementSettings.Parking.ADAStallAdjustWidth * (double) (num3 + 1);
        else
          _dDistance -= (double) _PlacementSettings.Parking.CurrentADAStallCount * num1;
      }
      else
        _dDistance -= (double) _PlacementSettings.Parking.CurrentADAStallCount * num1;
    }
    if (RevitDefines.GT(_dDistance, 0.0))
    {
      int num4 = (int) (_dDistance / _PlacementSettings.Parking.StallAdjustWidth);
      if (num4 > 0)
        _PlacementSettings.Parking.CurrentStallCount = num4;
    }
    if (!_PlacementSettings.Parking.OptimizeParking)
    {
      if (_PlacementSettings.Parking.CurrentADAStallCount > _PlacementSettings.Parking.ADAStallCount)
        _PlacementSettings.Parking.CurrentADAStallCount = _PlacementSettings.Parking.ADAStallCount;
      if (_PlacementSettings.Parking.CurrentStallCount > _PlacementSettings.Parking.StallCount)
        _PlacementSettings.Parking.CurrentStallCount = _PlacementSettings.Parking.StallCount;
      if (_PlacementSettings.Parking.CurrentStallCount > 0 && _bDoubleRowStallAdjustment)
      {
        _PlacementSettings.Parking.CurrentStallCount = Math.DivRem(_PlacementSettings.Parking.CurrentStallCount, 2, out result);
        if (result > 0)
          _PlacementSettings.Parking.CurrentStallCount += result;
      }
    }
    return _PlacementSettings.Parking.CurrentStallCount + _PlacementSettings.Parking.CurrentADAStallCount;
  }

  private static void CalculateStallLength(
    ref PlacementSettings _PlacementSettings,
    double _dParkingAngle)
  {
    double num = Math.PI - _dParkingAngle - Math.PI / 2.0;
    if (RevitDefines.GT(_dParkingAngle, Math.PI / 2.0))
      num = -num;
    if (RevitDefines.EQ(num, Math.PI / 2.0))
      _PlacementSettings.Parking.StripeLength = _PlacementSettings.Parking.StallLength;
    else if (_PlacementSettings.Parking.CurrentADAStallCount > 0 && RevitDefines.GE(_PlacementSettings.Parking.ADAStallWidth, _PlacementSettings.Width) && _PlacementSettings.Parking.CurrentStallCount > 0 || _PlacementSettings.Parking.CurrentStallCount <= 0)
      _PlacementSettings.Parking.StripeLength = (_PlacementSettings.Parking.ADAStallAdjustWidthNoAisleWidth - _PlacementSettings.Parking.ADAStallWidth) / Math.Abs(Math.Cos(num)) + _PlacementSettings.Parking.StallLength;
    else
      _PlacementSettings.Parking.StripeLength = (_PlacementSettings.Parking.StallAdjustWidth - _PlacementSettings.Width) / Math.Abs(Math.Cos(num)) + _PlacementSettings.Parking.StallLength;
  }

  private static void CalculateStallParameters(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    double _dParkingAngle)
  {
    double d = Math.PI - _dParkingAngle - Math.PI / 2.0;
    if (RevitDefines.GT(_dParkingAngle, Math.PI / 2.0))
      d = -d;
    ParkingLotCommon.GetAisleWidthAdjustment(_Document, ref _PlacementSettings);
    _PlacementSettings.Parking.ADAStallAdjustWidthNoAisleWidth = _PlacementSettings.Parking.ADAStallWidth / Math.Cos(d);
    _PlacementSettings.Parking.ADAStallAisleAdjustWidth = _PlacementSettings.Parking.AdjustAisleWidth / Math.Cos(d);
    _PlacementSettings.Parking.ADAStallAdjustWidth = (_PlacementSettings.Parking.ADAStallWidth + _PlacementSettings.Parking.AdjustAisleWidth) / Math.Cos(d);
    _PlacementSettings.Parking.StallAdjustWidth = _PlacementSettings.Width / Math.Cos(d);
  }

  private static int CalculateNumberOfRows(
    PlacementSettings _PlacementSettings,
    Eps_Line _CurLine,
    ref double AdjRowHeight)
  {
    AdjRowHeight = 0.0;
    if (RevitDefines.EQ(_PlacementSettings.RotationAngle, Math.PI) || RevitDefines.EQ(_PlacementSettings.RotationAngle, 0.0))
      return 0;
    if (_PlacementSettings.Parking.AreaRowSpacingOptions == 0)
    {
      AdjRowHeight = _PlacementSettings.Parking.AreaDistanceBetweenCenterlines;
    }
    else
    {
      double num = _PlacementSettings.Parking.StripeLength;
      double areaAisleWidth = _PlacementSettings.Parking.AreaAisleWidth;
      if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle), Math.PI / 2.0) && !RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle), 3.0 * Math.PI / 2.0))
      {
        double d = Math.PI - _PlacementSettings.RotationAngle - Math.PI / 2.0;
        if (RevitDefines.GT(_PlacementSettings.RotationAngle, Math.PI / 2.0))
          d = -d;
        num = _PlacementSettings.Parking.StripeLength * Math.Cos(d);
      }
      AdjRowHeight = 2.0 * num + areaAisleWidth;
    }
    return _PlacementSettings.Parking.AreaRowCount;
  }

  private static bool IsStallWithinStallLength(
    Eps_Leg _NextLeg,
    Eps_Point _StallPoint,
    double _dParkingLength)
  {
    double _dStation = 0.0;
    double _dOffset = 0.0;
    bool flag = false;
    if (_NextLeg != null)
    {
      if (_NextLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_StallPoint, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        if (RevitDefines.LT(Math.Abs(_dOffset), _dParkingLength))
          flag = true;
      }
      else if (_NextLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(_StallPoint, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700 && RevitDefines.LT(Math.Abs(_dOffset), _dParkingLength))
        flag = true;
    }
    return flag;
  }

  private static void CreateSingleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    double SideAngle,
    bool _bDoubleRowStallAdjustment,
    ref Eps_Point _LastCurbPoint,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    bool _bDrawFirstDoubleStripe)
  {
    Eps_Leg _RemainingLeg = new Eps_Leg();
    ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _CurLine, SideAngle, _bDoubleRowStallAdjustment, (Eps_Leg) null, ref _RemainingLeg, ref _LastCurbPoint, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
  }

  private static void CreateSingleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    double SideAngle,
    bool _bDoubleRowStallAdjustment,
    Eps_Leg _NextLeg,
    ref Eps_Leg RemainingLeg,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref bool _bDrawFirstDoubleStripe)
  {
    Eps_Point _LastCurbPoint = new Eps_Point();
    ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _CurLine, SideAngle, _bDoubleRowStallAdjustment, _NextLeg, ref RemainingLeg, ref _LastCurbPoint, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
  }

  private static void CreateSingleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    double SideAngle,
    bool _bDoubleRowStallAdjustment,
    Eps_Leg _NextLeg,
    ref Eps_Leg _RemainingLeg,
    ref Eps_Point _LastCurbPoint,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref bool _bDrawFirstDoubleStripe)
  {
    Eps_Line epsLine = new Eps_Line();
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point _NewPnt1 = new Eps_Point();
    Eps_Point _NewPnt2 = new Eps_Point();
    double _dDirection1 = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    FamilyInstance familyInstance = (FamilyInstance) null;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CurLine.StartPnt, _CurLine.EndPnt, ref _dDirection1);
    ParkingLotCommon.CalculateStallParameters(_Document, ref _PlacementSettings, _PlacementSettings.RotationAngle);
    if (ParkingLotCommon.CalculateNumberOfStalls(ref _PlacementSettings, _CurLine, _bDoubleRowStallAdjustment) < 1)
      return;
    _ProgressFrm.ResetValue();
    _ProgressFrm.MinValue = 0;
    _ProgressFrm.MaxValue = !_PlacementSettings.Parking.ADAStallSharedAccessibleAisle ? Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) _PlacementSettings.Parking.CurrentADAStallCount + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount) : Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.ADAStallWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount);
    Thread.Sleep(300);
    ParkingLotCommon.CalculateStallLength(ref _PlacementSettings, _PlacementSettings.RotationAngle);
    Eps_Point _StartPnt = _CurLine.StartPnt;
    EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection1 + SideAngle), _PlacementSettings.Parking.StripeLength, ref epsPoint1);
    if (_RemainingLeg != null)
    {
      if (_RemainingLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(epsPoint1, _RemainingLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongLine(_RemainingLeg.Line, _dStation, 0.0, ref epsPoint1);
        _RemainingLeg.Line.StartPnt = epsPoint1;
      }
      else if (_RemainingLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(epsPoint1, _RemainingLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongArc(_RemainingLeg.Arc, _dStation, 0.0, ref epsPoint1);
        _RemainingLeg.Arc.StartPnt = epsPoint1;
        double _dDistance = 0.0;
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_RemainingLeg.Arc.StartPnt, _RemainingLeg.Arc.EndPnt, ref _dDistance);
        double _dDeltaAngle = 0.0;
        EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _RemainingLeg.Arc.Radius, ref _dDeltaAngle);
        _RemainingLeg.Arc.Delta = _dDeltaAngle;
      }
    }
    double _dDirection2;
    bool flag;
    if (RevitDefines.LT(SideAngle, Math.PI) && RevitDefines.GE(SideAngle, 0.0))
    {
      _dDirection2 = EPShared.eplGeoE_NormalizeRadians(_dDirection1 + Math.PI);
      flag = true;
    }
    else
    {
      _dDirection2 = _dDirection1;
      flag = false;
    }
    bool _bIsHCapStall = true;
    double _dPolarDistance = _PlacementSettings.Parking.ADAStallAdjustWidth;
    double adaStallWidth = _PlacementSettings.Parking.ADAStallWidth;
    FamilySymbol _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
    for (int index = 0; index < _PlacementSettings.Parking.CurrentADAStallCount; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection1), _dPolarDistance, ref _NewPnt1);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(_dDirection1 + SideAngle), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      if (!ParkingLotCommon.IsStallWithinStallLength(_NextLeg, _NewPnt2, _PlacementSettings.Parking.StallLength))
      {
        if (RevitDefines.LT(SideAngle, Math.PI) && RevitDefines.GE(SideAngle, 0.0))
        {
          if (RevitDefines.LT(_PlacementSettings.RotationAngle, Math.PI / 2.0) && RevitDefines.GE(_PlacementSettings.RotationAngle, 0.0))
          {
            if (_bIsHCapStall && !flag && _PlacementSettings.Parking.ADAStallAisleAdjustWidth > 0.0)
            {
              EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection1), _PlacementSettings.Parking.ADAStallAisleAdjustWidth, ref epsPoint1);
              epsLine.StartPnt = epsPoint1;
            }
            else
              epsLine.StartPnt = _StartPnt;
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), adaStallWidth, ref epsPoint1);
            epsLine.EndPnt = epsPoint1;
          }
          else
          {
            if (_bIsHCapStall && flag && _PlacementSettings.Parking.ADAStallAisleAdjustWidth > 0.0)
            {
              EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection1), _PlacementSettings.Parking.ADAStallAisleAdjustWidth, ref epsPoint1);
              epsLine.EndPnt = epsPoint1;
            }
            else
              epsLine.EndPnt = _NewPnt1;
            EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), adaStallWidth, ref epsPoint1);
            epsLine.StartPnt = epsPoint1;
          }
        }
        else if (RevitDefines.LT(_PlacementSettings.RotationAngle, Math.PI / 2.0) && RevitDefines.GE(_PlacementSettings.RotationAngle, 0.0))
        {
          if (_bIsHCapStall && !flag && _PlacementSettings.Parking.ADAStallAisleAdjustWidth > 0.0)
          {
            EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection1), _PlacementSettings.Parking.ADAStallAisleAdjustWidth, ref epsPoint1);
            epsLine.EndPnt = epsPoint1;
          }
          else
            epsLine.EndPnt = _NewPnt1;
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), adaStallWidth, ref epsPoint1);
          epsLine.StartPnt = epsPoint1;
        }
        else
        {
          if (_bIsHCapStall && flag && _PlacementSettings.Parking.ADAStallAisleAdjustWidth > 0.0)
          {
            EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection1), _PlacementSettings.Parking.ADAStallAisleAdjustWidth, ref epsPoint1);
            epsLine.StartPnt = epsPoint1;
          }
          else
            epsLine.StartPnt = _StartPnt;
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), adaStallWidth, ref epsPoint1);
          epsLine.EndPnt = epsPoint1;
        }
        if (_PlacementSettings.Parking.PlaceBumper)
        {
          if (RevitDefines.LT(SideAngle, Math.PI) && RevitDefines.GE(SideAngle, 0.0))
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
            EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), adaStallWidth / 2.0, ref epsPoint1);
            ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, adaStallWidth, Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1), ref _ExistingBumperList);
          }
          else
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
            EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), adaStallWidth / 2.0, ref epsPoint1);
            ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, adaStallWidth, 3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1), ref _ExistingBumperList);
          }
        }
        bool _bHideRightStripe;
        bool _bHideLeftStripe;
        if (flag)
        {
          EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection1), _dPolarDistance, ref epsPoint1);
          _bHideRightStripe = false;
          _bHideLeftStripe = true;
          if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _bDrawFirstDoubleStripe)
            _bHideRightStripe = true;
          else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentADAStallCount - 1)
            _bHideLeftStripe = false;
        }
        else
        {
          epsPoint1 = _StartPnt;
          _bHideRightStripe = true;
          _bHideLeftStripe = false;
          if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _bDrawFirstDoubleStripe)
            _bHideLeftStripe = true;
          else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentADAStallCount - 1)
            _bHideRightStripe = false;
        }
        familyInstance = !_bIsHCapStall ? ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _StallSymbol, _dDirection2, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe, _bHideRightStripe, _bIsHCapStall, !flag, ref _ExistingParkingStallList) : ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _StallSymbol, _dDirection2, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe, _bHideRightStripe, _bIsHCapStall, !flag, ref _ExistingADAParkingStallList);
        _StartPnt = _NewPnt1;
        _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_dPolarDistance));
        if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
        {
          _bIsHCapStall = !_bIsHCapStall;
          if (_bIsHCapStall)
          {
            _dPolarDistance = _PlacementSettings.Parking.ADAStallAdjustWidth;
            _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
          }
          else
          {
            _dPolarDistance = _PlacementSettings.Parking.ADAStallWidth;
            _StallSymbol = _PlacementSettings.Type;
          }
        }
      }
      else
      {
        if (!_PlacementSettings.Parking.SidesOnIsland && familyInstance != null)
        {
          ((Element) familyInstance).LookupParameter(RevitParameters.RightVisibleParameter)?.Set(Convert.ToInt32(true));
          familyInstance = (FamilyInstance) null;
        }
        _PlacementSettings.Parking.CurrentADAStallCount = index;
        break;
      }
    }
    for (int index = 0; index < _PlacementSettings.Parking.CurrentStallCount; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection1), _PlacementSettings.Parking.StallAdjustWidth, ref _NewPnt1);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(_dDirection1 + SideAngle), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      if (!ParkingLotCommon.IsStallWithinStallLength(_NextLeg, _NewPnt2, _PlacementSettings.Parking.StallLength))
      {
        if (RevitDefines.LT(SideAngle, Math.PI) && RevitDefines.GE(SideAngle, 0.0))
        {
          if (RevitDefines.LT(_PlacementSettings.RotationAngle, Math.PI / 2.0) && RevitDefines.GE(_PlacementSettings.RotationAngle, 0.0))
          {
            epsLine.StartPnt = _StartPnt;
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Width, ref epsPoint1);
            epsLine.EndPnt = epsPoint1;
          }
          else
          {
            epsLine.EndPnt = _NewPnt1;
            EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Width, ref epsPoint1);
            epsLine.StartPnt = epsPoint1;
          }
        }
        else if (RevitDefines.LT(_PlacementSettings.RotationAngle, Math.PI / 2.0) && RevitDefines.GE(_PlacementSettings.RotationAngle, 0.0))
        {
          epsLine.EndPnt = _NewPnt1;
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Width, ref epsPoint1);
          epsLine.StartPnt = epsPoint1;
        }
        else
        {
          epsLine.StartPnt = _StartPnt;
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Width, ref epsPoint1);
          epsLine.EndPnt = epsPoint1;
        }
        if (_PlacementSettings.Parking.PlaceBumper)
        {
          if (RevitDefines.LT(SideAngle, Math.PI) && RevitDefines.GE(SideAngle, 0.0))
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
            EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Width / 2.0, ref epsPoint1);
            ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Width, Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1), ref _ExistingBumperList);
          }
          else
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
            EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1)), _PlacementSettings.Width / 2.0, ref epsPoint1);
            ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Width, 3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection1), ref _ExistingBumperList);
          }
        }
        bool _bHideRightStripe;
        bool _bHideLeftStripe;
        if (flag)
        {
          EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection1), _PlacementSettings.Parking.StallAdjustWidth, ref epsPoint1);
          _bHideRightStripe = false;
          _bHideLeftStripe = true;
          if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _PlacementSettings.Parking.CurrentADAStallCount == 0 && _bDrawFirstDoubleStripe)
            _bHideRightStripe = true;
          else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentStallCount - 1)
            _bHideLeftStripe = false;
        }
        else
        {
          epsPoint1 = _StartPnt;
          _bHideRightStripe = true;
          _bHideLeftStripe = false;
          if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _PlacementSettings.Parking.CurrentADAStallCount == 0 && _bDrawFirstDoubleStripe)
            _bHideLeftStripe = true;
          else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentStallCount - 1)
            _bHideRightStripe = false;
        }
        familyInstance = ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Type, _dDirection2, _PlacementSettings.Parking.StallLength, _PlacementSettings.Width, _PlacementSettings.RotationAngle, _bHideLeftStripe, _bHideRightStripe, ref _ExistingParkingStallList);
        _StartPnt = _NewPnt1;
        _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Parking.StallAdjustWidth));
      }
      else
      {
        if (!_PlacementSettings.Parking.SidesOnIsland && familyInstance != null)
          ((Element) familyInstance).LookupParameter(RevitParameters.RightVisibleParameter)?.Set(Convert.ToInt32(true));
        _PlacementSettings.Parking.CurrentStallCount = index;
        break;
      }
    }
    if (!_PlacementSettings.Parking.OptimizeParking)
      _PlacementSettings.Parking.StallCount -= _PlacementSettings.Parking.CurrentStallCount;
    _PlacementSettings.Parking.ADAStallCount -= _PlacementSettings.Parking.CurrentADAStallCount;
    if (_NextLeg != null)
    {
      if (_NextLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt2, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongLine(_NextLeg.Line, _dStation, 0.0, ref epsPoint1);
        _NextLeg.Line.StartPnt = epsPoint1;
      }
      else if (_NextLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt2, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongArc(_NextLeg.Arc, _dStation, 0.0, ref epsPoint1);
        _NextLeg.Arc.StartPnt = epsPoint1;
        double _dDistance = 0.0;
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NextLeg.Arc.StartPnt, _NextLeg.Arc.EndPnt, ref _dDistance);
        double _dDeltaAngle = 0.0;
        EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _NextLeg.Arc.Radius, ref _dDeltaAngle);
        _NextLeg.Arc.Delta = _dDeltaAngle;
      }
    }
    _LastCurbPoint = _StartPnt;
    _bDrawFirstDoubleStripe = true;
  }

  private static void CreateDoubleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref List<FamilyInstance> _ExistingIslandList)
  {
    Eps_Line epsLine = new Eps_Line();
    Eps_Point epsPoint = new Eps_Point();
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    if (_CurLine == null)
      return;
    bool _bIsHCapStall = true;
    double _dPolarDistance = _PlacementSettings.Parking.ADAStallAdjustWidth;
    double adaStallWidth = _PlacementSettings.Parking.ADAStallWidth;
    double widthNoAisleWidth = _PlacementSettings.Parking.ADAStallAdjustWidthNoAisleWidth;
    FamilySymbol _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CurLine.StartPnt, _CurLine.EndPnt, ref _dDirection);
    Eps_Point startPnt = _CurLine.StartPnt;
    if (_PlacementSettings.Parking.IslandSymbol != null && _PlacementSettings.Parking.IslandWidth > 0.0 && !_PlacementSettings.Parking.CenterIsland)
    {
      EPShared.eplGeoE_CalcPolarToXY(startPnt, _dDirection, _PlacementSettings.Parking.IslandWidth, ref startPnt);
      ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, _CurLine.StartPnt, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
      ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, startPnt, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), ref _ExistingIslandList);
    }
    for (int index = 0; index < _PlacementSettings.Parking.CurrentADAStallCount; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), widthNoAisleWidth * 0.5, ref epsPoint);
      epsLine.StartPnt = epsPoint;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth * 0.5, ref epsPoint);
      epsLine.StartPnt = epsPoint;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth, ref epsPoint);
      epsLine.EndPnt = epsPoint;
      if (_PlacementSettings.Parking.OptimizeParking)
      {
        if (_PlacementSettings.Parking.IslandWidth > 0.0)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
          epsLine.StartPnt = epsPoint;
        }
        EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth / 2.0, ref epsPoint);
        ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint, adaStallWidth, Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
        if (_PlacementSettings.Parking.IslandWidth > 0.0)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
          epsLine.EndPnt = epsPoint;
        }
        EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth / 2.0, ref epsPoint);
        ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint, adaStallWidth, 3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
      }
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _dPolarDistance, ref epsPoint);
      bool _bHideRightStripe1 = false;
      bool _bHideLeftStripe1 = true;
      if (!_PlacementSettings.Parking.SidesOnIsland && index == 0)
        _bHideRightStripe1 = true;
      else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentADAStallCount - 1)
        _bHideLeftStripe1 = false;
      if (_PlacementSettings.Parking.IslandWidth > 0.0)
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
      if (_bIsHCapStall)
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint, _StallSymbol, _dDirection + Math.PI, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe1, _bHideRightStripe1, _bIsHCapStall, false, ref _ExistingADAParkingStallList);
      else
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint, _StallSymbol, _dDirection + Math.PI, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe1, _bHideRightStripe1, _bIsHCapStall, false, ref _ExistingParkingStallList);
      epsPoint = startPnt;
      bool _bHideRightStripe2 = true;
      bool _bHideLeftStripe2 = false;
      if (!_PlacementSettings.Parking.SidesOnIsland && index == 0)
        _bHideLeftStripe2 = true;
      else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentADAStallCount - 1)
        _bHideRightStripe2 = false;
      if (_PlacementSettings.Parking.IslandWidth > 0.0)
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
      if (_bIsHCapStall)
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint, _StallSymbol, _dDirection, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe2, _bHideRightStripe2, _bIsHCapStall, true, ref _ExistingADAParkingStallList);
      else
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint, _StallSymbol, _dDirection, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe2, _bHideRightStripe2, _bIsHCapStall, true, ref _ExistingParkingStallList);
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _dPolarDistance, ref startPnt);
      _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_dPolarDistance));
      if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
      {
        _bIsHCapStall = !_bIsHCapStall;
        if (_bIsHCapStall)
        {
          _dPolarDistance = _PlacementSettings.Parking.ADAStallAdjustWidth;
          _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
        }
        else
        {
          _dPolarDistance = _PlacementSettings.Parking.ADAStallWidth;
          _StallSymbol = _PlacementSettings.Type;
        }
      }
    }
    for (int index = 0; index < _PlacementSettings.Parking.CurrentStallCount; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.StallAdjustWidth * 0.5, ref epsPoint);
      epsLine.StartPnt = epsPoint;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width * 0.5, ref epsPoint);
      epsLine.StartPnt = epsPoint;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width, ref epsPoint);
      epsLine.EndPnt = epsPoint;
      if (_PlacementSettings.Parking.OptimizeParking)
      {
        if (_PlacementSettings.Parking.IslandWidth > 0.0)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
          epsLine.StartPnt = epsPoint;
        }
        EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width / 2.0, ref epsPoint);
        ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint, _PlacementSettings.Width, Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
        if (_PlacementSettings.Parking.IslandWidth > 0.0)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
          epsLine.EndPnt = epsPoint;
        }
        EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width / 2.0, ref epsPoint);
        ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint, _PlacementSettings.Width, 3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
      }
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.StallAdjustWidth, ref epsPoint);
      bool _bHideRightStripe3 = false;
      bool _bHideLeftStripe3 = true;
      if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _PlacementSettings.Parking.CurrentADAStallCount == 0)
        _bHideRightStripe3 = true;
      else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentStallCount - 1)
        _bHideLeftStripe3 = false;
      if (_PlacementSettings.Parking.IslandWidth > 0.0)
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
      ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint, _PlacementSettings.Type, _dDirection + Math.PI, _PlacementSettings.Parking.StallLength, _PlacementSettings.Width, _PlacementSettings.RotationAngle, _bHideLeftStripe3, _bHideRightStripe3, ref _ExistingParkingStallList);
      epsPoint = startPnt;
      bool _bHideRightStripe4 = true;
      bool _bHideLeftStripe4 = false;
      if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _PlacementSettings.Parking.CurrentADAStallCount == 0)
        _bHideLeftStripe4 = true;
      else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentStallCount - 1)
        _bHideRightStripe4 = false;
      if (_PlacementSettings.Parking.IslandWidth > 0.0)
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint);
      ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint, _PlacementSettings.Type, _dDirection, _PlacementSettings.Parking.StallLength, _PlacementSettings.Width, _PlacementSettings.RotationAngle, _bHideLeftStripe4, _bHideRightStripe4, ref _ExistingParkingStallList);
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.StallAdjustWidth, ref startPnt);
      _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Parking.StallAdjustWidth));
    }
    if (!_PlacementSettings.Parking.OptimizeParking)
      _PlacementSettings.Parking.StallCount -= 2 * _PlacementSettings.Parking.CurrentStallCount;
    _PlacementSettings.Parking.ADAStallCount -= 2 * _PlacementSettings.Parking.CurrentADAStallCount;
    if (_PlacementSettings.Parking.IslandSymbol == null || _PlacementSettings.Parking.IslandWidth <= 0.0)
      return;
    if (_PlacementSettings.Parking.CenterIsland)
    {
      EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_CurLine.StartPnt, startPnt, ref epsPoint);
      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CurLine.StartPnt, startPnt, ref _dDistance);
      ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint, _dDistance, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
    }
    else
    {
      ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, startPnt, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
      EPShared.eplGeoE_CalcPolarToXY(startPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.IslandWidth, ref epsPoint);
      ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), ref _ExistingIslandList);
    }
  }

  private static void CreateDoubleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    Eps_Point _LastCurbPoint,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    bool _bDrawFirstDoubleStripe)
  {
    Eps_Leg _RemainingLeg = new Eps_Leg();
    ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _CurLine, (Eps_Leg) null, ref _RemainingLeg, ref _LastCurbPoint, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
  }

  private static void CreateDoubleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    Eps_Leg _NextLeg,
    ref Eps_Leg _RemainingLeg,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref bool _bDrawFirstDoubleStripe)
  {
    Eps_Point _LastCurbPoint = new Eps_Point();
    ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _CurLine, _NextLeg, ref _RemainingLeg, ref _LastCurbPoint, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
  }

  private static void CreateDoubleStalls(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    Eps_Leg _NextLeg,
    ref Eps_Leg _RemainingLeg,
    ref Eps_Point _LastCurbPoint,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref bool _bDrawFirstDoubleStripe)
  {
    Eps_Line epsLine = new Eps_Line();
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point _NewPnt1 = new Eps_Point();
    Eps_Point _NewPnt2 = new Eps_Point();
    Eps_Point _NewPnt3 = new Eps_Point();
    Eps_Point _NewPnt4 = new Eps_Point();
    Eps_Point _NewPnt5 = new Eps_Point();
    double _dDirection = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    bool flag1 = false;
    bool flag2 = true;
    FamilyInstance familyInstance = (FamilyInstance) null;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CurLine.StartPnt, _CurLine.EndPnt, ref _dDirection);
    ParkingLotCommon.CalculateStallParameters(_Document, ref _PlacementSettings, _PlacementSettings.RotationAngle);
    if (ParkingLotCommon.CalculateNumberOfStalls(ref _PlacementSettings, _CurLine, true) < 1)
      return;
    _ProgressFrm.ResetValue();
    _ProgressFrm.MinValue = 0;
    _ProgressFrm.MaxValue = !_PlacementSettings.Parking.ADAStallSharedAccessibleAisle ? Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.StallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentStallCount / 2)) : Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 4) + _PlacementSettings.Parking.ADAStallWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 4) + _PlacementSettings.Parking.StallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentStallCount / 2));
    Thread.Sleep(300);
    ParkingLotCommon.CalculateStallLength(ref _PlacementSettings, _PlacementSettings.RotationAngle);
    Eps_Point _StartPnt = _CurLine.StartPnt;
    EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.StripeLength, ref _NewPnt4);
    EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.StripeLength, ref _NewPnt5);
    if (_RemainingLeg != null)
    {
      if (_RemainingLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt4, _RemainingLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongLine(_RemainingLeg.Line, _dStation, 0.0, ref epsPoint1);
        _RemainingLeg.Line.StartPnt = epsPoint1;
      }
      else if (_RemainingLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt4, _RemainingLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongArc(_RemainingLeg.Arc, _dStation, 0.0, ref epsPoint1);
        _RemainingLeg.Arc.StartPnt = epsPoint1;
        double _dDistance = 0.0;
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_RemainingLeg.Arc.StartPnt, _RemainingLeg.Arc.EndPnt, ref _dDistance);
        double _dDeltaAngle = 0.0;
        EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _RemainingLeg.Arc.Radius, ref _dDeltaAngle);
        _RemainingLeg.Arc.Delta = _dDeltaAngle;
      }
      else if (_RemainingLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt5, _RemainingLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongLine(_RemainingLeg.Line, _dStation, 0.0, ref epsPoint1);
        _RemainingLeg.Line.StartPnt = epsPoint1;
      }
      else if (_RemainingLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt5, _RemainingLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700)
      {
        EPShared.eplGeoE_FindStaOffPointAlongArc(_RemainingLeg.Arc, _dStation, 0.0, ref epsPoint1);
        _RemainingLeg.Arc.StartPnt = epsPoint1;
        double _dDistance = 0.0;
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_RemainingLeg.Arc.StartPnt, _RemainingLeg.Arc.EndPnt, ref _dDistance);
        double _dDeltaAngle = 0.0;
        EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _RemainingLeg.Arc.Radius, ref _dDeltaAngle);
        _RemainingLeg.Arc.Delta = _dDeltaAngle;
      }
    }
    bool _bIsHCapStall = true;
    double _dPolarDistance = _PlacementSettings.Parking.ADAStallAdjustWidth;
    double adaStallWidth = _PlacementSettings.Parking.ADAStallWidth;
    double widthNoAisleWidth = _PlacementSettings.Parking.ADAStallAdjustWidthNoAisleWidth;
    FamilySymbol _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
    for (int index = 0; index < _PlacementSettings.Parking.CurrentADAStallCount; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), widthNoAisleWidth * 0.5, ref epsPoint1);
      epsLine.StartPnt = epsPoint1;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth * 0.5, ref epsPoint1);
      epsLine.StartPnt = epsPoint1;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth, ref epsPoint1);
      epsLine.EndPnt = epsPoint1;
      EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _dPolarDistance, ref _NewPnt1);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.StripeLength, ref _NewPnt3);
      if (!ParkingLotCommon.IsStallWithinStallLength(_NextLeg, _NewPnt2, _PlacementSettings.Parking.StallLength) && !ParkingLotCommon.IsStallWithinStallLength(_NextLeg, _NewPnt3, _PlacementSettings.Parking.StallLength))
      {
        if (_PlacementSettings.Parking.PlaceBumper)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth / 2.0, ref epsPoint1);
          ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, adaStallWidth, Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), adaStallWidth / 2.0, ref epsPoint1);
          ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, adaStallWidth, 3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
        }
        EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _dPolarDistance, ref epsPoint1);
        bool _bHideRightStripe1 = false;
        bool _bHideLeftStripe1 = true;
        if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _bDrawFirstDoubleStripe)
          _bHideRightStripe1 = true;
        else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentADAStallCount - 1)
          _bHideLeftStripe1 = false;
        if (_bIsHCapStall)
          ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _StallSymbol, _dDirection + Math.PI, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe1, _bHideRightStripe1, _bIsHCapStall, false, ref _ExistingADAParkingStallList);
        else
          ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _StallSymbol, _dDirection + Math.PI, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe1, _bHideRightStripe1, _bIsHCapStall, false, ref _ExistingParkingStallList);
        epsPoint1 = _StartPnt;
        bool _bHideRightStripe2 = true;
        bool _bHideLeftStripe2 = false;
        if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _bDrawFirstDoubleStripe)
          _bHideLeftStripe2 = true;
        else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentADAStallCount - 1)
          _bHideRightStripe2 = false;
        familyInstance = !_bIsHCapStall ? ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _StallSymbol, _dDirection, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe2, _bHideRightStripe2, _bIsHCapStall, true, ref _ExistingParkingStallList) : ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _StallSymbol, _dDirection, _PlacementSettings.Parking.StallLength, adaStallWidth, _PlacementSettings.RotationAngle, _bHideLeftStripe2, _bHideRightStripe2, _bIsHCapStall, true, ref _ExistingADAParkingStallList);
        _StartPnt = _NewPnt1;
        _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_dPolarDistance));
        if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
        {
          _bIsHCapStall = !_bIsHCapStall;
          if (_bIsHCapStall)
          {
            _dPolarDistance = _PlacementSettings.Parking.ADAStallAdjustWidth;
            _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
          }
          else
          {
            _dPolarDistance = _PlacementSettings.Parking.ADAStallWidth;
            _StallSymbol = _PlacementSettings.Type;
          }
        }
      }
      else
      {
        if (!_PlacementSettings.Parking.SidesOnIsland && familyInstance != null)
        {
          ((Element) familyInstance).LookupParameter(RevitParameters.RightVisibleParameter)?.Set(Convert.ToInt32(true));
          familyInstance = (FamilyInstance) null;
        }
        _PlacementSettings.Parking.CurrentADAStallCount = index;
        break;
      }
    }
    for (int index = 0; index < _PlacementSettings.Parking.CurrentStallCount; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.StallAdjustWidth * 0.5, ref epsPoint1);
      epsLine.StartPnt = epsPoint1;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width * 0.5, ref epsPoint1);
      epsLine.StartPnt = epsPoint1;
      EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width, ref epsPoint1);
      epsLine.EndPnt = epsPoint1;
      EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.StallAdjustWidth, ref _NewPnt1);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.StripeLength, ref _NewPnt3);
      if (!ParkingLotCommon.IsStallWithinStallLength(_NextLeg, _NewPnt2, _PlacementSettings.Parking.StallLength) && !ParkingLotCommon.IsStallWithinStallLength(_NextLeg, _NewPnt3, _PlacementSettings.Parking.StallLength))
      {
        if (_PlacementSettings.Parking.PlaceBumper)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width / 2.0, ref epsPoint1);
          ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Width, Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(2.0 * Math.PI - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint1);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint1, EPShared.eplGeoE_NormalizeRadians(3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection)), _PlacementSettings.Width / 2.0, ref epsPoint1);
          ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Width, 3.0 * Math.PI / 2.0 - (_PlacementSettings.RotationAngle - _dDirection), ref _ExistingBumperList);
        }
        EPShared.eplGeoE_CalcPolarToXY(_StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _PlacementSettings.Parking.StallAdjustWidth, ref epsPoint1);
        bool _bHideRightStripe3 = false;
        bool _bHideLeftStripe3 = true;
        if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _PlacementSettings.Parking.CurrentADAStallCount == 0 && _bDrawFirstDoubleStripe)
          _bHideRightStripe3 = true;
        else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentStallCount - 1)
          _bHideLeftStripe3 = false;
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Type, _dDirection + Math.PI, _PlacementSettings.Parking.StallLength, _PlacementSettings.Width, _PlacementSettings.RotationAngle, _bHideLeftStripe3, _bHideRightStripe3, ref _ExistingParkingStallList);
        epsPoint1 = _StartPnt;
        bool _bHideRightStripe4 = true;
        bool _bHideLeftStripe4 = false;
        if (!_PlacementSettings.Parking.SidesOnIsland && index == 0 && _PlacementSettings.Parking.CurrentADAStallCount == 0 && _bDrawFirstDoubleStripe)
          _bHideLeftStripe4 = true;
        else if (_PlacementSettings.Parking.SidesOnIsland && index == _PlacementSettings.Parking.CurrentStallCount - 1)
          _bHideRightStripe4 = false;
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Type, _dDirection, _PlacementSettings.Parking.StallLength, _PlacementSettings.Width, _PlacementSettings.RotationAngle, _bHideLeftStripe4, _bHideRightStripe4, ref _ExistingParkingStallList);
        flag1 = false;
        flag2 = true;
        _StartPnt = _NewPnt1;
        _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Parking.StallAdjustWidth));
      }
      else
      {
        if (!_PlacementSettings.Parking.SidesOnIsland && familyInstance != null)
          ((Element) familyInstance).LookupParameter(RevitParameters.RightVisibleParameter)?.Set(Convert.ToInt32(true));
        _PlacementSettings.Parking.CurrentStallCount = index;
        break;
      }
    }
    if (!_PlacementSettings.Parking.OptimizeParking)
      _PlacementSettings.Parking.StallCount -= 2 * _PlacementSettings.Parking.CurrentStallCount;
    _PlacementSettings.Parking.ADAStallCount -= 2 * _PlacementSettings.Parking.CurrentADAStallCount;
    if (_NextLeg != null)
    {
      if (_NextLeg.Line != null)
      {
        if (EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt2, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
        {
          EPShared.eplGeoE_FindStaOffPointAlongLine(_NextLeg.Line, _dStation, 0.0, ref epsPoint1);
          _NextLeg.Line.StartPnt = epsPoint1;
        }
        else if (EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt3, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
        {
          EPShared.eplGeoE_FindStaOffPointAlongLine(_NextLeg.Line, _dStation, 0.0, ref epsPoint1);
          _NextLeg.Line.StartPnt = epsPoint1;
        }
      }
      else if (_NextLeg.Arc != null)
      {
        if (EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt2, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700)
        {
          EPShared.eplGeoE_FindStaOffPointAlongArc(_NextLeg.Arc, _dStation, 0.0, ref epsPoint1);
          _NextLeg.Arc.StartPnt = epsPoint1;
          double _dDistance = 0.0;
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NextLeg.Arc.StartPnt, _NextLeg.Arc.EndPnt, ref _dDistance);
          double _dDeltaAngle = 0.0;
          EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _NextLeg.Arc.Radius, ref _dDeltaAngle);
          _NextLeg.Arc.Delta = _dDeltaAngle;
        }
        else if (EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt3, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700)
        {
          EPShared.eplGeoE_FindStaOffPointAlongArc(_NextLeg.Arc, _dStation, 0.0, ref epsPoint1);
          _NextLeg.Arc.StartPnt = epsPoint1;
          double _dDistance = 0.0;
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NextLeg.Arc.StartPnt, _NextLeg.Arc.EndPnt, ref _dDistance);
          double _dDeltaAngle = 0.0;
          EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _NextLeg.Arc.Radius, ref _dDeltaAngle);
          _NextLeg.Arc.Delta = _dDeltaAngle;
        }
      }
    }
    _LastCurbPoint = _StartPnt;
    _bDrawFirstDoubleStripe = true;
  }

  private static void DrawCurvedParking(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Arc _CurrentArc,
    bool _bIsInside,
    bool _bDoubleRowStallAdjustment,
    Eps_Leg _NextLeg,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList)
  {
    double num1 = 0.0;
    double _dDirection1 = 0.0;
    Eps_Line epsLine1 = new Eps_Line();
    Eps_Line epsLine2 = new Eps_Line();
    Eps_Line epsLine3 = new Eps_Line();
    Eps_Point epsPoint = new Eps_Point();
    Eps_Point _NewPnt1 = new Eps_Point();
    Eps_Point _InsertPoint = new Eps_Point();
    Eps_Point _NewPnt2 = new Eps_Point();
    int result = 0;
    double _dDirection2 = 0.0;
    bool _bRightAisle = false;
    double num2 = 0.0;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    Eps_Arc epsArc = new Eps_Arc(_CurrentArc);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsArc.RadiusPnt, epsArc.StartPnt, ref _dDirection1);
    double num3;
    double num4;
    if (_bIsInside)
    {
      num3 = EPShared.eplGeoE_NormalizeRadians(_dDirection1 + Math.PI);
      num4 = epsArc.Direction == 1 ? Math.PI / 2.0 : 3.0 * Math.PI / 2.0;
      num1 = (epsArc.Radius - _PlacementSettings.Parking.StallLength) * 2.0 * Math.PI * (epsArc.Delta / (2.0 * Math.PI));
      num2 = _PlacementSettings.Parking.StallLength;
      if (epsArc.Direction == -1)
        _bRightAisle = true;
      else if (epsArc.Direction == 1)
        _bRightAisle = false;
    }
    else
    {
      num3 = _dDirection1;
      num4 = epsArc.Direction == -1 ? Math.PI / 2.0 : 3.0 * Math.PI / 2.0;
      num1 = epsArc.Radius * 2.0 * Math.PI * (epsArc.Delta / (2.0 * Math.PI));
      if (epsArc.Direction == -1)
        _bRightAisle = false;
      else if (epsArc.Direction == 1)
        _bRightAisle = true;
    }
    ParkingLotCommon.CalculateStallParameters(_Document, ref _PlacementSettings, Math.PI / 2.0);
    double num5 = (Math.PI / 2.0 - Math.Acos(_PlacementSettings.Parking.ADAStallAdjustWidth / 2.0 / (epsArc.Radius - num2))) * 2.0;
    double num6 = (Math.PI / 2.0 - Math.Acos(_PlacementSettings.Parking.ADAStallWidth / 2.0 / (epsArc.Radius - num2))) * 2.0;
    double num7 = (Math.PI / 2.0 - Math.Acos(_PlacementSettings.Width / 2.0 / (epsArc.Radius - num2))) * 2.0;
    double delta = epsArc.Delta;
    _PlacementSettings.Parking.CurrentStallCount = 0;
    _PlacementSettings.Parking.CurrentADAStallCount = 0;
    double num8 = !_PlacementSettings.Parking.ADAStallSharedAccessibleAisle ? num6 : (num6 + num5) / 2.0;
    if (_PlacementSettings.Parking.ADAStallCount >= 1)
    {
      int a = (int) (delta / num8);
      if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
      {
        int num9 = Math.DivRem(a, 2, out result);
        if (result > 0 && delta < num6 * (double) num9 + num5 * (double) (num9 + 1))
          --a;
      }
      if (_bDoubleRowStallAdjustment)
      {
        if (2 * a < _PlacementSettings.Parking.ADAStallCount)
          _PlacementSettings.Parking.CurrentADAStallCount = a;
        else if (_PlacementSettings.Parking.ADAStallCount > 0)
          _PlacementSettings.Parking.CurrentADAStallCount = _PlacementSettings.Parking.ADAStallCount / 2;
      }
      else
        _PlacementSettings.Parking.CurrentADAStallCount = a >= _PlacementSettings.Parking.ADAStallCount ? _PlacementSettings.Parking.ADAStallCount : a;
      if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
      {
        int num10 = Math.DivRem(_PlacementSettings.Parking.CurrentADAStallCount, 2, out result);
        if (result > 0)
          delta -= num6 * (double) num10 + num5 * (double) (num10 + 1);
        else
          delta -= num8 * (double) _PlacementSettings.Parking.CurrentADAStallCount;
      }
      else
        delta -= num8 * (double) _PlacementSettings.Parking.CurrentADAStallCount;
    }
    if (RevitDefines.GT(delta, 0.0))
    {
      int num11 = (int) (delta / num7);
      if (num11 > 0)
        _PlacementSettings.Parking.CurrentStallCount = num11;
    }
    if (!_PlacementSettings.Parking.OptimizeParking)
    {
      if (_PlacementSettings.Parking.CurrentADAStallCount > _PlacementSettings.Parking.ADAStallCount)
        _PlacementSettings.Parking.CurrentADAStallCount = _PlacementSettings.Parking.ADAStallCount;
      if (_PlacementSettings.Parking.CurrentStallCount > _PlacementSettings.Parking.StallCount)
        _PlacementSettings.Parking.CurrentStallCount = _PlacementSettings.Parking.StallCount;
      if (_PlacementSettings.Parking.CurrentStallCount > 0 && _bDoubleRowStallAdjustment)
        _PlacementSettings.Parking.CurrentStallCount /= 2;
    }
    if (_PlacementSettings.Parking.CurrentStallCount + _PlacementSettings.Parking.CurrentADAStallCount <= 0)
      return;
    _ProgressFrm.ResetValue();
    _ProgressFrm.MinValue = 0;
    _ProgressFrm.MaxValue = Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) _PlacementSettings.Parking.CurrentADAStallCount + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount);
    Thread.Sleep(300);
    ParkingLotCommon.CalculateStallLength(ref _PlacementSettings, Math.PI / 2.0);
    if (epsArc.Direction != 1)
    {
      num6 *= -1.0;
      num7 *= -1.0;
    }
    bool _bIsHCapStall = true;
    double num12 = _PlacementSettings.Parking.ADAStallAdjustWidth;
    double adaStallWidth = _PlacementSettings.Parking.ADAStallWidth;
    double num13 = num5;
    double num14 = _dDirection1;
    double _dAngle = num3;
    FamilySymbol _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
    for (int index = 0; index < _PlacementSettings.Parking.CurrentADAStallCount; ++index)
    {
      double _dPolarDirection = EPShared.eplGeoE_NormalizeRadians(num14 + num13 * 0.5);
      EPShared.eplGeoE_CalcPolarToXY(epsArc.RadiusPnt, _dPolarDirection, epsArc.Radius, ref _NewPnt1);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), num12 / 2.0, ref epsPoint);
      if (_bRightAisle)
        epsLine1.StartPnt = epsPoint;
      else
        epsLine1.EndPnt = epsPoint;
      if (!_bIsInside)
      {
        _InsertPoint = epsPoint;
        if (_bIsHCapStall)
        {
          if (_bRightAisle)
            EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
          else
            EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
        }
      }
      else if (_bIsHCapStall)
      {
        if (_bRightAisle)
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
        else
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
      }
      if (_bRightAisle)
        epsLine2.StartPnt = epsPoint;
      else
        epsLine2.EndPnt = epsPoint;
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), num12 / 2.0, ref epsPoint);
      if (_bRightAisle)
        epsLine1.EndPnt = epsPoint;
      else
        epsLine1.StartPnt = epsPoint;
      if (_bIsInside)
      {
        _InsertPoint = epsPoint;
        if (_bIsHCapStall)
        {
          if (_bRightAisle)
            EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
          else
            EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
        }
      }
      else if (_bIsHCapStall)
      {
        if (_bRightAisle)
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
        else
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), _PlacementSettings.Parking.AdjustAisleWidth / 2.0, ref epsPoint);
      }
      if (_bRightAisle)
        epsLine2.EndPnt = epsPoint;
      else
        epsLine2.StartPnt = epsPoint;
      double _dDirection3;
      if (_bIsInside)
      {
        _dDirection3 = _dPolarDirection - Math.PI / 2.0;
        EPShared.eplGeoE_CalcPolarToXY(epsLine1.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle + num13 * 0.5), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      }
      else
      {
        _dDirection3 = _dPolarDirection + Math.PI / 2.0;
        EPShared.eplGeoE_CalcPolarToXY(epsLine1.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle + num13 * 0.5), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      }
      bool flag = true;
      if (_NextLeg != null)
      {
        if (_NextLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt2, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
        {
          if (RevitDefines.LT(_dOffset, _PlacementSettings.Parking.StripeLength))
            flag = false;
        }
        else if (_NextLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt2, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700 && RevitDefines.LT(_dOffset, _PlacementSettings.Parking.StripeLength))
          flag = false;
      }
      if (flag)
      {
        if (_bIsHCapStall)
          ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, _InsertPoint, _StallSymbol, _dDirection3, _PlacementSettings.Parking.StallLength, adaStallWidth, Math.PI / 2.0, true, true, _bIsHCapStall, _bRightAisle, ref _ExistingADAParkingStallList);
        else
          ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, _InsertPoint, _StallSymbol, _dDirection3, _PlacementSettings.Parking.StallLength, adaStallWidth, Math.PI / 2.0, true, true, _bIsHCapStall, _bRightAisle, ref _ExistingParkingStallList);
        if (_PlacementSettings.Parking.PlaceBumper)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine2.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dAngle - num4), _PlacementSettings.Parking.BumperOffset, ref epsPoint);
          epsLine3.StartPnt = epsPoint;
          EPShared.eplGeoE_CalcPolarToXY(epsLine2.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle + num13), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dAngle + num4 + num13), _PlacementSettings.Parking.BumperOffset, ref epsPoint);
          epsLine3.EndPnt = epsPoint;
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLine3.StartPnt, epsLine3.EndPnt, ref epsPoint);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLine3.StartPnt, epsLine3.EndPnt, ref _dDirection2);
          ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint, adaStallWidth, _dDirection2, ref _ExistingBumperList);
        }
      }
      _ProgressFrm.UpdateProgressBar(Convert.ToInt32(num12));
      num14 += num13;
      _dAngle += num13;
      if (_PlacementSettings.Parking.ADAStallSharedAccessibleAisle)
      {
        _bIsHCapStall = !_bIsHCapStall;
        if (_bIsHCapStall)
        {
          num12 = _PlacementSettings.Parking.ADAStallAdjustWidth;
          _StallSymbol = _PlacementSettings.Parking.ADAStallSymbol;
          num13 = num5;
        }
        else
        {
          num12 = _PlacementSettings.Parking.ADAStallWidth;
          _StallSymbol = _PlacementSettings.Type;
          num13 = num6;
        }
      }
    }
    for (int index = 0; index < _PlacementSettings.Parking.CurrentStallCount; ++index)
    {
      double _dPolarDirection = EPShared.eplGeoE_NormalizeRadians(num14 + num7 * 0.5);
      EPShared.eplGeoE_CalcPolarToXY(epsArc.RadiusPnt, _dPolarDirection, epsArc.Radius, ref _NewPnt1);
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, _dPolarDirection - Math.PI / 2.0, _PlacementSettings.Width / 2.0, ref epsPoint);
      if (!_bIsInside)
        _InsertPoint = epsPoint;
      if (_bRightAisle)
        epsLine2.StartPnt = epsPoint;
      else
        epsLine2.EndPnt = epsPoint;
      EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, _dPolarDirection + Math.PI / 2.0, _PlacementSettings.Width / 2.0, ref epsPoint);
      if (_bIsInside)
        _InsertPoint = epsPoint;
      if (_bRightAisle)
        epsLine2.EndPnt = epsPoint;
      else
        epsLine2.StartPnt = epsPoint;
      double _dDirection4;
      if (_bIsInside)
      {
        _dDirection4 = _dPolarDirection - Math.PI / 2.0;
        EPShared.eplGeoE_CalcPolarToXY(epsLine2.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle + num7 * 0.5), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      }
      else
      {
        _dDirection4 = _dPolarDirection + Math.PI / 2.0;
        EPShared.eplGeoE_CalcPolarToXY(epsLine2.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle + num7 * 0.5), _PlacementSettings.Parking.StripeLength, ref _NewPnt2);
      }
      bool flag = true;
      if (_NextLeg != null)
      {
        if (_NextLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt2, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
        {
          if (RevitDefines.LT(_dOffset, _PlacementSettings.Parking.StripeLength))
            flag = false;
        }
        else if (_NextLeg.Arc != null && EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt2, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) == 1700 && RevitDefines.LT(_dOffset, _PlacementSettings.Parking.StripeLength))
          flag = false;
      }
      if (flag)
      {
        ParkingLotCommon.DrawStall(_Document, _PlacementSettings, _Element, _InsertPoint, _PlacementSettings.Type, _dDirection4, _PlacementSettings.Parking.StallLength, _PlacementSettings.Width, Math.PI / 2.0, true, true, ref _ExistingParkingStallList);
        if (_PlacementSettings.Parking.PlaceBumper)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine2.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dAngle - num4), _PlacementSettings.Parking.BumperOffset, ref epsPoint);
          epsLine3.StartPnt = epsPoint;
          EPShared.eplGeoE_CalcPolarToXY(epsLine2.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dAngle + num7), _PlacementSettings.Parking.BumperSetback + _PlacementSettings.Parking.BumperWidth / 2.0, ref epsPoint);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dAngle + num4 + num7), _PlacementSettings.Parking.BumperOffset, ref epsPoint);
          epsLine3.EndPnt = epsPoint;
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLine3.StartPnt, epsLine3.EndPnt, ref epsPoint);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLine3.StartPnt, epsLine3.EndPnt, ref _dDirection2);
          ParkingLotCommon.DrawBumper(_Document, _PlacementSettings, _Element, epsPoint, _PlacementSettings.Width, _dDirection2, ref _ExistingBumperList);
        }
      }
      _ProgressFrm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Parking.StallAdjustWidth));
      num14 += num7;
      _dAngle += num7;
    }
    if (!_PlacementSettings.Parking.OptimizeParking)
      _PlacementSettings.Parking.StallCount -= _PlacementSettings.Parking.CurrentStallCount;
    _PlacementSettings.Parking.ADAStallCount -= _PlacementSettings.Parking.CurrentADAStallCount;
    if (_NextLeg == null)
      return;
    if (_NextLeg.Line != null && EPShared.eplGeoE_CalcStationOffsetAlongLine(_NewPnt2, _NextLeg.Line, ref _dStation, ref _dOffset, 0.0) == 1700)
    {
      EPShared.eplGeoE_FindStaOffPointAlongLine(_NextLeg.Line, _dStation, 0.0, ref epsPoint);
      _NextLeg.Line.StartPnt = epsPoint;
    }
    else
    {
      if (_NextLeg.Arc == null || EPShared.eplGeoE_CalcStationOffsetAlongArc(_NewPnt2, _NextLeg.Arc, ref _dStation, ref _dOffset, 0.0) != 1700)
        return;
      EPShared.eplGeoE_FindStaOffPointAlongArc(_NextLeg.Arc, _dStation, 0.0, ref epsPoint);
      _NextLeg.Arc.StartPnt = epsPoint;
      double _dDistance = 0.0;
      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NextLeg.Arc.StartPnt, _NextLeg.Arc.EndPnt, ref _dDistance);
      double _dDeltaAngle = 0.0;
      EPShared.eplGeoE_SolveDeltaByChordLenAndRadius(_dDistance, _NextLeg.Arc.Radius, ref _dDeltaAngle);
      _NextLeg.Arc.Delta = _dDeltaAngle;
    }
  }

  private static void DrawAreaParking(
    Document _Document,
    ref PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Element _Element,
    Eps_Line _CurLine,
    Eps_Point _SidePoint,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref List<FamilyInstance> _ExistingIslandList)
  {
    Eps_Point _NewPnt = new Eps_Point();
    double _dDirection = 0.0;
    double AdjRowHeight = 0.0;
    ParkingLotCommon.CalculateStallParameters(_Document, ref _PlacementSettings, _PlacementSettings.RotationAngle);
    if (ParkingLotCommon.CalculateNumberOfStalls(ref _PlacementSettings, _CurLine, true) < 1)
      return;
    _ProgressFrm.ResetValue();
    _ProgressFrm.MinValue = 0;
    _ProgressFrm.MaxValue = !_PlacementSettings.Parking.ADAStallSharedAccessibleAisle ? Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) _PlacementSettings.Parking.CurrentADAStallCount + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount) : Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.ADAStallWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount);
    Thread.Sleep(300);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_CurLine.StartPnt, _SidePoint, ref _dDirection);
    ParkingLotCommon.CalculateStallLength(ref _PlacementSettings, _PlacementSettings.RotationAngle);
    if (ParkingLotCommon.CalculateNumberOfRows(_PlacementSettings, _CurLine, ref AdjRowHeight) < 1)
      return;
    for (int index = 0; index < _PlacementSettings.Parking.AreaRowCount; ++index)
    {
      ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _CurLine, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _ExistingIslandList);
      EPShared.eplGeoE_CalcPolarToXY(_CurLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), AdjRowHeight, ref _NewPnt);
      _CurLine.StartPnt = _NewPnt;
      EPShared.eplGeoE_CalcPolarToXY(_CurLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), AdjRowHeight, ref _NewPnt);
      _CurLine.EndPnt = _NewPnt;
      if (!_PlacementSettings.Parking.AreaBiDirectionalAisles)
        _PlacementSettings.RotationAngle = EPShared.eplGeoE_NormalizeRadians(Math.PI - _PlacementSettings.RotationAngle);
      if (ParkingLotCommon.CalculateNumberOfStalls(ref _PlacementSettings, _CurLine, true) < 1)
        break;
      _ProgressFrm.ResetValue();
      _ProgressFrm.MinValue = 0;
      _ProgressFrm.MaxValue = !_PlacementSettings.Parking.ADAStallSharedAccessibleAisle ? Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) _PlacementSettings.Parking.CurrentADAStallCount + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount) : Convert.ToInt32(_PlacementSettings.Parking.ADAStallAdjustWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.ADAStallWidth * (double) (_PlacementSettings.Parking.CurrentADAStallCount / 2) + _PlacementSettings.Parking.StallAdjustWidth * (double) _PlacementSettings.Parking.CurrentStallCount);
      Thread.Sleep(300);
    }
  }

  public static bool PlaceLegList(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _CurrentLeg)
  {
    Eps_Leg _Leg1 = (Eps_Leg) null;
    Eps_Leg _Leg2 = (Eps_Leg) null;
    bool _UseRightSide = true;
    bool _bPickFirstLeg = true;
    bool _bPickMiddleSegment = false;
    if (!_PlacementSettings.ExistingElementChecked)
    {
      _Leg2 = _CurrentLeg;
      _bPickFirstLeg = false;
    }
    else if (!RevitUtility.BreakApartLeg(_Document, _PlacementSettings.TransactionContainer, _PlacementSettings.Width / 2.0, _CurrentLeg, _PlacementSettings.Parking.PromptForDirection, ref _Leg1, ref _Leg2, ref _bPickFirstLeg, ref _bPickMiddleSegment))
      return false;
    _PlacementSettings.Parking.MiddleStallPlacement = _bPickMiddleSegment;
    if (_PlacementSettings.PlacementType == PlacementType.ParkingSingleRow)
    {
      Eps_Leg ppOffsetLegList1 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.Parking.StallLength, 1, ref ppOffsetLegList1, true);
      Eps_Leg ppOffsetLegList2 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.Parking.StallLength, 2, ref ppOffsetLegList2, true);
      _PlacementSettings.TransactionContainer.BeginTransaction();
      ModelCurveArray modelCurveArray1 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList1);
      ModelCurveArray modelCurveArray2 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList2);
      _PlacementSettings.TransactionContainer.EndTransaction();
      _Document.Regenerate();
      bool flag = RevitUtility.PickSideLeg(_Document, _CurrentLeg, ref _UseRightSide);
      ElementSet elm_set = new ElementSet();
      foreach (ModelCurve modelCurve in modelCurveArray1)
        elm_set.Insert((Element) modelCurve);
      foreach (ModelCurve modelCurve in modelCurveArray2)
        elm_set.Insert((Element) modelCurve);
      _PlacementSettings.TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      _PlacementSettings.TransactionContainer.EndTransaction();
      if (!flag)
        return false;
    }
    ProgressBarForm _ProgressFrm = new ProgressBarForm();
    _ProgressFrm.ShowForm();
    _ProgressFrm.Refresh();
    int _nProgressBarCount = 1;
    List<FamilyInstance> _ExistingParkingStallList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingADAParkingStallList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingBumperList = (List<FamilyInstance>) null;
    if (_PlacementSettings.TransactionContainer != null)
      _PlacementSettings.TransactionContainer.BeginTransaction();
    if (_CurrentLeg.Element != null)
      _PlacementSettings.FirstLegSegmentID = _CurrentLeg.Element.UniqueId;
    if (_CurrentLeg.Last.Element != null)
      _PlacementSettings.LastLegSegmentID = _CurrentLeg.Last.Element.UniqueId;
    _PlacementSettings.IsReverse = _bPickFirstLeg;
    _PlacementSettings.UseRightSide = _UseRightSide;
    if (_bPickFirstLeg)
    {
      if (_Leg1 != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, _Leg1, ref _nProgressBarCount, !_UseRightSide, ref _Leg2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
      if (_Leg2 != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, _Leg2, ref _nProgressBarCount, _UseRightSide, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
    }
    else
    {
      if (_Leg2 != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, _Leg2, ref _nProgressBarCount, _UseRightSide, ref _Leg1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
      if (_Leg1 != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, _Leg1, ref _nProgressBarCount, !_UseRightSide, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
    }
    if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
    {
      for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
        _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
    }
    if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
    {
      for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
        _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
    }
    if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
    {
      for (int index = 0; index < _ExistingBumperList.Count; ++index)
        _Document.Delete(((Element) _ExistingBumperList[index]).Id);
    }
    if (_PlacementSettings.TransactionContainer != null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    _ProgressFrm?.Close();
    if (_PlacementSettings.DeleteExistingChecked && _CurrentLeg.ElementSet != null && _CurrentLeg.ElementSet.Size > 0)
    {
      _PlacementSettings.TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_CurrentLeg.ElementSet));
      _PlacementSettings.TransactionContainer.EndTransaction();
    }
    return true;
  }

  public static bool PlaceLegList(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _CurrentLeg,
    Eps_Leg FirstLeg,
    Eps_Leg SecondLeg,
    bool _bUseFirstLeg,
    List<FamilyInstance> _ExistingParkingStallList,
    List<FamilyInstance> _ExistingADAParkingStallList,
    List<FamilyInstance> _ExistingBumperList)
  {
    ProgressBarForm _ProgressFrm = new ProgressBarForm();
    _ProgressFrm.ShowForm();
    _ProgressFrm.Refresh();
    int _nProgressBarCount = 1;
    if (_PlacementSettings.TransactionContainer != null)
      _PlacementSettings.TransactionContainer.BeginTransaction();
    if (_bUseFirstLeg)
    {
      if (FirstLeg != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, FirstLeg, ref _nProgressBarCount, !_PlacementSettings.UseRightSide, ref SecondLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
      if (SecondLeg != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, SecondLeg, ref _nProgressBarCount, _PlacementSettings.UseRightSide, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
    }
    else
    {
      if (SecondLeg != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, SecondLeg, ref _nProgressBarCount, _PlacementSettings.UseRightSide, ref FirstLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
      if (FirstLeg != null)
        ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, FirstLeg, ref _nProgressBarCount, !_PlacementSettings.UseRightSide, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
    }
    if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
    {
      for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
        _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
    }
    if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
    {
      for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
        _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
    }
    if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
    {
      for (int index = 0; index < _ExistingBumperList.Count; ++index)
        _Document.Delete(((Element) _ExistingBumperList[index]).Id);
    }
    if (_PlacementSettings.TransactionContainer != null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    _ProgressFrm?.Close();
    return true;
  }

  private static void PlaceStallsOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Eps_Leg _Leg,
    ref int _nProgressBarCount,
    bool _bUseRightLeg,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList)
  {
    Eps_Leg _RemainingLeg = new Eps_Leg();
    ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, false, _Leg, ref _nProgressBarCount, _bUseRightLeg, ref _RemainingLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, !_PlacementSettings.Parking.MiddleStallPlacement);
  }

  private static void PlaceStallsOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    Eps_Leg _Leg,
    ref int _nProgressBarCount,
    bool _bUseRightLeg,
    ref Eps_Leg _RemainingLeg,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList)
  {
    ParkingLotCommon.PlaceStallsOnLeg(_Document, _PlacementSettings, _ProgressFrm, true, _Leg, ref _nProgressBarCount, _bUseRightLeg, ref _RemainingLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, true);
  }

  private static void PlaceStallsOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    ProgressBarForm _ProgressFrm,
    bool _bFirstCall,
    Eps_Leg _Leg,
    ref int _nProgressBarCount,
    bool _bUseRightLeg,
    ref Eps_Leg _RemainingLeg,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    bool _bDrawFirstDoubleStripe)
  {
    Eps_Line _OffsetLine1 = new Eps_Line();
    Eps_Line _OffsetLine2 = new Eps_Line();
    Eps_Arc _OffsetArc1 = new Eps_Arc();
    Eps_Arc _OffsetArc2 = new Eps_Arc();
    Eps_Point _MidPoint = new Eps_Point();
    Eps_Point epsPoint = new Eps_Point();
    if (_Leg == null)
      return;
    if (_bFirstCall && _Leg.ElementList != null && _Leg.ElementList.Count > 0 && !_PlacementSettings.DeleteExistingChecked && _PlacementSettings.GenericModelIDList == null)
    {
      if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.ADAStallSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.BumperSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.IslandSymbol))
      {
        if (_Leg.ElementList != null && _Leg.ElementList.Count > 0)
        {
          List<Element> elementList = _Leg.ElementList;
          if (_RemainingLeg != null && _RemainingLeg.ElementList != null && _RemainingLeg.ElementList.Count > 0)
          {
            int index = 0;
            if (_PlacementSettings.Parking.MiddleStallPlacement)
              index = 1;
            for (; index < _RemainingLeg.ElementList.Count; ++index)
              elementList.Add(_RemainingLeg.ElementList[index]);
          }
          _PlacementSettings.GenericModelIDList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, elementList);
        }
      }
      else
      {
        int num1 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "ParkingLotNoPositioning", EPShared.LocalRM.GetString("PositionParkingLotsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
      }
    }
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    double num2 = 0.0;
    if (_bFirstCall)
      num2 = _PlacementSettings.StartingDistance;
    else
      _bDrawFirstDoubleStripe = true;
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
        if (RevitDefines.GT(num2, _dDistance))
        {
          num2 -= _dDistance;
        }
        else
        {
          Eps_Line epsLine = new Eps_Line(epsLeg.Line);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDirection);
          EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, _dDirection, num2, ref epsPoint);
          epsLine.StartPnt = epsPoint;
          if (_PlacementSettings.PlacementType == PlacementType.ParkingSingleRow)
          {
            if (_bUseRightLeg)
              EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.Parking.StallLength, 1, ref _OffsetLine1);
            else
              EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.Parking.StallLength, 2, ref _OffsetLine1);
            EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_OffsetLine1.StartPnt, _OffsetLine1.EndPnt, ref _MidPoint);
            double _dAngle = 0.0;
            EPShared.eplGeoE_CalcHorzAngByThreePnts(epsLine.StartPnt, epsLine.EndPnt, _MidPoint, 12, ref _dAngle, 1E-05);
            _dAngle = !RevitDefines.GT(_dAngle, Math.PI) ? _PlacementSettings.RotationAngle : EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0);
            if (RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
            {
              if (_bUseRightLeg)
                EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.Parking.IslandWidth, 1, ref _OffsetLine2);
              else
                EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.Parking.IslandWidth, 2, ref _OffsetLine2);
            }
            else
              _OffsetLine2 = epsLine;
            _ProgressFrm.Message = EPShared.LocalRM.GetString("PlacingStallMessage") + _nProgressBarCount.ToString();
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, _OffsetLine2, _dAngle, false, epsLeg.Next, ref _RemainingLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
          }
          else if (_PlacementSettings.PlacementType == PlacementType.ParkingDoubleRow)
          {
            if (_PlacementSettings.Parking.PlaceIsland && RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
            {
              Eps_Line _OffsetLine3 = new Eps_Line();
              EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetLine3);
              Eps_Line _OffsetLine4 = new Eps_Line();
              EPShared.eplGeoE_ConstructOffsetLine(epsLine, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetLine4);
              _ProgressFrm.Message = EPShared.LocalRM.GetString("PlacingStallMessage") + _nProgressBarCount.ToString();
              bool _bDrawFirstDoubleStripe1 = _bDrawFirstDoubleStripe;
              ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, _OffsetLine3, EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0), true, epsLeg.Next, ref _RemainingLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe1);
              ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, _OffsetLine4, _PlacementSettings.RotationAngle, false, epsLeg.Next, ref _RemainingLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
            }
            else
            {
              _ProgressFrm.Message = EPShared.LocalRM.GetString("PlacingStallMessage") + _nProgressBarCount.ToString();
              ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, epsLine, epsLeg.Next, ref _RemainingLeg, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _bDrawFirstDoubleStripe);
            }
          }
          num2 = 0.0;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance = epsLeg.Arc.Radius * epsLeg.Arc.Delta;
        if (RevitDefines.GT(num2, _dDistance))
        {
          double num3 = num2 - _dDistance;
        }
        else
        {
          Eps_Arc epsArc = new Eps_Arc(epsLeg.Arc);
          EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, num2, 0.0, ref epsPoint);
          epsArc.Delta = (_dDistance - num2) / epsLeg.Arc.Radius;
          epsArc.StartPnt = epsPoint;
          if (_PlacementSettings.PlacementType == PlacementType.ParkingSingleRow)
          {
            if (_bUseRightLeg)
              EPShared.eplGeoE_ConstructOffsetArc(epsLeg.Arc, _PlacementSettings.Parking.StallLength, 1, ref _OffsetArc2);
            else
              EPShared.eplGeoE_ConstructOffsetArc(epsLeg.Arc, _PlacementSettings.Parking.StallLength, 2, ref _OffsetArc2);
            bool _bIsInside = false;
            if (EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_OffsetArc2.Radius, _OffsetArc2.Delta) < EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta))
              _bIsInside = true;
            if (RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
            {
              if (_bUseRightLeg)
                EPShared.eplGeoE_ConstructOffsetArc(epsLeg.Arc, _PlacementSettings.Parking.IslandWidth, 1, ref _OffsetArc1);
              else
                EPShared.eplGeoE_ConstructOffsetArc(epsLeg.Arc, _PlacementSettings.Parking.IslandWidth, 2, ref _OffsetArc1);
            }
            else
              _OffsetArc1 = epsLeg.Arc;
            _ProgressFrm.Message = EPShared.LocalRM.GetString("PlacingStallMessage") + _nProgressBarCount.ToString();
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, _OffsetArc1, _bIsInside, false, epsLeg.Next, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          }
          else if (_PlacementSettings.PlacementType == PlacementType.ParkingDoubleRow)
          {
            if (_PlacementSettings.Parking.PlaceIsland && RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
            {
              Eps_Arc _OffsetArc3 = new Eps_Arc();
              EPShared.eplGeoE_ConstructOffsetArc(epsLeg.Arc, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetArc3);
              Eps_Arc _OffsetArc4 = new Eps_Arc();
              EPShared.eplGeoE_ConstructOffsetArc(epsLeg.Arc, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetArc4);
              _ProgressFrm.Message = EPShared.LocalRM.GetString("PlacingStallMessage") + _nProgressBarCount.ToString();
              ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, _OffsetArc3, true, true, epsLeg.Next, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
              ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, _OffsetArc4, false, false, epsLeg.Next, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
            }
            else
            {
              _ProgressFrm.Message = EPShared.LocalRM.GetString("PlacingStallMessage") + _nProgressBarCount.ToString();
              ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, epsLeg.Arc, true, true, epsLeg.Next, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
              ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, epsLeg.Element, epsLeg.Arc, false, false, epsLeg.Next, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
            }
          }
        }
        num2 = 0.0;
      }
      ++_nProgressBarCount;
    }
  }

  public static bool PlaceStallsOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _ParkingArc,
    Eps_Arc _FirstArc,
    Eps_Arc _SecondArc,
    bool _bUseFirstArc)
  {
    List<FamilyInstance> _ExistingParkingStallList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingADAParkingStallList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingBumperList = (List<FamilyInstance>) null;
    return ParkingLotCommon.PlaceStallsOnArc(_Document, _PlacementSettings, _Element, _ParkingArc, _FirstArc, _SecondArc, _bUseFirstArc, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
  }

  public static bool PlaceStallsOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _ParkingArc,
    Eps_Arc _FirstArc,
    Eps_Arc _SecondArc,
    bool _bUseFirstArc,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    double startingDistance = _PlacementSettings.StartingDistance;
    double num1;
    Eps_Arc _Arc;
    if (_bUseFirstArc)
    {
      num1 = _FirstArc.Radius * _FirstArc.Delta;
      _Arc = new Eps_Arc(_FirstArc);
    }
    else
    {
      num1 = _SecondArc.Radius * _SecondArc.Delta;
      _Arc = new Eps_Arc(_SecondArc);
    }
    EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, startingDistance, 0.0, ref _StaOffPnt);
    _Arc.Delta = (num1 - startingDistance) / _Arc.Radius;
    _Arc.StartPnt = _StaOffPnt;
    if (_bUseFirstArc)
      _FirstArc = new Eps_Arc(_Arc);
    else
      _SecondArc = new Eps_Arc(_Arc);
    if (_PlacementSettings.PlacementType == PlacementType.ParkingSingleRow)
    {
      Eps_Arc _OffsetArc1 = new Eps_Arc();
      EPShared.eplGeoE_ConstructOffsetArc(_ParkingArc, _PlacementSettings.Parking.StallLength, 1, ref _OffsetArc1);
      Eps_Arc _OffsetArc2 = new Eps_Arc();
      EPShared.eplGeoE_ConstructOffsetArc(_ParkingArc, _PlacementSettings.Parking.StallLength, 2, ref _OffsetArc2);
      if (_PlacementSettings.TransactionContainer != null)
      {
        ElementSet elm_set = new ElementSet();
        if (_OffsetArc1.Radius > 0.0)
        {
          _PlacementSettings.TransactionContainer.BeginTransaction();
          ModelCurve modelCurve = RevitUtility.NewModelCurve(_Document, _OffsetArc1);
          _PlacementSettings.TransactionContainer.EndTransaction();
          elm_set.Insert((Element) modelCurve);
        }
        if (_OffsetArc2.Radius > 0.0)
        {
          _PlacementSettings.TransactionContainer.BeginTransaction();
          ModelCurve modelCurve = RevitUtility.NewModelCurve(_Document, _OffsetArc2);
          _PlacementSettings.TransactionContainer.EndTransaction();
          elm_set.Insert((Element) modelCurve);
        }
        bool _UseRightSide = true;
        bool flag = RevitUtility.PickSideArc(_Document, _ParkingArc, ref _UseRightSide);
        _PlacementSettings.TransactionContainer.BeginTransaction();
        _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
        _PlacementSettings.TransactionContainer.EndTransaction();
        if (!flag)
          return false;
        _PlacementSettings.UseRightSide = _UseRightSide;
      }
      bool _bIsInside = false;
      if (_PlacementSettings.UseRightSide)
      {
        if (EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_OffsetArc1.Radius, _OffsetArc1.Delta) < EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_ParkingArc.Radius, _ParkingArc.Delta))
          _bIsInside = true;
      }
      else if (EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_OffsetArc2.Radius, _OffsetArc2.Delta) < EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_ParkingArc.Radius, _ParkingArc.Delta))
        _bIsInside = true;
      if (RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
      {
        if (_PlacementSettings.UseRightSide)
        {
          if (_FirstArc != null)
            EPShared.eplGeoE_ConstructOffsetArc(_FirstArc, _PlacementSettings.Parking.IslandWidth, 2, ref _FirstArc);
          if (_SecondArc != null)
            EPShared.eplGeoE_ConstructOffsetArc(_SecondArc, _PlacementSettings.Parking.IslandWidth, 1, ref _SecondArc);
        }
        else
        {
          if (_FirstArc != null)
            EPShared.eplGeoE_ConstructOffsetArc(_FirstArc, _PlacementSettings.Parking.IslandWidth, 1, ref _FirstArc);
          if (_SecondArc != null)
            EPShared.eplGeoE_ConstructOffsetArc(_SecondArc, _PlacementSettings.Parking.IslandWidth, 2, ref _SecondArc);
        }
      }
      if (!_PlacementSettings.DeleteExistingChecked && _PlacementSettings.GenericModelIDList == null && _Element != null)
      {
        if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.ADAStallSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.BumperSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.IslandSymbol))
        {
          _PlacementSettings.GenericModelIDList = new List<KeyValuePair<string, string>>();
          _PlacementSettings.GenericModelIDList.Add(RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element));
        }
        else
        {
          int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "ParkingLotNoPositioning", EPShared.LocalRM.GetString("PositionParkingLotsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
        }
      }
      if (_PlacementSettings.TransactionContainer != null)
        _PlacementSettings.TransactionContainer.BeginTransaction();
      ProgressBarForm _ProgressFrm = new ProgressBarForm();
      _ProgressFrm.ShowForm();
      _ProgressFrm.Refresh();
      _ProgressFrm.Message = EPShared.LocalRM.GetString("StallOnArcMessage");
      if (_bUseFirstArc)
      {
        if (_FirstArc != null)
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstArc, _bIsInside, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
        if (_SecondArc != null)
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondArc, _bIsInside, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
      }
      else
      {
        if (_SecondArc != null)
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondArc, _bIsInside, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
        if (_FirstArc != null)
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstArc, _bIsInside, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
      }
      _ProgressFrm.Close();
      if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
      {
        for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
          _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
      }
      if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
      {
        for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
          _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
      }
      if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
      {
        for (int index = 0; index < _ExistingBumperList.Count; ++index)
          _Document.Delete(((Element) _ExistingBumperList[index]).Id);
      }
      if (_PlacementSettings.TransactionContainer != null)
        _PlacementSettings.TransactionContainer.EndTransaction();
    }
    else if (_PlacementSettings.PlacementType == PlacementType.ParkingDoubleRow)
    {
      if (!_PlacementSettings.DeleteExistingChecked && _PlacementSettings.GenericModelIDList == null && _Element != null)
      {
        if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.ADAStallSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.BumperSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.IslandSymbol))
        {
          _PlacementSettings.GenericModelIDList = new List<KeyValuePair<string, string>>();
          _PlacementSettings.GenericModelIDList.Add(RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element));
        }
        else
        {
          int num3 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "ParkingLotNoPositioning", EPShared.LocalRM.GetString("PositionParkingLotsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
        }
      }
      if (_PlacementSettings.TransactionContainer != null)
        _PlacementSettings.TransactionContainer.BeginTransaction();
      ProgressBarForm _ProgressFrm = new ProgressBarForm();
      _ProgressFrm.ShowForm();
      _ProgressFrm.Refresh();
      _ProgressFrm.Message = EPShared.LocalRM.GetString("StallOnArcMessage");
      if (_PlacementSettings.Parking.PlaceIsland && RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
      {
        if (_bUseFirstArc)
        {
          if (_FirstArc != null)
          {
            Eps_Arc _OffsetArc3 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_FirstArc, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetArc3);
            Eps_Arc _OffsetArc4 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_FirstArc, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetArc4);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc3, false, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc4, true, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          }
          if (_SecondArc != null)
          {
            Eps_Arc _OffsetArc5 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_SecondArc, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetArc5);
            Eps_Arc _OffsetArc6 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_SecondArc, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetArc6);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc5, true, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc6, false, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          }
        }
        else
        {
          if (_SecondArc != null)
          {
            Eps_Arc _OffsetArc7 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_SecondArc, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetArc7);
            Eps_Arc _OffsetArc8 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_SecondArc, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetArc8);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc7, true, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc8, false, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          }
          if (_FirstArc != null)
          {
            Eps_Arc _OffsetArc9 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_FirstArc, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetArc9);
            Eps_Arc _OffsetArc10 = new Eps_Arc();
            EPShared.eplGeoE_ConstructOffsetArc(_FirstArc, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetArc10);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc9, false, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
            ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetArc10, true, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          }
        }
      }
      else if (_bUseFirstArc)
      {
        if (_FirstArc != null)
        {
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstArc, true, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstArc, false, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
        }
        if (_SecondArc != null)
        {
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondArc, true, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondArc, false, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
        }
      }
      else
      {
        if (_SecondArc != null)
        {
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondArc, true, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondArc, false, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
        }
        if (_FirstArc != null)
        {
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstArc, true, true, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
          ParkingLotCommon.DrawCurvedParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstArc, false, false, (Eps_Leg) null, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList);
        }
      }
      _ProgressFrm.Close();
      if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
      {
        for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
          _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
      }
      if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
      {
        for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
          _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
      }
      if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
      {
        for (int index = 0; index < _ExistingBumperList.Count; ++index)
          _Document.Delete(((Element) _ExistingBumperList[index]).Id);
      }
      if (_PlacementSettings.TransactionContainer != null)
        _PlacementSettings.TransactionContainer.EndTransaction();
    }
    return true;
  }

  public static bool PlaceStallsOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _ParkingLotLine,
    Eps_Line _FirstLine,
    Eps_Line _SecondLine,
    bool _bUseFirstLine)
  {
    List<FamilyInstance> _ExistingParkingStallList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingADAParkingStallList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingBumperList = (List<FamilyInstance>) null;
    List<FamilyInstance> _ExistingIslandList = (List<FamilyInstance>) null;
    return ParkingLotCommon.PlaceStallsOnLine(_Document, _PlacementSettings, _Element, _ParkingLotLine, _FirstLine, _SecondLine, _bUseFirstLine, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _ExistingIslandList);
  }

  public static bool PlaceStallsOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _ParkingLotLine,
    Eps_Line _FirstLine,
    Eps_Line _SecondLine,
    bool _bUseFirstLine,
    ref List<FamilyInstance> _ExistingParkingStallList,
    ref List<FamilyInstance> _ExistingADAParkingStallList,
    ref List<FamilyInstance> _ExistingBumperList,
    ref List<FamilyInstance> _ExistingIslandList)
  {
    double _dDirection = 0.0;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point epsPoint3 = new Eps_Point();
    Eps_Line epsLine = new Eps_Line();
    double startingDistance = _PlacementSettings.StartingDistance;
    Eps_Line _Line = !_bUseFirstLine ? new Eps_Line(_SecondLine) : new Eps_Line(_FirstLine);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, startingDistance, ref epsPoint3);
    _Line.StartPnt = epsPoint3;
    if (_bUseFirstLine)
      _FirstLine = new Eps_Line(_Line);
    else
      _SecondLine = new Eps_Line(_Line);
    ParkingLotCommon.GetIslandParameters(_Document, ref _PlacementSettings);
    if (_PlacementSettings.PlacementType == PlacementType.ParkingSingleRow || _PlacementSettings.PlacementType == PlacementType.ParkingArea)
    {
      Eps_Line _OffsetLine1 = new Eps_Line();
      EPShared.eplGeoE_ConstructOffsetLine(_ParkingLotLine, _PlacementSettings.Parking.StallLength, 1, ref _OffsetLine1);
      Eps_Line _OffsetLine2 = new Eps_Line();
      EPShared.eplGeoE_ConstructOffsetLine(_ParkingLotLine, _PlacementSettings.Parking.StallLength, 2, ref _OffsetLine2);
      if (_PlacementSettings.TransactionContainer != null)
      {
        ElementSet elm_set = new ElementSet();
        _PlacementSettings.TransactionContainer.BeginTransaction();
        ModelCurve modelCurve1 = RevitUtility.NewModelCurve(_Document, _OffsetLine1);
        ModelCurve modelCurve2 = RevitUtility.NewModelCurve(_Document, _OffsetLine2);
        _PlacementSettings.TransactionContainer.EndTransaction();
        _Document.Regenerate();
        elm_set.Insert((Element) modelCurve1);
        elm_set.Insert((Element) modelCurve2);
        bool _UseRightSide = true;
        bool flag = RevitUtility.PickSideLine(_Document, _ParkingLotLine, ref _UseRightSide);
        _PlacementSettings.TransactionContainer.BeginTransaction();
        _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
        _PlacementSettings.TransactionContainer.EndTransaction();
        if (!flag)
          return false;
        _PlacementSettings.UseRightSide = _UseRightSide;
      }
      Eps_Point _MidPoint = new Eps_Point();
      if (_PlacementSettings.PlacementType == PlacementType.ParkingSingleRow)
      {
        if (_PlacementSettings.UseRightSide)
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_OffsetLine1.StartPnt, _OffsetLine1.EndPnt, ref _MidPoint);
        else
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_OffsetLine2.StartPnt, _OffsetLine2.EndPnt, ref _MidPoint);
        double _dAngle = 0.0;
        EPShared.eplGeoE_CalcHorzAngByThreePnts(_ParkingLotLine.StartPnt, _ParkingLotLine.EndPnt, _MidPoint, 12, ref _dAngle, 1E-05);
        double num1 = !RevitDefines.GT(_dAngle, Math.PI) ? _PlacementSettings.RotationAngle : EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0);
        if (RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
        {
          if (_PlacementSettings.UseRightSide)
          {
            if (_FirstLine != null)
              EPShared.eplGeoE_ConstructOffsetLine(_FirstLine, _PlacementSettings.Parking.IslandWidth, 2, ref _FirstLine);
            if (_SecondLine != null)
              EPShared.eplGeoE_ConstructOffsetLine(_SecondLine, _PlacementSettings.Parking.IslandWidth, 1, ref _SecondLine);
          }
          else
          {
            if (_FirstLine != null)
              EPShared.eplGeoE_ConstructOffsetLine(_FirstLine, _PlacementSettings.Parking.IslandWidth, 1, ref _FirstLine);
            if (_SecondLine != null)
              EPShared.eplGeoE_ConstructOffsetLine(_SecondLine, _PlacementSettings.Parking.IslandWidth, 2, ref _SecondLine);
          }
        }
        if (!_PlacementSettings.DeleteExistingChecked && _PlacementSettings.GenericModelIDList == null && _Element != null)
        {
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.ADAStallSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.BumperSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.IslandSymbol))
          {
            _PlacementSettings.GenericModelIDList = new List<KeyValuePair<string, string>>();
            _PlacementSettings.GenericModelIDList.Add(RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element));
          }
          else
          {
            int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "ParkingLotNoPositioning", EPShared.LocalRM.GetString("PositionParkingLotsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
          }
        }
        if (_PlacementSettings.TransactionContainer != null)
          _PlacementSettings.TransactionContainer.BeginTransaction();
        ProgressBarForm _ProgressFrm = new ProgressBarForm();
        _ProgressFrm.ShowForm();
        _ProgressFrm.Refresh();
        _ProgressFrm.Message = EPShared.LocalRM.GetString("StallOnLineMessage");
        bool _bDrawFirstDoubleStripe = true;
        if (_bUseFirstLine)
        {
          if (_FirstLine != null)
          {
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstLine, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI), false, ref epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe);
            epsLine.StartPnt = epsPoint1;
            if (_SecondLine == null)
              epsLine.EndPnt = _FirstLine.StartPnt;
          }
          if (_SecondLine != null)
          {
            if (RevitDefines.EQ(startingDistance, 0.0))
              _bDrawFirstDoubleStripe = false;
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondLine, num1, false, ref epsPoint2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe);
            epsLine.EndPnt = epsPoint2;
            if (_FirstLine == null)
              epsLine.StartPnt = _SecondLine.StartPnt;
          }
        }
        else
        {
          if (_SecondLine != null)
          {
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondLine, num1, false, ref epsPoint2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe);
            epsLine.EndPnt = epsPoint2;
            if (_FirstLine == null)
              epsLine.StartPnt = _SecondLine.StartPnt;
          }
          if (_FirstLine != null)
          {
            if (RevitDefines.EQ(startingDistance, 0.0))
              _bDrawFirstDoubleStripe = false;
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstLine, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI), false, ref epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe);
            epsLine.StartPnt = epsPoint1;
            if (_SecondLine == null)
              epsLine.EndPnt = _FirstLine.StartPnt;
          }
        }
        if (_PlacementSettings.Parking.IslandSymbol != null && _PlacementSettings.Parking.IslandWidth > 0.0)
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDirection);
          if (!_PlacementSettings.Parking.CenterIsland)
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection), _PlacementSettings.Parking.IslandWidth, ref epsPoint1);
            ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
            ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsLine.EndPnt, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
          }
          else
          {
            double _dDistance = 0.0;
            EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLine.StartPnt, epsLine.EndPnt, ref epsPoint3);
            EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDistance);
            if (RevitDefines.GT(num1, Math.PI))
              EPShared.eplGeoE_CalcPolarToXY(epsPoint3, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth, ref epsPoint3);
            else
              EPShared.eplGeoE_CalcPolarToXY(epsPoint3, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth, ref epsPoint3);
            ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint3, _dDistance, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
          }
        }
        _ProgressFrm.Close();
        if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
        {
          for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
            _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
        }
        if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
        {
          for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
            _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
        }
        if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
        {
          for (int index = 0; index < _ExistingBumperList.Count; ++index)
            _Document.Delete(((Element) _ExistingBumperList[index]).Id);
        }
        if (_ExistingIslandList != null && _ExistingIslandList.Count > 0)
        {
          for (int index = 0; index < _ExistingIslandList.Count; ++index)
            _Document.Delete(((Element) _ExistingIslandList[index]).Id);
        }
        if (_PlacementSettings.TransactionContainer != null)
          _PlacementSettings.TransactionContainer.EndTransaction();
      }
      else
      {
        Eps_Point _SidePoint = !_PlacementSettings.UseRightSide ? _OffsetLine2.StartPnt : _OffsetLine1.StartPnt;
        if (!_PlacementSettings.DeleteExistingChecked && _PlacementSettings.GenericModelIDList == null && _Element != null)
        {
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.ADAStallSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.BumperSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.IslandSymbol))
          {
            _PlacementSettings.GenericModelIDList = new List<KeyValuePair<string, string>>();
            _PlacementSettings.GenericModelIDList.Add(RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element));
          }
          else
          {
            int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "ParkingLotNoPositioning", EPShared.LocalRM.GetString("PositionParkingLotsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
          }
        }
        if (_PlacementSettings.TransactionContainer != null)
          _PlacementSettings.TransactionContainer.BeginTransaction();
        ProgressBarForm _ProgressFrm = new ProgressBarForm();
        _ProgressFrm.ShowForm();
        _ProgressFrm.Refresh();
        _ProgressFrm.Message = EPShared.LocalRM.GetString("StallOnLineMessage");
        ParkingLotCommon.DrawAreaParking(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _ParkingLotLine, _SidePoint, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, ref _ExistingIslandList);
        _ProgressFrm.Close();
        if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
        {
          for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
            _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
        }
        if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
        {
          for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
            _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
        }
        if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
        {
          for (int index = 0; index < _ExistingBumperList.Count; ++index)
            _Document.Delete(((Element) _ExistingBumperList[index]).Id);
        }
        if (_ExistingIslandList != null && _ExistingIslandList.Count > 0)
        {
          for (int index = 0; index < _ExistingIslandList.Count; ++index)
            _Document.Delete(((Element) _ExistingIslandList[index]).Id);
        }
        if (_PlacementSettings.TransactionContainer != null)
          _PlacementSettings.TransactionContainer.EndTransaction();
      }
    }
    else if (_PlacementSettings.PlacementType == PlacementType.ParkingDoubleRow)
    {
      if (!_PlacementSettings.DeleteExistingChecked && _PlacementSettings.GenericModelIDList == null && _Element != null)
      {
        if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.ADAStallSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.BumperSymbol) && RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Parking.IslandSymbol))
        {
          _PlacementSettings.GenericModelIDList = new List<KeyValuePair<string, string>>();
          _PlacementSettings.GenericModelIDList.Add(RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element));
        }
        else
        {
          int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "ParkingLotNoPositioning", EPShared.LocalRM.GetString("PositionParkingLotsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
        }
      }
      if (_PlacementSettings.TransactionContainer != null)
        _PlacementSettings.TransactionContainer.BeginTransaction();
      ProgressBarForm _ProgressFrm = new ProgressBarForm();
      _ProgressFrm.ShowForm();
      _ProgressFrm.Refresh();
      _ProgressFrm.Message = EPShared.LocalRM.GetString("StallOnLineMessage");
      bool _bDrawFirstDoubleStripe1 = true;
      if (_PlacementSettings.Parking.PlaceIsland && RevitDefines.GT(_PlacementSettings.Parking.IslandWidth, 0.0))
      {
        if (_bUseFirstLine)
        {
          if (_FirstLine != null)
          {
            Eps_Line _OffsetLine3 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_FirstLine, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetLine3);
            Eps_Line _OffsetLine4 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_FirstLine, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetLine4);
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine3, EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0), true, ref epsPoint3, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
            if (_SecondLine == null)
            {
              ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine4, _PlacementSettings.RotationAngle, false, ref epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
              epsLine.EndPnt = _OffsetLine4.StartPnt;
            }
            else
              ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine4, _PlacementSettings.RotationAngle, true, ref epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
            epsLine.StartPnt = epsPoint1;
          }
          if (_SecondLine != null)
          {
            Eps_Line _OffsetLine5 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_SecondLine, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetLine5);
            Eps_Line _OffsetLine6 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_SecondLine, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetLine6);
            bool _bDrawFirstDoubleStripe2 = false;
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine5, EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0), true, ref epsPoint2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe2);
            bool _bDrawFirstDoubleStripe3 = false;
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine6, _PlacementSettings.RotationAngle, false, ref epsPoint3, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe3);
            if (_FirstLine == null)
              epsLine.StartPnt = _OffsetLine5.StartPnt;
            epsLine.EndPnt = epsPoint2;
          }
        }
        else
        {
          if (_SecondLine != null)
          {
            Eps_Line _OffsetLine7 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_SecondLine, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetLine7);
            Eps_Line _OffsetLine8 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_SecondLine, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetLine8);
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine7, EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0), true, ref epsPoint2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
            if (_FirstLine == null)
            {
              ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine8, _PlacementSettings.RotationAngle, false, ref epsPoint3, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
              epsLine.StartPnt = _OffsetLine7.StartPnt;
            }
            else
              ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine8, _PlacementSettings.RotationAngle, true, ref epsPoint3, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
            epsLine.EndPnt = epsPoint2;
          }
          if (_FirstLine != null)
          {
            Eps_Line _OffsetLine9 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_FirstLine, _PlacementSettings.Parking.IslandWidth / 2.0, 1, ref _OffsetLine9);
            Eps_Line _OffsetLine10 = new Eps_Line();
            EPShared.eplGeoE_ConstructOffsetLine(_FirstLine, _PlacementSettings.Parking.IslandWidth / 2.0, 2, ref _OffsetLine10);
            bool _bDrawFirstDoubleStripe4 = false;
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine9, EPShared.eplGeoE_NormalizeRadians(_PlacementSettings.RotationAngle * -1.0), true, ref epsPoint3, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe4);
            bool _bDrawFirstDoubleStripe5 = false;
            ParkingLotCommon.CreateSingleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _OffsetLine10, _PlacementSettings.RotationAngle, false, ref epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe5);
            if (_SecondLine == null)
              epsLine.EndPnt = _OffsetLine10.StartPnt;
            epsLine.StartPnt = epsPoint1;
          }
        }
      }
      else if (_bUseFirstLine)
      {
        if (_FirstLine != null)
        {
          ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstLine, epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
          epsLine.StartPnt = epsPoint1;
          if (_SecondLine == null)
            epsLine.EndPnt = _FirstLine.StartPnt;
        }
        if (_SecondLine != null)
        {
          bool _bDrawFirstDoubleStripe6 = false;
          ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondLine, epsPoint2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe6);
          epsLine.EndPnt = epsPoint2;
          if (_FirstLine == null)
            epsLine.StartPnt = _SecondLine.StartPnt;
        }
      }
      else
      {
        if (_SecondLine != null)
        {
          ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _SecondLine, epsPoint2, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe1);
          epsLine.EndPnt = epsPoint2;
          if (_FirstLine == null)
            epsLine.StartPnt = _SecondLine.StartPnt;
        }
        if (_FirstLine != null)
        {
          bool _bDrawFirstDoubleStripe7 = false;
          ParkingLotCommon.CreateDoubleStalls(_Document, ref _PlacementSettings, _ProgressFrm, _Element, _FirstLine, epsPoint1, ref _ExistingParkingStallList, ref _ExistingADAParkingStallList, ref _ExistingBumperList, _bDrawFirstDoubleStripe7);
          epsLine.StartPnt = epsPoint1;
          if (_SecondLine == null)
            epsLine.EndPnt = _FirstLine.StartPnt;
        }
      }
      if (_PlacementSettings.Parking.IslandSymbol != null && _PlacementSettings.Parking.IslandWidth > 0.0)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDirection);
        if (!_PlacementSettings.Parking.CenterIsland)
        {
          EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection), _PlacementSettings.Parking.IslandWidth, ref epsPoint1);
          EPShared.eplGeoE_CalcPolarToXY(epsLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection), _PlacementSettings.Parking.IslandWidth, ref epsPoint2);
          ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint1, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
          ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsLine.StartPnt, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection), ref _ExistingIslandList);
          ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint2, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, EPShared.eplGeoE_NormalizeRadians(Math.PI + _dDirection), ref _ExistingIslandList);
          ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsLine.EndPnt, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
        }
        else
        {
          double _dDistance = 0.0;
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLine.StartPnt, epsLine.EndPnt, ref epsPoint3);
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDistance);
          EPShared.eplGeoE_CalcPolarToXY(epsPoint3, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), _PlacementSettings.Parking.IslandWidth / 2.0, ref epsPoint3);
          ParkingLotCommon.DrawIsland(_Document, _PlacementSettings, _Element, epsPoint3, _dDistance, _PlacementSettings.Parking.IslandWidth, _PlacementSettings.RotationAngle, _PlacementSettings.Parking.StripeLength, _dDirection, ref _ExistingIslandList);
        }
      }
      _ProgressFrm.Close();
      if (_ExistingParkingStallList != null && _ExistingParkingStallList.Count > 0)
      {
        for (int index = 0; index < _ExistingParkingStallList.Count; ++index)
          _Document.Delete(((Element) _ExistingParkingStallList[index]).Id);
      }
      if (_ExistingADAParkingStallList != null && _ExistingADAParkingStallList.Count > 0)
      {
        for (int index = 0; index < _ExistingADAParkingStallList.Count; ++index)
          _Document.Delete(((Element) _ExistingADAParkingStallList[index]).Id);
      }
      if (_ExistingBumperList != null && _ExistingBumperList.Count > 0)
      {
        for (int index = 0; index < _ExistingBumperList.Count; ++index)
          _Document.Delete(((Element) _ExistingBumperList[index]).Id);
      }
      if (_ExistingIslandList != null && _ExistingIslandList.Count > 0)
      {
        for (int index = 0; index < _ExistingIslandList.Count; ++index)
          _Document.Delete(((Element) _ExistingIslandList[index]).Id);
      }
      if (_PlacementSettings.TransactionContainer != null)
        _PlacementSettings.TransactionContainer.EndTransaction();
    }
    return true;
  }
}
