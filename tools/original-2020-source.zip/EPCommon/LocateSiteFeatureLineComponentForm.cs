﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LocateSiteFeatureLineComponentForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LocateSiteFeatureLineComponentForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private SiteComponentCreation m_dataBuffer;
  private DisplayUnit m_DisplayUnitSystem;
  private FormatOptions m_LengthFormatOptions;
  private FormatOptions m_SlopeFormatOptions;
  private UnitSymbolType m_LengthUnitSymbolType;
  private UnitSymbolType m_SlopeUnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private CurrentElevationFocus m_CurrentElevationFocus;
  private double m_dAdjustConstElevation;
  private IContainer components;
  private Label m_BeginningElevationRangeLabel;
  private TextBox m_BeginningElevationRangeTextBox;
  private Panel m_MoveablePanel;
  private CheckBox m_CreateCopyCheckBox;
  private Button m_CloseButton;
  private Button m_InsertButton;
  private Label m_RadiusLabel;
  private TextBox m_RadiusTextBox;
  private RadioButton m_RelativeElevationRadioButton;
  private Label m_RelativeElevationLabel;
  private TextBox m_RelativeElevationTextBox;
  private RadioButton m_ElevationRangeRadioButton;
  private Panel m_UsePanel;
  private RadioButton m_SegmentRadioButton;
  private RadioButton m_ChainRadioButton;
  private Panel m_HostLineSelectionPanel;
  private RadioButton m_UseExistingHostLineRadioButton;
  private RadioButton m_DrawHostLineRadioButton;
  private Label m_EndingElevationRangeLabel;
  private TextBox m_EndingElevationRangeTextBox;
  private Label m_GradeLabel;
  private TextBox m_GradeTextBox;
  private RadioButton m_GradeRadioButton;
  private Label m_GradeBeginningElevationLabel;
  private TextBox m_GradeBeginningElevationTextBox;
  private Label m_LinearIntervalLabel;
  private TextBox m_LinearIntervalTextBox;
  private Button m_PickInRevitButton;

  public LocateSiteFeatureLineComponentForm(SiteComponentCreation dataBuffer)
  {
    this.InitializeComponent();
    this.SetStrings();
    this.EPToolTip.SetToolTip((Control) this.m_PickInRevitButton, EPShared.LocalRM.GetString("PickPointElevationToolTip"));
    this.ContextualHelpID = "HID_SDfeatureLineCreate";
    this.m_dataBuffer = dataBuffer;
    this.m_LengthFormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_LengthUnitSymbolType = this.m_LengthFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_LengthUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_SlopeFormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 59);
    try
    {
      this.m_SlopeUnitSymbolType = this.m_SlopeFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_SlopeUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.m_dAdjustConstElevation = 0.0;
    this.InitializeControls();
  }

  private void SetStrings()
  {
    this.Text = EPShared.LocalRM.GetString("LocateFeatureLineDialog");
    this.m_LinearIntervalLabel.Text = EPShared.LocalRM.GetString("Linear_AMP_PointIntervalDialog");
    this.m_RelativeElevationRadioButton.Text = EPShared.LocalRM.GetString("Re_AMP_lativeElevationFromToposurfaceDialog");
    this.m_RelativeElevationLabel.Text = EPShared.LocalRM.GetString("AMP_ElevationDialog");
    this.m_ElevationRangeRadioButton.Text = EPShared.LocalRM.GetString("Elevatio_AMP_nRangeDialog");
    this.m_BeginningElevationRangeLabel.Text = EPShared.LocalRM.GetString("AMP_BeginningElevationDialog");
    this.m_EndingElevationRangeLabel.Text = EPShared.LocalRM.GetString("EndingEle_AMP_vationDialog");
    this.m_GradeBeginningElevationLabel.Text = EPShared.LocalRM.GetString("AMP_BeginningElevationDialog");
    this.m_GradeLabel.Text = EPShared.LocalRM.GetString("AMP_GradeDialog");
    this.m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_CreateCopyCheckBox.Text = EPShared.LocalRM.GetString("Create_AMP_ACopyDialog");
    this.m_UseExistingHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_UseExistingHostLineDialog");
    this.m_DrawHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_DrawHostLineDialog");
    this.m_RadiusLabel.Text = EPShared.LocalRM.GetString("AMP_RadiusDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty = string.Empty;
    this.GetDialogPosition();
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineLinearInterval", ref _dReturnValue))
      _dReturnValue = 5.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_LinearIntervalTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineRelativeElevation", ref _dReturnValue))
      _dReturnValue = 15.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_RelativeElevationTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineBeginningElevationRange", ref _dReturnValue))
      _dReturnValue = 15.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_BeginningElevationRangeTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineEndingElevationRange", ref _dReturnValue))
      _dReturnValue = 15.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_EndingElevationRangeTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineGradeBeginningElevation", ref _dReturnValue))
      _dReturnValue = 15.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_GradeBeginningElevationTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineGrade", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_SlopeFormatOptions.DisplayUnits, this.m_SlopeFormatOptions.Accuracy, this.m_SlopeUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_GradeTextBox.Text = empty;
    this.m_UseExistingHostLineRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineHostLineSelectionOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_UseExistingHostLineRadioButton.Checked = true;
      else
        this.m_DrawHostLineRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineRadius", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_RadiusTextBox.Text = empty;
    this.m_CreateCopyCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineCreateVisibleCopy", ref _nReturnValue))
      this.m_CreateCopyCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ChainRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineSegmentChainOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_SegmentRadioButton.Checked = true;
      else
        this.m_ChainRadioButton.Checked = true;
    }
    this.m_RelativeElevationRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateFeatureLineElevationOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_RelativeElevationRadioButton.Checked = true;
          break;
        case 1:
          this.m_ElevationRangeRadioButton.Checked = true;
          break;
        default:
          this.m_GradeRadioButton.Checked = true;
          break;
      }
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "UseSharedElevation", ref _nReturnValue) || _nReturnValue != 1)
      return;
    this.m_dAdjustConstElevation = this.m_dataBuffer.Document.ActiveProjectLocation.GetProjectPosition(new XYZ()).Elevation;
  }

  private void SaveSettings()
  {
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_LinearIntervalTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineLinearInterval", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RelativeElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineRelativeElevation", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BeginningElevationRangeTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineBeginningElevationRange", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationRangeTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineEndingElevationRange", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_GradeBeginningElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineGradeBeginningElevation", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Units, (UnitType) 59, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineGrade", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineHostLineSelectionOption", !this.m_UseExistingHostLineRadioButton.Checked ? 1 : 0);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineRadius", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineCreateVisibleCopy", Convert.ToInt32(this.m_CreateCopyCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineSegmentChainOption", !this.m_SegmentRadioButton.Checked ? 1 : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting("LocateFeatureLineElevationOption", !this.m_RelativeElevationRadioButton.Checked ? (!this.m_ElevationRangeRadioButton.Checked ? 2 : 1) : 0);
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCloseButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnHostLineSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_RadiusLabel.Enabled = this.m_DrawHostLineRadioButton.Checked;
    this.m_RadiusTextBox.Enabled = this.m_DrawHostLineRadioButton.Checked;
  }

  private void OnElevationSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_RelativeElevationLabel.Enabled = this.m_RelativeElevationRadioButton.Checked;
    this.m_RelativeElevationTextBox.Enabled = this.m_RelativeElevationRadioButton.Checked;
    this.m_BeginningElevationRangeLabel.Enabled = this.m_ElevationRangeRadioButton.Checked;
    this.m_BeginningElevationRangeTextBox.Enabled = this.m_ElevationRangeRadioButton.Checked;
    this.m_EndingElevationRangeLabel.Enabled = this.m_ElevationRangeRadioButton.Checked;
    this.m_EndingElevationRangeTextBox.Enabled = this.m_ElevationRangeRadioButton.Checked;
    this.m_GradeBeginningElevationLabel.Enabled = this.m_GradeRadioButton.Checked;
    this.m_GradeBeginningElevationTextBox.Enabled = this.m_GradeRadioButton.Checked;
    this.m_GradeLabel.Enabled = this.m_GradeRadioButton.Checked;
    this.m_GradeTextBox.Enabled = this.m_GradeRadioButton.Checked;
  }

  private bool ValidateFields() => true;

  private void FormatRelativeElevationValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RelativeElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_RelativeElevationTextBox.Text = empty;
    }
    else
      this.m_RelativeElevationTextBox.Focus();
  }

  private void OnRelativeElevationKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatRelativeElevationValue();
  }

  private void OnRelativeElevationTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatRelativeElevationValue();
  }

  private void FormatBeginningElevationRangeValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BeginningElevationRangeTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_BeginningElevationRangeTextBox.Text = empty;
    }
    else
      this.m_BeginningElevationRangeTextBox.Focus();
  }

  private void OnBeginningElevationRangeKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatBeginningElevationRangeValue();
  }

  private void OnBeginningElevationRangeTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatBeginningElevationRangeValue();
    this.m_CurrentElevationFocus = CurrentElevationFocus.BeginningElevationRange;
  }

  private void FormatEndingElevationRangeValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationRangeTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_EndingElevationRangeTextBox.Text = empty;
    }
    else
      this.m_EndingElevationRangeTextBox.Focus();
  }

  private void OnEndingElevationRangeKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatEndingElevationRangeValue();
  }

  private void OnEndingElevationRangeTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatEndingElevationRangeValue();
    this.m_CurrentElevationFocus = CurrentElevationFocus.EndingElevationRange;
  }

  private void FormatGradeBeginningElevationValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_GradeBeginningElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_GradeBeginningElevationTextBox.Text = empty;
    }
    else
      this.m_GradeBeginningElevationTextBox.Focus();
  }

  private void OnGradeBeginningElevationKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatGradeBeginningElevationValue();
  }

  private void OnGradeBeginningElevationTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatGradeBeginningElevationValue();
    this.m_CurrentElevationFocus = CurrentElevationFocus.GradeBeginningElevation;
  }

  private void FormatGradeValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Units, (UnitType) 59, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_SlopeFormatOptions.DisplayUnits, this.m_SlopeFormatOptions.Accuracy, this.m_SlopeUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_GradeTextBox.Text = empty;
    }
    else
      this.m_GradeTextBox.Focus();
  }

  private void OnGradeKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatGradeValue();
  }

  private void OnGradeTextBoxLeave(object sender, EventArgs e) => this.FormatGradeValue();

  private void FormatRadiusValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      if (_dReturnedDouble < 0.0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusValueString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_RadiusTextBox.Text = string.Empty;
      }
      else
      {
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
        this.m_RadiusTextBox.Text = empty;
      }
    }
    else
      this.m_RadiusTextBox.Focus();
  }

  private void OnRadiusKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatRadiusValue();
  }

  private void OnRadiusTextBoxLeave(object sender, EventArgs e) => this.FormatRadiusValue();

  private void FormatLinearIntervalValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_LinearIntervalTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_LinearIntervalTextBox.Text = empty;
    }
    else
      this.m_LinearIntervalTextBox.Focus();
  }

  private void OnLinearIntervalKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatLinearIntervalValue();
  }

  private void OnLinearIntervalTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatLinearIntervalValue();
  }

  private void OnLocateSiteComponentClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public double GetGrade(double _dLegListLength)
  {
    double _dReturnedDouble = 0.0;
    if (this.m_ElevationRangeRadioButton.Checked)
    {
      if (this.m_EndingElevationRangeTextBox.Text != string.Empty)
      {
        RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationRangeTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        _dReturnedDouble = (_dReturnedDouble - this.m_dAdjustConstElevation - this.Elevation) / _dLegListLength;
      }
    }
    else if (this.m_GradeRadioButton.Checked && this.m_GradeTextBox.Text != string.Empty)
      RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Units, (UnitType) 59, ref _dReturnedDouble);
    return _dReturnedDouble;
  }

  private void OnPickInRevitButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnElevationTextBoxEnter(object sender, EventArgs e)
  {
    this.m_PickInRevitButton.Enabled = true;
  }

  private void OnElevationTextBoxLostFocus(object sender, EventArgs e)
  {
    if (this.m_PickInRevitButton.Focused || this.m_BeginningElevationRangeTextBox.Focused || this.m_EndingElevationRangeTextBox.Focused || this.m_GradeBeginningElevationTextBox.Focused)
      return;
    this.m_PickInRevitButton.Enabled = false;
  }

  public void SetFocusedElevation(double _dElevation)
  {
    string empty = string.Empty;
    _dElevation += this.m_dAdjustConstElevation;
    RevitGeometry.Units_ConvertDoubleToString(_dElevation, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    switch (this.m_CurrentElevationFocus)
    {
      case CurrentElevationFocus.BeginningElevationRange:
        this.m_BeginningElevationRangeTextBox.Text = empty;
        this.m_PickInRevitButton.Enabled = true;
        break;
      case CurrentElevationFocus.EndingElevationRange:
        this.m_EndingElevationRangeTextBox.Text = empty;
        this.m_PickInRevitButton.Enabled = true;
        break;
      case CurrentElevationFocus.GradeBeginningElevation:
        this.m_GradeBeginningElevationTextBox.Text = empty;
        this.m_PickInRevitButton.Enabled = true;
        break;
    }
  }

  private void OnLocateSiteFeatureLineComponentFormShown(object sender, EventArgs e)
  {
    switch (this.m_CurrentElevationFocus)
    {
      case CurrentElevationFocus.None:
        this.m_PickInRevitButton.Enabled = false;
        break;
      case CurrentElevationFocus.BeginningElevationRange:
        this.m_BeginningElevationRangeTextBox.Focus();
        this.m_PickInRevitButton.Enabled = true;
        break;
      case CurrentElevationFocus.EndingElevationRange:
        this.m_EndingElevationRangeTextBox.Focus();
        this.m_PickInRevitButton.Enabled = true;
        break;
      case CurrentElevationFocus.GradeBeginningElevation:
        this.m_GradeBeginningElevationTextBox.Focus();
        this.m_PickInRevitButton.Enabled = true;
        break;
    }
  }

  public bool ExistingHostLineChecked => this.m_UseExistingHostLineRadioButton.Checked;

  public bool CreateCopyChecked => this.m_CreateCopyCheckBox.Checked;

  public double Radius
  {
    get
    {
      if (this.m_UseExistingHostLineRadioButton.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_RadiusTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double Elevation
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_RelativeElevationRadioButton.Checked)
      {
        if (this.m_RelativeElevationTextBox.Text != string.Empty)
          RevitGeometry.Units_ConvertStringToDouble(this.m_RelativeElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      }
      else if (this.m_ElevationRangeRadioButton.Checked)
      {
        if (this.m_BeginningElevationRangeTextBox.Text != string.Empty)
        {
          RevitGeometry.Units_ConvertStringToDouble(this.m_BeginningElevationRangeTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
          _dReturnedDouble -= this.m_dAdjustConstElevation;
        }
      }
      else if (this.m_GradeBeginningElevationTextBox.Text != string.Empty)
      {
        RevitGeometry.Units_ConvertStringToDouble(this.m_GradeBeginningElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        _dReturnedDouble -= this.m_dAdjustConstElevation;
      }
      return _dReturnedDouble;
    }
  }

  public double LinearInterval
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_LinearIntervalTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_LinearIntervalTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool SegmentChecked => this.m_SegmentRadioButton.Checked;

  public bool ChainChecked => this.m_ChainRadioButton.Checked;

  public bool RelativeElevationChecked => this.m_RelativeElevationRadioButton.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (LocateSiteFeatureLineComponentForm));
    this.m_BeginningElevationRangeLabel = new Label();
    this.m_BeginningElevationRangeTextBox = new TextBox();
    this.m_MoveablePanel = new Panel();
    this.m_CloseButton = new Button();
    this.m_InsertButton = new Button();
    this.m_CreateCopyCheckBox = new CheckBox();
    this.m_RadiusLabel = new Label();
    this.m_RadiusTextBox = new TextBox();
    this.m_RelativeElevationRadioButton = new RadioButton();
    this.m_RelativeElevationLabel = new Label();
    this.m_RelativeElevationTextBox = new TextBox();
    this.m_ElevationRangeRadioButton = new RadioButton();
    this.m_UsePanel = new Panel();
    this.m_SegmentRadioButton = new RadioButton();
    this.m_ChainRadioButton = new RadioButton();
    this.m_HostLineSelectionPanel = new Panel();
    this.m_UseExistingHostLineRadioButton = new RadioButton();
    this.m_DrawHostLineRadioButton = new RadioButton();
    this.m_EndingElevationRangeLabel = new Label();
    this.m_EndingElevationRangeTextBox = new TextBox();
    this.m_GradeLabel = new Label();
    this.m_GradeTextBox = new TextBox();
    this.m_GradeRadioButton = new RadioButton();
    this.m_GradeBeginningElevationLabel = new Label();
    this.m_GradeBeginningElevationTextBox = new TextBox();
    this.m_LinearIntervalLabel = new Label();
    this.m_LinearIntervalTextBox = new TextBox();
    this.m_PickInRevitButton = new Button();
    this.m_MoveablePanel.SuspendLayout();
    this.m_UsePanel.SuspendLayout();
    this.m_HostLineSelectionPanel.SuspendLayout();
    this.SuspendLayout();
    this.m_BeginningElevationRangeLabel.AutoSize = true;
    this.m_BeginningElevationRangeLabel.Enabled = false;
    this.m_BeginningElevationRangeLabel.Location = new Point(30, 113);
    this.m_BeginningElevationRangeLabel.Name = "m_BeginningElevationRangeLabel";
    this.m_BeginningElevationRangeLabel.Size = new Size(104, 13);
    this.m_BeginningElevationRangeLabel.TabIndex = 7;
    this.m_BeginningElevationRangeLabel.Text = "Beginning Elevation:";
    this.m_BeginningElevationRangeTextBox.Enabled = false;
    this.m_BeginningElevationRangeTextBox.Location = new Point(156, 110);
    this.m_BeginningElevationRangeTextBox.Name = "m_BeginningElevationRangeTextBox";
    this.m_BeginningElevationRangeTextBox.Size = new Size(100, 20);
    this.m_BeginningElevationRangeTextBox.TabIndex = 8;
    this.m_BeginningElevationRangeTextBox.KeyDown += new KeyEventHandler(this.OnBeginningElevationRangeKeyDown);
    this.m_BeginningElevationRangeTextBox.Leave += new EventHandler(this.OnBeginningElevationRangeTextBoxLeave);
    this.m_BeginningElevationRangeTextBox.Enter += new EventHandler(this.OnElevationTextBoxEnter);
    this.m_BeginningElevationRangeTextBox.LostFocus += new EventHandler(this.OnElevationTextBoxLostFocus);
    this.m_MoveablePanel.Controls.Add((Control) this.m_CloseButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Location = new Point(12, 304);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(476, 23);
    this.m_MoveablePanel.TabIndex = 21;
    this.m_CloseButton.DialogResult = DialogResult.Cancel;
    this.m_CloseButton.Location = new Point(400, 0);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 1;
    this.m_CloseButton.Text = "&Cancel";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClick);
    this.m_InsertButton.Location = new Point(319, 0);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 0;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CreateCopyCheckBox.AutoSize = true;
    this.m_CreateCopyCheckBox.Location = new Point(12, 209);
    this.m_CreateCopyCheckBox.Name = "m_CreateCopyCheckBox";
    this.m_CreateCopyCheckBox.Size = new Size(94, 17);
    this.m_CreateCopyCheckBox.TabIndex = 17;
    this.m_CreateCopyCheckBox.Text = "Create A Copy";
    this.m_CreateCopyCheckBox.UseVisualStyleBackColor = true;
    this.m_RadiusLabel.AutoSize = true;
    this.m_RadiusLabel.Enabled = false;
    this.m_RadiusLabel.Location = new Point(30, 281);
    this.m_RadiusLabel.Name = "m_RadiusLabel";
    this.m_RadiusLabel.Size = new Size(43, 13);
    this.m_RadiusLabel.TabIndex = 19;
    this.m_RadiusLabel.Text = "Radius:";
    this.m_RadiusTextBox.Enabled = false;
    this.m_RadiusTextBox.Location = new Point(219, 278);
    this.m_RadiusTextBox.Name = "m_RadiusTextBox";
    this.m_RadiusTextBox.Size = new Size(100, 20);
    this.m_RadiusTextBox.TabIndex = 20;
    this.m_RadiusTextBox.KeyDown += new KeyEventHandler(this.OnRadiusKeyDown);
    this.m_RadiusTextBox.Leave += new EventHandler(this.OnRadiusTextBoxLeave);
    this.m_RelativeElevationRadioButton.AutoSize = true;
    this.m_RelativeElevationRadioButton.Location = new Point(12, 38);
    this.m_RelativeElevationRadioButton.Name = "m_RelativeElevationRadioButton";
    this.m_RelativeElevationRadioButton.Size = new Size(197, 17);
    this.m_RelativeElevationRadioButton.TabIndex = 3;
    this.m_RelativeElevationRadioButton.Text = "&Relative Elevation from Toposurface";
    this.m_RelativeElevationRadioButton.UseVisualStyleBackColor = true;
    this.m_RelativeElevationRadioButton.CheckedChanged += new EventHandler(this.OnElevationSelectionOptionChecked);
    this.m_RelativeElevationLabel.AutoSize = true;
    this.m_RelativeElevationLabel.Enabled = false;
    this.m_RelativeElevationLabel.Location = new Point(30, 64 /*0x40*/);
    this.m_RelativeElevationLabel.Name = "m_RelativeElevationLabel";
    this.m_RelativeElevationLabel.Size = new Size(54, 13);
    this.m_RelativeElevationLabel.TabIndex = 4;
    this.m_RelativeElevationLabel.Text = "Elevation:";
    this.m_RelativeElevationTextBox.Enabled = false;
    this.m_RelativeElevationTextBox.Location = new Point(156, 61);
    this.m_RelativeElevationTextBox.Name = "m_RelativeElevationTextBox";
    this.m_RelativeElevationTextBox.Size = new Size(100, 20);
    this.m_RelativeElevationTextBox.TabIndex = 5;
    this.m_RelativeElevationTextBox.KeyDown += new KeyEventHandler(this.OnRelativeElevationKeyDown);
    this.m_RelativeElevationTextBox.Leave += new EventHandler(this.OnRelativeElevationTextBoxLeave);
    this.m_ElevationRangeRadioButton.AutoSize = true;
    this.m_ElevationRangeRadioButton.Location = new Point(12, 87);
    this.m_ElevationRangeRadioButton.Name = "m_ElevationRangeRadioButton";
    this.m_ElevationRangeRadioButton.Size = new Size(104, 17);
    this.m_ElevationRangeRadioButton.TabIndex = 6;
    this.m_ElevationRangeRadioButton.Text = "&Elevation Range";
    this.m_ElevationRangeRadioButton.UseVisualStyleBackColor = true;
    this.m_ElevationRangeRadioButton.CheckedChanged += new EventHandler(this.OnElevationSelectionOptionChecked);
    this.m_UsePanel.Controls.Add((Control) this.m_SegmentRadioButton);
    this.m_UsePanel.Controls.Add((Control) this.m_ChainRadioButton);
    this.m_UsePanel.Location = new Point(12, 186);
    this.m_UsePanel.Name = "m_UsePanel";
    this.m_UsePanel.Size = new Size(476, 18);
    this.m_UsePanel.TabIndex = 16 /*0x10*/;
    this.m_SegmentRadioButton.AutoSize = true;
    this.m_SegmentRadioButton.Location = new Point(0, 0);
    this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
    this.m_SegmentRadioButton.Size = new Size(67, 17);
    this.m_SegmentRadioButton.TabIndex = 0;
    this.m_SegmentRadioButton.Text = "&Segment";
    this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_ChainRadioButton.AutoSize = true;
    this.m_ChainRadioButton.Checked = true;
    this.m_ChainRadioButton.Location = new Point(207, 0);
    this.m_ChainRadioButton.Name = "m_ChainRadioButton";
    this.m_ChainRadioButton.Size = new Size(52, 17);
    this.m_ChainRadioButton.TabIndex = 1;
    this.m_ChainRadioButton.TabStop = true;
    this.m_ChainRadioButton.Text = "&Chain";
    this.m_ChainRadioButton.UseVisualStyleBackColor = true;
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_UseExistingHostLineRadioButton);
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_DrawHostLineRadioButton);
    this.m_HostLineSelectionPanel.Location = new Point(12, 232);
    this.m_HostLineSelectionPanel.Name = "m_HostLineSelectionPanel";
    this.m_HostLineSelectionPanel.Size = new Size(476, 41);
    this.m_HostLineSelectionPanel.TabIndex = 18;
    this.m_UseExistingHostLineRadioButton.AutoSize = true;
    this.m_UseExistingHostLineRadioButton.Location = new Point(0, 0);
    this.m_UseExistingHostLineRadioButton.Name = "m_UseExistingHostLineRadioButton";
    this.m_UseExistingHostLineRadioButton.Size = new Size(146, 17);
    this.m_UseExistingHostLineRadioButton.TabIndex = 0;
    this.m_UseExistingHostLineRadioButton.Text = "&Use an Existing Host Line";
    this.m_UseExistingHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_UseExistingHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_DrawHostLineRadioButton.AutoSize = true;
    this.m_DrawHostLineRadioButton.Location = new Point(0, 23);
    this.m_DrawHostLineRadioButton.Name = "m_DrawHostLineRadioButton";
    this.m_DrawHostLineRadioButton.Size = new Size(228, 17);
    this.m_DrawHostLineRadioButton.TabIndex = 1;
    this.m_DrawHostLineRadioButton.Text = "&Draw Host Line (Click Escape to Complete)";
    this.m_DrawHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_DrawHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_EndingElevationRangeLabel.AutoSize = true;
    this.m_EndingElevationRangeLabel.Enabled = false;
    this.m_EndingElevationRangeLabel.Location = new Point(262, 113);
    this.m_EndingElevationRangeLabel.Name = "m_EndingElevationRangeLabel";
    this.m_EndingElevationRangeLabel.Size = new Size(90, 13);
    this.m_EndingElevationRangeLabel.TabIndex = 9;
    this.m_EndingElevationRangeLabel.Text = "Ending Elevation:";
    this.m_EndingElevationRangeTextBox.Enabled = false;
    this.m_EndingElevationRangeTextBox.Location = new Point(388, 110);
    this.m_EndingElevationRangeTextBox.Name = "m_EndingElevationRangeTextBox";
    this.m_EndingElevationRangeTextBox.Size = new Size(100, 20);
    this.m_EndingElevationRangeTextBox.TabIndex = 10;
    this.m_EndingElevationRangeTextBox.KeyDown += new KeyEventHandler(this.OnEndingElevationRangeKeyDown);
    this.m_EndingElevationRangeTextBox.Leave += new EventHandler(this.OnEndingElevationRangeTextBoxLeave);
    this.m_EndingElevationRangeTextBox.Enter += new EventHandler(this.OnElevationTextBoxEnter);
    this.m_EndingElevationRangeTextBox.LostFocus += new EventHandler(this.OnElevationTextBoxLostFocus);
    this.m_GradeLabel.AutoSize = true;
    this.m_GradeLabel.Enabled = false;
    this.m_GradeLabel.Location = new Point(262, 163);
    this.m_GradeLabel.Name = "m_GradeLabel";
    this.m_GradeLabel.Size = new Size(39, 13);
    this.m_GradeLabel.TabIndex = 14;
    this.m_GradeLabel.Text = "Grade:";
    this.m_GradeTextBox.Enabled = false;
    this.m_GradeTextBox.Location = new Point(388, 160 /*0xA0*/);
    this.m_GradeTextBox.Name = "m_GradeTextBox";
    this.m_GradeTextBox.Size = new Size(100, 20);
    this.m_GradeTextBox.TabIndex = 15;
    this.m_GradeTextBox.KeyDown += new KeyEventHandler(this.OnGradeKeyDown);
    this.m_GradeTextBox.Leave += new EventHandler(this.OnGradeTextBoxLeave);
    this.m_GradeRadioButton.AutoSize = true;
    this.m_GradeRadioButton.Location = new Point(12, 137);
    this.m_GradeRadioButton.Name = "m_GradeRadioButton";
    this.m_GradeRadioButton.Size = new Size(54, 17);
    this.m_GradeRadioButton.TabIndex = 11;
    this.m_GradeRadioButton.Text = "&Grade";
    this.m_GradeRadioButton.UseVisualStyleBackColor = true;
    this.m_GradeRadioButton.CheckedChanged += new EventHandler(this.OnElevationSelectionOptionChecked);
    this.m_GradeBeginningElevationLabel.AutoSize = true;
    this.m_GradeBeginningElevationLabel.Enabled = false;
    this.m_GradeBeginningElevationLabel.Location = new Point(30, 163);
    this.m_GradeBeginningElevationLabel.Name = "m_GradeBeginningElevationLabel";
    this.m_GradeBeginningElevationLabel.Size = new Size(104, 13);
    this.m_GradeBeginningElevationLabel.TabIndex = 12;
    this.m_GradeBeginningElevationLabel.Text = "Beginning Elevation:";
    this.m_GradeBeginningElevationTextBox.Enabled = false;
    this.m_GradeBeginningElevationTextBox.Location = new Point(156, 160 /*0xA0*/);
    this.m_GradeBeginningElevationTextBox.Name = "m_GradeBeginningElevationTextBox";
    this.m_GradeBeginningElevationTextBox.Size = new Size(100, 20);
    this.m_GradeBeginningElevationTextBox.TabIndex = 13;
    this.m_GradeBeginningElevationTextBox.KeyDown += new KeyEventHandler(this.OnGradeBeginningElevationKeyDown);
    this.m_GradeBeginningElevationTextBox.Leave += new EventHandler(this.OnGradeBeginningElevationTextBoxLeave);
    this.m_GradeBeginningElevationTextBox.Enter += new EventHandler(this.OnElevationTextBoxEnter);
    this.m_GradeBeginningElevationTextBox.LostFocus += new EventHandler(this.OnElevationTextBoxLostFocus);
    this.m_LinearIntervalLabel.AutoSize = true;
    this.m_LinearIntervalLabel.Location = new Point(9, 15);
    this.m_LinearIntervalLabel.Name = "m_LinearIntervalLabel";
    this.m_LinearIntervalLabel.Size = new Size(104, 13);
    this.m_LinearIntervalLabel.TabIndex = 0;
    this.m_LinearIntervalLabel.Text = "Linear Point Interval:";
    this.m_LinearIntervalTextBox.Location = new Point(156, 12);
    this.m_LinearIntervalTextBox.Name = "m_LinearIntervalTextBox";
    this.m_LinearIntervalTextBox.Size = new Size(100, 20);
    this.m_LinearIntervalTextBox.TabIndex = 1;
    this.m_LinearIntervalTextBox.KeyDown += new KeyEventHandler(this.OnLinearIntervalKeyDown);
    this.m_LinearIntervalTextBox.Leave += new EventHandler(this.OnLinearIntervalTextBoxLeave);
    this.m_PickInRevitButton.Enabled = false;
    this.m_PickInRevitButton.Image = (Image) componentResourceManager.GetObject("m_PickInRevitButton.Image");
    this.m_PickInRevitButton.Location = new Point(464, 12);
    this.m_PickInRevitButton.Name = "m_PickInRevitButton";
    this.m_PickInRevitButton.Size = new Size(24, 20);
    this.m_PickInRevitButton.TabIndex = 2;
    this.m_PickInRevitButton.TabStop = false;
    this.m_PickInRevitButton.UseVisualStyleBackColor = true;
    this.m_PickInRevitButton.Click += new EventHandler(this.OnPickInRevitButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(500, 335);
    this.Controls.Add((Control) this.m_PickInRevitButton);
    this.Controls.Add((Control) this.m_LinearIntervalLabel);
    this.Controls.Add((Control) this.m_LinearIntervalTextBox);
    this.Controls.Add((Control) this.m_GradeLabel);
    this.Controls.Add((Control) this.m_GradeTextBox);
    this.Controls.Add((Control) this.m_GradeRadioButton);
    this.Controls.Add((Control) this.m_GradeBeginningElevationLabel);
    this.Controls.Add((Control) this.m_GradeBeginningElevationTextBox);
    this.Controls.Add((Control) this.m_EndingElevationRangeLabel);
    this.Controls.Add((Control) this.m_EndingElevationRangeTextBox);
    this.Controls.Add((Control) this.m_HostLineSelectionPanel);
    this.Controls.Add((Control) this.m_UsePanel);
    this.Controls.Add((Control) this.m_ElevationRangeRadioButton);
    this.Controls.Add((Control) this.m_RelativeElevationLabel);
    this.Controls.Add((Control) this.m_RelativeElevationTextBox);
    this.Controls.Add((Control) this.m_RelativeElevationRadioButton);
    this.Controls.Add((Control) this.m_RadiusLabel);
    this.Controls.Add((Control) this.m_RadiusTextBox);
    this.Controls.Add((Control) this.m_CreateCopyCheckBox);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.Controls.Add((Control) this.m_BeginningElevationRangeLabel);
    this.Controls.Add((Control) this.m_BeginningElevationRangeTextBox);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (LocateSiteFeatureLineComponentForm);
    this.Text = "Locate Feature Line";
    this.Shown += new EventHandler(this.OnLocateSiteFeatureLineComponentFormShown);
    this.FormClosing += new FormClosingEventHandler(this.OnLocateSiteComponentClosing);
    this.m_MoveablePanel.ResumeLayout(false);
    this.m_UsePanel.ResumeLayout(false);
    this.m_UsePanel.PerformLayout();
    this.m_HostLineSelectionPanel.ResumeLayout(false);
    this.m_HostLineSelectionPanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
