﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FenceCommon
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class FenceCommon
{
  public static bool PlaceLegList(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _CurrentLeg)
  {
    if (_PlacementSettings.ExistingElementChecked && !RevitUtility.EvaluateLeg(_Document, _PlacementSettings.TransactionContainer, _PlacementSettings.Width, ref _CurrentLeg))
      return false;
    _PlacementSettings.IsReverse = _CurrentLeg.IsReverse;
    if (_PlacementSettings.SetbackSpacing == 0.0)
    {
      FenceCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _CurrentLeg);
    }
    else
    {
      Eps_Leg ppOffsetLegList1 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 1, ref ppOffsetLegList1, true);
      Eps_Leg ppOffsetLegList2 = new Eps_Leg();
      RevitGeometry.OffsetLegList(_CurrentLeg, _PlacementSettings.SetbackSpacing, 2, ref ppOffsetLegList2, true);
      _PlacementSettings.TransactionContainer.BeginTransaction();
      ModelCurveArray modelCurveArray1 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList1);
      ModelCurveArray modelCurveArray2 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList2);
      _PlacementSettings.TransactionContainer.EndTransaction();
      _Document.Regenerate();
      bool _UseRightSide = true;
      bool flag = RevitUtility.PickSideLeg(_Document, _CurrentLeg, ref _UseRightSide);
      ElementSet elm_set = new ElementSet();
      foreach (ModelCurve modelCurve in modelCurveArray1)
        elm_set.Insert((Element) modelCurve);
      foreach (ModelCurve modelCurve in modelCurveArray2)
        elm_set.Insert((Element) modelCurve);
      _PlacementSettings.TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      _PlacementSettings.TransactionContainer.EndTransaction();
      if (!flag)
        return false;
      _PlacementSettings.UseRightSide = _UseRightSide;
      if (_UseRightSide)
        FenceCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, ppOffsetLegList1);
      else
        FenceCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, ppOffsetLegList2);
    }
    if (_PlacementSettings.DeleteExistingChecked && _CurrentLeg.ElementSet != null && _CurrentLeg.ElementSet.Size > 0)
    {
      _PlacementSettings.TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_CurrentLeg.ElementSet));
      _PlacementSettings.TransactionContainer.EndTransaction();
    }
    return true;
  }

  public static void PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line)
  {
    FenceCommon.PlaceCenterRowOnLine(_Document, _PlacementSettings, _Element, _Line, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Line _Line,
    List<FamilyInstance> _ExistingFenceList)
  {
    Eps_Point _NewPnt1 = new Eps_Point();
    Eps_Point epsPoint = new Eps_Point();
    Eps_Point _NewPnt2 = new Eps_Point();
    double _dDirection = 0.0;
    double _dDistance1 = 0.0;
    double width = _PlacementSettings.Width;
    double _dElevation = 0.0;
    double _dDistance2 = 0.0;
    if (_Line == null)
      return;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDistance1);
    List<Eps_Point> _PointList = new List<Eps_Point>();
    FamilyInstance familyInstance1 = (FamilyInstance) null;
    double _dAngle = 0.0;
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag2 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlacementSettings.GenericModelIDList[0];
    }
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(_dDistance1 - _PlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressPlacingFenceMessage");
    Eps_Point startPnt = _Line.StartPnt;
    double startingDistance;
    for (startingDistance = _PlacementSettings.StartingDistance; startingDistance <= _dDistance1; startingDistance += width)
    {
      if (startingDistance <= _dDistance1 - width)
      {
        EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, startingDistance + width / 2.0, ref _NewPnt1);
        if (!RevitUtility.IsPointInPointList(_NewPnt1, _PointList))
        {
          if (_Element != null && flag1 && flag2)
          {
            flag2 = false;
            if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
            {
              keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
            }
            else
            {
              int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
              flag1 = false;
            }
          }
          _PointList.Add(_NewPnt1);
          Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_NewPnt1, _PlacementSettings.SurfaceList, ref _dElevation);
          _NewPnt1.z = _dElevation;
          EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, _dDirection, width / 2.0, ref startPnt);
          RevitUtility.GetSurfaceContainingPoint(startPnt, _PlacementSettings.SurfaceList, ref _dElevation);
          startPnt.z = _dElevation;
          EPShared.eplGeoE_CalcPolarToXY(startPnt, _dDirection + Math.PI, width, ref _NewPnt2);
          RevitUtility.GetSurfaceContainingPoint(_NewPnt2, _PlacementSettings.SurfaceList, ref _dElevation);
          _NewPnt2.z = _dElevation;
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt2, startPnt, ref _dDistance2);
          double _dVertical = startPnt.z - _NewPnt2.z;
          double direction = RevitGeometry.CalculateDirection(_dDistance2, _dVertical);
          if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
          {
            _PlacementSettings.TransactionContainer.EndTransaction();
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
          FamilyInstance familyInstance2;
          if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
          {
            familyInstance2 = _ExistingFenceList[0];
            if (((Element) familyInstance2).Location is LocationPoint location)
            {
              if (!EPShared.eplGeoE_ArePntsDuplicates3D(_NewPnt1, new Eps_Point(location.Point)))
              {
                XYZ xyz = new XYZ(_NewPnt1.XYZ.X - location.Point.X, _NewPnt1.XYZ.Y - location.Point.Y, 0.0);
                ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance2).Id, xyz);
              }
              _dAngle = location.Rotation;
            }
            _ExistingFenceList.RemoveAt(0);
          }
          else
          {
            EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
            familyInstance2 = RevitUtility.NewFamilyInstance(_Document, _NewPnt1.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
            _PlacementSettings.TransactionContainer = transactionContainer;
          }
          familyInstance1 = familyInstance2;
          if (Math.Abs(_PlacementSettings.Height) > 0.0)
          {
            Parameter parameter = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
            if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
              parameter.Set(_PlacementSettings.Height);
          }
          if (Math.Abs(_PlacementSettings.Width) > 0.0)
          {
            Parameter parameter = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilySpanParameter);
            if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Width))
              parameter.Set(_PlacementSettings.Width);
          }
          XYZ xyz1 = new XYZ(_NewPnt1.x, _NewPnt1.y, _NewPnt1.z + 1.0);
          Line bound = Line.CreateBound(_NewPnt1.XYZ, xyz1);
          Parameter parameter1 = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceRightVisiability);
          Parameter parameter2 = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceLeftVisiability);
          bool flag3 = false;
          bool flag4 = false;
          if (direction < 0.0)
          {
            if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance2).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI - _dAngle));
            flag3 = true;
          }
          else
          {
            if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance2).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
            flag4 = true;
          }
          if (parameter1 != null && parameter2 != null)
          {
            parameter1.Set(Convert.ToInt32(flag3));
            parameter2.Set(Convert.ToInt32(flag4));
          }
          double num1 = Math.Abs(direction);
          ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num1);
          if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
          {
            Parameter parameter3 = ((Element) familyInstance2).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
            if (parameter3 != null)
              parameter3.Set(keyValuePair.Value);
            else
              flag1 = false;
          }
        }
        else
          familyInstance1 = (FamilyInstance) null;
        progressBarForm.UpdateProgressBar(Convert.ToInt32(width));
        _dAngle = 0.0;
      }
    }
    double num2 = _dDistance1 - (startingDistance - width);
    if (RevitDefines.GT(num2, 0.001))
    {
      EPShared.eplGeoE_CalcPolarToXY(startPnt, _dDirection, num2 / 2.0, ref _NewPnt1);
      if (!RevitUtility.IsPointInPointList(_NewPnt1, _PointList))
      {
        if (_Element != null && flag1 && flag2)
        {
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
          }
          else
          {
            int num3 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag1 = false;
          }
        }
        _PointList.Add(_NewPnt1);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_NewPnt1, _PlacementSettings.SurfaceList, ref _dElevation);
        _NewPnt1.z = _dElevation;
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, _dDirection, (startingDistance - _dDistance1) / 2.0, ref startPnt);
        RevitUtility.GetSurfaceContainingPoint(startPnt, _PlacementSettings.SurfaceList, ref _dElevation);
        startPnt.z = _dElevation;
        EPShared.eplGeoE_CalcPolarToXY(startPnt, _dDirection + Math.PI, width, ref _NewPnt2);
        RevitUtility.GetSurfaceContainingPoint(_NewPnt2, _PlacementSettings.SurfaceList, ref _dElevation);
        _NewPnt2.z = _dElevation;
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt2, startPnt, ref _dDistance2);
        double _dVertical = startPnt.z - _NewPnt2.z;
        double direction = RevitGeometry.CalculateDirection(_dDistance2, _dVertical);
        if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
        {
          _PlacementSettings.TransactionContainer.EndTransaction();
          int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return;
        }
        FamilyInstance familyInstance3;
        if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
        {
          familyInstance3 = _ExistingFenceList[0];
          if (((Element) familyInstance3).Location is LocationPoint location)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates3D(_NewPnt1, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_NewPnt1.XYZ.X - location.Point.X, _NewPnt1.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance3).Id, xyz);
            }
            _dAngle = location.Rotation;
          }
          _ExistingFenceList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          familyInstance3 = RevitUtility.NewFamilyInstance(_Document, _NewPnt1.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
        }
        if (Math.Abs(_PlacementSettings.Height) > 0.0)
        {
          Parameter parameter = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
          if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
            parameter.Set(_PlacementSettings.Height);
        }
        if (Math.Abs(_PlacementSettings.Width) > 0.0)
        {
          Parameter parameter = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilySpanParameter);
          if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), num2))
            parameter.Set(num2);
        }
        XYZ xyz2 = new XYZ(_NewPnt1.x, _NewPnt1.y, _NewPnt1.z + 1.0);
        Line bound = Line.CreateBound(_NewPnt1.XYZ, xyz2);
        Parameter parameter4 = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceRightVisiability);
        Parameter parameter5 = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceLeftVisiability);
        bool flag5 = true;
        bool flag6 = true;
        if (direction < 0.0)
        {
          if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
            ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance3).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI - _dAngle));
        }
        else if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dDirection), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
          ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance3).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dDirection - _dAngle));
        if (parameter4 != null && parameter5 != null)
        {
          parameter4.Set(Convert.ToInt32(flag5));
          parameter5.Set(Convert.ToInt32(flag6));
        }
        double num5 = Math.Abs(direction);
        ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num5);
        if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
          ((Element) familyInstance3).LookupParameter(RevitParameters.PlacementIDFamilyParameter)?.Set(keyValuePair.Value);
      }
    }
    else if (familyInstance1 != null)
    {
      Parameter parameter6 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceRightVisiability);
      Parameter parameter7 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceLeftVisiability);
      if (parameter6 != null && parameter7 != null)
      {
        parameter6.Set(Convert.ToInt32(true));
        parameter7.Set(Convert.ToInt32(true));
      }
    }
    if (_ExistingFenceList != null && _ExistingFenceList.Count > 0)
    {
      for (int index = 0; index < _ExistingFenceList.Count; ++index)
        _Document.Delete(((Element) _ExistingFenceList[index]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceCenterRowOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _Arc)
  {
    FenceCommon.PlaceCenterRowOnArc(_Document, _PlacementSettings, _Element, _Arc, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnArc(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element,
    Eps_Arc _Arc,
    List<FamilyInstance> _ExistingFenceList)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    Eps_Point epsPoint = new Eps_Point();
    Eps_Point _NewPnt = new Eps_Point();
    double width = _PlacementSettings.Width;
    double _dElevation = 0.0;
    if (_Arc == null)
      return;
    double num1 = _Arc.Radius * _Arc.Delta;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    FamilyInstance familyInstance1 = (FamilyInstance) null;
    double _dAngle = 0.0;
    bool flag1 = !_PlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag2 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlacementSettings.GenericModelIDList[0];
    }
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(num1 - _PlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressPlacingFenceMessage");
    Eps_Point startPnt = _Arc.StartPnt;
    double startingDistance;
    for (startingDistance = _PlacementSettings.StartingDistance; startingDistance <= num1; startingDistance += width)
    {
      if (startingDistance <= num1 - width)
      {
        EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, startingDistance + width / 2.0, 0.0, ref _StaOffPnt);
        if (!RevitUtility.IsPointInPointList(_StaOffPnt, _PointList))
        {
          if (_Element != null && flag1 && flag2)
          {
            flag2 = false;
            if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
            {
              keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
            }
            else
            {
              int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
              flag1 = false;
            }
          }
          _PointList.Add(_StaOffPnt);
          Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_StaOffPnt, _PlacementSettings.SurfaceList, ref _dElevation);
          _StaOffPnt.z = _dElevation;
          double _dTangentDir = 0.0;
          double _dDistance = 0.0;
          EPShared.eplGeoE_CalcTangentDirOfArc(_StaOffPnt, _Arc.RadiusPnt, _Arc.Direction, ref _dTangentDir);
          EPShared.eplGeoE_CalcPolarToXY(_StaOffPnt, _dTangentDir, width / 2.0, ref startPnt);
          RevitUtility.GetSurfaceContainingPoint(startPnt, _PlacementSettings.SurfaceList, ref _dElevation);
          startPnt.z = _dElevation;
          EPShared.eplGeoE_CalcPolarToXY(startPnt, _dTangentDir + Math.PI, width, ref _NewPnt);
          RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList, ref _dElevation);
          _NewPnt.z = _dElevation;
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, startPnt, ref _dDistance);
          double _dVertical = startPnt.z - _NewPnt.z;
          double direction = RevitGeometry.CalculateDirection(_dDistance, _dVertical);
          if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
          {
            _PlacementSettings.TransactionContainer.EndTransaction();
            int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
          FamilyInstance familyInstance2;
          if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
          {
            familyInstance2 = _ExistingFenceList[0];
            if (((Element) familyInstance2).Location is LocationPoint location)
            {
              if (!EPShared.eplGeoE_ArePntsDuplicates3D(_StaOffPnt, new Eps_Point(location.Point)))
              {
                XYZ xyz = new XYZ(_StaOffPnt.XYZ.X - location.Point.X, _StaOffPnt.XYZ.Y - location.Point.Y, 0.0);
                ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance2).Id, xyz);
              }
              _dAngle = location.Rotation;
            }
            _ExistingFenceList.RemoveAt(0);
          }
          else
          {
            EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
            familyInstance2 = RevitUtility.NewFamilyInstance(_Document, _StaOffPnt.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
            _PlacementSettings.TransactionContainer = transactionContainer;
          }
          familyInstance1 = familyInstance2;
          if (Math.Abs(_PlacementSettings.Height) > 0.0)
          {
            Parameter parameter = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
            if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
              parameter.Set(_PlacementSettings.Height);
          }
          if (Math.Abs(_PlacementSettings.Width) > 0.0)
          {
            Parameter parameter = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilySpanParameter);
            if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Width))
              parameter.Set(_PlacementSettings.Width);
          }
          XYZ xyz1 = new XYZ(_StaOffPnt.x, _StaOffPnt.y, _StaOffPnt.z + 1.0);
          Line bound = Line.CreateBound(_StaOffPnt.XYZ, xyz1);
          Parameter parameter1 = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceRightVisiability);
          Parameter parameter2 = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceLeftVisiability);
          bool flag3 = false;
          bool flag4 = false;
          if (direction < 0.0)
          {
            if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dTangentDir + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance2).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dTangentDir + Math.PI - _dAngle));
            flag3 = true;
          }
          else
          {
            if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dTangentDir), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
              ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance2).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dTangentDir - _dAngle));
            flag4 = true;
          }
          if (parameter1 != null && parameter2 != null)
          {
            parameter1.Set(Convert.ToInt32(flag3));
            parameter2.Set(Convert.ToInt32(flag4));
          }
          double num4 = Math.Abs(direction);
          ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num4);
          if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
          {
            Parameter parameter3 = ((Element) familyInstance2).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
            if (parameter3 != null)
              parameter3.Set(keyValuePair.Value);
            else
              flag1 = false;
          }
        }
        else
          familyInstance1 = (FamilyInstance) null;
        progressBarForm.UpdateProgressBar(Convert.ToInt32(width));
        _dAngle = 0.0;
      }
    }
    double num5 = num1 - (startingDistance - width);
    if (RevitDefines.GT(num5, 0.001))
    {
      EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, num1 - num5 / 2.0, 0.0, ref _StaOffPnt);
      if (!RevitUtility.IsPointInPointList(_StaOffPnt, _PointList))
      {
        if (_Element != null && flag1 && flag2)
        {
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Element);
          }
          else
          {
            int num6 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag1 = false;
          }
        }
        _PointList.Add(_StaOffPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_StaOffPnt, _PlacementSettings.SurfaceList, ref _dElevation);
        _StaOffPnt.z = _dElevation;
        double _dTangentDir = 0.0;
        double _dDistance = 0.0;
        EPShared.eplGeoE_CalcTangentDirOfArc(_StaOffPnt, _Arc.RadiusPnt, _Arc.Direction, ref _dTangentDir);
        EPShared.eplGeoE_CalcPolarToXY(_StaOffPnt, _dTangentDir, num5 / 2.0, ref startPnt);
        RevitUtility.GetSurfaceContainingPoint(startPnt, _PlacementSettings.SurfaceList, ref _dElevation);
        startPnt.z = _dElevation;
        EPShared.eplGeoE_CalcPolarToXY(startPnt, _dTangentDir + Math.PI, width, ref _NewPnt);
        RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList, ref _dElevation);
        _NewPnt.z = _dElevation;
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, startPnt, ref _dDistance);
        double _dVertical = startPnt.z - _NewPnt.z;
        double direction = RevitGeometry.CalculateDirection(_dDistance, _dVertical);
        if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
        {
          _PlacementSettings.TransactionContainer.EndTransaction();
          int num7 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return;
        }
        FamilyInstance familyInstance3;
        if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
        {
          familyInstance3 = _ExistingFenceList[0];
          if (((Element) familyInstance3).Location is LocationPoint location)
          {
            if (!EPShared.eplGeoE_ArePntsDuplicates3D(_StaOffPnt, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_StaOffPnt.XYZ.X - location.Point.X, _StaOffPnt.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance3).Id, xyz);
            }
            _dAngle = location.Rotation;
          }
          _ExistingFenceList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          familyInstance3 = RevitUtility.NewFamilyInstance(_Document, _StaOffPnt.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
        }
        if (Math.Abs(_PlacementSettings.Height) > 0.0)
        {
          Parameter parameter = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
          if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
            parameter.Set(_PlacementSettings.Height);
        }
        if (Math.Abs(_PlacementSettings.Width) > 0.0)
        {
          Parameter parameter = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilySpanParameter);
          if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), num5))
            parameter.Set(num5);
        }
        XYZ xyz2 = new XYZ(_StaOffPnt.x, _StaOffPnt.y, _StaOffPnt.z + 1.0);
        Line bound = Line.CreateBound(_StaOffPnt.XYZ, xyz2);
        Parameter parameter4 = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceRightVisiability);
        Parameter parameter5 = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceLeftVisiability);
        bool flag5 = true;
        bool flag6 = true;
        if (direction < 0.0)
        {
          if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dTangentDir + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
            ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance3).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dTangentDir + Math.PI - _dAngle));
        }
        else if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(_dTangentDir), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
          ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance3).Id, bound, EPShared.eplGeoE_NormalizeRadians(_dTangentDir - _dAngle));
        if (parameter4 != null && parameter5 != null)
        {
          parameter4.Set(Convert.ToInt32(flag5));
          parameter5.Set(Convert.ToInt32(flag6));
        }
        double num8 = Math.Abs(direction);
        ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num8);
        if (_Element != null && flag1 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
          ((Element) familyInstance3).LookupParameter(RevitParameters.PlacementIDFamilyParameter)?.Set(keyValuePair.Value);
      }
    }
    else if (familyInstance1 != null)
    {
      Parameter parameter6 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceRightVisiability);
      Parameter parameter7 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceLeftVisiability);
      if (parameter6 != null && parameter7 != null)
      {
        parameter6.Set(Convert.ToInt32(true));
        parameter7.Set(Convert.ToInt32(true));
      }
    }
    if (_ExistingFenceList != null && _ExistingFenceList.Count > 0)
    {
      for (int index = 0; index < _ExistingFenceList.Count; ++index)
        _Document.Delete(((Element) _ExistingFenceList[index]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg)
  {
    FenceCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _Leg, _Leg.ElementList, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg,
    List<FamilyInstance> _MovePlantList)
  {
    FenceCommon.PlaceCenterRowOnLeg(_Document, _PlacementSettings, _Leg, _Leg.ElementList, _MovePlantList);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Eps_Leg _Leg,
    List<Element> _OrigLegElementSet,
    List<FamilyInstance> _ExistingFenceList)
  {
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point _NewPnt = new Eps_Point();
    double _dDistance1 = 0.0;
    double num1 = 0.0;
    double num2 = _PlacementSettings.StartingDistance;
    double width = _PlacementSettings.Width;
    double _dElevation = 0.0;
    double _dDistance2 = 0.0;
    if (_Leg == null)
      return;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    FamilyInstance familyInstance1 = (FamilyInstance) null;
    double _dAngle = 0.0;
    bool flag1 = false;
    bool flag2 = !_PlacementSettings.DeleteExistingChecked;
    bool flag3 = false;
    int index1 = 0;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.GenericModelIDList == null)
    {
      flag3 = true;
      _PlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlacementSettings.GenericModelIDList;
    }
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(RevitGeometry.eplGeoE_CalcLegListLength(_Leg) - num2);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressPlacingFenceMessage");
    Eps_Point legStartPnt = _Leg.LegStartPnt;
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      KeyValuePair<string, string> keyValuePair;
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref num1);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance1);
        if (num2 > _dDistance1)
        {
          num2 -= _dDistance1;
        }
        else
        {
          double num3;
          for (num3 = num2; num3 <= _dDistance1; num3 += width)
          {
            if (num3 <= _dDistance1 - width)
            {
              EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, num1, num3 + width / 2.0, ref epsPoint1);
              if (!RevitUtility.IsPointInPointList(epsPoint1, _PointList))
              {
                if (epsLeg.Element != null && flag2 && flag3)
                {
                  flag3 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Leg.ElementList);
                  }
                  else
                  {
                    int num4 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag2 = false;
                  }
                  if (index1 < keyValuePairList.Count)
                  {
                    keyValuePair = keyValuePairList[index1];
                    if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                    {
                      flag1 = true;
                    }
                    else
                    {
                      for (int index2 = 0; index2 < keyValuePairList.Count; ++index2)
                      {
                        keyValuePair = keyValuePairList[index2];
                        if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                        {
                          index1 = index2;
                          flag1 = true;
                          break;
                        }
                      }
                    }
                  }
                }
                _PointList.Add(epsPoint1);
                Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint1, _PlacementSettings.SurfaceList, ref _dElevation);
                epsPoint1.z = _dElevation;
                EPShared.eplGeoE_CalcPolarToXY(epsPoint1, num1, width / 2.0, ref legStartPnt);
                RevitUtility.GetSurfaceContainingPoint(legStartPnt, _PlacementSettings.SurfaceList, ref _dElevation);
                legStartPnt.z = _dElevation;
                EPShared.eplGeoE_CalcPolarToXY(legStartPnt, num1 + Math.PI, width, ref _NewPnt);
                RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList, ref _dElevation);
                _NewPnt.z = _dElevation;
                EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, legStartPnt, ref _dDistance2);
                double _dVertical = legStartPnt.z - _NewPnt.z;
                double direction = RevitGeometry.CalculateDirection(_dDistance2, _dVertical);
                if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
                {
                  _PlacementSettings.TransactionContainer.EndTransaction();
                  int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                  return;
                }
                FamilyInstance familyInstance2;
                if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
                {
                  familyInstance2 = _ExistingFenceList[0];
                  if (((Element) familyInstance2).Location is LocationPoint location)
                  {
                    if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, new Eps_Point(location.Point)))
                    {
                      XYZ xyz = new XYZ(epsPoint1.XYZ.X - location.Point.X, epsPoint1.XYZ.Y - location.Point.Y, 0.0);
                      ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance2).Id, xyz);
                    }
                    _dAngle = location.Rotation;
                  }
                  _ExistingFenceList.RemoveAt(0);
                }
                else
                {
                  EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                  familyInstance2 = RevitUtility.NewFamilyInstance(_Document, epsPoint1.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                  _PlacementSettings.TransactionContainer = transactionContainer;
                }
                familyInstance1 = familyInstance2;
                if (Math.Abs(_PlacementSettings.Height) > 0.0)
                {
                  Parameter parameter = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
                  if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
                    parameter.Set(_PlacementSettings.Height);
                }
                if (Math.Abs(_PlacementSettings.Width) > 0.0)
                {
                  Parameter parameter = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilySpanParameter);
                  if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Width))
                    parameter.Set(_PlacementSettings.Width);
                }
                XYZ xyz1 = new XYZ(epsPoint1.x, epsPoint1.y, epsPoint1.z + 1.0);
                Line bound = Line.CreateBound(epsPoint1.XYZ, xyz1);
                Parameter parameter1 = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceRightVisiability);
                Parameter parameter2 = ((Element) familyInstance2).LookupParameter(RevitParameters.FenceLeftVisiability);
                bool flag4 = false;
                bool flag5 = false;
                if (direction < 0.0)
                {
                  if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                    ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance2).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI - _dAngle));
                  flag4 = true;
                }
                else
                {
                  if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                    ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance2).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI - _dAngle));
                  flag5 = true;
                }
                if (parameter1 != null && parameter2 != null)
                {
                  parameter1.Set(Convert.ToInt32(flag4));
                  parameter2.Set(Convert.ToInt32(flag5));
                }
                double num6 = Math.Abs(direction);
                ((Element) familyInstance2).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num6);
                if (epsLeg.Element != null && flag2 && flag1)
                {
                  Parameter parameter3 = ((Element) familyInstance2).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                  if (parameter3 != null)
                  {
                    Parameter parameter4 = parameter3;
                    keyValuePair = keyValuePairList[index1];
                    string str = keyValuePair.Value;
                    parameter4.Set(str);
                  }
                  else
                    flag2 = false;
                }
              }
              else
                familyInstance1 = (FamilyInstance) null;
              progressBarForm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Width));
              _dAngle = 0.0;
            }
          }
          double num7 = _dDistance1 - (num3 - width);
          if (RevitDefines.GT(num7, 0.001))
          {
            EPShared.eplGeoE_CalcPolarToXY(legStartPnt, num1, num7 / 2.0, ref epsPoint1);
            if (!RevitUtility.IsPointInPointList(epsPoint1, _PointList))
            {
              if (epsLeg.Element != null && flag2 && flag3)
              {
                flag3 = false;
                if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                {
                  keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Leg.ElementList);
                }
                else
                {
                  int num8 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                  flag2 = false;
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag1 = true;
                  }
                  else
                  {
                    for (int index3 = 0; index3 < keyValuePairList.Count; ++index3)
                    {
                      keyValuePair = keyValuePairList[index3];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index3;
                        flag1 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint1);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint1, _PlacementSettings.SurfaceList, ref _dElevation);
              epsPoint1.z = _dElevation;
              EPShared.eplGeoE_CalcPolarToXY(epsPoint1, num1, num7 / 2.0, ref legStartPnt);
              RevitUtility.GetSurfaceContainingPoint(legStartPnt, _PlacementSettings.SurfaceList, ref _dElevation);
              legStartPnt.z = _dElevation;
              EPShared.eplGeoE_CalcPolarToXY(legStartPnt, num1 + Math.PI, width, ref _NewPnt);
              RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList, ref _dElevation);
              _NewPnt.z = _dElevation;
              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, legStartPnt, ref _dDistance2);
              double _dVertical = legStartPnt.z - _NewPnt.z;
              double direction = RevitGeometry.CalculateDirection(_dDistance2, _dVertical);
              if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
              {
                _PlacementSettings.TransactionContainer.EndTransaction();
                int num9 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return;
              }
              FamilyInstance familyInstance3;
              if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
              {
                familyInstance3 = _ExistingFenceList[0];
                if (((Element) familyInstance3).Location is LocationPoint location)
                {
                  if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, new Eps_Point(location.Point)))
                  {
                    XYZ xyz = new XYZ(epsPoint1.XYZ.X - location.Point.X, epsPoint1.XYZ.Y - location.Point.Y, 0.0);
                    ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance3).Id, xyz);
                  }
                  _dAngle = location.Rotation;
                }
                _ExistingFenceList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                familyInstance3 = RevitUtility.NewFamilyInstance(_Document, epsPoint1.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlacementSettings.TransactionContainer = transactionContainer;
              }
              if (Math.Abs(_PlacementSettings.Height) > 0.0)
              {
                Parameter parameter = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
                if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
                  parameter.Set(_PlacementSettings.Height);
              }
              if (Math.Abs(_PlacementSettings.Width) > 0.0)
              {
                Parameter parameter = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilySpanParameter);
                if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), num7))
                  parameter.Set(num7);
              }
              XYZ xyz2 = new XYZ(epsPoint1.x, epsPoint1.y, epsPoint1.z + 1.0);
              Line bound = Line.CreateBound(epsPoint1.XYZ, xyz2);
              Parameter parameter5 = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceRightVisiability);
              Parameter parameter6 = ((Element) familyInstance3).LookupParameter(RevitParameters.FenceLeftVisiability);
              bool flag6 = true;
              bool flag7 = true;
              if (direction < 0.0)
              {
                if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                  ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance3).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI - _dAngle));
              }
              else if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance3).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
              if (parameter5 != null && parameter6 != null)
              {
                parameter5.Set(Convert.ToInt32(flag6));
                parameter6.Set(Convert.ToInt32(flag7));
              }
              double num10 = Math.Abs(direction);
              ((Element) familyInstance3).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num10);
              if (epsLeg.Element != null && flag2 && flag1)
              {
                Parameter parameter7 = ((Element) familyInstance3).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter7 != null)
                {
                  Parameter parameter8 = parameter7;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter8.Set(str);
                }
                else
                  flag2 = false;
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Width));
            _dAngle = 0.0;
          }
          else
          {
            if (familyInstance1 != null)
            {
              Parameter parameter9 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceRightVisiability);
              Parameter parameter10 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceLeftVisiability);
              if (parameter9 != null && parameter10 != null)
              {
                parameter9.Set(Convert.ToInt32(true));
                parameter10.Set(Convert.ToInt32(true));
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Width));
            _dAngle = 0.0;
          }
          num2 = 0.0;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance1 = epsLeg.Arc.Radius * epsLeg.Arc.Delta;
        if (num2 > _dDistance1)
        {
          num2 -= _dDistance1;
        }
        else
        {
          double num11;
          for (num11 = num2; num11 <= _dDistance1; num11 += width)
          {
            if (num11 <= _dDistance1 - width)
            {
              EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, num11 + width / 2.0, 0.0, ref epsPoint1);
              if (!RevitUtility.IsPointInPointList(epsPoint1, _PointList))
              {
                if (epsLeg.Element != null && flag2 && flag3)
                {
                  flag3 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Leg.ElementList);
                  }
                  else
                  {
                    int num12 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag2 = false;
                  }
                  if (index1 < keyValuePairList.Count)
                  {
                    keyValuePair = keyValuePairList[index1];
                    if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                    {
                      flag1 = true;
                    }
                    else
                    {
                      for (int index4 = 0; index4 < keyValuePairList.Count; ++index4)
                      {
                        keyValuePair = keyValuePairList[index4];
                        if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                        {
                          index1 = index4;
                          flag1 = true;
                          break;
                        }
                      }
                    }
                  }
                }
                _PointList.Add(epsPoint1);
                Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint1, _PlacementSettings.SurfaceList, ref _dElevation);
                epsPoint1.z = _dElevation;
                EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint1, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Direction, ref num1);
                EPShared.eplGeoE_CalcPolarToXY(epsPoint1, num1, width / 2.0, ref legStartPnt);
                RevitUtility.GetSurfaceContainingPoint(legStartPnt, _PlacementSettings.SurfaceList, ref _dElevation);
                legStartPnt.z = _dElevation;
                EPShared.eplGeoE_CalcPolarToXY(legStartPnt, num1 + Math.PI, width, ref _NewPnt);
                RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList, ref _dElevation);
                _NewPnt.z = _dElevation;
                EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, legStartPnt, ref _dDistance2);
                double _dVertical = legStartPnt.z - _NewPnt.z;
                double direction = RevitGeometry.CalculateDirection(_dDistance2, _dVertical);
                if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
                {
                  _PlacementSettings.TransactionContainer.EndTransaction();
                  int num13 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                  return;
                }
                FamilyInstance familyInstance4;
                if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
                {
                  familyInstance4 = _ExistingFenceList[0];
                  if (((Element) familyInstance4).Location is LocationPoint location)
                  {
                    if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, new Eps_Point(location.Point)))
                    {
                      XYZ xyz = new XYZ(epsPoint1.XYZ.X - location.Point.X, epsPoint1.XYZ.Y - location.Point.Y, 0.0);
                      ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance4).Id, xyz);
                    }
                    _dAngle = location.Rotation;
                  }
                  _ExistingFenceList.RemoveAt(0);
                }
                else
                {
                  EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                  familyInstance4 = RevitUtility.NewFamilyInstance(_Document, epsPoint1.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                  _PlacementSettings.TransactionContainer = transactionContainer;
                }
                familyInstance1 = familyInstance4;
                if (Math.Abs(_PlacementSettings.Height) > 0.0)
                {
                  Parameter parameter = ((Element) familyInstance4).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
                  if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
                    parameter.Set(_PlacementSettings.Height);
                }
                if (Math.Abs(_PlacementSettings.Width) > 0.0)
                {
                  Parameter parameter = ((Element) familyInstance4).LookupParameter(RevitParameters.FenceFamilySpanParameter);
                  if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Width))
                    parameter.Set(_PlacementSettings.Width);
                }
                XYZ xyz3 = new XYZ(epsPoint1.x, epsPoint1.y, epsPoint1.z + 1.0);
                Line bound = Line.CreateBound(epsPoint1.XYZ, xyz3);
                Parameter parameter11 = ((Element) familyInstance4).LookupParameter(RevitParameters.FenceRightVisiability);
                Parameter parameter12 = ((Element) familyInstance4).LookupParameter(RevitParameters.FenceLeftVisiability);
                bool flag8 = false;
                bool flag9 = false;
                if (direction < 0.0)
                {
                  if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                    ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance4).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI - _dAngle));
                  flag8 = true;
                }
                else
                {
                  if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                    ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance4).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
                  flag9 = true;
                }
                if (parameter11 != null && parameter12 != null)
                {
                  parameter11.Set(Convert.ToInt32(flag8));
                  parameter12.Set(Convert.ToInt32(flag9));
                }
                double num14 = Math.Abs(direction);
                ((Element) familyInstance4).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num14);
                if (epsLeg.Element != null && flag2 && flag1)
                {
                  Parameter parameter13 = ((Element) familyInstance4).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                  if (parameter13 != null)
                  {
                    Parameter parameter14 = parameter13;
                    keyValuePair = keyValuePairList[index1];
                    string str = keyValuePair.Value;
                    parameter14.Set(str);
                  }
                  else
                    flag2 = false;
                }
              }
              else
                familyInstance1 = (FamilyInstance) null;
              progressBarForm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Width));
              _dAngle = 0.0;
            }
          }
          double num15 = _dDistance1 - (num11 - width);
          if (RevitDefines.GT(num15, 0.001))
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dDistance1 - num15 / 2.0, 0.0, ref epsPoint1);
            if (!RevitUtility.IsPointInPointList(epsPoint1, _PointList))
            {
              if (epsLeg.Element != null && flag2 && flag3)
              {
                flag3 = false;
                if (RevitUtility.IsParameterIDOnFamily(_Document, _PlacementSettings, _PlacementSettings.Type))
                {
                  keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _Leg.ElementList);
                }
                else
                {
                  int num16 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "LocateFenceNoPositioning", EPShared.LocalRM.GetString("PositionFenceMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                  flag2 = false;
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag1 = true;
                  }
                  else
                  {
                    for (int index5 = 0; index5 < keyValuePairList.Count; ++index5)
                    {
                      keyValuePair = keyValuePairList[index5];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index5;
                        flag1 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint1);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint1, _PlacementSettings.SurfaceList, ref _dElevation);
              epsPoint1.z = _dElevation;
              EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint1, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Direction, ref num1);
              EPShared.eplGeoE_CalcPolarToXY(epsPoint1, num1, num15 / 2.0, ref legStartPnt);
              RevitUtility.GetSurfaceContainingPoint(legStartPnt, _PlacementSettings.SurfaceList, ref _dElevation);
              legStartPnt.z = _dElevation;
              EPShared.eplGeoE_CalcPolarToXY(legStartPnt, num1 + Math.PI, width, ref _NewPnt);
              RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlacementSettings.SurfaceList, ref _dElevation);
              _NewPnt.z = _dElevation;
              EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, legStartPnt, ref _dDistance2);
              double _dVertical = legStartPnt.z - _NewPnt.z;
              double direction = RevitGeometry.CalculateDirection(_dDistance2, _dVertical);
              if (direction <= -1.0 * Math.PI / 2.0 && direction >= Math.PI / 2.0)
              {
                _PlacementSettings.TransactionContainer.EndTransaction();
                int num17 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FenceError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                return;
              }
              FamilyInstance familyInstance5;
              if ((surfaceContainingPoint == null || _PlacementSettings.GenericModelIDList != null) && _ExistingFenceList != null && _ExistingFenceList.Count > 0)
              {
                familyInstance5 = _ExistingFenceList[0];
                if (((Element) familyInstance5).Location is LocationPoint location)
                {
                  if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, new Eps_Point(location.Point)))
                  {
                    XYZ xyz = new XYZ(epsPoint1.XYZ.X - location.Point.X, epsPoint1.XYZ.Y - location.Point.Y, 0.0);
                    ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance5).Id, xyz);
                  }
                  _dAngle = location.Rotation;
                }
                _ExistingFenceList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
                familyInstance5 = RevitUtility.NewFamilyInstance(_Document, epsPoint1.XY, _PlacementSettings.Type, surfaceContainingPoint, _PlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlacementSettings.TransactionContainer = transactionContainer;
              }
              if (Math.Abs(_PlacementSettings.Height) > 0.0)
              {
                Parameter parameter = ((Element) familyInstance5).LookupParameter(RevitParameters.FenceFamilyHeightParameter);
                if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), _PlacementSettings.Height))
                  parameter.Set(_PlacementSettings.Height);
              }
              if (Math.Abs(_PlacementSettings.Width) > 0.0)
              {
                Parameter parameter = ((Element) familyInstance5).LookupParameter(RevitParameters.FenceFamilySpanParameter);
                if (parameter != null && !RevitDefines.EQ(parameter.AsDouble(), num15))
                  parameter.Set(num15);
              }
              XYZ xyz4 = new XYZ(epsPoint1.x, epsPoint1.y, epsPoint1.z + 1.0);
              Line bound = Line.CreateBound(epsPoint1.XYZ, xyz4);
              Parameter parameter15 = ((Element) familyInstance5).LookupParameter(RevitParameters.FenceRightVisiability);
              Parameter parameter16 = ((Element) familyInstance5).LookupParameter(RevitParameters.FenceLeftVisiability);
              bool flag10 = true;
              bool flag11 = true;
              if (direction < 0.0)
              {
                if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                  ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance5).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 + Math.PI - _dAngle));
              }
              else if (!RevitDefines.EQ(EPShared.eplGeoE_NormalizeRadians(num1), EPShared.eplGeoE_NormalizeRadians(_dAngle)))
                ElementTransformUtils.RotateElement(_Document, ((Element) familyInstance5).Id, bound, EPShared.eplGeoE_NormalizeRadians(num1 - _dAngle));
              if (parameter15 != null && parameter16 != null)
              {
                parameter15.Set(Convert.ToInt32(flag10));
                parameter16.Set(Convert.ToInt32(flag11));
              }
              double num18 = Math.Abs(direction);
              ((Element) familyInstance5).LookupParameter(RevitParameters.FenceFamilyAngleParameter)?.Set(num18);
              if (epsLeg.Element != null && flag2 && flag1)
              {
                Parameter parameter17 = ((Element) familyInstance5).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter17 != null)
                {
                  Parameter parameter18 = parameter17;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter18.Set(str);
                }
                else
                  flag2 = false;
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Width));
            _dAngle = 0.0;
          }
          else
          {
            if (familyInstance1 != null)
            {
              Parameter parameter19 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceRightVisiability);
              Parameter parameter20 = ((Element) familyInstance1).LookupParameter(RevitParameters.FenceLeftVisiability);
              if (parameter19 != null && parameter20 != null)
              {
                parameter19.Set(Convert.ToInt32(true));
                parameter20.Set(Convert.ToInt32(true));
              }
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(_PlacementSettings.Width));
            _dAngle = 0.0;
          }
          num2 = 0.0;
        }
      }
      flag1 = false;
    }
    if (_ExistingFenceList != null && _ExistingFenceList.Count > 0)
    {
      for (int index6 = 0; index6 < _ExistingFenceList.Count; ++index6)
        _Document.Delete(((Element) _ExistingFenceList[index6]).Id);
    }
    if (_PlacementSettings.GenericModelIDList == null)
      _PlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
  }
}
