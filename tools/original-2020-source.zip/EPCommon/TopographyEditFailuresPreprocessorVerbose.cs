﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.TopographyEditFailuresPreprocessorVerbose
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace EPCommon;

internal class TopographyEditFailuresPreprocessorVerbose : IFailuresPreprocessor
{
  public FailureProcessingResult PreprocessFailures(FailuresAccessor failuresAccessor)
  {
    try
    {
      TaskDialog.Show("Preprocess failures", "Hello");
      IList<FailureMessageAccessor> failureMessages = failuresAccessor.GetFailureMessages();
      int count = failureMessages.Count;
      TaskDialog.Show("Preprocess failures", $"Found {(object) count} failure messages.");
      if (count < 5)
      {
        foreach (FailureMessageAccessor failureMessageAccessor in (IEnumerable<FailureMessageAccessor>) failureMessages)
          TaskDialog.Show("Failure!", failureMessageAccessor.GetDescriptionText());
      }
      else
        TaskDialog.Show("Failure 1 of " + (object) count, failureMessages.First<FailureMessageAccessor>().GetDescriptionText());
      TaskDialog.Show("Preprocess failures", "Goodbye");
      return (FailureProcessingResult) 0;
    }
    catch (Exception ex)
    {
      TaskDialog.Show("Exception", ex.ToString());
      return (FailureProcessingResult) 2;
    }
  }
}
