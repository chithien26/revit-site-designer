﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.EPShared
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Resources;

#nullable disable
namespace EPCommon;

public class EPShared
{
  private const double angleRatio = 0.017453292519943295;
  private static ResourceManager m_LocRM;

  public static ResourceManager LocalRM
  {
    get
    {
      if (EPShared.m_LocRM == null)
        EPShared.m_LocRM = new ResourceManager("SITES.WinFormStrings", typeof (LocateSiteComponentForm).Assembly);
      return EPShared.m_LocRM;
    }
  }

  public static bool eplGeoE_ArePntsDuplicates2D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt)
  {
    return EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt, _SecondCheckPnt, 1E-05);
  }

  public static bool eplGeoE_ArePntsDuplicates2D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt,
    double _dTolerance)
  {
    double _dY = _dTolerance;
    bool flag = false;
    double num1 = _FirstCheckPnt.x - _SecondCheckPnt.x;
    double num2 = _FirstCheckPnt.y - _SecondCheckPnt.y;
    if (RevitDefines.EQ(_dTolerance, 1E-09, 0.0))
    {
      double _dX1 = EPShared.eplCalE_CalcPointTolerance(_FirstCheckPnt, _dTolerance, false);
      double _dX2 = EPShared.eplCalE_CalcPointTolerance(_SecondCheckPnt, _dTolerance, false);
      if (RevitDefines.GT(_dX1, _dY, 0.0))
        _dY = _dX1;
      if (RevitDefines.GT(_dX2, _dY, 0.0))
        _dY = _dX2;
    }
    if (Math.Sqrt(num1 * num1 + num2 * num2) <= _dY)
      flag = true;
    return flag;
  }

  public static int eplGeoE_CalcHorzAngByThreePnts(
    Eps_Point _StartPnt,
    Eps_Point _Vertex,
    Eps_Point _EndPnt,
    int _nAngleType,
    ref double _dAngle,
    double _dPointTol)
  {
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_Vertex, _StartPnt, _dPointTol) || EPShared.eplGeoE_ArePntsDuplicates2D(_Vertex, _EndPnt, _dPointTol))
      return 6;
    double num1 = EPShared.eplGeoE_CalcPlaneDirBtwnTwoPnts(_Vertex, _StartPnt);
    double num2 = EPShared.eplGeoE_CalcPlaneDirBtwnTwoPnts(_Vertex, _EndPnt);
    double num3 = EPShared.eplGeoE_CalcPlaneDirBtwnTwoPnts(_StartPnt, _Vertex);
    switch (_nAngleType)
    {
      case 11:
        _dAngle = Math.Abs(num1 - num2);
        if (_dAngle > Math.PI)
        {
          _dAngle = 2.0 * Math.PI - _dAngle;
          break;
        }
        break;
      case 12:
        _dAngle = EPShared.eplGeoE_NormalizeRadians(num1 - num2);
        break;
      case 13:
        _dAngle = EPShared.eplGeoE_NormalizeRadians(num2 - num1);
        break;
      case 14:
        _dAngle = EPShared.eplGeoE_NormalizeRadians(num3 - num2);
        break;
      case 15:
        _dAngle = EPShared.eplGeoE_NormalizeRadians(num2 - num3);
        break;
      default:
        return 6;
    }
    return 0;
  }

  public static double eplGeoE_NormalizeRadians(double _dAngle)
  {
    return _dAngle - EPShared.eplCalE_floor(_dAngle / (2.0 * Math.PI), 1E-10) * (2.0 * Math.PI);
  }

  public static double eplCalE_floor(double Operand, double Tolerance)
  {
    return Math.Floor(Operand + Tolerance);
  }

  public static int eplGeoE_CalcHorzDirBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDirection)
  {
    return EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, _SecondPnt, ref _dDirection, 1E-05);
  }

  public static int eplGeoE_CalcHorzDirBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDirection,
    double _dMinDist)
  {
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_FirstPnt, _SecondPnt, _dMinDist))
      return 6;
    _dDirection = EPShared.eplGeoE_CalcPlaneDirBtwnTwoPnts(_FirstPnt, _SecondPnt);
    return 0;
  }

  public static double eplGeoE_CalcPlaneDirBtwnTwoPnts(Eps_Point _FirstPnt, Eps_Point _SecondPnt)
  {
    double x = _SecondPnt.x - _FirstPnt.x;
    double y = _SecondPnt.y - _FirstPnt.y;
    return EPShared.eplGeoE_NormalizeRadians(x != 0.0 || y != 0.0 ? Math.Atan2(y, x) : 0.0);
  }

  public static int eplGeoE_CalcHorzDistBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDistance)
  {
    return EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, _SecondPnt, ref _dDistance, 1E-05);
  }

  public static int eplGeoE_CalcHorzDistBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDistance,
    double _dMinDist)
  {
    double num = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(_FirstPnt.x, _FirstPnt.y, _SecondPnt.x, _SecondPnt.y);
    if (num <= _dMinDist)
    {
      _dDistance = 0.0;
      return 6;
    }
    _dDistance = num;
    return 0;
  }

  public static void eplGeoE_CalcPolarToXY(
    Eps_Point _StartPnt,
    double _dPolarDirection,
    double _dPolarDistance,
    ref Eps_Point _NewPnt)
  {
    double _dX = _StartPnt.XYZ.X + _dPolarDistance * Math.Cos(_dPolarDirection);
    double _dY = _StartPnt.XYZ.Y + _dPolarDistance * Math.Sin(_dPolarDirection);
    _NewPnt = new Eps_Point(_dX, _dY, _StartPnt.XYZ.Z);
  }

  public static void eplGeoE_FindStaOffPointAlongArc(
    Eps_Arc _Arc,
    double _dStation,
    double _dOffset,
    ref Eps_Point _StaOffPnt)
  {
    _StaOffPnt = new Eps_Point();
    double _dDirection = 0.0;
    double num1 = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_Arc.Radius, _Arc.Delta);
    double num2 = num1 > 1E-05 ? _Arc.Delta * (_dStation / num1) : 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Arc.StartPnt, ref _dDirection);
    double _dPolarDirection = _Arc.Direction != -1 ? _dDirection + num2 : _dDirection - num2;
    double _dPolarDistance = _Arc.Direction != -1 ? _Arc.Radius + _dOffset : _Arc.Radius - _dOffset;
    EPShared.eplGeoE_CalcPolarToXY(_Arc.RadiusPnt, _dPolarDirection, _dPolarDistance, ref _StaOffPnt);
  }

  public static void eplGeoE_FindStaOffPointAlongLine(
    Eps_Line _Line,
    double _dStation,
    double _dOffset,
    ref Eps_Point _StaOffPnt)
  {
    _StaOffPnt = new Eps_Point();
    double _dDirection = 0.0;
    Eps_Point _NewPnt = new Eps_Point();
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, _dStation, ref _NewPnt);
    EPShared.eplGeoE_CalcPolarToXY(_NewPnt, _dDirection - Math.PI / 2.0, _dOffset, ref _StaOffPnt);
  }

  public static void eplGeoE_CalcTangentDirOfArc(
    Eps_Point _ArcPnt,
    Eps_Point _RadiusPnt,
    int _nArcDirection,
    ref double _dTangentDir)
  {
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_RadiusPnt, _ArcPnt, ref _dTangentDir);
    if (_nArcDirection == 1)
      _dTangentDir += Math.PI / 2.0;
    else
      _dTangentDir -= Math.PI / 2.0;
    _dTangentDir = EPShared.eplGeoE_NormalizeRadians(_dTangentDir);
  }

  public static int eplGeoE_CalcStationOffsetAlongLine(
    Eps_Point _Point,
    Eps_Line _Line,
    ref double _dStation,
    ref double _dOffset,
    double _dStaTolerance)
  {
    double _Direction1 = 0.0;
    double _Direction2 = 0.0;
    double _Distance1 = 0.0;
    double _Distance2 = 0.0;
    EPShared.eplGeoE_InversePoints(_Line.StartPnt, _Line.EndPnt, ref _Direction1, ref _Distance1);
    EPShared.eplGeoE_InversePoints(_Line.StartPnt, _Point, ref _Direction2, ref _Distance2);
    double num = _Direction1 - _Direction2;
    _dStation = _Distance2 * Math.Cos(num);
    _dOffset = _Distance2 * Math.Sin(num);
    if (RevitDefines.EQ(_dStation, _Distance1))
      return 1700;
    if (_dStation < 0.0)
    {
      if (_dStation + _dStaTolerance < 0.0)
        return 1701;
      _dStation = 0.0;
    }
    else if (_dStation > _Distance1)
    {
      if (_dStation - _dStaTolerance > _Distance1)
        return 1701;
      _dStation = _Distance1;
    }
    return 1700;
  }

  public static int eplGeoE_InversePoints(
    Eps_Point _StartPnt,
    Eps_Point _EndPnt,
    ref double _Direction,
    ref double _Distance)
  {
    _Direction = 0.0;
    _Distance = 0.0;
    int num = EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_StartPnt, _EndPnt, ref _Distance);
    return num != 0 ? num : EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_StartPnt, _EndPnt, ref _Direction);
  }

  public static int eplGeoE_CalcStationOffsetAlongArc(
    Eps_Point _Point,
    Eps_Arc _Arc,
    ref double _dStation,
    ref double _dOffset)
  {
    return EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Arc, ref _dStation, ref _dOffset, 1E-05);
  }

  public static int eplGeoE_CalcStationOffsetAlongArc(
    Eps_Point _Point,
    Eps_Arc _Arc,
    ref double _dStation,
    ref double _dOffset,
    double _dStaTolerance)
  {
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    double _dDirection3 = 0.0;
    double _dDistance = 0.0;
    double _SweepAngle = 0.0;
    Eps_Point _NewPnt = new Eps_Point();
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_Arc.RadiusPnt, _Point))
      return 1701;
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_Arc.StartPnt, _Point))
    {
      _dStation = 0.0;
      _dOffset = 0.0;
      return 1700;
    }
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Arc.StartPnt, ref _dDirection1);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Arc.EndPnt, ref _dDirection2);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Point, ref _dDirection3);
    EPShared.eplGeoE_CalcPolarToXY(_Arc.RadiusPnt, _dDirection3, _Arc.Radius, ref _NewPnt);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Point, _NewPnt, ref _dOffset);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Arc.RadiusPnt, _Point, ref _dDistance);
    if (_Arc.Direction == -1 && _dDistance > _Arc.Radius)
      _dOffset = -_dOffset;
    else if (_Arc.Direction == 1 && _dDistance < _Arc.Radius)
      _dOffset = -_dOffset;
    _dDirection2 -= _dDirection1;
    double _dAngle = _dDirection3 - _dDirection1;
    double _EndDir = 0.0;
    _dDirection2 = EPShared.eplGeoE_NormalizeRadians(_dDirection2);
    double num = EPShared.eplGeoE_NormalizeRadians(_dAngle);
    _dStation = num * _Arc.Radius;
    if (_Arc.Direction == -1)
    {
      if (num < _dDirection2)
      {
        EPShared.eplGeoE_CalcSweepAngle(-1, _dDirection2, num, ref _SweepAngle);
        _dStation = _SweepAngle * _Arc.Radius;
        if (_dStation - _dStaTolerance > 0.0)
        {
          EPShared.eplGeoE_CalcSweepAngle(-1, num, _EndDir, ref _SweepAngle);
          _dStation = _SweepAngle * _Arc.Radius;
          if (_dStation - _dStaTolerance > 0.0)
            return 1701;
          _dStation = 2.0 * Math.PI * _Arc.Radius;
        }
        else
          _dStation = (2.0 * Math.PI - _Arc.Delta) * _Arc.Radius;
      }
    }
    else if (num > _dDirection2)
    {
      EPShared.eplGeoE_CalcSweepAngle(1, _dDirection2, num, ref _SweepAngle);
      _dStation = _SweepAngle * _Arc.Radius;
      if (_dStation - _dStaTolerance > 0.0)
      {
        EPShared.eplGeoE_CalcSweepAngle(1, num, _EndDir, ref _SweepAngle);
        _dStation = _SweepAngle * _Arc.Radius;
        if (_dStation - _dStaTolerance > 0.0)
          return 1701;
        _dStation = 0.0;
      }
      else
        _dStation = _Arc.Delta * _Arc.Radius;
    }
    if (_Arc.Direction == -1)
      _dStation = 2.0 * Math.PI * _Arc.Radius - _dStation;
    return 1700;
  }

  public static void eplGeoE_CalcSweepAngle(
    int _ArcDir,
    double _StartDir,
    double _EndDir,
    ref double _SweepAngle)
  {
    if (_ArcDir == -1)
      _SweepAngle = EPShared.eplGeoE_NormalizeRadians(_StartDir - _EndDir);
    else
      _SweepAngle = EPShared.eplGeoE_NormalizeRadians(_EndDir - _StartDir);
  }

  public static double eplGeoE_SolveArcLenByRadiusAndDelta(double _Radius, double _DeltaAngle)
  {
    return _Radius * _DeltaAngle;
  }

  public static int eplGeoE_ConstructOffsetArc(
    Eps_Arc _OrigArc,
    double _dOffsetDist,
    int _nOffsetDir,
    ref Eps_Arc _OffsetArc)
  {
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    if (_nOffsetDir == 1 && _OrigArc.Direction == -1 || _nOffsetDir == 2 && _OrigArc.Direction == 1)
    {
      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_OrigArc.StartPnt, _OrigArc.RadiusPnt, ref _dDirection1);
      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_OrigArc.EndPnt, _OrigArc.RadiusPnt, ref _dDirection2);
      _OffsetArc.Radius = _OrigArc.Radius - _dOffsetDist;
      if (Math.Abs(_OffsetArc.Radius - 0.0) <= 1E-05)
        return 1;
    }
    else
    {
      if ((_nOffsetDir != 1 || _OrigArc.Direction != 1) && (_nOffsetDir != 2 || _OrigArc.Direction != -1))
        return 1;
      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_OrigArc.RadiusPnt, _OrigArc.StartPnt, ref _dDirection1);
      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_OrigArc.RadiusPnt, _OrigArc.EndPnt, ref _dDirection2);
      _OffsetArc.Radius = _OrigArc.Radius + _dOffsetDist;
    }
    Eps_Point _NewPnt1 = new Eps_Point();
    Eps_Point _NewPnt2 = new Eps_Point();
    EPShared.eplGeoE_CalcPolarToXY(_OrigArc.StartPnt, _dDirection1, _dOffsetDist, ref _NewPnt1);
    EPShared.eplGeoE_CalcPolarToXY(_OrigArc.EndPnt, _dDirection2, _dOffsetDist, ref _NewPnt2);
    _OffsetArc.StartPnt = _NewPnt1;
    _OffsetArc.EndPnt = _NewPnt2;
    _OffsetArc.RadiusPnt = _OrigArc.RadiusPnt;
    _OffsetArc.Delta = _OrigArc.Delta;
    _OffsetArc.Direction = _OrigArc.Direction;
    return 0;
  }

  public static int eplGeoE_ConstructOffsetLine(
    Eps_Line _OrigLine,
    double _dOffsetDist,
    int _nOffsetDir,
    ref Eps_Line _OffsetLine)
  {
    _OffsetLine = new Eps_Line();
    double _dDirection = 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_OrigLine.StartPnt, _OrigLine.EndPnt, ref _dDirection);
    double _dPolarDirection;
    switch (_nOffsetDir)
    {
      case 1:
        _dPolarDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0);
        break;
      case 2:
        _dPolarDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0);
        break;
      default:
        return 1;
    }
    Eps_Point _NewPnt1 = new Eps_Point();
    Eps_Point _NewPnt2 = new Eps_Point();
    EPShared.eplGeoE_CalcPolarToXY(_OrigLine.StartPnt, _dPolarDirection, _dOffsetDist, ref _NewPnt1);
    EPShared.eplGeoE_CalcPolarToXY(_OrigLine.EndPnt, _dPolarDirection, _dOffsetDist, ref _NewPnt2);
    _OffsetLine.StartPnt = _NewPnt1;
    _OffsetLine.EndPnt = _NewPnt2;
    return 0;
  }

  public static int eplGeoE_CalcMidPointBetweenTwoPoints(
    Eps_Point _FirstPoint,
    Eps_Point _SecondPoint,
    ref Eps_Point _MidPoint)
  {
    _MidPoint = new Eps_Point();
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPoint, _SecondPoint, ref _dDistance);
    if (_dDistance == 0.0 || EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPoint, _SecondPoint, ref _dDirection) != 0)
      return 6;
    EPShared.eplGeoE_CalcPolarToXY(_FirstPoint, _dDirection, _dDistance / 2.0, ref _MidPoint);
    return 0;
  }

  public static int eplGeoE_IntersectTwoDirs2D(
    Eps_Point _FirstPnt,
    double _dFirstDir,
    Eps_Point _SecondPnt,
    double _dSecondDir,
    ref Eps_Point _InterPnt,
    double _dTolerance)
  {
    _InterPnt = new Eps_Point();
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    double num1 = 1E-10;
    double _dX1 = EPShared.eplCalE_CalcPointTolerance(_FirstPnt, _dTolerance, false);
    double _dX2 = EPShared.eplCalE_CalcPointTolerance(_SecondPnt, _dTolerance, false);
    if (RevitDefines.GT(_dX1, num1, 0.0))
      num1 = _dX1;
    if (RevitDefines.GT(_dX2, num1, 0.0))
      num1 = _dX2;
    _InterPnt.z = _FirstPnt.z;
    _dFirstDir = EPShared.eplGeoE_NormalizeRadians(_dFirstDir);
    _dSecondDir = EPShared.eplGeoE_NormalizeRadians(_dSecondDir);
    if (EPShared.eplGeoE_AreLinesParallel(_dFirstDir, _dSecondDir, num1))
      return 1103;
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_FirstPnt, _SecondPnt, _dTolerance))
    {
      _InterPnt.x = _FirstPnt.x;
      _InterPnt.y = _FirstPnt.y;
      return 1104;
    }
    if (RevitDefines.EQ(_dFirstDir, Math.PI / 2.0, 1E-10) || RevitDefines.EQ(_dFirstDir, 3.0 * Math.PI / 2.0, 1E-10))
    {
      _InterPnt.x = _FirstPnt.x;
      double num2 = Math.Tan(_dSecondDir);
      double num3 = _SecondPnt.y - num2 * _SecondPnt.x;
      _InterPnt.y = num3 + num2 * _InterPnt.x;
    }
    else if (RevitDefines.EQ(_dSecondDir, Math.PI / 2.0, 1E-10) || RevitDefines.EQ(_dSecondDir, 3.0 * Math.PI / 2.0, 1E-10))
    {
      _InterPnt.x = _SecondPnt.x;
      double num4 = Math.Tan(_dFirstDir);
      double num5 = _FirstPnt.y - num4 * _FirstPnt.x;
      _InterPnt.y = num4 * _InterPnt.x + num5;
    }
    else
    {
      double num6 = Math.Tan(_dFirstDir);
      double num7 = Math.Tan(_dSecondDir);
      double num8 = _FirstPnt.y - num6 * _FirstPnt.x;
      double num9 = _SecondPnt.y - num7 * _SecondPnt.x;
      _InterPnt.x = -(num8 - num9) / (num6 - num7);
      _InterPnt.y = num6 * _InterPnt.x + num8;
    }
    if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_InterPnt, _FirstPnt, ref _dDirection1) == 1105)
      _dDirection1 = 0.0;
    if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_InterPnt, _SecondPnt, ref _dDirection2) == 1105)
      _dDirection2 = 0.0;
    double num10 = Math.Abs(_dDirection1 - _dFirstDir);
    double num11 = Math.Abs(_dDirection2 - _dSecondDir);
    if (num10 <= 1E-10 && num11 <= 1E-10)
      return 1106;
    if (num10 <= 1E-10 && num11 > 1E-10)
      return 1107;
    return num10 > 1E-10 && num11 <= 1E-10 ? 1112 : 1104;
  }

  public static double eplCalE_CalcPointTolerance(Eps_Point _Point, double _Tolerance, bool _Is3D)
  {
    double _dY = _Tolerance;
    double _dX1 = _Tolerance;
    double _dX2 = _Tolerance;
    double _dX3 = _Tolerance;
    if (RevitDefines.EQ(_Tolerance, 1E-05, 0.0))
    {
      if (Math.Abs(_Point.x) >= 100000.0)
        _dX1 = EPShared.eplCalE_CalcTolerance(_Point.x);
      if (Math.Abs(_Point.y) >= 100000.0)
        _dX2 = EPShared.eplCalE_CalcTolerance(_Point.y);
      if (_Is3D && Math.Abs(_Point.z) >= 100000.0)
        _dX3 = EPShared.eplCalE_CalcTolerance(_Point.z);
      if (RevitDefines.GT(_dX1, _dY, 0.0))
        _dY = _dX1;
      if (RevitDefines.GT(_dX2, _dY, 0.0))
        _dY = _dX2;
      if (_Is3D && RevitDefines.GT(_dX3, _dY, 0.0))
        _dY = _dX3;
    }
    return _dY;
  }

  public static double eplCalE_CalcTolerance(double _Value)
  {
    return Math.Pow(10.0, -(15.0 - (double) EPShared.GetBase10(_Value)));
  }

  public static int GetBase10(double _Value)
  {
    int base10 = 0;
    if (RevitDefines.EQ(_Value, 0.0, 0.0))
      return 1;
    double _dX = Math.Log10(Math.Abs(_Value));
    if (RevitDefines.GE(_dX, 0.0, 0.0))
      base10 = (int) _dX + 1;
    else if (RevitDefines.LT(_dX, 0.0, 0.0))
      base10 = (int) _dX;
    return base10;
  }

  public static bool eplGeoE_AreLinesParallel(
    Eps_Line _FirstLine,
    Eps_Line _SecondLine,
    double _dTolerance)
  {
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstLine.StartPnt, _FirstLine.EndPnt, ref _dDirection1);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_SecondLine.StartPnt, _SecondLine.EndPnt, ref _dDirection2);
    return EPShared.eplGeoE_AreLinesParallel(_dDirection1, _dDirection2, _dTolerance);
  }

  public static bool eplGeoE_AreLinesParallel(
    double _dFirstLineDir,
    double _dSecondLineDir,
    double _dTolerance)
  {
    return Math.Abs(_dFirstLineDir - _dSecondLineDir) <= _dTolerance || Math.Abs(EPShared.eplGeoE_NormalizeRadians(_dFirstLineDir + Math.PI) - _dSecondLineDir) <= _dTolerance;
  }

  public static bool eplGeoE_ArePntsDuplicates3D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt)
  {
    return EPShared.eplGeoE_ArePntsDuplicates3D(_FirstCheckPnt, _SecondCheckPnt, 1E-05);
  }

  public static bool eplGeoE_ArePntsDuplicates3D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt,
    double _dTolerance)
  {
    bool flag = false;
    double num1 = _FirstCheckPnt.x - _SecondCheckPnt.x;
    double num2 = _FirstCheckPnt.y - _SecondCheckPnt.y;
    double num3 = _FirstCheckPnt.z - _SecondCheckPnt.z;
    if (num1 * num1 + num2 * num2 + num3 * num3 <= _dTolerance * _dTolerance)
      flag = true;
    return flag;
  }

  public static void eplGeoE_CalcArcStructFromPCAndPTAndRP(
    Eps_Point _PntOfArc,
    Eps_Point _RadiusPoint,
    Eps_Point _PntOfTangency,
    int _nDirection,
    ref Eps_Arc _ArcStruct)
  {
    _ArcStruct = new Eps_Arc();
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    double _dDistance1 = 0.0;
    double _dDistance2 = 0.0;
    _ArcStruct.StartPnt = _PntOfArc;
    _ArcStruct.RadiusPnt = _RadiusPoint;
    _ArcStruct.EndPnt = _PntOfTangency;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_ArcStruct.RadiusPnt, _ArcStruct.StartPnt, ref _dDistance1);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_ArcStruct.RadiusPnt, _ArcStruct.EndPnt, ref _dDistance2);
    if (Math.Abs(_dDistance1 - _dDistance2) <= 1E-05)
    {
      _ArcStruct.Radius = _dDistance1;
    }
    else
    {
      EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_ArcStruct.RadiusPnt, _ArcStruct.EndPnt, ref _dDirection2);
      Eps_Point _NewPnt = new Eps_Point();
      EPShared.eplGeoE_CalcPolarToXY(_ArcStruct.RadiusPnt, _dDirection2, _dDistance1, ref _NewPnt);
      _ArcStruct.EndPnt = _NewPnt;
      _ArcStruct.Radius = _dDistance1;
    }
    _ArcStruct.Direction = _nDirection;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_ArcStruct.RadiusPnt, _ArcStruct.StartPnt, ref _dDirection1);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_ArcStruct.RadiusPnt, _ArcStruct.EndPnt, ref _dDirection2);
    double _SweepAngle = 0.0;
    EPShared.eplGeoE_CalcSweepAngle(_ArcStruct.Direction, _dDirection1, _dDirection2, ref _SweepAngle);
    _ArcStruct.Delta = _SweepAngle;
  }

  public static void eplGeoE_FindMinMaxOfArc(
    Eps_Arc _Arc,
    ref Eps_Point _MinPnt,
    ref Eps_Point _MaxPnt)
  {
    _MinPnt = new Eps_Point();
    _MaxPnt = new Eps_Point();
    Eps_Point _NewPnt = new Eps_Point();
    _MinPnt.x = double.MaxValue;
    _MaxPnt.x = double.MinValue;
    _MinPnt.y = double.MaxValue;
    _MaxPnt.y = double.MinValue;
    _MinPnt.z = double.MaxValue;
    _MaxPnt.z = double.MinValue;
    EPShared.CalcMinMax(_Arc.StartPnt, ref _MinPnt, ref _MaxPnt);
    EPShared.CalcMinMax(_Arc.EndPnt, ref _MinPnt, ref _MaxPnt);
    for (int index = 0; index < 4; ++index)
    {
      EPShared.eplGeoE_CalcPolarToXY(_Arc.RadiusPnt, EPShared.eplGeoE_NormalizeRadians(0.0 + (double) index * (Math.PI / 2.0)), _Arc.Radius, ref _NewPnt);
      if (EPShared.eplGeoE_IsPointOnArc2D(_NewPnt, _Arc, 1E-05))
        EPShared.CalcMinMax(_NewPnt, ref _MinPnt, ref _MaxPnt);
    }
  }

  public static void CalcMinMax(Eps_Point pPoint, ref Eps_Point pMinPnt, ref Eps_Point pMaxPnt)
  {
    pMinPnt.x = Math.Min(pMinPnt.x, pPoint.x);
    pMaxPnt.x = Math.Max(pMaxPnt.x, pPoint.x);
    pMinPnt.y = Math.Min(pMinPnt.y, pPoint.y);
    pMaxPnt.y = Math.Max(pMaxPnt.y, pPoint.y);
    pMinPnt.z = Math.Min(pMinPnt.z, pPoint.z);
    pMaxPnt.z = Math.Max(pMaxPnt.z, pPoint.z);
  }

  public static bool eplGeoE_IsPointOnArc2D(
    Eps_Point _Point,
    Eps_Arc _Arc,
    double _dPointTolerance)
  {
    double _dDistance = 0.0;
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    double _SweepAngle = 0.0;
    bool flag = false;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Arc.RadiusPnt, _Point, ref _dDistance, _dPointTolerance);
    if (RevitDefines.LT(_dDistance, _Arc.Radius, _dPointTolerance) || RevitDefines.GT(_dDistance, _Arc.Radius, _dPointTolerance))
      flag = false;
    else if (EPShared.eplGeoE_ArePntsDuplicates2D(_Arc.StartPnt, _Arc.EndPnt, _dPointTolerance))
    {
      flag = true;
    }
    else
    {
      if (_Arc.Direction == -1)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Point, ref _dDirection1);
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Arc.EndPnt, ref _dDirection2);
      }
      else
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Arc.StartPnt, ref _dDirection1);
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.RadiusPnt, _Point, ref _dDirection2);
      }
      EPShared.eplGeoE_CalcSweepAngle(_Arc.Direction, _dDirection1, _dDirection2, ref _SweepAngle);
      if (RevitDefines.LE(_SweepAngle, _Arc.Delta, 1E-10))
        flag = true;
    }
    return flag;
  }

  public static bool eplGeoE_IsPointOnLine2D(
    Eps_Point _Point,
    Eps_Line _Line,
    double _dPointTolerance)
  {
    Eps_Point _ProjPnt = new Eps_Point();
    return !RevitDefines.LT(_Point.x, Math.Min(_Line.StartPnt.x, _Line.EndPnt.x), _dPointTolerance) && !RevitDefines.GT(_Point.x, Math.Max(_Line.StartPnt.x, _Line.EndPnt.x), _dPointTolerance) && !RevitDefines.LT(_Point.y, Math.Min(_Line.StartPnt.y, _Line.EndPnt.y), _dPointTolerance) && !RevitDefines.GT(_Point.y, Math.Max(_Line.StartPnt.y, _Line.EndPnt.y), _dPointTolerance) && EPShared.eplGeoE_ProjectPointOnLine2D(_Point, _Line, ref _ProjPnt, ref _dPointTolerance) == 1700 && EPShared.eplGeoE_ArePntsDuplicates2D(_Point, _ProjPnt, _dPointTolerance);
  }

  public static int eplGeoE_ProjectPointOnLine2D(
    Eps_Point _PointToProj,
    Eps_Line _Line,
    ref Eps_Point _ProjPnt,
    ref double _dPntTolerance)
  {
    double _Direction1 = 0.0;
    double _Direction2 = 0.0;
    double _Distance1 = 0.0;
    double _Distance2 = 0.0;
    EPShared.eplGeoE_InversePoints(_Line.StartPnt, _Line.EndPnt, ref _Direction1, ref _Distance1);
    if (EPShared.eplGeoE_InversePoints(_Line.StartPnt, _PointToProj, ref _Direction2, ref _Distance2) == 1105)
    {
      _ProjPnt = _PointToProj;
      return 1700;
    }
    double d = _Direction1 - _Direction2;
    double _dPolarDistance = _Distance2 * Math.Cos(d);
    EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _Direction1, _dPolarDistance, ref _ProjPnt);
    if (_dPolarDistance < 0.0)
    {
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_Line.StartPnt, _ProjPnt, _dPntTolerance))
        return 1701;
      _ProjPnt = _Line.StartPnt;
    }
    else if (_dPolarDistance > _Distance1)
    {
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_Line.EndPnt, _ProjPnt, _dPntTolerance))
        return 1701;
      _ProjPnt = _Line.EndPnt;
    }
    return 1700;
  }

  public static bool eplGeoE_DoBoundingBoxesOverlap(
    Eps_Line _LineOne,
    Eps_Line _LineTwo,
    double _dPointTolerance)
  {
    return !RevitDefines.LT(Math.Max(_LineOne.StartPnt.x, _LineOne.EndPnt.x), Math.Min(_LineTwo.StartPnt.x, _LineTwo.EndPnt.x), _dPointTolerance) && !RevitDefines.GT(Math.Min(_LineOne.StartPnt.x, _LineOne.EndPnt.x), Math.Max(_LineTwo.StartPnt.x, _LineTwo.EndPnt.x), _dPointTolerance) && !RevitDefines.LT(Math.Max(_LineOne.StartPnt.y, _LineOne.EndPnt.y), Math.Min(_LineTwo.StartPnt.y, _LineTwo.EndPnt.y), _dPointTolerance) && !RevitDefines.GT(Math.Min(_LineOne.StartPnt.y, _LineOne.EndPnt.y), Math.Max(_LineTwo.StartPnt.y, _LineTwo.EndPnt.y), _dPointTolerance);
  }

  public static double eplGeoE_CalcPlaneDistBtwnTwoPnts(
    double _dFirstPntRightLeft,
    double _dFirstPntUpDown,
    double _dSecondPntRightLeft,
    double _dSecondPntUpDown)
  {
    double x1 = _dSecondPntRightLeft - _dFirstPntRightLeft;
    double x2 = _dSecondPntUpDown - _dFirstPntUpDown;
    return Math.Sqrt(Math.Pow(x1, 2.0) + Math.Pow(x2, 2.0));
  }

  public static void eplGeoE_MakeVector(
    Eps_Point _InitialPnt,
    Eps_Point _FinalPnt,
    ref Eps_Point _Vector)
  {
    _Vector = new Eps_Point();
    _Vector.x = _FinalPnt.x - _InitialPnt.x;
    _Vector.y = _FinalPnt.y - _InitialPnt.y;
    _Vector.z = _FinalPnt.z - _InitialPnt.z;
  }

  public static int eplGeoE_CheckIfLineInsideLine(
    Eps_Line _LineOne,
    Eps_Line _LineTwo,
    double _dPointTolerance)
  {
    Eps_Point _ProjPnt = new Eps_Point();
    return EPShared.eplGeoE_ProjectPointOnLine2D(_LineOne.StartPnt, _LineTwo, ref _ProjPnt, ref _dPointTolerance) == 1701 || EPShared.eplGeoE_ProjectPointOnLine2D(_LineOne.EndPnt, _LineTwo, ref _ProjPnt, ref _dPointTolerance) == 1701 ? 1701 : 1700;
  }

  public static int eplGeoE_SolveDeltaByChordLenAndRadius(
    double _dChordLength,
    double _dRadius,
    ref double _dDeltaAngle)
  {
    _dDeltaAngle = 0.0;
    if (_dChordLength > 2.0 * _dRadius)
      return 1210;
    _dDeltaAngle = 2.0 * Math.Asin(_dChordLength / (2.0 * _dRadius));
    return 0;
  }

  public static double eplGeoE_SolveTanLenByRadiusAndDelta(double _dRadius, double _dDeltaAngle)
  {
    return Math.Abs(_dDeltaAngle - Math.PI) >= 1E-10 ? _dRadius * Math.Tan(_dDeltaAngle / 2.0) : 0.0;
  }

  public static void eplGeoE_CalcRadiusPointFromPCAndPIAndPT(
    Eps_Point _PntOfCurve,
    Eps_Point _PntOfInter,
    Eps_Point _PntOfTangency,
    ref Eps_Point _RadiusPoint)
  {
    double _dDirection = 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_PntOfCurve, _PntOfInter, ref _dDirection);
    double _dFirstDir = EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_PntOfTangency, _PntOfInter, ref _dDirection);
    double _dSecondDir = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0);
    EPShared.eplGeoE_IntersectTwoDirs2D(_PntOfCurve, _dFirstDir, _PntOfTangency, _dSecondDir, ref _RadiusPoint, 0.0);
  }

  public static void eplGeoE_RotatePoint(
    ref Eps_Point _Point,
    Eps_Point _ReferencePoint,
    double _dRotation)
  {
    if (_dRotation.Equals(0.0))
      return;
    double _pPolarDirection = 0.0;
    double _pPolarDistance = 0.0;
    EPShared.eplGeoE_CalcXYToPolar(_ReferencePoint, _Point, ref _pPolarDirection, ref _pPolarDistance);
    EPShared.eplGeoE_CalcPolarToXY(_ReferencePoint, _pPolarDirection + _dRotation, _pPolarDistance, ref _Point);
  }

  public static void eplGeoE_CalcXYToPolar(
    Eps_Point _pStartPnt,
    Eps_Point _pSecondPnt,
    ref double _pPolarDirection,
    ref double _pPolarDistance)
  {
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_pStartPnt, _pSecondPnt, ref _pPolarDistance);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_pStartPnt, _pSecondPnt, ref _pPolarDirection);
  }

  public static void eplGeoE_CalcPolarToXYZ(
    Eps_Point _StartPnt,
    double _dHorzPolarDirection,
    double _dVertPolarDirection,
    double _dPolarSlopeDistance,
    ref Eps_Point _NewPnt)
  {
    _NewPnt = new Eps_Point();
    double num = Math.Cos(_dVertPolarDirection) * _dPolarSlopeDistance;
    _NewPnt.x = _StartPnt.x + Math.Cos(_dHorzPolarDirection) * num;
    _NewPnt.y = _StartPnt.y + Math.Sin(_dHorzPolarDirection) * num;
    _NewPnt.z = _StartPnt.z + Math.Sin(_dVertPolarDirection) * _dPolarSlopeDistance;
  }

  public static void eplGeoE_CalcXYZToPolar(
    Eps_Point _StartPnt,
    Eps_Point _EndPnt,
    ref double _dHorzPolarDirection,
    ref double _dVertPolarDirection,
    ref double _dPolarSlopeDistance)
  {
    _dHorzPolarDirection = 0.0;
    _dVertPolarDirection = 0.0;
    _dPolarSlopeDistance = 0.0;
    EPShared.eplGeoE_CalcSlopeDistBtwnTwoPnts(_StartPnt, _EndPnt, ref _dPolarSlopeDistance, 1E-05);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_StartPnt, _EndPnt, ref _dHorzPolarDirection);
    EPShared.eplGeoE_CalcVertDirBtwnTwoPnts(_StartPnt, _EndPnt, ref _dVertPolarDirection, 0.0);
  }

  public static int eplGeoE_CalcSlopeDistBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDistance,
    double MinDist)
  {
    double num = _FirstPnt.XYZ.DistanceTo(_SecondPnt.XYZ);
    if (num <= MinDist)
    {
      _dDistance = 0.0;
      return 1113;
    }
    _dDistance = num;
    return 0;
  }

  public static int eplGeoE_CalcVertDirBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDirection,
    double _dMinDist)
  {
    if (EPShared.eplGeoE_ArePntsDuplicates3D(_FirstPnt, _SecondPnt, _dMinDist))
      return 1113;
    double y = _SecondPnt.z - _FirstPnt.z;
    double x = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(_FirstPnt.x, _FirstPnt.y, _SecondPnt.x, _SecondPnt.y);
    if (y == 0.0 && x == 0.0)
      return 1113;
    _dDirection = Math.Atan2(y, x);
    return 0;
  }

  public static int eplGeoE_CalcTangentInDirOfArc(Eps_Arc _Arc, ref double _dTangentInDir)
  {
    Eps_Point _PIPoint = new Eps_Point();
    Eps_Arc epsArc = new Eps_Arc();
    switch (EPShared.eplGeoE_SolvePIByArcStruct(_Arc, ref _PIPoint))
    {
      case 0:
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.StartPnt, _PIPoint, ref _dTangentInDir);
        break;
      case 1211:
        return 1211;
      case 1212:
        Eps_Arc _ArcStruct = _Arc;
        if (_Arc.Direction == -1)
          _ArcStruct.Direction = 1;
        else
          _ArcStruct.Direction = -1;
        _ArcStruct.Delta = 2.0 * Math.PI - _Arc.Delta;
        EPShared.eplGeoE_SolvePIByArcStruct(_ArcStruct, ref _PIPoint);
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.StartPnt, _PIPoint, ref _dTangentInDir);
        break;
      default:
        return 1;
    }
    return 0;
  }

  public static int eplGeoE_SolvePIByArcStruct(Eps_Arc _ArcStruct, ref Eps_Point _PIPoint)
  {
    double _dDirection = 0.0;
    if (Math.Abs(_ArcStruct.Delta - Math.PI) < 1E-10)
      return 1211;
    if (_ArcStruct.Delta > Math.PI)
      return 1212;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_ArcStruct.RadiusPnt, _ArcStruct.StartPnt, ref _dDirection);
    double _dPolarDirection = _ArcStruct.Direction != -1 ? _dDirection + _ArcStruct.Delta / 2.0 : _dDirection - _ArcStruct.Delta / 2.0;
    double num = EPShared.eplGeoE_SolveExternByRadiusAndDelta(_ArcStruct.Radius, _ArcStruct.Delta);
    EPShared.eplGeoE_CalcPolarToXY(_ArcStruct.RadiusPnt, _dPolarDirection, _ArcStruct.Radius + num, ref _PIPoint);
    return 0;
  }

  public static double eplGeoE_SolveExternByRadiusAndDelta(double _dRadius, double _dDeltaAngle)
  {
    return Math.Abs(_dDeltaAngle - Math.PI) >= 1E-10 ? Math.Abs(_dRadius * (1.0 / Math.Cos(_dDeltaAngle / 2.0) - 1.0)) : 0.0;
  }

  public static int eplGeoE_CalcTangentOutDirOfArc(Eps_Arc _Arc, ref double _dTangentOutDir)
  {
    Eps_Point _PIPoint = new Eps_Point();
    Eps_Arc epsArc = new Eps_Arc();
    switch (EPShared.eplGeoE_SolvePIByArcStruct(_Arc, ref _PIPoint))
    {
      case 0:
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_PIPoint, _Arc.EndPnt, ref _dTangentOutDir);
        break;
      case 1211:
        return 1211;
      case 1212:
        Eps_Arc _ArcStruct = _Arc;
        if (_Arc.Direction == -1)
          _ArcStruct.Direction = 1;
        else
          _ArcStruct.Direction = -1;
        _ArcStruct.Delta = 2.0 * Math.PI - _Arc.Delta;
        EPShared.eplGeoE_SolvePIByArcStruct(_ArcStruct, ref _PIPoint);
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_PIPoint, _ArcStruct.EndPnt, ref _dTangentOutDir);
        break;
      default:
        return 1;
    }
    return 0;
  }

  public static void eplGeoE_CalcArcChordArea(Eps_Arc _Arc, ref double _dChordArea)
  {
    double _dDirection = 0.0;
    double _dDistance1 = 0.0;
    Eps_Point _NewPnt = new Eps_Point();
    double _dDistance2 = 0.0;
    double num1 = _Arc.Delta / 2.0 * Math.Pow(_Arc.Radius, 2.0);
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Arc.StartPnt, _Arc.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Arc.StartPnt, _Arc.EndPnt, ref _dDistance1);
    EPShared.eplGeoE_CalcPolarToXY(_Arc.StartPnt, _dDirection, _dDistance1 / 2.0, ref _NewPnt);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_NewPnt, _Arc.RadiusPnt, ref _dDistance2);
    double num2 = _dDistance1 * _dDistance2 / 2.0;
    _dChordArea = _Arc.Delta <= Math.PI ? num1 - num2 : num1 + num2;
    if (_Arc.Direction != -1)
      return;
    _dChordArea = -_dChordArea;
  }

  public static double eplCalE_fmod(double _dFirstOperand, double _dSecondOperand)
  {
    return EPShared.eplCalE_fmod(_dFirstOperand, _dSecondOperand, 1E-05);
  }

  public static double eplCalE_fmod(
    double _dFirstOperand,
    double _dSecondOperand,
    double _dTolerance)
  {
    double _dX;
    if (RevitDefines.EQ(_dSecondOperand, 0.0, _dTolerance))
    {
      _dX = 0.0;
    }
    else
    {
      _dX = _dFirstOperand % _dSecondOperand;
      if (Math.Abs(Math.Abs(_dX) - Math.Abs(_dSecondOperand)) < _dTolerance || RevitDefines.EQ(_dX, 0.0, _dTolerance))
        _dX = 0.0;
    }
    return _dX;
  }

  public static double eplCalE_RoundValue(double _dValue, int _nPrecision)
  {
    return Math.Round(_dValue, _nPrecision);
  }

  public static double eplCalE_CalcComponentKOfCrossProduct(
    Eps_Point _FirstPoint,
    Eps_Point _SecondPoint)
  {
    return _FirstPoint.x * _SecondPoint.y - _SecondPoint.x * _FirstPoint.y;
  }

  public static bool eplGeoE_IsLegListInsideLegList(
    Eps_Line[] _aTestLines,
    int _nTestLineCount,
    Eps_Arc[] _aTestArcs,
    int _nTestArcCount,
    int[] _aTestLegOrder,
    Eps_Line[] _aLines,
    int _nLineCount,
    Eps_Arc[] _aArcs,
    int _nArcCount,
    int[] _aLegOrder,
    double _dTolerance)
  {
    Eps_Leg _LegList1 = (Eps_Leg) null;
    Eps_Leg _LegList2 = (Eps_Leg) null;
    int index1 = 0;
    int index2 = 0;
    for (int index3 = 0; index3 < _nTestLineCount + _nTestArcCount; ++index3)
    {
      if (_aTestLegOrder[index3] == 0)
      {
        EPShared.eplDsmE_AddLineToLegList(_aTestLines[index1], ref _LegList1);
        ++index1;
      }
      else if (_aTestLegOrder[index3] == 1)
      {
        EPShared.eplDsmE_AddArcToLegList(_aTestArcs[index2], ref _LegList1);
        ++index2;
      }
    }
    int index4 = 0;
    int index5 = 0;
    for (int index6 = 0; index6 < _nLineCount + _nArcCount; ++index6)
    {
      if (_aLegOrder[index6] == 0)
      {
        EPShared.eplDsmE_AddLineToLegList(_aLines[index4], ref _LegList2);
        ++index4;
      }
      else if (_aLegOrder[index6] == 1)
      {
        EPShared.eplDsmE_AddArcToLegList(_aArcs[index5], ref _LegList2);
        ++index5;
      }
    }
    return EPShared.eplGeoE_IsLegListInsideLegList(_LegList1, _LegList2, _dTolerance);
  }

  public static bool eplGeoE_IsLegListInsideLegList(
    Eps_Leg _pTestLegList,
    Eps_Leg _pLegList,
    double _dTolerance)
  {
    bool flag = true;
    Eps_Leg epsLeg1 = new Eps_Leg();
    Eps_Point _Point = new Eps_Point();
    double _dDirection = 0.0;
    if (_pTestLegList == null || _pLegList == null)
      return false;
    if (!EPShared.eplGeoE_DoLegListsIntersect(_pTestLegList, _pLegList, _dTolerance))
    {
      for (Eps_Leg epsLeg2 = _pTestLegList; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
      {
        if (epsLeg2.Line != null)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg2.Line.StartPnt, epsLeg2.Line.EndPnt, _dTolerance))
            _Point = epsLeg2.Line.StartPnt;
          else
            EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLeg2.Line.StartPnt, epsLeg2.Line.EndPnt, ref _Point);
        }
        else if (epsLeg2.Arc != null)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg2.Arc.StartPnt, epsLeg2.Arc.EndPnt, _dTolerance))
          {
            if (EPShared.eplGeoE_ArePntsDuplicates2D(epsLeg2.Arc.StartPnt, epsLeg2.Arc.RadiusPnt, _dTolerance))
            {
              _Point = epsLeg2.Arc.StartPnt;
            }
            else
            {
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg2.Arc.StartPnt, epsLeg2.Arc.RadiusPnt, ref _dDirection);
              EPShared.eplGeoE_CalcPolarToXY(epsLeg2.Arc.RadiusPnt, _dDirection, epsLeg2.Arc.Radius, ref _Point);
            }
          }
          else
            EPShared.eplGeoE_SolveMidPntByArcStruct(epsLeg2.Arc, ref _Point);
        }
        else
          continue;
        if (EPShared.eplGeoE_IsPointInsideLegList(_pLegList, _Point, _dTolerance, (Eps_Point) null, (Eps_Point) null) == 6)
        {
          flag = false;
          break;
        }
      }
    }
    else
      flag = false;
    return flag;
  }

  public static bool eplGeoE_DoLegListsIntersect(
    Eps_Leg _pLeg1,
    Eps_Leg _pLeg2,
    double _dTolerance)
  {
    Eps_Point[] _IntPoints = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int _nNumberOfIntersections = 0;
    return EPShared.DoLegsIntersect(_pLeg1, _pLeg2, ref _IntPoints, ref _nNumberOfIntersections, _dTolerance);
  }

  public static bool DoLegsIntersect(
    Eps_Leg _Leg1,
    Eps_Leg _Leg2,
    ref Eps_Point[] _IntPoints,
    ref int _nNumberOfIntersections,
    double _dTolerance)
  {
    _IntPoints = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    Eps_Leg epsLeg1 = new Eps_Leg();
    Eps_Leg epsLeg2 = new Eps_Leg();
    for (Eps_Leg epsLeg3 = _Leg1; epsLeg3 != null; epsLeg3 = epsLeg3.Next)
    {
      for (Eps_Leg epsLeg4 = _Leg2; epsLeg4 != null; epsLeg4 = epsLeg4.Next)
      {
        if (epsLeg3.Line != null)
        {
          if (epsLeg4.Line != null)
          {
            if (EPShared.DoLinesIntersect(epsLeg3.Line, epsLeg4.Line, ref _IntPoints, ref _nNumberOfIntersections, _dTolerance))
              return true;
          }
          else if (epsLeg4.Arc != null && EPShared.DoesLineArcIntersect(epsLeg3.Line, epsLeg4.Arc, ref _IntPoints, ref _nNumberOfIntersections, _dTolerance))
            return true;
        }
        else if (epsLeg3.Arc != null)
        {
          if (epsLeg4.Line != null)
          {
            if (EPShared.DoesLineArcIntersect(epsLeg4.Line, epsLeg3.Arc, ref _IntPoints, ref _nNumberOfIntersections, _dTolerance))
              return true;
          }
          else if (epsLeg4.Arc != null && EPShared.DoArcsIntersect(epsLeg3.Arc, epsLeg4.Arc, ref _IntPoints, ref _nNumberOfIntersections, _dTolerance))
            return true;
        }
      }
    }
    return false;
  }

  public static bool DoLinesIntersect(
    Eps_Line _Line1,
    Eps_Line _Line2,
    ref Eps_Point[] _IntPoints,
    ref int _nNumberOfIntersections,
    double _dTolerance)
  {
    return EPShared.eplGeoE_IntersectTwoLines(_Line1, _Line2, ref _IntPoints, ref _nNumberOfIntersections, _dTolerance) == 1606;
  }

  public static bool DoesLineArcIntersect(
    Eps_Line _Line,
    Eps_Arc _Arc,
    ref Eps_Point[] _IntPoints,
    ref int _nNumberOfIntersections,
    double _dTolerance)
  {
    _nNumberOfIntersections = 0;
    switch (EPShared.eplGeoE_IntersectLineArc(_Line, _Arc, ref _IntPoints, _dTolerance))
    {
      case 1606:
        if (EPShared.eplGeoE_ArePntsDuplicates2D(_Line.StartPnt, _IntPoints[0], _dTolerance) || EPShared.eplGeoE_ArePntsDuplicates2D(_Line.EndPnt, _IntPoints[0], _dTolerance))
          return false;
        _nNumberOfIntersections = 1;
        return true;
      case 1607:
        _nNumberOfIntersections = 2;
        if (EPShared.eplGeoE_ArePntsDuplicates2D(_Line.StartPnt, _IntPoints[0], _dTolerance) || EPShared.eplGeoE_ArePntsDuplicates2D(_Line.EndPnt, _IntPoints[0], _dTolerance))
        {
          _IntPoints[0] = _IntPoints[1];
          --_nNumberOfIntersections;
        }
        if (EPShared.eplGeoE_ArePntsDuplicates2D(_Line.StartPnt, _IntPoints[1], _dTolerance) || EPShared.eplGeoE_ArePntsDuplicates2D(_Line.EndPnt, _IntPoints[1], _dTolerance))
        {
          _IntPoints[1] = _IntPoints[0];
          --_nNumberOfIntersections;
        }
        return _nNumberOfIntersections > 0;
      default:
        return false;
    }
  }

  public static bool DoArcsIntersect(
    Eps_Arc _Arc1,
    Eps_Arc _Arc2,
    ref Eps_Point[] _IntPoints,
    ref int _nNumberOfIntersections,
    double _dTolerance)
  {
    _nNumberOfIntersections = 0;
    switch (EPShared.eplGeoE_IntersectTwoArcs2D(_Arc1, _Arc2, ref _IntPoints, _dTolerance))
    {
      case 1606:
        _nNumberOfIntersections = 1;
        return true;
      case 1607:
      case 1608:
        _nNumberOfIntersections = 2;
        return true;
      default:
        return false;
    }
  }

  public static int eplGeoE_IntersectTwoArcs2D(
    Eps_Arc _ArcOne,
    Eps_Arc _ArcTwo,
    ref Eps_Point[] _InterPnt,
    double _dPointTolerance)
  {
    Eps_Point[] _InterPnt1 = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int num1 = 1600;
    Eps_Line[] epsLineArray = new Eps_Line[2]
    {
      new Eps_Line(),
      new Eps_Line()
    };
    epsLineArray[0].StartPnt = epsLineArray[0].EndPnt = _ArcOne.RadiusPnt;
    epsLineArray[0].StartPnt.x -= _ArcOne.Radius;
    epsLineArray[0].EndPnt.x += _ArcOne.Radius;
    epsLineArray[0].StartPnt.y -= _ArcOne.Radius;
    epsLineArray[0].EndPnt.y += _ArcOne.Radius;
    epsLineArray[1].StartPnt = epsLineArray[1].EndPnt = _ArcTwo.RadiusPnt;
    epsLineArray[1].StartPnt.x -= _ArcTwo.Radius;
    epsLineArray[1].EndPnt.x += _ArcTwo.Radius;
    epsLineArray[1].StartPnt.y -= _ArcTwo.Radius;
    epsLineArray[1].EndPnt.y += _ArcTwo.Radius;
    if (!EPShared.eplGeoE_DoBoundingBoxesOverlap(epsLineArray[0], epsLineArray[1], _dPointTolerance))
      return num1;
    _InterPnt[0].z = _ArcOne.StartPnt.z;
    _InterPnt[1].z = _ArcOne.StartPnt.z;
    int num2 = EPShared.eplGeoE_FindCommonEndPntsOnArcs2D(_ArcOne, _ArcTwo, ref _InterPnt, _dPointTolerance);
    switch (num2)
    {
      case 1209:
        num2 = 1600;
        break;
      case 1604:
      case 1613:
        return num2;
    }
    int num3 = EPShared.ChkIfArcsOverlapOrWithIn2D(_ArcOne, _ArcTwo, ref _InterPnt, _dPointTolerance);
    if (num3 != 1609)
      return num3;
    bool flag1 = EPShared.eplGeoE_IsPointOnArc2D(_ArcOne.StartPnt, _ArcTwo, _dPointTolerance);
    bool flag2 = EPShared.eplGeoE_IsPointOnArc2D(_ArcOne.EndPnt, _ArcTwo, _dPointTolerance);
    bool flag3 = EPShared.eplGeoE_IsPointOnArc2D(_ArcTwo.StartPnt, _ArcOne, _dPointTolerance);
    bool flag4 = EPShared.eplGeoE_IsPointOnArc2D(_ArcTwo.EndPnt, _ArcOne, _dPointTolerance);
    if (num2 == 1612)
    {
      bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.StartPnt, _ArcTwo.StartPnt, _dPointTolerance);
      bool flag6 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.EndPnt, _ArcTwo.EndPnt, _dPointTolerance);
      bool flag7 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.StartPnt, _ArcTwo.EndPnt, _dPointTolerance);
      bool flag8 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.EndPnt, _ArcTwo.StartPnt, _dPointTolerance);
      if (flag5)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        if (flag2)
        {
          _InterPnt[1] = _ArcOne.EndPnt;
          return 1607;
        }
        if (flag4)
        {
          _InterPnt[1] = _ArcTwo.EndPnt;
          return 1607;
        }
      }
      if (flag6)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        if (flag1)
        {
          _InterPnt[1] = _ArcOne.StartPnt;
          return 1607;
        }
        if (flag3)
        {
          _InterPnt[1] = _ArcTwo.StartPnt;
          return 1607;
        }
      }
      if (flag7)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        if (flag2)
        {
          _InterPnt[1] = _ArcOne.EndPnt;
          return 1607;
        }
        if (flag3)
        {
          _InterPnt[1] = _ArcTwo.StartPnt;
          return 1607;
        }
      }
      if (flag8)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        if (flag1)
        {
          _InterPnt[1] = _ArcOne.StartPnt;
          return 1607;
        }
        if (flag4)
        {
          _InterPnt[1] = _ArcTwo.EndPnt;
          return 1607;
        }
      }
    }
    if (num2 != 1612)
    {
      if (flag1 & flag2)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcOne.EndPnt;
        return 1607;
      }
      if (flag3 & flag4)
      {
        _InterPnt[0] = _ArcTwo.StartPnt;
        _InterPnt[1] = _ArcTwo.EndPnt;
        return 1607;
      }
      if (flag1 & flag3)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcTwo.StartPnt;
        return 1607;
      }
      if (flag1 & flag4)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcTwo.EndPnt;
        return 1607;
      }
      if (flag2 & flag3)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        _InterPnt[1] = _ArcTwo.StartPnt;
        return 1607;
      }
      if (flag2 & flag4)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        _InterPnt[1] = _ArcTwo.EndPnt;
        return 1607;
      }
      if (flag1)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        num2 = 1606;
      }
      else if (flag2)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        num2 = 1606;
      }
      else if (flag3)
      {
        _InterPnt[0] = _ArcTwo.StartPnt;
        num2 = 1606;
      }
      else if (flag4)
      {
        _InterPnt[0] = _ArcTwo.EndPnt;
        num2 = 1606;
      }
    }
    int num4 = num2;
    switch (EPShared.eplGeoE_IntersectTwoDists2D(_ArcOne.RadiusPnt, _ArcOne.Radius, _ArcTwo.RadiusPnt, _ArcTwo.Radius, ref _InterPnt1, 0.0))
    {
      case 1606:
        switch (num2)
        {
          case 1600:
            if (EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _ArcOne, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _ArcTwo, _dPointTolerance))
            {
              _InterPnt[0] = _InterPnt1[0];
              return 1606;
            }
            break;
          case 1606:
            return 1606;
          case 1612:
            return 1612;
        }
        break;
      case 1607:
        if (num2 == 1600)
        {
          if (EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _ArcOne, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _ArcTwo, _dPointTolerance))
          {
            _InterPnt[0] = _InterPnt1[0];
            num4 = num2 != 1612 ? 1606 : 1612;
          }
          if (EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[1], _ArcOne, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[1], _ArcTwo, _dPointTolerance))
          {
            if (num4 != 1606)
            {
              _InterPnt[0] = _InterPnt1[1];
              num4 = num2 != 1612 ? 1606 : 1612;
            }
            else
            {
              _InterPnt[1] = _InterPnt1[1];
              num4 = 1607;
            }
          }
          return num4;
        }
        if (!EPShared.eplGeoE_ArePntsDuplicates2D(_InterPnt[0], _InterPnt1[0], _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _ArcOne, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _ArcTwo, _dPointTolerance))
        {
          _InterPnt[1] = _InterPnt1[0];
          return 1607;
        }
        if (EPShared.eplGeoE_ArePntsDuplicates2D(_InterPnt[0], _InterPnt1[1], _dPointTolerance) || !EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[1], _ArcOne, _dPointTolerance) || !EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[1], _ArcTwo, _dPointTolerance))
          return num4;
        _InterPnt[1] = _InterPnt1[1];
        return 1607;
      default:
        num4 = 1600;
        break;
    }
    return num4;
  }

  public static int ChkIfArcsOverlapOrWithIn2D(
    Eps_Arc _ArcOne,
    Eps_Arc _ArcTwo,
    ref Eps_Point[] _InterPnt,
    double _dPointTolerance)
  {
    int num = 1600;
    _InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _InterPnt[0].z = _ArcOne.StartPnt.z;
    _InterPnt[1].z = _ArcOne.StartPnt.z;
    bool flag1 = _ArcOne.Direction == _ArcTwo.Direction;
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.StartPnt, _ArcTwo.StartPnt, _dPointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.EndPnt, _ArcTwo.EndPnt, _dPointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.StartPnt, _ArcTwo.EndPnt, _dPointTolerance);
    bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.EndPnt, _ArcTwo.StartPnt, _dPointTolerance);
    if (flag2 || flag4 || flag5 || flag3)
      num = 1612;
    bool flag6 = EPShared.eplGeoE_IsPointOnArc2D(_ArcOne.StartPnt, _ArcTwo, _dPointTolerance);
    bool flag7 = EPShared.eplGeoE_IsPointOnArc2D(_ArcOne.EndPnt, _ArcTwo, _dPointTolerance);
    bool flag8 = EPShared.eplGeoE_IsPointOnArc2D(_ArcTwo.StartPnt, _ArcOne, _dPointTolerance);
    bool flag9 = EPShared.eplGeoE_IsPointOnArc2D(_ArcTwo.EndPnt, _ArcOne, _dPointTolerance);
    if (EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.RadiusPnt, _ArcTwo.RadiusPnt, _dPointTolerance) && Math.Abs(_ArcOne.Radius - _ArcTwo.Radius) <= 1E-05)
    {
      if (_ArcOne.Delta + _ArcTwo.Delta > 2.0 * Math.PI && flag6 && flag7 && flag8 && flag9)
      {
        if (_ArcOne.Delta > _ArcTwo.Delta)
        {
          _InterPnt[0] = _ArcOne.StartPnt;
          _InterPnt[1] = _ArcOne.EndPnt;
        }
        else
        {
          _InterPnt[0] = _ArcTwo.StartPnt;
          _InterPnt[1] = _ArcTwo.EndPnt;
        }
        return num == 1612 ? 1619 : 1620;
      }
      if (num == 1612)
      {
        if (flag2)
        {
          if (flag7)
          {
            _InterPnt[1] = _ArcOne.EndPnt;
            return 1618;
          }
          if (!flag9)
            return 1612;
          _InterPnt[1] = _ArcTwo.EndPnt;
          return 1618;
        }
        if (flag3)
        {
          if (flag6)
          {
            _InterPnt[1] = _ArcOne.StartPnt;
            return 1618;
          }
          if (!flag8)
            return 1612;
          _InterPnt[1] = _ArcTwo.StartPnt;
          return 1618;
        }
        if (flag4)
        {
          if (flag7)
          {
            _InterPnt[1] = _ArcOne.EndPnt;
            return 1618;
          }
          if (!flag8)
            return 1612;
          _InterPnt[1] = _ArcTwo.StartPnt;
          return 1618;
        }
        if (flag5)
        {
          if (flag6)
          {
            _InterPnt[1] = _ArcOne.StartPnt;
            return 1618;
          }
          if (!flag9)
            return 1612;
          _InterPnt[1] = _ArcTwo.EndPnt;
          return 1618;
        }
      }
      if (flag6 && flag7)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcOne.EndPnt;
        return 1610;
      }
      if (flag8 && flag9)
      {
        _InterPnt[0] = _ArcTwo.StartPnt;
        _InterPnt[1] = _ArcTwo.EndPnt;
        return 1611;
      }
      if (flag6 && flag9)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcTwo.EndPnt;
        return 1608;
      }
      if (flag6 && flag8)
      {
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcTwo.StartPnt;
        return 1608;
      }
      if (flag7 && flag8)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        _InterPnt[1] = _ArcTwo.StartPnt;
        return 1608;
      }
      if (flag7 && flag9)
      {
        _InterPnt[0] = _ArcOne.EndPnt;
        _InterPnt[1] = _ArcTwo.EndPnt;
        return 1608;
      }
    }
    return 1609;
  }

  public static int eplGeoE_FindCommonEndPntsOnArcs2D(
    Eps_Arc _ArcOne,
    Eps_Arc _ArcTwo,
    ref Eps_Point[] _InterPnt,
    double _dPointTolerance)
  {
    _InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _InterPnt[0].z = _ArcOne.StartPnt.z;
    _InterPnt[1].z = _ArcOne.StartPnt.z;
    bool flag1 = _ArcOne.Direction == _ArcTwo.Direction;
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.StartPnt, _ArcTwo.StartPnt, _dPointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.EndPnt, _ArcTwo.EndPnt, _dPointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.StartPnt, _ArcTwo.EndPnt, _dPointTolerance);
    bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.EndPnt, _ArcTwo.StartPnt, _dPointTolerance);
    if (flag2 && flag3)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.RadiusPnt, _ArcTwo.RadiusPnt, _dPointTolerance))
      {
        if (flag1)
          return 1604;
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcOne.EndPnt;
        return 1613;
      }
      _InterPnt[0] = _ArcOne.StartPnt;
      _InterPnt[1] = _ArcOne.EndPnt;
      return 1613;
    }
    if (flag4 && flag5)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_ArcOne.RadiusPnt, _ArcTwo.RadiusPnt, _dPointTolerance))
      {
        if (!flag1)
          return 1604;
        _InterPnt[0] = _ArcOne.StartPnt;
        _InterPnt[1] = _ArcOne.EndPnt;
        return 1613;
      }
      _InterPnt[0] = _ArcOne.StartPnt;
      _InterPnt[1] = _ArcOne.EndPnt;
      return 1613;
    }
    if (flag2 || flag4)
    {
      _InterPnt[0] = _ArcOne.StartPnt;
      return 1612;
    }
    if (!flag5 && !flag3)
      return 1209;
    _InterPnt[0] = _ArcOne.EndPnt;
    return 1612;
  }

  public static int eplGeoE_IntersectTwoDists2D(
    Eps_Point _FirstRadiusPnt,
    double _FirstRadiusLen,
    Eps_Point _SecondRadiusPnt,
    double _SecondRadiusLen,
    ref Eps_Point[] _InterPnt,
    double _dTolerance)
  {
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    _InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    double num1 = Math.Abs(_FirstRadiusLen);
    double num2 = Math.Abs(_SecondRadiusLen);
    _InterPnt[0].z = _FirstRadiusPnt.z;
    _InterPnt[1].z = _FirstRadiusPnt.z;
    if (num1 < 1E-05 || num2 < 1E-05)
      return 1602;
    double num3 = Math.Abs(num1 - num2);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstRadiusPnt, _SecondRadiusPnt, ref _dDistance);
    if (_dDistance < _dTolerance && num3 < 1E-05)
      return 1604;
    if (_dDistance < _dTolerance)
      return 1605;
    if (_dDistance + num1 + _dTolerance < num2 || _dDistance + num2 + _dTolerance < num1)
      return 1601;
    if (num1 + num2 + 1E-05 < _dDistance)
      return 1602;
    double d = (_dDistance * _dDistance + num1 * num1 - num2 * num2) / (2.0 * _dDistance * num1);
    double num4 = d < 1.0 ? (d > -1.0 ? EPShared.eplGeoE_NormalizeRadians(Math.Acos(d)) : Math.PI) : 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstRadiusPnt, _SecondRadiusPnt, ref _dDirection);
    Eps_Point _NewPnt = new Eps_Point();
    EPShared.eplGeoE_CalcPolarToXY(_FirstRadiusPnt, _dDirection + num4, _FirstRadiusLen, ref _NewPnt);
    _InterPnt[0] = _NewPnt;
    if (num4 <= 1E-10 || Math.Abs(num4 - Math.PI) <= 1E-10)
      return 1606;
    EPShared.eplGeoE_CalcPolarToXY(_FirstRadiusPnt, _dDirection - num4, _FirstRadiusLen, ref _NewPnt);
    _InterPnt[1] = _NewPnt;
    return 1607;
  }

  public static int eplGeoE_IsPointInsideLegList(
    Eps_Leg _pLeg,
    Eps_Point _Point,
    double _dTolerance,
    Eps_Point _pMinPnt,
    Eps_Point _pMaxPnt)
  {
    Eps_Leg epsLeg1 = new Eps_Leg();
    Eps_Line epsLine = new Eps_Line();
    Eps_Point _pMinPnt1 = new Eps_Point();
    Eps_Point _pMaxPnt1 = new Eps_Point();
    double _dDistance1 = 0.0;
    double _dDistance2 = 0.0;
    int _pNumOfInter = 0;
    int num1 = 0;
    List<double> doubleList = new List<double>();
    Eps_Point _pLegStartPnt = new Eps_Point();
    Eps_Point _pLegEndPnt = new Eps_Point();
    double _dDirection = 0.0;
    int index1 = 0;
    double num2 = 0.0;
    bool flag = false;
    if (_pMinPnt == null || _pMaxPnt == null)
    {
      EPShared.eplGeoE_FindMinMaxOfLegList(_pLeg, ref _pMinPnt1, ref _pMaxPnt1);
    }
    else
    {
      _pMinPnt1 = _pMinPnt;
      _pMaxPnt1 = _pMaxPnt;
    }
    Eps_Point[] epsPointArray = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    if (RevitDefines.LT(_Point.x, _pMinPnt1.x, _dTolerance) || RevitDefines.GT(_Point.x, _pMaxPnt1.x, _dTolerance) || RevitDefines.LT(_Point.y, _pMinPnt1.y, _dTolerance) || RevitDefines.GT(_Point.y, _pMaxPnt1.y, _dTolerance))
      return 6;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_pMinPnt1, _pMaxPnt1, ref _dDistance1);
    for (Eps_Leg _pLeg1 = _pLeg; _pLeg1 != null; _pLeg1 = _pLeg1.Next)
    {
      EPShared.eplGeoE_GetLegStartAndEndPoints(_pLeg1, ref _pLegStartPnt, ref _pLegEndPnt);
      if (RevitDefines.EQ(_pLegStartPnt.y, _Point.y) || RevitDefines.EQ(_pLegEndPnt.y, _Point.y))
      {
        flag = true;
        break;
      }
    }
    double _dPolarDirection;
    if (flag)
    {
      for (Eps_Leg _pLeg2 = _pLeg; _pLeg2 != null; _pLeg2 = _pLeg2.Next)
      {
        EPShared.eplGeoE_GetLegStartAndEndPoints(_pLeg2, ref _pLegStartPnt, ref _pLegEndPnt);
        if (_pLeg2 == _pLeg)
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Point, _pLegStartPnt, ref _dDirection);
          if (!doubleList.Contains(_dDirection))
            doubleList.Add(_dDirection);
        }
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Point, _pLegEndPnt, ref _dDirection);
        if (!doubleList.Contains(_dDirection))
          doubleList.Add(_dDirection);
      }
      doubleList.Sort();
      for (int index2 = 0; index2 < doubleList.Count - 1; ++index2)
      {
        double num3 = doubleList[index2 + 1] - doubleList[index2];
        if (index2 == 0 || num3 > num2)
        {
          num2 = num3;
          index1 = index2;
        }
      }
      _dPolarDirection = (doubleList[index1 + 1] - doubleList[index1]) / 2.0;
    }
    else
      _dPolarDirection = 0.0;
    epsLine.StartPnt = _Point;
    Eps_Point _NewPnt = new Eps_Point();
    EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, _dPolarDirection, _dDistance1 * 2.0, ref _NewPnt);
    epsLine.EndPnt = _NewPnt;
    for (Eps_Leg epsLeg2 = _pLeg; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      if (epsLeg2.Line != null)
      {
        if (EPShared.eplGeoE_IsPointOnLine2D(_Point, epsLeg2.Line, _dTolerance))
          return 1903;
        switch (EPShared.eplGeoE_IntersectTwoLines(epsLine, epsLeg2.Line, ref epsPointArray, ref _pNumOfInter, _dTolerance))
        {
          case 1606:
          case 1612:
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(epsPointArray[0], epsLeg2.Line.StartPnt) && !EPShared.eplGeoE_ArePntsDuplicates2D(epsPointArray[0], epsLeg2.Line.EndPnt))
            {
              ++num1;
              continue;
            }
            continue;
          case 1608:
          case 1610:
          case 1611:
            num1 += 2;
            continue;
          default:
            continue;
        }
      }
      else if (epsLeg2.Arc != null)
      {
        if (EPShared.eplGeoE_IsPointOnArc2D(_Point, epsLeg2.Arc, _dTolerance))
          return 1903;
        switch (EPShared.eplGeoE_IntersectLineArc(epsLine, epsLeg2.Arc, ref epsPointArray, 0.0))
        {
          case 1606:
            EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Point, epsLeg2.Arc.RadiusPnt, ref _dDistance2);
            if (RevitDefines.LT(_dDistance2, epsLeg2.Arc.Radius))
            {
              ++num1;
              continue;
            }
            continue;
          case 1607:
            num1 += 2;
            continue;
          default:
            continue;
        }
      }
    }
    return num1 % 2 == 1 ? 0 : 6;
  }

  public static int eplGeoE_IntersectTwoLines(
    Eps_Line _pLineOne,
    Eps_Line _pLineTwo,
    ref Eps_Point[] _aInterPnt,
    ref int _pNumOfInter,
    double _dPointTolerance)
  {
    int num1 = 1600;
    _aInterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _pNumOfInter = 0;
    if (!EPShared.eplGeoE_DoBoundingBoxesOverlap(_pLineOne, _pLineTwo, _dPointTolerance))
      return num1;
    double num2 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(_pLineOne.StartPnt.x, _pLineOne.StartPnt.y, _pLineOne.EndPnt.x, _pLineOne.EndPnt.y);
    double num3 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(_pLineTwo.StartPnt.x, _pLineTwo.StartPnt.y, _pLineTwo.EndPnt.x, _pLineTwo.EndPnt.y);
    if (num2 <= _dPointTolerance)
    {
      if (num3 <= _dPointTolerance)
        num1 = 1604;
      else if (EPShared.eplGeoE_IsPointOnLine2D(_pLineOne.StartPnt, _pLineTwo, _dPointTolerance))
      {
        _aInterPnt[0] = _aInterPnt[1] = _pLineOne.StartPnt;
        num1 = 1610;
      }
      return num1;
    }
    if (num3 <= _dPointTolerance)
    {
      if (EPShared.eplGeoE_IsPointOnLine2D(_pLineTwo.StartPnt, _pLineOne, _dPointTolerance))
      {
        _aInterPnt[0] = _aInterPnt[1] = _pLineTwo.StartPnt;
        num1 = 1611;
      }
      return num1;
    }
    int num4 = EPShared.eplGeoE_InterBoundedLineLine(_pLineOne, _pLineTwo, ref _aInterPnt, _dPointTolerance);
    switch (num4)
    {
      case 1111:
        num4 = EPShared.eplGeoE_InterColinearBoundedLineLine(_pLineOne, _pLineTwo, ref _aInterPnt, ref _pNumOfInter, _dPointTolerance);
        break;
      case 1606:
        _pNumOfInter = 1;
        switch (EPShared.CheckLinesForCommonEndPnts(_pLineOne, _pLineTwo, _dPointTolerance))
        {
          case 1614:
          case 1615:
          case 1616:
          case 1617:
            num4 = 1612;
            break;
        }
        break;
    }
    return num4;
  }

  public static int eplGeoE_InterColinearBoundedLineLine(
    Eps_Line _pLineOne,
    Eps_Line _pLineTwo,
    ref Eps_Point[] _aInterPnt,
    ref int _pNumOfInter,
    double _dPointTolerance)
  {
    int num = 1600;
    _pNumOfInter = 0;
    _aInterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    switch (EPShared.CheckLinesForCommonEndPnts(_pLineOne, _pLineTwo, _dPointTolerance))
    {
      case 1108:
      case 1109:
        return 1604;
      case 1614:
      case 1616:
        _aInterPnt[_pNumOfInter++] = _pLineOne.StartPnt;
        num = 1612;
        break;
      case 1615:
      case 1617:
        _aInterPnt[_pNumOfInter++] = _pLineOne.EndPnt;
        num = 1612;
        break;
    }
    if (EPShared.eplGeoE_CheckIfLineInsideLine(_pLineOne, _pLineTwo, _dPointTolerance) == 1700)
    {
      _aInterPnt[0] = _pLineOne.StartPnt;
      _aInterPnt[1] = _pLineOne.EndPnt;
      _pNumOfInter = 2;
      num = 1610;
    }
    else if (EPShared.eplGeoE_CheckIfLineInsideLine(_pLineTwo, _pLineOne, _dPointTolerance) == 1700)
    {
      _aInterPnt[0] = _pLineTwo.StartPnt;
      _aInterPnt[1] = _pLineTwo.EndPnt;
      _pNumOfInter = 2;
      num = 1611;
    }
    if (num == 1600)
    {
      if (EPShared.eplGeoE_IsPointOnLine2D(_pLineOne.StartPnt, _pLineTwo, _dPointTolerance))
      {
        _aInterPnt[_pNumOfInter++] = _pLineOne.StartPnt;
        _aInterPnt[_pNumOfInter++] = !EPShared.eplGeoE_IsPointOnLine2D(_pLineTwo.StartPnt, _pLineOne, _dPointTolerance) ? _pLineTwo.EndPnt : _pLineTwo.StartPnt;
        num = 1608;
      }
      else if (EPShared.eplGeoE_IsPointOnLine2D(_pLineOne.EndPnt, _pLineTwo, _dPointTolerance))
      {
        _aInterPnt[_pNumOfInter++] = _pLineOne.EndPnt;
        _aInterPnt[_pNumOfInter++] = !EPShared.eplGeoE_IsPointOnLine2D(_pLineTwo.StartPnt, _pLineOne, _dPointTolerance) ? _pLineTwo.EndPnt : _pLineTwo.StartPnt;
        num = 1608;
      }
    }
    return num;
  }

  public static int CheckLinesForCommonEndPnts(
    Eps_Line _LineOne,
    Eps_Line _LineTwo,
    double _dPointTolerance)
  {
    int num = 1110;
    bool flag1 = EPShared.eplGeoE_ArePntsDuplicates2D(_LineOne.StartPnt, _LineTwo.StartPnt, _dPointTolerance);
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(_LineOne.EndPnt, _LineTwo.EndPnt, _dPointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(_LineOne.StartPnt, _LineTwo.EndPnt, _dPointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(_LineOne.EndPnt, _LineTwo.StartPnt, _dPointTolerance);
    if (flag1 && flag2)
      num = 1108;
    else if (flag3 && flag4)
      num = 1109;
    else if (flag1)
      num = 1614;
    else if (flag2)
      num = 1615;
    else if (flag3)
      num = 1616;
    else if (flag4)
      num = 1617;
    return num;
  }

  public static int eplGeoE_InterBoundedLineLine(
    Eps_Line _pLineOne,
    Eps_Line _pLineTwo,
    ref Eps_Point[] _aInterPnt,
    double _dPointTolerance)
  {
    _aInterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int num1 = 1600;
    double num2 = (_pLineTwo.StartPnt.x - _pLineOne.StartPnt.x) * (_pLineOne.EndPnt.y - _pLineOne.StartPnt.y) - (_pLineOne.EndPnt.x - _pLineOne.StartPnt.x) * (_pLineTwo.StartPnt.y - _pLineOne.StartPnt.y);
    double num3 = (_pLineTwo.EndPnt.x - _pLineOne.StartPnt.x) * (_pLineOne.EndPnt.y - _pLineOne.StartPnt.y) - (_pLineOne.EndPnt.x - _pLineOne.StartPnt.x) * (_pLineTwo.EndPnt.y - _pLineOne.StartPnt.y);
    double num4 = (_pLineOne.StartPnt.x - _pLineTwo.StartPnt.x) * (_pLineTwo.EndPnt.y - _pLineTwo.StartPnt.y) - (_pLineTwo.EndPnt.x - _pLineTwo.StartPnt.x) * (_pLineOne.StartPnt.y - _pLineTwo.StartPnt.y);
    double num5 = (_pLineOne.EndPnt.x - _pLineTwo.StartPnt.x) * (_pLineTwo.EndPnt.y - _pLineTwo.StartPnt.y) - (_pLineTwo.EndPnt.x - _pLineTwo.StartPnt.x) * (_pLineOne.EndPnt.y - _pLineTwo.StartPnt.y);
    double num6 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(_pLineOne.StartPnt.x, _pLineOne.StartPnt.y, _pLineOne.EndPnt.x, _pLineOne.EndPnt.y);
    double num7 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(_pLineTwo.StartPnt.x, _pLineTwo.StartPnt.y, _pLineTwo.EndPnt.x, _pLineTwo.EndPnt.y);
    double num8 = Math.Abs(num2 / num6);
    double num9 = Math.Abs(num3 / num6);
    double num10 = Math.Abs(num4 / num7);
    double num11 = Math.Abs(num5 / num7);
    if (num8 <= _dPointTolerance)
    {
      if (num9 <= _dPointTolerance)
        num1 = 1111;
      else if (EPShared.IsPntInBoundingBoxOfLine(_pLineTwo.StartPnt, _pLineOne, _dPointTolerance))
      {
        _aInterPnt[0] = _pLineTwo.StartPnt;
        num1 = 1606;
      }
      return num1;
    }
    if (num9 <= _dPointTolerance)
    {
      if (EPShared.IsPntInBoundingBoxOfLine(_pLineTwo.EndPnt, _pLineOne, _dPointTolerance))
      {
        _aInterPnt[0] = _pLineTwo.EndPnt;
        num1 = 1606;
      }
      return num1;
    }
    if (num10 <= _dPointTolerance)
    {
      if (EPShared.IsPntInBoundingBoxOfLine(_pLineOne.StartPnt, _pLineTwo, _dPointTolerance))
      {
        _aInterPnt[0] = _pLineOne.StartPnt;
        num1 = 1606;
      }
      return num1;
    }
    if (num11 <= _dPointTolerance)
    {
      if (EPShared.IsPntInBoundingBoxOfLine(_pLineOne.EndPnt, _pLineTwo, _dPointTolerance))
      {
        _aInterPnt[0] = _pLineOne.EndPnt;
        num1 = 1606;
      }
      return num1;
    }
    if ((num2 < 0.0 && num3 > 0.0 || num2 > 0.0 && num3 < 0.0) && (num4 < 0.0 && num5 > 0.0 || num4 > 0.0 && num5 < 0.0))
    {
      Eps_Point _aInterPnt1 = new Eps_Point();
      EPShared.CalculateInterPnt(_pLineOne, _pLineTwo, ref _aInterPnt1);
      _aInterPnt[0] = _aInterPnt1;
      num1 = 1606;
    }
    return num1;
  }

  public static void CalculateInterPnt(
    Eps_Line _pLineOne,
    Eps_Line _pLineTwo,
    ref Eps_Point _aInterPnt)
  {
    Eps_Point _Vector1 = new Eps_Point();
    Eps_Point _Vector2 = new Eps_Point();
    Eps_Point _Vector3 = new Eps_Point();
    EPShared.eplGeoE_MakeVector(_pLineOne.StartPnt, _pLineOne.EndPnt, ref _Vector1);
    EPShared.eplGeoE_MakeVector(_pLineTwo.StartPnt, _pLineTwo.EndPnt, ref _Vector2);
    EPShared.eplGeoE_MakeVector(_pLineOne.StartPnt, _pLineTwo.EndPnt, ref _Vector3);
    double _dX = EPShared.eplCalE_CalcComponentKOfCrossProduct(_Vector1, _Vector2);
    double num1 = EPShared.eplCalE_CalcComponentKOfCrossProduct(_Vector3, _Vector2);
    if (RevitDefines.EQ(_dX, 0.0, 1E-10))
      _dX = 1E-10;
    double num2 = Math.Abs(num1 / _dX);
    _aInterPnt.x = _pLineOne.StartPnt.x + num2 * _Vector1.x;
    _aInterPnt.y = _pLineOne.StartPnt.y + num2 * _Vector1.y;
    _aInterPnt.z = 0.0;
  }

  public static bool IsPntInBoundingBoxOfLine(
    Eps_Point _pPoint,
    Eps_Line _pLine,
    double _dTolerance)
  {
    return !RevitDefines.LT(Math.Max(_pLine.StartPnt.x, _pLine.EndPnt.x), _pPoint.x, _dTolerance) && !RevitDefines.GT(Math.Min(_pLine.StartPnt.x, _pLine.EndPnt.x), _pPoint.x, _dTolerance) && !RevitDefines.LT(Math.Max(_pLine.StartPnt.y, _pLine.EndPnt.y), _pPoint.y, _dTolerance) && !RevitDefines.GT(Math.Min(_pLine.StartPnt.y, _pLine.EndPnt.y), _pPoint.y, _dTolerance);
  }

  public static int eplGeoE_IntersectLineArc(
    Eps_Line _Line,
    Eps_Arc _Arc,
    ref Eps_Point[] _InterPnt,
    double _dPointTolerance)
  {
    double _dDirection = 0.0;
    int num1 = 1600;
    int num2 = 1600;
    Eps_Line _LineTwo = new Eps_Line();
    _LineTwo.StartPnt = _LineTwo.EndPnt = _Arc.RadiusPnt;
    _LineTwo.StartPnt.x -= _Arc.Radius;
    _LineTwo.EndPnt.x += _Arc.Radius;
    _LineTwo.StartPnt.y -= _Arc.Radius;
    _LineTwo.EndPnt.y += _Arc.Radius;
    if (!EPShared.eplGeoE_DoBoundingBoxesOverlap(_Line, _LineTwo, _dPointTolerance))
      return num1;
    Eps_Point[] _InterPnt1 = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _InterPnt[0].z = _Line.StartPnt.z;
    _InterPnt[1].z = _Line.StartPnt.z;
    bool flag1 = EPShared.eplGeoE_ArePntsDuplicates2D(_Line.StartPnt, _Arc.StartPnt, _dPointTolerance);
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(_Line.EndPnt, _Arc.EndPnt, _dPointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(_Line.StartPnt, _Arc.EndPnt, _dPointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(_Line.EndPnt, _Arc.StartPnt, _dPointTolerance);
    if (flag1 && flag2 || flag3 && flag4)
    {
      _InterPnt[0] = _Line.StartPnt;
      _InterPnt[1] = _Line.EndPnt;
      return 1613;
    }
    bool flag5 = EPShared.eplGeoE_IsPointOnArc2D(_Line.StartPnt, _Arc, _dPointTolerance);
    bool flag6 = EPShared.eplGeoE_IsPointOnArc2D(_Line.EndPnt, _Arc, _dPointTolerance);
    bool flag7 = EPShared.eplGeoE_IsPointOnLine2D(_Arc.StartPnt, _Line, _dPointTolerance);
    bool flag8 = EPShared.eplGeoE_IsPointOnLine2D(_Arc.EndPnt, _Line, _dPointTolerance);
    if (flag1 || flag3)
    {
      _InterPnt[0] = _Line.StartPnt;
      num2 = 1612;
      if (flag6)
      {
        _InterPnt[1] = _Line.EndPnt;
        return 1607;
      }
      if (flag1)
      {
        if (flag8)
        {
          _InterPnt[1] = _Arc.EndPnt;
          return 1607;
        }
      }
      else if (flag7)
      {
        _InterPnt[1] = _Arc.StartPnt;
        return 1607;
      }
    }
    if (num2 == 1600 && (flag2 || flag4))
    {
      _InterPnt[0] = _Line.EndPnt;
      num2 = 1612;
      if (flag5)
      {
        _InterPnt[1] = _Line.StartPnt;
        return 1607;
      }
      if (flag2)
      {
        if (flag7)
        {
          _InterPnt[1] = _Arc.StartPnt;
          return 1607;
        }
      }
      else if (flag8)
      {
        _InterPnt[1] = _Arc.EndPnt;
        return 1607;
      }
    }
    if (num2 == 1600)
    {
      if (flag6)
      {
        _InterPnt[0] = _Line.EndPnt;
        num2 = 1606;
        if (flag7)
        {
          _InterPnt[1] = _Arc.StartPnt;
          return 1607;
        }
        if (flag8)
        {
          _InterPnt[1] = _Arc.EndPnt;
          return 1607;
        }
      }
      if (flag5)
      {
        if (num2 == 1606)
        {
          _InterPnt[1] = _Line.StartPnt;
          return 1607;
        }
        _InterPnt[0] = _Line.StartPnt;
        num2 = 1606;
        if (flag7)
        {
          _InterPnt[1] = _Arc.StartPnt;
          return 1607;
        }
        if (flag8)
        {
          _InterPnt[1] = _Arc.EndPnt;
          return 1607;
        }
      }
    }
    if (num2 == 1600)
    {
      if (flag7 && flag8)
      {
        _InterPnt[0] = _Arc.StartPnt;
        _InterPnt[1] = _Arc.EndPnt;
        return 1607;
      }
      if (flag7)
      {
        _InterPnt[0] = _Arc.StartPnt;
        num2 = 1606;
      }
      else if (flag8)
      {
        _InterPnt[0] = _Arc.EndPnt;
        num2 = 1606;
      }
    }
    int num3 = num2;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    double radius = _Arc.Radius;
    switch (EPShared.eplGeoE_IntersectDirDist2D(_Line.StartPnt, _dDirection, _Arc.RadiusPnt, radius, ref _InterPnt1, 0.0))
    {
      case 1606:
        switch (num2)
        {
          case 1600:
            if (EPShared.eplGeoE_IsPointOnLine2D(_InterPnt1[0], _Line, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _Arc, _dPointTolerance))
            {
              _InterPnt[0] = _InterPnt1[0];
              return 1606;
            }
            break;
          case 1606:
            return 1606;
          case 1612:
            return 1612;
        }
        break;
      case 1607:
        if (num2 == 1600)
        {
          if (EPShared.eplGeoE_IsPointOnLine2D(_InterPnt1[0], _Line, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _Arc, _dPointTolerance))
          {
            _InterPnt[0] = _InterPnt1[0];
            num3 = 1606;
          }
          if (EPShared.eplGeoE_IsPointOnLine2D(_InterPnt1[1], _Line, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[1], _Arc, _dPointTolerance))
          {
            if (num3 != 1606)
            {
              _InterPnt[0] = _InterPnt1[1];
              num3 = num2 != 1612 ? 1606 : 1612;
            }
            else
            {
              _InterPnt[1] = _InterPnt1[1];
              num3 = 1607;
            }
          }
          return num3;
        }
        if (!EPShared.eplGeoE_ArePntsDuplicates2D(_InterPnt[0], _InterPnt1[0], _dPointTolerance) && EPShared.eplGeoE_IsPointOnLine2D(_InterPnt1[0], _Line, _dPointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[0], _Arc, _dPointTolerance))
        {
          _InterPnt[1] = _InterPnt1[0];
          return 1607;
        }
        if (EPShared.eplGeoE_ArePntsDuplicates2D(_InterPnt[0], _InterPnt1[1], _dPointTolerance) || !EPShared.eplGeoE_IsPointOnLine2D(_InterPnt1[1], _Line, _dPointTolerance) || !EPShared.eplGeoE_IsPointOnArc2D(_InterPnt1[1], _Arc, _dPointTolerance))
          return num3;
        _InterPnt[1] = _InterPnt1[1];
        return 1607;
    }
    return num3;
  }

  public static int eplGeoE_IntersectDirDist2D(
    Eps_Point _FirstPnt,
    double _dDirOfFirstPnt,
    Eps_Point _RadiusPnt,
    double _dLenOfRadius,
    ref Eps_Point[] _InterPnt,
    double _dTolerance)
  {
    double num1 = 0.0;
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    int index = 0;
    int num2 = 0;
    int num3 = 0;
    _dTolerance = 0.001;
    Eps_Point epsPoint = new Eps_Point();
    _InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    _InterPnt[0].z = _FirstPnt.z;
    _InterPnt[1].z = _FirstPnt.z;
    double num4 = Math.Cos(_dDirOfFirstPnt);
    double num5 = Math.Sin(_dDirOfFirstPnt);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_RadiusPnt, _FirstPnt, ref _dDistance);
    if (_dDistance < _dTolerance)
    {
      Eps_Point _NewPnt = new Eps_Point();
      EPShared.eplGeoE_CalcPolarToXY(_RadiusPnt, _dDirOfFirstPnt, _dLenOfRadius, ref _NewPnt);
      _InterPnt[0] = _NewPnt;
      return 1606;
    }
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, _RadiusPnt, ref _dDirection);
    double a = Math.Abs(_dDirOfFirstPnt - _dDirection);
    if (_dLenOfRadius - _dDistance > 1E-05)
      num2 = 1;
    if (num2 == 0 && Math.Abs(((_RadiusPnt.y - _FirstPnt.y) * Math.Cos(_dDirOfFirstPnt) - (_RadiusPnt.x - _FirstPnt.x) * Math.Sin(_dDirOfFirstPnt)) / _dLenOfRadius) - 1.0 > 1E-05)
      return 1600;
    double num6 = Math.Sin(a);
    double num7 = _dDistance * num6 / _dLenOfRadius;
    if (num7 < -1.0 || num7 > 1.0)
    {
      if (num7 < -1.0000000001 || num7 > 1.0000000001)
        return 1600;
      num7 = EPShared.eplCalE_RoundValue(num7, 0);
    }
    double num8 = Math.Asin(num7);
    double d1 = Math.PI - (a + num8);
    num1 = Math.PI - a;
    double num9 = Math.PI - num8;
    double d2 = Math.PI - (a + num9);
    double num10 = Math.Sqrt(Math.Abs(_dDistance * _dDistance + _dLenOfRadius * _dLenOfRadius - 2.0 * _dDistance * _dLenOfRadius * Math.Cos(d1)));
    double num11 = Math.Sqrt(Math.Abs(_dDistance * _dDistance + _dLenOfRadius * _dLenOfRadius - 2.0 * _dDistance * _dLenOfRadius * Math.Cos(d2)));
    if (num2 == 0)
      num2 = Math.Abs(num8 - Math.PI / 2.0) > 1E-10 ? 2 : 1;
    epsPoint.x = _FirstPnt.x + num10 * num4;
    epsPoint.y = _FirstPnt.y + num10 * num5;
    if ((epsPoint.x - _RadiusPnt.x) * (epsPoint.x - _RadiusPnt.x) + (epsPoint.y - _RadiusPnt.y) * (epsPoint.y - _RadiusPnt.y) - _dLenOfRadius * _dLenOfRadius <= _dTolerance)
    {
      num3 = 1;
      _InterPnt[index].x = epsPoint.x;
      _InterPnt[index].y = epsPoint.y;
      index = 1;
    }
    if (num2 == 1)
      return index == 1 ? 1606 : 1600;
    epsPoint.x = _FirstPnt.x + num11 * num4;
    epsPoint.y = _FirstPnt.y + num11 * num5;
    if ((epsPoint.x - _RadiusPnt.x) * (epsPoint.x - _RadiusPnt.x) + (epsPoint.y - _RadiusPnt.y) * (epsPoint.y - _RadiusPnt.y) - _dLenOfRadius * _dLenOfRadius <= _dTolerance)
    {
      ++num3;
      _InterPnt[index].x = epsPoint.x;
      _InterPnt[index].y = epsPoint.y;
    }
    switch (num3)
    {
      case 0:
        return 1600;
      case 1:
        return 1606;
      case 2:
        return 1607;
      default:
        return 1600;
    }
  }

  public static void eplGeoE_FindMinMaxOfLegList(
    Eps_Leg _pLeg,
    ref Eps_Point _pMinPnt,
    ref Eps_Point _pMaxPnt)
  {
    Eps_Leg epsLeg1 = new Eps_Leg();
    Eps_Point _MinPnt = new Eps_Point();
    Eps_Point _MaxPnt = new Eps_Point();
    _pMinPnt.x = double.MaxValue;
    _pMaxPnt.x = double.MinValue;
    _pMinPnt.y = double.MaxValue;
    _pMaxPnt.y = double.MinValue;
    _pMinPnt.z = double.MaxValue;
    _pMaxPnt.z = double.MinValue;
    for (Eps_Leg epsLeg2 = _pLeg; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      if (epsLeg2.Line != null)
      {
        EPShared.CalcMinMax(epsLeg2.Line.StartPnt, ref _pMinPnt, ref _pMaxPnt);
        EPShared.CalcMinMax(epsLeg2.Line.EndPnt, ref _pMinPnt, ref _pMaxPnt);
      }
      else if (epsLeg2.Arc != null)
      {
        EPShared.eplGeoE_FindMinMaxOfArc(epsLeg2.Arc, ref _MinPnt, ref _MaxPnt);
        EPShared.CalcMinMax(_MinPnt, ref _pMinPnt, ref _pMaxPnt);
        EPShared.CalcMinMax(_MaxPnt, ref _pMinPnt, ref _pMaxPnt);
      }
      else if (GeometryObject.op_Inequality((GeometryObject) epsLeg2.HermiteSpline, (GeometryObject) null))
      {
        for (int index = 0; index < _pLeg.HermiteSpline.ControlPoints.Count; ++index)
          EPShared.CalcMinMax(new Eps_Point(epsLeg2.HermiteSpline.ControlPoints[index]), ref _pMinPnt, ref _pMaxPnt);
      }
      else if (GeometryObject.op_Inequality((GeometryObject) epsLeg2.NurbSpline, (GeometryObject) null))
      {
        for (int index = 0; index < _pLeg.NurbSpline.CtrlPoints.Count; ++index)
          EPShared.CalcMinMax(new Eps_Point(epsLeg2.NurbSpline.CtrlPoints[index]), ref _pMinPnt, ref _pMaxPnt);
      }
    }
  }

  public static void eplGeoE_GetLegStartAndEndPoints(
    Eps_Leg _pLeg,
    ref Eps_Point _pLegStartPnt,
    ref Eps_Point _pLegEndPnt)
  {
    _pLegStartPnt = new Eps_Point();
    _pLegEndPnt = new Eps_Point();
    if (_pLeg == null)
      return;
    if (_pLeg.Line != null)
    {
      _pLegStartPnt = _pLeg.Line.StartPnt;
      _pLegEndPnt = _pLeg.Line.EndPnt;
    }
    else if (_pLeg.Arc != null)
    {
      _pLegStartPnt = _pLeg.Arc.StartPnt;
      _pLegEndPnt = _pLeg.Arc.EndPnt;
    }
    else if (GeometryObject.op_Inequality((GeometryObject) _pLeg.HermiteSpline, (GeometryObject) null))
    {
      _pLegStartPnt = new Eps_Point(((Curve) _pLeg.HermiteSpline).GetEndPoint(0));
      _pLegEndPnt = new Eps_Point(((Curve) _pLeg.HermiteSpline).GetEndPoint(1));
    }
    else
    {
      if (!GeometryObject.op_Inequality((GeometryObject) _pLeg.NurbSpline, (GeometryObject) null))
        return;
      _pLegStartPnt = new Eps_Point(((Curve) _pLeg.NurbSpline).GetEndPoint(0));
      _pLegEndPnt = new Eps_Point(((Curve) _pLeg.NurbSpline).GetEndPoint(1));
    }
  }

  public static void eplGeoE_SolveMidPntByArcStruct(Eps_Arc _ArcStruct, ref Eps_Point _MidPnt)
  {
    double _dDirection = 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_ArcStruct.StartPnt, _ArcStruct.EndPnt, ref _dDirection);
    if (_ArcStruct.Direction == -1)
      EPShared.eplGeoE_CalcPolarToXY(_ArcStruct.RadiusPnt, _dDirection + Math.PI / 2.0, _ArcStruct.Radius, ref _MidPnt);
    else
      EPShared.eplGeoE_CalcPolarToXY(_ArcStruct.RadiusPnt, _dDirection - Math.PI / 2.0, _ArcStruct.Radius, ref _MidPnt);
  }

  public static int eplDsmE_AddArcToLegList(Eps_Arc _ArcToAdd, ref Eps_Leg _LegList)
  {
    return EPShared.eplDsmE_AddArcToLegList(_ArcToAdd, ref _LegList, false, 0.0, 0.0);
  }

  public static int eplDsmE_AddArcToLegList(
    Eps_Arc _ArcToAdd,
    ref Eps_Leg _LegList,
    bool _bIs3D,
    double _dStartWidth,
    double _dEndWidth)
  {
    return EPShared.eplDsmE_AddLegToList(new Eps_Leg()
    {
      Arc = _ArcToAdd,
      Is3D = _bIs3D
    }, ref _LegList, _dStartWidth, _dEndWidth);
  }

  public static int eplDsmE_AddLineToLegList(Eps_Line _LineToAdd, ref Eps_Leg _LegList)
  {
    return EPShared.eplDsmE_AddLineToLegList(_LineToAdd, ref _LegList, false, 0.0, 0.0);
  }

  public static int eplDsmE_AddLineToLegList(
    Eps_Line _LineToAdd,
    ref Eps_Leg _LegList,
    bool _bIs3D,
    double _dStartWidth,
    double _dEndWidth)
  {
    return EPShared.eplDsmE_AddLegToList(new Eps_Leg()
    {
      Line = _LineToAdd,
      Is3D = _bIs3D
    }, ref _LegList, _dStartWidth, _dEndWidth);
  }

  public static int eplDsmE_AddLegToList(
    Eps_Leg _LegToAdd,
    ref Eps_Leg _LegList,
    double _dStartWidth,
    double _dEndWidth)
  {
    Eps_Leg epsLeg = new Eps_Leg();
    Eps_Point epsPoint = new Eps_Point();
    Eps_Leg _ListToAdd = _LegToAdd;
    _ListToAdd.Next = (Eps_Leg) null;
    EPShared.eplDsmE_AppendLegListToList(_ListToAdd, ref _LegList);
    return 0;
  }

  public static void eplDsmE_AppendLegListToList(Eps_Leg _ListToAdd, ref Eps_Leg _LegList)
  {
    Eps_Leg epsLeg = _LegList;
    if (epsLeg != null)
    {
      while (epsLeg.Next != null)
        epsLeg = epsLeg.Next;
      epsLeg.Next = _ListToAdd;
    }
    else
      _LegList = _ListToAdd;
  }

  public static int eplFilP_GetSupportPath(string _strFileName, ref string _strSupportPath)
  {
    _strSupportPath = string.Empty;
    return 6;
  }

  public static bool eplLicM_GetLicense() => true;

  public static bool eplLicM_ReturnLicense() => true;

  public static void epl_UnloadHelper(bool _bIs64BitInstall)
  {
    int num = _bIs64BitInstall ? 1 : 0;
  }

  public static bool eplLicM_LicenseManagement() => true;

  public static bool eplLicM_IsNodeLicense() => true;

  public static bool eplLicM_BorrowNetworkLicense() => false;

  public static bool eplLicM_IsBorrowedNetworkLicense() => false;

  public static bool eplLicM_ReturnBorrowedLicense() => false;
}
