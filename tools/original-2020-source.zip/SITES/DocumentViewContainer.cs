﻿// Decompiled with JetBrains decompiler
// Type: SITES.DocumentViewContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace SITES;

public class DocumentViewContainer
{
  private Document m_Document;
  private List<View> m_ViewList;

  public DocumentViewContainer(Document _Document, List<View> _ViewList)
  {
    this.m_Document = _Document;
    this.m_ViewList = _ViewList;
  }

  public Document Document => this.m_Document;

  public List<View> ViewList => this.m_ViewList;
}
