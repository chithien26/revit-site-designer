﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FailurePreprocessor
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FailurePreprocessor : IFailuresPreprocessor
{
  private List<FailureDefinitionId> m_FailureDefinitionIdList;

  public FailurePreprocessor(FailureDefinitionId _FailureDefinitionId)
  {
    this.m_FailureDefinitionIdList = new List<FailureDefinitionId>();
    this.m_FailureDefinitionIdList.Add(_FailureDefinitionId);
  }

  public FailurePreprocessor(List<FailureDefinitionId> _FailureDefinitionIdList)
  {
    this.m_FailureDefinitionIdList = _FailureDefinitionIdList;
  }

  public FailureProcessingResult PreprocessFailures(FailuresAccessor FailuresAccessor)
  {
    IList<FailureMessageAccessor> failureMessageAccessorList = (IList<FailureMessageAccessor>) new List<FailureMessageAccessor>();
    foreach (FailureMessageAccessor failureMessage in (IEnumerable<FailureMessageAccessor>) FailuresAccessor.GetFailureMessages())
    {
      FailureDefinitionId failureDefinitionId = failureMessage.GetFailureDefinitionId();
      for (int index = 0; index < this.m_FailureDefinitionIdList.Count; ++index)
      {
        if (FailureDefinitionId.op_Equality(this.m_FailureDefinitionIdList[index], failureDefinitionId))
        {
          FailuresAccessor.DeleteWarning(failureMessage);
          break;
        }
      }
    }
    return (FailureProcessingResult) 0;
  }

  public List<FailureDefinitionId> FailureDefinitionIdList
  {
    get => this.m_FailureDefinitionIdList;
    set => this.m_FailureDefinitionIdList = value;
  }
}
