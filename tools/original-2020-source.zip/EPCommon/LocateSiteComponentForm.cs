﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LocateSiteComponentForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LocateSiteComponentForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private SiteComponentCreation m_dataBuffer;
  private FamilySymbol m_CurType;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private LandcaddID m_CurrentLandcaddID = LandcaddID.SoftTerrain;
  private string m_strCurrentDlgType = string.Empty;
  private DecimalSymbol m_DecimalSymbolType;
  private CurrentElevationFocus m_CurrentElevationFocus;
  private double m_dAdjustConstElevation;
  private IContainer components;
  private Button m_LoadFamilyButton;
  private ComboBox m_TypeNameComboBox;
  private Label m_TypeNameLabel;
  private ComboBox m_FamilyComboBox;
  private Label m_FamilyLabel;
  private Label m_ConstantElevationLabel;
  private TextBox m_ConstantElevationTextBox;
  private Panel m_MoveablePanel;
  private CheckBox m_CreateCopyCheckBox;
  private Button m_CloseButton;
  private Button m_InsertButton;
  private Label m_RadiusLabel;
  private TextBox m_RadiusTextBox;
  private Label m_NameLabel;
  private TextBox m_NameTextBox;
  private RadioButton m_RelativeElevationRadioButton;
  private Label m_RelativeElevationLabel;
  private TextBox m_RelativeElevationTextBox;
  private RadioButton m_ConstantElevationRadioButton;
  private Panel m_UsePanel;
  private RadioButton m_SegmentRadioButton;
  private RadioButton m_ChainRadioButton;
  private Panel m_HostLineSelectionPanel;
  private RadioButton m_UseExistingHostLineRadioButton;
  private RadioButton m_DrawHostLineRadioButton;
  private Button m_PickInRevitButton;

  public LocateSiteComponentForm(SiteComponentCreation dataBuffer, LandcaddID _CurrentLandcaddID)
  {
    this.InitializeComponent();
    this.m_CurrentLandcaddID = _CurrentLandcaddID;
    this.SetStrings();
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_PickInRevitButton, EPShared.LocalRM.GetString("PickPointElevationToolTip"));
    this.m_dataBuffer = dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.m_dAdjustConstElevation = 0.0;
    this.InitializeControls();
  }

  private void SetStrings()
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    string empty4 = string.Empty;
    string empty5 = string.Empty;
    string empty6 = string.Empty;
    switch (this.m_CurrentLandcaddID)
    {
      case LandcaddID.SoftTerrain:
        empty1 = EPShared.LocalRM.GetString("LocateSoftTerrainDialog");
        empty2 = EPShared.LocalRM.GetString("SoftTerrainFamilyDialog");
        empty3 = EPShared.LocalRM.GetString("SoftTerrainTypeDialog");
        empty4 = EPShared.LocalRM.GetString("SoftTerrainNameDialog");
        empty5 = EPShared.LocalRM.GetString("RelativeElevationFromToposurfaceDialog");
        empty6 = EPShared.LocalRM.GetString("ConstantElevationDialog");
        this.ContextualHelpID = "HID_SDsoftTerrainCreate";
        break;
      case LandcaddID.Street:
        empty1 = EPShared.LocalRM.GetString("LocateStreetDialog");
        empty2 = EPShared.LocalRM.GetString("StreetFamilyDialog");
        empty3 = EPShared.LocalRM.GetString("StreetTypeDialog");
        empty4 = EPShared.LocalRM.GetString("StreetNameDialog");
        empty5 = EPShared.LocalRM.GetString("RelativeElevationFromToposurfaceDialog");
        empty6 = EPShared.LocalRM.GetString("ConstantElevationDialog");
        this.ContextualHelpID = "HID_SDstreetCreate";
        break;
      case LandcaddID.Curb:
        empty1 = EPShared.LocalRM.GetString("LocateCurbDialog");
        empty2 = EPShared.LocalRM.GetString("CurbFamilyDialog");
        empty3 = EPShared.LocalRM.GetString("CurbTypeDialog");
        empty4 = EPShared.LocalRM.GetString("CurbNameDialog");
        empty5 = EPShared.LocalRM.GetString("RelativeElevationFromToposurfaceDialog");
        empty6 = EPShared.LocalRM.GetString("ConstantElevationDialog");
        this.ContextualHelpID = "HID_SDcurbCreate";
        break;
      case LandcaddID.Sidewalk:
        empty1 = EPShared.LocalRM.GetString("LocateSidewalkDialog");
        empty2 = EPShared.LocalRM.GetString("SideWalkFamilyDialog");
        empty3 = EPShared.LocalRM.GetString("SideWalkTypeDialog");
        empty4 = EPShared.LocalRM.GetString("SideWalkNameDialog");
        empty5 = EPShared.LocalRM.GetString("RelativeElevationFromToposurfaceDialog");
        empty6 = EPShared.LocalRM.GetString("ConstantElevationDialog");
        this.ContextualHelpID = "HID_SDsidewalkCreate";
        break;
      case LandcaddID.RetainingWall:
        empty1 = EPShared.LocalRM.GetString("LocateRetainingWallDialog");
        empty2 = EPShared.LocalRM.GetString("RetainingWallFamilyDialog");
        empty3 = EPShared.LocalRM.GetString("RetainingWallTypeDialog");
        empty4 = EPShared.LocalRM.GetString("RetainingWallNameDialog");
        empty5 = EPShared.LocalRM.GetString("RetainingwallRelativeElevationFromToposurfaceDialog");
        empty6 = EPShared.LocalRM.GetString("RetainingwallConstantElevationDialog");
        this.ContextualHelpID = "HID_SDretainingWallCreate";
        break;
    }
    this.Text = empty1;
    this.m_FamilyLabel.Text = empty2;
    this.m_TypeNameLabel.Text = empty3;
    this.m_NameLabel.Text = empty4;
    this.m_RelativeElevationRadioButton.Text = empty5;
    this.m_ConstantElevationRadioButton.Text = empty6;
    this.m_RelativeElevationLabel.Text = EPShared.LocalRM.GetString("AMP_ElevationDialog");
    this.m_ConstantElevationLabel.Text = EPShared.LocalRM.GetString("Ele_AMP_vationDialog");
    this.m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_CreateCopyCheckBox.Text = EPShared.LocalRM.GetString("Create_AMP_ACopyDialog");
    this.m_UseExistingHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_UseExistingHostLineDialog");
    this.m_DrawHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_DrawHostLineDialog");
    this.m_RadiusLabel.Text = EPShared.LocalRM.GetString("AMP_RadiusDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
  }

  private void InitializeControls()
  {
    int num = 0;
    double _dReturnValue = 0.0;
    string empty = string.Empty;
    this.GetDialogPosition();
    switch (this.m_CurrentLandcaddID)
    {
      case LandcaddID.SoftTerrain:
        this.m_strCurrentDlgType = "LocateSoftTerrain";
        break;
      case LandcaddID.Street:
        this.m_strCurrentDlgType = "LocateStreet";
        break;
      case LandcaddID.Sidewalk:
        this.m_strCurrentDlgType = "LocateSidewalk";
        break;
      case LandcaddID.RetainingWall:
        this.m_strCurrentDlgType = "LocateRetainingWall";
        break;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "RelativeElevation", ref _dReturnValue))
      _dReturnValue = 15.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_RelativeElevationTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "ConstantElevation", ref _dReturnValue))
      _dReturnValue = 15.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_ConstantElevationTextBox.Text = empty;
    this.m_UseExistingHostLineRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "HostLineSelectionOption", ref num))
    {
      if (num == 0)
        this.m_UseExistingHostLineRadioButton.Checked = true;
      else
        this.m_DrawHostLineRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "Radius", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    this.m_RadiusTextBox.Text = empty;
    this.m_CreateCopyCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "CreateVisibleCopy", ref num))
      this.m_CreateCopyCheckBox.Checked = Convert.ToBoolean(num);
    this.m_FamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
    this.m_FamilyComboBox.DisplayMember = "FamilyName";
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, this.m_strCurrentDlgType + "FamilyName", ref empty))
    {
      for (int index = 0; index < this.m_FamilyComboBox.Items.Count; ++index)
      {
        if (this.m_FamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty, true) == 0)
        {
          this.m_FamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, this.m_strCurrentDlgType + "TypeName", ref empty))
    {
      for (int index = 0; index < this.m_TypeNameComboBox.Items.Count; ++index)
      {
        if (this.m_TypeNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty, true) == 0)
        {
          this.m_TypeNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    string _strReturnValue = string.Empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, this.m_strCurrentDlgType + "Name", ref _strReturnValue) && this.m_FamilyComboBox.SelectedItem is FamilyContainer selectedItem && selectedItem.FamilyName != string.Empty)
      _strReturnValue = selectedItem.FamilyName;
    if (this.m_CurrentLandcaddID != LandcaddID.SoftTerrain ? this.m_dataBuffer.FindMassingFamilyStartingNumberName(_strReturnValue, ref num) : this.m_dataBuffer.FindPlacementStartingNumberName(_strReturnValue, ref num))
      this.m_NameTextBox.Text = _strReturnValue + this.m_dataBuffer.NUMMERIC_SEPERATOR + Convert.ToString(num);
    else
      this.m_NameTextBox.Text = _strReturnValue;
    this.m_ChainRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "SegmentChainOption", ref num))
    {
      if (num == 0)
        this.m_SegmentRadioButton.Checked = true;
      else
        this.m_ChainRadioButton.Checked = true;
    }
    this.m_RelativeElevationRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strCurrentDlgType + "ElevationOption", ref num))
    {
      if (num == 0)
        this.m_RelativeElevationRadioButton.Checked = true;
      else
        this.m_ConstantElevationRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "UseSharedElevation", ref num) || num != 1)
      return;
    this.m_dAdjustConstElevation = this.m_dataBuffer.Document.ActiveProjectLocation.GetProjectPosition(new XYZ()).Elevation;
  }

  private void SaveSettings()
  {
    this.m_CurType = this.m_TypeNameComboBox.SelectedItem as FamilySymbol;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RelativeElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "RelativeElevation", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_ConstantElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "ConstantElevation", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "HostLineSelectionOption", !this.m_UseExistingHostLineRadioButton.Checked ? 1 : 0);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "Radius", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "CreateVisibleCopy", Convert.ToInt32(this.m_CreateCopyCheckBox.Checked));
    if (this.m_FamilyComboBox.SelectedItem is FamilyContainer selectedItem)
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, this.m_strCurrentDlgType + "FamilyName", selectedItem.FamilyName);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, this.m_strCurrentDlgType + "TypeName", ((Element) this.m_CurType).Name);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, this.m_strCurrentDlgType + "Name", this.m_dataBuffer.GetSitePlacementNameWithoutSeperator(this.m_NameTextBox.Text));
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "SegmentChainOption", !this.m_SegmentRadioButton.Checked ? 1 : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strCurrentDlgType + "ElevationOption", !this.m_RelativeElevationRadioButton.Checked ? 1 : 0);
  }

  private void OnFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_FamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_TypeNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_TypeNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_FamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty1 = string.Empty;
      Family _Family = (Family) null;
      string empty2 = string.Empty;
      switch (this.m_CurrentLandcaddID)
      {
        case LandcaddID.SoftTerrain:
          empty2 = EPShared.LocalRM.GetString("PleaseSelectSoftTerrainFamilyFileMessage");
          break;
        case LandcaddID.Street:
          empty2 = EPShared.LocalRM.GetString("PleaseSelectStreetFamilyFileMessage");
          break;
        case LandcaddID.Sidewalk:
          empty2 = EPShared.LocalRM.GetString("PleaseSelectSidewalkFamilyFileMessage");
          break;
        case LandcaddID.RetainingWall:
          empty2 = EPShared.LocalRM.GetString("PleaseSelectRetainingWallFamilyFileMessage");
          break;
      }
      openFileDialog.Title = empty2;
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty1) == 0)
        openFileDialog.InitialDirectory = empty1;
      bool flag1 = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            string empty3 = string.Empty;
            switch (this.m_CurrentLandcaddID)
            {
              case LandcaddID.SoftTerrain:
                empty3 = EPShared.LocalRM.GetString("LoadSoftTerrainFamilyTransaction");
                break;
              case LandcaddID.Street:
                empty3 = EPShared.LocalRM.GetString("LoadStreetFamilyTransaction");
                break;
              case LandcaddID.Sidewalk:
                empty3 = EPShared.LocalRM.GetString("LoadSidewalkFamilyTransaction");
                break;
              case LandcaddID.RetainingWall:
                empty3 = EPShared.LocalRM.GetString("LoadRetainingWallFamilyTransaction");
                break;
            }
            this.m_dataBuffer.TransactionContainer.Start(empty3 + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag1 = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            string _strFindName = string.Empty;
            if (_Family != null)
            {
              this.m_dataBuffer.TransactionContainer.Commit();
              _strFindName = ((Element) _Family).Name;
            }
            else
            {
              this.m_dataBuffer.TransactionContainer.Rollback();
              bool flag2 = false;
              int num = 0;
              foreach (FamilyContainer family in this.m_dataBuffer.FamilyList)
              {
                Document document = this.m_dataBuffer.Document.EditFamily(family.FamilySymbolList[0].Family);
                if (document != null && string.Compare(document.PathName, openFileDialog.FileName, true) == 0)
                {
                  _strFindName = family.FamilyName;
                  flag2 = true;
                  break;
                }
                ++num;
              }
              if (flag2)
                this.m_FamilyComboBox.SelectedIndex = num;
            }
            int nBeginningIndex = 0;
            if (this.m_CurrentLandcaddID != LandcaddID.SoftTerrain ? this.m_dataBuffer.FindMassingFamilyStartingNumberName(_strFindName, ref nBeginningIndex) : this.m_dataBuffer.FindPlacementStartingNumberName(_strFindName, ref nBeginningIndex))
            {
              this.m_NameTextBox.Text = _strFindName + this.m_dataBuffer.NUMMERIC_SEPERATOR + Convert.ToString(nBeginningIndex);
              break;
            }
            this.m_NameTextBox.Text = _strFindName;
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag1 = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSelectionMadeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag1)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSelectionMadeMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_FamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
        this.m_FamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_FamilyComboBox.Items.Count; ++index)
          {
            if (this.m_FamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_FamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_FamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSelectionMadeMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCloseButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnHostLineSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_RadiusLabel.Enabled = this.m_DrawHostLineRadioButton.Checked;
    this.m_RadiusTextBox.Enabled = this.m_DrawHostLineRadioButton.Checked;
  }

  private void OnElevationSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_ConstantElevationLabel.Enabled = this.m_ConstantElevationRadioButton.Checked;
    this.m_ConstantElevationTextBox.Enabled = this.m_ConstantElevationRadioButton.Checked;
    this.m_RelativeElevationLabel.Enabled = !this.m_ConstantElevationRadioButton.Checked;
    this.m_RelativeElevationTextBox.Enabled = !this.m_ConstantElevationRadioButton.Checked;
  }

  private bool ValidateFields()
  {
    if (this.m_TypeNameComboBox.SelectedItem == null)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    string empty = string.Empty;
    switch (this.m_CurrentLandcaddID)
    {
      case LandcaddID.SoftTerrain:
        empty = EPShared.LocalRM.GetString("SoftTerrainString");
        break;
      case LandcaddID.Street:
        empty = EPShared.LocalRM.GetString("StreetString");
        break;
      case LandcaddID.Sidewalk:
        empty = EPShared.LocalRM.GetString("SidewalkString");
        break;
      case LandcaddID.RetainingWall:
        empty = EPShared.LocalRM.GetString("RetainingWallString");
        break;
    }
    if (string.IsNullOrEmpty(this.m_NameTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("Specify_Message") + empty + EPShared.LocalRM.GetString("NameString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_NameTextBox.Focus();
      return false;
    }
    if (this.m_NameTextBox.Text.StartsWith(" ") || this.m_NameTextBox.Text.EndsWith(" "))
    {
      int num = (int) RevitMessageBox.Show($"{empty} {EPShared.LocalRM.GetString("NameString")}{EPShared.LocalRM.GetString("_LeadingAndTrailingSpacesMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_NameTextBox.Focus();
      return false;
    }
    if (this.m_CurrentLandcaddID != LandcaddID.SoftTerrain ? this.m_dataBuffer.FindFamilyName(this.m_NameTextBox.Text) : this.m_dataBuffer.FindPlacementName(this.m_NameTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("MassingFamilyNameAlreadyUsedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_NameTextBox.Focus();
      return false;
    }
    if (this.m_ChainRadioButton.Checked && this.m_DrawHostLineRadioButton.Checked)
    {
      this.m_CurType = this.m_TypeNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_CurType == null)
        return false;
      if (this.m_CurrentLandcaddID != LandcaddID.SoftTerrain)
      {
        double _dY = 0.0;
        switch (this.m_CurrentLandcaddID)
        {
          case LandcaddID.Street:
            double num1 = 0.0;
            Parameter parameter1 = ((Element) this.m_CurType).LookupParameter(RevitParameters.StreetLaneWidthParameter);
            if (parameter1 != null)
              num1 = parameter1.AsDouble();
            Parameter parameter2 = ((Element) this.m_CurType).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
            if (parameter2 != null)
            {
              _dY = num1 * (double) parameter2.AsInteger();
              break;
            }
            break;
          case LandcaddID.Curb:
            double num2 = 0.0;
            double num3 = 0.0;
            Parameter parameter3 = ((Element) this.m_CurType).LookupParameter(RevitParameters.StreetCurbWidthParameter);
            if (parameter3 != null)
              num2 = parameter3.AsDouble();
            Parameter parameter4 = ((Element) this.m_CurType).LookupParameter(RevitParameters.StreetGutterWidthParameter);
            if (parameter4 != null)
              num3 = parameter4.AsDouble();
            _dY = num2 + num3;
            break;
          case LandcaddID.Sidewalk:
            Parameter parameter5 = ((Element) this.m_CurType).LookupParameter(RevitParameters.SideWalkWidthParameter);
            if (parameter5 != null)
            {
              _dY = parameter5.AsDouble();
              break;
            }
            break;
          case LandcaddID.RetainingWall:
            Parameter parameter6 = ((Element) this.m_CurType).LookupParameter(RevitParameters.RetainingWallWidthParameter);
            if (parameter6 != null)
            {
              _dY = parameter6.AsDouble();
              break;
            }
            break;
        }
        double _dReturnedDouble = 0.0;
        if (this.m_RadiusTextBox.Text != string.Empty)
          RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true);
        if (RevitDefines.LT(_dReturnedDouble, _dY) && !RevitDefines.EQ(_dReturnedDouble, 0.0))
        {
          int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
    }
    return true;
  }

  private void FormatRelativeElevationValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RelativeElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_RelativeElevationTextBox.Text = empty;
    }
    else
      this.m_RelativeElevationTextBox.Focus();
  }

  private void OnRelativeElevationKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatRelativeElevationValue();
  }

  private void OnRelativeElevationTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatRelativeElevationValue();
  }

  private void FormatConstantElevationValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_ConstantElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
      this.m_ConstantElevationTextBox.Text = empty;
    }
    else
      this.m_ConstantElevationTextBox.Focus();
  }

  private void OnConstantElevationKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatConstantElevationValue();
  }

  private void OnConstantElevationTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatConstantElevationValue();
    this.m_CurrentElevationFocus = CurrentElevationFocus.ConstantElevation;
  }

  private void FormatRadiusValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true))
    {
      if (_dReturnedDouble < 0.0)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidRadiusValueString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        this.m_RadiusTextBox.Text = string.Empty;
      }
      else
      {
        RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
        this.m_RadiusTextBox.Text = empty;
      }
    }
    else
      this.m_RadiusTextBox.Focus();
  }

  private void OnRadiusKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatRadiusValue();
  }

  private void OnRadiusTextBoxLeave(object sender, EventArgs e) => this.FormatRadiusValue();

  private void OnLocateSiteComponentClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public void ResetSiteComponentName()
  {
    string withoutSeperator = this.m_dataBuffer.GetSitePlacementNameWithoutSeperator(this.m_NameTextBox.Text);
    int nBeginningIndex = 0;
    if (this.m_CurrentLandcaddID != LandcaddID.SoftTerrain ? this.m_dataBuffer.FindMassingFamilyStartingNumberName(withoutSeperator, ref nBeginningIndex) : this.m_dataBuffer.FindPlacementStartingNumberName(withoutSeperator, ref nBeginningIndex))
      this.m_NameTextBox.Text = withoutSeperator + this.m_dataBuffer.NUMMERIC_SEPERATOR + Convert.ToString(nBeginningIndex);
    else
      this.m_NameTextBox.Text = withoutSeperator;
  }

  private void OnPickInRevitButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnElevationTextBoxEnter(object sender, EventArgs e)
  {
    this.m_PickInRevitButton.Enabled = true;
  }

  private void OnElevationTextBoxLostFocus(object sender, EventArgs e)
  {
    if (this.m_PickInRevitButton.Focused || this.m_ConstantElevationTextBox.Focused)
      return;
    this.m_PickInRevitButton.Enabled = false;
  }

  public void SetFocusedElevation(double _dElevation)
  {
    string empty = string.Empty;
    _dElevation += this.m_dAdjustConstElevation;
    RevitGeometry.Units_ConvertDoubleToString(_dElevation, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_dataBuffer.Document.GetUnits(), ref empty);
    if (this.m_CurrentElevationFocus != CurrentElevationFocus.ConstantElevation)
      return;
    this.m_ConstantElevationTextBox.Text = empty;
    this.m_PickInRevitButton.Enabled = true;
  }

  private void OnLocateSiteComponentFormShown(object sender, EventArgs e)
  {
    switch (this.m_CurrentElevationFocus)
    {
      case CurrentElevationFocus.None:
        this.m_PickInRevitButton.Enabled = false;
        break;
      case CurrentElevationFocus.ConstantElevation:
        this.m_ConstantElevationTextBox.Focus();
        this.m_PickInRevitButton.Enabled = true;
        break;
    }
  }

  public bool ExistingHostLineChecked => this.m_UseExistingHostLineRadioButton.Checked;

  public bool CreateCopyChecked => this.m_CreateCopyCheckBox.Checked;

  public double Radius
  {
    get
    {
      if (this.m_UseExistingHostLineRadioButton.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_RadiusTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true);
      return _dReturnedDouble;
    }
  }

  public FamilySymbol Type => this.m_CurType;

  public double Elevation
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_RelativeElevationRadioButton.Checked)
      {
        if (this.m_RelativeElevationTextBox.Text != string.Empty)
          RevitGeometry.Units_ConvertStringToDouble(this.m_RelativeElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true);
      }
      else if (this.m_ConstantElevationTextBox.Text != string.Empty)
      {
        RevitGeometry.Units_ConvertStringToDouble(this.m_ConstantElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, true);
        _dReturnedDouble -= this.m_dAdjustConstElevation;
      }
      return _dReturnedDouble;
    }
  }

  public bool SegmentChecked => this.m_SegmentRadioButton.Checked;

  public bool ChainChecked => this.m_ChainRadioButton.Checked;

  public bool RelativeElevationChecked => this.m_RelativeElevationRadioButton.Checked;

  public string SitePlacementName => this.m_NameTextBox.Text;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (LocateSiteComponentForm));
    this.m_LoadFamilyButton = new Button();
    this.m_TypeNameComboBox = new ComboBox();
    this.m_TypeNameLabel = new Label();
    this.m_FamilyComboBox = new ComboBox();
    this.m_FamilyLabel = new Label();
    this.m_ConstantElevationLabel = new Label();
    this.m_ConstantElevationTextBox = new TextBox();
    this.m_MoveablePanel = new Panel();
    this.m_CloseButton = new Button();
    this.m_InsertButton = new Button();
    this.m_CreateCopyCheckBox = new CheckBox();
    this.m_RadiusLabel = new Label();
    this.m_RadiusTextBox = new TextBox();
    this.m_NameLabel = new Label();
    this.m_NameTextBox = new TextBox();
    this.m_RelativeElevationRadioButton = new RadioButton();
    this.m_RelativeElevationLabel = new Label();
    this.m_RelativeElevationTextBox = new TextBox();
    this.m_ConstantElevationRadioButton = new RadioButton();
    this.m_UsePanel = new Panel();
    this.m_SegmentRadioButton = new RadioButton();
    this.m_ChainRadioButton = new RadioButton();
    this.m_HostLineSelectionPanel = new Panel();
    this.m_UseExistingHostLineRadioButton = new RadioButton();
    this.m_DrawHostLineRadioButton = new RadioButton();
    this.m_PickInRevitButton = new Button();
    this.m_MoveablePanel.SuspendLayout();
    this.m_UsePanel.SuspendLayout();
    this.m_HostLineSelectionPanel.SuspendLayout();
    this.SuspendLayout();
    this.m_LoadFamilyButton.Location = new Point(434, 12);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_TypeNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_TypeNameComboBox.FormattingEnabled = true;
    this.m_TypeNameComboBox.Location = new Point(189, 40);
    this.m_TypeNameComboBox.Name = "m_TypeNameComboBox";
    this.m_TypeNameComboBox.Size = new Size(239, 21);
    this.m_TypeNameComboBox.TabIndex = 5;
    this.m_TypeNameLabel.AutoSize = true;
    this.m_TypeNameLabel.Location = new Point(12, 42);
    this.m_TypeNameLabel.Name = "m_TypeNameLabel";
    this.m_TypeNameLabel.Size = new Size(92, 13);
    this.m_TypeNameLabel.TabIndex = 4;
    this.m_TypeNameLabel.Text = "Soft &Terrain Type:";
    this.m_FamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_FamilyComboBox.FormattingEnabled = true;
    this.m_FamilyComboBox.Location = new Point(189, 13);
    this.m_FamilyComboBox.Name = "m_FamilyComboBox";
    this.m_FamilyComboBox.Size = new Size(239, 21);
    this.m_FamilyComboBox.TabIndex = 1;
    this.m_FamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnFamilyComboBoxSelectedIndexChanged);
    this.m_FamilyLabel.AutoSize = true;
    this.m_FamilyLabel.Location = new Point(12, 17);
    this.m_FamilyLabel.Name = "m_FamilyLabel";
    this.m_FamilyLabel.Size = new Size(97, 13);
    this.m_FamilyLabel.TabIndex = 0;
    this.m_FamilyLabel.Text = "&Soft Terrain Family:";
    this.m_ConstantElevationLabel.AutoSize = true;
    this.m_ConstantElevationLabel.Enabled = false;
    this.m_ConstantElevationLabel.Location = new Point(30, 167);
    this.m_ConstantElevationLabel.Name = "m_ConstantElevationLabel";
    this.m_ConstantElevationLabel.Size = new Size(54, 13);
    this.m_ConstantElevationLabel.TabIndex = 12;
    this.m_ConstantElevationLabel.Text = "Elevation:";
    this.m_ConstantElevationTextBox.Enabled = false;
    this.m_ConstantElevationTextBox.Location = new Point(189, 164);
    this.m_ConstantElevationTextBox.Name = "m_ConstantElevationTextBox";
    this.m_ConstantElevationTextBox.Size = new Size(100, 20);
    this.m_ConstantElevationTextBox.TabIndex = 13;
    this.m_ConstantElevationTextBox.KeyDown += new KeyEventHandler(this.OnConstantElevationKeyDown);
    this.m_ConstantElevationTextBox.Leave += new EventHandler(this.OnConstantElevationTextBoxLeave);
    this.m_ConstantElevationTextBox.Enter += new EventHandler(this.OnElevationTextBoxEnter);
    this.m_ConstantElevationTextBox.LostFocus += new EventHandler(this.OnElevationTextBoxLostFocus);
    this.m_MoveablePanel.Controls.Add((Control) this.m_CloseButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Location = new Point(12, 308);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(476, 23);
    this.m_MoveablePanel.TabIndex = 19;
    this.m_CloseButton.DialogResult = DialogResult.Cancel;
    this.m_CloseButton.Location = new Point(400, 0);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 1;
    this.m_CloseButton.Text = "&Cancel";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClick);
    this.m_InsertButton.Location = new Point(319, 0);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 0;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CreateCopyCheckBox.AutoSize = true;
    this.m_CreateCopyCheckBox.Location = new Point(12, 213);
    this.m_CreateCopyCheckBox.Name = "m_CreateCopyCheckBox";
    this.m_CreateCopyCheckBox.Size = new Size(94, 17);
    this.m_CreateCopyCheckBox.TabIndex = 15;
    this.m_CreateCopyCheckBox.Text = "Create A Copy";
    this.m_CreateCopyCheckBox.UseVisualStyleBackColor = true;
    this.m_RadiusLabel.AutoSize = true;
    this.m_RadiusLabel.Enabled = false;
    this.m_RadiusLabel.Location = new Point(30, 285);
    this.m_RadiusLabel.Name = "m_RadiusLabel";
    this.m_RadiusLabel.Size = new Size(43, 13);
    this.m_RadiusLabel.TabIndex = 17;
    this.m_RadiusLabel.Text = "Radius:";
    this.m_RadiusTextBox.Enabled = false;
    this.m_RadiusTextBox.Location = new Point(189, 282);
    this.m_RadiusTextBox.Name = "m_RadiusTextBox";
    this.m_RadiusTextBox.Size = new Size(100, 20);
    this.m_RadiusTextBox.TabIndex = 18;
    this.m_RadiusTextBox.KeyDown += new KeyEventHandler(this.OnRadiusKeyDown);
    this.m_RadiusTextBox.Leave += new EventHandler(this.OnRadiusTextBoxLeave);
    this.m_NameLabel.AutoSize = true;
    this.m_NameLabel.Location = new Point(12, 69);
    this.m_NameLabel.Name = "m_NameLabel";
    this.m_NameLabel.Size = new Size(96 /*0x60*/, 13);
    this.m_NameLabel.TabIndex = 6;
    this.m_NameLabel.Text = "Soft Terrain Name:";
    this.m_NameTextBox.Location = new Point(189, 67);
    this.m_NameTextBox.Name = "m_NameTextBox";
    this.m_NameTextBox.Size = new Size(239, 20);
    this.m_NameTextBox.TabIndex = 7;
    this.m_RelativeElevationRadioButton.AutoSize = true;
    this.m_RelativeElevationRadioButton.Location = new Point(12, 92);
    this.m_RelativeElevationRadioButton.Name = "m_RelativeElevationRadioButton";
    this.m_RelativeElevationRadioButton.Size = new Size(197, 17);
    this.m_RelativeElevationRadioButton.TabIndex = 8;
    this.m_RelativeElevationRadioButton.Text = "&Relative Elevation from Toposurface";
    this.m_RelativeElevationRadioButton.UseVisualStyleBackColor = true;
    this.m_RelativeElevationRadioButton.CheckedChanged += new EventHandler(this.OnElevationSelectionOptionChecked);
    this.m_RelativeElevationLabel.AutoSize = true;
    this.m_RelativeElevationLabel.Enabled = false;
    this.m_RelativeElevationLabel.Location = new Point(30, 118);
    this.m_RelativeElevationLabel.Name = "m_RelativeElevationLabel";
    this.m_RelativeElevationLabel.Size = new Size(54, 13);
    this.m_RelativeElevationLabel.TabIndex = 9;
    this.m_RelativeElevationLabel.Text = "Elevation:";
    this.m_RelativeElevationTextBox.Enabled = false;
    this.m_RelativeElevationTextBox.Location = new Point(189, 115);
    this.m_RelativeElevationTextBox.Name = "m_RelativeElevationTextBox";
    this.m_RelativeElevationTextBox.Size = new Size(100, 20);
    this.m_RelativeElevationTextBox.TabIndex = 10;
    this.m_RelativeElevationTextBox.KeyDown += new KeyEventHandler(this.OnRelativeElevationKeyDown);
    this.m_RelativeElevationTextBox.Leave += new EventHandler(this.OnRelativeElevationTextBoxLeave);
    this.m_ConstantElevationRadioButton.AutoSize = true;
    this.m_ConstantElevationRadioButton.Location = new Point(12, 141);
    this.m_ConstantElevationRadioButton.Name = "m_ConstantElevationRadioButton";
    this.m_ConstantElevationRadioButton.Size = new Size(114, 17);
    this.m_ConstantElevationRadioButton.TabIndex = 11;
    this.m_ConstantElevationRadioButton.Text = "&Constant Elevation";
    this.m_ConstantElevationRadioButton.UseVisualStyleBackColor = true;
    this.m_ConstantElevationRadioButton.CheckedChanged += new EventHandler(this.OnElevationSelectionOptionChecked);
    this.m_UsePanel.Controls.Add((Control) this.m_SegmentRadioButton);
    this.m_UsePanel.Controls.Add((Control) this.m_ChainRadioButton);
    this.m_UsePanel.Location = new Point(12, 190);
    this.m_UsePanel.Name = "m_UsePanel";
    this.m_UsePanel.Size = new Size(476, 18);
    this.m_UsePanel.TabIndex = 14;
    this.m_SegmentRadioButton.AutoSize = true;
    this.m_SegmentRadioButton.Location = new Point(0, 0);
    this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
    this.m_SegmentRadioButton.Size = new Size(67, 17);
    this.m_SegmentRadioButton.TabIndex = 0;
    this.m_SegmentRadioButton.Text = "&Segment";
    this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_ChainRadioButton.AutoSize = true;
    this.m_ChainRadioButton.Checked = true;
    this.m_ChainRadioButton.Location = new Point(207, 0);
    this.m_ChainRadioButton.Name = "m_ChainRadioButton";
    this.m_ChainRadioButton.Size = new Size(52, 17);
    this.m_ChainRadioButton.TabIndex = 1;
    this.m_ChainRadioButton.TabStop = true;
    this.m_ChainRadioButton.Text = "&Chain";
    this.m_ChainRadioButton.UseVisualStyleBackColor = true;
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_UseExistingHostLineRadioButton);
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_DrawHostLineRadioButton);
    this.m_HostLineSelectionPanel.Location = new Point(12, 236);
    this.m_HostLineSelectionPanel.Name = "m_HostLineSelectionPanel";
    this.m_HostLineSelectionPanel.Size = new Size(476, 41);
    this.m_HostLineSelectionPanel.TabIndex = 16 /*0x10*/;
    this.m_UseExistingHostLineRadioButton.AutoSize = true;
    this.m_UseExistingHostLineRadioButton.Location = new Point(0, 0);
    this.m_UseExistingHostLineRadioButton.Name = "m_UseExistingHostLineRadioButton";
    this.m_UseExistingHostLineRadioButton.Size = new Size(146, 17);
    this.m_UseExistingHostLineRadioButton.TabIndex = 0;
    this.m_UseExistingHostLineRadioButton.Text = "&Use an Existing Host Line";
    this.m_UseExistingHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_UseExistingHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_DrawHostLineRadioButton.AutoSize = true;
    this.m_DrawHostLineRadioButton.Location = new Point(0, 23);
    this.m_DrawHostLineRadioButton.Name = "m_DrawHostLineRadioButton";
    this.m_DrawHostLineRadioButton.Size = new Size(228, 17);
    this.m_DrawHostLineRadioButton.TabIndex = 1;
    this.m_DrawHostLineRadioButton.Text = "&Draw Host Line (Click Escape to Complete)";
    this.m_DrawHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_DrawHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_PickInRevitButton.Enabled = false;
    this.m_PickInRevitButton.Image = (Image) componentResourceManager.GetObject("m_PickInRevitButton.Image");
    this.m_PickInRevitButton.Location = new Point(464, 12);
    this.m_PickInRevitButton.Name = "m_PickInRevitButton";
    this.m_PickInRevitButton.Size = new Size(24, 20);
    this.m_PickInRevitButton.TabIndex = 3;
    this.m_PickInRevitButton.TabStop = false;
    this.m_PickInRevitButton.UseVisualStyleBackColor = true;
    this.m_PickInRevitButton.Click += new EventHandler(this.OnPickInRevitButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(500, 343);
    this.Controls.Add((Control) this.m_PickInRevitButton);
    this.Controls.Add((Control) this.m_HostLineSelectionPanel);
    this.Controls.Add((Control) this.m_UsePanel);
    this.Controls.Add((Control) this.m_ConstantElevationRadioButton);
    this.Controls.Add((Control) this.m_RelativeElevationLabel);
    this.Controls.Add((Control) this.m_RelativeElevationTextBox);
    this.Controls.Add((Control) this.m_RelativeElevationRadioButton);
    this.Controls.Add((Control) this.m_NameLabel);
    this.Controls.Add((Control) this.m_NameTextBox);
    this.Controls.Add((Control) this.m_RadiusLabel);
    this.Controls.Add((Control) this.m_RadiusTextBox);
    this.Controls.Add((Control) this.m_CreateCopyCheckBox);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.Controls.Add((Control) this.m_ConstantElevationLabel);
    this.Controls.Add((Control) this.m_ConstantElevationTextBox);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_TypeNameComboBox);
    this.Controls.Add((Control) this.m_TypeNameLabel);
    this.Controls.Add((Control) this.m_FamilyComboBox);
    this.Controls.Add((Control) this.m_FamilyLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (LocateSiteComponentForm);
    this.Text = "Locate Soft Terrain";
    this.Shown += new EventHandler(this.OnLocateSiteComponentFormShown);
    this.FormClosing += new FormClosingEventHandler(this.OnLocateSiteComponentClosing);
    this.m_MoveablePanel.ResumeLayout(false);
    this.m_UsePanel.ResumeLayout(false);
    this.m_UsePanel.PerformLayout();
    this.m_HostLineSelectionPanel.ResumeLayout(false);
    this.m_HostLineSelectionPanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
