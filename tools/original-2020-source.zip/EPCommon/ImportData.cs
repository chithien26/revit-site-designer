﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ImportData
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ImportData
{
  protected Document m_CurDocument;
  protected Document m_ActiveDoc;
  protected EPTransactionContainer m_TransactionContainer;
  protected bool m_bAbortTransaction;
  protected string m_strImportFolder;
  protected string m_strImportFileFullName;
  protected string m_strSaveAsFileName;

  public Document CurDocument => this.m_CurDocument;

  public string ImportFileFullName
  {
    get => this.m_strImportFileFullName;
    set => this.m_strImportFileFullName = value;
  }

  public string SaveAsFileName
  {
    get => this.m_strSaveAsFileName;
    set => this.m_strSaveAsFileName = value;
  }

  public string ImportFolder
  {
    get => this.m_strImportFolder;
    set => this.m_strImportFolder = value;
  }

  public ImportData(Document _CurDocument)
  {
    this.m_bAbortTransaction = true;
    this.m_CurDocument = _CurDocument;
    string empty = string.Empty;
    if (!ManagePlants.FindTemplateFileName(this.m_CurDocument, ref empty, true))
      return;
    this.m_ActiveDoc = this.m_CurDocument.Application.NewFamilyDocument(empty);
    this.m_TransactionContainer = new EPTransactionContainer(this.m_ActiveDoc);
    this.Initialize();
  }

  private void Initialize()
  {
    this.m_strImportFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
    this.m_strImportFileFullName = string.Empty;
  }

  public virtual bool Import()
  {
    if (this.m_strImportFileFullName == null)
      throw new NullReferenceException();
    return true;
  }

  public DialogResult CompleteTransaction()
  {
    DialogResult dialogResult = DialogResult.Cancel;
    this.m_ActiveDoc.Close(false);
    if (!this.m_bAbortTransaction)
      dialogResult = DialogResult.OK;
    return dialogResult;
  }
}
