﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RevitUtility
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class RevitUtility
{
  public const int PROGRESSBAR_DELAY = 300;

  public static string GetFormattedFileName(string _strFileName)
  {
    return RevitUtility.GetFormattedFileName(_strFileName, false);
  }

  public static string GetFormattedFileName(string _strFileName, bool _bCreateDirectory)
  {
    string formattedFileName = string.Empty;
    if (_strFileName != string.Empty)
    {
      _strFileName = _strFileName.Replace('/', '\\');
      FileInfo fileInfo = new FileInfo(_strFileName);
      string path = string.Empty;
      string name = fileInfo.Name;
      if (_strFileName.IndexOf('\\') >= 0)
      {
        path = fileInfo.DirectoryName;
        if (!path.EndsWith("\\"))
          path += "\\";
      }
      if (_bCreateDirectory && !Directory.Exists(path))
        Directory.CreateDirectory(path);
      formattedFileName = path + name;
    }
    return formattedFileName;
  }

  public static int CompareFileNames(string _strFirstFileName, string _strSecondFileName)
  {
    return string.Compare(RevitUtility.GetFormattedFileName(_strFirstFileName), RevitUtility.GetFormattedFileName(_strSecondFileName), true);
  }

  public static string GetFormattedDirectoryName(string _strDirectoryName)
  {
    return RevitUtility.GetFormattedDirectoryName(_strDirectoryName, false);
  }

  public static string GetFormattedDirectoryName(string _strDirectoryName, bool _bCreateDirectory)
  {
    string formattedDirectoryName = string.Empty;
    if (_strDirectoryName != string.Empty)
    {
      _strDirectoryName = _strDirectoryName.Replace('/', '\\');
      string name = new DirectoryInfo(_strDirectoryName).Name;
      if (!name.EndsWith("\\"))
        name += "\\";
      if (_bCreateDirectory && !Directory.Exists(name))
        Directory.CreateDirectory(name);
      formattedDirectoryName = name;
    }
    return formattedDirectoryName;
  }

  public static int CompareDirectoryNames(
    string _strFirstDirectoryName,
    string _strSecondDirectoryName)
  {
    return string.Compare(RevitUtility.GetFormattedDirectoryName(_strFirstDirectoryName), RevitUtility.GetFormattedDirectoryName(_strSecondDirectoryName), true);
  }

  public static Element GetSurfaceContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList)
  {
    double _dElevation = 0.0;
    return RevitUtility.GetSurfaceContainingPoint(_FindPoint, _SurfaceList, ref _dElevation);
  }

  public static bool GetFullFamilyFilenameIfExist(
    string _strSearchFilename,
    ref string _strFullFamilyFilename)
  {
    return RevitUtility.GetFullFamilyFilenameIfExist(string.Empty, _strSearchFilename, ref _strFullFamilyFilename);
  }

  public static bool GetFullFamilyFilenameIfExist(
    string _strLibrarySubFolder,
    string _strSearchFilename,
    ref string _strFullFamilyFilename)
  {
    if (_strLibrarySubFolder != string.Empty && !_strLibrarySubFolder.EndsWith("\\"))
      _strLibrarySubFolder += "\\";
    string empty = string.Empty;
    string str = "2011\\";
    ApplicationUtility.RegistryPaths.GetLibraryPath(str + _strLibrarySubFolder + _strSearchFilename, ref _strFullFamilyFilename);
    if (File.Exists(_strFullFamilyFilename))
      return true;
    ApplicationUtility.RegistryPaths.GetSamplePath(str + _strSearchFilename, ref _strFullFamilyFilename);
    if (File.Exists(_strFullFamilyFilename))
      return true;
    ApplicationUtility.RegistryPaths.GetLibraryPath(_strLibrarySubFolder + _strSearchFilename, ref _strFullFamilyFilename);
    if (File.Exists(_strFullFamilyFilename))
      return true;
    ApplicationUtility.RegistryPaths.GetSamplePath(_strSearchFilename, ref _strFullFamilyFilename);
    return File.Exists(_strFullFamilyFilename);
  }

  public static Element GetSurfaceContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList,
    ref double _dElevation)
  {
    return RevitUtility.GetSurfaceContainingPoint(_FindPoint, _SurfaceList, (Phase) null, ref _dElevation);
  }

  public static Element GetSurfaceContainingPoint(
    Eps_Point _FindPoint,
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase,
    ref double _dElevation)
  {
    _dElevation = 0.0;
    if (_SurfaceList != null && _SurfaceList.Count > 0)
    {
      for (int index = 0; index < _SurfaceList.Count; ++index)
      {
        Element surfaceContainingPoint = (Element) _SurfaceList[index].GetSurfaceContainingPoint(_FindPoint, _CurPhase, ref _dElevation);
        if (surfaceContainingPoint != null)
          return surfaceContainingPoint;
      }
    }
    return (Element) null;
  }

  public static bool GetElementsFromProject(
    Document _Document,
    string _strPrompt,
    ref ElementSet _Elements)
  {
    return RevitUtility.GetElementsFromProject(_Document, _strPrompt, ref _Elements, true, PickMethod.PickObject);
  }

  public static bool GetElementsFromProject(
    Document _Document,
    string _strPrompt,
    ref ElementSet _Elements,
    bool _bDisplayError)
  {
    return RevitUtility.GetElementsFromProject(_Document, _strPrompt, ref _Elements, _bDisplayError, PickMethod.PickObject);
  }

  public static bool GetElementsFromProject(
    Document _Document,
    string _strPrompt,
    ref ElementSet _Elements,
    bool _bDisplayError,
    PickMethod _PickMethod)
  {
    UIDocument uiDocument = new UIDocument(_Document);
    switch (_PickMethod)
    {
      case PickMethod.PickObject:
        Reference reference1;
        try
        {
          reference1 = uiDocument.Selection.PickObject((ObjectType) 1, _strPrompt);
        }
        catch (OperationCanceledException ex)
        {
          if (_bDisplayError)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
          }
          return false;
        }
        if (reference1 != null && _Document.GetElement(reference1) != null)
        {
          _Elements = new ElementSet();
          _Elements.Insert(_Document.GetElement(reference1));
          break;
        }
        if (_bDisplayError)
        {
          int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
        return false;
      case PickMethod.PickObjects:
        try
        {
          bool flag = true;
          while (flag)
          {
            Reference reference2 = uiDocument.Selection.PickObject((ObjectType) 1, _strPrompt);
            if (reference2 != null && _Document.GetElement(reference2) != null)
            {
              if (_Elements == null)
                _Elements = new ElementSet();
              _Elements.Insert(_Document.GetElement(reference2));
            }
            else
              flag = false;
          }
        }
        catch (OperationCanceledException ex)
        {
          if (_Elements != null)
          {
            if (_Elements.Size != 0)
              goto label_24;
          }
          if (_bDisplayError)
          {
            int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
          return false;
        }
label_24:
        if (_Elements == null || _Elements.Size == 0)
        {
          if (_bDisplayError)
          {
            int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
          return false;
        }
        break;
      case PickMethod.WindowSelect:
        IList<Element> elementList;
        try
        {
          elementList = uiDocument.Selection.PickElementsByRectangle(_strPrompt);
        }
        catch (OperationCanceledException ex)
        {
          if (_bDisplayError)
          {
            int num4 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
          return false;
        }
        if (elementList != null && elementList.Count > 0)
        {
          _Elements = new ElementSet();
          for (int index = 0; index < elementList.Count; ++index)
            _Elements.Insert(elementList[index]);
          break;
        }
        if (_bDisplayError)
        {
          int num5 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoObject"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
        return false;
    }
    uiDocument.Selection.Dispose();
    return true;
  }

  public static bool GetPointFromProject(
    Document _Document,
    string _strPrompt,
    ref Eps_Point _Point,
    bool _bDisplayError)
  {
    try
    {
      UIDocument uiDocument = new UIDocument(_Document);
      _Point = new Eps_Point(uiDocument.Selection.PickPoint(_strPrompt));
    }
    catch (OperationCanceledException ex)
    {
      if (_bDisplayError)
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPointPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      return false;
    }
    catch (AccessViolationException ex)
    {
      int num = (int) RevitMessageBox.Show("Install Update 1 for Revit 2011.", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    return true;
  }

  public static bool PickSideLeg(Document _Document, Eps_Leg _CurrentLeg, ref bool _UseRightSide)
  {
    return RevitUtility.PickSideLeg(_Document, _CurrentLeg, ref _UseRightSide, EPShared.LocalRM.GetString("PickOffsetSideMessage"));
  }

  public static bool PickSideLeg(
    Document _Document,
    Eps_Leg _CurrentLeg,
    ref bool _UseRightSide,
    string _strPrompt)
  {
    Eps_Point _Point = new Eps_Point();
    if (!RevitUtility.GetPointFromProject(_Document, _strPrompt, ref _Point, true))
      return false;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _CurrentLeg, ref _dStation, ref _dOffset, true);
    _UseRightSide = RevitDefines.GT(_dOffset, 0.0);
    return true;
  }

  public static bool PickSideLine(
    Document _Document,
    Eps_Line _CurrentLine,
    ref bool _UseRightSide)
  {
    return RevitUtility.PickSideLine(_Document, _CurrentLine, ref _UseRightSide, EPShared.LocalRM.GetString("PickOffsetSideMessage"));
  }

  public static bool PickSideLine(
    Document _Document,
    Eps_Line _CurrentLine,
    ref bool _UseRightSide,
    string _strPrompt)
  {
    Eps_Point _Point = new Eps_Point();
    if (!RevitUtility.GetPointFromProject(_Document, _strPrompt, ref _Point, true))
      return false;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    EPShared.eplGeoE_CalcStationOffsetAlongLine(_Point, _CurrentLine, ref _dStation, ref _dOffset, 0.0);
    _UseRightSide = RevitDefines.GT(_dOffset, 0.0);
    return true;
  }

  public static bool PickSideArc(Document _Document, Eps_Arc _CurrentArc, ref bool _UseRightSide)
  {
    return RevitUtility.PickSideArc(_Document, _CurrentArc, ref _UseRightSide, EPShared.LocalRM.GetString("PickOffsetSideMessage"));
  }

  public static bool PickSideArc(
    Document _Document,
    Eps_Arc _CurrentArc,
    ref bool _UseRightSide,
    string _strPrompt)
  {
    Eps_Point _Point = new Eps_Point();
    if (!RevitUtility.GetPointFromProject(_Document, _strPrompt, ref _Point, true))
      return false;
    double _dStation = 0.0;
    double _dOffset = 0.0;
    EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _CurrentArc, ref _dStation, ref _dOffset, 0.0);
    _UseRightSide = RevitDefines.GT(_dOffset, 0.0);
    return true;
  }

  public static bool BreakApartLeg(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Leg _EvalLeg,
    ref Eps_Leg _FirstLeg,
    ref Eps_Leg _SecondLeg,
    ref bool _bPickFirstLeg,
    ref bool _bPickMiddleSegment,
    ref Eps_Point _PickedPoint,
    string _strPrompt)
  {
    bool flag = RevitUtility.BreakApartLeg(_Document, _TransactionContainer, _dCircleRadius, _EvalLeg, false, true, ref _FirstLeg, ref _SecondLeg, ref _bPickFirstLeg, ref _bPickMiddleSegment, false, _strPrompt, (List<Eps_Point>) null);
    if (_FirstLeg != null)
    {
      _PickedPoint = _FirstLeg.LegStartPnt;
      _FirstLeg = _FirstLeg.Reverse();
    }
    else if (_SecondLeg != null)
      _PickedPoint = _SecondLeg.LegStartPnt;
    return flag;
  }

  public static bool BreakApartLeg(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Leg _EvalLeg,
    ref Eps_Leg _FirstLeg,
    ref Eps_Leg _SecondLeg,
    ref bool _bPickFirstLeg,
    ref bool _bPickMiddleSegment,
    ref Eps_Point _PickedPoint,
    string _strPrompt,
    List<Eps_Point> _ExcludePoints)
  {
    bool flag = RevitUtility.BreakApartLeg(_Document, _TransactionContainer, _dCircleRadius, _EvalLeg, false, true, ref _FirstLeg, ref _SecondLeg, ref _bPickFirstLeg, ref _bPickMiddleSegment, false, _strPrompt, _ExcludePoints);
    if (_FirstLeg != null)
    {
      _PickedPoint = _FirstLeg.LegStartPnt;
      _FirstLeg = _FirstLeg.Reverse();
    }
    else if (_SecondLeg != null)
      _PickedPoint = _SecondLeg.LegStartPnt;
    return flag;
  }

  public static bool BreakApartLeg(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Leg _EvalLeg,
    bool _bPromptForDirection,
    ref Eps_Leg _FirstLeg,
    ref Eps_Leg _SecondLeg,
    ref bool _bPickFirstLeg,
    ref bool _bPickMiddleSegment)
  {
    return RevitUtility.BreakApartLeg(_Document, _TransactionContainer, _dCircleRadius, _EvalLeg, _bPromptForDirection, false, ref _FirstLeg, ref _SecondLeg, ref _bPickFirstLeg, ref _bPickMiddleSegment, true, EPShared.LocalRM.GetString("PickStartingSideMessage"), (List<Eps_Point>) null);
  }

  public static bool BreakApartLeg(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Leg _EvalLeg,
    bool _bAllPromptForDirection,
    bool _bOnlyPromptMiddle,
    ref Eps_Leg _FirstLeg,
    ref Eps_Leg _SecondLeg,
    ref bool _bPickFirstLeg,
    ref bool _bPickMiddleSegment,
    bool _bDisplayError,
    string _strPrompt)
  {
    return RevitUtility.BreakApartLeg(_Document, _TransactionContainer, _dCircleRadius, _EvalLeg, _bAllPromptForDirection, _bOnlyPromptMiddle, ref _FirstLeg, ref _SecondLeg, ref _bPickFirstLeg, ref _bPickMiddleSegment, _bDisplayError, _strPrompt, (List<Eps_Point>) null);
  }

  public static bool BreakApartLeg(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Leg _EvalLeg,
    bool _bAllPromptForDirection,
    bool _bOnlyPromptMiddle,
    ref Eps_Leg _FirstLeg,
    ref Eps_Leg _SecondLeg,
    ref bool _bPickFirstLeg,
    ref bool _bPickMiddleSegment,
    bool _bDisplayError,
    string _strPrompt,
    List<Eps_Point> _ExcludePoints)
  {
    Eps_Point _FirstCheckPnt = new Eps_Point();
    bool flag1 = false;
    bool flag2 = false;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    _PointList.Add(_EvalLeg.LegStartPnt);
    for (Eps_Leg epsLeg = _EvalLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _FirstCheckPnt);
        _PointList.Add(_FirstCheckPnt);
        _PointList.Add(epsLeg.Line.EndPnt);
      }
      else if (epsLeg.Arc != null)
      {
        double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta);
        EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, num / 2.0, 0.0, ref _FirstCheckPnt);
        _PointList.Add(_FirstCheckPnt);
        _PointList.Add(epsLeg.Arc.EndPnt);
      }
    }
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLeg.LegStartPnt, _EvalLeg.LegEndPnt, ref _dDistance);
    if (!RevitDefines.EQ(_dDistance, 0.0) && _dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    if (_ExcludePoints != null && _ExcludePoints.Count > 0 && _PointList.Count > 0)
    {
      List<Eps_Point> epsPointList = new List<Eps_Point>();
      epsPointList.AddRange((IEnumerable<Eps_Point>) _ExcludePoints);
      for (int index1 = _PointList.Count - 1; index1 >= 0; --index1)
      {
        for (int index2 = epsPointList.Count - 1; index2 >= 0; --index2)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates2D(_PointList[index1], epsPointList[index2]))
          {
            _PointList.RemoveAt(index1);
            epsPointList.RemoveAt(index2);
            break;
          }
        }
      }
    }
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint, (ElementSet) null, _bDisplayError, _strPrompt))
    {
      _bPickMiddleSegment = false;
      flag1 = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLeg.LegStartPnt, _UsePoint))
      {
        _SecondLeg = _EvalLeg;
        _FirstLeg = (Eps_Leg) null;
        _bPickFirstLeg = false;
        return true;
      }
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLeg.LegEndPnt, _UsePoint))
      {
        _SecondLeg = (Eps_Leg) null;
        _FirstLeg = _EvalLeg.Reverse();
        _bPickFirstLeg = true;
        return true;
      }
      for (Eps_Leg _CompleteLeg1 = _EvalLeg; _CompleteLeg1 != null; _CompleteLeg1 = _CompleteLeg1.Next)
      {
        if (flag2)
        {
          if (_SecondLeg == null)
            _SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
          else
            _SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
        }
        else if (_CompleteLeg1.Line != null)
        {
          RevitGeometry.eplGeoE_CalcMidPointBetweenTwoPoints3D(_CompleteLeg1.Line.StartPnt, _CompleteLeg1.Line.EndPnt, ref _FirstCheckPnt);
          if (EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt, _UsePoint))
          {
            _bPickMiddleSegment = true;
            flag2 = true;
            Eps_Leg _CompleteLeg2 = new Eps_Leg();
            _CompleteLeg2.Line = new Eps_Line();
            _CompleteLeg2.Line.StartPnt = _CompleteLeg1.Line.StartPnt;
            _CompleteLeg2.Line.EndPnt = _FirstCheckPnt;
            _CompleteLeg2.Element = _CompleteLeg1.Element;
            if (_FirstLeg == null)
              _FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg2);
            else
              _FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
            Eps_Leg _CompleteLeg3 = new Eps_Leg();
            _CompleteLeg3.Line = new Eps_Line();
            _CompleteLeg3.Line.StartPnt = _FirstCheckPnt;
            _CompleteLeg3.Line.EndPnt = _CompleteLeg1.Line.EndPnt;
            _CompleteLeg3.Element = _CompleteLeg1.Element;
            if (_SecondLeg == null)
              _SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg3);
            else
              _SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg3);
          }
          else
          {
            if (_FirstLeg == null)
              _FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
            else
              _FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
            if (EPShared.eplGeoE_ArePntsDuplicates2D(_CompleteLeg1.Line.EndPnt, _UsePoint))
              flag2 = true;
          }
        }
        else if (_CompleteLeg1.Arc != null)
        {
          double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_CompleteLeg1.Arc.Radius, _CompleteLeg1.Arc.Delta);
          EPShared.eplGeoE_FindStaOffPointAlongArc(_CompleteLeg1.Arc, num / 2.0, 0.0, ref _FirstCheckPnt);
          _FirstCheckPnt.z = _CompleteLeg1.Arc.RadiusPnt.z;
          if (EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt, _UsePoint))
          {
            _bPickMiddleSegment = true;
            flag2 = true;
            Eps_Leg _CompleteLeg4 = new Eps_Leg();
            _CompleteLeg4.Arc = new Eps_Arc(_CompleteLeg1.Arc);
            _CompleteLeg4.Arc.Delta = _CompleteLeg1.Arc.Delta / 2.0;
            _CompleteLeg4.Arc.StartPnt = _CompleteLeg1.Arc.StartPnt;
            _CompleteLeg4.Arc.EndPnt = _FirstCheckPnt;
            _CompleteLeg4.Element = _CompleteLeg1.Element;
            if (_FirstLeg == null)
              _FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg4);
            else
              _FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg4);
            Eps_Leg _CompleteLeg5 = new Eps_Leg();
            _CompleteLeg5.Arc = new Eps_Arc(_CompleteLeg1.Arc);
            _CompleteLeg5.Arc.Delta = _CompleteLeg1.Arc.Delta / 2.0;
            _CompleteLeg5.Arc.StartPnt = _FirstCheckPnt;
            _CompleteLeg5.Arc.EndPnt = _CompleteLeg1.Arc.EndPnt;
            _CompleteLeg5.Element = _CompleteLeg1.Element;
            if (_SecondLeg == null)
              _SecondLeg = Eps_Leg.SingleLeg(_CompleteLeg5);
            else
              _SecondLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg5);
          }
          else
          {
            if (_FirstLeg == null)
              _FirstLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
            else
              _FirstLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
            if (EPShared.eplGeoE_ArePntsDuplicates2D(_CompleteLeg1.Arc.EndPnt, _UsePoint))
              flag2 = true;
          }
        }
      }
      if (_FirstLeg != null)
      {
        _FirstLeg = _FirstLeg.Reverse();
        if ((_bAllPromptForDirection || _bOnlyPromptMiddle && _bPickMiddleSegment) && _SecondLeg != null)
        {
          Eps_Point _FindPoint1 = new Eps_Point();
          Eps_Point _FindPoint2 = new Eps_Point();
          double _dDirection1 = 0.0;
          double _dDirection2 = 0.0;
          if (RevitUtility.FindDistPointAndDirectionAlongLeg(_FirstLeg, _dCircleRadius, ref _FindPoint1, ref _dDirection1) && RevitUtility.FindDistPointAndDirectionAlongLeg(_SecondLeg, _dCircleRadius, ref _FindPoint2, ref _dDirection2))
            return RevitUtility.PickDirection(_Document, _TransactionContainer, _dCircleRadius * 2.0, _FindPoint1, _dDirection1, _FindPoint2, _dDirection2, ref _bPickFirstLeg);
        }
      }
    }
    return flag1;
  }

  public static bool RemoveLegFromLegList(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Leg _EvalLeg,
    ref Eps_Leg _ReturnLeg,
    bool _bDisplayError,
    string _strPrompt)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    if (_EvalLeg.Line != null)
      _PointList.Add(_EvalLeg.Line.StartPnt);
    for (Eps_Leg epsLeg = _EvalLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        if (epsLeg.Next == null || epsLeg.Next.Line != null)
          _PointList.Add(epsLeg.Line.EndPnt);
      }
      else if (epsLeg.Arc != null)
      {
        double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta);
        EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, num / 2.0, 0.0, ref _StaOffPnt);
        _PointList.Add(_StaOffPnt);
      }
    }
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLeg.LegStartPnt, _EvalLeg.LegEndPnt, ref _dDistance);
    if (!RevitDefines.EQ(_dDistance, 0.0) && _dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint, (ElementSet) null, _bDisplayError, _strPrompt))
    {
      flag1 = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLeg.LegStartPnt, _UsePoint))
      {
        if (_EvalLeg.Next != null)
        {
          if (!_EvalLeg.IsLegClosed())
          {
            _ReturnLeg = Eps_Leg.CopyLeg(_EvalLeg.Next);
          }
          else
          {
            Eps_Leg next;
            for (next = _EvalLeg.Next; next.Next != null; next = next.Next)
            {
              if (_ReturnLeg == null)
                _ReturnLeg = Eps_Leg.SingleLeg(next);
              else
                _ReturnLeg.Last.Next = Eps_Leg.SingleLeg(next);
            }
            if (next != null)
            {
              Eps_Leg _CompleteLeg = new Eps_Leg();
              if (next.Line != null)
              {
                _CompleteLeg.Line = new Eps_Line();
                _CompleteLeg.Line.StartPnt = next.Line.StartPnt;
                _CompleteLeg.Line.EndPnt = _ReturnLeg.LegStartPnt;
              }
              else if (next.Arc != null)
              {
                _CompleteLeg.Arc = new Eps_Arc(next.Arc);
                _CompleteLeg.Arc.EndPnt = _ReturnLeg.LegStartPnt;
              }
              if (_ReturnLeg == null)
                _ReturnLeg = Eps_Leg.SingleLeg(_CompleteLeg);
              else
                _ReturnLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
            }
          }
        }
        return true;
      }
      for (Eps_Leg _CompleteLeg1 = _EvalLeg; _CompleteLeg1 != null; _CompleteLeg1 = _CompleteLeg1.Next)
      {
        if (flag3)
        {
          flag3 = false;
        }
        else
        {
          if (!flag2)
          {
            if (_CompleteLeg1.Line != null)
            {
              if (EPShared.eplGeoE_ArePntsDuplicates2D(_CompleteLeg1.Line.EndPnt, _UsePoint))
              {
                flag2 = true;
                if (_CompleteLeg1.Next != null && _CompleteLeg1.Next.Line != null)
                {
                  flag3 = true;
                  Eps_Leg _CompleteLeg2 = new Eps_Leg();
                  _CompleteLeg2.Line = new Eps_Line();
                  _CompleteLeg2.Line.StartPnt = _CompleteLeg1.Line.StartPnt;
                  _CompleteLeg2.Line.EndPnt = _CompleteLeg1.Next.Line.EndPnt;
                  if (_ReturnLeg == null)
                  {
                    _ReturnLeg = Eps_Leg.SingleLeg(_CompleteLeg2);
                    continue;
                  }
                  _ReturnLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
                  continue;
                }
                continue;
              }
            }
            else if (_CompleteLeg1.Arc != null)
            {
              double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_CompleteLeg1.Arc.Radius, _CompleteLeg1.Arc.Delta);
              EPShared.eplGeoE_FindStaOffPointAlongArc(_CompleteLeg1.Arc, num / 2.0, 0.0, ref _StaOffPnt);
              _StaOffPnt.z = _CompleteLeg1.Arc.RadiusPnt.z;
              if (EPShared.eplGeoE_ArePntsDuplicates2D(_StaOffPnt, _UsePoint))
              {
                flag2 = true;
                Eps_Leg _CompleteLeg3 = new Eps_Leg();
                _CompleteLeg3.Line = new Eps_Line();
                _CompleteLeg3.Line.StartPnt = _CompleteLeg1.Arc.StartPnt;
                _CompleteLeg3.Line.EndPnt = _CompleteLeg1.Arc.EndPnt;
                if (_ReturnLeg == null)
                {
                  _ReturnLeg = Eps_Leg.SingleLeg(_CompleteLeg3);
                  continue;
                }
                _ReturnLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg3);
                continue;
              }
            }
          }
          if (_ReturnLeg == null)
            _ReturnLeg = Eps_Leg.SingleLeg(_CompleteLeg1);
          else
            _ReturnLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
        }
      }
    }
    return flag1;
  }

  private static bool FindDistPointAndDirectionAlongLeg(
    Eps_Leg _EvalLeg,
    double _dDistance,
    ref Eps_Point _FindPoint,
    ref double _dDirection)
  {
    _dDirection = 0.0;
    double _dDistance1 = 0.0;
    for (Eps_Leg epsLeg = _EvalLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance1);
        if (_dDistance < _dDistance1)
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDirection);
          EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _dDistance, ref _FindPoint);
          return true;
        }
        _dDistance -= _dDistance1;
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance1 = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta);
        if (_dDistance < _dDistance1)
        {
          EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dDistance, 0.0, ref _FindPoint);
          EPShared.eplGeoE_CalcTangentDirOfArc(_FindPoint, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Direction, ref _dDirection);
          return true;
        }
        _dDistance -= _dDistance1;
      }
    }
    return false;
  }

  public static bool EvaluateLeg(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    ref Eps_Leg _EvalLeg)
  {
    bool leg = false;
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLeg.LegStartPnt, _EvalLeg.LegEndPnt, ref _dDistance);
    if (RevitDefines.EQ(_dDistance, 0.0) && RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(_EvalLeg), 0.0))
      return true;
    if (RevitDefines.GT(_dDistance / 10.0, 0.0) && _dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    if (RevitDefines.EQ(_dCircleRadius, 0.0))
      _dCircleRadius = 1.0;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    _PointList.Add(_EvalLeg.LegStartPnt);
    _PointList.Add(_EvalLeg.LegEndPnt);
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint))
    {
      leg = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLeg.LegEndPnt, _UsePoint))
        _EvalLeg = _EvalLeg.Reverse();
    }
    return leg;
  }

  public static bool BreakApartLine(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Line _EvalLine,
    bool _bPromptForDirection,
    ref Eps_Line _FirstLine,
    ref Eps_Line _SecondLine,
    ref bool _bPickFirstLine)
  {
    Eps_Point _MidPoint = new Eps_Point();
    bool flag = false;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    _PointList.Add(_EvalLine.StartPnt);
    EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_EvalLine.StartPnt, _EvalLine.EndPnt, ref _MidPoint);
    _PointList.Add(_MidPoint);
    _PointList.Add(_EvalLine.EndPnt);
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLine.StartPnt, _EvalLine.EndPnt, ref _dDistance);
    if (_dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint))
    {
      flag = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLine.StartPnt, _UsePoint))
      {
        _SecondLine = _EvalLine;
        _FirstLine = (Eps_Line) null;
        _bPickFirstLine = false;
        return true;
      }
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLine.EndPnt, _UsePoint))
      {
        _SecondLine = (Eps_Line) null;
        _FirstLine = _EvalLine.Reverse();
        _bPickFirstLine = true;
        return true;
      }
      EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_EvalLine.StartPnt, _EvalLine.EndPnt, ref _MidPoint);
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_MidPoint, _UsePoint))
      {
        Eps_Line epsLine1 = new Eps_Line();
        epsLine1.StartPnt = _EvalLine.StartPnt;
        epsLine1.EndPnt = _MidPoint;
        if (_FirstLine == null)
          _FirstLine = epsLine1;
        Eps_Line epsLine2 = new Eps_Line();
        epsLine2.StartPnt = _MidPoint;
        epsLine2.EndPnt = _EvalLine.EndPnt;
        if (_SecondLine == null)
          _SecondLine = epsLine2;
      }
      if (_FirstLine != null)
      {
        _FirstLine = _FirstLine.Reverse();
        if (_bPromptForDirection && _SecondLine != null)
        {
          Eps_Point _FindPoint1 = new Eps_Point();
          Eps_Point _FindPoint2 = new Eps_Point();
          double _dDirection1 = 0.0;
          double _dDirection2 = 0.0;
          if (RevitUtility.FindDistPointAndDirectionAlongLine(_FirstLine, _dCircleRadius, ref _FindPoint1, ref _dDirection1) && RevitUtility.FindDistPointAndDirectionAlongLine(_SecondLine, _dCircleRadius, ref _FindPoint2, ref _dDirection2))
            return RevitUtility.PickDirection(_Document, _TransactionContainer, _dCircleRadius * 2.0, _FindPoint1, _dDirection1, _FindPoint2, _dDirection2, ref _bPickFirstLine);
        }
      }
    }
    return flag;
  }

  private static bool FindDistPointAndDirectionAlongLine(
    Eps_Line _EvalLine,
    double _dDistance,
    ref Eps_Point _FindPoint,
    ref double _dDirection)
  {
    _dDirection = 0.0;
    double _dDistance1 = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLine.StartPnt, _EvalLine.EndPnt, ref _dDistance1);
    if (_dDistance >= _dDistance1)
      return false;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_EvalLine.StartPnt, _EvalLine.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcPolarToXY(_EvalLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection), _dDistance, ref _FindPoint);
    return true;
  }

  public static bool EvaluateLine(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    ref Eps_Line _EvalLine)
  {
    bool line = false;
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalLine.StartPnt, _EvalLine.EndPnt, ref _dDistance);
    if (_dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    _PointList.Add(_EvalLine.StartPnt);
    _PointList.Add(_EvalLine.EndPnt);
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint))
    {
      line = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalLine.EndPnt, _UsePoint))
        _EvalLine = _EvalLine.Reverse();
    }
    return line;
  }

  public static bool BreakApartArc(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    Eps_Arc _EvalArc,
    bool _bPromptForDirection,
    ref Eps_Arc _FirstArc,
    ref Eps_Arc _SecondArc,
    ref bool _bPickFirstArc)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    bool flag = false;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    _PointList.Add(_EvalArc.StartPnt);
    double num1 = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_EvalArc.Radius, _EvalArc.Delta);
    EPShared.eplGeoE_FindStaOffPointAlongArc(_EvalArc, num1 / 2.0, 0.0, ref _StaOffPnt);
    _PointList.Add(_StaOffPnt);
    _PointList.Add(_EvalArc.EndPnt);
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalArc.StartPnt, _EvalArc.EndPnt, ref _dDistance);
    if (_dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint))
    {
      flag = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalArc.StartPnt, _UsePoint))
      {
        _SecondArc = _EvalArc;
        _FirstArc = (Eps_Arc) null;
        _bPickFirstArc = false;
        return true;
      }
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalArc.EndPnt, _UsePoint))
      {
        _SecondArc = (Eps_Arc) null;
        _FirstArc = _EvalArc.Reverse();
        _bPickFirstArc = true;
        return true;
      }
      double num2 = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_EvalArc.Radius, _EvalArc.Delta);
      EPShared.eplGeoE_FindStaOffPointAlongArc(_EvalArc, num2 / 2.0, 0.0, ref _StaOffPnt);
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_StaOffPnt, _UsePoint))
      {
        Eps_Arc epsArc1 = new Eps_Arc(_EvalArc);
        epsArc1.Delta = _EvalArc.Delta / 2.0;
        epsArc1.StartPnt = _EvalArc.StartPnt;
        epsArc1.EndPnt = _StaOffPnt;
        if (_FirstArc == null)
          _FirstArc = epsArc1;
        Eps_Arc epsArc2 = new Eps_Arc(_EvalArc);
        epsArc2.Delta = _EvalArc.Delta / 2.0;
        epsArc2.StartPnt = _StaOffPnt;
        epsArc2.EndPnt = _EvalArc.EndPnt;
        if (_SecondArc == null)
          _SecondArc = epsArc2;
      }
      if (_FirstArc != null)
      {
        _FirstArc = _FirstArc.Reverse();
        if (_bPromptForDirection && _SecondArc != null)
        {
          Eps_Point _FindPoint1 = new Eps_Point();
          Eps_Point _FindPoint2 = new Eps_Point();
          double _dDirection1 = 0.0;
          double _dDirection2 = 0.0;
          if (RevitUtility.FindDistPointAndDirectionAlongArc(_FirstArc, _dCircleRadius, ref _FindPoint1, ref _dDirection1) && RevitUtility.FindDistPointAndDirectionAlongArc(_SecondArc, _dCircleRadius, ref _FindPoint2, ref _dDirection2))
            return RevitUtility.PickDirection(_Document, _TransactionContainer, _dCircleRadius * 2.0, _FindPoint1, _dDirection1, _FindPoint2, _dDirection2, ref _bPickFirstArc);
        }
      }
    }
    return flag;
  }

  private static bool FindDistPointAndDirectionAlongArc(
    Eps_Arc _EvalArc,
    double _dDistance,
    ref Eps_Point _FindPoint,
    ref double _dDirection)
  {
    _dDirection = 0.0;
    double num = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_EvalArc.Radius, _EvalArc.Delta);
    if (_dDistance >= num)
      return false;
    EPShared.eplGeoE_FindStaOffPointAlongArc(_EvalArc, _dDistance, 0.0, ref _FindPoint);
    EPShared.eplGeoE_CalcTangentDirOfArc(_FindPoint, _EvalArc.RadiusPnt, _EvalArc.Direction, ref _dDirection);
    return true;
  }

  public static bool EvaluateArc(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    ref Eps_Arc _EvalArc)
  {
    bool arc = false;
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_EvalArc.StartPnt, _EvalArc.EndPnt, ref _dDistance);
    if (_dCircleRadius > _dDistance / 10.0)
      _dCircleRadius = _dDistance / 10.0;
    List<Eps_Point> _PointList = new List<Eps_Point>();
    _PointList.Add(_EvalArc.StartPnt);
    _PointList.Add(_EvalArc.EndPnt);
    Eps_Point _UsePoint = new Eps_Point();
    if (RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint))
    {
      arc = true;
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_EvalArc.EndPnt, _UsePoint))
        _EvalArc = _EvalArc.Reverse();
    }
    return arc;
  }

  public static bool PickSide(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    List<Eps_Point> _PointList,
    ref Eps_Point _UsePoint)
  {
    return RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint, (ElementSet) null, true, EPShared.LocalRM.GetString("PickStartingSideMessage"));
  }

  public static bool PickSide(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    List<Eps_Point> _PointList,
    ref Eps_Point _UsePoint,
    ElementSet _DeleteElementSet,
    bool _bDisplayError)
  {
    return RevitUtility.PickSide(_Document, _TransactionContainer, _dCircleRadius, _PointList, ref _UsePoint, (ElementSet) null, true, EPShared.LocalRM.GetString("PickStartingSideMessage"));
  }

  public static bool PickSide(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dCircleRadius,
    List<Eps_Point> _PointList,
    ref Eps_Point _UsePoint,
    ElementSet _DeleteElementSet,
    bool _bDisplayError,
    string _strPrompt)
  {
    List<Eps_Arc> epsArcList = new List<Eps_Arc>();
    if (_DeleteElementSet == null)
    {
      _DeleteElementSet = new ElementSet();
      for (int index = 0; index < _PointList.Count; ++index)
      {
        Eps_Arc _Arc = new Eps_Arc();
        _Arc.Radius = _dCircleRadius;
        _Arc.EndPnt = _PointList[index];
        _Arc.RadiusPnt = _PointList[index];
        _Arc.StartPnt = _PointList[index];
        epsArcList.Add(_Arc);
        _TransactionContainer.BeginTransaction();
        ModelCurve modelCurve = RevitUtility.NewModelCurve(_Document, _Arc);
        _DeleteElementSet.Insert((Element) modelCurve);
        _TransactionContainer.EndTransaction();
      }
      _Document.Regenerate();
    }
    Eps_Point _Point = new Eps_Point();
    if (!RevitUtility.GetPointFromProject(_Document, _strPrompt, ref _Point, _bDisplayError))
    {
      _TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_DeleteElementSet));
      _TransactionContainer.EndTransaction();
      _Document.Regenerate();
      return false;
    }
    bool flag = false;
    if (_PointList.Count == epsArcList.Count)
    {
      for (int index = 0; index < epsArcList.Count; ++index)
      {
        if (EPShared.eplGeoE_IsPointOnArc2D(_Point, epsArcList[index], 0.01))
        {
          flag = true;
          _UsePoint = _PointList[index];
          break;
        }
      }
    }
    if (!flag)
    {
      double _dY = double.MaxValue;
      double _dDistance = 0.0;
      for (int index = 0; index < _PointList.Count; ++index)
      {
        if (_PointList[index].IsEqual(_Point))
        {
          _UsePoint = _Point;
          break;
        }
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_PointList[index], _Point, ref _dDistance);
        if (RevitDefines.LT(_dDistance, _dY))
        {
          _dY = _dDistance;
          _UsePoint = _PointList[index];
        }
      }
    }
    _TransactionContainer.BeginTransaction();
    _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_DeleteElementSet));
    _TransactionContainer.EndTransaction();
    _Document.Regenerate();
    return true;
  }

  private static bool PickDirection(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dLineLength,
    Eps_Point _FirstPoint,
    double _dFirstDirection,
    Eps_Point _SecondPoint,
    double _dSecondDirection,
    ref bool _UseFirstPoint)
  {
    return RevitUtility.PickDirection(_Document, _TransactionContainer, _dLineLength, _FirstPoint, _dFirstDirection, _SecondPoint, _dSecondDirection, ref _UseFirstPoint, (ElementSet) null);
  }

  private static bool PickDirection(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    double _dLineLength,
    Eps_Point _FirstPoint,
    double _dFirstDirection,
    Eps_Point _SecondPoint,
    double _dSecondDirection,
    ref bool _UseFirstPoint,
    ElementSet _DeleteElementSet)
  {
    Eps_Point _NewPnt = new Eps_Point();
    Eps_Line _Line1 = new Eps_Line();
    Eps_Line _Line2 = new Eps_Line();
    Eps_Line _Line3 = new Eps_Line();
    Eps_Line _Line4 = new Eps_Line();
    Eps_Line _Line5 = new Eps_Line();
    Eps_Line _Line6 = new Eps_Line();
    if (_DeleteElementSet == null)
    {
      _DeleteElementSet = new ElementSet();
      _TransactionContainer.BeginTransaction();
      EPShared.eplGeoE_CalcPolarToXY(_FirstPoint, EPShared.eplGeoE_NormalizeRadians(_dFirstDirection + Math.PI / 2.0), _dLineLength / 2.0, ref _NewPnt);
      _Line1.StartPnt = _NewPnt;
      EPShared.eplGeoE_CalcPolarToXY(_FirstPoint, EPShared.eplGeoE_NormalizeRadians(_dFirstDirection - Math.PI / 2.0), _dLineLength / 2.0, ref _NewPnt);
      _Line1.EndPnt = _NewPnt;
      ModelCurve modelCurve1 = RevitUtility.NewModelCurve(_Document, _Line1);
      _DeleteElementSet.Insert((Element) modelCurve1);
      EPShared.eplGeoE_CalcPolarToXY(_FirstPoint, EPShared.eplGeoE_NormalizeRadians(_dFirstDirection), _dLineLength, ref _NewPnt);
      _Line2.StartPnt = _NewPnt;
      _Line2.EndPnt = _Line1.StartPnt;
      ModelCurve modelCurve2 = RevitUtility.NewModelCurve(_Document, _Line2);
      _DeleteElementSet.Insert((Element) modelCurve2);
      _Line3.StartPnt = _NewPnt;
      _Line3.EndPnt = _Line1.EndPnt;
      ModelCurve modelCurve3 = RevitUtility.NewModelCurve(_Document, _Line3);
      _DeleteElementSet.Insert((Element) modelCurve3);
      EPShared.eplGeoE_CalcPolarToXY(_SecondPoint, EPShared.eplGeoE_NormalizeRadians(_dSecondDirection + Math.PI / 2.0), _dLineLength / 2.0, ref _NewPnt);
      _Line4.StartPnt = _NewPnt;
      EPShared.eplGeoE_CalcPolarToXY(_SecondPoint, EPShared.eplGeoE_NormalizeRadians(_dSecondDirection - Math.PI / 2.0), _dLineLength / 2.0, ref _NewPnt);
      _Line4.EndPnt = _NewPnt;
      ModelCurve modelCurve4 = RevitUtility.NewModelCurve(_Document, _Line4);
      _DeleteElementSet.Insert((Element) modelCurve4);
      EPShared.eplGeoE_CalcPolarToXY(_SecondPoint, EPShared.eplGeoE_NormalizeRadians(_dSecondDirection), _dLineLength, ref _NewPnt);
      _Line5.StartPnt = _NewPnt;
      _Line5.EndPnt = _Line4.StartPnt;
      ModelCurve modelCurve5 = RevitUtility.NewModelCurve(_Document, _Line5);
      _DeleteElementSet.Insert((Element) modelCurve5);
      _Line6.StartPnt = _NewPnt;
      _Line6.EndPnt = _Line4.EndPnt;
      ModelCurve modelCurve6 = RevitUtility.NewModelCurve(_Document, _Line6);
      _DeleteElementSet.Insert((Element) modelCurve6);
      _TransactionContainer.EndTransaction();
      _Document.Regenerate();
    }
    Eps_Point _Point = new Eps_Point();
    if (!RevitUtility.GetPointFromProject(_Document, EPShared.LocalRM.GetString("PickStartingDirectionMessage"), ref _Point, true))
    {
      _TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_DeleteElementSet));
      _TransactionContainer.EndTransaction();
      return false;
    }
    double _dDistance1 = 0.0;
    double _dDistance2 = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPoint, _Point, ref _dDistance1);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_SecondPoint, _Point, ref _dDistance2);
    _UseFirstPoint = RevitDefines.LE(_dDistance1, _dDistance2);
    _TransactionContainer.BeginTransaction();
    _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_DeleteElementSet));
    _TransactionContainer.EndTransaction();
    return true;
  }

  public static bool IsPointInPointList(Eps_Point _FindPoint, List<Eps_Point> _PointList)
  {
    for (int index = 0; index < _PointList.Count; ++index)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_FindPoint, _PointList[index]))
        return true;
    }
    return false;
  }

  public static bool IsArcInArcList(Eps_Arc _FindArc, List<Eps_Arc> _ArcList)
  {
    for (int index = 0; index < _ArcList.Count; ++index)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_FindArc.RadiusPnt, _ArcList[index].RadiusPnt))
        return true;
    }
    return false;
  }

  public static KeyValuePair<string, string> CreatePlacementGenericModel(
    Document _Document,
    PlacementSettings _PlacementSettings,
    Element _Element)
  {
    Guid _ChainID = Guid.NewGuid();
    List<KeyValuePair<string, string>> placementGenericModel = RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, new List<Element>()
    {
      _Element
    }, string.Empty, _ChainID);
    return placementGenericModel != null && placementGenericModel.Count > 0 ? placementGenericModel[0] : new KeyValuePair<string, string>(string.Empty, string.Empty);
  }

  public static List<KeyValuePair<string, string>> CreatePlacementGenericModel(
    Document _Document,
    PlacementSettings _PlacementSettings,
    List<Element> _CurveElementList)
  {
    Guid _ChainID = Guid.NewGuid();
    return RevitUtility.CreatePlacementGenericModel(_Document, _PlacementSettings, _CurveElementList, string.Empty, _ChainID);
  }

  public static List<KeyValuePair<string, string>> CreatePlacementGenericModel(
    Document _Document,
    PlacementSettings _PlacementSettings,
    List<Element> _CurveElementList,
    string _strBoundaryID,
    Guid _ChainID)
  {
    List<KeyValuePair<string, string>> placementGenericModel = new List<KeyValuePair<string, string>>();
    _PlacementSettings.TransactionContainer.BeginTransaction();
    if (_CurveElementList != null && _PlacementSettings.PlacementSymbol != null && _PlacementSettings.ExistingElementChecked && !_PlacementSettings.DeleteExistingChecked)
    {
      if (_PlacementSettings.SurfaceList != null && _PlacementSettings.SurfaceList.Count > 0)
      {
        FamilySymbolParameterContainer parameterContainer = new FamilySymbolParameterContainer(RevitParameters.ToposurfaceIDFamilyParameter, (BuiltInParameterGroup) -5000175, (ParameterType) 1, true);
        List<FamilySymbolParameterContainer> FamilySymbolParameterContainerList = new List<FamilySymbolParameterContainer>();
        FamilySymbol placementSymbol = _PlacementSettings.PlacementSymbol;
        FamilySymbolParameterContainerList.Add(parameterContainer);
        RevitUtility.AddParametersToFamilySymbol(_Document, _PlacementSettings.TransactionContainer, FamilySymbolParameterContainerList, ref placementSymbol);
        _PlacementSettings.PlacementSymbol = placementSymbol;
      }
      int num = 0;
      bool flag = false;
      foreach (Element curveElement in _CurveElementList)
      {
        for (int index = 0; index < placementGenericModel.Count; ++index)
        {
          if (string.Compare(placementGenericModel[index].Key, curveElement.UniqueId, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (flag)
        {
          flag = false;
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(_Document, new XYZ(0.0, 0.0, 0.0), _PlacementSettings.PlacementSymbol, curveElement, _PlacementSettings.Level, (StructuralType) 0, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
          if (familyInstance != null)
          {
            ElementSet elm_set = new ElementSet();
            elm_set.Insert((Element) familyInstance);
            _Document.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
            Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.HeightGenericFamilyParameter);
            if (parameter1 != null && !((APIObject) parameter1).IsReadOnly)
              parameter1.Set(_PlacementSettings.Height);
            Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.HeightVarianceGenericFamilyParameter);
            if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
              parameter2.Set(_PlacementSettings.HeightVariance);
            Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.WidthGenericFamilyParameter);
            if (parameter3 != null && !((APIObject) parameter3).IsReadOnly)
              parameter3.Set(_PlacementSettings.Width);
            Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.WidthVarianceGenericFamilyParameter);
            if (parameter4 != null && !((APIObject) parameter4).IsReadOnly)
              parameter4.Set(_PlacementSettings.WidthVariance);
            Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.SpacingGenericFamilyParameter);
            if (parameter5 != null && !((APIObject) parameter5).IsReadOnly)
              parameter5.Set(_PlacementSettings.PlantSpacing);
            Parameter parameter6 = ((Element) familyInstance).LookupParameter(RevitParameters.SetbackGenericFamilyParameter);
            if (parameter6 != null && !((APIObject) parameter6).IsReadOnly)
              parameter6.Set(_PlacementSettings.SetbackSpacing);
            Parameter parameter7 = ((Element) familyInstance).LookupParameter(RevitParameters.GroveRotationGenericFamilyParameter);
            if (parameter7 != null && !((APIObject) parameter7).IsReadOnly)
              parameter7.Set(_PlacementSettings.RotationAngle);
            Parameter parameter8 = ((Element) familyInstance).LookupParameter(RevitParameters.IsSingleSegmentGenericFamilyParameter);
            if (parameter8 != null && !((APIObject) parameter8).IsReadOnly)
            {
              if (_CurveElementList.Count > 1)
                parameter8.Set(Convert.ToInt32(true));
              else
                parameter8.Set(Convert.ToInt32(false));
            }
            Parameter parameter9 = ((Element) familyInstance).LookupParameter(RevitParameters.IsFirstPlacementSegmentGenericFamilyParameter);
            if (parameter9 != null && !((APIObject) parameter9).IsReadOnly)
            {
              if (num == 0)
              {
                parameter9.Set(Convert.ToInt32(true));
                if (_PlacementSettings.FirstLegSegmentID == string.Empty)
                  _PlacementSettings.FirstLegSegmentID = curveElement.UniqueId;
              }
              else
              {
                if (num == _CurveElementList.Count<Element>() - 1 && _PlacementSettings.LastLegSegmentID == string.Empty)
                  _PlacementSettings.LastLegSegmentID = curveElement.UniqueId;
                parameter9.Set(Convert.ToInt32(false));
              }
            }
            ++num;
            Parameter parameter10 = ((Element) familyInstance).LookupParameter(RevitParameters.IsFirstLegSegmentGenericFamilyParameter);
            if (parameter10 != null && !((APIObject) parameter10).IsReadOnly)
            {
              if (string.Compare(curveElement.UniqueId, _PlacementSettings.FirstLegSegmentID, true) == 0)
                parameter10.Set(Convert.ToInt32(true));
              else
                parameter10.Set(Convert.ToInt32(false));
            }
            Parameter parameter11 = ((Element) familyInstance).LookupParameter(RevitParameters.IsLastLegSegmentGenericFamilyParameter);
            if (parameter11 != null && !((APIObject) parameter11).IsReadOnly)
            {
              if (string.Compare(curveElement.UniqueId, _PlacementSettings.LastLegSegmentID, true) == 0)
                parameter11.Set(Convert.ToInt32(true));
              else
                parameter11.Set(Convert.ToInt32(false));
            }
            Parameter parameter12 = ((Element) familyInstance).LookupParameter(RevitParameters.IsReverseGenericFamilyParameter);
            if (parameter12 != null && !((APIObject) parameter12).IsReadOnly)
              parameter12.Set(Convert.ToInt32(_PlacementSettings.IsReverse));
            Parameter parameter13 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementTypeGenericFamilyParameter);
            if (parameter13 != null && !((APIObject) parameter13).IsReadOnly)
              parameter13.Set(_PlacementSettings.PlacementType.GetHashCode());
            Parameter parameter14 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
            if (parameter14 != null && !((APIObject) parameter14).IsReadOnly)
              parameter14.Set(curveElement.UniqueId);
            if (_PlacementSettings.Type != null)
            {
              Parameter parameter15 = ((Element) familyInstance).LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
              if (parameter15 != null && !((APIObject) parameter15).IsReadOnly)
                parameter15.Set(((Element) _PlacementSettings.Type).UniqueId);
            }
            Parameter parameter16 = ((Element) familyInstance).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
            if (parameter16 != null && !((APIObject) parameter16).IsReadOnly)
              parameter16.Set(Convert.ToInt32(_PlacementSettings.UseRightSide));
            if (_strBoundaryID != string.Empty)
            {
              Parameter parameter17 = ((Element) familyInstance).LookupParameter(RevitParameters.BoundaryIslandIDGenericFamilyParameter);
              if (parameter17 != null && !((APIObject) parameter17).IsReadOnly)
                parameter17.Set(_strBoundaryID);
            }
            if (_ChainID != Guid.Empty)
            {
              Parameter parameter18 = ((Element) familyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
              if (parameter18 != null && !((APIObject) parameter18).IsReadOnly)
                parameter18.Set(_ChainID.ToString());
            }
            Parameter parameter19 = ((Element) familyInstance).LookupParameter(RevitParameters.AlignToGenericFamilyParameter);
            if (parameter19 != null && !((APIObject) parameter19).IsReadOnly)
              parameter19.Set(Convert.ToInt32(_PlacementSettings.AlignTo));
            Parameter parameter20 = ((Element) familyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
            if (parameter20 != null && !((APIObject) parameter20).IsReadOnly)
              parameter20.Set(_PlacementSettings.LocateType.GetHashCode());
            Parameter parameter21 = ((Element) familyInstance).LookupParameter(RevitParameters.StartingDistanceGenericFamilyParameter);
            if (parameter21 != null && !((APIObject) parameter21).IsReadOnly)
              parameter21.Set(_PlacementSettings.StartingDistance);
            if (_PlacementSettings.SurfaceList != null && _PlacementSettings.SurfaceList.Count > 0)
            {
              Parameter parameter22 = ((Element) familyInstance).LookupParameter(RevitParameters.ToposurfaceIDFamilyParameter);
              if (parameter22 != null && !((APIObject) parameter22).IsReadOnly)
                parameter22.Set(((Element) _PlacementSettings.SurfaceList[0].TopographySurface).UniqueId);
            }
            if (_PlacementSettings.Parking != null)
            {
              Parameter parameter23 = ((Element) familyInstance).LookupParameter(RevitParameters.ADAStallWidthGenericModelFamilyParameter);
              if (parameter23 != null && !((APIObject) parameter23).IsReadOnly)
                parameter23.Set(_PlacementSettings.Parking.ADAStallWidth);
              Parameter parameter24 = ((Element) familyInstance).LookupParameter(RevitParameters.ADAStallCountGenericModelFamilyParameter);
              if (parameter24 != null && !((APIObject) parameter24).IsReadOnly)
                parameter24.Set(_PlacementSettings.Parking.ADAStallCount);
              Parameter parameter25 = ((Element) familyInstance).LookupParameter(RevitParameters.BumperHeightGenericModelFamilyParameter);
              if (parameter25 != null && !((APIObject) parameter25).IsReadOnly)
                parameter25.Set(_PlacementSettings.Parking.BumperHeight);
              Parameter parameter26 = ((Element) familyInstance).LookupParameter(RevitParameters.BumperWidthGenericModelFamilyParameter);
              if (parameter26 != null && !((APIObject) parameter26).IsReadOnly)
                parameter26.Set(_PlacementSettings.Parking.BumperWidth);
              Parameter parameter27 = ((Element) familyInstance).LookupParameter(RevitParameters.BumperOffsetGenericModelFamilyParameter);
              if (parameter27 != null && !((APIObject) parameter27).IsReadOnly)
                parameter27.Set(_PlacementSettings.Parking.BumperOffset);
              Parameter parameter28 = ((Element) familyInstance).LookupParameter(RevitParameters.BumperSetbackGenericModelFamilyParameter);
              if (parameter28 != null && !((APIObject) parameter28).IsReadOnly)
                parameter28.Set(_PlacementSettings.Parking.BumperSetback);
              Parameter parameter29 = ((Element) familyInstance).LookupParameter(RevitParameters.IslandHeightGenericModelFamilyParameter);
              if (parameter29 != null && !((APIObject) parameter29).IsReadOnly)
                parameter29.Set(_PlacementSettings.Parking.IslandHeight);
              Parameter parameter30 = ((Element) familyInstance).LookupParameter(RevitParameters.IslandWidthGenericModelFamilyParameter);
              if (parameter30 != null && !((APIObject) parameter30).IsReadOnly)
                parameter30.Set(_PlacementSettings.Parking.IslandWidth);
              Parameter parameter31 = ((Element) familyInstance).LookupParameter(RevitParameters.StallLengthGenericModelFamilyParameter);
              if (parameter31 != null && !((APIObject) parameter31).IsReadOnly)
                parameter31.Set(_PlacementSettings.Parking.StallLength);
              Parameter parameter32 = ((Element) familyInstance).LookupParameter(RevitParameters.AreaDistanceBetweenCenterlinesGenericModelFamilyParameter);
              if (parameter32 != null && !((APIObject) parameter32).IsReadOnly)
                parameter32.Set(_PlacementSettings.Parking.AreaDistanceBetweenCenterlines);
              Parameter parameter33 = ((Element) familyInstance).LookupParameter(RevitParameters.AreaAisleWidthGenericModelFamilyParameter);
              if (parameter33 != null && !((APIObject) parameter33).IsReadOnly)
                parameter33.Set(_PlacementSettings.Parking.AreaAisleWidth);
              Parameter parameter34 = ((Element) familyInstance).LookupParameter(RevitParameters.PlaceIslandGenericModelFamilyParameter);
              if (parameter34 != null && !((APIObject) parameter34).IsReadOnly)
                parameter34.Set(Convert.ToInt32(_PlacementSettings.Parking.PlaceIsland));
              Parameter parameter35 = ((Element) familyInstance).LookupParameter(RevitParameters.PlaceBumperGenericModelFamilyParameter);
              if (parameter35 != null && !((APIObject) parameter35).IsReadOnly)
                parameter35.Set(Convert.ToInt32(_PlacementSettings.Parking.PlaceBumper));
              Parameter parameter36 = ((Element) familyInstance).LookupParameter(RevitParameters.OptimizeParkingGenericModelFamilyParameter);
              if (parameter36 != null && !((APIObject) parameter36).IsReadOnly)
                parameter36.Set(Convert.ToInt32(_PlacementSettings.Parking.OptimizeParking));
              Parameter parameter37 = ((Element) familyInstance).LookupParameter(RevitParameters.AreaBidirectionalAislesGenericModelFamilyParameter);
              if (parameter37 != null && !((APIObject) parameter37).IsReadOnly)
                parameter37.Set(Convert.ToInt32(_PlacementSettings.Parking.AreaBiDirectionalAisles));
              Parameter parameter38 = ((Element) familyInstance).LookupParameter(RevitParameters.StallCountGenericModelFamilyParameter);
              if (parameter38 != null && !((APIObject) parameter38).IsReadOnly)
                parameter38.Set(_PlacementSettings.Parking.StallCount);
              Parameter parameter39 = ((Element) familyInstance).LookupParameter(RevitParameters.AreaRowCountGenericModelFamilyParameter);
              if (parameter39 != null && !((APIObject) parameter39).IsReadOnly)
                parameter39.Set(_PlacementSettings.Parking.AreaRowCount);
              Parameter parameter40 = ((Element) familyInstance).LookupParameter(RevitParameters.AreaRowSpacingOptionsGenericModelFamilyParameter);
              if (parameter40 != null && !((APIObject) parameter40).IsReadOnly)
                parameter40.Set(_PlacementSettings.Parking.AreaRowSpacingOptions);
              if (_PlacementSettings.Parking.ADAStallSymbol != null)
              {
                Parameter parameter41 = ((Element) familyInstance).LookupParameter(RevitParameters.ADAStallSymbolIDGenericFamilyParameter);
                if (parameter41 != null && !((APIObject) parameter41).IsReadOnly)
                  parameter41.Set(((Element) _PlacementSettings.Parking.ADAStallSymbol).UniqueId);
              }
              if (_PlacementSettings.Parking.IslandSymbol != null)
              {
                Parameter parameter42 = ((Element) familyInstance).LookupParameter(RevitParameters.IslandSymbolIDGenericFamilyParameter);
                if (parameter42 != null && !((APIObject) parameter42).IsReadOnly)
                  parameter42.Set(((Element) _PlacementSettings.Parking.IslandSymbol).UniqueId);
              }
              if (_PlacementSettings.Parking.BumperSymbol != null)
              {
                Parameter parameter43 = ((Element) familyInstance).LookupParameter(RevitParameters.BumperSymbolIDGenericFamilyParameter);
                if (parameter43 != null && !((APIObject) parameter43).IsReadOnly)
                  parameter43.Set(((Element) _PlacementSettings.Parking.BumperSymbol).UniqueId);
              }
              Parameter parameter44 = ((Element) familyInstance).LookupParameter(RevitParameters.MiddleStallPlacementGenericFamilyParameter);
              if (parameter44 != null && !((APIObject) parameter44).IsReadOnly)
                parameter44.Set(Convert.ToInt32(_PlacementSettings.Parking.MiddleStallPlacement));
              Parameter parameter45 = ((Element) familyInstance).LookupParameter(RevitParameters.ADAStallSharedAccessibleAisleGenericModelFamilyParameter);
              if (parameter45 != null && !((APIObject) parameter45).IsReadOnly)
                parameter45.Set(Convert.ToInt32(_PlacementSettings.Parking.ADAStallSharedAccessibleAisle));
            }
            placementGenericModel.Add(new KeyValuePair<string, string>(curveElement.UniqueId, ((Element) familyInstance).UniqueId));
          }
        }
      }
    }
    _PlacementSettings.TransactionContainer.EndTransaction();
    return placementGenericModel;
  }

  public static FamilyInstance CreatePlacementSiteComponent(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    Element _Element)
  {
    Guid _ChainID = Guid.NewGuid();
    List<FamilyInstance> placementSiteComponent = RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, new List<Element>()
    {
      _Element
    }, _ChainID, false);
    return placementSiteComponent != null && placementSiteComponent.Count > 0 ? placementSiteComponent[0] : (FamilyInstance) null;
  }

  public static List<FamilyInstance> CreatePlacementSiteComponent(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    List<Element> _CurveElementList)
  {
    Guid _ChainID = Guid.NewGuid();
    return RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, _CurveElementList, _ChainID, false);
  }

  public static List<FamilyInstance> CreatePlacementSiteComponent(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    List<Element> _CurveElementList,
    Guid _ChainID)
  {
    return RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, _CurveElementList, new List<double>()
    {
      _PlacementSettings.LinearPointInterval
    }, _ChainID, false);
  }

  public static List<FamilyInstance> CreatePlacementSiteComponent(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    List<Element> _CurveElementList,
    Guid _ChainID,
    bool _bIsParkingLotBreakline)
  {
    return RevitUtility.CreatePlacementSiteComponent(_Document, _PlacementSettings, _CurveElementList, new List<double>()
    {
      _PlacementSettings.LinearPointInterval
    }, _ChainID, _bIsParkingLotBreakline);
  }

  public static List<FamilyInstance> CreatePlacementSiteComponent(
    Document _Document,
    SitePlacementSettings _PlacementSettings,
    List<Element> _CurveElementList,
    List<double> _LinearPointIntervals,
    Guid _ChainID,
    bool _bIsParkingLotBreakline)
  {
    List<FamilyInstance> placementSiteComponent = new List<FamilyInstance>();
    _PlacementSettings.TransactionContainer.BeginTransaction();
    ElementSet _ElementSet = new ElementSet();
    if (_CurveElementList != null && _PlacementSettings.PlacementSymbol != null)
    {
      int index = 0;
      foreach (Element curveElement in _CurveElementList)
      {
        EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
        FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(_Document, new XYZ(0.0, 0.0, 0.0), _PlacementSettings.PlacementSymbol, curveElement, _PlacementSettings.Level, (StructuralType) 0, ref transactionContainer);
        _PlacementSettings.TransactionContainer = transactionContainer;
        _ElementSet.Insert((Element) familyInstance);
        Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
        if (parameter1 != null && !((APIObject) parameter1).IsReadOnly)
          parameter1.Set(_PlacementSettings.LocateType.GetHashCode().ToString("000"));
        Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.IsSingleSegmentGenericFamilyParameter);
        if (parameter2 != null && !((APIObject) parameter2).IsReadOnly)
        {
          if (_CurveElementList.Count > 1)
            parameter2.Set(Convert.ToInt32(true));
          else
            parameter2.Set(Convert.ToInt32(false));
        }
        Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.IsFirstPlacementSegmentGenericFamilyParameter);
        if (parameter3 != null && !((APIObject) parameter3).IsReadOnly)
        {
          if (index == 0)
            parameter3.Set(Convert.ToInt32(true));
          else
            parameter3.Set(Convert.ToInt32(false));
        }
        Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.IsReverseGenericFamilyParameter);
        if (parameter4 != null && !((APIObject) parameter4).IsReadOnly)
          parameter4.Set(Convert.ToInt32(_PlacementSettings.IsReverse));
        Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
        if (parameter5 != null && !((APIObject) parameter5).IsReadOnly)
          parameter5.Set(curveElement.UniqueId);
        if (_PlacementSettings.Type != null)
        {
          Parameter parameter6 = ((Element) familyInstance).LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
          if (parameter6 != null && !((APIObject) parameter6).IsReadOnly)
            parameter6.Set(((Element) _PlacementSettings.Type).UniqueId);
          Parameter parameter7 = ((Element) familyInstance).LookupParameter(RevitParameters.FamilySymbolNameFamilyParameter);
          if (parameter7 != null && !((APIObject) parameter7).IsReadOnly)
            parameter7.Set(((Element) _PlacementSettings.Type).Name);
          Parameter parameter8 = ((Element) familyInstance).LookupParameter(RevitParameters.FamilyNameFamilyParameter);
          if (parameter8 != null && !((APIObject) parameter8).IsReadOnly)
            parameter8.Set(((Element) _PlacementSettings.Type.Family).Name);
        }
        if (_PlacementSettings.LoftFormID != string.Empty)
        {
          Parameter parameter9 = ((Element) familyInstance).LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
          if (parameter9 != null && !((APIObject) parameter9).IsReadOnly)
            parameter9.Set(_PlacementSettings.LoftFormID);
        }
        if (_PlacementSettings.AdditionalLoftFormID != string.Empty)
        {
          Parameter parameter10 = ((Element) familyInstance).LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
          if (parameter10 != null && !((APIObject) parameter10).IsReadOnly)
            parameter10.Set(_PlacementSettings.AdditionalLoftFormID);
        }
        if (_PlacementSettings.IslandSurfaceID != string.Empty)
        {
          Parameter parameter11 = ((Element) familyInstance).LookupParameter(RevitParameters.IslandSurfaceIdFamilyParameter);
          if (parameter11 != null && !((APIObject) parameter11).IsReadOnly)
            parameter11.Set(_PlacementSettings.IslandSurfaceID);
        }
        if (_PlacementSettings.ParkingLotSurfaceID != string.Empty)
        {
          Parameter parameter12 = ((Element) familyInstance).LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
          if (parameter12 != null && !((APIObject) parameter12).IsReadOnly)
            parameter12.Set(_PlacementSettings.ParkingLotSurfaceID);
        }
        if (_PlacementSettings.ParentTopoSurfaceID != string.Empty)
        {
          Parameter parameter13 = ((Element) familyInstance).LookupParameter(RevitParameters.ParentSurfaceIDFamilyParameter);
          if (parameter13 != null && !((APIObject) parameter13).IsReadOnly)
            parameter13.Set(_PlacementSettings.ParentTopoSurfaceID);
        }
        Parameter parameter14 = ((Element) familyInstance).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
        if (parameter14 != null && !((APIObject) parameter14).IsReadOnly)
          parameter14.Set(Convert.ToInt32(_PlacementSettings.UseRightSide));
        if (_ChainID != Guid.Empty)
        {
          Parameter parameter15 = ((Element) familyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
          if (parameter15 != null && !((APIObject) parameter15).IsReadOnly)
            parameter15.Set(_ChainID.ToString());
        }
        Parameter parameter16 = ((Element) familyInstance).LookupParameter(RevitParameters.ProjectInnerSlopesFamilyParameter);
        if (parameter16 != null && !((APIObject) parameter16).IsReadOnly)
          parameter16.Set(_PlacementSettings.ProjectInnerSlopes);
        Parameter parameter17 = ((Element) familyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
        if (parameter17 != null && !((APIObject) parameter17).IsReadOnly)
          parameter17.Set(_PlacementSettings.Name);
        Parameter parameter18 = ((Element) familyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
        if (parameter18 != null && !((APIObject) parameter18).IsReadOnly)
          parameter18.Set(_PlacementSettings.TopoDrawOrder);
        Parameter parameter19 = ((Element) familyInstance).LookupParameter(RevitParameters.ElevationFamilyParameter);
        if (parameter19 != null && !((APIObject) parameter19).IsReadOnly)
          parameter19.Set(_PlacementSettings.Elevation);
        if (index < _PlacementSettings.BeginningElevationList.Count)
        {
          Parameter parameter20 = ((Element) familyInstance).LookupParameter(RevitParameters.BeginningElevationFamilyParameter);
          if (parameter20 != null && !((APIObject) parameter20).IsReadOnly)
            parameter20.Set(_PlacementSettings.BeginningElevationList[index]);
        }
        if (index < _PlacementSettings.EndingElevationList.Count)
        {
          Parameter parameter21 = ((Element) familyInstance).LookupParameter(RevitParameters.EndingElevationFamilyParameter);
          if (parameter21 != null && !((APIObject) parameter21).IsReadOnly)
            parameter21.Set(_PlacementSettings.EndingElevationList[index]);
        }
        Parameter parameter22 = ((Element) familyInstance).LookupParameter(RevitParameters.UsePlacementElevationsFamilyParameter);
        if (parameter22 != null && !((APIObject) parameter22).IsReadOnly)
        {
          if (index < _PlacementSettings.BeginningElevationList.Count && index < _PlacementSettings.EndingElevationList.Count)
            parameter22.Set(Convert.ToInt32(true));
          else
            parameter22.Set(Convert.ToInt32(false));
        }
        Parameter parameter23 = ((Element) familyInstance).LookupParameter(RevitParameters.SiteComponentIsRelativeElevationParameter);
        if (parameter23 != null && !((APIObject) parameter23).IsReadOnly)
          parameter23.Set(Convert.ToInt32(_PlacementSettings.IsRelativeElevation));
        Parameter parameter24 = ((Element) familyInstance).LookupParameter(RevitParameters.IsBreaklineFamilyParameter);
        if (parameter24 != null && !((APIObject) parameter24).IsReadOnly)
          parameter24.Set(Convert.ToInt32(_bIsParkingLotBreakline));
        Parameter parameter25 = ((Element) familyInstance).LookupParameter(RevitParameters.LinearPointIntervalParameter);
        if (parameter25 != null && !((APIObject) parameter25).IsReadOnly)
        {
          if (index < _LinearPointIntervals.Count)
            parameter25.Set(_LinearPointIntervals[index]);
          else
            parameter25.Set(_LinearPointIntervals[0]);
        }
        placementSiteComponent.Add(familyInstance);
        ++index;
      }
    }
    if (_PlacementSettings.IntersectionStations != null && _PlacementSettings.IntersectionStations.Count > 0 && _PlacementSettings.IntersectionPlacementSymbol != null)
    {
      for (int index1 = 0; index1 < _PlacementSettings.IntersectionStations.Count; ++index1)
      {
        for (int index2 = 0; index2 < _PlacementSettings.IntersectionStations[index1].IntersectionStations.Count; ++index2)
        {
          EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
          FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(_Document, new XYZ(0.0, 0.0, 0.0), _PlacementSettings.IntersectionPlacementSymbol, (Element) null, _PlacementSettings.Level, (StructuralType) 0, ref transactionContainer);
          _PlacementSettings.TransactionContainer = transactionContainer;
          _ElementSet.Insert((Element) familyInstance);
          Parameter parameter26 = ((Element) familyInstance).LookupParameter(RevitParameters.PrimaryPlacementIDParameter);
          if (parameter26 != null && !((APIObject) parameter26).IsReadOnly)
            parameter26.Set(_PlacementSettings.IntersectionStations[index1].PrimaryPlacementId);
          if (placementSiteComponent.Count > 0)
          {
            Parameter parameter27 = ((Element) familyInstance).LookupParameter(RevitParameters.SecondaryPlacementIDParameter);
            if (parameter27 != null && !((APIObject) parameter27).IsReadOnly)
              parameter27.Set(((Element) placementSiteComponent[0]).UniqueId);
          }
          Parameter parameter28 = ((Element) familyInstance).LookupParameter(RevitParameters.IsStartingParameter);
          if (parameter28 != null && !((APIObject) parameter28).IsReadOnly)
            parameter28.Set(Convert.ToInt32(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].StartingIntersection));
          Parameter parameter29 = ((Element) familyInstance).LookupParameter(RevitParameters.RadiusParameter);
          if (parameter29 != null && !((APIObject) parameter29).IsReadOnly)
            parameter29.Set(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].Radius);
          Parameter parameter30 = ((Element) familyInstance).LookupParameter(RevitParameters.SecondaryStationParameter);
          if (parameter30 != null && !((APIObject) parameter30).IsReadOnly)
            parameter30.Set(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].Station);
          Parameter parameter31 = ((Element) familyInstance).LookupParameter(RevitParameters.PrimaryStationParameter);
          if (parameter31 != null && !((APIObject) parameter31).IsReadOnly)
            parameter31.Set(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].PrimaryStation);
          Parameter parameter32 = ((Element) familyInstance).LookupParameter(RevitParameters.IsSecondaryLeftParameter);
          if (parameter32 != null && !((APIObject) parameter32).IsReadOnly)
            parameter32.Set(Convert.ToInt32(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].IsLeft));
          Parameter parameter33 = ((Element) familyInstance).LookupParameter(RevitParameters.IsPrimaryLeftParameter);
          if (parameter33 != null && !((APIObject) parameter33).IsReadOnly)
            parameter33.Set(Convert.ToInt32(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].IsPrimaryLeft));
          Parameter parameter34 = ((Element) familyInstance).LookupParameter(RevitParameters.TransitioningDistanceParameter);
          if (parameter34 != null && !((APIObject) parameter34).IsReadOnly)
            parameter34.Set(_PlacementSettings.IntersectionStations[index1].IntersectionStations[index2].TransitioningDistance);
        }
      }
    }
    if (_ElementSet.Size > 0)
      RevitUtility.HideElementsInAllViews(_Document, _ElementSet);
    _PlacementSettings.TransactionContainer.EndTransaction();
    return placementSiteComponent;
  }

  public static List<FamilyInstanceComponentWrapper> FindAllSiteComponents(Document _Document)
  {
    EPTransactionContainer _TransactionContainer = new EPTransactionContainer(_Document);
    int nMaxExistingTopoDrawOrder = -1;
    return RevitUtility.FindSiteCategoryComponents(_Document, _TransactionContainer, string.Empty, ref nMaxExistingTopoDrawOrder);
  }

  public static List<FamilyInstanceComponentWrapper> FindAllSiteComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer)
  {
    int nMaxExistingTopoDrawOrder = -1;
    return RevitUtility.FindSiteCategoryComponents(_Document, _TransactionContainer, string.Empty, ref nMaxExistingTopoDrawOrder);
  }

  public static List<FamilyInstanceComponentWrapper> FindAllSiteComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    ref int _nMaxExistingTopoDrawOrder)
  {
    return RevitUtility.FindSiteCategoryComponents(_Document, _TransactionContainer, string.Empty, ref _nMaxExistingTopoDrawOrder);
  }

  public static List<FamilyInstanceComponentWrapper> FindSiteCategoryComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    string _strLandcaddID)
  {
    int nMaxExistingTopoDrawOrder = -1;
    return RevitUtility.FindSiteCategoryComponents(_Document, _TransactionContainer, _strLandcaddID, ref nMaxExistingTopoDrawOrder);
  }

  private static List<FamilyInstanceComponentWrapper> FindSiteCategoryComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    string _strLandcaddID,
    ref int nMaxExistingTopoDrawOrder)
  {
    List<FamilyInstanceComponentWrapper> categoryComponents = new List<FamilyInstanceComponentWrapper>();
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    Parameter LocateTypeParameter = (Parameter) null;
    List<KeyValuePair<string, Category>> MassLineSubCategoryList = (List<KeyValuePair<string, Category>>) null;
    bool flag1 = false;
    nMaxExistingTopoDrawOrder = -1;
    FilteredElementCollector source1 = new FilteredElementCollector(_Document);
    source1.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source1).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && (LocateTypeParameter = ((Element) FindFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter)) != null && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>();
    if (list.Count == 0)
      return categoryComponents;
    FilteredElementCollector source2 = new FilteredElementCollector(_Document);
    source2.WhereElementIsViewIndependent();
    source2.OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051);
    bool flag2 = _TransactionContainer.Start(EPShared.LocalRM.GetString("CreateLineSubCategoriesTransaction"));
    if (_strLandcaddID == string.Empty)
    {
      MassLineSubCategoryList = RevitUtility.GetAllMassLineSubCategories(_Document, ref flag1);
    }
    else
    {
      LandcaddID _CurLandcaddId = LandcaddID.SoftTerrain;
      foreach (int num in Enum.GetValues(typeof (LandcaddID)))
      {
        if (string.Compare(_strLandcaddID, num.ToString("000"), true) == 0)
        {
          _CurLandcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
          break;
        }
      }
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, _CurLandcaddId, ref flag1);
      if (!flag1)
        MassLineSubCategoryList = RevitUtility.GetAllMassLineSubCategories(_Document, ref flag1);
      else if (componentLineSubCategory != null)
      {
        MassLineSubCategoryList = new List<KeyValuePair<string, Category>>();
        MassLineSubCategoryList.Add(new KeyValuePair<string, Category>(_strLandcaddID, componentLineSubCategory));
      }
    }
    List<Element> elementList = (List<Element>) null;
    if (flag1 && MassLineSubCategoryList != null && MassLineSubCategoryList.Count > 0)
    {
      for (int nIndex = 0; nIndex < MassLineSubCategoryList.Count; nIndex++)
      {
        if (MassLineSubCategoryList[nIndex].Value != null)
        {
          Parameter LineStyleParameter = (Parameter) null;
          FindCurveElement = (CurveElement) null;
          IEnumerable<Element> source3 = ((IEnumerable<Element>) source2).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is CurveElement FindCurveElement && (LineStyleParameter = ((Element) FindCurveElement)[(BuiltInParameter) -1006210]) != null && ElementId.op_Equality(LineStyleParameter.AsElementId(), ((Element) MassLineSubCategoryList[nIndex].Value.GetGraphicsStyle((GraphicsStyleType) 1)).Id)));
          if (nIndex == 0)
            elementList = source3.ToList<Element>();
          else
            elementList.AddRange((IEnumerable<Element>) source3.ToList<Element>());
        }
      }
    }
    else
      elementList = ((IEnumerable<Element>) source2).ToList<Element>();
    bool flag3 = false;
    foreach (Element element in list)
    {
      if (element is FamilyInstance _FamilyInstance && ((Element) _FamilyInstance).Category != null && ((Element) _FamilyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
      {
        SiteworksIDParameter = ((Element) _FamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (SiteworksIDParameter != null)
        {
          LocateTypeParameter = ((Element) _FamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
          if (LocateTypeParameter != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0)
          {
            Parameter parameter1 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
            if (parameter1 != null)
            {
              Parameter parameter2 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.ChainIDGenericFamilyParameter);
              if (parameter2 != null && parameter2.AsString() != string.Empty)
              {
                for (int index1 = 0; index1 < elementList.Count; ++index1)
                {
                  Element _Element = elementList[index1];
                  if (_Element != null && _Element.Category != null && _Element.Category.Id.IntegerValue == ((BuiltInCategory) -2000051).GetHashCode() && string.Compare(parameter1.AsString(), _Element.UniqueId, true) == 0)
                  {
                    if (MassLineSubCategoryList != null && !flag1)
                    {
                      for (int index2 = 0; index2 < MassLineSubCategoryList.Count; ++index2)
                      {
                        KeyValuePair<string, Category> keyValuePair = MassLineSubCategoryList[index2];
                        if (string.Compare(keyValuePair.Key, LocateTypeParameter.AsString(), true) == 0)
                        {
                          keyValuePair = MassLineSubCategoryList[index2];
                          if (keyValuePair.Value != null && _Element is ModelCurve modelCurve)
                          {
                            keyValuePair = MassLineSubCategoryList[index2];
                            GraphicsStyle graphicsStyle = keyValuePair.Value.GetGraphicsStyle((GraphicsStyleType) 1);
                            ((CurveElement) modelCurve).LineStyle = (Element) graphicsStyle;
                            break;
                          }
                          break;
                        }
                      }
                    }
                    for (int index3 = 0; index3 < categoryComponents.Count; ++index3)
                    {
                      if (string.Compare(parameter2.AsString(), categoryComponents[index3].ChainID, true) == 0)
                      {
                        flag3 = true;
                        if (_strLandcaddID == string.Empty || string.Compare(LocateTypeParameter.AsString(), _strLandcaddID, true) == 0)
                        {
                          FamilyInstanceComponentContainer componentContainer = new FamilyInstanceComponentContainer(_Element, _FamilyInstance);
                          categoryComponents[index3].FamilyContainerList.Add(componentContainer);
                          break;
                        }
                        break;
                      }
                    }
                    if (!flag3)
                    {
                      int _nDrawOrder = 0;
                      Parameter parameter3 = ((Element) _FamilyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
                      if (parameter3 != null)
                      {
                        _nDrawOrder = parameter3.AsInteger();
                        if (nMaxExistingTopoDrawOrder < _nDrawOrder)
                          nMaxExistingTopoDrawOrder = parameter3.AsInteger();
                      }
                      if (_strLandcaddID == string.Empty || string.Compare(LocateTypeParameter.AsString(), _strLandcaddID, true) == 0)
                        categoryComponents.Add(new FamilyInstanceComponentWrapper(parameter2.AsString(), new List<FamilyInstanceComponentContainer>()
                        {
                          new FamilyInstanceComponentContainer(_Element, _FamilyInstance)
                        }, _nDrawOrder));
                    }
                    else
                      flag3 = false;
                    elementList.RemoveAt(index1);
                    break;
                  }
                }
                if (elementList.Count == 0)
                  break;
              }
            }
          }
        }
      }
    }
    if (flag2)
    {
      if (!flag1)
        _TransactionContainer.Commit();
      else
        _TransactionContainer.Rollback();
    }
    return categoryComponents;
  }

  public static int FindMaxTopoDrawOrderFromSiteComponents(Document _Document)
  {
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    Parameter LocateTypeParameter = (Parameter) null;
    int fromSiteComponents = -1;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    foreach (Element element in ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.SiteComponentPlacement).ToString("000"), true) == 0 && (LocateTypeParameter = ((Element) FindFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter)) != null && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>())
    {
      if (element is FamilyInstance familyInstance && ((Element) familyInstance).Category != null && ((Element) familyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.TopoDrawOrderFamilyParameter);
        if (parameter != null)
        {
          int num = parameter.AsInteger();
          if (fromSiteComponents < num)
            fromSiteComponents = parameter.AsInteger();
        }
      }
    }
    return fromSiteComponents;
  }

  public static bool RemoveAllSiteComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer)
  {
    return RevitUtility.RemoveAllSiteComponents(_Document, _TransactionContainer, false);
  }

  public static bool RemoveAllSiteComponents(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    bool _bIssueWarningForRemoval)
  {
    bool flag = false;
    List<FamilyInstanceComponentWrapper> allSiteComponents = RevitUtility.FindAllSiteComponents(_Document, _TransactionContainer);
    ElementSet elm_set = new ElementSet();
    if (allSiteComponents.Count > 0)
    {
      if (_bIssueWarningForRemoval && RevitMessageBox.Show(EPShared.LocalRM.GetString("SiteComponentsFoundInProjectMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
        return false;
      for (int index = 0; index < allSiteComponents.Count; ++index)
      {
        foreach (Element familyInstanceElement in allSiteComponents[index].GetFamilyInstanceElementSet())
          elm_set.Insert(familyInstanceElement);
        foreach (Element originalElement in allSiteComponents[index].GetOriginalElementSet())
          elm_set.Insert(originalElement);
      }
    }
    if (elm_set.Size > 0)
    {
      flag = true;
      _TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      _TransactionContainer.EndTransaction();
    }
    return flag;
  }

  public static void AddParameterToFamilySymbol(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilySymbolParameterContainer FamilySymbolParameterContainer,
    ref FamilySymbol _FamilySymbol)
  {
    RevitUtility.AddParametersToFamilySymbol(_Document, _TransactionContainer, new List<FamilySymbolParameterContainer>()
    {
      FamilySymbolParameterContainer
    }, ref _FamilySymbol);
  }

  public static void AddParametersToFamilySymbol(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    List<FamilySymbolParameterContainer> FamilySymbolParameterContainerList,
    ref FamilySymbol _FamilySymbol)
  {
    bool flag1 = _TransactionContainer.HasStarted();
    string name1 = _TransactionContainer.GetName();
    if (flag1)
      _TransactionContainer.Rollback();
    if (_FamilySymbol != null && _FamilySymbol.Family != null)
    {
      Document _Document1 = _Document.EditFamily(_FamilySymbol.Family);
      if (_Document1 != null)
      {
        EPTransactionContainer transactionContainer = new EPTransactionContainer(_Document1);
        transactionContainer.Start(EPShared.LocalRM.GetString("AddParametersToFamilyTransaction"));
        transactionContainer.BeginTransaction();
        bool flag2 = false;
        for (int index = 0; index < FamilySymbolParameterContainerList.Count; ++index)
        {
          if (FamilySymbolParameterContainerList[index].FamilyDefinition != null)
          {
            if (_Document1.FamilyManager[(Definition) FamilySymbolParameterContainerList[index].FamilyDefinition] == null)
            {
              _Document1.FamilyManager.AddParameter(FamilySymbolParameterContainerList[index].FamilyDefinition, FamilySymbolParameterContainerList[index].BuiltInParameterGroup, FamilySymbolParameterContainerList[index].IsInstance);
              flag2 = true;
            }
          }
          else if (FamilySymbolParameterContainerList[index].FamilyCategory != null)
          {
            if (FamilySymbolParameterContainerList[index].ParameterName != string.Empty && _Document1.FamilyManager[FamilySymbolParameterContainerList[index].ParameterName] == null)
            {
              _Document1.FamilyManager.AddParameter(FamilySymbolParameterContainerList[index].ParameterName, FamilySymbolParameterContainerList[index].BuiltInParameterGroup, FamilySymbolParameterContainerList[index].FamilyCategory, FamilySymbolParameterContainerList[index].IsInstance);
              flag2 = true;
            }
          }
          else if (FamilySymbolParameterContainerList[index].ParameterName != string.Empty && _Document1.FamilyManager[FamilySymbolParameterContainerList[index].ParameterName] == null)
          {
            _Document1.FamilyManager.AddParameter(FamilySymbolParameterContainerList[index].ParameterName, FamilySymbolParameterContainerList[index].BuiltInParameterGroup, FamilySymbolParameterContainerList[index].ParameterType, FamilySymbolParameterContainerList[index].IsInstance);
            flag2 = true;
          }
        }
        transactionContainer.EndTransaction();
        if (flag2)
        {
          transactionContainer.Commit();
          string empty = string.Empty;
          string name2 = ((Element) _FamilySymbol).Name;
          bool flag3 = false;
          string str;
          if (File.Exists(_Document1.PathName))
          {
            str = _Document1.PathName;
            flag3 = true;
          }
          else
          {
            string tempPath = Path.GetTempPath();
            if (tempPath != string.Empty)
            {
              tempPath += "\\Autodesk\\Site Designer for Revit\\";
              if (!Directory.Exists(tempPath))
                Directory.CreateDirectory(tempPath);
            }
            else
              ApplicationUtility.RegistryPaths.GetSupportPath(string.Empty, ref tempPath);
            str = Path.Combine(tempPath, _Document1.Title);
          }
          if (str != string.Empty)
          {
            _Document1.SaveAs(str, new SaveAsOptions()
            {
              OverwriteExistingFile = true
            });
            _Document1.Close(false);
            bool flag4 = _TransactionContainer.Start(EPShared.LocalRM.GetString("ReloadFamilyTransaction") + Path.GetFileName(str));
            FamilyLoadOptions _FamilyLoadOptions = new FamilyLoadOptions(true);
            RevitUtility.LoadFamilySymbol(_Document, str, name2, (IFamilyLoadOptions) _FamilyLoadOptions, out _FamilySymbol, true, ref _TransactionContainer);
            if (flag4)
              _TransactionContainer.Commit();
            if (!flag3)
              File.Delete(str);
          }
        }
        else
        {
          transactionContainer.Rollback();
          _Document1.Close(false);
        }
      }
    }
    if (!flag1)
      return;
    _TransactionContainer.Start(name1);
  }

  public static void HideAllSiteComponents(Document _Document, View _View)
  {
    RevitUtility.ChangeVisibilityOfAllSiteComponents(_Document, _View, false);
  }

  public static void ShowAllSiteComponents(Document _Document, View _View)
  {
    RevitUtility.ChangeVisibilityOfAllSiteComponents(_Document, _View, true);
  }

  private static void ChangeVisibilityOfAllSiteComponents(
    Document _Document,
    View _View,
    bool _bShow)
  {
    if (_View.GenLevel == null)
    {
      switch (_View)
      {
        case View3D _:
        case ViewSection _:
          break;
        default:
          return;
      }
    }
    List<FamilyInstanceComponentWrapper> allSiteComponents = RevitUtility.FindAllSiteComponents(_Document);
    ElementSet elm_set = new ElementSet();
    for (int index = 0; index < allSiteComponents.Count; ++index)
    {
      if (!_bShow)
      {
        foreach (Element familyInstanceElement in allSiteComponents[index].GetFamilyInstanceElementSet())
        {
          if (familyInstanceElement.IsHidden(_View) == _bShow)
            elm_set.Insert(familyInstanceElement);
        }
      }
      foreach (Element originalElement in allSiteComponents[index].GetOriginalElementSet())
      {
        if (originalElement.IsHidden(_View) == _bShow)
          elm_set.Insert(originalElement);
      }
    }
    if (elm_set.Size <= 0)
      return;
    EPTransactionContainer transactionContainer = new EPTransactionContainer(_Document);
    transactionContainer.Start("Hide Element(s) In " + ((Element) _View).Name);
    transactionContainer.BeginTransaction();
    if (_bShow)
      _View.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
    else
      _View.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
    transactionContainer.EndTransaction();
    transactionContainer.Commit();
  }

  public static void AnnotateGradeAndElevationOnLegList(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper,
    bool _bUseOriginalLeg,
    ref ElementSet _ElevationText,
    ref ElementSet _GradeText)
  {
    RevitUtility.AnnotateGradeAndElevationOnLegList(_Document, _TransactionContainer, _CurrentFamilyInstanceComponentWrapper, true, true, _bUseOriginalLeg, (TextNoteType) null, ref _ElevationText, ref _GradeText, false);
  }

  public static void AnnotateGradeAndElevationOnLegList(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper,
    bool _bAnnotateElevations,
    bool _bAnnotateGrades,
    bool _bUseOriginalLeg,
    TextNoteType _TextNoteType,
    ref ElementSet _ElevationText,
    ref ElementSet _GradeText)
  {
    RevitUtility.AnnotateGradeAndElevationOnLegList(_Document, _TransactionContainer, _CurrentFamilyInstanceComponentWrapper, true, true, _bUseOriginalLeg, _TextNoteType, ref _ElevationText, ref _GradeText, false);
  }

  public static void AnnotateGradeAndElevationOnLegList(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    FamilyInstanceComponentWrapper _CurrentFamilyInstanceComponentWrapper,
    bool _bAnnotateElevations,
    bool _bAnnotateGrades,
    bool _bUseOriginalLeg,
    TextNoteType _TextNoteType,
    ref ElementSet _ElevationText,
    ref ElementSet _GradeText,
    bool _bCheckProjectSharedCoordinatesSetting)
  {
    double num1 = 0.125;
    Eps_Leg epsLeg1 = !_bUseOriginalLeg ? _CurrentFamilyInstanceComponentWrapper.ProposedLeg : _CurrentFamilyInstanceComponentWrapper.OriginalLeg;
    if (_GradeText == null)
      _GradeText = new ElementSet();
    if (_ElevationText == null)
      _ElevationText = new ElementSet();
    int _nReturnValue = 0;
    bool flag1 = false;
    if (_bCheckProjectSharedCoordinatesSetting && ApplicationUtility.Settings.eplSetE_GetSetting(_Document.PathName, "AnnotateUsingSharedCoordinates", ref _nReturnValue) || ApplicationUtility.Settings.eplSetE_GetSetting(_Document.PathName, "UseSharedElevation", ref _nReturnValue))
      flag1 = Convert.ToBoolean(_nReturnValue);
    double num2 = 0.0;
    if (flag1)
      num2 = _Document.ActiveProjectLocation.GetProjectPosition(new XYZ()).Elevation;
    XYZ xyz1 = new XYZ(1.0, 0.0, 0.0);
    XYZ xyz2 = (XYZ) null;
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    string _strToDisplay = string.Empty;
    List<TextNote> textNoteList1 = new List<TextNote>();
    List<TextNote> textNoteList2 = new List<TextNote>();
    Eps_Point epsPoint = new Eps_Point();
    FormatOptions formatOptions1 = _Document.GetUnits().GetFormatOptions((UnitType) 0);
    UnitSymbolType _UnitSymbolType1;
    try
    {
      _UnitSymbolType1 = formatOptions1.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      _UnitSymbolType1 = (UnitSymbolType) 0;
    }
    FormatOptions formatOptions2 = _Document.GetUnits().GetFormatOptions((UnitType) 59);
    UnitSymbolType _UnitSymbolType2;
    try
    {
      _UnitSymbolType2 = formatOptions2.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      _UnitSymbolType2 = (UnitSymbolType) 0;
    }
    DecimalSymbol decimalSymbol = _Document.GetUnits().DecimalSymbol;
    ElementSet instanceElementSet = _CurrentFamilyInstanceComponentWrapper.GetFamilyInstanceElementSet();
    if (instanceElementSet == null || instanceElementSet.Size == 0 || epsLeg1 == null)
      return;
    FamilyInstance existingFamilyInstance = _CurrentFamilyInstanceComponentWrapper.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance != null)
    {
      LandcaddID _LocateType = LandcaddID.SoftTerrain;
      Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
      if (parameter != null)
      {
        foreach (int num3 in Enum.GetValues(typeof (LandcaddID)))
        {
          if (string.Compare(parameter.AsString(), num3.ToString("000"), true) == 0)
          {
            _LocateType = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num3);
            break;
          }
        }
      }
      if (_CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol == null)
        _CurrentFamilyInstanceComponentWrapper.ProposedFamilySymbol = RevitUtility.FindFamilyTypeSymbol(_Document, existingFamilyInstance, _LocateType);
    }
    List<bool> boolList1 = new List<bool>();
    List<bool> boolList2 = new List<bool>();
    bool flag2 = false;
    List<XYZ> xyzList1 = new List<XYZ>();
    List<XYZ> xyzList2 = new List<XYZ>();
    XYZ _XYZPoint = (XYZ) null;
    ElementId defaultElementTypeId = _Document.GetDefaultElementTypeId((ElementTypeGroup) 12);
    TextNoteOptions textNoteOptions = new TextNoteOptions();
    textNoteOptions.HorizontalAlignment = (HorizontalTextAlignment) 2;
    textNoteOptions.TypeId = defaultElementTypeId;
    for (Eps_Leg epsLeg2 = epsLeg1; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      if (epsLeg2.Line != null)
      {
        if (_bAnnotateElevations)
        {
          RevitGeometry.Units_ConvertDoubleToString(epsLeg2.Line.StartPnt.z + num2, formatOptions1.DisplayUnits, formatOptions1.Accuracy, _UnitSymbolType1, _Document.GetUnits(), ref _strToDisplay, false);
          TextNote textNote = TextNote.Create(_Document, ((Element) _Document.ActiveView).Id, epsLeg2.Line.StartPnt.XY, num1, _strToDisplay, textNoteOptions);
          textNoteList1.Add(textNote);
          boolList1.Add(true);
          xyzList1.Add(epsLeg2.Line.StartPnt.XY);
        }
        else
        {
          boolList1.Add(false);
          xyzList1.Add((XYZ) null);
        }
        if (_bAnnotateGrades)
        {
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg2.Line.StartPnt, epsLeg2.Line.EndPnt, ref _dDistance);
          RevitGeometry.Units_ConvertDoubleToString((epsLeg2.Line.EndPnt.z - epsLeg2.Line.StartPnt.z) / _dDistance, formatOptions2.DisplayUnits, formatOptions2.Accuracy, _UnitSymbolType2, _Document.GetUnits(), ref _strToDisplay, false);
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsLeg2.Line.StartPnt, epsLeg2.Line.EndPnt, ref epsPoint);
          xyz2 = new XYZ(epsLeg2.Line.StartPnt.x - epsLeg2.Line.EndPnt.x, epsLeg2.Line.StartPnt.y - epsLeg2.Line.EndPnt.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg2.Line.StartPnt, epsLeg2.Line.EndPnt, ref _dDirection);
          _strToDisplay = _dDirection <= Math.PI / 2.0 || _dDirection > 3.0 * Math.PI / 2.0 ? _strToDisplay + " >" : "< " + _strToDisplay;
          TextNote textNote = TextNote.Create(_Document, ((Element) _Document.ActiveView).Id, epsPoint.XY, num1, _strToDisplay, textNoteOptions);
          textNoteList2.Add(textNote);
          boolList2.Add(true);
          xyzList2.Add(epsPoint.XY);
        }
        else
        {
          boolList2.Add(false);
          xyzList2.Add((XYZ) null);
        }
        if (epsLeg2.Next == null)
        {
          if (_bAnnotateElevations)
          {
            RevitGeometry.Units_ConvertDoubleToString(epsLeg2.Line.EndPnt.z + num2, formatOptions1.DisplayUnits, formatOptions1.Accuracy, _UnitSymbolType1, _Document.GetUnits(), ref _strToDisplay, false);
            TextNote textNote = TextNote.Create(_Document, ((Element) _Document.ActiveView).Id, epsLeg2.Line.EndPnt.XY, num1, _strToDisplay, textNoteOptions);
            textNoteList1.Add(textNote);
            flag2 = true;
            _XYZPoint = epsLeg2.Line.EndPnt.XY;
          }
          else
          {
            flag2 = false;
            _XYZPoint = (XYZ) null;
          }
        }
      }
      else if (epsLeg2.Arc != null)
      {
        if (_bAnnotateElevations)
        {
          RevitGeometry.Units_ConvertDoubleToString(epsLeg2.Arc.StartPnt.z + num2, formatOptions1.DisplayUnits, formatOptions1.Accuracy, _UnitSymbolType1, _Document.GetUnits(), ref _strToDisplay, false);
          TextNote textNote = TextNote.Create(_Document, ((Element) _Document.ActiveView).Id, epsLeg2.Arc.StartPnt.XY, num1, _strToDisplay, textNoteOptions);
          textNoteList1.Add(textNote);
          boolList1.Add(true);
          xyzList1.Add(epsLeg2.Arc.StartPnt.XY);
        }
        else
        {
          boolList1.Add(false);
          xyzList1.Add((XYZ) null);
        }
        if (_bAnnotateGrades)
        {
          _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg2.Arc.Radius, epsLeg2.Arc.Delta);
          RevitGeometry.Units_ConvertDoubleToString((epsLeg2.Arc.StartPnt.z - epsLeg2.Arc.EndPnt.z) / _dDistance, formatOptions2.DisplayUnits, formatOptions2.Accuracy, _UnitSymbolType2, _Document.GetUnits(), ref _strToDisplay, false);
          EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg2.Arc, _dDistance / 2.0, 0.0, ref epsPoint);
          xyz2 = new XYZ(epsLeg2.Arc.StartPnt.x - epsLeg2.Arc.EndPnt.x, epsLeg2.Arc.StartPnt.y - epsLeg2.Arc.EndPnt.y, RevitUtility.GetPlane(_Document.ActiveView.SketchPlane).Origin.Z);
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg2.Arc.StartPnt, epsLeg2.Arc.EndPnt, ref _dDirection);
          _strToDisplay = _dDirection <= Math.PI / 2.0 || _dDirection > 3.0 * Math.PI / 2.0 ? _strToDisplay + " >" : "< " + _strToDisplay;
          TextNote textNote = TextNote.Create(_Document, ((Element) _Document.ActiveView).Id, epsPoint.XY, num1, _strToDisplay, textNoteOptions);
          textNoteList2.Add(textNote);
          boolList2.Add(true);
          xyzList2.Add(epsPoint.XY);
        }
        else
        {
          boolList2.Add(false);
          xyzList2.Add((XYZ) null);
        }
        if (epsLeg2.Next == null)
        {
          if (_bAnnotateElevations)
          {
            RevitGeometry.Units_ConvertDoubleToString(epsLeg2.Arc.EndPnt.z + num2, formatOptions1.DisplayUnits, formatOptions1.Accuracy, _UnitSymbolType1, _Document.GetUnits(), ref _strToDisplay, false);
            TextNote textNote = TextNote.Create(_Document, ((Element) _Document.ActiveView).Id, epsLeg2.Arc.EndPnt.XY, num1, _strToDisplay, textNoteOptions);
            textNoteList1.Add(textNote);
            flag2 = true;
            _XYZPoint = epsLeg2.Arc.EndPnt.XY;
          }
          else
          {
            flag2 = false;
            _XYZPoint = (XYZ) null;
          }
        }
      }
    }
    foreach (Element element in instanceElementSet)
    {
      Parameter parameter1 = element.LookupParameter(RevitParameters.SiteComponentHasElevationAnnotationParameter);
      if (parameter1 != null)
      {
        int num4 = _bAnnotateElevations ? 1 : 0;
        parameter1.Set(num4);
      }
      Parameter parameter2 = element.LookupParameter(RevitParameters.SiteComponentHasGradeAnnotationParameter);
      if (parameter2 != null)
      {
        int num5 = _bAnnotateGrades ? 1 : 0;
        parameter2.Set(num5);
      }
    }
    if (textNoteList1.Count > 0)
    {
      _TransactionContainer.BeginTransaction();
      foreach (TextNote textNote in textNoteList1)
        _ElevationText.Insert((Element) textNote);
      _TransactionContainer.EndTransaction();
    }
    if (textNoteList2.Count > 0)
    {
      _TransactionContainer.BeginTransaction();
      foreach (TextNote textNote in textNoteList2)
        _GradeText.Insert((Element) textNote);
      _TransactionContainer.EndTransaction();
    }
    foreach (Element element1 in _ElevationText)
    {
      if (element1 is TextNote textNote)
      {
        if (_TextNoteType != null)
          textNote.TextNoteType = _TextNoteType;
        Eps_Point _ComparePoint = new Eps_Point(((TextElement) textNote).Coord);
        int index = 0;
        foreach (Element element2 in instanceElementSet)
        {
          if (boolList1.Count > 0 && xyzList1.Count > 0 && index < boolList1.Count && index < xyzList1.Count && boolList1[index] && new Eps_Point(xyzList1[index]).IsEqual(_ComparePoint))
            element2.LookupParameter(RevitParameters.SiteComponentAnnotationBeginElevationIDParameter)?.Set(element1.UniqueId);
          if (!epsLeg1.IsLegClosed() && index == instanceElementSet.Size - 1 && flag2 && _XYZPoint != null && new Eps_Point(_XYZPoint).IsEqual(_ComparePoint))
            element2.LookupParameter(RevitParameters.SiteComponentAnnotationEndElevationIDParameter)?.Set(element1.UniqueId);
          ++index;
        }
      }
    }
    foreach (Element element3 in _GradeText)
    {
      if (element3 is TextNote textNote)
      {
        if (_TextNoteType != null)
          textNote.TextNoteType = _TextNoteType;
        Eps_Point _ComparePoint = new Eps_Point(((TextElement) textNote).Coord);
        int index = 0;
        foreach (Element element4 in instanceElementSet)
        {
          if (boolList2.Count > 0 && xyzList2.Count > 0 && index < boolList2.Count && index < xyzList2.Count && boolList2[index] && new Eps_Point(xyzList2[index]).IsEqual(_ComparePoint))
            element4.LookupParameter(RevitParameters.SiteComponentAnnotationGradeIDParameter)?.Set(element3.UniqueId);
          ++index;
        }
      }
    }
  }

  public static FamilySymbol FindFamilyTypeSymbol(
    Document _Document,
    FamilyInstance _PlacementInstance,
    LandcaddID _LocateType)
  {
    bool _bFamilySymbolPresent = false;
    return RevitUtility.FindFamilyTypeSymbol(_Document, _PlacementInstance, _LocateType, ref _bFamilySymbolPresent);
  }

  public static FamilySymbol FindFamilyTypeSymbol(
    Document _Document,
    FamilyInstance _PlacementInstance,
    LandcaddID _LocateType,
    ref bool _bFamilySymbolPresent)
  {
    _bFamilySymbolPresent = false;
    string strA1 = string.Empty;
    string strA2 = string.Empty;
    string strA3 = string.Empty;
    Parameter parameter1 = ((Element) _PlacementInstance).LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
    if (parameter1 != null)
      strA1 = parameter1.AsString();
    Parameter parameter2 = ((Element) _PlacementInstance).LookupParameter(RevitParameters.FamilySymbolNameFamilyParameter);
    if (parameter2 != null)
      strA2 = parameter2.AsString();
    Parameter parameter3 = ((Element) _PlacementInstance).LookupParameter(RevitParameters.FamilyNameFamilyParameter);
    if (parameter3 != null)
      strA3 = parameter3.AsString();
    Parameter CurLanddCadID = (Parameter) null;
    FamilySymbol familySymbol = (FamilySymbol) null;
    FamilySymbol familyTypeSymbol1 = (FamilySymbol) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) _LocateType).ToString("000"), true) == 0)).ToList<Element>();
    familySymbol = (FamilySymbol) null;
    foreach (Element element in list)
    {
      if (element is FamilySymbol familyTypeSymbol2 && ((Element) familyTypeSymbol2).Category != null && familyTypeSymbol2.Family != null)
      {
        CurLanddCadID = ((Element) familyTypeSymbol2).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) _LocateType).ToString("000"), true) == 0)
        {
          _bFamilySymbolPresent = true;
          if (string.Compare(strA1, ((Element) familyTypeSymbol2).UniqueId, true) == 0)
            return familyTypeSymbol2;
          if (string.Compare(strA2, ((Element) familyTypeSymbol2).Name, true) == 0 && string.Compare(strA3, ((Element) familyTypeSymbol2.Family).Name, true) == 0)
            familyTypeSymbol1 = familyTypeSymbol2;
        }
      }
    }
    if (familyTypeSymbol1 != null)
      parameter1.Set(((Element) familyTypeSymbol1).UniqueId);
    return familyTypeSymbol1;
  }

  public static bool FindMassTemplateFileName(
    Document _Document,
    LandcaddID _CurID,
    ref string _strTemplateFileName,
    ref string _strAdditionalTemplateFileName)
  {
    return RevitUtility.FindMassTemplateFileName(_Document, _CurID, ref _strTemplateFileName, ref _strAdditionalTemplateFileName, true);
  }

  public static bool FindMassTemplateFileName(
    Document _Document,
    LandcaddID _CurID,
    ref string _strTemplateFileName,
    bool _bIssueWarning)
  {
    string empty = string.Empty;
    return RevitUtility.FindMassTemplateFileName(_Document, _CurID, ref _strTemplateFileName, ref empty, _bIssueWarning);
  }

  public static bool FindMassTemplateFileName(
    Document _Document,
    LandcaddID _CurID,
    ref string _strTemplateFileName,
    ref string _strAdditionalTemplateFileName,
    bool _bIssueWarning)
  {
    bool templateFileName = false;
    string _strSettingsName1 = string.Empty;
    string _strSettingsName2 = string.Empty;
    switch (_CurID)
    {
      case LandcaddID.Street:
        _strSettingsName1 = "StreetMassTemplateFileName";
        _strSettingsName2 = "CurbMassTemplateFileName";
        break;
      case LandcaddID.Curb:
        _strSettingsName1 = "CurbMassTemplateFileName";
        break;
      case LandcaddID.Sidewalk:
        _strSettingsName1 = "SidewalkMassTemplateFileName";
        break;
      case LandcaddID.RetainingWall:
        _strSettingsName1 = "RetainingWallMassTemplateFileName";
        break;
      case LandcaddID.Pipe:
        _strSettingsName1 = "PipeMassTemplateFileName";
        _strSettingsName2 = "StructureMassTemplateFileName";
        break;
      case LandcaddID.Structure:
        _strSettingsName1 = "StructureMassTemplateFileName";
        break;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName1, ref _strTemplateFileName) || !File.Exists(_strTemplateFileName))
    {
      string empty1 = string.Empty;
      string _strSettingsName3 = "MassTemplateFileName";
      if (_strSettingsName1 == string.Empty)
        _strSettingsName1 = _strSettingsName3;
      if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName3, ref _strTemplateFileName) || !File.Exists(_strTemplateFileName))
      {
        if (_Document != null)
        {
          string searchPattern1 = string.Empty;
          string searchPattern2 = string.Empty;
          string familyTemplatePath = _Document.Application.FamilyTemplatePath;
          if (!string.IsNullOrEmpty(familyTemplatePath))
          {
            for (int index = 0; index < 2; ++index)
            {
              DirectoryInfo directoryInfo1 = new DirectoryInfo(familyTemplatePath);
              DirectoryInfo directoryInfo2 = (DirectoryInfo) null;
              if (directoryInfo1.Parent != null)
                directoryInfo2 = directoryInfo1.Parent.Parent;
              if (directoryInfo2 != null)
              {
                if (_Document.DisplayUnitSystem == 1)
                {
                  if (searchPattern1 == string.Empty)
                    searchPattern1 = ApplicationUtility.GetString("MassImperialTemplate") + ".rft";
                  switch (index)
                  {
                    case 0:
                      searchPattern2 = ApplicationUtility.GetString("ENU-ImperialTemplateFolderName");
                      break;
                    case 1:
                      searchPattern2 = "Imperial";
                      break;
                  }
                }
                else if (_Document.DisplayUnitSystem == null)
                {
                  if (searchPattern1 == string.Empty)
                    searchPattern1 = ApplicationUtility.GetString("MassMetricTemplate") + ".rft";
                  switch (index)
                  {
                    case 0:
                      searchPattern2 = ApplicationUtility.GetString("ENU-MetricTemplateFolderName");
                      break;
                    case 1:
                      searchPattern2 = "Metric";
                      break;
                  }
                }
                if (directoryInfo2.Exists)
                {
                  try
                  {
                    foreach (DirectoryInfo directory in directoryInfo2.GetDirectories(searchPattern2, SearchOption.AllDirectories))
                    {
                      foreach (FileInfo file in directory.GetFiles(searchPattern1, SearchOption.AllDirectories))
                      {
                        if (file.Exists)
                        {
                          _strTemplateFileName = file.FullName;
                          templateFileName = true;
                          break;
                        }
                      }
                      if (templateFileName)
                        break;
                    }
                  }
                  catch (UnauthorizedAccessException ex)
                  {
                    continue;
                  }
                  catch (DirectoryNotFoundException ex)
                  {
                    continue;
                  }
                }
              }
              if (templateFileName)
                break;
            }
          }
        }
        if (!templateFileName)
        {
          string empty2 = string.Empty;
          string empty3 = string.Empty;
          if (!File.Exists(ApplicationUtility.RevitIniFilename))
          {
            if (_bIssueWarning)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RevitINIFileMissingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
            }
            return false;
          }
          StreamReader streamReader = new StreamReader((Stream) new FileStream(ApplicationUtility.RevitIniFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
          string strA;
          while ((strA = streamReader.ReadLine()) != null)
          {
            if (strA.Contains(ApplicationUtility.GetString("FamilyTemplatePath")))
            {
              string str1 = string.Empty;
              int num = strA.IndexOf('=');
              if (num >= 0 && num < strA.Length - 1)
              {
                string str2 = strA.Substring(num + 1);
                if (!str2.EndsWith("\\"))
                  str2 += "\\";
                str1 = $"{str2}{ApplicationUtility.GetString("ConceptualMassFolder")}\\";
              }
              _strTemplateFileName = !strA.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str1 + ApplicationUtility.GetString("MassMetricTemplate") : str1 + ApplicationUtility.GetString("MassImperialTemplate");
              _strTemplateFileName += ".rft";
              if (File.Exists(_strTemplateFileName))
              {
                templateFileName = true;
                break;
              }
              _strTemplateFileName = string.Empty;
            }
            else if (string.Compare(strA, ApplicationUtility.GetString("ContentInstalledName"), true) == 0)
            {
              string str3;
              while ((str3 = streamReader.ReadLine()) != null)
              {
                if (str3.Contains(ApplicationUtility.GetString("ImperialTemplateCabName")) || str3.Contains(ApplicationUtility.GetString("MetricTemplateCabName")))
                {
                  string str4 = string.Empty;
                  int num = str3.IndexOf('=');
                  if (num >= 0 && num < str3.Length - 1)
                  {
                    string str5 = str3.Substring(num + 1);
                    if (!str5.EndsWith("\\"))
                      str5 += "\\";
                    str4 = $"{str5}{ApplicationUtility.GetString("ConceptualMassFolder")}\\";
                  }
                  _strTemplateFileName = !str3.Contains(ApplicationUtility.GetString("ENU-ImperialTemplateFolderName")) ? str4 + ApplicationUtility.GetString("MassMetricTemplate") : str4 + ApplicationUtility.GetString("MassImperialTemplate");
                  _strTemplateFileName += ".rft";
                  if (File.Exists(_strTemplateFileName))
                  {
                    templateFileName = true;
                    break;
                  }
                  _strTemplateFileName = string.Empty;
                }
              }
              break;
            }
          }
          streamReader.Close();
        }
        if (!templateFileName)
        {
          if (!_bIssueWarning)
            return false;
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoMassRFTMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
          using (OpenFileDialog openFileDialog = new OpenFileDialog())
          {
            openFileDialog.Title = EPShared.LocalRM.GetString("TemplateNotLoadedErrorMessage");
            openFileDialog.RestoreDirectory = true;
            openFileDialog.Filter = ApplicationUtility.GetString("TemplateFilePickerFilter");
            if (openFileDialog.ShowDialog() == DialogResult.Cancel)
              return false;
            _strTemplateFileName = openFileDialog.FileName;
            templateFileName = true;
          }
        }
      }
      else
        templateFileName = true;
    }
    else
      templateFileName = true;
    if (_CurID == LandcaddID.Street || _CurID == LandcaddID.Pipe)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName2, ref _strAdditionalTemplateFileName) || !File.Exists(_strAdditionalTemplateFileName))
        _strAdditionalTemplateFileName = _strTemplateFileName;
      ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName2, _strAdditionalTemplateFileName);
    }
    ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName1, _strTemplateFileName);
    return templateFileName;
  }

  public static bool FindLanguageName(ref string _strLanguageName)
  {
    bool languageName = false;
    string _strSettingsName = "LanguageName";
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName, ref _strLanguageName))
    {
      string empty = string.Empty;
      if (!File.Exists(ApplicationUtility.RevitIniFilename))
      {
        if (ApplicationUtility.StringTable != null)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("RevitINIFileMissingMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
        }
        return false;
      }
      StreamReader streamReader = new StreamReader((Stream) new FileStream(ApplicationUtility.RevitIniFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.ASCII);
      string strA;
      while ((strA = streamReader.ReadLine()) != null)
      {
        if (string.Compare(strA, "[Language]", true) == 0)
        {
          string str = streamReader.ReadLine();
          int num = str.IndexOf('=');
          if (num >= 0 && num < str.Length - 1)
          {
            _strLanguageName = str.Substring(num + 1);
            languageName = true;
            break;
          }
          break;
        }
      }
      streamReader.Close();
      ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName, _strLanguageName);
    }
    else
      languageName = true;
    return languageName;
  }

  public static ModelCurve NewModelCurve(Document _Document, Eps_Arc _Arc)
  {
    return RevitUtility.NewModelCurve(_Document, _Arc, _Document.ActiveView.SketchPlane);
  }

  public static ModelCurve NewModelCurve(Document _Document, Eps_Arc _Arc, View _CurView)
  {
    return RevitUtility.NewModelCurve(_Document, _Arc, _CurView.SketchPlane);
  }

  public static ModelCurve NewModelCurve(
    Document _Document,
    Eps_Arc _Arc,
    SketchPlane _SketchPlane)
  {
    Eps_Arc epsArc = new Eps_Arc(_Arc);
    epsArc.RadiusPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
    epsArc.EndPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
    epsArc.StartPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
    Arc arc = epsArc.RevitArc(_Document);
    try
    {
      return ((ItemFactoryBase) _Document.Create).NewModelCurve((Curve) arc, _SketchPlane);
    }
    catch (ArgumentException ex)
    {
      Plane byNormalAndOrigin = Plane.CreateByNormalAndOrigin(new XYZ(0.0, 0.0, 1.0), RevitUtility.GetPlane(_SketchPlane).Origin);
      SketchPlane sketchPlane = SketchPlane.Create(_Document, byNormalAndOrigin);
      return ((ItemFactoryBase) _Document.Create).NewModelCurve((Curve) arc, sketchPlane);
    }
  }

  public static ModelCurve NewModelCurve(Document _Document, Eps_Line _Line)
  {
    return RevitUtility.NewModelCurve(_Document, _Line, _Document.ActiveView.SketchPlane);
  }

  public static ModelCurve NewModelCurve(Document _Document, Eps_Line _Line, View _CurView)
  {
    return RevitUtility.NewModelCurve(_Document, _Line, _CurView.SketchPlane);
  }

  public static ModelCurve NewModelCurve(
    Document _Document,
    Eps_Line _Line,
    SketchPlane _SketchPlane)
  {
    Eps_Line epsLine = new Eps_Line(_Line);
    epsLine.EndPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
    epsLine.StartPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
    if (EPShared.eplGeoE_ArePntsDuplicates2D(epsLine.StartPnt, epsLine.EndPnt, 1.0 / 400.0))
      return (ModelCurve) null;
    Line line = epsLine.RevitLine(_Document);
    try
    {
      return ((ItemFactoryBase) _Document.Create).NewModelCurve((Curve) line, _SketchPlane);
    }
    catch (ArgumentException ex)
    {
      Plane byNormalAndOrigin = Plane.CreateByNormalAndOrigin(new XYZ(0.0, 0.0, 1.0), RevitUtility.GetPlane(_SketchPlane).Origin);
      SketchPlane sketchPlane = SketchPlane.Create(_Document, byNormalAndOrigin);
      return ((ItemFactoryBase) _Document.Create).NewModelCurve((Curve) line, sketchPlane);
    }
  }

  public static ModelCurveArray NewModelCurveArray(Document _Document, Eps_Leg _Leg)
  {
    return RevitUtility.NewModelCurveArray(_Document, _Leg, _Document.ActiveView.SketchPlane, true);
  }

  public static ModelCurveArray NewModelCurveArray(Document _Document, Eps_Leg _Leg, View _CurView)
  {
    return RevitUtility.NewModelCurveArray(_Document, _Leg, _CurView.SketchPlane, true);
  }

  public static ModelCurveArray NewModelCurveArray(
    Document _Document,
    Eps_Leg _Leg,
    View _CurView,
    bool _bUse2011TempLines)
  {
    return RevitUtility.NewModelCurveArray(_Document, _Leg, _CurView.SketchPlane, _bUse2011TempLines);
  }

  public static Plane GetPlane(SketchPlane p) => p.GetPlane();

  public static Line CreateLine(XYZ pt1, XYZ pt2, bool bBound)
  {
    return bBound ? Line.CreateBound(pt1, pt2) : Line.CreateUnbound(pt1, pt2);
  }

  public static ModelCurveArray NewModelCurveArray(
    Document _Document,
    Eps_Leg _Leg,
    SketchPlane _SketchPlane,
    bool _bUse2011TempLines)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    for (Eps_Leg epsLeg2 = _Leg; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg2.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg2.Line);
        _CompleteLeg.Line.EndPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
        _CompleteLeg.Line.StartPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
      }
      else if (epsLeg2.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg2.Arc);
        _CompleteLeg.Arc.RadiusPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
        _CompleteLeg.Arc.EndPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
        _CompleteLeg.Arc.StartPnt.z = RevitUtility.GetPlane(_SketchPlane).Origin.Z;
      }
      if (_CompleteLeg.Line != null || _CompleteLeg.Arc != null)
      {
        if (epsLeg1 == null)
          epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg);
        else
          epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
      }
    }
    CurveArray _CurveArray = epsLeg1.CurveArray(_Document);
    ModelCurveArray modelCurveArray = (ModelCurveArray) null;
    if (_CurveArray != null)
    {
      if (_CurveArray.Size > 0)
      {
        try
        {
          modelCurveArray = RevitUtility.CreateModelCurveArray(_Document, _CurveArray, _SketchPlane, _bUse2011TempLines);
        }
        catch (ArgumentException ex)
        {
          Plane byNormalAndOrigin = Plane.CreateByNormalAndOrigin(new XYZ(0.0, 0.0, 1.0), RevitUtility.GetPlane(_SketchPlane).Origin);
          SketchPlane _SketchPlane1 = SketchPlane.Create(_Document, byNormalAndOrigin);
          modelCurveArray = RevitUtility.CreateModelCurveArray(_Document, _CurveArray, _SketchPlane1, _bUse2011TempLines);
        }
      }
    }
    return modelCurveArray;
  }

  private static ModelCurveArray CreateModelCurveArray(
    Document _Document,
    CurveArray _CurveArray,
    SketchPlane _SketchPlane,
    bool _bUse2011TempLines)
  {
    ModelCurveArray modelCurveArray;
    if (_bUse2011TempLines)
    {
      modelCurveArray = new ModelCurveArray();
      for (int index = 0; index < _CurveArray.Size; ++index)
        modelCurveArray.Append(((ItemFactoryBase) _Document.Create).NewModelCurve(_CurveArray[index], _SketchPlane));
    }
    else
      modelCurveArray = ((ItemFactoryBase) _Document.Create).NewModelCurveArray(_CurveArray, _SketchPlane);
    return modelCurveArray;
  }

  public static DetailCurveArray NewDetailCurveArray(Document _Document, Eps_Leg _Leg)
  {
    return RevitUtility.NewDetailCurveArray(_Document, _Leg, _Document.ActiveView);
  }

  public static DetailCurveArray NewDetailCurveArray(
    Document _Document,
    Eps_Leg _Leg,
    View _CurView)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    for (Eps_Leg epsLeg2 = _Leg; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg2.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg2.Line);
        _CompleteLeg.Line.EndPnt.z = RevitUtility.GetPlane(_CurView.SketchPlane).Origin.Z;
        _CompleteLeg.Line.StartPnt.z = RevitUtility.GetPlane(_CurView.SketchPlane).Origin.Z;
      }
      else if (epsLeg2.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg2.Arc);
        _CompleteLeg.Arc.RadiusPnt.z = RevitUtility.GetPlane(_CurView.SketchPlane).Origin.Z;
        _CompleteLeg.Arc.EndPnt.z = RevitUtility.GetPlane(_CurView.SketchPlane).Origin.Z;
        _CompleteLeg.Arc.StartPnt.z = RevitUtility.GetPlane(_CurView.SketchPlane).Origin.Z;
      }
      if (epsLeg1 == null)
        epsLeg1 = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        epsLeg1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    CurveArray curveArray = epsLeg1.CurveArray(_Document);
    DetailCurveArray detailCurveArray = (DetailCurveArray) null;
    if (curveArray != null && curveArray.Size > 0)
      detailCurveArray = ((ItemFactoryBase) _Document.Create).NewDetailCurveArray(_CurView, curveArray);
    return detailCurveArray;
  }

  public static void HideElementsInAllViews(Document _Document, ElementSet _ElementSet)
  {
    if (_ElementSet == null || _ElementSet.Size == 0)
      return;
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<View> viewList = new List<View>();
    foreach (View view in (IEnumerable<Element>) elements)
    {
      if (!viewList.Contains(view))
      {
        if (view.GenLevel != null || view is ViewSection)
        {
          view.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(_ElementSet));
          viewList.Add(view);
        }
        else if (view is View3D && (view.CropBox != null || view.Origin != null || view.SketchPlane != null))
        {
          view.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(_ElementSet));
          viewList.Add(view);
        }
      }
    }
  }

  public static void ShowElementsInAllViews(Document _Document, ElementSet _ElementSet)
  {
    if (_ElementSet == null || _ElementSet.Size == 0)
      return;
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<View> viewList = new List<View>();
    foreach (View view in (IEnumerable<Element>) elements)
    {
      if (!viewList.Contains(view))
      {
        if (view.GenLevel != null || view is ViewSection)
        {
          view.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(_ElementSet));
          viewList.Add(view);
        }
        else if (view is View3D && (view.CropBox != null || view.Origin != null || view.SketchPlane != null))
        {
          view.UnhideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(_ElementSet));
          viewList.Add(view);
        }
      }
    }
  }

  public static List<View> FindAllViews(Document _Document)
  {
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<View> allViews = new List<View>();
    foreach (View view in (IEnumerable<Element>) elements)
    {
      if (!allViews.Contains(view))
      {
        if (view.GenLevel != null || view is ViewSection)
          allViews.Add(view);
        else if (view is View3D && (view.CropBox != null || view.Origin != null || view.SketchPlane != null))
          allViews.Add(view);
      }
    }
    return allViews;
  }

  public static List<KeyValuePair<View, string>> FindShowByForAllViews(Document _Document)
  {
    string str = string.Empty;
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<KeyValuePair<View, string>> showByForAllViews = new List<KeyValuePair<View, string>>();
    List<View> viewList = new List<View>();
    foreach (View key in (IEnumerable<Element>) elements)
    {
      if (!viewList.Contains(key))
      {
        if (key.GenLevel != null || key is ViewSection)
        {
          if (_Document.IsWorkshared && ((Element) key)[(BuiltInParameter) -1002053] != null)
          {
            Parameter parameter = ((Element) key)[(BuiltInParameter) -1002067];
            if (parameter != null)
              str = parameter.AsString();
          }
          viewList.Add(key);
          showByForAllViews.Add(new KeyValuePair<View, string>(key, str));
          str = string.Empty;
        }
        else if (key is View3D && (key.CropBox != null || key.Origin != null || key.SketchPlane != null))
        {
          if (_Document.IsWorkshared && ((Element) key)[(BuiltInParameter) -1002053] != null)
          {
            Parameter parameter = ((Element) key)[(BuiltInParameter) -1002067];
            if (parameter != null)
              str = parameter.AsString();
          }
          viewList.Add(key);
          showByForAllViews.Add(new KeyValuePair<View, string>(key, str));
          str = string.Empty;
        }
      }
    }
    return showByForAllViews;
  }

  public static bool CreateTrue3DViewIfNotPresent(Document _Document, ref View3D _ReturnView3D)
  {
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View3D)).ToElements();
    bool dviewIfNotPresent = false;
    foreach (View3D view3D in (IEnumerable<Element>) elements)
    {
      if (((View) view3D).CropBox != null || ((View) view3D).Origin != null || ((View) view3D).SketchPlane != null)
      {
        _ReturnView3D = view3D;
        dviewIfNotPresent = true;
        break;
      }
    }
    if (!dviewIfNotPresent)
    {
      ViewFamilyType viewFamilyType = ((IEnumerable) new FilteredElementCollector(_Document).OfClass(typeof (ViewFamilyType))).Cast<ViewFamilyType>().Where<ViewFamilyType>((Func<ViewFamilyType, bool>) (v => v.ViewFamily == 102)).First<ViewFamilyType>();
      _ReturnView3D = View3D.CreateIsometric(_Document, ((Element) viewFamilyType).Id);
      ((Element) _ReturnView3D).Name = EPShared.LocalRM.GetString("ThreeDString");
    }
    return dviewIfNotPresent;
  }

  public static void HideCategoryInAllViews(Document _Document, BuiltInCategory _BuiltInCategory)
  {
    RevitUtility.ChangeVisibilityOfCategoryInAllViews(_Document, _BuiltInCategory, false);
  }

  public static void ShowCategoryInAllViews(Document _Document, BuiltInCategory _BuiltInCategory)
  {
    RevitUtility.ChangeVisibilityOfCategoryInAllViews(_Document, _BuiltInCategory, true);
  }

  private static void ChangeVisibilityOfCategoryInAllViews(
    Document _Document,
    BuiltInCategory _BuiltInCategory,
    bool _bShow)
  {
    if (_BuiltInCategory == -1)
      return;
    Category category = _Document.Settings.Categories[_BuiltInCategory];
    if (category == null)
      return;
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<View> viewList = new List<View>();
    foreach (View view in (IEnumerable<Element>) elements)
    {
      if (!viewList.Contains(view))
      {
        if (view.GenLevel != null || view is ViewSection)
        {
          try
          {
            category[view] = _bShow;
          }
          catch
          {
            if (_Document.GetElement(_Document.ActiveView.ViewTemplateId) is ViewPlan element)
              category[(View) element] = true;
          }
          viewList.Add(view);
        }
        else if (view is View3D && (view.CropBox != null || view.Origin != null || view.SketchPlane != null))
        {
          try
          {
            category[view] = _bShow;
          }
          catch
          {
            if (_Document.GetElement(_Document.ActiveView.ViewTemplateId) is ViewPlan element)
              category[(View) element] = true;
          }
          viewList.Add(view);
        }
      }
    }
  }

  public static List<View> FindAllViewsWithElementsVisible(
    Document _Document,
    ElementSet _ElementSet)
  {
    if (_ElementSet == null || _ElementSet.Size == 0)
      return (List<View>) null;
    IList<Element> elements = new FilteredElementCollector(_Document).OfClass(typeof (View)).ToElements();
    List<View> withElementsVisible = new List<View>();
    foreach (Element element in _ElementSet)
    {
      foreach (View view in (IEnumerable<Element>) elements)
      {
        if (!withElementsVisible.Contains(view) && !element.IsHidden(view))
        {
          if (view.GenLevel != null || view is ViewSection)
            withElementsVisible.Add(view);
          else if (view is View3D && (view.CropBox != null || view.Origin != null || view.SketchPlane != null))
            withElementsVisible.Add(view);
        }
      }
    }
    return withElementsVisible;
  }

  public static List<KeyValuePair<string, Category>> GetAllMassLineSubCategories(
    Document _Document,
    ref bool _bDoesAllMassLineSubCategoriesExist)
  {
    return RevitUtility.GetAllMassLineSubCategories(_Document, ref _bDoesAllMassLineSubCategoriesExist, string.Empty);
  }

  public static List<KeyValuePair<string, Category>> GetAllMassLineSubCategories(
    Document _Document,
    ref bool _bDoesAllMassLineSubCategoriesExist,
    string _strExcludeCategory)
  {
    _bDoesAllMassLineSubCategoriesExist = true;
    bool _bDoesMassLineSubCategoryExist = false;
    List<KeyValuePair<string, Category>> lineSubCategories = new List<KeyValuePair<string, Category>>();
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.SoftTerrain, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.SoftTerrain).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.Sidewalk, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.Sidewalk).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.RetainingWall, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.RetainingWall).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.Street).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.Street, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.Street).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.Curb).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.Curb, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.Curb).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.ParkingLot, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.ParkingLot).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.FeatureLine).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.FeatureLine, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.FeatureLine).ToString("000"), componentLineSubCategory));
    }
    if (string.Compare(_strExcludeCategory, Convert.ToInt32((object) LandcaddID.PointWipeout).ToString("000"), true) != 0)
    {
      Category componentLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, LandcaddID.PointWipeout, ref _bDoesMassLineSubCategoryExist);
      if (!_bDoesMassLineSubCategoryExist)
        _bDoesAllMassLineSubCategoriesExist = false;
      if (componentLineSubCategory == null)
        return (List<KeyValuePair<string, Category>>) null;
      lineSubCategories.Add(new KeyValuePair<string, Category>(Convert.ToInt32((object) LandcaddID.PointWipeout).ToString("000"), componentLineSubCategory));
    }
    return lineSubCategories;
  }

  public static Category GetSiteComponentLineSubCategory(
    Document _Document,
    LandcaddID _CurLandcaddId)
  {
    bool _bDoesMassLineSubCategoryExist = false;
    return RevitUtility.GetSiteComponentLineSubCategory(_Document, _CurLandcaddId, ref _bDoesMassLineSubCategoryExist);
  }

  public static Category GetSiteComponentLineSubCategory(
    Document _Document,
    LandcaddID _CurLandcaddId,
    ref bool _bDoesMassLineSubCategoryExist)
  {
    Category componentLineSubCategory = (Category) null;
    string _strSettingsName1 = string.Empty;
    string empty1 = string.Empty;
    string _strSettingsName2 = string.Empty;
    string _strSettingsName3 = string.Empty;
    switch (_CurLandcaddId)
    {
      case LandcaddID.SoftTerrain:
        _strSettingsName1 = "SoftTerrainLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWSoftTerrainLineNameString");
        _strSettingsName2 = "SoftTerrainLineSubCategoryColor";
        _strSettingsName3 = "SoftTerrainLineSubCategoryLineWeight";
        break;
      case LandcaddID.Street:
        _strSettingsName1 = "StreetLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWStreetLineNameString");
        _strSettingsName2 = "StreetLineSubCategoryColor";
        _strSettingsName3 = "StreetLineSubCategoryLineWeight";
        break;
      case LandcaddID.Curb:
        _strSettingsName1 = "CurbLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWCurbLineNameString");
        _strSettingsName2 = "CurbLineSubCategoryColor";
        _strSettingsName3 = "CurbLineSubCategoryLineWeight";
        break;
      case LandcaddID.Sidewalk:
        _strSettingsName1 = "SidewalkLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWSidewalkLineNameString");
        _strSettingsName2 = "SidewalkLineSubCategoryColor";
        _strSettingsName3 = "SidewalkLineSubCategoryLineWeight";
        break;
      case LandcaddID.RetainingWall:
        _strSettingsName1 = "RetainingWallLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWRetainingWallLineNameString");
        _strSettingsName2 = "RetainingWallLineSubCategoryColor";
        _strSettingsName3 = "RetainingWallLineSubCategoryLineWeight";
        break;
      case LandcaddID.ParkingLot:
        _strSettingsName1 = "ParkingLotLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWParkingLotLineNameString");
        _strSettingsName2 = "ParkingLotLineSubCategoryColor";
        _strSettingsName3 = "ParkingLotLineSubCategoryLineWeight";
        break;
      case LandcaddID.FeatureLine:
        _strSettingsName1 = "FeatureLineLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWFeatureLineLineNameString");
        _strSettingsName2 = "FeatureLineLineSubCategoryColor";
        _strSettingsName3 = "FeatureLineLineSubCategoryLineWeight";
        break;
      case LandcaddID.PointWipeout:
        _strSettingsName1 = "PointWipeoutLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWPointWipeoutLineNameString");
        _strSettingsName2 = "PointWipeoutLineSubCategoryColor";
        _strSettingsName3 = "PointWipeoutLineSubCategoryLineWeight";
        break;
      case LandcaddID.IntersectionPlacement:
        _strSettingsName1 = "IntersectionLineSubCategoryName";
        empty1 = EPShared.LocalRM.GetString("SWIntersectionLineNameString");
        _strSettingsName2 = "IntersectionLineSubCategoryColor";
        _strSettingsName3 = "IntersectionLineSubCategoryLineWeight";
        break;
    }
    Category category = _Document.Settings.Categories[(BuiltInCategory) -2000051];
    if (category != null && category.SubCategories != null && category.SubCategories.Size > 0)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName1, ref empty1) && !ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName1.Replace("Category", "Catergory"), ref empty1))
        ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName1, empty1);
      if (category.SubCategories.Contains(empty1))
        componentLineSubCategory = category.SubCategories[empty1];
    }
    string empty2 = string.Empty;
    if (componentLineSubCategory == null)
    {
      string _strReturnValue = $"{EPShared.LocalRM.GetString("RGBString")} {EPShared.LocalRM.GetString("DefaultLineColor")}";
      _bDoesMassLineSubCategoryExist = false;
      componentLineSubCategory = _Document.Settings.Categories.NewSubcategory(category, empty1);
      if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName2, ref _strReturnValue) && !ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName2.Replace("Category", "Catergory"), ref _strReturnValue))
        ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName2, _strReturnValue);
      Color _FindColor = (Color) null;
      if (RevitUtility.FindColorFromString(_strReturnValue, ref _FindColor) && _FindColor != null)
        componentLineSubCategory.LineColor = _FindColor;
      int _nReturnValue = 1;
      if (!ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName3, ref _nReturnValue) && !ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingsName3.Replace("Category", "Catergory"), ref _nReturnValue))
        ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName3, _nReturnValue);
      componentLineSubCategory.SetLineWeight(_nReturnValue, (GraphicsStyleType) 1);
    }
    else
    {
      if (componentLineSubCategory.Name != string.Empty)
        ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName1, componentLineSubCategory.Name);
      RevitUtility.FindStringFromColor(componentLineSubCategory.LineColor, ref empty2);
      if (empty2 != string.Empty)
        ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName2, empty2);
      int? lineWeight = componentLineSubCategory.GetLineWeight((GraphicsStyleType) 1);
      if (lineWeight.HasValue)
        ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingsName3, lineWeight.Value);
      _bDoesMassLineSubCategoryExist = true;
    }
    return componentLineSubCategory;
  }

  public static bool FindColorFromString(string _strColorValue, ref Color _FindColor)
  {
    _FindColor = (Color) null;
    Color _FindColor1 = new Color();
    bool colorFromString = RevitUtility.FindColorFromString(_strColorValue, ref _FindColor1);
    if (colorFromString)
      _FindColor = new Color(_FindColor1.R, _FindColor1.G, _FindColor1.B);
    return colorFromString;
  }

  public static bool FindColorFromString(string _strColorValue, ref Color _FindColor)
  {
    bool colorFromString = false;
    string name = _strColorValue;
    _FindColor = new Color();
    if (!name.StartsWith(EPShared.LocalRM.GetString("RGBString")))
    {
      _FindColor = Color.FromName(name);
      colorFromString = true;
    }
    if (!colorFromString && name != string.Empty)
    {
      int num = name.IndexOf(' ');
      if (num >= 0 && num < name.Length)
      {
        string[] strArray = name.Substring(num + 1).Split('-');
        if (strArray.Length == 3)
        {
          _FindColor = Color.FromArgb(Convert.ToInt32(strArray[0]), Convert.ToInt32(strArray[1]), Convert.ToInt32(strArray[2]));
          colorFromString = true;
        }
      }
    }
    return colorFromString;
  }

  public static bool FindStringFromColor(Color _Color, ref string _strColorValue)
  {
    return RevitUtility.FindStringFromColor(Color.FromArgb((int) _Color.Red, (int) _Color.Green, (int) _Color.Blue), ref _strColorValue);
  }

  public static bool FindStringFromColor(Color _Color, ref string _strColorValue)
  {
    string str = _strColorValue;
    bool stringFromColor;
    if (_Color.IsNamedColor)
    {
      _strColorValue = _Color.Name;
      stringFromColor = true;
    }
    else
    {
      _strColorValue = $"{EPShared.LocalRM.GetString("RGBString")} {Convert.ToString(_Color.R)}-{Convert.ToString(_Color.G)}-{Convert.ToString(_Color.B)}";
      stringFromColor = true;
    }
    return stringFromColor;
  }

  public static FamilyInstance NewFamilyInstance(
    Document _CurDocument,
    XYZ _Location,
    FamilySymbol _FamilySymbol,
    Element _Host,
    Level _Level,
    StructuralType _StructuralType,
    ref EPTransactionContainer _TransactionContainer)
  {
    return RevitUtility.NewFamilyInstance(_CurDocument, _Location, _FamilySymbol, _Host, _Level, _StructuralType, true, ref _TransactionContainer);
  }

  public static FamilyInstance NewFamilyInstance(
    Document _CurDocument,
    XYZ _Location,
    FamilySymbol _FamilySymbol,
    Element _Host,
    Level _Level,
    StructuralType _StructuralType,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    if (!_FamilySymbol.IsActive)
      _FamilySymbol.Activate();
    return _CurDocument.Create.NewFamilyInstance(_Location, _FamilySymbol, _Host, _Level, _StructuralType);
  }

  public static bool LoadFamilySymbol(
    Document _CurDocument,
    string _strFamilyFilename,
    string _strSymbolName,
    IFamilyLoadOptions _FamilyLoadOptions,
    out FamilySymbol _FamilySymbol,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    return _CurDocument.LoadFamilySymbol(_strFamilyFilename, _strSymbolName, _FamilyLoadOptions, ref _FamilySymbol);
  }

  public static bool LoadFamilySymbol(
    Document _CurDocument,
    string _strFamilyFilename,
    string _strSymbolName,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    return _CurDocument.LoadFamilySymbol(_strFamilyFilename, _strSymbolName);
  }

  public static bool LoadFamilySymbol(
    Document _CurDocument,
    string _strFamilyFilename,
    string _strSymbolName,
    out FamilySymbol _FamilySymbol,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    bool flag = _CurDocument.LoadFamilySymbol(_strFamilyFilename, _strSymbolName, ref _FamilySymbol);
    if (_FamilySymbol != null && !_FamilySymbol.IsActive)
      _FamilySymbol.Activate();
    return flag;
  }

  public static bool LoadFamily(
    Document _CurDocument,
    string _strFilename,
    out Family _Family,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    return _CurDocument.LoadFamily(_strFilename, ref _Family);
  }

  public static bool LoadFamily(
    Document _CurDocument,
    string _strFilename,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    return _CurDocument.LoadFamily(_strFilename);
  }

  public static Family LoadFamily(
    Document _CurDocument,
    Document _SymbolDocument,
    bool _bUseFailureHandling,
    ref EPTransactionContainer _TransactionContainer)
  {
    if (_bUseFailureHandling)
      _TransactionContainer.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
    return _CurDocument.LoadFamily(_SymbolDocument);
  }

  public static Eps_Point GetSurveyPoint(Document _Document)
  {
    BasePoint basePoint1 = (BasePoint) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (BasePoint)).OfCategory((BuiltInCategory) -2001272);
    foreach (Element element in ((IEnumerable<Element>) source).ToList<Element>())
    {
      if (element is BasePoint basePoint2 && ((Element) basePoint2).Category != null && basePoint2.IsShared)
      {
        basePoint1 = basePoint2;
        break;
      }
    }
    Eps_Point surveyPoint = new Eps_Point();
    if (basePoint1 != null)
    {
      Parameter parameter1 = ((Element) basePoint1)[(BuiltInParameter) -1150191];
      if (parameter1 != null)
        surveyPoint.y = parameter1.AsDouble();
      Parameter parameter2 = ((Element) basePoint1)[(BuiltInParameter) -1150192];
      if (parameter2 != null)
        surveyPoint.x = parameter2.AsDouble();
      Parameter parameter3 = ((Element) basePoint1)[(BuiltInParameter) -1150193];
      if (parameter3 != null)
        surveyPoint.z = parameter3.AsDouble();
    }
    return surveyPoint;
  }

  public static FamilyInstance FindMassFamilyInstance(Document _Document, string _strFormUniqueId)
  {
    int _nIntersectionSWStreetMassLastIndex = 0;
    return RevitUtility.FindMassFamilyInstance(_Document, _strFormUniqueId, ref _nIntersectionSWStreetMassLastIndex);
  }

  public static FamilyInstance FindMassFamilyInstance(
    Document _Document,
    string _strFormUniqueId,
    ref int _nIntersectionSWStreetMassLastIndex)
  {
    FamilyInstance familyInstance = (FamilyInstance) null;
    _nIntersectionSWStreetMassLastIndex = 0;
    List<Element> list = ((IEnumerable<Element>) new FilteredElementCollector(_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2003400)).ToList<Element>();
    string str1 = EPShared.LocalRM.GetString("IntersectionSWStreetMass");
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    familyInstance = (FamilyInstance) null;
    foreach (Element element in list)
    {
      if (element is FamilyInstance massFamilyInstance && ((Element) massFamilyInstance).Category != null)
      {
        if (string.Compare(_strFormUniqueId, ((Element) massFamilyInstance).UniqueId, true) == 0)
          return massFamilyInstance;
        if (((Element) massFamilyInstance.Symbol.Family).Name.StartsWith(str1))
        {
          string str2 = ((Element) massFamilyInstance.Symbol.Family).Name.Substring(str1.Length + 1);
          for (int index = 0; index < str2.Length && char.IsDigit(str2[index]); ++index)
            empty2 += str2[index].ToString();
          if (empty2 != string.Empty)
          {
            int int32 = Convert.ToInt32(empty2);
            if (int32 > _nIntersectionSWStreetMassLastIndex)
              _nIntersectionSWStreetMassLastIndex = int32;
          }
          empty2 = string.Empty;
        }
      }
    }
    return (FamilyInstance) null;
  }

  public static DirectShape FindDirectShape(Document _Document, string _strFormUniqueId)
  {
    int _nIntersectionSWStreetMassLastIndex = 0;
    return RevitUtility.FindDirectShape(_Document, _strFormUniqueId, ref _nIntersectionSWStreetMassLastIndex);
  }

  public static DirectShape FindDirectShape(
    Document _Document,
    string _strFormUniqueId,
    ref int _nIntersectionSWStreetMassLastIndex)
  {
    DirectShape directShape1 = (DirectShape) null;
    _nIntersectionSWStreetMassLastIndex = 0;
    List<Element> list = ((IEnumerable<Element>) new FilteredElementCollector(_Document).OfClass(typeof (DirectShape))).ToList<Element>();
    string str1 = EPShared.LocalRM.GetString("IntersectionSWStreetMass");
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    directShape1 = (DirectShape) null;
    foreach (Element element in list)
    {
      if (element is DirectShape directShape2 && ((Element) directShape2).Category != null)
      {
        if (string.Compare(_strFormUniqueId, ((Element) directShape2).UniqueId, true) == 0)
          return directShape2;
        if (((Element) directShape2).Name.StartsWith(str1))
        {
          string str2 = ((Element) directShape2).Name.Substring(str1.Length + 1);
          for (int index = 0; index < str2.Length && char.IsDigit(str2[index]); ++index)
            empty2 += str2[index].ToString();
          if (empty2 != string.Empty)
          {
            int int32 = Convert.ToInt32(empty2);
            if (int32 > _nIntersectionSWStreetMassLastIndex)
              _nIntersectionSWStreetMassLastIndex = int32;
          }
          empty2 = string.Empty;
        }
      }
    }
    return (DirectShape) null;
  }

  public static bool IsParameterIDOnFamily(
    Document _Document,
    PlacementSettings _PlacementSettings,
    FamilySymbol _FamilySymbol)
  {
    if (_FamilySymbol == null)
      return true;
    Eps_Point epsPoint = new Eps_Point();
    bool flag = false;
    bool _bUseFailureHandling = true;
    if (_PlacementSettings.TransactionContainer == null)
      _bUseFailureHandling = false;
    EPTransactionContainer transactionContainer = _PlacementSettings.TransactionContainer;
    FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _FamilySymbol, (Element) null, _Document.ActiveView.GenLevel, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
    _PlacementSettings.TransactionContainer = transactionContainer;
    if (familyInstance != null && ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter) != null)
      flag = true;
    _PlacementSettings.TransactionContainer.BeginTransaction();
    _Document.Delete(((Element) familyInstance).Id);
    _PlacementSettings.TransactionContainer.EndTransaction();
    return flag;
  }

  public static void ShowHelpInRevit(string contextualID)
  {
    new ContextualHelp((ContextualHelpType) 1, contextualID).Launch();
  }
}
