using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace EPCommon;

public class SharedParametersFilenameForm : EPForm
{
	private IContainer components;

	private TextBox m_SharedParameterFileTextBox;

	private Button m_SharedParameterFileButton;

	private Label m_SharedParameterFileLabel;

	private TextBox m_SharedParameterWarningTextBox;

	private Button m_CancelButton;

	private Button m_OKButton;

	public string SharedParameterFileName
	{
		get
		{
			return m_SharedParameterFileTextBox.Text;
		}
		set
		{
			m_SharedParameterFileTextBox.Text = value;
		}
	}

	public SharedParametersFilenameForm()
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("CreateSharedParameterFileDialog");
		m_SharedParameterFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_SharedParameterWarningTextBox.Text = EPShared.LocalRM.GetString("SharedParametersDontExistDialog");
		SiteDesigner.UI.WpfFocus.Focus(m_SharedParameterFileTextBox);
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		if (ValidateField())
		{
			DialogResult = DialogResult.OK;
			Close();
		}
	}

	private void OnCancelClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private bool ValidateField()
	{
		string text = m_SharedParameterFileTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySharedParameterFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_SharedParameterFileTextBox);
			return false;
		}
		string text2 = ".txt";
		if ((text.LastIndexOf("\\") < 0 || !Directory.Exists(text.Substring(0, text.LastIndexOf("\\")))) && (text.LastIndexOf("/") < 0 || !Directory.Exists(text.Substring(0, text.LastIndexOf("/")))))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return false;
		}
		if (text.IndexOf(text2) < 0)
		{
			text += text2;
		}
		m_SharedParameterFileTextBox.Text = text;
		return true;
	}

	private void OnSharedParameterFileButtonClick(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		saveFileDialog.OverwritePrompt = false;
		string _strSupportPath = string.Empty;
		int num = -1;
		if (m_SharedParameterFileTextBox.Text.IndexOf("\\") >= 0)
		{
			num = m_SharedParameterFileTextBox.Text.LastIndexOf("\\");
		}
		if (m_SharedParameterFileTextBox.Text.LastIndexOf("/") > num)
		{
			num = m_SharedParameterFileTextBox.Text.LastIndexOf("/");
		}
		if (Directory.Exists(m_SharedParameterFileTextBox.Text.Substring(0, num)))
		{
			saveFileDialog.InitialDirectory = m_SharedParameterFileTextBox.Text.Substring(0, num);
		}
		else if (ApplicationUtility.RegistryPaths.GetSupportPath(string.Empty, ref _strSupportPath) == 0)
		{
			saveFileDialog.InitialDirectory = _strSupportPath;
		}
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_SharedParameterFileTextBox.Text = saveFileDialog.FileName;
			SiteDesigner.UI.WpfFocus.Focus(m_SharedParameterFileTextBox);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_SharedParameterFileTextBox = new System.Windows.Forms.TextBox();
		this.m_SharedParameterFileButton = new System.Windows.Forms.Button();
		this.m_SharedParameterFileLabel = new System.Windows.Forms.Label();
		this.m_SharedParameterWarningTextBox = new System.Windows.Forms.TextBox();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_OKButton = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.m_SharedParameterFileTextBox.Location = new System.Drawing.Point(74, 62);
		this.m_SharedParameterFileTextBox.Name = "m_SharedParameterFileTextBox";
		this.m_SharedParameterFileTextBox.Size = new System.Drawing.Size(392, 20);
		this.m_SharedParameterFileTextBox.TabIndex = 2;
		this.m_SharedParameterFileButton.Location = new System.Drawing.Point(472, 62);
		this.m_SharedParameterFileButton.Name = "m_SharedParameterFileButton";
		this.m_SharedParameterFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_SharedParameterFileButton.TabIndex = 3;
		this.m_SharedParameterFileButton.Text = "...";
		this.m_SharedParameterFileButton.UseVisualStyleBackColor = true;
		this.m_SharedParameterFileButton.Click += new System.EventHandler(this.OnSharedParameterFileButtonClick);
		this.m_SharedParameterFileLabel.AutoSize = true;
		this.m_SharedParameterFileLabel.Location = new System.Drawing.Point(10, 65);
		this.m_SharedParameterFileLabel.Name = "m_SharedParameterFileLabel";
		this.m_SharedParameterFileLabel.Size = new System.Drawing.Size(23, 13);
		this.m_SharedParameterFileLabel.TabIndex = 1;
		this.m_SharedParameterFileLabel.Text = "File";
		this.m_SharedParameterWarningTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
		this.m_SharedParameterWarningTextBox.Location = new System.Drawing.Point(13, 13);
		this.m_SharedParameterWarningTextBox.Multiline = true;
		this.m_SharedParameterWarningTextBox.Name = "m_SharedParameterWarningTextBox";
		this.m_SharedParameterWarningTextBox.ReadOnly = true;
		this.m_SharedParameterWarningTextBox.Size = new System.Drawing.Size(483, 43);
		this.m_SharedParameterWarningTextBox.TabIndex = 0;
		this.m_SharedParameterWarningTextBox.TabStop = false;
		this.m_CancelButton.Location = new System.Drawing.Point(421, 88);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 5;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelClick);
		this.m_OKButton.Location = new System.Drawing.Point(340, 88);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 4;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(508, 119);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_OKButton);
		base.Controls.Add(this.m_SharedParameterWarningTextBox);
		base.Controls.Add(this.m_SharedParameterFileTextBox);
		base.Controls.Add(this.m_SharedParameterFileButton);
		base.Controls.Add(this.m_SharedParameterFileLabel);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		base.Name = "SharedParametersFilenameForm";
		this.Text = "Create Shared Parameters File";
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_OKButton;
		base.CancelButton = this.m_CancelButton;
	}
}
