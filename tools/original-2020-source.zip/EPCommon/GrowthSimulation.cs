﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.GrowthSimulation
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class GrowthSimulation
{
  private Application m_CurApplication;
  private Document m_Document;
  private GrowthSimulationForm m_DisplayForm;
  private List<FamilySymbolContainer> m_ExistingPlantSymbolList;
  private bool m_bShowUI = true;
  private FormatOptions m_LengthFormatOptions;
  private EPTransactionContainer m_TransactionContainer;
  private List<Element> m_CurrentElementList;

  public GrowthSimulation(Document _CurDocument)
  {
    this.m_CurApplication = _CurDocument.Application;
    this.m_ExistingPlantSymbolList = new List<FamilySymbolContainer>();
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_LengthFormatOptions = this.m_Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.InitializeListData();
  }

  private void InitializeListData() => this.PopulateExistingPlantList();

  private void PopulateExistingPlantList()
  {
    IList<Element> elements = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements();
    this.m_CurrentElementList = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements().ToList<Element>();
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag = false;
    foreach (Element element in (IEnumerable<Element>) elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        flag = true;
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          this.UpdateFamilySymbolContainerList(familyInstance.Symbol);
        }
      }
    }
    this.m_TransactionContainer.Rollback();
    if (this.m_ExistingPlantSymbolList.Count > 0)
      return;
    if (!flag)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("GrowthSimulationNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    else
    {
      int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("GrowthSimulationNoLandCaddFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    this.m_bShowUI = false;
  }

  private void UpdateFamilySymbolContainerList(FamilySymbol _SelectedSymbol)
  {
    FamilySymbolContainer familySymbolContainer = new FamilySymbolContainer();
    for (int index = 0; index < this.m_ExistingPlantSymbolList.Count; ++index)
    {
      if (string.Compare(((Element) this.m_ExistingPlantSymbolList[index].FamilySymbol).Name, ((Element) _SelectedSymbol).Name, true) == 0)
        return;
    }
    familySymbolContainer.FamilySymbol = _SelectedSymbol;
    Parameter parameter1 = ((Element) _SelectedSymbol).LookupParameter(RevitParameters.GrowthServiceLifePlantFamilyParameter);
    familySymbolContainer.ServiceLife = parameter1 == null ? EPShared.LocalRM.GetString("NotAvailableString") : (!string.IsNullOrEmpty(parameter1.AsString()) ? parameter1.AsString() : EPShared.LocalRM.GetString("NotAvailableString"));
    bool flag1 = false;
    bool flag2 = false;
    Eps_Point _SecondCheckPnt = new Eps_Point();
    List<Eps_Point> _PointList = (List<Eps_Point>) null;
    foreach (Element currentElement in this.m_CurrentElementList)
    {
      if (currentElement is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) _SelectedSymbol).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
      {
        if (_PointList == null)
          _PointList = new List<Eps_Point>();
        Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
          _PointList.Add(_FindPoint);
      }
    }
    if (_PointList != null && _PointList.Count > 0)
    {
      bool flag3 = true;
      while (flag3)
      {
        flag3 = false;
        for (int index = 0; index < _PointList.Count; ++index)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index], _SecondCheckPnt))
          {
            ++_SecondCheckPnt.z;
            flag3 = true;
            break;
          }
        }
      }
    }
    FamilyInstance familyInstance1 = RevitUtility.NewFamilyInstance(this.m_Document, _SecondCheckPnt.XYZ, _SelectedSymbol, (Element) null, this.m_Document.ActiveView.GenLevel, (StructuralType) 0, ref this.m_TransactionContainer);
    if (familyInstance1 != null)
    {
      Parameter parameter2 = ((Element) familyInstance1).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
      if (parameter2 != null)
      {
        double _dValue = parameter2.AsDouble();
        familySymbolContainer.MaxHeight = ValueConversion.ToString(_dValue);
        flag1 = true;
      }
      else
        familySymbolContainer.MaxHeight = EPShared.LocalRM.GetString("NotAvailableString");
      Parameter parameter3 = ((Element) familyInstance1).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
      if (parameter3 != null)
      {
        double _dValue = parameter3.AsDouble();
        familySymbolContainer.MaxWidth = ValueConversion.ToString(_dValue);
        flag2 = true;
      }
      else
        familySymbolContainer.MaxWidth = EPShared.LocalRM.GetString("NotAvailableString");
    }
    else
    {
      Parameter parameter4 = ((Element) _SelectedSymbol)[(BuiltInParameter) -1005193];
      if (parameter4 != null)
      {
        double _dValue = parameter4.AsDouble();
        familySymbolContainer.MaxHeight = ValueConversion.ToString(_dValue);
      }
      else
        familySymbolContainer.MaxHeight = EPShared.LocalRM.GetString("NotAvailableString");
    }
    if (flag1 || flag2)
      this.m_ExistingPlantSymbolList.Add(familySymbolContainer);
    this.m_TransactionContainer.BeginTransaction();
    this.m_Document.Delete(((Element) familyInstance1).Id);
    this.m_TransactionContainer.EndTransaction();
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    if (!this.m_bShowUI)
      return this.m_bShowUI;
    bool flag = false;
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_DisplayForm = new GrowthSimulationForm(this))
    {
      while (_DialogResult != DialogResult.Cancel)
      {
        flag = this.ShowDialog(ref _DialogResult);
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    return flag;
  }

  private bool GetFindSymbol()
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString(EPShared.LocalRM.GetString("PickPlantMessage")), ref _Elements, true) || _Elements == null)
      return false;
    foreach (Element element in _Elements)
    {
      if (!(element is FamilyInstance familyInstance) || familyInstance.Symbol == null || ((Element) familyInstance.Symbol).Category == null || ((Element) familyInstance.Symbol).Category.Id.IntegerValue != ((BuiltInCategory) -2001360).GetHashCode())
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    return true;
  }

  private bool GetSinglePoint(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
      return false;
    foreach (Element element in _Elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
      }
      else
      {
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportedForPlantsMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    return true;
  }

  private bool GetWindowPoints(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
      return false;
    foreach (Element element in _Elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
      }
    }
    return true;
  }

  private bool GetAllPointsWithType(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    IList<Element> elements = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements();
    if (elements == null || elements.Count == 0)
      return false;
    foreach (Element element in (IEnumerable<Element>) elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
      }
    }
    return true;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    int num = (int) this.m_DisplayForm.ShowDialog();
    _DialogResult = this.m_DisplayForm.DialogResult;
    bool flag;
    if (_DialogResult == DialogResult.Cancel)
      flag = false;
    else if (_DialogResult == DialogResult.Retry)
    {
      flag = this.GetFindSymbol();
    }
    else
    {
      this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GrowthSimulationTransaction"));
      if (this.m_DisplayForm.FamilySymbolLocalList.Count <= 0)
        return false;
      ElementSet _InstanceSet = new ElementSet();
      List<Eps_Point> _PointList = new List<Eps_Point>();
      if (this.m_DisplayForm.SelectionSetChecked)
      {
        if (!this.GetSinglePoint(ref _InstanceSet, ref _PointList))
          return false;
      }
      else if (this.m_DisplayForm.WindowSelectChecked)
      {
        if (!this.GetWindowPoints(ref _InstanceSet, ref _PointList))
          return false;
      }
      else if (this.m_DisplayForm.AllInstancesChecked && !this.GetAllPointsWithType(ref _InstanceSet, ref _PointList))
        return false;
      flag = this.UpdateDocument(_InstanceSet);
    }
    return flag;
  }

  private bool UpdateDocument(ElementSet _InstanceSet)
  {
    List<FamilySymbolContainer> familySymbolContainerList = new List<FamilySymbolContainer>();
    List<FamilySymbolContainer> familySymbolLocalList = this.m_DisplayForm.FamilySymbolLocalList;
    if (familySymbolLocalList.Count <= 0)
      return false;
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _InstanceSet.Size;
    if (_InstanceSet.Size <= 0)
      progressBarForm.MaxValue = 10000;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarGrowingPlantsMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    this.m_TransactionContainer.BeginTransaction();
    foreach (Element instance in _InstanceSet)
    {
      FamilyInstance familyInstance = instance as FamilyInstance;
      double num1 = -1.0;
      double num2 = 0.0;
      if (familyInstance != null)
      {
        for (int index = 0; index < familySymbolLocalList.Count; ++index)
        {
          if (string.Compare(((Element) familyInstance.Symbol).Name, ((Element) familySymbolLocalList[index].FamilySymbol).Name, true) == 0)
          {
            Parameter parameter1 = ((Element) familyInstance.Symbol).LookupParameter(RevitParameters.GrowthServiceLifePlantFamilyParameter);
            bool flag;
            if (parameter1 != null && string.Compare(familySymbolLocalList[index].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
            {
              parameter1.Set(Convert.ToInt32(familySymbolLocalList[index].ServiceLife));
              num1 = ValueConversion.ToDouble(familySymbolLocalList[index].ServiceLife);
              flag = true;
            }
            else if (string.Compare(familySymbolLocalList[index].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
            {
              num1 = ValueConversion.ToDouble(familySymbolLocalList[index].ServiceLife);
              flag = true;
            }
            else
              flag = false;
            if (this.m_DisplayForm.Age > num1 || !flag)
            {
              Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
              if (parameter2 != null && string.Compare(familySymbolLocalList[index].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
              {
                double num3 = ValueConversion.ToDouble(familySymbolLocalList[index].MaxHeight);
                parameter2.Set(num3);
              }
              Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
              if (parameter3 != null && string.Compare(familySymbolLocalList[index].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
              {
                num2 = ValueConversion.ToDouble(familySymbolLocalList[index].MaxWidth);
                parameter3.Set(ValueConversion.ToDouble(familySymbolLocalList[index].MaxWidth));
              }
            }
            else
            {
              Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
              if (parameter4 != null && string.Compare(familySymbolLocalList[index].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
              {
                double num4 = ValueConversion.ToDouble(familySymbolLocalList[index].MaxHeight) * this.m_DisplayForm.Age / num1;
                parameter4.Set(num4);
              }
              Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
              if (parameter5 != null && string.Compare(familySymbolLocalList[index].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
              {
                double num5 = ValueConversion.ToDouble(familySymbolLocalList[index].MaxWidth) * this.m_DisplayForm.Age / num1;
                parameter5.Set(num5);
              }
            }
          }
        }
      }
      progressBarForm.UpdateProgressBar(1);
    }
    this.m_TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  public Document Document => this.m_Document;

  public List<FamilySymbolContainer> ExistingPlantSymbolList
  {
    get => this.m_ExistingPlantSymbolList;
    set => this.m_ExistingPlantSymbolList = value;
  }

  public EPTransactionContainer TransactionContainer => this.m_TransactionContainer;
}
