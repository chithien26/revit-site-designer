﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantFieldsForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantFieldsForm : EPForm
{
  private bool m_bIsDisplayFields;
  private string m_strSettingValue = string.Empty;
  private IContainer components;
  private ListBox m_ExistingFieldsListBox;
  private ListBox m_OrderedFieldsListBox;
  private Button m_MoveUpButton;
  private Button m_MoveDownButton;
  private Button m_AddAllButton;
  private Button m_AddButton;
  private Button m_RemoveButton;
  private Button m_RemoveAllButton;
  private Button m_OKButton;
  private Button m_CancelButton;
  private Label m_AvailableParametersLabel;
  private Label m_ParametersUsedLabel;

  public PlantFieldsForm(bool _bIsDisplayFields, string _strSettingValue)
  {
    this.InitializeComponent();
    this.m_bIsDisplayFields = _bIsDisplayFields;
    this.m_strSettingValue = _strSettingValue;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    List<string> stringList = !this.m_bIsDisplayFields ? ManagePlants.PlantSharedParamenterList() : ManagePlants.PlantAllParamenterList();
    for (int index = 0; index < stringList.Count; ++index)
    {
      if (string.Compare(stringList[index], EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), true) != 0)
        this.m_ExistingFieldsListBox.Items.Add((object) stringList[index]);
    }
    if (this.m_bIsDisplayFields)
      this.Text = EPShared.LocalRM.GetString("ColumnDisplayFormDialog");
    else
      this.Text = EPShared.LocalRM.GetString("DestinationPlantFamilyParametersFormDialog");
    this.m_AvailableParametersLabel.Text = EPShared.LocalRM.GetString("AvailableParametersDialog");
    this.m_ParametersUsedLabel.Text = EPShared.LocalRM.GetString("ParametersUsedDialog");
    this.m_AddAllButton.Text = EPShared.LocalRM.GetString("AMP_AddAllDialog");
    this.m_AddButton.Text = EPShared.LocalRM.GetString("A_AMP_ddDialog");
    this.m_RemoveButton.Text = EPShared.LocalRM.GetString("AMP_RemoveDialog");
    this.m_RemoveAllButton.Text = EPShared.LocalRM.GetString("R_AMP_emoveAllDialog");
    this.m_MoveUpButton.Text = EPShared.LocalRM.GetString("AMP_MoveUpDialog");
    this.m_MoveDownButton.Text = EPShared.LocalRM.GetString("Mo_AMP_veDownDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.GetDialogPosition();
    List<ParameterColumn> parameterList = ManagePlants.GetParameterList(this.m_strSettingValue);
    string empty = string.Empty;
    for (int index1 = 0; index1 < parameterList.Count; ++index1)
    {
      string plantParamenterName = ManagePlants.GetPlantParamenterName(parameterList[index1].PlantField);
      this.m_OrderedFieldsListBox.Items.Add((object) plantParamenterName);
      int index2 = this.m_ExistingFieldsListBox.Items.IndexOf((object) plantParamenterName);
      if (index2 >= 0 && index2 < this.m_ExistingFieldsListBox.Items.Count)
        this.m_ExistingFieldsListBox.Items.RemoveAt(index2);
    }
  }

  private void SaveSettings()
  {
    for (int index = 0; index < this.m_OrderedFieldsListBox.Items.Count; ++index)
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingValue + ManagePlants.GetPlantFieldFromParamenter((string) this.m_OrderedFieldsListBox.Items[index]).ToString() + EPShared.LocalRM.GetString("ColumnOrderString"), index + 1);
    for (int index = 0; index < this.m_ExistingFieldsListBox.Items.Count; ++index)
      ApplicationUtility.Settings.eplSetE_DeleteIntegerSetting(this.m_strSettingValue + ManagePlants.GetPlantFieldFromParamenter((string) this.m_ExistingFieldsListBox.Items[index]).ToString() + EPShared.LocalRM.GetString("ColumnOrderString"));
  }

  private void OnAddAllButtonClick(object sender, EventArgs e)
  {
    this.m_ExistingFieldsListBox.Items.Clear();
    this.m_OrderedFieldsListBox.Items.Clear();
    List<string> stringList = !this.m_bIsDisplayFields ? ManagePlants.PlantSharedParamenterList() : ManagePlants.PlantAllParamenterList();
    for (int index = 0; index < stringList.Count; ++index)
    {
      if (string.Compare(stringList[index], EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), true) != 0)
        this.m_OrderedFieldsListBox.Items.Add((object) stringList[index]);
    }
  }

  private void OnAddButtonClick(object sender, EventArgs e)
  {
    int count;
    if ((count = this.m_ExistingFieldsListBox.SelectedItems.Count) < 1)
      return;
    for (int index = 0; index < count; ++index)
      this.m_OrderedFieldsListBox.Items.Add(this.m_ExistingFieldsListBox.SelectedItems[index]);
    for (int index = count - 1; index >= 0; --index)
      this.m_ExistingFieldsListBox.Items.RemoveAt(this.m_ExistingFieldsListBox.SelectedIndices[index]);
  }

  private void OnRemoveButtonClick(object sender, EventArgs e)
  {
    int count;
    if ((count = this.m_OrderedFieldsListBox.SelectedItems.Count) < 1)
      return;
    for (int index = 0; index < count; ++index)
      this.m_ExistingFieldsListBox.Items.Add(this.m_OrderedFieldsListBox.SelectedItems[index]);
    for (int index = count - 1; index >= 0; --index)
      this.m_OrderedFieldsListBox.Items.RemoveAt(this.m_OrderedFieldsListBox.SelectedIndices[index]);
  }

  private void OnRemoveAllButtonClick(object sender, EventArgs e)
  {
    this.m_ExistingFieldsListBox.Items.Clear();
    this.m_OrderedFieldsListBox.Items.Clear();
    List<string> stringList = !this.m_bIsDisplayFields ? ManagePlants.PlantSharedParamenterList() : ManagePlants.PlantAllParamenterList();
    for (int index = 0; index < stringList.Count; ++index)
    {
      if (string.Compare(stringList[index], EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), true) != 0 && string.Compare(stringList[index], EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), true) != 0)
        this.m_ExistingFieldsListBox.Items.Add((object) stringList[index]);
    }
  }

  private void OnMoveUpButtonClick(object sender, EventArgs e)
  {
    if (this.m_OrderedFieldsListBox.SelectedIndex <= 0)
      return;
    string str = (string) this.m_OrderedFieldsListBox.Items[this.m_OrderedFieldsListBox.SelectedIndex - 1];
    int selectedIndex = this.m_OrderedFieldsListBox.SelectedIndex;
    this.m_OrderedFieldsListBox.Items.RemoveAt(selectedIndex - 1);
    this.m_OrderedFieldsListBox.Items.Insert(selectedIndex, (object) str);
  }

  private void OnMoveDownButtonClick(object sender, EventArgs e)
  {
    if (this.m_OrderedFieldsListBox.SelectedIndex >= this.m_OrderedFieldsListBox.Items.Count - 1)
      return;
    string str = (string) this.m_OrderedFieldsListBox.Items[this.m_OrderedFieldsListBox.SelectedIndex + 1];
    int selectedIndex = this.m_OrderedFieldsListBox.SelectedIndex;
    this.m_OrderedFieldsListBox.Items.RemoveAt(selectedIndex + 1);
    this.m_OrderedFieldsListBox.Items.Insert(selectedIndex, (object) str);
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnPlantFieldsFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ExistingFieldsListBox = new ListBox();
    this.m_OrderedFieldsListBox = new ListBox();
    this.m_MoveUpButton = new Button();
    this.m_MoveDownButton = new Button();
    this.m_AddAllButton = new Button();
    this.m_AddButton = new Button();
    this.m_RemoveButton = new Button();
    this.m_RemoveAllButton = new Button();
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_AvailableParametersLabel = new Label();
    this.m_ParametersUsedLabel = new Label();
    this.SuspendLayout();
    this.m_ExistingFieldsListBox.FormattingEnabled = true;
    this.m_ExistingFieldsListBox.Location = new Point(14, 27);
    this.m_ExistingFieldsListBox.Name = "m_ExistingFieldsListBox";
    this.m_ExistingFieldsListBox.SelectionMode = SelectionMode.MultiExtended;
    this.m_ExistingFieldsListBox.Size = new Size(206, 290);
    this.m_ExistingFieldsListBox.Sorted = true;
    this.m_ExistingFieldsListBox.TabIndex = 2;
    this.m_OrderedFieldsListBox.FormattingEnabled = true;
    this.m_OrderedFieldsListBox.Location = new Point(332, 27);
    this.m_OrderedFieldsListBox.Name = "m_OrderedFieldsListBox";
    this.m_OrderedFieldsListBox.SelectionMode = SelectionMode.MultiExtended;
    this.m_OrderedFieldsListBox.Size = new Size(206, 290);
    this.m_OrderedFieldsListBox.TabIndex = 7;
    this.m_MoveUpButton.Location = new Point(332, 323);
    this.m_MoveUpButton.Name = "m_MoveUpButton";
    this.m_MoveUpButton.Size = new Size(100, 23);
    this.m_MoveUpButton.TabIndex = 8;
    this.m_MoveUpButton.Text = "&Move Up";
    this.m_MoveUpButton.UseVisualStyleBackColor = true;
    this.m_MoveUpButton.Click += new EventHandler(this.OnMoveUpButtonClick);
    this.m_MoveDownButton.Location = new Point(438, 323);
    this.m_MoveDownButton.Name = "m_MoveDownButton";
    this.m_MoveDownButton.Size = new Size(100, 23);
    this.m_MoveDownButton.TabIndex = 9;
    this.m_MoveDownButton.Text = "Mo&ve Down";
    this.m_MoveDownButton.UseVisualStyleBackColor = true;
    this.m_MoveDownButton.Click += new EventHandler(this.OnMoveDownButtonClick);
    this.m_AddAllButton.Location = new Point(226, 64 /*0x40*/);
    this.m_AddAllButton.Name = "m_AddAllButton";
    this.m_AddAllButton.Size = new Size(100, 23);
    this.m_AddAllButton.TabIndex = 3;
    this.m_AddAllButton.Text = "&Add All >>>";
    this.m_AddAllButton.UseVisualStyleBackColor = true;
    this.m_AddAllButton.Click += new EventHandler(this.OnAddAllButtonClick);
    this.m_AddButton.Location = new Point(226, 93);
    this.m_AddButton.Name = "m_AddButton";
    this.m_AddButton.Size = new Size(100, 23);
    this.m_AddButton.TabIndex = 4;
    this.m_AddButton.Text = "A&dd -->";
    this.m_AddButton.UseVisualStyleBackColor = true;
    this.m_AddButton.Click += new EventHandler(this.OnAddButtonClick);
    this.m_RemoveButton.Location = new Point(226, 214);
    this.m_RemoveButton.Name = "m_RemoveButton";
    this.m_RemoveButton.Size = new Size(100, 23);
    this.m_RemoveButton.TabIndex = 5;
    this.m_RemoveButton.Text = "<-- &Remove";
    this.m_RemoveButton.UseVisualStyleBackColor = true;
    this.m_RemoveButton.Click += new EventHandler(this.OnRemoveButtonClick);
    this.m_RemoveAllButton.Location = new Point(226, 243);
    this.m_RemoveAllButton.Name = "m_RemoveAllButton";
    this.m_RemoveAllButton.Size = new Size(100, 23);
    this.m_RemoveAllButton.TabIndex = 6;
    this.m_RemoveAllButton.Text = "<<< R&emove All";
    this.m_RemoveAllButton.UseVisualStyleBackColor = true;
    this.m_RemoveAllButton.Click += new EventHandler(this.OnRemoveAllButtonClick);
    this.m_OKButton.Location = new Point(382, 352);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 10;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(463, 352);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 11;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_AvailableParametersLabel.AutoSize = true;
    this.m_AvailableParametersLabel.Location = new Point(12, 9);
    this.m_AvailableParametersLabel.Name = "m_AvailableParametersLabel";
    this.m_AvailableParametersLabel.Size = new Size(106, 13);
    this.m_AvailableParametersLabel.TabIndex = 0;
    this.m_AvailableParametersLabel.Text = "Available Parameters";
    this.m_ParametersUsedLabel.AutoSize = true;
    this.m_ParametersUsedLabel.Location = new Point(329, 9);
    this.m_ParametersUsedLabel.Name = "m_ParametersUsedLabel";
    this.m_ParametersUsedLabel.Size = new Size(88, 13);
    this.m_ParametersUsedLabel.TabIndex = 1;
    this.m_ParametersUsedLabel.Text = "Parameters Used";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(550, 387);
    this.Controls.Add((Control) this.m_ParametersUsedLabel);
    this.Controls.Add((Control) this.m_AvailableParametersLabel);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_RemoveAllButton);
    this.Controls.Add((Control) this.m_RemoveButton);
    this.Controls.Add((Control) this.m_AddButton);
    this.Controls.Add((Control) this.m_AddAllButton);
    this.Controls.Add((Control) this.m_MoveDownButton);
    this.Controls.Add((Control) this.m_MoveUpButton);
    this.Controls.Add((Control) this.m_OrderedFieldsListBox);
    this.Controls.Add((Control) this.m_ExistingFieldsListBox);
    this.Name = nameof (PlantFieldsForm);
    this.Text = "Plant Parameters";
    this.FormClosing += new FormClosingEventHandler(this.OnPlantFieldsFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
