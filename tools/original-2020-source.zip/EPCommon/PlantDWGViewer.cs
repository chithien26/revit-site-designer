﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantDWGViewer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantDWGViewer
{
  private Element m_selected;
  private View m_currentView;
  private ViewDetailLevel m_detailLevel = (ViewDetailLevel) 3;
  private Sketch3D m_currentSketch3D;
  private bool m_isSelectView = true;
  private Document m_CurDocument;
  private EPTransactionContainer m_TransactionContainer;

  public ViewDetailLevel DetailLevel
  {
    get => this.m_detailLevel;
    set
    {
      this.m_detailLevel = value;
      this.m_isSelectView = false;
      this.UpdateSketch3D();
    }
  }

  public Sketch3D CurrentSketch3D => this.m_currentSketch3D;

  public Document CurDocument => this.m_CurDocument;

  public EPTransactionContainer TransactionContainer => this.m_TransactionContainer;

  public PlantDWGViewer(Document _CurDocument, EPTransactionContainer _TransactionContainer)
  {
    this.m_CurDocument = _CurDocument;
    this.m_TransactionContainer = _TransactionContainer;
  }

  private void UpdateSketch3D()
  {
    GeometryData geometryData;
    if (this.m_isSelectView)
    {
      geometryData = new GeometryData(this.m_CurDocument.Application, this.m_selected, this.m_currentView);
      this.m_detailLevel = (ViewDetailLevel) 0;
    }
    else
      geometryData = new GeometryData(this.m_CurDocument.Application, this.m_selected, this.m_detailLevel, this.m_currentView);
    Graphics3DData data3D1 = geometryData.Data3D;
    Graphics3DData data3D2 = this.m_currentSketch3D.Data3D;
    data3D1.CurrentUCS = data3D2.CurrentUCS;
    this.m_currentSketch3D.Data3D = data3D1;
  }

  public bool SetupPreview(string _strDrawingName)
  {
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ObtainDrawingImageTransaction"));
    this.DeleteSelected();
    Document curDocument = this.m_CurDocument;
    DWGImportOptions dwgImportOptions = new DWGImportOptions();
    ((BaseImportOptions) dwgImportOptions).ColorMode = (ImportColorMode) 0;
    ((BaseImportOptions) dwgImportOptions).CustomScale = 0.0;
    ((BaseImportOptions) dwgImportOptions).OrientToView = true;
    ((BaseImportOptions) dwgImportOptions).Placement = (ImportPlacement) 1;
    ((BaseImportOptions) dwgImportOptions).ThisViewOnly = false;
    ((BaseImportOptions) dwgImportOptions).Unit = (ImportUnit) 1;
    ((BaseImportOptions) dwgImportOptions).VisibleLayersOnly = false;
    ElementId elementId = (ElementId) null;
    curDocument.Import(_strDrawingName, dwgImportOptions, curDocument.ActiveView, ref elementId);
    this.m_selected = curDocument.GetElement(elementId);
    ElementSet elm_set = new ElementSet();
    elm_set.Insert(this.m_selected);
    try
    {
      curDocument.ActiveView.HideElements((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
      this.m_TransactionContainer.Commit();
    }
    catch (ArgumentException ex)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("CannotImport_String") + Path.GetFileName(_strDrawingName) + EPShared.LocalRM.GetString("_InSettingString"), EPShared.LocalRM.GetString("ImportString"), MessageBoxIcon.Exclamation);
      this.DeleteSelected();
      this.m_TransactionContainer.Commit();
      this.m_currentSketch3D = (Sketch3D) null;
      return false;
    }
    this.m_currentView = curDocument.ActiveView;
    this.m_currentSketch3D = new Sketch3D(new GeometryData(this.m_CurDocument.Application, this.m_selected, this.m_currentView).Data3D);
    return true;
  }

  public void DeleteSelected()
  {
    if (this.m_selected == null)
      return;
    this.m_TransactionContainer.BeginTransaction();
    this.m_CurDocument.Delete(this.m_selected.Id);
    this.m_TransactionContainer.EndTransaction();
  }
}
