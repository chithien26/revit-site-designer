﻿// Decompiled with JetBrains decompiler
// Type: SITES.Sites_Core.Resources
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace SITES.Sites_Core;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
public class Resources
{
  private static ResourceManager resourceMan;
  private static CultureInfo resourceCulture;

  internal Resources()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  public static ResourceManager ResourceManager
  {
    get
    {
      if (SITES.Sites_Core.Resources.resourceMan == null)
        SITES.Sites_Core.Resources.resourceMan = new ResourceManager("SITES.Sites_Core.Resources", typeof (SITES.Sites_Core.Resources).Assembly);
      return SITES.Sites_Core.Resources.resourceMan;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  public static CultureInfo Culture
  {
    get => SITES.Sites_Core.Resources.resourceCulture;
    set => SITES.Sites_Core.Resources.resourceCulture = value;
  }

  public static Bitmap About
  {
    get => (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (About), SITES.Sites_Core.Resources.resourceCulture);
  }

  public static Bitmap Annotate
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (Annotate), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap AssignPatioWalk
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (AssignPatioWalk), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap AssignPlantMix
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (AssignPlantMix), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap BorrowLicense
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (BorrowLicense), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ConvertPlants
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ConvertPlants), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap CurbFamilyManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (CurbFamilyManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap CurbInfo
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (CurbInfo), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ExportLandXML
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ExportLandXML), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap GrowthSimulation
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (GrowthSimulation), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ImportLandXML
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ImportLandXML), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Icon lc4revit
  {
    get => (Icon) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (lc4revit), SITES.Sites_Core.Resources.resourceCulture);
  }

  public static Bitmap LocateComponents
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateComponents), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateCurb
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateCurb), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateFeatureLine
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateFeatureLine), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateFence
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateFence), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateParkingLot
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateParkingLot), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocatePlants
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocatePlants), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocatePointWipeout
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocatePointWipeout), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateRetainingWall
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateRetainingWall), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateSidewalk
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateSidewalk), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateSoftTerrain
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateSoftTerrain), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap LocateStreet
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (LocateStreet), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ManageLicense
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ManageLicense), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyCurb
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyCurb), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyFeatureLine
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyFeatureLine), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyParkingLot
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyParkingLot), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyPlants
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyPlants), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyPointWipeout
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyPointWipeout), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyRetainingWall
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyRetainingWall), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifySidewalk
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifySidewalk), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifySoftTerrain
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifySoftTerrain), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ModifyStreet
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ModifyStreet), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ParkingLot
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ParkingLot), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ParkingLotFamilyManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ParkingLotFamilyManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ParkingLotInfo
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ParkingLotInfo), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PatioWalkManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PatioWalkManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PatioWalkReport
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PatioWalkReport), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PickElevation
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PickElevation), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PlantBooklet
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PlantBooklet), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PlantFamilyManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PlantFamilyManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PlantMixManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PlantMixManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap PlantMixReport
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (PlantMixReport), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap Report
  {
    get => (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (Report), SITES.Sites_Core.Resources.resourceCulture);
  }

  public static Bitmap RetainingWallFamilyManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (RetainingWallFamilyManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap RetainingWallInfo
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (RetainingWallInfo), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ReturnLicense
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ReturnLicense), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap SetBaseToposurface
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (SetBaseToposurface), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap Settings
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (Settings), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap SidewalkFamilyManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (SidewalkFamilyManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap SidewalkInfo
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (SidewalkInfo), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap SitesReport
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (SitesReport), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Icon Siteworks
  {
    get
    {
      return (Icon) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (Siteworks), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap SoftTerrainInfo
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (SoftTerrainInfo), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap SoftTerrainManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (SoftTerrainManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap StreetFamilyManager
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (StreetFamilyManager), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap StreetInfo
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (StreetInfo), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static string String1
  {
    get => SITES.Sites_Core.Resources.ResourceManager.GetString(nameof (String1), SITES.Sites_Core.Resources.resourceCulture);
  }

  public static Bitmap tooltip_curb
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_curb), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_feature_line
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_feature_line), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_parking_lot
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_parking_lot), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_point_wipeout
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_point_wipeout), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_retaining_wall
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_retaining_wall), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_sidewalk
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_sidewalk), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_soft_terrain
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_soft_terrain), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap tooltip_street
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (tooltip_street), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap ToposurfaceConversion
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (ToposurfaceConversion), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap UserLog
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (UserLog), SITES.Sites_Core.Resources.resourceCulture);
    }
  }

  public static Bitmap UserLog1
  {
    get
    {
      return (Bitmap) SITES.Sites_Core.Resources.ResourceManager.GetObject(nameof (UserLog1), SITES.Sites_Core.Resources.resourceCulture);
    }
  }
}
