﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.MeshTriangleLineComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class MeshTriangleLineComparer : IComparer<MeshTriangleLine>
{
  private bool m_bSortByStartNumber = true;

  int IComparer<MeshTriangleLine>.Compare(MeshTriangleLine first, MeshTriangleLine second)
  {
    int num = 0;
    if (this.m_bSortByStartNumber)
    {
      if (first != null)
        num = second == null ? -1 : first.LineStartNumber.CompareTo(second.LineStartNumber);
      else if (second != null)
        num = 1;
    }
    return num;
  }
}
