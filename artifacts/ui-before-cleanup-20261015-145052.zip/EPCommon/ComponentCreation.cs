using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;

namespace EPCommon;

public class ComponentCreation
{
	private Document m_Document;

	private List<Autodesk.Revit.DB.View> m_ViewList;

	private LocateComponentsForm m_DisplayForm;

	private List<TopographySurfaceContainer> m_SurfaceList;

	private List<FamilyContainer> m_FamilyList;

	private List<BuiltInCategory> m_CategoryList;

	private ProgressBarForm m_ProgressFrm;

	private bool m_bShowUI = true;

	private EPTransactionContainer m_TransactionContainer;

	private FamilySymbol m_PlacementSymbol;

	public ReadOnlyCollection<Autodesk.Revit.DB.View> Views => new ReadOnlyCollection<Autodesk.Revit.DB.View>(m_ViewList);

	public Document Document => m_Document;

	public ReadOnlyCollection<FamilyContainer> FamilyList => new ReadOnlyCollection<FamilyContainer>(m_FamilyList);

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public ReadOnlyCollection<TopographySurfaceContainer> SurfaceList => new ReadOnlyCollection<TopographySurfaceContainer>(m_SurfaceList);

	public ComponentCreation(Document _CurDocument)
	{
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_ViewList = new List<Autodesk.Revit.DB.View>();
		m_SurfaceList = new List<TopographySurfaceContainer>();
		m_FamilyList = new List<FamilyContainer>();
		m_CategoryList = new List<BuiltInCategory>();
		m_CategoryList.Add(BuiltInCategory.OST_Site);
		m_CategoryList.Add(BuiltInCategory.OST_Entourage);
		m_CategoryList.Add(BuiltInCategory.OST_Furniture);
		m_CategoryList.Add(BuiltInCategory.OST_GenericModel);
		m_CategoryList.Add(BuiltInCategory.OST_ElectricalEquipment);
		m_CategoryList.Add(BuiltInCategory.OST_LightingFixtures);
		m_CategoryList.Add(BuiltInCategory.OST_Columns);
		InitializeListData();
	}

	public void PopulateFamilyAndSymbolLists()
	{
		int num = 0;
		m_FamilyList.Clear();
		FamilySymbol familySymbol = null;
		FilteredElementCollector filteredElementCollector;
		List<Element> list;
		for (int i = 0; i < m_CategoryList.Count; i++)
		{
			filteredElementCollector = new FilteredElementCollector(m_Document);
			filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(m_CategoryList.ElementAt(i));
			if (m_CategoryList.ElementAt(i) == BuiltInCategory.OST_GenericModel)
			{
				IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => CurrentElement.GetParameters(RevitParameters.LandcaddIDGenericModelFamilyParameter).FirstOrDefault() != null);
				list = source.ToList();
			}
			else if (m_CategoryList.ElementAt(i) == BuiltInCategory.OST_Site)
			{
				IEnumerable<Element> source2 = filteredElementCollector.Where((Element CurrentElement) => CurrentElement.GetParameters(RevitParameters.SiteworksIDFamilyParameter).FirstOrDefault() == null);
				list = source2.ToList();
			}
			else
			{
				list = filteredElementCollector.ToList();
			}
			familySymbol = null;
			foreach (Element item in list)
			{
				if (!(item is FamilySymbol { Category: not null } familySymbol2) || familySymbol2.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter) != null)
				{
					continue;
				}
				bool flag = false;
				for (num = 0; num < m_FamilyList.Count; num++)
				{
					if (string.Compare(m_FamilyList[num].FamilyName, familySymbol2.Family.Name, ignoreCase: true) == 0)
					{
						m_FamilyList[num].FamilySymbolList.Add(familySymbol2);
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					FamilyContainer familyContainer = new FamilyContainer(familySymbol2.Family.Name);
					familyContainer.FamilySymbolList.Add(familySymbol2);
					m_FamilyList.Add(familyContainer);
				}
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel);
		Parameter CurLanddCadID = null;
		IEnumerable<Element> source3 = filteredElementCollector.Where((Element CurrentElement) => (CurLanddCadID = CurrentElement.GetParameters(RevitParameters.LandcaddIDGenericModelFamilyParameter).FirstOrDefault()) != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0);
		list = source3.ToList();
		bool flag2 = false;
		familySymbol = null;
		foreach (Element item2 in list)
		{
			if (item2 is FamilySymbol { Category: not null } familySymbol3)
			{
				CurLanddCadID = familySymbol3.GetParameters(RevitParameters.LandcaddIDGenericModelFamilyParameter).FirstOrDefault();
				if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0)
				{
					m_PlacementSymbol = familySymbol3;
					flag2 = true;
					break;
				}
			}
		}
		string _strFullFamilyFilename = string.Empty;
		if (!flag2)
		{
			List<string> list2 = new List<string>();
			list2.Add(EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"));
			list2.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, "LocateComponents", EPShared.LocalRM.GetString("PlacementFamilyNotLoadedMessage"), list2);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), ignoreCase: true) == 0)
			{
				Family _Family = null;
				if (!flag2 && RevitUtility.GetFullFamilyFilenameIfExist("LC Placement.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocatePlacementFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						using IEnumerator<ElementId> enumerator3 = _Family.GetFamilySymbolIds().GetEnumerator();
						if (enumerator3.MoveNext())
						{
							ElementId current3 = enumerator3.Current;
							m_PlacementSymbol = m_Document.GetElement(current3) as FamilySymbol;
						}
					}
				}
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		for (num = 0; num < m_FamilyList.Count; num++)
		{
			m_FamilyList[num].FamilySymbolList.Sort(comparer);
		}
	}

	private void InitializeListData()
	{
		PopulateFamilyAndSymbolLists();
		if (m_FamilyList.Count <= 0)
		{
			m_bShowUI = false;
			RevitMessageBox.Show(EPShared.LocalRM.GetString("LocateComponentsNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			return;
		}
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(Autodesk.Revit.DB.View)).ToElements();
		foreach (Autodesk.Revit.DB.View item in list)
		{
			if (item.GenLevel == null || m_ViewList.Contains(item) || (item.ViewType != ViewType.FloorPlan && item.ViewType != ViewType.CeilingPlan && item.ViewType != ViewType.EngineeringPlan && item.ViewType != ViewType.AreaPlan) || string.Compare(item.Name, EPShared.LocalRM.GetString("SiteString"), ignoreCase: true) == 0)
			{
				continue;
			}
			bool flag = false;
			for (int i = 0; i < m_ViewList.Count; i++)
			{
				if (m_ViewList[i].ViewType == item.ViewType && string.Compare(m_ViewList[i].GenLevel.UniqueId, item.GenLevel.UniqueId, ignoreCase: true) == 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				m_ViewList.Add(item);
			}
		}
		filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list2 = filteredElementCollector.OfClass(typeof(TopographySurface)).OfCategory(BuiltInCategory.OST_Topography).ToElements();
		foreach (Element item2 in list2)
		{
			TopographySurface topographySurface = item2 as TopographySurface;
			m_SurfaceList.Add(new TopographySurfaceContainer(m_Document.Application, topographySurface));
		}
	}

	private FamilyInstance PlaceSingleOnPoint(Eps_Point originPoint, List<TopographySurfaceContainer> _SurfaceList)
	{
		m_TransactionContainer.BeginTransaction();
		FamilyInstance result = RevitUtility.NewFamilyInstance(m_Document, originPoint.XY, m_DisplayForm.Type, RevitUtility.GetSurfaceContainingPoint(originPoint, _SurfaceList), m_DisplayForm.Level, StructuralType.NonStructural, ref m_TransactionContainer);
		m_TransactionContainer.EndTransaction();
		return result;
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		if (!m_bShowUI)
		{
			return m_bShowUI;
		}
		bool flag = false;
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new LocateComponentsForm(this))
		{
			while (_DialogResult == DialogResult.OK)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult != DialogResult.OK)
		{
			return false;
		}
		List<TopographySurfaceContainer> list = new List<TopographySurfaceContainer>();
		if (m_DisplayForm.PickToposurface)
		{
			list.Add(m_DisplayForm.Surface);
		}
		PlacementSettings placementSettings = new PlacementSettings(LocateType.Component, m_DisplayForm.PlacementType, m_DisplayForm.DeleteExistingChecked, m_DisplayForm.ExistingElementChecked, _bPlaceGroupTagChecked: false, m_DisplayForm.Level, m_DisplayForm.View, m_DisplayForm.Type, list, m_DisplayForm.SetbackSpacing, 0.0, 0.0, 0.0, 0.0, m_DisplayForm.ComponentSpacing, m_DisplayForm.RotationAngle, m_DisplayForm.StartingDistance, m_PlacementSymbol, m_TransactionContainer);
		placementSettings.AlignTo = m_DisplayForm.AlignTo;
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("LocateComponentsTransaction"));
		m_ProgressFrm = new ProgressBarForm();
		ElementSet _Elements = null;
		string strPrompt = string.Empty;
		if (!m_DisplayForm.ExistingElementChecked)
		{
			if (m_DisplayForm.GroveChecked)
			{
				strPrompt = EPShared.LocalRM.GetString("PickPointsForBoundaryPrompt");
			}
			else if (m_DisplayForm.HedgeRowChecked)
			{
				strPrompt = EPShared.LocalRM.GetString("PickStartPointPrompt");
			}
			ElementSet elementSet = new ElementSet();
			List<ModelCurve> list2 = new List<ModelCurve>();
			Eps_Leg eps_Leg = null;
			Eps_Leg eps_Leg2 = null;
			Eps_Point _Point = null;
			Eps_Point eps_Point = null;
			bool flag = true;
			while (flag)
			{
				flag = RevitUtility.GetPointFromProject(m_Document, strPrompt, ref _Point, _bDisplayError: false);
				if (flag)
				{
					if (eps_Point != null)
					{
						eps_Leg2 = new Eps_Leg();
						eps_Leg2.Line = new Eps_Line();
						eps_Leg2.Line.StartPnt = eps_Point;
						eps_Leg2.Line.EndPnt = _Point;
						if (eps_Leg == null)
						{
							eps_Leg = Eps_Leg.SingleLeg(eps_Leg2);
						}
						else
						{
							eps_Leg.Last.Next = Eps_Leg.SingleLeg(eps_Leg2);
						}
						m_TransactionContainer.BeginTransaction();
						list2.Add(RevitUtility.NewModelCurve(m_Document, eps_Leg2.Line));
						m_TransactionContainer.EndTransaction();
						if (m_DisplayForm.SegmentChecked)
						{
							flag = false;
						}
					}
					else if (m_DisplayForm.HedgeRowChecked)
					{
						strPrompt = EPShared.LocalRM.GetString("PickEndPointPrompt");
					}
					eps_Point = _Point;
				}
				m_Document.Regenerate();
			}
			if (eps_Leg != null && eps_Leg.Next != null && m_DisplayForm.GroveChecked && !EPShared.eplGeoE_ArePntsDuplicates2D(eps_Leg.LegStartPnt, eps_Leg.LegEndPnt, 1E-05))
			{
				eps_Leg2 = new Eps_Leg();
				eps_Leg2.Line = new Eps_Line();
				eps_Leg2.Line.StartPnt = eps_Leg.LegEndPnt;
				eps_Leg2.Line.EndPnt = eps_Leg.LegStartPnt;
				eps_Leg.Last.Next = Eps_Leg.SingleLeg(eps_Leg2);
				m_TransactionContainer.BeginTransaction();
				list2.Add(RevitUtility.NewModelCurve(m_Document, eps_Leg2.Line));
				m_TransactionContainer.EndTransaction();
			}
			for (int i = 0; i < list2.Count; i++)
			{
				elementSet.Insert(list2[i]);
			}
			bool result = true;
			if (eps_Leg != null)
			{
				result = ComponentCommon.PlaceLegList(m_Document, placementSettings, eps_Leg);
			}
			m_TransactionContainer.BeginTransaction();
			m_Document.Delete(ElementSetConverter.ToIDList(elementSet));
			m_TransactionContainer.EndTransaction();
			return result;
		}
		if (!RevitUtility.GetElementsFromProject(_strPrompt: m_DisplayForm.HedgeRowChecked ? EPShared.LocalRM.GetString("PickObjectMessage") : EPShared.LocalRM.GetString("PickClosedBoundaryMessage"), _Document: m_Document, _Elements: ref _Elements))
		{
			return false;
		}
		foreach (Element item5 in _Elements)
		{
			LocationCurve locationCurve = item5.Location as LocationCurve;
			Curve curve = null;
			if (locationCurve != null)
			{
				curve = locationCurve.Curve;
			}
			if (curve != null)
			{
				Eps_Leg eps_Leg3 = null;
				if (locationCurve != null && m_DisplayForm.ChainChecked)
				{
					eps_Leg3 = RevitGeometry.GetLegFromElementList(null, item5);
				}
				if (eps_Leg3 == null && m_DisplayForm.GroveChecked)
				{
					eps_Leg3 = RevitGeometry.GetLegFromElementList(null, item5);
				}
				if (eps_Leg3 != null)
				{
					double dY = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, dY))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					return ComponentCommon.PlaceLegList(m_Document, placementSettings, eps_Leg3);
				}
				if (curve is Arc)
				{
					Arc arc = (Arc)curve;
					if (!m_DisplayForm.HedgeRowChecked)
					{
						if (arc.IsBound)
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return false;
						}
						eps_Leg3 = new Eps_Leg();
						eps_Leg3.Arc = new Eps_Arc(arc);
						List<Eps_Leg> _IslandList = new List<Eps_Leg>();
						ComponentCommon.PickIslandLegs(m_Document, ref _IslandList);
						ComponentCommon.PlaceHedgeGrove(m_Document, placementSettings, eps_Leg3, _IslandList);
						if (m_DisplayForm.DeleteExistingChecked)
						{
							m_TransactionContainer.BeginTransaction();
							for (int j = 0; j < _IslandList.Count; j++)
							{
								if (_IslandList[j].ElementSet != null && _IslandList[j].ElementSet.Size > 0)
								{
									m_Document.Delete(ElementSetConverter.ToIDList(_IslandList[j].ElementSet));
								}
							}
							m_TransactionContainer.EndTransaction();
						}
					}
					else
					{
						if (RevitDefines.GT(m_DisplayForm.StartingDistance, curve.Length))
						{
							RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
							return false;
						}
						Eps_Arc _EvalArc = new Eps_Arc(arc);
						if (!RevitUtility.EvaluateArc(m_Document, m_TransactionContainer, m_DisplayForm.ComponentSpacing, ref _EvalArc))
						{
							return false;
						}
						placementSettings.IsReverse = _EvalArc.IsReverse;
						if (m_DisplayForm.CenteredHedgeRowChecked)
						{
							ComponentCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _EvalArc);
						}
						else if (m_DisplayForm.AlternateHedgeRowChecked)
						{
							ComponentCommon.PlaceAltRowOnArc(m_Document, placementSettings, item5, _EvalArc);
						}
						else
						{
							Eps_Arc _OffsetArc = new Eps_Arc();
							EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, m_DisplayForm.SetbackSpacing, 1, ref _OffsetArc);
							Eps_Arc _OffsetArc2 = new Eps_Arc();
							EPShared.eplGeoE_ConstructOffsetArc(_EvalArc, m_DisplayForm.SetbackSpacing, 2, ref _OffsetArc2);
							ElementSet elementSet2 = new ElementSet();
							if (_OffsetArc.Radius > 0.0)
							{
								m_TransactionContainer.BeginTransaction();
								ModelCurve item = RevitUtility.NewModelCurve(m_Document, _OffsetArc);
								m_TransactionContainer.EndTransaction();
								elementSet2.Insert(item);
							}
							if (_OffsetArc2.Radius > 0.0)
							{
								m_TransactionContainer.BeginTransaction();
								ModelCurve item2 = RevitUtility.NewModelCurve(m_Document, _OffsetArc2);
								m_TransactionContainer.EndTransaction();
								elementSet2.Insert(item2);
							}
							bool _UseRightSide = true;
							bool flag2 = RevitUtility.PickSideArc(m_Document, _EvalArc, ref _UseRightSide);
							m_TransactionContainer.BeginTransaction();
							m_Document.Delete(ElementSetConverter.ToIDList(elementSet2));
							m_TransactionContainer.EndTransaction();
							if (!flag2)
							{
								return false;
							}
							placementSettings.UseRightSide = _UseRightSide;
							if (_UseRightSide)
							{
								ComponentCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _OffsetArc);
							}
							else
							{
								ComponentCommon.PlaceCenterRowOnArc(m_Document, placementSettings, item5, _OffsetArc2);
							}
						}
					}
				}
				else if (curve is Line)
				{
					if (!m_DisplayForm.HedgeRowChecked)
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, curve.Length))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					Eps_Line _EvalLine = new Eps_Line();
					_EvalLine.StartPnt = new Eps_Point(curve.GetEndPoint(0));
					_EvalLine.EndPnt = new Eps_Point(curve.GetEndPoint(1));
					if (!RevitUtility.EvaluateLine(m_Document, m_TransactionContainer, m_DisplayForm.ComponentSpacing, ref _EvalLine))
					{
						return false;
					}
					placementSettings.IsReverse = _EvalLine.IsReverse;
					if (m_DisplayForm.CenteredHedgeRowChecked)
					{
						ComponentCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _EvalLine);
					}
					else if (m_DisplayForm.AlternateHedgeRowChecked)
					{
						ComponentCommon.PlaceAltRowOnLine(m_Document, placementSettings, item5, _EvalLine);
					}
					else
					{
						Eps_Line _OffsetLine = new Eps_Line();
						EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, m_DisplayForm.SetbackSpacing, 1, ref _OffsetLine);
						Eps_Line _OffsetLine2 = new Eps_Line();
						EPShared.eplGeoE_ConstructOffsetLine(_EvalLine, m_DisplayForm.SetbackSpacing, 2, ref _OffsetLine2);
						m_TransactionContainer.BeginTransaction();
						ModelCurve item3 = RevitUtility.NewModelCurve(m_Document, _OffsetLine);
						ModelCurve item4 = RevitUtility.NewModelCurve(m_Document, _OffsetLine2);
						m_TransactionContainer.EndTransaction();
						m_Document.Regenerate();
						bool _UseRightSide2 = true;
						bool flag3 = RevitUtility.PickSideLine(m_Document, _EvalLine, ref _UseRightSide2);
						ElementSet elementSet3 = new ElementSet();
						elementSet3.Insert(item3);
						elementSet3.Insert(item4);
						m_TransactionContainer.BeginTransaction();
						m_Document.Delete(ElementSetConverter.ToIDList(elementSet3));
						m_TransactionContainer.EndTransaction();
						if (!flag3)
						{
							return false;
						}
						placementSettings.UseRightSide = _UseRightSide2;
						if (_UseRightSide2)
						{
							ComponentCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _OffsetLine);
						}
						else
						{
							ComponentCommon.PlaceCenterRowOnLine(m_Document, placementSettings, item5, _OffsetLine2);
						}
					}
				}
				else
				{
					if (!(curve is Ellipse) && !(curve is NurbSpline) && !(curve is HermiteSpline))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					IList<XYZ> list3 = curve.Tessellate();
					int count = list3.Count;
					if (count > 1)
					{
						int num = 0;
						Eps_Point startPnt = new Eps_Point();
						Eps_Point eps_Point2 = new Eps_Point();
						eps_Leg3 = null;
						Eps_Leg eps_Leg4 = null;
						for (num = 0; num < count; num += 2)
						{
							eps_Point2 = new Eps_Point(list3[num]);
							if (num > 0)
							{
								eps_Leg4 = new Eps_Leg();
								eps_Leg4.Line = new Eps_Line();
								eps_Leg4.Line.StartPnt = startPnt;
								eps_Leg4.Line.EndPnt = eps_Point2;
								if (eps_Leg3 == null)
								{
									eps_Leg3 = eps_Leg4;
									eps_Leg3.Element = item5;
								}
								else
								{
									eps_Leg3.Last.Next = eps_Leg4;
									eps_Leg3.Last.Element = item5;
								}
							}
							startPnt = eps_Point2;
						}
						if (num == count)
						{
							eps_Leg4 = new Eps_Leg();
							eps_Leg4.Line = new Eps_Line();
							eps_Leg4.Line.StartPnt = startPnt;
							eps_Leg4.Line.EndPnt = new Eps_Point(list3[count - 1]);
							if (eps_Leg3 == null)
							{
								eps_Leg3 = eps_Leg4;
								eps_Leg3.Element = item5;
							}
							else
							{
								eps_Leg3.Last.Next = eps_Leg4;
								eps_Leg3.Last.Element = item5;
							}
						}
					}
					double dY2 = RevitGeometry.eplGeoE_CalcLegListLength(eps_Leg3);
					if (RevitDefines.GT(m_DisplayForm.StartingDistance, dY2))
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("StartingDistanceGreaterThanLineLengthMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return false;
					}
					if (!ComponentCommon.PlaceLegList(m_Document, placementSettings, eps_Leg3))
					{
						return false;
					}
				}
				if (m_DisplayForm.DeleteExistingChecked)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(item5.Id);
					m_TransactionContainer.EndTransaction();
				}
			}
			else
			{
				if (!(item5.Location is LocationPoint locationPoint))
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectSelectedNotSupportedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					return false;
				}
				PlaceSingleOnPoint(new Eps_Point(locationPoint.Point), list);
				if (m_DisplayForm.DeleteExistingChecked)
				{
					m_TransactionContainer.BeginTransaction();
					m_Document.Delete(item5.Id);
					m_TransactionContainer.EndTransaction();
				}
			}
		}
		return true;
	}
}
