﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RevitGeometry
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

#nullable disable
namespace EPCommon;

public class RevitGeometry
{
  private static List<UnitAbbrContainer> m_UnitAbbrContainer = (List<UnitAbbrContainer>) null;
  private static DisplayUnitType m_UnitBaseUnit = (DisplayUnitType) -2;

  private static bool FindFeetAndInchSymbol(string _strValue)
  {
    bool feetAndInchSymbol = true;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    bool flag5 = true;
    bool flag6 = false;
    for (int index = 0; index < _strValue.Length; ++index)
    {
      switch (_strValue[index])
      {
        case '"':
          if (index == 0 || flag4 || !flag5 || flag6 && !flag3)
          {
            feetAndInchSymbol = false;
            break;
          }
          flag4 = true;
          flag5 = false;
          break;
        case '\'':
          if (index == 0 || flag2 || flag4 || !flag5 || flag6 && !flag3)
          {
            feetAndInchSymbol = false;
            break;
          }
          flag2 = true;
          flag5 = false;
          if (flag1 || flag3)
          {
            flag4 = true;
            break;
          }
          break;
        default:
          feetAndInchSymbol = false;
          break;
      }
    }
    if (!flag4 && flag6 && !flag3 && !flag5)
      feetAndInchSymbol = false;
    return feetAndInchSymbol;
  }

  public static bool StrE_GetValidSlope(
    string _strInput,
    DisplayUnitType _BaseUnit,
    DisplayUnit _UnitType,
    ref double _dReturnedDouble)
  {
    return RevitGeometry.GetCurrentSlopeUnits(_strInput, _BaseUnit, _UnitType, ref _dReturnedDouble);
  }

  public static double GetSlopeAccuracy(DisplayUnitType dut)
  {
    if (dut == 161)
      return 1.0 / 256.0;
    return dut == 162 ? 0.00032552083333333332 : 0.0001;
  }

  public static double GetDirectShapeVolume(DirectShape ds)
  {
    double directShapeVolume = 0.0;
    foreach (GeometryObject geometryObject in ((Element) ds)[new Options()])
    {
      if (geometryObject is Solid)
        directShapeVolume += (geometryObject as Solid).Volume;
    }
    return directShapeVolume;
  }

  private static bool CheckForValidSlopeInput(
    string _strInput,
    DisplayUnitType _BaseUnit,
    DisplayUnit _UnitType)
  {
    bool flag = RevitGeometry.StrE_IsValidArchInput(_strInput);
    if (_BaseUnit != 19)
    {
      switch (_BaseUnit - 158)
      {
        case 0:
        case 1:
        case 2:
          break;
        default:
          goto label_4;
      }
    }
    if (flag)
      return false;
label_4:
    return true;
  }

  private static bool GetCurrentSlopeUnits(
    string _strInput,
    DisplayUnitType _BaseUnit,
    DisplayUnit _UnitType,
    ref double _dValue)
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    if (string.IsNullOrEmpty(_strInput))
      return false;
    string strA;
    string str;
    if (_strInput.IndexOf(":12") > 0)
    {
      int length = _strInput.IndexOf(":12");
      strA = ":12";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf(":10") > 0)
    {
      int length = _strInput.IndexOf(":10");
      strA = ":10";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("/ 12\"") > 0)
    {
      int length = _strInput.LastIndexOf("/ 12\"");
      strA = "/ 12\"";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("/ 1' - 0\"") > 0)
    {
      int length = _strInput.IndexOf("/ 1' - 0\"");
      strA = "/ 1' - 0\"";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("/ 1000") > 0)
    {
      int length = _strInput.IndexOf("/ 1000");
      strA = "/ 1000";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("mm") > 0)
    {
      int length = _strInput.IndexOf("mm");
      strA = "/ 1000";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("°") > 0)
    {
      int length = _strInput.IndexOf("°");
      strA = "°";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("%") > 0)
    {
      int length = _strInput.IndexOf("%");
      strA = "%";
      str = _strInput.Substring(0, length);
    }
    else if (_strInput.IndexOf("m") > 0)
    {
      int length = _strInput.IndexOf("m");
      strA = "m";
      str = _strInput.Substring(0, length);
    }
    else
    {
      strA = string.Empty;
      str = _strInput;
    }
    if (strA == string.Empty && str == string.Empty)
      return false;
    try
    {
      if (string.Compare(strA, ":12", true) == 0)
        _dValue = ValueConversion.ToDouble(str) / 12.0;
      else if (string.Compare(strA, ":10", true) == 0)
        _dValue = ValueConversion.ToDouble(str) / 10.0;
      else if (string.Compare(strA, "/ 12\"", true) == 0)
        RevitGeometry.StrE_GetValidArchNumber(str, _BaseUnit, _UnitType, ref _dValue);
      else if (string.Compare(strA, "/ 1' - 0\"", true) == 0)
        RevitGeometry.StrE_GetValidArchNumber(str, _BaseUnit, _UnitType, ref _dValue);
      else if (string.Compare(strA, "/ 1000", true) == 0)
        _dValue = ValueConversion.ToDouble(str) / 304.8;
      else if (string.Compare(strA, "°", true) == 0)
      {
        _dValue = RevitGeometry.DecimalDegreesToRadians(ValueConversion.ToDouble(str));
        if (RevitDefines.EQ(_dValue, Math.PI / 2.0) || RevitDefines.EQ(_dValue, 3.0 * Math.PI / 2.0))
        {
          double num = 0.0;
          double maxValue = double.MaxValue;
          _dValue = maxValue / num;
        }
        else
        {
          double num1 = 1.0;
          double num2 = Math.Tan(_dValue);
          _dValue = RevitDefines.EQ(_dValue, 0.0) || RevitDefines.EQ(_dValue, Math.PI) ? num1 / num2 : num2 / num1;
        }
      }
      else if (string.Compare(strA, "%", true) == 0)
        _dValue = ValueConversion.ToDouble(str) / 100.0;
      else if (string.Compare(strA, "m", true) == 0)
        _dValue = ValueConversion.ToDouble(str) / 0.3048;
      else if (strA == string.Empty)
      {
        if (RevitGeometry.FindFeetAndInchSymbol(str) && RevitGeometry.StrE_GetValidArchNumber(str, _BaseUnit, _UnitType, ref _dValue))
          return true;
        if (_BaseUnit != 19)
        {
          switch (_BaseUnit - 158)
          {
            case 0:
              _dValue = ValueConversion.ToDouble(str) / 10.0;
              break;
            case 1:
              _dValue = ValueConversion.ToDouble(str) / 12.0;
              break;
            case 2:
              _dValue = RevitGeometry.DecimalDegreesToRadians(ValueConversion.ToDouble(str));
              if (_dValue >= 0.0 && _dValue <= Math.PI)
              {
                if (RevitDefines.EQ(_dValue, Math.PI / 2.0) || RevitDefines.EQ(_dValue, 3.0 * Math.PI / 2.0))
                {
                  double num = 0.0;
                  double maxValue = double.MaxValue;
                  _dValue = maxValue / num;
                  break;
                }
                double num3 = 1.0;
                double num4 = Math.Tan(_dValue);
                _dValue = RevitDefines.EQ(_dValue, 0.0) || RevitDefines.EQ(_dValue, Math.PI) ? num3 / num4 : num4 / num3;
                break;
              }
              _dValue = 0.0;
              break;
            case 3:
              RevitGeometry.StrE_GetValidArchNumber(str, _BaseUnit, _UnitType, ref _dValue);
              break;
            case 4:
              RevitGeometry.StrE_GetValidArchNumber(str, _BaseUnit, _UnitType, ref _dValue);
              _dValue /= 1.0;
              break;
            case 5:
              _dValue = ValueConversion.ToDouble(str) / 304.8;
              break;
          }
        }
        else
          _dValue = ValueConversion.ToDouble(str) / 100.0;
      }
    }
    catch (Exception ex)
    {
      return false;
    }
    return true;
  }

  private static string FindSlopeStringToDisplay(
    double _dConvertedDouble,
    double _dDisplayPrecision,
    UnitSymbolType _UnitSymbolType,
    DecimalSymbol _DecimalSymbolType)
  {
    string empty = string.Empty;
    string str1 = ValueConversion.ToString(_dDisplayPrecision);
    int num1 = str1.IndexOf(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
    if (num1 >= 0 && num1 < str1.Length - 1)
    {
      int Precision = str1.Length - num1 - 1;
      _dConvertedDouble = RevitGeometry.eplCalE_RoundValue(_dConvertedDouble, Precision);
      return RevitGeometry.ApplyUnitToSlopeString(ValueConversion.Format(_DecimalSymbolType, $"{{0:f{Precision.ToString()}}}", (object) _dConvertedDouble), _UnitSymbolType);
    }
    int num2 = str1.IndexOf('-');
    if (num2 >= 0 && num2 < str1.Length - 1)
    {
      bool flag = true;
      string str2 = str1.Substring(num2 + 1);
      for (int index = 0; index < str2.Length; ++index)
      {
        if (!char.IsDigit(str2[index]))
        {
          flag = false;
          break;
        }
      }
      if (flag)
      {
        int int32 = Convert.ToInt32(str2);
        _dConvertedDouble = RevitGeometry.eplCalE_RoundValue(_dConvertedDouble, int32);
        return RevitGeometry.ApplyUnitToSlopeString(ValueConversion.Format(_DecimalSymbolType, $"{{0:f{int32.ToString()}}}", (object) _dConvertedDouble), _UnitSymbolType);
      }
    }
    return RevitGeometry.ApplyUnitToSlopeString(ValueConversion.ToString(_DecimalSymbolType, _dConvertedDouble), _UnitSymbolType);
  }

  private static string ApplyUnitToSlopeString(string _strToDisplay, UnitSymbolType _UnitSymbolType)
  {
    string slopeString = _strToDisplay;
    if (_UnitSymbolType <= 15801)
    {
      if (_UnitSymbolType != 1901)
      {
        if (_UnitSymbolType == 15801)
          slopeString += " :10";
      }
      else
        slopeString += "%";
    }
    else if (_UnitSymbolType != 15901)
    {
      if (_UnitSymbolType == 16001)
        slopeString += " °";
    }
    else
      slopeString += ":12";
    return slopeString;
  }

  public static bool Units_ConvertStringToDouble(
    string _strInput,
    Units _Units,
    UnitType _UnitType,
    ref double _dReturnedDouble)
  {
    return RevitGeometry.Units_ConvertStringToDouble(_strInput, _Units, _UnitType, ref _dReturnedDouble, true);
  }

  public static bool Units_ConvertStringToDouble(
    string _strInput,
    Units _Units,
    UnitType _UnitType,
    ref double _dReturnedDouble,
    bool _bDisplayInvalidInputMessage)
  {
    return RevitGeometry.Units_ConvertStringToDouble(_strInput, _Units, _UnitType, ref _dReturnedDouble, double.MinValue, true, double.MaxValue, true, _bDisplayInvalidInputMessage);
  }

  public static bool Units_ConvertStringToDouble(
    string _strInput,
    Units _Units,
    UnitType _UnitType,
    ref double _dReturnedDouble,
    double _dLowerLimit,
    bool _bLowerLimitInclusive,
    double _dUpperLimit,
    bool _bUpperLimitInclusive,
    bool _bDisplayInvalidInputMessage)
  {
    double num = 0.0;
    if (!UnitFormatUtils.TryParse(_Units, _UnitType, _strInput, ref num))
      return false;
    if (_bLowerLimitInclusive)
    {
      if (num < _dLowerLimit)
        return false;
    }
    else if (num <= _dLowerLimit)
      return false;
    if (_bUpperLimitInclusive)
    {
      if (num > _dUpperLimit)
        return false;
    }
    else if (num >= _dUpperLimit)
      return false;
    _dReturnedDouble = num;
    return true;
  }

  public static void Units_ConvertDoubleToString(
    double _dConvertedDouble,
    DisplayUnitType _UnitType,
    double _dDisplayPrecision,
    UnitSymbolType _UnitSymbolType,
    Units _Units,
    ref string _strToDisplay,
    bool forEditing = true)
  {
    FormatValueOptions formatValueOptions = new FormatValueOptions();
    formatValueOptions.AppendUnitSymbol = true;
    formatValueOptions.SetFormatOptions(new FormatOptions(_UnitType, _UnitSymbolType)
    {
      UseDefault = false,
      DisplayUnits = _UnitType,
      UnitSymbol = _UnitSymbolType,
      Accuracy = _dDisplayPrecision,
      SuppressSpaces = false,
      SuppressTrailingZeros = false,
      UseDigitGrouping = true,
      UsePlusPrefix = false
    });
    switch ((int) _UnitType)
    {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 9:
        _strToDisplay = UnitFormatUtils.Format(_Units, (UnitType) 0, _dConvertedDouble, false, forEditing, formatValueOptions);
        break;
      case 7:
      case 8:
      case 11:
      case 12:
      case 20:
      case 21:
      case 22:
        _strToDisplay = UnitFormatUtils.Format(_Units, (UnitType) 1, _dConvertedDouble, false, forEditing, formatValueOptions);
        break;
      case 10:
      case 13:
      case 14:
      case 26:
      case 27:
        _strToDisplay = UnitFormatUtils.Format(_Units, (UnitType) 2, _dConvertedDouble, false, forEditing, formatValueOptions);
        break;
      case 15:
        break;
      case 16 /*0x10*/:
        break;
      case 17:
        break;
      case 18:
        break;
      case 19:
        _strToDisplay = UnitFormatUtils.Format(_Units, (UnitType) 59, _dConvertedDouble, false, forEditing, formatValueOptions);
        break;
      case 23:
        break;
      case 24:
        break;
      case 25:
        break;
      default:
        if (_UnitType - 158 > 5)
          break;
        goto case 19;
    }
  }

  private static string ApplyUnitToString(string _strToDisplay, UnitSymbolType _UnitSymbolType)
  {
    return _strToDisplay;
  }

  private static string FindStringToDisplay(
    double _dConvertedDouble,
    double _dDisplayPrecision,
    UnitSymbolType _UnitSymbolType,
    DecimalSymbol _DecimalSymbolType)
  {
    string empty = string.Empty;
    string str1 = ValueConversion.ToString(_dDisplayPrecision);
    int num1 = str1.IndexOf(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
    if (num1 >= 0 && num1 < str1.Length - 1)
    {
      int Precision = str1.Length - num1 - 1;
      _dConvertedDouble = RevitGeometry.eplCalE_RoundValue(_dConvertedDouble, Precision);
      return RevitGeometry.ApplyUnitToString(ValueConversion.Format(_DecimalSymbolType, $"{{0:f{Precision.ToString()}}}", (object) _dConvertedDouble), _UnitSymbolType);
    }
    int num2 = str1.IndexOf('-');
    if (num2 >= 0 && num2 < str1.Length - 1)
    {
      bool flag = true;
      string str2 = str1.Substring(num2 + 1);
      for (int index = 0; index < str2.Length; ++index)
      {
        if (!char.IsDigit(str2[index]))
        {
          flag = false;
          break;
        }
      }
      if (flag)
      {
        int int32 = Convert.ToInt32(str2);
        _dConvertedDouble = RevitGeometry.eplCalE_RoundValue(_dConvertedDouble, int32);
        return RevitGeometry.ApplyUnitToString(ValueConversion.Format(_DecimalSymbolType, $"{{0:f{int32.ToString()}}}", (object) _dConvertedDouble), _UnitSymbolType);
      }
    }
    return RevitGeometry.ApplyUnitToString(ValueConversion.ToString(_DecimalSymbolType, _dConvertedDouble), _UnitSymbolType);
  }

  private static string FindStringToDisplay(
    double _dConvertedDouble,
    double _dDisplayPrecision,
    DecimalSymbol _DecimalSymbolType)
  {
    string empty = string.Empty;
    string str1 = ValueConversion.ToString(_dDisplayPrecision);
    int num1 = str1.IndexOf(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
    if (num1 >= 0 && num1 < str1.Length - 1)
    {
      int Precision = str1.Length - num1 - 1;
      _dConvertedDouble = RevitGeometry.eplCalE_RoundValue(_dConvertedDouble, Precision);
      return ValueConversion.Format(_DecimalSymbolType, $"{{0:f{Precision.ToString()}}}", (object) _dConvertedDouble);
    }
    int num2 = str1.IndexOf('-');
    if (num2 >= 0 && num2 < str1.Length - 1)
    {
      bool flag = true;
      string str2 = str1.Substring(num2 + 1);
      for (int index = 0; index < str2.Length; ++index)
      {
        if (!char.IsDigit(str2[index]))
        {
          flag = false;
          break;
        }
      }
      if (flag)
      {
        int int32 = Convert.ToInt32(str2);
        _dConvertedDouble = RevitGeometry.eplCalE_RoundValue(_dConvertedDouble, int32);
        return ValueConversion.Format(_DecimalSymbolType, $"{{0:f{int32.ToString()}}}", (object) _dConvertedDouble);
      }
    }
    return ValueConversion.ToString(_DecimalSymbolType, _dConvertedDouble);
  }

  private static void eplStrE_FloatToArch(double ArchFloat, ref string OutputStr, bool ShowInch)
  {
    int num1 = 0;
    bool flag = true;
    int num2 = 256 /*0x0100*/;
    double num3 = 0.0;
    string empty = string.Empty;
    string str1 = string.Empty;
    if (RevitDefines.EQ(ArchFloat, 0.0))
    {
      OutputStr = "0\"";
    }
    else
    {
      if (ArchFloat < 0.0)
      {
        ArchFloat *= -1.0;
        flag = false;
      }
      double num4;
      if (!ShowInch)
      {
        num1 = (int) (ArchFloat / 12.0);
        double num5 = (double) num1;
        num4 = ArchFloat - num5 * 12.0;
      }
      else
        num4 = ArchFloat;
      int num6 = (int) num4;
      num3 = (double) num1;
      double num7 = (num4 - (double) num6) * 256.0;
      int num8 = num7 - (double) (int) num7 < 0.5 ? (int) num7 : (int) num7 + 1;
      if (num8 == 256 /*0x0100*/)
      {
        num8 = 0;
        ++num6;
      }
      if ((double) num6 == 12.0)
      {
        num6 = 0;
        ++num1;
      }
      if (num8 > 0)
      {
        for (; num8 % 2 == 0 && num2 % 2 == 0; num2 = (int) ((double) num2 / 2.0))
          num8 = (int) ((double) num8 / 2.0);
      }
      if (num1 > 0 || num6 > 0 || num8 > 0)
      {
        if (!flag)
          str1 += "-";
        if (num1 > 0)
        {
          string str2 = Convert.ToString(num1) + "'";
          str1 += str2;
        }
        if (num1 > 0)
          str1 = str1 + "-" + Convert.ToString(num6);
        else if (num6 > 0)
        {
          string str3 = Convert.ToString(num6);
          str1 += str3;
        }
        if (num8 > 0)
        {
          if (num6 > 0 || num1 > 0)
            str1 += " ";
          string str4 = $"{Convert.ToString(num8)}/{Convert.ToString(num2)}";
          str1 += str4;
        }
      }
      if (str1 == string.Empty)
        str1 = "0";
      string str5 = str1 + "\"";
      OutputStr = str5;
    }
  }

  public static bool StrE_GetValidLinearMixedUnitNumber(
    string _strInput,
    DisplayUnitType _BaseUnit,
    DisplayUnit _UnitType,
    ref double _dValue)
  {
    string str1 = _strInput;
    string empty = string.Empty;
    string lower = str1.Trim().ToLower();
    if (RevitGeometry.m_UnitAbbrContainer == null)
      RevitGeometry.m_UnitAbbrContainer = new List<UnitAbbrContainer>();
    if (RevitGeometry.m_UnitBaseUnit != _BaseUnit)
    {
      RevitGeometry.m_UnitAbbrContainer.Clear();
      switch ((int) _BaseUnit)
      {
        case 0:
        case 9:
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("LF", 1.0, 0.3048));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("mm", 0.0032808398950131233, 0.001));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("cm", 25.0 / 762.0, 0.01));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("m", 1250.0 / 381.0, 1.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("'", 1.0, 0.3048));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("\"", 1.0 / 12.0, 0.0254));
          break;
        case 1:
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("LF", 1.0, 30.48));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("mm", 0.0032808398950131233, 0.1));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("cm", 25.0 / 762.0, 1.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("m", 1250.0 / 381.0, 100.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("'", 1.0, 30.48));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("\"", 1.0 / 12.0, 2.54));
          break;
        case 2:
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("LF", 1.0, 304.8));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("mm", 0.0032808398950131233, 1.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("cm", 25.0 / 762.0, 10.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("m", 1250.0 / 381.0, 1000.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("'", 1.0, 304.8));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("\"", 1.0 / 12.0, 25.4));
          break;
        case 3:
        case 4:
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("LF", 1.0, 0.3048));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("mm", 0.0032808398950131233, 0.001));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("cm", 0.0032808398950131233, 0.01));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("m", 1250.0 / 381.0, 1.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("'", 1.0, 0.3048));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("\"", 12.0, 0.0254));
          break;
        case 5:
        case 6:
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("LF", 1.0 / 12.0, 0.3048));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("mm", 5.0 / (double) sbyte.MaxValue, 0.001));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("cm", 50.0 / (double) sbyte.MaxValue, 0.01));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("m", 5000.0 / (double) sbyte.MaxValue, 1.0));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("'", 1.0 / 12.0, 0.3048));
          RevitGeometry.m_UnitAbbrContainer.Add(new UnitAbbrContainer("\"", 1.0, 0.0254));
          break;
      }
      RevitGeometry.m_UnitBaseUnit = _BaseUnit;
    }
    for (int index = 0; index < lower.Length && (char.IsDigit(lower[index]) || lower[index] == '.' || lower[index] == '-' || lower[index] == ','); ++index)
      empty += lower[index].ToString();
    if (empty != string.Empty)
      _dValue = ValueConversion.ToDouble(empty);
    for (int index = 0; index < RevitGeometry.m_UnitAbbrContainer.Count<UnitAbbrContainer>(); ++index)
    {
      int length;
      if ((length = lower.IndexOf(RevitGeometry.m_UnitAbbrContainer[index].Abbreviation)) != -1 && length + RevitGeometry.m_UnitAbbrContainer[index].Abbreviation.Length == lower.Length)
      {
        string str2 = lower.Substring(0, length);
        bool validRealNumber;
        if (!(validRealNumber = RevitGeometry.StrE_GetValidRealNumber(str2, ref _dValue, double.MinValue, true, double.MaxValue, true)))
          return validRealNumber;
        _dValue = ValueConversion.ToDouble(str2);
        if (_UnitType == 1)
          _dValue *= RevitGeometry.m_UnitAbbrContainer[index].EnglishFactor;
        else
          _dValue *= RevitGeometry.m_UnitAbbrContainer[index].MetricFactor;
        return true;
      }
    }
    return RevitGeometry.StrE_GetValidRealNumber(lower, ref _dValue, double.MinValue, true, double.MaxValue, true);
  }

  public static bool StrE_GetValidWholeNumber(string _strInput, ref int _nReturnedInt)
  {
    return RevitGeometry.StrE_GetValidWholeNumber(_strInput, ref _nReturnedInt, int.MinValue, int.MaxValue);
  }

  private static bool StrE_GetValidWholeNumber(
    string _strInput,
    ref int _nReturnedInt,
    int _nLowerLimit,
    int _nUpperLimit)
  {
    string str = _strInput.Trim();
    if (str == string.Empty)
      return false;
    for (int index = 0; index < str.Length; ++index)
    {
      if (!char.IsDigit(str[index]))
        return false;
    }
    int int32 = Convert.ToInt32(str);
    if (int32 < _nLowerLimit || int32 > _nUpperLimit)
      return false;
    _nReturnedInt = int32;
    return true;
  }

  public static bool StrE_GetValidRealNumber(string _strInput, ref double _dReturnedDouble)
  {
    return RevitGeometry.StrE_GetValidRealNumber(_strInput, ref _dReturnedDouble, double.MinValue, true, double.MaxValue, true);
  }

  private static bool StrE_GetValidRealNumber(
    string _strInput,
    ref double _dReturnedDouble,
    double _dLowerLimit,
    bool _bLowerLimitInclusive,
    double _dUpperLimit,
    bool _bUpperLimitInclusive)
  {
    string _strValue = _strInput.Trim();
    if (_strValue == string.Empty)
      return false;
    for (int index = 0; index < _strValue.Length; ++index)
    {
      if (!char.IsDigit(_strValue[index]) && _strValue[index] != '.' && _strValue[index] != '-' && _strValue[index] != ',')
        return false;
    }
    double num = ValueConversion.ToDouble(_strValue);
    if (_bLowerLimitInclusive)
    {
      if (num < _dLowerLimit)
        return false;
    }
    else if (num <= _dLowerLimit)
      return false;
    if (_bUpperLimitInclusive)
    {
      if (num > _dUpperLimit)
        return false;
    }
    else if (num >= _dUpperLimit)
      return false;
    _dReturnedDouble = num;
    return true;
  }

  public static bool StrE_GetValidArchNumber(
    string _InputString,
    DisplayUnitType gBaseUnit,
    DisplayUnit _UnitType,
    ref double _ReturnedDouble)
  {
    string str1 = _InputString;
    string _strValue1 = string.Empty;
    string _strValue2 = string.Empty;
    string _strValue3 = string.Empty;
    string _strValue4 = string.Empty;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    string _strValue5 = str1.Trim();
    if (_strValue5 == string.Empty || !RevitGeometry.StrE_IsValidArchInput(_strValue5))
      return false;
    for (int index = 0; index < _strValue5.Length; ++index)
    {
      char ch = _strValue5[index];
      switch (ch)
      {
        case ' ':
          _strValue2 = _strValue1;
          _strValue1 = string.Empty;
          break;
        case '"':
          if (num2 > 0.0)
            return false;
          flag3 = true;
          if (flag2)
          {
            _strValue4 = _strValue1;
            _strValue1 = string.Empty;
          }
          if (_strValue1 != string.Empty)
          {
            num2 = ValueConversion.ToDouble(_strValue1);
            _strValue1 = string.Empty;
            break;
          }
          if (_strValue2 != string.Empty)
          {
            num3 = ValueConversion.ToDouble(_strValue2);
            _strValue2 = string.Empty;
          }
          num2 = num3;
          if (flag2)
          {
            double num4 = ValueConversion.ToDouble(_strValue3);
            _strValue3 = string.Empty;
            double num5 = ValueConversion.ToDouble(_strValue4);
            _strValue4 = string.Empty;
            num3 = num4 / num5;
            num2 += num3;
            break;
          }
          break;
        case '\'':
          flag3 = true;
          if (num1 > 0.0)
            return false;
          flag4 = true;
          if (flag2)
          {
            _strValue4 = _strValue1;
            _strValue1 = string.Empty;
          }
          if (_strValue1 != string.Empty)
          {
            num1 = ValueConversion.ToDouble(_strValue1);
            _strValue1 = string.Empty;
            break;
          }
          if (_strValue2 != string.Empty)
          {
            num3 = ValueConversion.ToDouble(_strValue2);
            _strValue2 = string.Empty;
          }
          num1 = num3;
          if (flag2)
          {
            double num6 = ValueConversion.ToDouble(_strValue3);
            _strValue3 = string.Empty;
            double num7 = ValueConversion.ToDouble(_strValue4);
            _strValue4 = string.Empty;
            num3 = num6 / num7;
            num1 += num3;
            break;
          }
          break;
        case ',':
        case '.':
          string str2 = _strValue1;
          ch = _strValue5[index];
          string str3 = ch.ToString();
          _strValue1 = str2 + str3;
          break;
        case '-':
          if (index == 0)
          {
            flag1 = true;
            break;
          }
          _strValue2 = _strValue1;
          _strValue1 = string.Empty;
          break;
        case '/':
          _strValue3 = _strValue1;
          _strValue1 = string.Empty;
          flag2 = true;
          break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
          string str4 = _strValue1;
          ch = _strValue5[index];
          string str5 = ch.ToString();
          _strValue1 = str4 + str5;
          break;
        default:
          return false;
      }
    }
    string empty1;
    if (_strValue1 != string.Empty)
    {
      if (flag2)
      {
        string _strValue6 = _strValue1;
        empty1 = string.Empty;
        if (_strValue2 != string.Empty)
        {
          num3 = ValueConversion.ToDouble(_strValue2);
          string empty2 = string.Empty;
        }
        if (flag3 || gBaseUnit == 5 || gBaseUnit == 6 || gBaseUnit == 161)
          num2 = num3;
        else
          num1 = num3;
        double num8 = ValueConversion.ToDouble(_strValue3);
        string empty3 = string.Empty;
        double num9 = ValueConversion.ToDouble(_strValue6);
        string empty4 = string.Empty;
        double num10 = num8 / num9;
        if (flag3 || gBaseUnit == 5 || gBaseUnit == 6 || gBaseUnit == 161)
          num2 += num10;
        else
          num1 += num10;
      }
      else
      {
        if (flag3 || gBaseUnit == 5 || gBaseUnit == 6 || gBaseUnit == 161)
          num2 = ValueConversion.ToDouble(_strValue1);
        else
          num1 = ValueConversion.ToDouble(_strValue1);
        empty1 = string.Empty;
      }
    }
    if (flag3 || flag4 || gBaseUnit == 5 || gBaseUnit == 6 || gBaseUnit == 4 || gBaseUnit == 3 || gBaseUnit == 161 || gBaseUnit == 162)
    {
      _ReturnedDouble = num1 * 12.0 + num2;
      if (_UnitType == 1)
        _ReturnedDouble *= 1.0 / 12.0;
      else
        _ReturnedDouble *= 0.0254;
    }
    else
      _ReturnedDouble = num1;
    if (flag1)
      _ReturnedDouble *= -1.0;
    return true;
  }

  private static bool StrE_IsValidArchInput(string _strValue)
  {
    bool flag1 = true;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    bool flag5 = false;
    bool flag6 = false;
    bool flag7 = false;
    bool flag8 = true;
    bool flag9 = false;
    for (int index = 0; index < _strValue.Length; ++index)
    {
      switch (_strValue[index])
      {
        case ' ':
          if (flag7 || flag2 || flag3 || flag6 || index == 0)
          {
            flag1 = false;
            break;
          }
          flag2 = true;
          flag9 = flag8;
          flag8 = false;
          break;
        case '"':
          if (index == 0 || flag7 || !flag8 || flag9 && !flag6)
          {
            flag1 = false;
            break;
          }
          flag7 = true;
          flag8 = false;
          break;
        case '\'':
          if (index == 0 || flag4 || flag7 || !flag8 || flag9 && !flag6)
          {
            flag1 = false;
            break;
          }
          flag4 = true;
          flag8 = false;
          if (flag3 || flag6)
          {
            flag7 = true;
            break;
          }
          break;
        case ',':
        case '.':
          if (flag3 || flag6 || flag7)
          {
            flag1 = false;
            break;
          }
          flag3 = true;
          flag8 = false;
          break;
        case '-':
          if (index != 0 && (flag5 || flag7))
          {
            flag1 = false;
            break;
          }
          if (index != 0)
          {
            flag5 = true;
            flag9 = flag8;
            flag8 = false;
            break;
          }
          break;
        case '/':
          if (flag3 || flag6 || flag7 || index == 0 || !flag8)
          {
            flag1 = false;
            break;
          }
          flag6 = true;
          flag8 = false;
          break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
          if (flag7)
            flag1 = false;
          flag8 = true;
          break;
        default:
          flag1 = false;
          break;
      }
    }
    if (!flag7 && flag9 && !flag6 && !flag8)
      flag1 = false;
    return flag1;
  }

  public static int eplStrE_ConvertRadiansToAngleStr(
    DisplayUnitType _AngularUnits,
    double _dAngle,
    double _dRounding,
    UnitSymbolType _UnitSymbolType,
    DecimalSymbol _DecimalSymbolType,
    ref string _strAngleStr)
  {
    int angleStr = 0;
    if (_dRounding > 0.001)
      _dRounding = 0.001;
    int _nPrecision = 0;
    string str1 = ValueConversion.ToString((DecimalSymbol) 0, _dRounding);
    int num1 = str1.IndexOf(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
    if (num1 >= 0 && num1 < str1.Length - 1)
    {
      _nPrecision = str1.Length - num1 - 1;
    }
    else
    {
      int num2 = str1.IndexOf('-');
      if (num2 >= 0 && num2 < str1.Length - 1)
      {
        bool flag = true;
        string str2 = str1.Substring(num2 + 1);
        for (int index = 0; index < str2.Length; ++index)
        {
          if (!char.IsDigit(str2[index]))
          {
            flag = false;
            break;
          }
        }
        if (flag)
          _nPrecision = Convert.ToInt32(str2);
      }
    }
    if (_AngularUnits != 15)
    {
      if (_AngularUnits == 16 /*0x10*/)
        RevitGeometry.eplStrE_ConvertRadiansToDMSAngleStr(_dAngle, _nPrecision, _DecimalSymbolType, ref _strAngleStr);
      else
        angleStr = 2500;
    }
    else
      RevitGeometry.eplStrE_ConvertRadiansToDecimalDegreesAngleStr(_dAngle, _nPrecision, _UnitSymbolType, _DecimalSymbolType, ref _strAngleStr);
    return angleStr;
  }

  public static void RadiansToDMS(
    double _dRadians,
    ref int _nSign,
    ref int _nDegrees,
    ref int _nMinutes,
    ref double _dSeconds)
  {
    double num1 = Math.Abs(_dRadians) / (Math.PI / 180.0);
    _nSign = 1;
    if (_dRadians < 0.0)
      _nSign = -1;
    _nDegrees = (int) num1;
    double num2 = Math.Abs(num1 - (double) _nDegrees) * 60.0;
    _nMinutes = (int) num2;
    double num3 = (num2 - (double) _nMinutes) * 60.0;
    _dSeconds = num3;
  }

  public static double RadiansToDecimalDegrees(double _dRadians) => _dRadians / (Math.PI / 180.0);

  public static double DecimalDegreesToRadians(double _dDecimalDegrees)
  {
    return _dDecimalDegrees * (Math.PI / 180.0);
  }

  public static void DMSToRadians(
    ref double _dRadians,
    int _nSign,
    int _nDegrees,
    int _nMinutes,
    double _dSeconds)
  {
    _dRadians = (double) _nSign * (((double) Math.Abs(_nDegrees) + (double) Math.Abs(_nMinutes) / 60.0 + Math.Abs(_dSeconds) / 3600.0) * (Math.PI / 180.0));
  }

  private static void RoundDMSAngle(
    ref int _nDegrees,
    ref int _nMinutes,
    ref double _dSeconds,
    int _nPrecision)
  {
    _dSeconds = RevitGeometry.eplCalE_RoundValue(_dSeconds, _nPrecision);
    if (_dSeconds == 60.0)
    {
      _dSeconds = 0.0;
      ++_nMinutes;
    }
    if (_nMinutes == 60)
    {
      _nMinutes = 0;
      ++_nDegrees;
    }
    if (_nDegrees < 360)
      return;
    _nDegrees -= 360;
  }

  private static void eplStrE_ConvertRadiansToDMSAngleStr(
    double _dAngle,
    int _nPrecision,
    DecimalSymbol _DecimalSymbolType,
    ref string strAngleString)
  {
    int _nDegrees = 0;
    int _nMinutes = 0;
    double _dSeconds = 0.0;
    strAngleString = string.Empty;
    int _nSign = 1;
    RevitGeometry.RadiansToDMS(_dAngle, ref _nSign, ref _nDegrees, ref _nMinutes, ref _dSeconds);
    RevitGeometry.RoundDMSAngle(ref _nDegrees, ref _nMinutes, ref _dSeconds, _nPrecision);
    strAngleString = RevitGeometry.CreateDMSString(_nDegrees, _nMinutes, _dSeconds, _nPrecision, _DecimalSymbolType);
    if (_nSign == 1)
      return;
    strAngleString = "-" + strAngleString;
  }

  private static void eplStrE_ConvertRadiansToDecimalDegreesAngleStr(
    double _dAngle,
    int _nPrecision,
    UnitSymbolType _UnitSymbolType,
    DecimalSymbol _DecimalSymbolType,
    ref string strAngleString)
  {
    strAngleString = string.Empty;
    _dAngle = RevitGeometry.RadiansToDecimalDegrees(_dAngle);
    _dAngle = RevitGeometry.eplCalE_RoundValue(_dAngle, _nPrecision);
    if (_nPrecision < 0)
      strAngleString = ValueConversion.ToString(_DecimalSymbolType, _dAngle);
    else
      strAngleString = ValueConversion.Format(_DecimalSymbolType, $"{{0:f{_nPrecision.ToString()}}}", (object) _dAngle);
    if (_UnitSymbolType != 1501)
      return;
    strAngleString += "°";
  }

  private static string CreateDMSString(
    int _nDegrees,
    int _nMinutes,
    double _dSeconds,
    int _nPrecision,
    DecimalSymbol _DecimalSymbolType)
  {
    string empty = string.Empty;
    string dmsString;
    if (_nPrecision < 0)
    {
      dmsString = $"{_nDegrees.ToString("00")}°{_nMinutes.ToString("00")}'{_dSeconds.ToString()}\"";
    }
    else
    {
      string str = "";
      for (int index = 0; index < _nPrecision; ++index)
        str += "0";
      dmsString = $"{_nDegrees.ToString("00")}°{_nMinutes.ToString("00")}'{_dSeconds.ToString("00." + str)}\"";
    }
    if (_DecimalSymbolType == null)
      dmsString = dmsString.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, ".");
    else if (_DecimalSymbolType == 1)
      dmsString = dmsString.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, ",");
    return dmsString;
  }

  public static double eplGeoE_ConvertAngleToRadians(string _strDirection)
  {
    double _dRadians = 0.0;
    _strDirection = _strDirection.Replace(" ", string.Empty);
    if (_strDirection == string.Empty)
      return _dRadians;
    int startIndex1 = 0;
    string _strInput1 = "0";
    string _strInput2 = "0";
    string _strInput3 = "0";
    int _nSign = 1;
    int _nReturnedInt1 = 0;
    int _nReturnedInt2 = 0;
    double _dReturnedDouble1 = 0.0;
    double _dReturnedDouble2 = 0.0;
    int num1 = _strDirection.IndexOf("°");
    int num2 = _strDirection.IndexOf("'");
    int num3 = _strDirection.IndexOf("\"");
    if (_strDirection.IndexOf("-") != -1)
      _nSign = -1;
    int startIndex2;
    if (num1 != -1)
    {
      _strInput1 = _strDirection.Substring(startIndex1, num1 - startIndex1);
      startIndex2 = num1 + 1;
    }
    else
    {
      startIndex2 = startIndex1;
      if (num2 == -1 && num3 == -1 && _strDirection.Length > startIndex1)
        _strInput1 = _strDirection.Substring(startIndex1, _strDirection.Length - startIndex1);
    }
    int startIndex3;
    if (num2 != -1)
    {
      _strInput2 = _strDirection.Substring(startIndex2, num2 - startIndex2);
      startIndex3 = num2 + 1;
    }
    else
    {
      startIndex3 = startIndex2;
      if (num1 != -1 && num3 == -1 && _strDirection.Length > startIndex2)
        _strInput2 = _strDirection.Substring(startIndex2, _strDirection.Length - startIndex2);
    }
    if (num3 != -1)
      _strInput3 = _strDirection.Substring(startIndex3, num3 - startIndex3);
    else if (num2 != -1 && _strDirection.Length > startIndex3)
      _strInput3 = _strDirection.Substring(startIndex3, _strDirection.Length - startIndex3);
    if (_strInput1 == string.Empty || _strInput2 == string.Empty || _strInput3 == string.Empty)
      return 0.0;
    if (num2 != -1 || num3 != -1)
    {
      if (!RevitGeometry.StrE_GetValidWholeNumber(_strInput1, ref _nReturnedInt1))
        _nReturnedInt1 = 0;
      if (!RevitGeometry.StrE_GetValidWholeNumber(_strInput2, ref _nReturnedInt2))
        _nReturnedInt2 = 0;
      if (!RevitGeometry.StrE_GetValidRealNumber(_strInput3, ref _dReturnedDouble1))
        _dReturnedDouble1 = 0.0;
      RevitGeometry.DMSToRadians(ref _dRadians, _nSign, Math.Abs(_nReturnedInt1), Math.Abs(_nReturnedInt2), Math.Abs(_dReturnedDouble1));
    }
    else
    {
      if (!RevitGeometry.StrE_GetValidRealNumber(_strInput1, ref _dReturnedDouble2))
        _dReturnedDouble2 = 0.0;
      _dRadians = RevitGeometry.DecimalDegreesToRadians(_dReturnedDouble2);
    }
    return EPShared.eplGeoE_NormalizeRadians(_dRadians);
  }

  public static void eplGeoE_CalcSweepAngle(
    int ArcDir,
    double StartDir,
    double EndDir,
    ref double SweepAngle)
  {
    if (ArcDir == -1)
      SweepAngle = EPShared.eplGeoE_NormalizeRadians(StartDir - EndDir);
    else
      SweepAngle = EPShared.eplGeoE_NormalizeRadians(EndDir - StartDir);
  }

  public static int CalcSignedArea(Eps_Point _pPt1, Eps_Point _pPt2, Eps_Point _pPt3)
  {
    return (_pPt3.x - _pPt1.x) * (_pPt2.y - _pPt1.y) - (_pPt2.x - _pPt1.x) * (_pPt3.y - _pPt1.y) >= 0.0 ? 1 : -1;
  }

  public static double GeoE_CalcSignedArea(Eps_Line pLine, Eps_Point pPoint)
  {
    return (pPoint.x - pLine.StartPnt.x) * (pLine.EndPnt.y - pLine.StartPnt.y) - (pLine.EndPnt.x - pLine.StartPnt.x) * (pPoint.y - pLine.StartPnt.y);
  }

  public static double ConvertLinearValue(
    double _dSource,
    DisplayUnitType _InputLinearDistanceType,
    DisplayUnitType _OutputLinearDistanceType)
  {
    double num = 1.0;
    switch ((int) _InputLinearDistanceType)
    {
      case 0:
      case 9:
        switch ((int) _OutputLinearDistanceType)
        {
          case 1:
            num = 100.0;
            break;
          case 2:
            num = 1000.0;
            break;
          case 3:
          case 4:
            num = 1250.0 / 381.0;
            break;
          case 5:
          case 6:
            num = 5000.0 / (double) sbyte.MaxValue;
            break;
          default:
            num = 1.0;
            break;
        }
        break;
      case 1:
        switch ((int) _OutputLinearDistanceType)
        {
          case 0:
          case 9:
            num = 0.01;
            break;
          case 2:
            num = 10.0;
            break;
          case 3:
          case 4:
            num = 25.0 / 762.0;
            break;
          case 5:
          case 6:
            num = 50.0 / (double) sbyte.MaxValue;
            break;
          default:
            num = 1.0;
            break;
        }
        break;
      case 2:
        switch ((int) _OutputLinearDistanceType)
        {
          case 0:
          case 9:
            num = 0.001;
            break;
          case 1:
            num = 0.1;
            break;
          case 3:
          case 4:
            num = 0.0032808398950131233;
            break;
          case 5:
          case 6:
            num = 5.0 / (double) sbyte.MaxValue;
            break;
          default:
            num = 1.0;
            break;
        }
        break;
      case 3:
      case 4:
        switch ((int) _OutputLinearDistanceType)
        {
          case 0:
          case 9:
            num = 0.3048;
            break;
          case 1:
            num = 30.48;
            break;
          case 2:
            num = 304.8;
            break;
          case 5:
          case 6:
            num = 12.0;
            break;
          default:
            num = 1.0;
            break;
        }
        break;
      case 5:
      case 6:
        switch ((int) _OutputLinearDistanceType)
        {
          case 0:
          case 9:
            num = 0.0254;
            break;
          case 1:
            num = 2.54;
            break;
          case 2:
            num = 25.4;
            break;
          case 3:
          case 4:
            num = 1.0 / 12.0;
            break;
          default:
            num = 1.0;
            break;
        }
        break;
    }
    return _dSource * num;
  }

  public static double eplCalE_RoundValue(double Value, int Precision)
  {
    double num = Math.Pow(10.0, (double) Precision);
    return RevitGeometry.eplCalE_floor(Value * num + 0.5, 0.0) / num;
  }

  public static double eplCalE_floor(double Operand, double Tolerance)
  {
    return Math.Floor(Operand + Tolerance);
  }

  public static Eps_Leg GetLegFromElementList(Eps_Leg _CurrentLeg, Element _LocationElement)
  {
    bool flag = true;
    if (_CurrentLeg != null)
      flag = false;
    _CurrentLeg = RevitGeometry.GetLegFromElementListAtJoin(_CurrentLeg, _LocationElement, 0);
    _CurrentLeg = RevitGeometry.GetLegFromElementListAtJoin(_CurrentLeg, _LocationElement, 1);
    if (_CurrentLeg != null && flag && _LocationElement.Location != null)
    {
      if (!(_LocationElement.Location is LocationCurve location))
        return (Eps_Leg) null;
      Eps_Point _Point1 = new Eps_Point();
      Eps_Point _Point2 = new Eps_Point();
      if (location.Curve is Arc)
      {
        Eps_Arc epsArc = new Eps_Arc((Arc) location.Curve);
        _Point1 = epsArc.StartPnt;
        _Point2 = epsArc.EndPnt;
      }
      else if (location.Curve is Line)
      {
        Eps_Line epsLine = new Eps_Line((Line) location.Curve);
        _Point1 = epsLine.StartPnt;
        _Point2 = epsLine.EndPnt;
      }
      double _dStation1 = 0.0;
      double _dStation2 = 0.0;
      double _dOffset1 = 0.0;
      double _dOffset2 = 0.0;
      RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point1, _CurrentLeg, ref _dStation1, ref _dOffset1);
      RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point2, _CurrentLeg, ref _dStation2, ref _dOffset2);
      double num = _dStation1 > _dStation2 ? _dStation2 : _dStation1;
      Eps_Leg _LegList = _CurrentLeg.Reverse();
      RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point1, _LegList, ref _dStation1, ref _dOffset1);
      RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point2, _LegList, ref _dStation2, ref _dOffset2);
      if (_dStation1 < num || _dStation2 < num)
        _CurrentLeg = _LegList;
    }
    return _CurrentLeg;
  }

  public static Eps_Leg GetLegFromSpline(
    Element _LocationElement,
    Curve _SplineCurve,
    bool _bReverseOrder)
  {
    Eps_Leg legFromSpline = (Eps_Leg) null;
    IList<XYZ> xyzList = _SplineCurve.Tessellate();
    int count = xyzList.Count;
    if (count > 1)
    {
      Eps_Point epsPoint1 = new Eps_Point();
      Eps_Point epsPoint2 = new Eps_Point();
      if (!_bReverseOrder)
      {
        int index;
        for (index = 0; index < count; index += 2)
        {
          Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
          if (index > 0)
          {
            Eps_Leg epsLeg = new Eps_Leg();
            epsLeg.Line = new Eps_Line();
            epsLeg.Line.StartPnt = epsPoint1;
            epsLeg.Line.EndPnt = epsPoint3;
            if (legFromSpline == null)
            {
              legFromSpline = epsLeg;
              legFromSpline.Element = _LocationElement;
            }
            else
              legFromSpline.Last.Next = epsLeg;
          }
          epsPoint1 = epsPoint3;
        }
        if (index == count)
        {
          Eps_Leg epsLeg = new Eps_Leg();
          epsLeg.Line = new Eps_Line();
          epsLeg.Line.StartPnt = epsPoint1;
          epsLeg.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
          if (legFromSpline == null)
          {
            legFromSpline = epsLeg;
            legFromSpline.Element = _LocationElement;
          }
          else
            legFromSpline.Last.Next = epsLeg;
        }
      }
      else
      {
        int index;
        for (index = count - 1; index >= 0; index -= 2)
        {
          Eps_Point epsPoint4 = new Eps_Point(xyzList[index]);
          if (index < count - 1)
          {
            Eps_Leg epsLeg = new Eps_Leg();
            epsLeg.Line = new Eps_Line();
            epsLeg.Line.StartPnt = epsPoint1;
            epsLeg.Line.EndPnt = epsPoint4;
            if (legFromSpline == null)
            {
              legFromSpline = epsLeg;
              legFromSpline.Element = _LocationElement;
            }
            else
              legFromSpline.Last.Next = epsLeg;
          }
          epsPoint1 = epsPoint4;
        }
        if (index == -1)
        {
          Eps_Leg epsLeg = new Eps_Leg();
          epsLeg.Line = new Eps_Line();
          epsLeg.Line.StartPnt = epsPoint1;
          epsLeg.Line.EndPnt = new Eps_Point(xyzList[0]);
          if (legFromSpline == null)
          {
            legFromSpline = epsLeg;
            legFromSpline.Element = _LocationElement;
          }
          else
            legFromSpline.Last.Next = epsLeg;
        }
      }
    }
    return legFromSpline;
  }

  private static Eps_Leg GetLegFromElementListAtJoin(
    Eps_Leg _CurrentLeg,
    Element _LocationElement,
    int _nIndex)
  {
    Eps_Arc _CompareArc = (Eps_Arc) null;
    Eps_Line _CompareLine = (Eps_Line) null;
    locationCurve = (LocationCurve) null;
    if (_CurrentLeg != null && EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt))
      return _CurrentLeg;
    if (_LocationElement.Location != null && !(_LocationElement.Location is LocationCurve locationCurve))
      return (Eps_Leg) null;
    ElementArray elementArray = locationCurve[_nIndex];
    if (elementArray.Size > 0)
    {
      if (_CurrentLeg == null)
      {
        Eps_Leg epsLeg = new Eps_Leg();
        if (locationCurve.Curve is Arc)
        {
          epsLeg.Element = _LocationElement;
          epsLeg.Arc = new Eps_Arc((Arc) locationCurve.Curve);
        }
        else if (locationCurve.Curve is Line)
        {
          epsLeg.Element = _LocationElement;
          epsLeg.Line = new Eps_Line((Line) locationCurve.Curve);
        }
        else if (locationCurve.Curve is NurbSpline || locationCurve.Curve is HermiteSpline || locationCurve.Curve is Ellipse)
          epsLeg = RevitGeometry.GetLegFromSpline(_LocationElement, locationCurve.Curve, false);
        _CurrentLeg = epsLeg;
      }
      ElementArrayIterator elementArrayIterator = elementArray.ForwardIterator();
      elementArrayIterator.Reset();
      while (elementArrayIterator.MoveNext())
      {
        if (elementArrayIterator.Current is Element current && current.Location is LocationCurve location)
        {
          Curve curve = location.Curve;
          switch (curve)
          {
            case Arc _:
              _CompareArc = new Eps_Arc((Arc) curve);
              if (!_CurrentLeg.IsArcInLeg(_CompareArc))
                break;
              continue;
            case Line _:
              _CompareLine = new Eps_Line((Line) curve);
              if (!_CurrentLeg.IsLineInLeg(_CompareLine))
                break;
              continue;
            case NurbSpline _:
            case HermiteSpline _:
            case Ellipse _:
              IList<XYZ> xyzList = curve.Tessellate();
              int count = xyzList.Count;
              if (count <= 1 || !RevitGeometry.eplGeoE_IsPointOnLegList2D(new Eps_Point(xyzList[0]), _CurrentLeg) || !RevitGeometry.eplGeoE_IsPointOnLegList2D(new Eps_Point(xyzList[count - 1]), _CurrentLeg))
                break;
              continue;
          }
          bool flag = false;
          if (_CurrentLeg.LegStartPnt.IsEqual(new Eps_Point(curve.GetEndPoint(0))))
          {
            Eps_Leg epsLeg = new Eps_Leg();
            switch (curve)
            {
              case Arc _:
                epsLeg.Element = current;
                epsLeg.Arc = _CompareArc.Reverse();
                break;
              case Line _:
                epsLeg.Element = current;
                epsLeg.Line = _CompareLine.Reverse();
                break;
              case NurbSpline _:
              case HermiteSpline _:
              case Ellipse _:
                epsLeg = RevitGeometry.GetLegFromSpline(current, curve, true);
                break;
            }
            epsLeg.Last.Next = _CurrentLeg;
            _CurrentLeg = epsLeg;
            flag = true;
          }
          else if (_CurrentLeg.LegStartPnt.IsEqual(new Eps_Point(curve.GetEndPoint(1))))
          {
            Eps_Leg epsLeg = new Eps_Leg();
            switch (curve)
            {
              case Arc _:
                epsLeg.Element = current;
                epsLeg.Arc = _CompareArc;
                break;
              case Line _:
                epsLeg.Element = current;
                epsLeg.Line = _CompareLine;
                break;
              case NurbSpline _:
              case HermiteSpline _:
              case Ellipse _:
                epsLeg = RevitGeometry.GetLegFromSpline(current, curve, false);
                break;
            }
            epsLeg.Last.Next = _CurrentLeg;
            _CurrentLeg = epsLeg;
            flag = true;
          }
          else if (_CurrentLeg.LegEndPnt.IsEqual(new Eps_Point(curve.GetEndPoint(0))))
          {
            Eps_Leg epsLeg = new Eps_Leg();
            switch (curve)
            {
              case Arc _:
                epsLeg.Element = current;
                epsLeg.Arc = _CompareArc;
                break;
              case Line _:
                epsLeg.Element = current;
                epsLeg.Line = _CompareLine;
                break;
              case NurbSpline _:
              case HermiteSpline _:
              case Ellipse _:
                epsLeg = RevitGeometry.GetLegFromSpline(current, curve, false);
                break;
            }
            _CurrentLeg.Last.Next = epsLeg;
            flag = true;
          }
          else if (_CurrentLeg.LegEndPnt.IsEqual(new Eps_Point(curve.GetEndPoint(1))))
          {
            Eps_Leg epsLeg = new Eps_Leg();
            switch (curve)
            {
              case Arc _:
                epsLeg.Element = current;
                epsLeg.Arc = _CompareArc.Reverse();
                break;
              case Line _:
                epsLeg.Element = current;
                epsLeg.Line = _CompareLine.Reverse();
                break;
              case NurbSpline _:
              case HermiteSpline _:
              case Ellipse _:
                epsLeg = RevitGeometry.GetLegFromSpline(current, curve, true);
                break;
            }
            _CurrentLeg.Last.Next = epsLeg;
            flag = true;
          }
          if (EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt))
            return _CurrentLeg;
          if (flag)
          {
            _CurrentLeg = RevitGeometry.GetLegFromElementList(_CurrentLeg, current);
            break;
          }
        }
      }
    }
    return _CurrentLeg;
  }

  public static void CreatePointListFromMinMaxOfArea(
    ref List<Eps_Point> _PointList,
    Eps_Point _LowerLeftPnt,
    Eps_Point _UpperRightPnt,
    double _dBaseLineAngle,
    double _dSpacing,
    bool _bSpacingType)
  {
    Eps_Point _MidPoint = new Eps_Point();
    double num1 = 0.0;
    double _dPolarDirection1 = 0.0;
    double _dDistance = 0.0;
    EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_LowerLeftPnt, _UpperRightPnt, ref _MidPoint);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_LowerLeftPnt, _UpperRightPnt, ref _dDistance);
    for (int index = 1; index <= 4; ++index)
    {
      switch (index)
      {
        case 1:
          _dPolarDirection1 = _dBaseLineAngle;
          num1 = 1.0;
          break;
        case 2:
          _dPolarDirection1 = EPShared.eplGeoE_NormalizeRadians(_dBaseLineAngle + Math.PI);
          num1 = 1.0;
          break;
        case 3:
          _dPolarDirection1 = EPShared.eplGeoE_NormalizeRadians(_dBaseLineAngle + Math.PI);
          num1 = -1.0;
          break;
        case 4:
          _dPolarDirection1 = _dBaseLineAngle;
          num1 = -1.0;
          break;
      }
      Eps_Point _NewPnt1 = new Eps_Point(_MidPoint);
      Eps_Point _NewPnt2 = new Eps_Point(_MidPoint);
      double num2 = _dDistance;
      int num3 = 1;
      while (num2 >= 0.0)
      {
        _NewPnt1 = new Eps_Point(_NewPnt2);
        RevitGeometry.AddBoundedPointToPointArray(ref _PointList, _NewPnt2, _LowerLeftPnt, _UpperRightPnt);
        for (double num4 = _dDistance; num4 >= 0.0; num4 -= _dSpacing)
        {
          EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, _dPolarDirection1, _dSpacing, ref _NewPnt1);
          RevitGeometry.AddBoundedPointToPointArray(ref _PointList, _NewPnt1, _LowerLeftPnt, _UpperRightPnt);
        }
        double num5 = !_bSpacingType ? Math.PI / 2.0 : (num3 % 2 <= 0 ? 2.0 * Math.PI / 3.0 : Math.PI / 3.0);
        double _dPolarDirection2 = EPShared.eplGeoE_NormalizeRadians(_dPolarDirection1 + num5 * num1);
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt2, _dPolarDirection2, _dSpacing, ref _NewPnt2);
        num2 -= _dSpacing;
        ++num3;
      }
    }
  }

  private static void AddBoundedPointToPointArray(
    ref List<Eps_Point> _PointList,
    Eps_Point _AddPoint,
    Eps_Point _LowerLeftPnt,
    Eps_Point _UpperRightPnt)
  {
    if (_LowerLeftPnt != null && _UpperRightPnt != null && (RevitDefines.LT(_AddPoint.x, _LowerLeftPnt.x) || RevitDefines.LT(_AddPoint.y, _LowerLeftPnt.y) || RevitDefines.GT(_AddPoint.x, _UpperRightPnt.x) || RevitDefines.GT(_AddPoint.y, _UpperRightPnt.y)))
      return;
    if (_PointList == null)
      _PointList = new List<Eps_Point>();
    bool flag = false;
    for (int index = 0; index < _PointList.Count; ++index)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(_PointList[index], _AddPoint, 1E-05))
      {
        flag = true;
        break;
      }
    }
    if (flag)
      return;
    _PointList.Add(_AddPoint);
  }

  public static void GetAllPointsInBoundary(
    ref List<Eps_Point> paPntList,
    Eps_Leg pLeg,
    List<Eps_Leg> pIslandList)
  {
    if (pLeg == null)
      return;
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    Eps_Point pMinPnt = new Eps_Point();
    Eps_Point pMaxPnt = new Eps_Point();
    if (paPntList == null || paPntList.Count == 0)
      return;
    RevitGeometry.eplGeoE_FindMinMaxOfLegList(pLeg, ref pMinPnt, ref pMaxPnt);
    for (int index1 = 0; index1 < paPntList.Count; ++index1)
    {
      if (RevitGeometry.eplGeoE_IsPointInsideLegList(pLeg, paPntList[index1], 1E-05, pMinPnt, pMaxPnt) != 6)
      {
        bool flag = true;
        if (pIslandList != null)
        {
          for (int index2 = 0; index2 < pIslandList.Count; ++index2)
          {
            if (RevitGeometry.eplGeoE_IsPointInsideLegList(pIslandList[index2], paPntList[index1]) != 6)
            {
              flag = false;
              break;
            }
          }
        }
        if (flag && (epsPointList.Count == 0 || !EPShared.eplGeoE_ArePntsDuplicates2D(paPntList[index1], epsPointList[epsPointList.Count - 1])))
          epsPointList.Add(paPntList[index1]);
      }
    }
    paPntList = epsPointList;
  }

  public static void RemoveAllPointsInBoundary(ref List<Eps_Point> paPntList, Eps_Leg pLeg)
  {
    if (pLeg == null)
      return;
    Eps_Point pMinPnt = new Eps_Point();
    Eps_Point pMaxPnt = new Eps_Point();
    if (paPntList == null || paPntList.Count == 0)
      return;
    RevitGeometry.eplGeoE_FindMinMaxOfLegList(pLeg, ref pMinPnt, ref pMaxPnt);
    for (int index = paPntList.Count - 1; index >= 0; --index)
    {
      if (RevitGeometry.eplGeoE_IsPointInsideLegList(pLeg, paPntList[index], 1E-05, pMinPnt, pMaxPnt) != 6 && paPntList.Count > 0)
        paPntList.RemoveAt(index);
    }
  }

  public static int SolveArcFromTangentLines(
    Eps_Line _pIn,
    Eps_Line _pOut,
    double _dRadius,
    ref Eps_Arc _pArc)
  {
    return RevitGeometry.SolveArcFromTangentLines(_pIn, _pOut, _dRadius, ref _pArc, false);
  }

  public static int SolveArcFromTangentLines(
    Eps_Line _pIn,
    Eps_Line _pOut,
    double _dRadius,
    ref Eps_Arc _pArc,
    bool _bVerifyTangentLength)
  {
    if (RevitDefines.EQ(_dRadius, 0.0))
      return 6;
    Eps_Arc _ArcStruct = new Eps_Arc();
    Eps_Point epsPoint = new Eps_Point();
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    double _dAngle = 0.0;
    Eps_Point startPnt = _pIn.StartPnt;
    Eps_Point endPnt1 = _pIn.EndPnt;
    Eps_Point endPnt2 = _pOut.EndPnt;
    _ArcStruct.Radius = _dRadius;
    if (EPShared.eplGeoE_CalcHorzAngByThreePnts(startPnt, endPnt1, endPnt2, 12, ref _dAngle, 1E-05) != 0)
      return 6;
    if (_dAngle > Math.PI)
    {
      _ArcStruct.Delta = _dAngle - Math.PI;
      _ArcStruct.Direction = -1;
    }
    else
    {
      _ArcStruct.Delta = Math.PI - _dAngle;
      _ArcStruct.Direction = 1;
    }
    double num = EPShared.eplGeoE_SolveTanLenByRadiusAndDelta(_dRadius, _ArcStruct.Delta);
    if (_bVerifyTangentLength)
    {
      if (RevitDefines.EQ(num, 0.0))
        return 6;
      double _dDistance = 0.0;
      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(endPnt1, startPnt, ref _dDistance);
      if (RevitDefines.GT(num, _dDistance))
        return 6;
      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(endPnt1, endPnt2, ref _dDistance);
      if (RevitDefines.GT(num, _dDistance))
        return 6;
    }
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(endPnt1, startPnt, ref _dDirection1);
    EPShared.eplGeoE_CalcPolarToXY(endPnt1, _dDirection1, num, ref epsPoint);
    _ArcStruct.StartPnt = epsPoint;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(endPnt1, endPnt2, ref _dDirection2);
    EPShared.eplGeoE_CalcPolarToXY(endPnt1, _dDirection2, num, ref epsPoint);
    _ArcStruct.EndPnt = epsPoint;
    EPShared.eplGeoE_CalcRadiusPointFromPCAndPIAndPT(_ArcStruct.StartPnt, endPnt1, _ArcStruct.EndPnt, ref epsPoint);
    _ArcStruct.RadiusPnt = epsPoint;
    EPShared.eplGeoE_CalcArcStructFromPCAndPTAndRP(_ArcStruct.StartPnt, _ArcStruct.RadiusPnt, _ArcStruct.EndPnt, _ArcStruct.Direction, ref _ArcStruct);
    _pArc = _ArcStruct;
    return 0;
  }

  public static double RandomDouble(double MinValue, double MaxValue)
  {
    Random random = new Random();
    int _dFirstOperand = random.Next();
    double num = MinValue;
    double _dSecondOperand = MaxValue - MinValue;
    return num + EPShared.eplCalE_fmod((double) _dFirstOperand, _dSecondOperand) + EPShared.eplCalE_fmod((double) random.Next(), 10000.0) * 0.0001;
  }

  public static int OffsetLegList(
    Eps_Leg pLegListToOffset,
    double OffsetDist,
    int OffsetDir,
    ref Eps_Leg ppOffsetLegList,
    bool TrimClosedObject)
  {
    int num = 0;
    if (pLegListToOffset == null)
      return 700;
    Eps_Leg pOrigLegList = Eps_Leg.CopyLeg(pLegListToOffset);
    if (num != 0)
      return num;
    ppOffsetLegList = new Eps_Leg();
    bool bClosedLegList = EPShared.eplGeoE_ArePntsDuplicates2D(pOrigLegList.LegStartPnt, pOrigLegList.LegEndPnt);
    int offsetLegs = RevitGeometry.FindOffsetLegs(pOrigLegList, OffsetDist, OffsetDir, ref ppOffsetLegList);
    if (offsetLegs == 0)
    {
      RevitGeometry.TrimOffsetLegs(ref ppOffsetLegList, bClosedLegList);
      RevitGeometry.TrimAdjacentArcs(ref ppOffsetLegList, bClosedLegList);
      if (bClosedLegList)
        RevitGeometry.CloseLegList(ref ppOffsetLegList);
      if (TrimClosedObject)
        RevitGeometry.RemoveCrossingLegs(ref ppOffsetLegList);
    }
    return offsetLegs;
  }

  private static void RemoveCrossingLegs(ref Eps_Leg pOffsetLegList)
  {
    Eps_Point epsPoint = new Eps_Point();
    Eps_Point[] paIntersections = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    if (pOffsetLegList.LegCount < 3)
      return;
    Eps_Leg pLeg1 = pOffsetLegList;
    Eps_Leg last = pLeg1.Last;
    if (RevitGeometry.IntersectTwoLegs(pOffsetLegList, last, ref epsPoint) == 0)
    {
      Eps_Leg epsLeg = (Eps_Leg) null;
      Eps_Leg pLeg2 = Eps_Leg.SingleLeg(pOffsetLegList);
      if (RevitGeometry.eplGeoE_IsPointOnLegList2D(epsPoint, pLeg2) && RevitGeometry.eplGeoE_IsPointOnLegList2D(epsPoint, last))
        RevitGeometry.CloseLegList(ref pOffsetLegList);
      epsLeg = (Eps_Leg) null;
    }
    for (; pLeg1 != null && pLeg1.Next != null; pLeg1 = pLeg1.Next)
    {
      for (Eps_Leg next = pLeg1.Next.Next; next != null; next = next.Next)
      {
        int pcNumIntersections = 0;
        int num = RevitGeometry.eplGeoE_IntersectTwoLegs(pLeg1, next, ref paIntersections, ref pcNumIntersections, 1E-05);
        if (num != 1600 && pcNumIntersections > 0)
        {
          if (pcNumIntersections == 1)
            epsPoint = new Eps_Point(paIntersections[0]);
          else if (pLeg1.Arc != null)
            RevitGeometry.GetClosestPoint(pLeg1.Arc.StartPnt, paIntersections, ref epsPoint);
          else if (pLeg1.Line != null)
            RevitGeometry.GetClosestPoint(pLeg1.Line.StartPnt, paIntersections, ref epsPoint);
          else
            num = 1600;
          if (num != 1600)
          {
            Eps_Point _FirstCheckPnt1 = new Eps_Point(pLeg1.LegStartPnt);
            Eps_Point _FirstCheckPnt2 = new Eps_Point(next.LegEndPnt);
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt1, epsPoint, 1E-05) && !EPShared.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt2, epsPoint, 1E-05))
            {
              RevitGeometry.TrimEndOfLeg(ref pLeg1, epsPoint);
              RevitGeometry.TrimStartOfLeg(ref next, epsPoint);
              RevitGeometry.RemoveLegsFromList(pLeg1, next);
            }
          }
        }
      }
    }
  }

  private static void RemoveLegsFromList(Eps_Leg pRemoveFromLeg, Eps_Leg pRemoveToLeg)
  {
    Eps_Leg next = pRemoveFromLeg.Next;
    while (next != pRemoveToLeg && next != null)
    {
      Eps_Leg epsLeg = next;
      next = next.Next;
      epsLeg = (Eps_Leg) null;
    }
    pRemoveFromLeg.Next = pRemoveToLeg;
  }

  private static void CloseLegList(ref Eps_Leg pLegList)
  {
    Eps_Leg pLeg1 = (Eps_Leg) null;
    Eps_Leg epsLeg = (Eps_Leg) null;
    Eps_Point pIntersectionPoint = new Eps_Point();
    Eps_Point pTrimPoint = new Eps_Point();
    if (pLegList.LegCount < 2 || EPShared.eplGeoE_ArePntsDuplicates2D(pLegList.LegStartPnt, pLegList.LegEndPnt))
      return;
    if (pLegList.LegCount == 2 && pLegList.Arc != null && pLegList.Next.Arc != null)
    {
      RevitGeometry.CloseLegListWithTwoArcsOnly(pLegList, pLegList.Next);
    }
    else
    {
      Eps_Leg pLeg2;
      for (pLeg2 = pLegList; pLeg2 != null && pLeg2.Next != null; pLeg2 = pLeg2.Next)
      {
        for (Eps_Leg next = pLeg2.Next.Next; next != null; next = next.Next)
        {
          if (RevitGeometry.IntersectTwoLegs(pLeg2, next, ref pIntersectionPoint) == 0)
          {
            pLeg1 = next;
            pTrimPoint = new Eps_Point(pIntersectionPoint);
            Eps_Leg pLeg3 = next;
            pLeg3.Next = (Eps_Leg) null;
            Eps_Leg pLeg4 = pLeg2;
            pLeg4.Next = (Eps_Leg) null;
            if (!RevitGeometry.eplGeoE_IsPointOnLegList2D(pIntersectionPoint, pLeg3) || !RevitGeometry.eplGeoE_IsPointOnLegList2D(pIntersectionPoint, pLeg4))
              pLeg1 = (Eps_Leg) null;
            else
              break;
          }
        }
        if (pLeg1 == null)
          epsLeg = pLeg2;
        else
          break;
      }
      if (pLeg2 == null || pLeg1 == null)
        return;
      RevitGeometry.TrimStartOfLeg(ref pLeg2, pTrimPoint);
      RevitGeometry.TrimEndOfLeg(ref pLeg1, pTrimPoint);
      if (pLeg2 != pLegList)
      {
        epsLeg.Next = (Eps_Leg) null;
        pLegList = pLeg2;
      }
      pLeg1.Next = (Eps_Leg) null;
    }
  }

  private static void CloseLegListWithTwoArcsOnly(Eps_Leg pFirstLeg, Eps_Leg pSecondLeg)
  {
    Eps_Point[] InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    Eps_Point pClosestPoint = new Eps_Point();
    if (RevitGeometry.eplGeoE_IntersectTwoDists2D(pFirstLeg.Arc.RadiusPnt, pFirstLeg.Arc.Radius, pSecondLeg.Arc.RadiusPnt, pSecondLeg.Arc.Radius, ref InterPnt, 0.01) != 1607)
      return;
    RevitGeometry.GetClosestPoint(pFirstLeg.Arc.StartPnt, InterPnt, ref pClosestPoint);
    RevitGeometry.TrimStartOfLeg(ref pFirstLeg, pClosestPoint);
    RevitGeometry.TrimEndOfLeg(ref pSecondLeg, pClosestPoint);
  }

  public static int FindOffsetLegs(
    Eps_Leg pOrigLegList,
    double OffsetDist,
    int OffsetDir,
    ref Eps_Leg ppOffsetLegList)
  {
    int offsetLegs = 0;
    for (Eps_Leg epsLeg1 = pOrigLegList; epsLeg1 != null; epsLeg1 = epsLeg1.Next)
    {
      Eps_Leg epsLeg2 = new Eps_Leg();
      epsLeg2.Element = epsLeg1.Element;
      if (epsLeg1.Arc != null)
      {
        Eps_Arc _OffsetArc = new Eps_Arc();
        offsetLegs = EPShared.eplGeoE_ConstructOffsetArc(epsLeg1.Arc, OffsetDist, OffsetDir, ref _OffsetArc);
        epsLeg2.Arc = _OffsetArc;
        epsLeg2.Arc.StartPnt.z = epsLeg1.Arc.StartPnt.z;
        epsLeg2.Arc.EndPnt.z = epsLeg1.Arc.EndPnt.z;
        epsLeg2.Arc.RadiusPnt.z = epsLeg1.Arc.RadiusPnt.z;
      }
      else if (epsLeg1.Line != null)
      {
        Eps_Line _OffsetLine = new Eps_Line();
        offsetLegs = EPShared.eplGeoE_ConstructOffsetLine(epsLeg1.Line, OffsetDist, OffsetDir, ref _OffsetLine);
        epsLeg2.Line = _OffsetLine;
        epsLeg2.Line.StartPnt.z = epsLeg1.Line.StartPnt.z;
        epsLeg2.Line.EndPnt.z = epsLeg1.Line.EndPnt.z;
      }
      else
        offsetLegs = 700;
      if (offsetLegs == 0)
      {
        epsLeg2.SplineNum = -1;
        epsLeg2.Is3D = epsLeg1.Is3D;
        epsLeg2.Next = (Eps_Leg) null;
        if (RevitDefines.GT(RevitGeometry.eplGeoE_CalcLegListLength(epsLeg2), 0.0))
        {
          if (ppOffsetLegList.LegCount == 0)
            ppOffsetLegList = Eps_Leg.SingleLeg(epsLeg2);
          else
            ppOffsetLegList.Last.Next = Eps_Leg.SingleLeg(epsLeg2);
        }
      }
    }
    return offsetLegs;
  }

  private static void TrimOffsetLegs(ref Eps_Leg pOffsetLegList, bool bClosedLegList)
  {
    Eps_Leg pLeg1 = (Eps_Leg) null;
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    Eps_Point epsPoint3 = new Eps_Point();
    Eps_Point pIntersectionPoint1 = new Eps_Point();
    bool flag = false;
    Eps_Point pIntersectionPoint2 = new Eps_Point();
    int num = 0;
    if (pOffsetLegList.LegCount < 2)
      return;
    if (bClosedLegList)
    {
      pLeg1 = pOffsetLegList.Last;
      if (RevitGeometry.IntersectTwoLegs(pLeg1, pOffsetLegList, ref pIntersectionPoint1) != 0)
      {
        if (pLeg1.Line != null)
        {
          epsPoint1 = new Eps_Point(pLeg1.Line.StartPnt);
          epsPoint2 = new Eps_Point(pLeg1.Line.EndPnt);
        }
        else if (pLeg1.Arc != null)
        {
          epsPoint1 = new Eps_Point(pLeg1.Arc.StartPnt);
          epsPoint2 = new Eps_Point(pLeg1.Arc.EndPnt);
        }
        else
          num = 1600;
        if (pOffsetLegList.Line != null)
          epsPoint3 = new Eps_Point(pOffsetLegList.Line.StartPnt);
        else if (pOffsetLegList.Arc != null)
          epsPoint3 = new Eps_Point(pOffsetLegList.Arc.StartPnt);
        else
          num = 1600;
        if (num == 0)
        {
          Eps_Leg epsLeg2 = new Eps_Leg();
          epsLeg2.Arc = new Eps_Arc();
          epsLeg2.Arc.StartPnt = new Eps_Point(epsPoint2);
          epsLeg2.Arc.EndPnt = new Eps_Point(epsPoint3);
          epsLeg2.Arc.Delta = Math.PI;
          Eps_Point _MidPoint = new Eps_Point();
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsPoint2, epsPoint3, ref _MidPoint);
          epsLeg2.Arc.RadiusPnt = new Eps_Point(_MidPoint);
          double _dDistance = 0.0;
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsPoint2, epsLeg2.Arc.RadiusPnt, ref _dDistance);
          epsLeg2.Arc.Radius = _dDistance;
          if ((epsPoint2.x - epsPoint1.x) * (epsPoint3.y - epsPoint1.y) - (epsPoint3.x - epsPoint1.x) * (epsPoint2.y - epsPoint1.y) > 0.0)
            epsLeg2.Arc.Direction = 1;
          else
            epsLeg2.Arc.Direction = -1;
          pLeg1.Next = epsLeg2;
          epsLeg1 = (Eps_Leg) null;
        }
      }
      else
        flag = true;
    }
    Eps_Leg pLeg2 = Eps_Leg.CopyLeg(pOffsetLegList);
    Eps_Leg pLeg3 = Eps_Leg.CopyLeg(pOffsetLegList.Next);
    pOffsetLegList = (Eps_Leg) null;
    for (; pLeg3 != null; pLeg3 = pLeg3.Next)
    {
      if (RevitGeometry.IntersectTwoLegs(pLeg2, pLeg3, ref pIntersectionPoint2) == 0)
      {
        RevitGeometry.TrimEndOfLeg(ref pLeg2, pIntersectionPoint2);
        RevitGeometry.TrimStartOfLeg(ref pLeg3, pIntersectionPoint2);
      }
      else
      {
        if (pLeg2.Line != null)
        {
          epsPoint1 = new Eps_Point(pLeg2.Line.StartPnt);
          epsPoint2 = new Eps_Point(pLeg2.Line.EndPnt);
        }
        else if (pLeg3.Arc != null)
        {
          epsPoint1 = new Eps_Point(pLeg2.Arc.StartPnt);
          epsPoint2 = new Eps_Point(pLeg2.Arc.EndPnt);
        }
        else
          num = 1600;
        if (pLeg3.Line != null)
          epsPoint3 = pLeg3.Line.StartPnt;
        else if (pLeg3.Arc != null)
          epsPoint3 = pLeg3.Arc.StartPnt;
        else
          num = 1600;
        if (num == 0)
        {
          Eps_Leg epsLeg3 = new Eps_Leg();
          epsLeg3.Arc = new Eps_Arc();
          epsLeg3.Arc.StartPnt = new Eps_Point(epsPoint2);
          epsLeg3.Arc.EndPnt = new Eps_Point(epsPoint3);
          epsLeg3.Arc.Delta = Math.PI;
          Eps_Point _MidPoint = new Eps_Point();
          EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(epsPoint2, epsPoint3, ref _MidPoint);
          epsLeg3.Arc.RadiusPnt = new Eps_Point(_MidPoint);
          double _dDistance = 0.0;
          EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsPoint2, epsLeg3.Arc.RadiusPnt, ref _dDistance);
          epsLeg3.Arc.Radius = _dDistance;
          if ((epsPoint2.x - epsPoint1.x) * (epsPoint3.y - epsPoint1.y) - (epsPoint3.x - epsPoint1.x) * (epsPoint2.y - epsPoint1.y) > 0.0)
            epsLeg3.Arc.Direction = 1;
          else
            epsLeg3.Arc.Direction = -1;
          epsLeg3.Next = pLeg3;
          pLeg2.Next = pLeg3 = epsLeg3;
          epsLeg1 = (Eps_Leg) null;
        }
      }
      if (pOffsetLegList == null)
        pOffsetLegList = Eps_Leg.SingleLeg(pLeg2);
      else
        pOffsetLegList.Last.Next = Eps_Leg.SingleLeg(pLeg2);
      pLeg2 = pLeg2.Next;
    }
    if (pOffsetLegList == null)
      pOffsetLegList = Eps_Leg.SingleLeg(pLeg2);
    else
      pOffsetLegList.Last.Next = Eps_Leg.SingleLeg(pLeg2);
    if (!bClosedLegList || !flag)
      return;
    RevitGeometry.TrimEndOfLeg(ref pLeg1, pIntersectionPoint1);
    RevitGeometry.TrimStartOfLeg(ref pOffsetLegList, pIntersectionPoint1);
  }

  private static void TrimAdjacentArcs(ref Eps_Leg pOffsetLegList, bool bClosedLegList)
  {
    Eps_Point pClosestPoint = new Eps_Point();
    Eps_Point[] paIntersections = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int legCount = pOffsetLegList.LegCount;
    if (legCount < 2 || legCount == 2 && bClosedLegList)
      return;
    Eps_Leg pLeg1 = Eps_Leg.CopyLeg(pOffsetLegList);
    Eps_Leg pLeg2 = Eps_Leg.CopyLeg(pOffsetLegList.Next);
    pOffsetLegList = (Eps_Leg) null;
    for (; pLeg2 != null; pLeg2 = pLeg2.Next)
    {
      if (pLeg1.Arc != null && pLeg2.Arc != null)
      {
        int pcNumIntersections = 0;
        if (RevitGeometry.eplGeoE_IntersectTwoLegs(pLeg1, pLeg2, ref paIntersections, ref pcNumIntersections, 0.01) != 1600 && pcNumIntersections > 1)
        {
          RevitGeometry.GetClosestPointAlongArc(pLeg1.Arc, paIntersections, ref pClosestPoint);
          RevitGeometry.TrimEndOfLeg(ref pLeg1, pClosestPoint);
          RevitGeometry.TrimStartOfLeg(ref pLeg2, pClosestPoint);
        }
      }
      if (pOffsetLegList == null)
        pOffsetLegList = Eps_Leg.SingleLeg(pLeg1);
      else
        pOffsetLegList.Last.Next = Eps_Leg.SingleLeg(pLeg1);
      pLeg1 = pLeg1.Next;
    }
    if (pOffsetLegList == null)
      pOffsetLegList = Eps_Leg.SingleLeg(pLeg1);
    else
      pOffsetLegList.Last.Next = Eps_Leg.SingleLeg(pLeg1);
  }

  private static int IntersectTwoLegs(
    Eps_Leg pCurrLeg,
    Eps_Leg pNextLeg,
    ref Eps_Point pIntersectionPoint)
  {
    int num = 1600;
    if (pCurrLeg.Arc != null)
    {
      if (pNextLeg.Arc != null)
        num = RevitGeometry.IntersectTwoArcs(pCurrLeg.Arc, pNextLeg.Arc, ref pIntersectionPoint);
      else if (pNextLeg.Line != null)
        num = RevitGeometry.IntersectArcLine(pNextLeg.Line, pCurrLeg.Arc, ref pIntersectionPoint);
    }
    else if (pCurrLeg.Line != null)
    {
      if (pNextLeg.Arc != null)
        num = RevitGeometry.IntersectLineArc(pCurrLeg.Line, pNextLeg.Arc, ref pIntersectionPoint);
      else if (pNextLeg.Line != null)
        num = RevitGeometry.IntersectTwoLines(pCurrLeg.Line, pNextLeg.Line, ref pIntersectionPoint);
    }
    return num;
  }

  private static int IntersectTwoLines(
    Eps_Line pCurrLine,
    Eps_Line pNextLine,
    ref Eps_Point pIntersectionPoint)
  {
    double _dDirection1 = 0.0;
    double _dDirection2 = 0.0;
    double _dDirection3 = 0.0;
    double _dDirection4 = 0.0;
    if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(pCurrLine.StartPnt, pCurrLine.EndPnt, ref _dDirection1) != 0 || EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(pNextLine.EndPnt, pNextLine.StartPnt, ref _dDirection2) != 0)
      return 1600;
    int num;
    if (EPShared.eplGeoE_IntersectTwoDirs2D(pCurrLine.StartPnt, _dDirection1, pNextLine.EndPnt, _dDirection2, ref pIntersectionPoint, 1E-05) == 1103)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(pCurrLine.EndPnt, pNextLine.StartPnt, 1E-05))
      {
        pIntersectionPoint = new Eps_Point(pCurrLine.EndPnt);
        num = 0;
      }
      else
      {
        if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(pCurrLine.EndPnt, pNextLine.StartPnt, ref _dDirection3) != 0 || EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(pNextLine.EndPnt, pCurrLine.StartPnt, ref _dDirection4) != 0)
          return 1600;
        if (RevitDefines.EQ(_dDirection3, _dDirection1) || RevitDefines.EQ(_dDirection3, _dDirection2) || RevitDefines.EQ(_dDirection4, _dDirection1) || RevitDefines.EQ(_dDirection4, _dDirection2))
        {
          pIntersectionPoint = new Eps_Point(pCurrLine.EndPnt);
          num = 0;
        }
        else
          num = 1600;
      }
    }
    else
      num = 0;
    return num;
  }

  private static int IntersectLineArc(
    Eps_Line pCurrLine,
    Eps_Arc pNextArc,
    ref Eps_Point pIntersectionPoint)
  {
    Eps_Point[] InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int num;
    switch (RevitGeometry.eplGeoE_IntersectLineArc(pCurrLine, pNextArc, ref InterPnt, 0.01))
    {
      case 1606:
      case 1612:
        pIntersectionPoint = new Eps_Point(InterPnt[0]);
        num = 0;
        break;
      case 1607:
      case 1613:
        RevitGeometry.GetClosestPoint(pCurrLine.EndPnt, InterPnt, ref pIntersectionPoint);
        num = 0;
        break;
      default:
        double _dDirection = 0.0;
        Eps_Point[] paPoints = new Eps_Point[2]
        {
          new Eps_Point(),
          new Eps_Point()
        };
        if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(pCurrLine.StartPnt, pCurrLine.EndPnt, ref _dDirection) != 0)
          return 1600;
        double radius = pNextArc.Radius;
        switch (RevitGeometry.eplGeoE_IntersectDirDist2D(pCurrLine.StartPnt, _dDirection, pNextArc.RadiusPnt, radius, ref InterPnt, 0.01))
        {
          case 1606:
            paPoints[0] = new Eps_Point(InterPnt[0]);
            pIntersectionPoint = new Eps_Point(InterPnt[0]);
            num = RevitGeometry.eplGeoE_IntersectDirDist2D(pCurrLine.EndPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), pNextArc.RadiusPnt, radius, ref InterPnt, 0.01);
            if (num == 1606)
            {
              paPoints[1] = new Eps_Point(InterPnt[0]);
              RevitGeometry.GetClosestPoint(pCurrLine.EndPnt, paPoints, ref pIntersectionPoint);
              num = 0;
              break;
            }
            break;
          case 1607:
            RevitGeometry.GetClosestPoint(pCurrLine.EndPnt, InterPnt, ref pIntersectionPoint);
            num = 0;
            break;
          default:
            num = 1600;
            break;
        }
        break;
    }
    return num;
  }

  private static int IntersectArcLine(
    Eps_Line pNextLine,
    Eps_Arc pCurrArc,
    ref Eps_Point pIntersectionPoint)
  {
    Eps_Point[] InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int num1;
    switch (RevitGeometry.eplGeoE_IntersectLineArc(pNextLine, pCurrArc, ref InterPnt, 0.01))
    {
      case 1606:
      case 1612:
        pIntersectionPoint = new Eps_Point(InterPnt[0]);
        num1 = 0;
        break;
      case 1607:
      case 1613:
        RevitGeometry.GetClosestPoint(pNextLine.EndPnt, InterPnt, ref pIntersectionPoint);
        num1 = 0;
        break;
      default:
        int num2 = 1600;
        double _dDirection = 0.0;
        Eps_Point[] paPoints = new Eps_Point[2]
        {
          new Eps_Point(),
          new Eps_Point()
        };
        if (EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(pNextLine.EndPnt, pNextLine.StartPnt, ref _dDirection) != 0)
          return 1600;
        double radius = pCurrArc.Radius;
        switch (RevitGeometry.eplGeoE_IntersectDirDist2D(pNextLine.EndPnt, _dDirection, pCurrArc.RadiusPnt, radius, ref InterPnt, 0.01))
        {
          case 1606:
            paPoints[0] = new Eps_Point(InterPnt[0]);
            pIntersectionPoint = new Eps_Point(InterPnt[0]);
            if (RevitGeometry.eplGeoE_IntersectDirDist2D(pNextLine.StartPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI), pCurrArc.RadiusPnt, radius, ref InterPnt, 0.01) == 1606)
            {
              paPoints[1] = new Eps_Point(InterPnt[0]);
              RevitGeometry.GetClosestPoint(pCurrArc.EndPnt, paPoints, ref pIntersectionPoint);
              num2 = 0;
            }
            num1 = 0;
            break;
          case 1607:
            RevitGeometry.GetClosestPoint(pCurrArc.EndPnt, InterPnt, ref pIntersectionPoint);
            num1 = 0;
            break;
          default:
            num1 = 1600;
            break;
        }
        break;
    }
    return num1;
  }

  private static int IntersectTwoArcs(
    Eps_Arc pCurrArc,
    Eps_Arc pNextArc,
    ref Eps_Point pIntersectionPoint)
  {
    Eps_Point[] InterPnt = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int num;
    switch (RevitGeometry.eplGeoE_IntersectTwoDists2D(pCurrArc.RadiusPnt, pCurrArc.Radius, pNextArc.RadiusPnt, pNextArc.Radius, ref InterPnt, 0.01))
    {
      case 1604:
        num = 0;
        if (EPShared.eplGeoE_ArePntsDuplicates3D(pCurrArc.EndPnt, pNextArc.StartPnt))
        {
          pIntersectionPoint = new Eps_Point(pNextArc.StartPnt);
          break;
        }
        if (EPShared.eplGeoE_ArePntsDuplicates3D(pCurrArc.StartPnt, pNextArc.EndPnt))
        {
          pIntersectionPoint = new Eps_Point(pNextArc.EndPnt);
          break;
        }
        num = 1600;
        break;
      case 1606:
        pIntersectionPoint = new Eps_Point(InterPnt[0]);
        num = 0;
        break;
      case 1607:
        RevitGeometry.GetClosestPoint(pCurrArc.EndPnt, InterPnt, ref pIntersectionPoint);
        num = 0;
        break;
      default:
        num = 1600;
        break;
    }
    return num;
  }

  private static void GetClosestPoint(
    Eps_Point pPoint,
    Eps_Point[] paPoints,
    ref Eps_Point pClosestPoint)
  {
    double _dDistance1 = 0.0;
    double _dDistance2 = 0.0;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(pPoint, paPoints[0], ref _dDistance1);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(pPoint, paPoints[1], ref _dDistance2);
    if (_dDistance1 <= _dDistance2)
      pClosestPoint = new Eps_Point(paPoints[0]);
    else
      pClosestPoint = new Eps_Point(paPoints[1]);
  }

  public static void TrimStartOfLeg(ref Eps_Leg pLeg, Eps_Point pTrimPoint)
  {
    if (pLeg.Arc != null)
    {
      pTrimPoint.z = pLeg.Arc.StartPnt.z;
      bool flag = EPShared.eplGeoE_ArePntsDuplicates2D(pLeg.Arc.StartPnt, pTrimPoint);
      pLeg.Arc.StartPnt = new Eps_Point(pTrimPoint);
      if (flag)
        return;
      Eps_Arc _ArcStruct = new Eps_Arc();
      EPShared.eplGeoE_CalcArcStructFromPCAndPTAndRP(pLeg.Arc.StartPnt, pLeg.Arc.RadiusPnt, pLeg.Arc.EndPnt, pLeg.Arc.Direction, ref _ArcStruct);
      pLeg.Arc = _ArcStruct;
    }
    else
    {
      if (pLeg.Line == null)
        return;
      pTrimPoint.z = pLeg.Line.StartPnt.z;
      pLeg.Line.StartPnt = new Eps_Point(pTrimPoint);
    }
  }

  public static void TrimEndOfLeg(ref Eps_Leg pLeg, Eps_Point pTrimPoint)
  {
    if (pLeg.Arc != null)
    {
      pTrimPoint.z = pLeg.Arc.EndPnt.z;
      bool flag = EPShared.eplGeoE_ArePntsDuplicates2D(pLeg.Arc.EndPnt, pTrimPoint);
      pLeg.Arc.EndPnt = new Eps_Point(pTrimPoint);
      if (flag)
        return;
      Eps_Arc _ArcStruct = new Eps_Arc();
      EPShared.eplGeoE_CalcArcStructFromPCAndPTAndRP(pLeg.Arc.StartPnt, pLeg.Arc.RadiusPnt, pLeg.Arc.EndPnt, pLeg.Arc.Direction, ref _ArcStruct);
      pLeg.Arc = _ArcStruct;
    }
    else
    {
      if (pLeg.Line == null)
        return;
      pTrimPoint.z = pLeg.Line.EndPnt.z;
      pLeg.Line.EndPnt = new Eps_Point(pTrimPoint);
    }
  }

  private static void GetClosestPointAlongArc(
    Eps_Arc pArc,
    Eps_Point[] paPoints,
    ref Eps_Point pClosestPoint)
  {
    double _dStation1 = 99999.0;
    double _dStation2 = 99999.0;
    double _dOffset = 0.0;
    EPShared.eplGeoE_CalcStationOffsetAlongArc(paPoints[0], pArc, ref _dStation1, ref _dOffset);
    EPShared.eplGeoE_CalcStationOffsetAlongArc(paPoints[1], pArc, ref _dStation2, ref _dOffset);
    if (_dStation1 <= _dStation2)
      pClosestPoint = new Eps_Point(paPoints[0]);
    else
      pClosestPoint = new Eps_Point(paPoints[1]);
  }

  public static void CalcMinMax(Eps_Point pPoint, ref Eps_Point pMinPnt, ref Eps_Point pMaxPnt)
  {
    pMinPnt.x = Math.Min(pMinPnt.x, pPoint.x);
    pMaxPnt.x = Math.Max(pMaxPnt.x, pPoint.x);
    pMinPnt.y = Math.Min(pMinPnt.y, pPoint.y);
    pMaxPnt.y = Math.Max(pMaxPnt.y, pPoint.y);
    pMinPnt.z = Math.Min(pMinPnt.z, pPoint.z);
    pMaxPnt.z = Math.Max(pMaxPnt.z, pPoint.z);
  }

  private static int CheckLinesForCommonEndPnts(
    Eps_Line LineOne,
    Eps_Line LineTwo,
    double PointTolerance)
  {
    int num = 1110;
    bool flag1 = EPShared.eplGeoE_ArePntsDuplicates2D(LineOne.StartPnt, LineTwo.StartPnt, PointTolerance);
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(LineOne.EndPnt, LineTwo.EndPnt, PointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(LineOne.StartPnt, LineTwo.EndPnt, PointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(LineOne.EndPnt, LineTwo.StartPnt, PointTolerance);
    if (flag1 && flag2)
      num = 1108;
    else if (flag3 && flag4)
      num = 1109;
    else if (flag1)
      num = 1614;
    else if (flag2)
      num = 1615;
    else if (flag3)
      num = 1616;
    else if (flag4)
      num = 1617;
    return num;
  }

  private static int ChkIfArcsOverlapOrWithIn2D(
    Eps_Arc ArcOne,
    Eps_Arc ArcTwo,
    ref Eps_Point[] InterPnt,
    double PointTolerance)
  {
    int num = 1600;
    InterPnt[0].z = ArcOne.StartPnt.z;
    InterPnt[1].z = ArcOne.StartPnt.z;
    bool flag1 = ArcOne.Direction == ArcTwo.Direction;
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.StartPnt, ArcTwo.StartPnt, PointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.EndPnt, ArcTwo.EndPnt, PointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.StartPnt, ArcTwo.EndPnt, PointTolerance);
    bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.EndPnt, ArcTwo.StartPnt, PointTolerance);
    if (flag2 || flag4 || flag5 || flag3)
      num = 1612;
    bool flag6 = EPShared.eplGeoE_IsPointOnArc2D(ArcOne.StartPnt, ArcTwo, PointTolerance);
    bool flag7 = EPShared.eplGeoE_IsPointOnArc2D(ArcOne.EndPnt, ArcTwo, PointTolerance);
    bool flag8 = EPShared.eplGeoE_IsPointOnArc2D(ArcTwo.StartPnt, ArcOne, PointTolerance);
    bool flag9 = EPShared.eplGeoE_IsPointOnArc2D(ArcTwo.EndPnt, ArcOne, PointTolerance);
    if (EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.RadiusPnt, ArcTwo.RadiusPnt, PointTolerance) && Math.Abs(ArcOne.Radius - ArcTwo.Radius) <= 1E-05)
    {
      if (ArcOne.Delta + ArcTwo.Delta > 2.0 * Math.PI && flag6 && flag7 && flag8 && flag9)
      {
        if (ArcOne.Delta > ArcTwo.Delta)
        {
          InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
          InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
        }
        else
        {
          InterPnt[0] = new Eps_Point(ArcTwo.StartPnt);
          InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        }
        return num == 1612 ? 1619 : 1620;
      }
      if (num == 1612)
      {
        if (flag2)
        {
          if (flag7)
          {
            InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
            return 1618;
          }
          if (!flag9)
            return 1612;
          InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
          return 1618;
        }
        if (flag3)
        {
          if (flag6)
          {
            InterPnt[1] = new Eps_Point(ArcOne.StartPnt);
            return 1618;
          }
          if (!flag8)
            return 1612;
          InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
          return 1618;
        }
        if (flag4)
        {
          if (flag7)
          {
            InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
            return 1618;
          }
          if (!flag8)
            return 1612;
          InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
          return 1618;
        }
        if (flag5)
        {
          if (flag6)
          {
            InterPnt[1] = new Eps_Point(ArcOne.StartPnt);
            return 1618;
          }
          if (!flag9)
            return 1612;
          InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
          return 1618;
        }
      }
      if (flag6 && flag7)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
        return 1610;
      }
      if (flag8 && flag9)
      {
        InterPnt[0] = new Eps_Point(ArcTwo.StartPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        return 1611;
      }
      if (flag6 && flag9)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        return 1608;
      }
      if (flag6 && flag8)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
        return 1608;
      }
      if (flag7 && flag8)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
        return 1608;
      }
      if (flag7 && flag9)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        return 1608;
      }
    }
    return 1609;
  }

  private static bool IsPntInBoundingBoxOfLine(Eps_Point pPoint, Eps_Line pLine, double Tolerance)
  {
    return !RevitDefines.LT(Math.Max(pLine.StartPnt.x, pLine.EndPnt.x), pPoint.x, Tolerance) && !RevitDefines.GT(Math.Min(pLine.StartPnt.x, pLine.EndPnt.x), pPoint.x, Tolerance) && !RevitDefines.LT(Math.Max(pLine.StartPnt.y, pLine.EndPnt.y), pPoint.y, Tolerance) && !RevitDefines.GT(Math.Min(pLine.StartPnt.y, pLine.EndPnt.y), pPoint.y, Tolerance);
  }

  private static void CalculateInterPnt(
    Eps_Line pLineOne,
    Eps_Line pLineTwo,
    ref Eps_Point[] aInterPnt)
  {
    Eps_Point _Vector1 = new Eps_Point();
    Eps_Point _Vector2 = new Eps_Point();
    Eps_Point _Vector3 = new Eps_Point();
    EPShared.eplGeoE_MakeVector(pLineOne.StartPnt, pLineOne.EndPnt, ref _Vector1);
    EPShared.eplGeoE_MakeVector(pLineTwo.StartPnt, pLineTwo.EndPnt, ref _Vector2);
    EPShared.eplGeoE_MakeVector(pLineOne.StartPnt, pLineTwo.EndPnt, ref _Vector3);
    double _dX = EPShared.eplCalE_CalcComponentKOfCrossProduct(_Vector1, _Vector2);
    double num1 = EPShared.eplCalE_CalcComponentKOfCrossProduct(_Vector3, _Vector2);
    if (RevitDefines.EQ(_dX, 0.0, 1E-10))
      _dX = 1E-10;
    double num2 = Math.Abs(num1 / _dX);
    aInterPnt[0].x = pLineOne.StartPnt.x + num2 * _Vector1.x;
    aInterPnt[0].y = pLineOne.StartPnt.y + num2 * _Vector1.y;
    aInterPnt[0].z = 0.0;
  }

  public static double CalculateDirection(double _dHorizontal, double _dVertical)
  {
    return Math.Atan(_dVertical / _dHorizontal);
  }

  public static int eplGeoE_CalcMidPointBetweenTwoPoints3D(
    Eps_Point _StartPnt,
    Eps_Point _EndPnt,
    ref Eps_Point _MidPoint)
  {
    int num = EPShared.eplGeoE_CalcMidPointBetweenTwoPoints(_StartPnt, _EndPnt, ref _MidPoint);
    if (num == 0)
      _MidPoint.z = (_StartPnt.z + _EndPnt.z) / 2.0;
    return num;
  }

  public static int AddVertexToLegList(
    Eps_Leg _CurrLegList,
    Eps_Point _AddPoint,
    ref Eps_Leg _NewLegList)
  {
    double _dStation = 0.0;
    double _dOffset = 0.0;
    double num1 = 0.0;
    double _dDistance = 0.0;
    double num2 = 0.0;
    int legList = 506;
    if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_AddPoint, _CurrLegList, ref _dStation, ref _dOffset, true) == 1700)
    {
      for (Eps_Leg epsLeg = _CurrLegList; epsLeg != null; epsLeg = epsLeg.Next)
      {
        double _dX = RevitGeometry.eplGeoE_CalcLegLength(epsLeg);
        if (RevitDefines.LE(_dX, 0.0) && num1 + _dX < _dStation)
          num1 += _dX;
        else if (legList != 0 && _dStation - (num1 + _dX) <= 1E-05)
        {
          Eps_Point epsPoint1 = (Eps_Point) null;
          Eps_Point epsPoint2 = (Eps_Point) null;
          if (epsLeg.Line != null)
          {
            epsPoint1 = new Eps_Point(epsLeg.Line.StartPnt);
            epsPoint2 = new Eps_Point(epsLeg.Line.EndPnt);
            EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsPoint1, epsPoint2, ref _dDistance);
          }
          else if (epsLeg.Arc != null)
          {
            epsPoint1 = new Eps_Point(epsLeg.Arc.StartPnt);
            epsPoint2 = new Eps_Point(epsLeg.Arc.EndPnt);
            _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta);
          }
          if (EPShared.eplGeoE_ArePntsDuplicates2D(_AddPoint, epsPoint1) || EPShared.eplGeoE_ArePntsDuplicates2D(_AddPoint, epsPoint2))
            return 1;
          double num3 = (epsPoint2.z - epsPoint1.z) / _dDistance * (_dStation - num1);
          Eps_Leg _CompleteLeg1 = new Eps_Leg();
          Eps_Point _Point = new Eps_Point(_AddPoint);
          _Point.z = epsPoint1.z + num3;
          _CompleteLeg1.Line = new Eps_Line();
          _CompleteLeg1.Line.StartPnt = new Eps_Point(epsPoint1);
          _CompleteLeg1.Line.EndPnt = new Eps_Point(_Point);
          if (_NewLegList == null)
            _NewLegList = Eps_Leg.SingleLeg(_CompleteLeg1);
          else
            _NewLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
          Eps_Leg _CompleteLeg2 = new Eps_Leg();
          _CompleteLeg2.Line = new Eps_Line();
          _CompleteLeg2.Line.StartPnt = new Eps_Point(_Point);
          _CompleteLeg2.Line.EndPnt = new Eps_Point(epsPoint2);
          _NewLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
          legList = 0;
        }
        else
        {
          num1 += _dX;
          if (_NewLegList == null)
            _NewLegList = Eps_Leg.SingleLeg(epsLeg);
          else
            _NewLegList.Last.Next = Eps_Leg.SingleLeg(epsLeg);
        }
      }
    }
    else if (RevitDefines.LE(_dStation, 0.0))
    {
      if (_CurrLegList.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CurrLegList.Line.StartPnt, _CurrLegList.Line.EndPnt, ref _dDistance);
        num2 = _CurrLegList.Line.EndPnt.z - _CurrLegList.Line.StartPnt.z;
      }
      else if (_CurrLegList.Arc != null)
      {
        _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_CurrLegList.Arc.Radius, _CurrLegList.Arc.Delta);
        num2 = _CurrLegList.Arc.EndPnt.z - _CurrLegList.Arc.StartPnt.z;
      }
      double num4 = num2 / _dDistance * Math.Abs(_dStation);
      Eps_Point _Point = new Eps_Point(_AddPoint);
      _Point.z = _CurrLegList.LegStartPnt.z - num4;
      Eps_Leg _CompleteLeg = new Eps_Leg();
      _CompleteLeg.Line = new Eps_Line();
      _CompleteLeg.Line.StartPnt = new Eps_Point(_Point);
      _CompleteLeg.Line.EndPnt = new Eps_Point(_CurrLegList.LegStartPnt);
      _NewLegList = Eps_Leg.SingleLeg(_CompleteLeg);
      _NewLegList.Last.Next = Eps_Leg.CopyLeg(_CurrLegList);
    }
    else
    {
      if (_CurrLegList.Last.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_CurrLegList.Last.Line.StartPnt, _CurrLegList.Last.Line.EndPnt, ref _dDistance);
        num2 = _CurrLegList.Last.Line.EndPnt.z - _CurrLegList.Last.Line.StartPnt.z;
      }
      else if (_CurrLegList.Last.Arc != null)
      {
        _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_CurrLegList.Last.Arc.Radius, _CurrLegList.Last.Arc.Delta);
        num2 = _CurrLegList.Last.Arc.EndPnt.z - _CurrLegList.Last.Arc.StartPnt.z;
      }
      double num5 = num2 / _dDistance * (_dStation - RevitGeometry.eplGeoE_CalcLegListLength(_CurrLegList));
      Eps_Point _Point = new Eps_Point(_AddPoint);
      _Point.z = _CurrLegList.LegEndPnt.z + num5;
      _NewLegList = Eps_Leg.CopyLeg(_CurrLegList);
      Eps_Leg _CompleteLeg = new Eps_Leg();
      _CompleteLeg.Line = new Eps_Line();
      _CompleteLeg.Line.StartPnt = new Eps_Point(_CurrLegList.LegEndPnt);
      _CompleteLeg.Line.EndPnt = new Eps_Point(_Point);
      _NewLegList.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
    return legList;
  }

  public static List<OffsetLegWrapper> InsertLegsAtStations(
    Eps_Leg _OriginalLeg,
    List<double> _OffsetStations,
    List<Eps_Leg> _AddLegs,
    List<double> _CenterIntStations,
    bool _bInsertFirstLeg)
  {
    double _dStation = 0.0;
    double _dOffset = 0.0;
    double num1 = 0.0;
    bool flag1 = false;
    bool flag2 = _bInsertFirstLeg;
    int index = 0;
    List<OffsetLegWrapper> offsetLegWrapperList = new List<OffsetLegWrapper>();
    OffsetLegWrapper offsetLegWrapper = (OffsetLegWrapper) null;
    for (Eps_Leg epsLeg = _OriginalLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      double num2 = RevitGeometry.eplGeoE_CalcLegLength(epsLeg);
      Eps_Leg _CompleteLeg = new Eps_Leg();
      if (epsLeg.Line != null)
      {
        _CompleteLeg.Line = new Eps_Line(epsLeg.Line);
        for (; index < _OffsetStations.Count && _OffsetStations[index] <= num1 + num2; ++index)
        {
          if (flag2)
          {
            if (!flag1)
            {
              offsetLegWrapper = new OffsetLegWrapper();
              offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_AddLegs[index]);
              offsetLegWrapper.Station = _CenterIntStations[index];
            }
            if (_CompleteLeg == null)
            {
              _CompleteLeg = new Eps_Leg();
              _CompleteLeg.Line = new Eps_Line(epsLeg.Line);
            }
            if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_AddLegs[index].LegEndPnt, Eps_Leg.SingleLeg(epsLeg), ref _dStation, ref _dOffset) != 1700)
            {
              flag1 = true;
              _CompleteLeg = (Eps_Leg) null;
              break;
            }
            flag1 = false;
            _CompleteLeg.Line.StartPnt = _AddLegs[index].LegEndPnt;
            _CompleteLeg.Line.EndPnt = epsLeg.Line.EndPnt;
          }
          else
          {
            if (offsetLegWrapper == null)
            {
              offsetLegWrapper = new OffsetLegWrapper();
              offsetLegWrapper.Station = 0.0;
            }
            if (_CompleteLeg != null)
            {
              _CompleteLeg.Line.EndPnt = _AddLegs[index].LegStartPnt;
              if (offsetLegWrapper.OriginalLeg == null)
                offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_CompleteLeg);
              else
                offsetLegWrapper.OriginalLeg.Last.Next = Eps_Leg.CopyLeg(_CompleteLeg);
            }
            if (offsetLegWrapper.OriginalLeg == null)
              offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_AddLegs[index]);
            else
              offsetLegWrapper.OriginalLeg.Last.Next = Eps_Leg.CopyLeg(_AddLegs[index]);
            offsetLegWrapper.EndingStation = _CenterIntStations[index];
            offsetLegWrapperList.Add(offsetLegWrapper);
            offsetLegWrapper = (OffsetLegWrapper) null;
          }
          if (_CompleteLeg != null && _CompleteLeg.Line.StartPnt.IsEqual(_CompleteLeg.Line.EndPnt))
            _CompleteLeg = (Eps_Leg) null;
          flag2 = !flag2;
        }
        if (flag2 || _CompleteLeg.Line.StartPnt.IsEqual(_CompleteLeg.Line.EndPnt))
          _CompleteLeg = (Eps_Leg) null;
      }
      else if (epsLeg.Arc != null)
      {
        _CompleteLeg.Arc = new Eps_Arc(epsLeg.Arc);
        double radius = _CompleteLeg.Arc.Radius;
        Eps_Point radiusPnt = _CompleteLeg.Arc.RadiusPnt;
        for (; index < _OffsetStations.Count && _OffsetStations[index] <= num1 + num2; ++index)
        {
          if (flag2)
          {
            if (!flag1)
            {
              offsetLegWrapper = new OffsetLegWrapper();
              offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_AddLegs[index]);
              offsetLegWrapper.Station = _CenterIntStations[index];
            }
            if (_CompleteLeg == null)
            {
              _CompleteLeg = new Eps_Leg();
              _CompleteLeg.Arc = new Eps_Arc(epsLeg.Arc);
            }
            else
            {
              if (RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_AddLegs[index].LegEndPnt, Eps_Leg.SingleLeg(epsLeg), ref _dStation, ref _dOffset) != 1700)
              {
                flag1 = true;
                _CompleteLeg = (Eps_Leg) null;
                break;
              }
              flag1 = false;
            }
            _CompleteLeg.Arc.StartPnt = _AddLegs[index].LegEndPnt;
            _CompleteLeg.Arc.EndPnt = epsLeg.Arc.EndPnt;
            _CompleteLeg.Arc.RadiusPnt = radiusPnt;
            _CompleteLeg.Arc.RadiusPnt.z = (_CompleteLeg.Arc.StartPnt.z + _CompleteLeg.Arc.EndPnt.z) / 2.0;
            _CompleteLeg.Arc.Radius = radius;
            _CompleteLeg.Arc.Delta = (num2 - (_OffsetStations[index] - num1)) / _CompleteLeg.Arc.Radius;
          }
          else
          {
            if (offsetLegWrapper == null)
            {
              offsetLegWrapper = new OffsetLegWrapper();
              offsetLegWrapper.Station = 0.0;
            }
            if (_CompleteLeg != null)
            {
              _CompleteLeg.Arc.EndPnt = _AddLegs[index].LegStartPnt;
              _CompleteLeg.Arc.RadiusPnt.z = (_CompleteLeg.Arc.StartPnt.z + _CompleteLeg.Arc.EndPnt.z) / 2.0;
              _CompleteLeg.Arc.Delta = (_OffsetStations[index] - num1) / _CompleteLeg.Arc.Radius;
              if (offsetLegWrapper.OriginalLeg == null)
                offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_CompleteLeg);
              else
                offsetLegWrapper.OriginalLeg.Last.Next = Eps_Leg.CopyLeg(_CompleteLeg);
            }
            if (offsetLegWrapper.OriginalLeg == null)
              offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_AddLegs[index]);
            else
              offsetLegWrapper.OriginalLeg.Last.Next = Eps_Leg.CopyLeg(_AddLegs[index]);
            offsetLegWrapper.EndingStation = _CenterIntStations[index];
            offsetLegWrapperList.Add(offsetLegWrapper);
            offsetLegWrapper = (OffsetLegWrapper) null;
          }
          if (_CompleteLeg != null && _CompleteLeg.Arc.StartPnt.IsEqual(_CompleteLeg.Arc.EndPnt))
            _CompleteLeg = (Eps_Leg) null;
          flag2 = !flag2;
        }
        if (flag2 || _CompleteLeg.Arc.StartPnt.IsEqual(_CompleteLeg.Arc.EndPnt))
          _CompleteLeg = (Eps_Leg) null;
      }
      num1 += num2;
      if (_CompleteLeg != null)
      {
        if (offsetLegWrapper == null)
        {
          offsetLegWrapper = new OffsetLegWrapper();
          offsetLegWrapper.Station = 0.0;
        }
        if (offsetLegWrapper.OriginalLeg == null)
          offsetLegWrapper.OriginalLeg = Eps_Leg.CopyLeg(_CompleteLeg);
        else
          offsetLegWrapper.OriginalLeg.Last.Next = Eps_Leg.CopyLeg(_CompleteLeg);
      }
    }
    if (offsetLegWrapper != null)
    {
      offsetLegWrapper.EndingStation = RevitGeometry.eplGeoE_CalcLegListLength(_OriginalLeg);
      offsetLegWrapperList.Add(offsetLegWrapper);
    }
    return offsetLegWrapperList;
  }

  public static int eplGeoE_FindPntOnLegByStationOffset(
    Eps_Leg StartOfLegList,
    double DistAlongObj,
    double Offset,
    ref Eps_Point Pnt)
  {
    Eps_Leg Leg = (Eps_Leg) null;
    return RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(StartOfLegList, DistAlongObj, Offset, ref Pnt, ref Leg);
  }

  public static int eplGeoE_FindPntOnLegByStationOffset(
    Eps_Leg StartOfLegList,
    double DistAlongObj,
    double Offset,
    ref Eps_Point Pnt,
    ref Eps_Leg Leg)
  {
    double num = 0.0;
    int legByStationOffset = 506;
    for (Eps_Leg epsLeg = StartOfLegList; epsLeg != null; epsLeg = epsLeg.Next)
    {
      double _dX = RevitGeometry.eplGeoE_CalcLegLength(epsLeg);
      if (RevitDefines.LE(_dX, 0.0) && num + _dX < DistAlongObj)
      {
        num += _dX;
      }
      else
      {
        if (DistAlongObj - (num + _dX) <= 1E-05)
        {
          RevitGeometry.FindStaOffPointAlongLeg(epsLeg, DistAlongObj - num, Offset, ref Pnt);
          Leg = epsLeg;
          legByStationOffset = 0;
          break;
        }
        num += _dX;
      }
    }
    return legByStationOffset;
  }

  private static void FindStaOffPointAlongLeg(
    Eps_Leg Leg,
    double Station,
    double Offset,
    ref Eps_Point StaOffPnt)
  {
    Eps_Point _FirstPnt = (Eps_Point) null;
    Eps_Point _SecondPnt = (Eps_Point) null;
    double _dDistance = 0.0;
    if (Leg.Line != null)
    {
      EPShared.eplGeoE_FindStaOffPointAlongLine(Leg.Line, Station, Offset, ref StaOffPnt);
      _FirstPnt = new Eps_Point(Leg.Line.StartPnt);
      _SecondPnt = new Eps_Point(Leg.Line.EndPnt);
      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, _SecondPnt, ref _dDistance);
    }
    else if (Leg.Arc != null)
    {
      EPShared.eplGeoE_FindStaOffPointAlongArc(Leg.Arc, Station, Offset, ref StaOffPnt);
      _FirstPnt = new Eps_Point(Leg.Arc.StartPnt);
      _SecondPnt = new Eps_Point(Leg.Arc.EndPnt);
      _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(Leg.Arc.Radius, Leg.Arc.Delta);
    }
    double num = (_SecondPnt.z - _FirstPnt.z) / _dDistance * Station;
    StaOffPnt.z = _FirstPnt.z + num;
  }

  public static int eplGeoE_CalcStationOffsetAlongLegList(
    Eps_Point _Point,
    Eps_Leg _LegList,
    ref double _dStation,
    ref double _dOffset)
  {
    return RevitGeometry.eplGeoE_CalcStationOffsetAlongLegList(_Point, _LegList, ref _dStation, ref _dOffset, false);
  }

  public static int eplGeoE_CalcStationOffsetAlongLegList(
    Eps_Point _Point,
    Eps_Leg _LegList,
    ref double _dStation,
    ref double _dOffset,
    bool _bAlwaysSetStationOffset)
  {
    int num1 = 0;
    double num2 = 0.0;
    double num3 = 0.0;
    double _dStation1 = 0.0;
    int num4 = 1701;
    double num5 = double.MaxValue;
    double num6 = double.MaxValue;
    double num7 = 0.0;
    double _dOffset1 = 0.0;
    _dStation = 0.0;
    _dOffset = 0.0;
    for (Eps_Leg _Leg = _LegList; _Leg != null; _Leg = _Leg.Next)
    {
      double num8 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
      num1 = 1701;
      int num9;
      if (_Leg.Line != null)
      {
        num9 = EPShared.eplGeoE_CalcStationOffsetAlongLine(_Point, _Leg.Line, ref _dStation1, ref _dOffset1, 0.0);
      }
      else
      {
        if (_Leg.Arc == null)
          return 700;
        num9 = EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation1, ref _dOffset1, 0.0);
      }
      if (num9 == 1700 && Math.Abs(_dOffset1) < Math.Abs(num5))
      {
        num4 = 1700;
        _dStation = _dStation1 + num7;
        _dOffset = _dOffset1;
        num5 = _dOffset1;
        if (RevitDefines.EQ(_dOffset1, 0.0))
          return num4;
      }
      else if (num9 == 1701 && Math.Abs(_dOffset1) < Math.Abs(num6))
      {
        num2 = _dStation1 + num7;
        num3 = _dOffset1;
        num6 = _dOffset1;
      }
      num7 += num8;
    }
    if (_bAlwaysSetStationOffset && num4 == 1701)
    {
      _dStation = num2;
      _dOffset = num6;
    }
    return num4;
  }

  private static int eplGeoE_IntersectTwoLegs(
    Eps_Leg pLegOne,
    Eps_Leg pLegTwo,
    ref Eps_Point[] paIntersections,
    ref int pcNumIntersections,
    double Tolerance)
  {
    int num = 1600;
    pcNumIntersections = 0;
    if (pLegOne.Line != null)
    {
      if (pLegTwo.Line != null)
        num = RevitGeometry.eplGeoE_IntersectTwoLines(pLegOne.Line, pLegTwo.Line, ref paIntersections, ref pcNumIntersections, Tolerance);
      else if (pLegTwo.Arc != null)
      {
        num = RevitGeometry.eplGeoE_IntersectLineArc(pLegOne.Line, pLegTwo.Arc, ref paIntersections, Tolerance);
        switch (num)
        {
          case 1600:
            pcNumIntersections = 0;
            break;
          case 1607:
          case 1613:
            pcNumIntersections = 2;
            break;
          default:
            pcNumIntersections = 1;
            break;
        }
      }
    }
    else if (pLegOne.Arc != null)
    {
      if (pLegTwo.Line != null)
      {
        num = RevitGeometry.eplGeoE_IntersectLineArc(pLegTwo.Line, pLegOne.Arc, ref paIntersections, Tolerance);
        switch (num)
        {
          case 1600:
            pcNumIntersections = 0;
            break;
          case 1607:
          case 1613:
            pcNumIntersections = 2;
            break;
          default:
            pcNumIntersections = 1;
            break;
        }
      }
      else if (pLegTwo.Arc != null)
      {
        num = RevitGeometry.eplGeoE_IntersectTwoArcs2D(pLegOne.Arc, pLegTwo.Arc, ref paIntersections, Tolerance);
        switch (num)
        {
          case 1600:
          case 1604:
            pcNumIntersections = 0;
            break;
          case 1607:
          case 1608:
          case 1610:
          case 1611:
          case 1613:
          case 1619:
          case 1620:
            pcNumIntersections = 2;
            break;
          default:
            pcNumIntersections = 1;
            break;
        }
      }
    }
    return num;
  }

  public static int eplGeoE_IntersectTwoLegLists(
    Eps_Leg pFirstLeg,
    Eps_Leg pSecondLeg,
    ref List<Eps_Point> ppPointList,
    ref int pNumberOfIntersections,
    double _dTolerance)
  {
    Eps_Point[] paIntersections = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int pcNumIntersections = 0;
    ppPointList = new List<Eps_Point>();
    pNumberOfIntersections = 0;
    for (Eps_Leg pLegOne = pFirstLeg; pLegOne != null; pLegOne = pLegOne.Next)
    {
      for (Eps_Leg pLegTwo = pSecondLeg; pLegTwo != null; pLegTwo = pLegTwo.Next)
      {
        paIntersections[0] = new Eps_Point();
        paIntersections[1] = new Eps_Point();
        RevitGeometry.eplGeoE_IntersectTwoLegs(pLegOne, pLegTwo, ref paIntersections, ref pcNumIntersections, _dTolerance);
        for (int index1 = 0; index1 < pcNumIntersections; ++index1)
        {
          bool flag = false;
          for (int index2 = 0; index2 < pNumberOfIntersections; ++index2)
          {
            if (EPShared.eplGeoE_ArePntsDuplicates3D(ppPointList[index2], paIntersections[index1], _dTolerance))
            {
              flag = true;
              break;
            }
          }
          if (!flag)
          {
            ppPointList.Add(paIntersections[index1]);
            ++pNumberOfIntersections;
          }
        }
      }
    }
    return 0;
  }

  public static void eplGeoE_FindMinMaxOfLegList(
    Eps_Leg pLeg,
    ref Eps_Point pMinPnt,
    ref Eps_Point pMaxPnt)
  {
    Eps_Point _MinPnt = new Eps_Point();
    Eps_Point _MaxPnt = new Eps_Point();
    pMinPnt.x = double.MaxValue;
    pMaxPnt.x = double.MinValue;
    pMinPnt.y = double.MaxValue;
    pMaxPnt.y = double.MinValue;
    pMinPnt.z = double.MaxValue;
    pMaxPnt.z = double.MinValue;
    for (Eps_Leg epsLeg = pLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        RevitGeometry.CalcMinMax(epsLeg.Line.StartPnt, ref pMinPnt, ref pMaxPnt);
        RevitGeometry.CalcMinMax(epsLeg.Line.EndPnt, ref pMinPnt, ref pMaxPnt);
      }
      else if (epsLeg.Arc != null)
      {
        EPShared.eplGeoE_FindMinMaxOfArc(epsLeg.Arc, ref _MinPnt, ref _MaxPnt);
        RevitGeometry.CalcMinMax(_MinPnt, ref pMinPnt, ref pMaxPnt);
        RevitGeometry.CalcMinMax(_MaxPnt, ref pMinPnt, ref pMaxPnt);
      }
    }
  }

  public static void eplGeoE_FindMinMaxOfLineArcList(
    Eps_Line[] _LineList,
    int _nLineCount,
    Eps_Arc[] _ArcList,
    int _nArcCount,
    ref Eps_Point pMinPnt,
    ref Eps_Point pMaxPnt)
  {
    Eps_Point _MinPnt = new Eps_Point();
    Eps_Point _MaxPnt = new Eps_Point();
    pMinPnt.x = double.MaxValue;
    pMaxPnt.x = double.MinValue;
    pMinPnt.y = double.MaxValue;
    pMaxPnt.y = double.MinValue;
    pMinPnt.z = double.MaxValue;
    pMaxPnt.z = double.MinValue;
    for (int index = 0; index < _nLineCount; ++index)
    {
      RevitGeometry.CalcMinMax(_LineList[index].StartPnt, ref pMinPnt, ref pMaxPnt);
      RevitGeometry.CalcMinMax(_LineList[index].EndPnt, ref pMinPnt, ref pMaxPnt);
    }
    for (int index = 0; index < _nArcCount; ++index)
    {
      EPShared.eplGeoE_FindMinMaxOfArc(_ArcList[index], ref _MinPnt, ref _MaxPnt);
      RevitGeometry.CalcMinMax(_MinPnt, ref pMinPnt, ref pMaxPnt);
      RevitGeometry.CalcMinMax(_MaxPnt, ref pMinPnt, ref pMaxPnt);
    }
  }

  private static bool eplGeoE_IsPointOnLegList2D(Eps_Point pPoint, Eps_Leg pLeg)
  {
    Eps_Leg ppCurrLeg = (Eps_Leg) null;
    return RevitGeometry.eplGeoE_IsPointOnLegList2D(pPoint, pLeg, 1E-05, ref ppCurrLeg);
  }

  private static bool eplGeoE_IsPointOnLegList2D(
    Eps_Point pPoint,
    Eps_Leg pLeg,
    double Tolerance,
    ref Eps_Leg ppCurrLeg)
  {
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    bool flag = false;
    Eps_Point pMinPnt = new Eps_Point();
    Eps_Point pMaxPnt = new Eps_Point();
    RevitGeometry.eplGeoE_FindMinMaxOfLegList(pLeg, ref pMinPnt, ref pMaxPnt);
    if (RevitDefines.LT(pPoint.x, pMinPnt.x, Tolerance) || RevitDefines.GT(pPoint.x, pMaxPnt.x, Tolerance) || RevitDefines.LT(pPoint.y, pMinPnt.y, Tolerance) || RevitDefines.GT(pPoint.y, pMaxPnt.y, Tolerance))
      return false;
    for (Eps_Leg epsLeg2 = pLeg; epsLeg2 != null && !flag; epsLeg2 = epsLeg2.Next)
    {
      if (epsLeg2.Arc != null)
      {
        flag = EPShared.eplGeoE_IsPointOnArc2D(pPoint, epsLeg2.Arc, Tolerance);
      }
      else
      {
        if (epsLeg2.Line == null)
          return false;
        flag = EPShared.eplGeoE_IsPointOnLine2D(pPoint, epsLeg2.Line, Tolerance);
      }
      epsLeg1 = epsLeg2;
    }
    if (flag && ppCurrLeg != null)
      ppCurrLeg = epsLeg1;
    return flag;
  }

  public static double eplGeoE_CalcLegListLength(Eps_Leg _LegList)
  {
    double num = 0.0;
    for (Eps_Leg _Leg = _LegList; _Leg != null; _Leg = _Leg.Next)
      num += RevitGeometry.eplGeoE_CalcLegLength(_Leg);
    return num;
  }

  public static double eplGeoE_CalcLegLength(Eps_Leg _Leg)
  {
    double _dDistance = 0.0;
    if (_Leg.Line != null)
      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dDistance);
    else
      _dDistance = _Leg.Arc == null ? 0.0 : EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(_Leg.Arc.Radius, _Leg.Arc.Delta);
    return _dDistance;
  }

  private static int eplGeoE_IntersectTwoDists2D(
    Eps_Point FirstRadiusPnt,
    double FirstRadiusLen,
    Eps_Point SecondRadiusPnt,
    double SecondRadiusLen,
    ref Eps_Point[] InterPnt,
    double Tolerance)
  {
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    double num1 = Math.Abs(FirstRadiusLen);
    double num2 = Math.Abs(SecondRadiusLen);
    InterPnt[0].z = FirstRadiusPnt.z;
    InterPnt[1].z = FirstRadiusPnt.z;
    if (num1 < 1E-05 || num2 < 1E-05)
      return 1602;
    double num3 = Math.Abs(num1 - num2);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(FirstRadiusPnt, SecondRadiusPnt, ref _dDistance);
    if (_dDistance < Tolerance && num3 < 1E-05)
      return 1604;
    if (_dDistance < Tolerance)
      return 1605;
    if (_dDistance + num1 + Tolerance < num2 || _dDistance + num2 + Tolerance < num1)
      return 1601;
    if (num1 + num2 + 1E-05 < _dDistance)
      return 1602;
    double d = (_dDistance * _dDistance + num1 * num1 - num2 * num2) / (2.0 * _dDistance * num1);
    double num4 = d < 1.0 ? (d > -1.0 ? EPShared.eplGeoE_NormalizeRadians(Math.Acos(d)) : Math.PI) : 0.0;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(FirstRadiusPnt, SecondRadiusPnt, ref _dDirection);
    EPShared.eplGeoE_CalcPolarToXY(FirstRadiusPnt, _dDirection + num4, FirstRadiusLen, ref InterPnt[0]);
    if (num4 <= 1E-10 || Math.Abs(num4 - Math.PI) <= 1E-10)
      return 1606;
    EPShared.eplGeoE_CalcPolarToXY(FirstRadiusPnt, _dDirection - num4, FirstRadiusLen, ref InterPnt[1]);
    return 1607;
  }

  private static int eplGeoE_IntersectDirDist2D(
    Eps_Point FirstPnt,
    double DirOfFirstPnt,
    Eps_Point RadiusPnt,
    double LenOfRadius,
    ref Eps_Point[] InterPnt,
    double Tolerance)
  {
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    int index = 0;
    int num1 = 0;
    int num2 = 0;
    Eps_Point epsPoint = new Eps_Point();
    Tolerance = 0.001;
    InterPnt[0].z = FirstPnt.z;
    InterPnt[1].z = FirstPnt.z;
    double num3 = Math.Cos(DirOfFirstPnt);
    double num4 = Math.Sin(DirOfFirstPnt);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(RadiusPnt, FirstPnt, ref _dDistance);
    if (_dDistance < Tolerance)
    {
      EPShared.eplGeoE_CalcPolarToXY(RadiusPnt, DirOfFirstPnt, LenOfRadius, ref InterPnt[0]);
      EPShared.eplGeoE_CalcPolarToXY(RadiusPnt, DirOfFirstPnt, LenOfRadius, ref InterPnt[1]);
      return 1606;
    }
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(FirstPnt, RadiusPnt, ref _dDirection);
    double a = Math.Abs(DirOfFirstPnt - _dDirection);
    if (LenOfRadius - _dDistance > 1E-05)
      num1 = 1;
    if (num1 == 0 && Math.Abs(((RadiusPnt.y - FirstPnt.y) * Math.Cos(DirOfFirstPnt) - (RadiusPnt.x - FirstPnt.x) * Math.Sin(DirOfFirstPnt)) / LenOfRadius) - 1.0 > 1E-05)
      return 1600;
    double num5 = Math.Sin(a);
    double d1 = _dDistance * num5 / LenOfRadius;
    if (d1 < -1.0 || d1 > 1.0)
    {
      if (d1 < -1.0000000001 || d1 > 1.0000000001)
        return 1600;
      d1 = RevitGeometry.eplCalE_RoundValue(d1, 0);
    }
    double num6 = Math.Asin(d1);
    double d2 = Math.PI - (a + num6);
    double num7 = Math.PI - a;
    double num8 = Math.PI - num6;
    double d3 = Math.PI - (a + num8);
    double num9 = Math.Sqrt(Math.Abs(_dDistance * _dDistance + LenOfRadius * LenOfRadius - 2.0 * _dDistance * LenOfRadius * Math.Cos(d2)));
    double num10 = Math.Sqrt(Math.Abs(_dDistance * _dDistance + LenOfRadius * LenOfRadius - 2.0 * _dDistance * LenOfRadius * Math.Cos(d3)));
    if (num1 == 0)
      num1 = Math.Abs(num6 - Math.PI / 2.0) > 1E-10 ? 2 : 1;
    epsPoint.x = FirstPnt.x + num9 * num3;
    epsPoint.y = FirstPnt.y + num9 * num4;
    if ((epsPoint.x - RadiusPnt.x) * (epsPoint.x - RadiusPnt.x) + (epsPoint.y - RadiusPnt.y) * (epsPoint.y - RadiusPnt.y) - LenOfRadius * LenOfRadius <= Tolerance)
    {
      num2 = 1;
      InterPnt[index].x = epsPoint.x;
      InterPnt[index].y = epsPoint.y;
      index = 1;
    }
    if (num1 == 1)
      return index > 0 ? 1606 : 1600;
    epsPoint.x = FirstPnt.x + num10 * num3;
    epsPoint.y = FirstPnt.y + num10 * num4;
    if ((epsPoint.x - RadiusPnt.x) * (epsPoint.x - RadiusPnt.x) + (epsPoint.y - RadiusPnt.y) * (epsPoint.y - RadiusPnt.y) - LenOfRadius * LenOfRadius <= Tolerance)
    {
      ++num2;
      InterPnt[index].x = epsPoint.x;
      InterPnt[index].y = epsPoint.y;
    }
    switch (num2)
    {
      case 0:
        return 1600;
      case 1:
        return 1606;
      case 2:
        return 1607;
      default:
        return 1600;
    }
  }

  private static int eplGeoE_IntersectTwoLines(
    Eps_Line pLineOne,
    Eps_Line pLineTwo,
    ref Eps_Point[] aInterPnt,
    ref int pNumOfInter,
    double PointTolerance)
  {
    int num1 = 1600;
    pNumOfInter = 0;
    if (!EPShared.eplGeoE_DoBoundingBoxesOverlap(pLineOne, pLineTwo, PointTolerance))
      return num1;
    double num2 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(pLineOne.StartPnt.x, pLineOne.StartPnt.y, pLineOne.EndPnt.x, pLineOne.EndPnt.y);
    double num3 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(pLineTwo.StartPnt.x, pLineTwo.StartPnt.y, pLineTwo.EndPnt.x, pLineTwo.EndPnt.y);
    if (num2 <= PointTolerance)
    {
      if (num3 <= PointTolerance)
        num1 = 1604;
      else if (EPShared.eplGeoE_IsPointOnLine2D(pLineOne.StartPnt, pLineTwo, PointTolerance))
      {
        aInterPnt[0] = new Eps_Point(pLineOne.StartPnt);
        aInterPnt[1] = new Eps_Point(pLineOne.StartPnt);
        num1 = 1610;
      }
      return num1;
    }
    if (num3 <= PointTolerance)
    {
      if (EPShared.eplGeoE_IsPointOnLine2D(pLineTwo.StartPnt, pLineOne, PointTolerance))
      {
        aInterPnt[0] = new Eps_Point(pLineTwo.StartPnt);
        aInterPnt[1] = new Eps_Point(pLineTwo.StartPnt);
        num1 = 1611;
      }
      return num1;
    }
    int num4 = RevitGeometry.eplGeoE_InterBoundedLineLine(pLineOne, pLineTwo, ref aInterPnt, PointTolerance);
    switch (num4)
    {
      case 1111:
        num4 = RevitGeometry.eplGeoE_InterColinearBoundedLineLine(pLineOne, pLineTwo, ref aInterPnt, pNumOfInter, PointTolerance);
        break;
      case 1606:
        pNumOfInter = 1;
        switch (RevitGeometry.CheckLinesForCommonEndPnts(pLineOne, pLineTwo, PointTolerance))
        {
          case 1614:
          case 1615:
          case 1616:
          case 1617:
            num4 = 1612;
            break;
        }
        break;
    }
    return num4;
  }

  private static int eplGeoE_IntersectTwoArcs2D(
    Eps_Arc ArcOne,
    Eps_Arc ArcTwo,
    ref Eps_Point[] InterPnt,
    double PointTolerance)
  {
    Eps_Point[] InterPnt1 = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    int num1 = 1600;
    Eps_Line[] epsLineArray = new Eps_Line[2]
    {
      new Eps_Line(),
      new Eps_Line()
    };
    epsLineArray[0].StartPnt.x = epsLineArray[0].EndPnt.x = ArcOne.RadiusPnt.x;
    epsLineArray[0].StartPnt.y = epsLineArray[0].EndPnt.y = ArcOne.RadiusPnt.y;
    epsLineArray[0].StartPnt.x -= ArcOne.Radius;
    epsLineArray[0].EndPnt.x += ArcOne.Radius;
    epsLineArray[0].StartPnt.y -= ArcOne.Radius;
    epsLineArray[0].EndPnt.y += ArcOne.Radius;
    epsLineArray[1].StartPnt.x = epsLineArray[1].EndPnt.x = ArcTwo.RadiusPnt.x;
    epsLineArray[1].StartPnt.y = epsLineArray[1].EndPnt.y = ArcTwo.RadiusPnt.y;
    epsLineArray[1].StartPnt.x -= ArcTwo.Radius;
    epsLineArray[1].EndPnt.x += ArcTwo.Radius;
    epsLineArray[1].StartPnt.y -= ArcTwo.Radius;
    epsLineArray[1].EndPnt.y += ArcTwo.Radius;
    if (!EPShared.eplGeoE_DoBoundingBoxesOverlap(epsLineArray[0], epsLineArray[1], PointTolerance))
      return num1;
    InterPnt[0].z = ArcOne.StartPnt.z;
    InterPnt[1].z = ArcOne.StartPnt.z;
    int num2 = RevitGeometry.eplGeoE_FindCommonEndPntsOnArcs2D(ArcOne, ArcTwo, ref InterPnt, PointTolerance);
    switch (num2)
    {
      case 1209:
        num2 = 1600;
        break;
      case 1604:
      case 1613:
        return num2;
    }
    int num3 = RevitGeometry.ChkIfArcsOverlapOrWithIn2D(ArcOne, ArcTwo, ref InterPnt, PointTolerance);
    if (num3 != 1609)
      return num3;
    bool flag1 = EPShared.eplGeoE_IsPointOnArc2D(ArcOne.StartPnt, ArcTwo, PointTolerance);
    bool flag2 = EPShared.eplGeoE_IsPointOnArc2D(ArcOne.EndPnt, ArcTwo, PointTolerance);
    bool flag3 = EPShared.eplGeoE_IsPointOnArc2D(ArcTwo.StartPnt, ArcOne, PointTolerance);
    bool flag4 = EPShared.eplGeoE_IsPointOnArc2D(ArcTwo.EndPnt, ArcOne, PointTolerance);
    if (num2 == 1612)
    {
      bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.StartPnt, ArcTwo.StartPnt, PointTolerance);
      bool flag6 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.EndPnt, ArcTwo.EndPnt, PointTolerance);
      bool flag7 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.StartPnt, ArcTwo.EndPnt, PointTolerance);
      bool flag8 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.EndPnt, ArcTwo.StartPnt, PointTolerance);
      if (flag5)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        if (flag2)
        {
          InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
          return 1607;
        }
        if (flag4)
        {
          InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
          return 1607;
        }
      }
      if (flag6)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        if (flag1)
        {
          InterPnt[1] = new Eps_Point(ArcOne.StartPnt);
          return 1607;
        }
        if (flag3)
        {
          InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
          return 1607;
        }
      }
      if (flag7)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        if (flag2)
        {
          InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
          return 1607;
        }
        if (flag3)
        {
          InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
          return 1607;
        }
      }
      if (flag8)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        if (flag1)
        {
          InterPnt[1] = new Eps_Point(ArcOne.StartPnt);
          return 1607;
        }
        if (flag4)
        {
          InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
          return 1607;
        }
      }
    }
    if (num2 != 1612)
    {
      if (flag1 & flag2)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
        return 1607;
      }
      if (flag3 & flag4)
      {
        InterPnt[0] = new Eps_Point(ArcTwo.StartPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        return 1607;
      }
      if (flag1 & flag3)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
        return 1607;
      }
      if (flag1 & flag4)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        return 1607;
      }
      if (flag2 & flag3)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.StartPnt);
        return 1607;
      }
      if (flag2 & flag4)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        InterPnt[1] = new Eps_Point(ArcTwo.EndPnt);
        return 1607;
      }
      if (flag1)
      {
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        num2 = 1606;
      }
      else if (flag2)
      {
        InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
        num2 = 1606;
      }
      else if (flag3)
      {
        InterPnt[0] = new Eps_Point(ArcTwo.StartPnt);
        num2 = 1606;
      }
      else if (flag4)
      {
        InterPnt[0] = new Eps_Point(ArcTwo.EndPnt);
        num2 = 1606;
      }
    }
    int num4 = num2;
    switch (RevitGeometry.eplGeoE_IntersectTwoDists2D(ArcOne.RadiusPnt, ArcOne.Radius, ArcTwo.RadiusPnt, ArcTwo.Radius, ref InterPnt1, 1E-05))
    {
      case 1606:
        switch (num2)
        {
          case 1600:
            if (EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], ArcOne, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], ArcTwo, PointTolerance))
            {
              InterPnt[0] = new Eps_Point(InterPnt1[0]);
              return 1606;
            }
            break;
          case 1606:
            return 1606;
          case 1612:
            return 1612;
        }
        break;
      case 1607:
        if (num2 == 1600)
        {
          if (EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], ArcOne, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], ArcTwo, PointTolerance))
          {
            InterPnt[0] = new Eps_Point(InterPnt1[0]);
            num4 = num2 != 1612 ? 1606 : 1612;
          }
          if (EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[1], ArcOne, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[1], ArcTwo, PointTolerance))
          {
            if (num4 != 1606)
            {
              InterPnt[0] = new Eps_Point(InterPnt1[1]);
              num4 = num2 != 1612 ? 1606 : 1612;
            }
            else
            {
              InterPnt[1] = new Eps_Point(InterPnt1[1]);
              num4 = 1607;
            }
          }
          return num4;
        }
        if (!EPShared.eplGeoE_ArePntsDuplicates2D(InterPnt[0], InterPnt1[0], PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], ArcOne, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], ArcTwo, PointTolerance))
        {
          InterPnt[1] = new Eps_Point(InterPnt1[0]);
          return 1607;
        }
        if (EPShared.eplGeoE_ArePntsDuplicates2D(InterPnt[0], InterPnt1[1], PointTolerance) || !EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[1], ArcOne, PointTolerance) || !EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[1], ArcTwo, PointTolerance))
          return num4;
        InterPnt[1] = new Eps_Point(InterPnt1[1]);
        return 1607;
      default:
        num4 = 1600;
        break;
    }
    return num4;
  }

  private static int eplGeoE_InterBoundedLineLine(
    Eps_Line pLineOne,
    Eps_Line pLineTwo,
    ref Eps_Point[] aInterPnt,
    double PointTolerance)
  {
    int num1 = 1600;
    double num2 = (pLineTwo.StartPnt.x - pLineOne.StartPnt.x) * (pLineOne.EndPnt.y - pLineOne.StartPnt.y) - (pLineOne.EndPnt.x - pLineOne.StartPnt.x) * (pLineTwo.StartPnt.y - pLineOne.StartPnt.y);
    double num3 = (pLineTwo.EndPnt.x - pLineOne.StartPnt.x) * (pLineOne.EndPnt.y - pLineOne.StartPnt.y) - (pLineOne.EndPnt.x - pLineOne.StartPnt.x) * (pLineTwo.EndPnt.y - pLineOne.StartPnt.y);
    double num4 = (pLineOne.StartPnt.x - pLineTwo.StartPnt.x) * (pLineTwo.EndPnt.y - pLineTwo.StartPnt.y) - (pLineTwo.EndPnt.x - pLineTwo.StartPnt.x) * (pLineOne.StartPnt.y - pLineTwo.StartPnt.y);
    double num5 = (pLineOne.EndPnt.x - pLineTwo.StartPnt.x) * (pLineTwo.EndPnt.y - pLineTwo.StartPnt.y) - (pLineTwo.EndPnt.x - pLineTwo.StartPnt.x) * (pLineOne.EndPnt.y - pLineTwo.StartPnt.y);
    double num6 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(pLineOne.StartPnt.x, pLineOne.StartPnt.y, pLineOne.EndPnt.x, pLineOne.EndPnt.y);
    double num7 = EPShared.eplGeoE_CalcPlaneDistBtwnTwoPnts(pLineTwo.StartPnt.x, pLineTwo.StartPnt.y, pLineTwo.EndPnt.x, pLineTwo.EndPnt.y);
    double num8 = Math.Abs(num2 / num6);
    double num9 = Math.Abs(num3 / num6);
    double num10 = Math.Abs(num4 / num7);
    double num11 = Math.Abs(num5 / num7);
    if (num8 <= PointTolerance)
    {
      if (num9 <= PointTolerance)
        num1 = 1111;
      else if (RevitGeometry.IsPntInBoundingBoxOfLine(pLineTwo.StartPnt, pLineOne, PointTolerance))
      {
        aInterPnt[0] = new Eps_Point(pLineTwo.StartPnt);
        num1 = 1606;
      }
      return num1;
    }
    if (num9 <= PointTolerance)
    {
      if (RevitGeometry.IsPntInBoundingBoxOfLine(pLineTwo.EndPnt, pLineOne, PointTolerance))
      {
        aInterPnt[0] = new Eps_Point(pLineTwo.EndPnt);
        num1 = 1606;
      }
      return num1;
    }
    if (num10 <= PointTolerance)
    {
      if (RevitGeometry.IsPntInBoundingBoxOfLine(pLineOne.StartPnt, pLineTwo, PointTolerance))
      {
        aInterPnt[0] = new Eps_Point(pLineOne.StartPnt);
        num1 = 1606;
      }
      return num1;
    }
    if (num11 <= PointTolerance)
    {
      if (RevitGeometry.IsPntInBoundingBoxOfLine(pLineOne.EndPnt, pLineTwo, PointTolerance))
      {
        aInterPnt[0] = new Eps_Point(pLineOne.EndPnt);
        num1 = 1606;
      }
      return num1;
    }
    if ((num2 < 0.0 && num3 > 0.0 || num2 > 0.0 && num3 < 0.0) && (num4 < 0.0 && num5 > 0.0 || num4 > 0.0 && num5 < 0.0))
    {
      RevitGeometry.CalculateInterPnt(pLineOne, pLineTwo, ref aInterPnt);
      num1 = 1606;
    }
    return num1;
  }

  private static int eplGeoE_InterColinearBoundedLineLine(
    Eps_Line pLineOne,
    Eps_Line pLineTwo,
    ref Eps_Point[] aInterPnt,
    int pNumOfInter,
    double PointTolerance)
  {
    int num = 1600;
    pNumOfInter = 0;
    switch (RevitGeometry.CheckLinesForCommonEndPnts(pLineOne, pLineTwo, PointTolerance))
    {
      case 1108:
      case 1109:
        return 1604;
      case 1614:
      case 1616:
        aInterPnt[pNumOfInter++] = new Eps_Point(pLineOne.StartPnt);
        num = 1612;
        break;
      case 1615:
      case 1617:
        aInterPnt[pNumOfInter++] = new Eps_Point(pLineOne.EndPnt);
        num = 1612;
        break;
    }
    if (EPShared.eplGeoE_CheckIfLineInsideLine(pLineOne, pLineTwo, 1E-05) == 1700)
    {
      aInterPnt[0] = new Eps_Point(pLineOne.StartPnt);
      aInterPnt[1] = new Eps_Point(pLineOne.EndPnt);
      pNumOfInter = 2;
      num = 1610;
    }
    else if (EPShared.eplGeoE_CheckIfLineInsideLine(pLineTwo, pLineOne, 1E-05) == 1700)
    {
      aInterPnt[0] = new Eps_Point(pLineTwo.StartPnt);
      aInterPnt[1] = new Eps_Point(pLineTwo.EndPnt);
      pNumOfInter = 2;
      num = 1611;
    }
    if (num == 1600)
    {
      if (EPShared.eplGeoE_IsPointOnLine2D(pLineOne.StartPnt, pLineTwo, PointTolerance))
      {
        aInterPnt[pNumOfInter++] = new Eps_Point(pLineOne.StartPnt);
        aInterPnt[pNumOfInter++] = !EPShared.eplGeoE_IsPointOnLine2D(pLineTwo.StartPnt, pLineOne, PointTolerance) ? new Eps_Point(pLineTwo.EndPnt) : new Eps_Point(pLineTwo.StartPnt);
        num = 1608;
      }
      else if (EPShared.eplGeoE_IsPointOnLine2D(pLineOne.EndPnt, pLineTwo, PointTolerance))
      {
        aInterPnt[pNumOfInter++] = new Eps_Point(pLineOne.EndPnt);
        aInterPnt[pNumOfInter++] = !EPShared.eplGeoE_IsPointOnLine2D(pLineTwo.StartPnt, pLineOne, PointTolerance) ? new Eps_Point(pLineTwo.EndPnt) : new Eps_Point(pLineTwo.StartPnt);
        num = 1608;
      }
    }
    return num;
  }

  private static int eplGeoE_FindCommonEndPntsOnArcs2D(
    Eps_Arc ArcOne,
    Eps_Arc ArcTwo,
    ref Eps_Point[] InterPnt,
    double PointTolerance)
  {
    InterPnt[0].z = ArcOne.StartPnt.z;
    InterPnt[1].z = ArcOne.StartPnt.z;
    bool flag1 = ArcOne.Direction == ArcTwo.Direction;
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.StartPnt, ArcTwo.StartPnt, PointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.EndPnt, ArcTwo.EndPnt, PointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.StartPnt, ArcTwo.EndPnt, PointTolerance);
    bool flag5 = EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.EndPnt, ArcTwo.StartPnt, PointTolerance);
    if (flag2 && flag3)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.RadiusPnt, ArcTwo.RadiusPnt, PointTolerance))
      {
        if (flag1)
          return 1604;
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
        return 1613;
      }
      InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
      InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
      return 1613;
    }
    if (flag4 && flag5)
    {
      if (EPShared.eplGeoE_ArePntsDuplicates2D(ArcOne.RadiusPnt, ArcTwo.RadiusPnt, PointTolerance))
      {
        if (!flag1)
          return 1604;
        InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
        InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
        return 1613;
      }
      InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
      InterPnt[1] = new Eps_Point(ArcOne.EndPnt);
      return 1613;
    }
    if (flag2 || flag4)
    {
      InterPnt[0] = new Eps_Point(ArcOne.StartPnt);
      return 1612;
    }
    if (!flag5 && !flag3)
      return 1209;
    InterPnt[0] = new Eps_Point(ArcOne.EndPnt);
    return 1612;
  }

  private static int eplGeoE_IntersectLineArc(
    Eps_Line Line,
    Eps_Arc Arc,
    ref Eps_Point[] InterPnt,
    double PointTolerance)
  {
    Eps_Point[] InterPnt1 = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    double _dDirection = 0.0;
    int num1 = 1600;
    int num2 = 1600;
    Eps_Line _LineTwo = new Eps_Line();
    _LineTwo.StartPnt.x = _LineTwo.EndPnt.x = Arc.RadiusPnt.x;
    _LineTwo.StartPnt.y = _LineTwo.EndPnt.y = Arc.RadiusPnt.y;
    _LineTwo.StartPnt.x -= Arc.Radius;
    _LineTwo.EndPnt.x += Arc.Radius;
    _LineTwo.StartPnt.y -= Arc.Radius;
    _LineTwo.EndPnt.y += Arc.Radius;
    if (!EPShared.eplGeoE_DoBoundingBoxesOverlap(Line, _LineTwo, PointTolerance))
      return num1;
    InterPnt[0].z = Line.StartPnt.z;
    InterPnt[1].z = Line.StartPnt.z;
    bool flag1 = EPShared.eplGeoE_ArePntsDuplicates2D(Line.StartPnt, Arc.StartPnt, PointTolerance);
    bool flag2 = EPShared.eplGeoE_ArePntsDuplicates2D(Line.EndPnt, Arc.EndPnt, PointTolerance);
    bool flag3 = EPShared.eplGeoE_ArePntsDuplicates2D(Line.StartPnt, Arc.EndPnt, PointTolerance);
    bool flag4 = EPShared.eplGeoE_ArePntsDuplicates2D(Line.EndPnt, Arc.StartPnt, PointTolerance);
    if (flag1 && flag2 || flag3 && flag4)
    {
      InterPnt[0] = new Eps_Point(Line.StartPnt);
      InterPnt[1] = new Eps_Point(Line.EndPnt);
      return 1613;
    }
    bool flag5 = EPShared.eplGeoE_IsPointOnArc2D(Line.StartPnt, Arc, PointTolerance);
    bool flag6 = EPShared.eplGeoE_IsPointOnArc2D(Line.EndPnt, Arc, PointTolerance);
    bool flag7 = EPShared.eplGeoE_IsPointOnLine2D(Arc.StartPnt, Line, PointTolerance);
    bool flag8 = !EPShared.eplGeoE_ArePntsDuplicates2D(Arc.StartPnt, Arc.EndPnt, PointTolerance) && EPShared.eplGeoE_IsPointOnLine2D(Arc.EndPnt, Line, PointTolerance);
    if (flag1 || flag3)
    {
      InterPnt[0] = new Eps_Point(Line.StartPnt);
      num2 = 1612;
      if (flag6)
      {
        InterPnt[1] = new Eps_Point(Line.EndPnt);
        return 1607;
      }
      if (flag1)
      {
        if (flag8)
        {
          InterPnt[1] = new Eps_Point(Arc.EndPnt);
          return 1607;
        }
      }
      else if (flag7)
      {
        InterPnt[1] = new Eps_Point(Arc.StartPnt);
        return 1607;
      }
    }
    if (num2 == 1600 && (flag2 || flag4))
    {
      InterPnt[0] = new Eps_Point(Line.EndPnt);
      num2 = 1612;
      if (flag5)
      {
        InterPnt[1] = new Eps_Point(Line.StartPnt);
        return 1607;
      }
      if (flag2)
      {
        if (flag7)
        {
          InterPnt[1] = new Eps_Point(Arc.StartPnt);
          return 1607;
        }
      }
      else if (flag8)
      {
        InterPnt[1] = new Eps_Point(Arc.EndPnt);
        return 1607;
      }
    }
    if (num2 == 1600)
    {
      if (flag6)
      {
        InterPnt[0] = new Eps_Point(Line.EndPnt);
        num2 = 1606;
        if (flag7)
        {
          InterPnt[1] = new Eps_Point(Arc.StartPnt);
          return 1607;
        }
        if (flag8)
        {
          InterPnt[1] = new Eps_Point(Arc.EndPnt);
          return 1607;
        }
      }
      if (flag5)
      {
        if (num2 == 1606)
        {
          InterPnt[1] = new Eps_Point(Line.StartPnt);
          return 1607;
        }
        InterPnt[0] = new Eps_Point(Line.StartPnt);
        num2 = 1606;
        if (flag7)
        {
          InterPnt[1] = new Eps_Point(Arc.StartPnt);
          return 1607;
        }
        if (flag8)
        {
          InterPnt[1] = new Eps_Point(Arc.EndPnt);
          return 1607;
        }
      }
    }
    if (num2 == 1600)
    {
      if (flag7 && flag8)
      {
        InterPnt[0] = new Eps_Point(Arc.StartPnt);
        InterPnt[1] = new Eps_Point(Arc.EndPnt);
        return 1607;
      }
      if (flag7)
      {
        InterPnt[0] = new Eps_Point(Arc.StartPnt);
        num2 = 1606;
      }
      else if (flag8)
      {
        InterPnt[0] = new Eps_Point(Arc.EndPnt);
        num2 = 1606;
      }
    }
    int num3 = num2;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Line.StartPnt, Line.EndPnt, ref _dDirection);
    double radius = Arc.Radius;
    switch (RevitGeometry.eplGeoE_IntersectDirDist2D(Line.StartPnt, _dDirection, Arc.RadiusPnt, radius, ref InterPnt1, 0.01))
    {
      case 1606:
        switch (num2)
        {
          case 1600:
            if (EPShared.eplGeoE_IsPointOnLine2D(InterPnt1[0], Line, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], Arc, PointTolerance))
            {
              InterPnt[0] = new Eps_Point(InterPnt1[0]);
              return 1606;
            }
            break;
          case 1606:
            return 1606;
          case 1612:
            return 1612;
        }
        break;
      case 1607:
        if (num2 == 1600)
        {
          if (EPShared.eplGeoE_IsPointOnLine2D(InterPnt1[0], Line, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], Arc, PointTolerance))
          {
            InterPnt[0] = new Eps_Point(InterPnt1[0]);
            num3 = 1606;
          }
          if (EPShared.eplGeoE_IsPointOnLine2D(InterPnt1[1], Line, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[1], Arc, PointTolerance))
          {
            if (num3 != 1606)
            {
              InterPnt[0] = new Eps_Point(InterPnt1[1]);
              num3 = num2 != 1612 ? 1606 : 1612;
            }
            else
            {
              InterPnt[1] = new Eps_Point(InterPnt1[1]);
              num3 = 1607;
            }
          }
          return num3;
        }
        if (!EPShared.eplGeoE_ArePntsDuplicates2D(InterPnt[0], InterPnt1[0], PointTolerance) && EPShared.eplGeoE_IsPointOnLine2D(InterPnt1[0], Line, PointTolerance) && EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[0], Arc, PointTolerance))
        {
          InterPnt[1] = new Eps_Point(InterPnt1[0]);
          return 1607;
        }
        if (EPShared.eplGeoE_ArePntsDuplicates2D(InterPnt[0], InterPnt1[1], PointTolerance) || !EPShared.eplGeoE_IsPointOnLine2D(InterPnt1[1], Line, PointTolerance) || !EPShared.eplGeoE_IsPointOnArc2D(InterPnt1[1], Arc, PointTolerance))
          return num3;
        InterPnt[1] = new Eps_Point(InterPnt1[1]);
        return 1607;
    }
    return num3;
  }

  private static int eplGeoE_IntersectLineCircle(
    Eps_Line pLine,
    Eps_Point RadiusPnt,
    double Radius,
    ref Eps_Point[] paIntPnts,
    ref int pNumInts,
    double Tolerance)
  {
    Eps_Arc Arc = new Eps_Arc();
    Eps_Point _NewPnt = new Eps_Point();
    EPShared.eplGeoE_CalcPolarToXY(RadiusPnt, 0.0, Radius, ref _NewPnt);
    Arc.RadiusPnt = new Eps_Point(RadiusPnt);
    Arc.Radius = Radius;
    Arc.Direction = -1;
    Arc.StartPnt = new Eps_Point(_NewPnt);
    Arc.EndPnt = new Eps_Point(_NewPnt);
    Arc.Delta = 2.0 * Math.PI;
    int num = RevitGeometry.eplGeoE_IntersectLineArc(pLine, Arc, ref paIntPnts, Tolerance);
    switch (num)
    {
      case 1606:
      case 1612:
      case 1613:
        pNumInts = 1;
        num = 1606;
        break;
      case 1607:
        pNumInts = 2;
        break;
    }
    return num;
  }

  public static int eplGeoE_IsPointInsideLegList(Eps_Leg pLeg, Eps_Point Point)
  {
    Eps_Point pMinPnt = (Eps_Point) null;
    Eps_Point pMaxPnt = (Eps_Point) null;
    return RevitGeometry.eplGeoE_IsPointInsideLegList(pLeg, Point, 1E-05, pMinPnt, pMaxPnt);
  }

  public static int eplGeoE_IsPointInsideLegList(
    Eps_Leg pLeg,
    Eps_Point Point,
    double Tolerance,
    Eps_Point pMinPnt,
    Eps_Point pMaxPnt)
  {
    Eps_Point[] epsPointArray = new Eps_Point[2]
    {
      new Eps_Point(),
      new Eps_Point()
    };
    Eps_Line epsLine = new Eps_Line();
    Eps_Point pMinPnt1 = new Eps_Point();
    Eps_Point pMaxPnt1 = new Eps_Point();
    Eps_Point _NewPnt = new Eps_Point();
    double _dDistance1 = 0.0;
    double _dDistance2 = 0.0;
    int pNumOfInter = 0;
    int num1 = 0;
    List<double> doubleList = new List<double>();
    Eps_Point _SecondPnt1 = new Eps_Point();
    Eps_Point _SecondPnt2 = new Eps_Point();
    double _dDirection = 0.0;
    int index1 = 0;
    double num2 = 0.0;
    bool flag = false;
    if (pMinPnt == null || pMaxPnt == null)
    {
      RevitGeometry.eplGeoE_FindMinMaxOfLegList(pLeg, ref pMinPnt1, ref pMaxPnt1);
    }
    else
    {
      pMinPnt1 = new Eps_Point(pMinPnt);
      pMaxPnt1 = new Eps_Point(pMaxPnt);
    }
    if (RevitDefines.LT(Point.x, pMinPnt1.x, Tolerance) || RevitDefines.GT(Point.x, pMaxPnt1.x, Tolerance) || RevitDefines.LT(Point.y, pMinPnt1.y, Tolerance) || RevitDefines.GT(Point.y, pMaxPnt1.y, Tolerance))
      return 6;
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(pMinPnt1, pMaxPnt1, ref _dDistance1);
    for (Eps_Leg epsLeg = pLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        _SecondPnt1 = new Eps_Point(epsLeg.Line.StartPnt);
        _SecondPnt2 = new Eps_Point(epsLeg.Line.EndPnt);
      }
      else if (epsLeg.Arc != null)
      {
        _SecondPnt1 = new Eps_Point(epsLeg.Arc.StartPnt);
        _SecondPnt2 = new Eps_Point(epsLeg.Arc.EndPnt);
      }
      if (RevitDefines.EQ(_SecondPnt1.y, Point.y) || RevitDefines.EQ(_SecondPnt2.y, Point.y))
      {
        flag = true;
        break;
      }
    }
    double _dPolarDirection;
    if (flag)
    {
      for (Eps_Leg epsLeg = pLeg; epsLeg != null; epsLeg = epsLeg.Next)
      {
        if (epsLeg.Line != null)
        {
          _SecondPnt1 = new Eps_Point(epsLeg.Line.StartPnt);
          _SecondPnt2 = new Eps_Point(epsLeg.Line.EndPnt);
        }
        else if (epsLeg.Arc != null)
        {
          _SecondPnt1 = new Eps_Point(epsLeg.Arc.StartPnt);
          _SecondPnt2 = new Eps_Point(epsLeg.Arc.EndPnt);
        }
        if (epsLeg == pLeg)
        {
          EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Point, _SecondPnt1, ref _dDirection);
          if (!doubleList.Contains(_dDirection))
            doubleList.Add(_dDirection);
        }
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(Point, _SecondPnt2, ref _dDirection);
        if (!doubleList.Contains(_dDirection))
          doubleList.Add(_dDirection);
      }
      DoubleComparer doubleComparer = new DoubleComparer();
      doubleList.Sort((IComparer<double>) doubleComparer);
      for (int index2 = 0; index2 < doubleList.Count - 1; ++index2)
      {
        double num3 = doubleList[index2 + 1] - doubleList[index2];
        if (index2 == 0 || num3 > num2)
        {
          num2 = num3;
          index1 = index2;
        }
      }
      _dPolarDirection = (doubleList[index1 + 1] - doubleList[index1]) / 2.0;
      doubleList.Clear();
    }
    else
      _dPolarDirection = 0.0;
    epsLine.StartPnt = new Eps_Point(Point);
    EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, _dPolarDirection, _dDistance1 * 2.0, ref _NewPnt);
    epsLine.EndPnt = new Eps_Point(_NewPnt);
    for (Eps_Leg epsLeg = pLeg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
      {
        if (EPShared.eplGeoE_IsPointOnLine2D(Point, epsLeg.Line, Tolerance))
          return 1903;
        switch (RevitGeometry.eplGeoE_IntersectTwoLines(epsLine, epsLeg.Line, ref epsPointArray, ref pNumOfInter, 1E-05))
        {
          case 1606:
          case 1612:
            if (!EPShared.eplGeoE_ArePntsDuplicates2D(epsPointArray[0], epsLeg.Line.StartPnt) && !EPShared.eplGeoE_ArePntsDuplicates2D(epsPointArray[0], epsLeg.Line.EndPnt))
            {
              ++num1;
              continue;
            }
            continue;
          case 1608:
          case 1610:
          case 1611:
            num1 += 2;
            continue;
          default:
            continue;
        }
      }
      else if (epsLeg.Arc != null)
      {
        if (EPShared.eplGeoE_IsPointOnArc2D(Point, epsLeg.Arc, Tolerance))
          return 1903;
        switch (RevitGeometry.eplGeoE_IntersectLineArc(epsLine, epsLeg.Arc, ref epsPointArray, 1E-05))
        {
          case 1606:
            EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(Point, epsLeg.Arc.RadiusPnt, ref _dDistance2);
            if (RevitDefines.LT(_dDistance2, epsLeg.Arc.Radius))
            {
              ++num1;
              continue;
            }
            Eps_Point[] paIntPnts = new Eps_Point[2]
            {
              new Eps_Point(),
              new Eps_Point()
            };
            int pNumInts = 0;
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, _dPolarDirection, _dDistance2 * 2.0, ref _NewPnt);
            epsLine.EndPnt = new Eps_Point(_NewPnt);
            if (RevitGeometry.eplGeoE_IntersectLineCircle(epsLine, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Radius, ref paIntPnts, ref pNumInts, 1E-05) == 1607 && !EPShared.eplGeoE_ArePntsDuplicates2D(epsPointArray[0], epsLeg.Arc.StartPnt) && !EPShared.eplGeoE_ArePntsDuplicates2D(epsPointArray[0], epsLeg.Arc.EndPnt))
              ++num1;
            EPShared.eplGeoE_CalcPolarToXY(epsLine.StartPnt, _dPolarDirection, _dDistance1 * 2.0, ref _NewPnt);
            epsLine.EndPnt = new Eps_Point(_NewPnt);
            continue;
          case 1607:
            num1 += 2;
            continue;
          default:
            continue;
        }
      }
    }
    return num1 % 2 == 1 ? 0 : 6;
  }

  public static int eplGeoE_CalcLegDirection(Eps_Leg TestLeg, ref int Direction, double Tolerance)
  {
    Eps_Leg pNewLeg = (Eps_Leg) null;
    double _dAngle = 0.0;
    double num1 = 0.0;
    Eps_Point[] epsPointArray = new Eps_Point[3];
    if (!EPShared.eplGeoE_ArePntsDuplicates2D(TestLeg.LegStartPnt, TestLeg.LegEndPnt, Tolerance))
      return 1;
    RevitGeometry.eplGeoE_ConvLegListIntoLineLegList(TestLeg, ref pNewLeg);
    Eps_Leg epsLeg = pNewLeg;
    int num2 = 0;
    while (epsLeg.Next != null)
    {
      if (epsLeg.Line == null)
        return 1;
      epsPointArray[0] = new Eps_Point(epsLeg.Line.StartPnt);
      epsPointArray[1] = new Eps_Point(epsLeg.Line.EndPnt);
      if (epsLeg.Next == null)
        return 1;
      epsPointArray[2] = new Eps_Point(epsLeg.Next.Line.EndPnt);
      EPShared.eplGeoE_CalcHorzAngByThreePnts(epsPointArray[0], epsPointArray[1], epsPointArray[2], 13, ref _dAngle, 1E-05);
      num1 += _dAngle;
      epsLeg = epsLeg.Next;
      ++num2;
    }
    if (pNewLeg.Line == null)
      return 1;
    epsPointArray[0] = new Eps_Point(pNewLeg.Line.EndPnt);
    int num3 = num2 + 1;
    EPShared.eplGeoE_CalcHorzAngByThreePnts(epsPointArray[1], epsPointArray[2], epsPointArray[0], 13, ref _dAngle, 1E-05);
    Direction = !RevitDefines.EQ(num1 + _dAngle, (double) (num3 - 2) * Math.PI) ? 1 : -1;
    pNewLeg = (Eps_Leg) null;
    return 0;
  }

  private static int eplGeoE_ConvLegListIntoLineLegList(Eps_Leg pLeg, ref Eps_Leg pNewLeg)
  {
    if (pLeg == null)
      return 6;
    for (Eps_Leg _CompleteLeg = pLeg; _CompleteLeg != null; _CompleteLeg = _CompleteLeg.Next)
    {
      if (_CompleteLeg.Line != null)
      {
        if (pNewLeg == null)
          pNewLeg = Eps_Leg.SingleLeg(_CompleteLeg);
        else
          pNewLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
      }
      else
      {
        if (_CompleteLeg.Arc == null)
          return 6;
        RevitGeometry.eplDsmE_AddArcLinesToLegList(_CompleteLeg.Arc, ref pNewLeg);
      }
    }
    return 0;
  }

  private static void eplDsmE_AddArcLinesToLegList(Eps_Arc pArc, ref Eps_Leg pNewLeg)
  {
    double _dStation = 0.0;
    Eps_Line _Line = new Eps_Line();
    Eps_Point _StaOffPnt = new Eps_Point();
    double _dX = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(pArc.Radius, pArc.Delta);
    int num1 = (int) (36.0 * pArc.Delta / Math.PI);
    _Line.StartPnt = new Eps_Point(pArc.StartPnt);
    _Line.EndPnt = new Eps_Point(pArc.EndPnt);
    if (RevitDefines.GT(_dX, 0.0) && num1 > 0)
    {
      double num2 = _dX / (double) num1;
      for (int index = 0; index < num1; ++index)
      {
        _dStation += num2;
        EPShared.eplGeoE_FindStaOffPointAlongArc(pArc, _dStation, 0.0, ref _StaOffPnt);
        _Line.EndPnt = _StaOffPnt;
        Eps_Leg _CompleteLeg = new Eps_Leg();
        _CompleteLeg.Line = new Eps_Line(_Line);
        if (pNewLeg == null)
          pNewLeg = Eps_Leg.SingleLeg(_CompleteLeg);
        else
          pNewLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
        _Line.StartPnt = new Eps_Point(_Line.EndPnt);
      }
    }
    else
    {
      Eps_Leg _CompleteLeg = new Eps_Leg();
      _CompleteLeg.Line = new Eps_Line(_Line);
      if (pNewLeg == null)
        pNewLeg = Eps_Leg.SingleLeg(_CompleteLeg);
      else
        pNewLeg.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg);
    }
  }

  public static int eplGeoE_CalcAreaOfLegList(Eps_Leg BoundaryLegList, ref double LegListArea)
  {
    double LegListPerimeter = 0.0;
    return RevitGeometry.eplGeoE_CalcAreaAndPerimeterOfLegList(BoundaryLegList, ref LegListArea, ref LegListPerimeter);
  }

  public static int eplGeoE_CalcAreaAndPerimeterOfLegList(
    Eps_Leg BoundaryLegList,
    ref double LegListArea,
    ref double LegListPerimeter)
  {
    LegListArea = 0.0;
    LegListPerimeter = 0.0;
    double _dChordArea = 0.0;
    LegListPerimeter = RevitGeometry.eplGeoE_CalcLegListLength(BoundaryLegList);
    List<Eps_Point> Vertices = new List<Eps_Point>();
    for (Eps_Leg epsLeg = BoundaryLegList; epsLeg != null; epsLeg = epsLeg.Next)
    {
      if (epsLeg.Line != null)
        Vertices.Add(epsLeg.Line.StartPnt);
      else if (epsLeg.Arc != null)
      {
        Vertices.Add(epsLeg.Arc.StartPnt);
        EPShared.eplGeoE_CalcArcChordArea(epsLeg.Arc, ref _dChordArea);
        LegListArea += _dChordArea;
      }
    }
    LegListArea += RevitGeometry.eplGeoE_CalcPolygonArea(Vertices);
    LegListArea = Math.Abs(LegListArea);
    return 0;
  }

  public static double eplGeoE_CalcPolygonArea(List<Eps_Point> Vertices)
  {
    if (Vertices == null || Vertices.Count == 0)
      return 0.0;
    double num = 0.0;
    int count = Vertices.Count;
    Eps_Point epsPoint1 = new Eps_Point(Vertices[0]);
    double x = epsPoint1.x;
    double y = epsPoint1.y;
    for (int index = 0; index < count; ++index)
    {
      Eps_Point epsPoint2 = new Eps_Point(Vertices[index]);
      if (epsPoint2.x < x)
        x = epsPoint2.x;
      if (epsPoint2.y < y)
        y = epsPoint2.y;
    }
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    for (int index = 0; index < count; ++index)
      epsPointList.Add(new Eps_Point(Vertices[index].x - x, Vertices[index].y - y, 0.0));
    Eps_Point epsPoint3 = new Eps_Point(epsPointList[0]);
    Eps_Point epsPoint4 = new Eps_Point(epsPointList[0]);
    for (int index = 0; index < count; ++index)
    {
      Eps_Point _Point = new Eps_Point(epsPointList[index]);
      num += epsPoint3.x * epsPoint4.y + epsPoint3.y * _Point.x + _Point.y * epsPoint4.x - epsPoint4.y * _Point.x - epsPoint3.y * epsPoint4.x - epsPoint3.x * _Point.y;
      epsPoint4 = new Eps_Point(_Point);
    }
    return num / 2.0;
  }
}
