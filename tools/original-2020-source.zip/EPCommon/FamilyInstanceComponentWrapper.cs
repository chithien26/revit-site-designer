﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyInstanceComponentWrapper
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FamilyInstanceComponentWrapper
{
  private string m_strChainID;
  private List<FamilyInstanceComponentContainer> m_FamilyContainerList;
  private ElementSet m_ProposedElementSet;
  private List<Element> m_ParkingLotBreaklineElementList;
  private List<FamilyInstance> m_ParkingLotBreaklineFamilyInstanceList;
  private Eps_Leg m_ProposedLeg;
  private Eps_Leg m_OriginalLeg;
  private int m_nDrawOrder;
  private FamilySymbol m_ProposedFamilySymbol;
  private FamilySymbol m_IntersectionFamilySymbol;
  private FamilySymbol m_OriginalFamilySymbol;
  private List<FamilyInstance> m_IntersectionFamilyInstanceList;
  private TopographySurfaceContainer m_ParkingLotTopographySurface;
  private List<Eps_Leg> m_ParkingLotBreaklineList;
  private FamilyInstance m_PrimarySiteComponentMass;
  private FamilyInstance m_AdditionalSiteComponentMass;
  private DirectShape m_PrimarySiteComponentDirectShape;
  private DirectShape m_AdditionalSiteComponentDirectShape;
  private bool m_bFormDepthApplied;
  private bool m_bRedrawForm;
  private Category m_MassLineSubCategory;
  private LandcaddID m_CurrentLandcaddId;
  private List<double> m_ParkingLotBreaklineLinearPointIntervals;
  private List<IntersectionStationContainer> m_LeftIntersectionStations;
  private List<IntersectionStationContainer> m_RightIntersectionStations;
  private List<IntersectionStationContainer> m_CenterIntersectionStations;
  private List<IntersectionContainer> m_IntersectionContainerList;

  public FamilyInstanceComponentWrapper(
    string _strChainID,
    List<FamilyInstanceComponentContainer> _FamilyContainerList)
  {
    this.m_strChainID = _strChainID;
    this.m_FamilyContainerList = _FamilyContainerList;
    this.m_ProposedElementSet = (ElementSet) null;
    this.m_ProposedLeg = (Eps_Leg) null;
    this.m_OriginalLeg = (Eps_Leg) null;
    this.m_nDrawOrder = 0;
    this.m_ProposedFamilySymbol = (FamilySymbol) null;
    this.m_OriginalFamilySymbol = (FamilySymbol) null;
    this.m_IntersectionFamilySymbol = (FamilySymbol) null;
    this.m_IntersectionFamilyInstanceList = new List<FamilyInstance>();
    this.m_ParkingLotTopographySurface = (TopographySurfaceContainer) null;
    this.m_ParkingLotBreaklineList = new List<Eps_Leg>();
    this.m_ParkingLotBreaklineElementList = new List<Element>();
    this.m_ParkingLotBreaklineFamilyInstanceList = new List<FamilyInstance>();
    this.m_PrimarySiteComponentMass = (FamilyInstance) null;
    this.m_AdditionalSiteComponentMass = (FamilyInstance) null;
    this.m_PrimarySiteComponentDirectShape = (DirectShape) null;
    this.m_AdditionalSiteComponentDirectShape = (DirectShape) null;
    this.m_bFormDepthApplied = false;
    this.m_bRedrawForm = false;
    this.m_MassLineSubCategory = (Category) null;
    this.m_ParkingLotBreaklineLinearPointIntervals = new List<double>();
    this.m_LeftIntersectionStations = new List<IntersectionStationContainer>();
    this.m_RightIntersectionStations = new List<IntersectionStationContainer>();
    this.m_CenterIntersectionStations = new List<IntersectionStationContainer>();
    this.m_IntersectionContainerList = new List<IntersectionContainer>();
    this.SetCurrentLandcaddId();
  }

  public FamilyInstanceComponentWrapper(
    string _strChainID,
    List<FamilyInstanceComponentContainer> _FamilyContainerList,
    int _nDrawOrder)
  {
    this.m_strChainID = _strChainID;
    this.m_FamilyContainerList = _FamilyContainerList;
    this.m_ProposedElementSet = (ElementSet) null;
    this.m_ProposedLeg = (Eps_Leg) null;
    this.m_OriginalLeg = (Eps_Leg) null;
    this.m_nDrawOrder = _nDrawOrder;
    this.m_ProposedFamilySymbol = (FamilySymbol) null;
    this.m_OriginalFamilySymbol = (FamilySymbol) null;
    this.m_IntersectionFamilySymbol = (FamilySymbol) null;
    this.m_IntersectionFamilyInstanceList = new List<FamilyInstance>();
    this.m_ParkingLotTopographySurface = (TopographySurfaceContainer) null;
    this.m_ParkingLotBreaklineList = new List<Eps_Leg>();
    this.m_ParkingLotBreaklineElementList = new List<Element>();
    this.m_ParkingLotBreaklineFamilyInstanceList = new List<FamilyInstance>();
    this.m_PrimarySiteComponentMass = (FamilyInstance) null;
    this.m_AdditionalSiteComponentMass = (FamilyInstance) null;
    this.m_PrimarySiteComponentDirectShape = (DirectShape) null;
    this.m_AdditionalSiteComponentDirectShape = (DirectShape) null;
    this.m_bFormDepthApplied = false;
    this.m_bRedrawForm = false;
    this.m_MassLineSubCategory = (Category) null;
    this.m_ParkingLotBreaklineLinearPointIntervals = new List<double>();
    this.m_LeftIntersectionStations = new List<IntersectionStationContainer>();
    this.m_RightIntersectionStations = new List<IntersectionStationContainer>();
    this.m_CenterIntersectionStations = new List<IntersectionStationContainer>();
    this.m_IntersectionContainerList = new List<IntersectionContainer>();
    this.SetCurrentLandcaddId();
  }

  public void CreateOriginalLeg(TopographySurfaceContainer _Surface)
  {
    this.CreateOriginalOrProposedLeg(new List<TopographySurfaceContainer>()
    {
      _Surface
    }, (Phase) null, true);
  }

  public void CreateOriginalLeg(List<TopographySurfaceContainer> _SurfaceList)
  {
    this.CreateOriginalOrProposedLeg(_SurfaceList, (Phase) null, true);
  }

  public void CreateOriginalLeg(List<TopographySurfaceContainer> _SurfaceList, Phase _CurPhase)
  {
    this.CreateOriginalOrProposedLeg(_SurfaceList, _CurPhase, true);
  }

  public void CreateOriginalOrProposedLeg(
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase,
    bool _bIsOriginalLeg)
  {
    List<Eps_Line> epsLineList = new List<Eps_Line>();
    List<Eps_Arc> epsArcList = new List<Eps_Arc>();
    Eps_Leg epsLeg1 = (Eps_Leg) null;
    FamilyInstance familyInstance = (FamilyInstance) null;
    bool flag1 = false;
    bool _bAppendToEndOnly = false;
    bool flag2 = true;
    double num1 = 0.0;
    double num2 = 0.0;
    for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
    {
      Element element = this.m_FamilyContainerList[index].Element;
      if (element != null)
      {
        if (element.Location is LocationCurve location)
        {
          Curve curve = location.Curve;
          if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
          {
            if (!_bAppendToEndOnly && this.m_FamilyContainerList[index].FamilyInstance != null)
            {
              Parameter parameter1 = ((Element) this.m_FamilyContainerList[index].FamilyInstance).LookupParameter(RevitParameters.IsFirstPlacementSegmentGenericFamilyParameter);
              if (parameter1 != null && parameter1.AsInteger() == 1)
              {
                Parameter parameter2 = ((Element) this.m_FamilyContainerList[index].FamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
                if (parameter2 != null && string.Compare(parameter2.AsString(), element.UniqueId, true) == 0)
                {
                  flag1 = true;
                  _bAppendToEndOnly = true;
                }
              }
            }
            if (flag2)
            {
              bool flag3 = false;
              bool flag4 = false;
              familyInstance = this.m_FamilyContainerList[index].FamilyInstance;
              if (familyInstance != null)
              {
                Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.UsePlacementElevationsFamilyParameter);
                if (parameter3 != null && parameter3.AsInteger() == 1)
                {
                  Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.BeginningElevationFamilyParameter);
                  if (parameter4 != null)
                  {
                    num1 = parameter4.AsDouble();
                    flag3 = true;
                  }
                  Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.EndingElevationFamilyParameter);
                  if (parameter5 != null)
                  {
                    num2 = parameter5.AsDouble();
                    flag4 = true;
                  }
                }
              }
              if (!flag3 || !flag4)
                flag2 = false;
            }
            switch (curve)
            {
              case Arc _:
                Eps_Arc _CurrentArc = new Eps_Arc((Arc) curve);
                if (familyInstance != null)
                {
                  _CurrentArc.StartPnt.z = num1;
                  _CurrentArc.EndPnt.z = num2;
                  _CurrentArc.RadiusPnt.z = (_CurrentArc.StartPnt.z + _CurrentArc.EndPnt.z) / 2.0;
                }
                if (flag1)
                {
                  Eps_Leg.InsertArcLegSegment(ref epsLeg1, _CurrentArc);
                  break;
                }
                epsArcList.Add(_CurrentArc);
                break;
              case Line _:
                Eps_Line _CurrentLine = new Eps_Line((Line) curve);
                if (familyInstance != null)
                {
                  _CurrentLine.StartPnt.z = num1;
                  _CurrentLine.EndPnt.z = num2;
                }
                if (flag1)
                {
                  Eps_Leg.InsertLineLegSegment(ref epsLeg1, _CurrentLine);
                  break;
                }
                epsLineList.Add(_CurrentLine);
                break;
              case Ellipse _:
              case NurbSpline _:
              case HermiteSpline _:
                Eps_Leg legFromSpline = RevitGeometry.GetLegFromSpline(element, curve, false);
                double _dDistance = 0.0;
                double num3 = 0.0;
                double num4 = 0.0;
                if (familyInstance != null)
                {
                  double num5 = num2 - num1;
                  _dDistance = RevitGeometry.eplGeoE_CalcLegListLength(legFromSpline);
                  num4 = num5 / _dDistance;
                  num3 = num1;
                }
                for (Eps_Leg epsLeg2 = legFromSpline; epsLeg2 != null; epsLeg2 = epsLeg2.Next)
                {
                  if (epsLeg2.Line != null)
                  {
                    Eps_Line epsLine = new Eps_Line(epsLeg2.Line);
                    if (familyInstance != null)
                    {
                      EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLine.StartPnt, epsLine.EndPnt, ref _dDistance);
                      double num6 = num4 * _dDistance;
                      epsLine.StartPnt.z = num3;
                      num3 += num6;
                      epsLine.EndPnt.z = num3;
                    }
                    if (flag1)
                      Eps_Leg.InsertLineLegSegment(ref epsLeg1, epsLine);
                    else
                      epsLineList.Add(new Eps_Line(epsLine));
                  }
                  else if (epsLeg2.Arc != null)
                  {
                    Eps_Arc epsArc = new Eps_Arc(epsLeg2.Arc);
                    if (familyInstance != null)
                    {
                      _dDistance = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsArc.Radius, epsArc.Delta);
                      double num7 = num4 * _dDistance;
                      epsArc.StartPnt.z = num3;
                      num3 += num7;
                      epsArc.EndPnt.z = num3;
                      epsArc.RadiusPnt.z = (epsArc.StartPnt.z + epsArc.EndPnt.z) / 2.0;
                    }
                    if (flag1)
                      Eps_Leg.InsertArcLegSegment(ref epsLeg1, epsArc);
                    else
                      epsArcList.Add(new Eps_Arc(epsArc));
                  }
                }
                break;
              default:
                flag2 = false;
                break;
            }
            flag1 = false;
          }
          else
            flag2 = false;
        }
        else
          flag2 = false;
      }
      else
        flag2 = false;
    }
    int index1 = -1;
    int index2 = -1;
    double maxValue = double.MaxValue;
    double num8 = double.MaxValue;
    bool flag5 = false;
    while (epsLineList.Count > 0 || epsArcList.Count > 0)
    {
      for (int index3 = epsLineList.Count - 1; index3 >= 0; --index3)
      {
        Eps_Line _CurrentLine = epsLineList[index3];
        if (Eps_Leg.InsertLineLegSegment(ref epsLeg1, _CurrentLine, _bAppendToEndOnly))
        {
          epsLineList.RemoveAt(index3);
          flag5 = true;
        }
      }
      for (int index4 = epsArcList.Count - 1; index4 >= 0; --index4)
      {
        Eps_Arc _CurrentArc = epsArcList[index4];
        if (Eps_Leg.InsertArcLegSegment(ref epsLeg1, _CurrentArc, _bAppendToEndOnly))
        {
          epsArcList.RemoveAt(index4);
          flag5 = true;
        }
      }
      if (!flag5)
      {
        for (int index5 = epsLineList.Count - 1; index5 >= 0; --index5)
        {
          double distanceBetweenLegs = Eps_Leg.FindMinimumDistanceBetweenLegs(epsLeg1, new Eps_Leg()
          {
            Line = epsLineList[index5]
          });
          if (distanceBetweenLegs < num8)
          {
            num8 = distanceBetweenLegs;
            index1 = index5;
          }
        }
        for (int index6 = epsArcList.Count - 1; index6 >= 0; --index6)
        {
          double distanceBetweenLegs = Eps_Leg.FindMinimumDistanceBetweenLegs(epsLeg1, new Eps_Leg()
          {
            Arc = epsArcList[index6]
          });
          if (distanceBetweenLegs < num8)
          {
            num8 = distanceBetweenLegs;
            index2 = index6;
            index1 = -1;
          }
        }
        if (index1 >= 0)
        {
          Eps_Leg.CombineLegListsAtShortestGaps(ref epsLeg1, new Eps_Leg()
          {
            Line = epsLineList[index1]
          });
          epsLineList.RemoveAt(index1);
          index1 = -1;
        }
        else if (index2 >= 0)
        {
          Eps_Leg.CombineLegListsAtShortestGaps(ref epsLeg1, new Eps_Leg()
          {
            Arc = epsArcList[index2]
          });
          epsArcList.RemoveAt(index2);
          index2 = -1;
        }
        maxValue = double.MaxValue;
        num8 = double.MaxValue;
      }
      else
        flag5 = false;
    }
    if (epsLeg1 == null)
      return;
    this.m_bFormDepthApplied = flag2;
    if (_bIsOriginalLeg)
    {
      if (!flag2)
        this.m_OriginalLeg = epsLeg1.TopographySurfaceLeg(_SurfaceList, _CurPhase);
      else
        this.m_OriginalLeg = Eps_Leg.CopyLeg(epsLeg1);
    }
    else if (!flag2)
      this.m_ProposedLeg = epsLeg1.TopographySurfaceLeg(_SurfaceList, _CurPhase);
    else
      this.m_ProposedLeg = Eps_Leg.CopyLeg(epsLeg1);
  }

  public void CreateProposedLeg(TopographySurfaceContainer _Surface)
  {
    this.CreateOriginalOrProposedLeg(new List<TopographySurfaceContainer>()
    {
      _Surface
    }, (Phase) null, false);
  }

  public void CreateProposedLeg(List<TopographySurfaceContainer> _SurfaceList)
  {
    this.CreateOriginalOrProposedLeg(_SurfaceList, (Phase) null, false);
  }

  public void CreateProposedLeg(List<TopographySurfaceContainer> _SurfaceList, Phase _CurPhase)
  {
    this.CreateOriginalOrProposedLeg(_SurfaceList, _CurPhase, false);
  }

  private void SetCurrentLandcaddId()
  {
    FamilyInstance existingFamilyInstance = this.GetFirstExistingFamilyInstance();
    if (existingFamilyInstance == null)
      return;
    this.m_CurrentLandcaddId = LandcaddID.SoftTerrain;
    Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
    if (parameter == null)
      return;
    foreach (int num in Enum.GetValues(typeof (LandcaddID)))
    {
      if (string.Compare(parameter.AsString(), num.ToString("000"), true) == 0)
      {
        this.m_CurrentLandcaddId = (LandcaddID) Enum.ToObject(typeof (LandcaddID), num);
        break;
      }
    }
  }

  private void ApplyFormDepthToLegs()
  {
    Parameter parameter1 = (Parameter) null;
    if (this.m_bFormDepthApplied || this.m_ProposedFamilySymbol == null || this.m_ProposedLeg == null && this.m_OriginalLeg == null)
      return;
    double num = 0.0;
    parameter1 = (Parameter) null;
    switch (this.m_CurrentLandcaddId)
    {
      case LandcaddID.Street:
        Parameter parameter2 = ((Element) this.m_ProposedFamilySymbol).LookupParameter(RevitParameters.StreetPavementDepthParameter);
        if (parameter2 != null)
        {
          num = parameter2.AsDouble();
          break;
        }
        break;
      case LandcaddID.Curb:
        Parameter parameter3 = ((Element) this.m_ProposedFamilySymbol).LookupParameter(RevitParameters.CurbGutterHeightParameter);
        if (parameter3 != null)
        {
          num = parameter3.AsDouble();
          break;
        }
        break;
      case LandcaddID.Sidewalk:
        Parameter parameter4 = ((Element) this.m_ProposedFamilySymbol).LookupParameter(RevitParameters.SideWalkPavementDepthParameter);
        if (parameter4 != null)
        {
          num = parameter4.AsDouble();
          break;
        }
        break;
      case LandcaddID.RetainingWall:
        Parameter parameter5 = ((Element) this.m_ProposedFamilySymbol).LookupParameter(RevitParameters.RetainingWallHeightParameter);
        if (parameter5 != null)
        {
          num = parameter5.AsDouble();
          break;
        }
        break;
    }
    if (!RevitDefines.EQ(num, 0.0))
    {
      if (this.m_OriginalLeg != null)
        this.m_OriginalLeg = this.m_OriginalLeg.MoveLeg(0.0, 0.0, num);
      if (this.m_ProposedLeg != null)
        this.m_ProposedLeg = this.m_ProposedLeg.MoveLeg(0.0, 0.0, num);
    }
    this.m_bFormDepthApplied = true;
  }

  public int IndexOfFamilyInstanceUniqueID(string _strUniqueID)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        FamilyInstance familyInstance = this.m_FamilyContainerList[index].FamilyInstance;
        if (familyInstance != null && string.Compare(((Element) familyInstance).UniqueId, _strUniqueID, true) == 0)
          return index;
      }
    }
    return -1;
  }

  public int IndexOfOriginalElementID(ElementId _ContainerID)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (ElementId.op_Equality(this.m_FamilyContainerList[index].Element.Id, _ContainerID))
          return index;
      }
    }
    return -1;
  }

  public int IndexOfProposedElementID(ElementId _ElementId)
  {
    int num = 0;
    if (this.m_ProposedElementSet != null)
    {
      foreach (Element proposedElement in this.m_ProposedElementSet)
      {
        if (ElementId.op_Equality(proposedElement.Id, _ElementId))
          return num;
        ++num;
      }
    }
    return -1;
  }

  public int IndexOfFamilyInstanceID(ElementId _ElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (ElementId.op_Equality(((Element) this.m_FamilyContainerList[index].FamilyInstance).Id, _ElementId))
          return index;
      }
    }
    return -1;
  }

  public FamilyInstance FindFamilyInstance(ElementId _FindElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (ElementId.op_Equality(this.m_FamilyContainerList[index].Element.Id, _FindElementId))
          return this.m_FamilyContainerList[index].FamilyInstance;
      }
    }
    return (FamilyInstance) null;
  }

  public Element GetFirstExistingElement() => this.GetFirstExistingElement(new ElementId(-1));

  public Element GetFirstExistingElement(ElementId _FindElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (_FindElementId.IntegerValue == -1 || ElementId.op_Equality(_FindElementId, this.m_FamilyContainerList[index].Element.Id))
          return this.m_FamilyContainerList[index].Element;
      }
    }
    return (Element) null;
  }

  public FamilyInstance GetFirstExistingFamilyInstance()
  {
    return this.GetFirstExistingFamilyInstance(new ElementId(-1));
  }

  public FamilyInstance GetFirstExistingFamilyInstance(ElementId _FindElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (_FindElementId.IntegerValue == -1 || ElementId.op_Equality(_FindElementId, this.m_FamilyContainerList[index].Element.Id))
          return this.m_FamilyContainerList[index].FamilyInstance;
      }
    }
    return (FamilyInstance) null;
  }

  public Element FindElement(ElementId _FindElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (ElementId.op_Equality(this.m_FamilyContainerList[index].Element.Id, _FindElementId))
          return this.m_FamilyContainerList[index].Element;
      }
    }
    return (Element) null;
  }

  public ElementSet GetOriginalElementSet()
  {
    ElementSet originalElementSet = new ElementSet();
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
        originalElementSet.Insert(this.m_FamilyContainerList[index].Element);
    }
    return originalElementSet;
  }

  public ElementSet GetFamilyInstanceElementSet()
  {
    ElementSet instanceElementSet = new ElementSet();
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
        instanceElementSet.Insert((Element) this.m_FamilyContainerList[index].FamilyInstance);
    }
    return instanceElementSet;
  }

  public void CreateNewProposedElementSet(Document _Document)
  {
    if (this.m_MassLineSubCategory == null)
      this.m_MassLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, this.m_CurrentLandcaddId);
    if (this.m_ProposedElementSet == null)
      this.m_ProposedElementSet = new ElementSet();
    else
      this.m_ProposedElementSet.Clear();
    SketchPlane _SketchPlane = (SketchPlane) null;
    Element firstExistingElement = this.GetFirstExistingElement();
    if (firstExistingElement != null && firstExistingElement is CurveElement curveElement)
      _SketchPlane = curveElement.SketchPlane;
    foreach (ModelCurve modelCurve in _SketchPlane == null ? RevitUtility.NewModelCurveArray(_Document, this.m_ProposedLeg) : RevitUtility.NewModelCurveArray(_Document, this.m_ProposedLeg, _SketchPlane, true))
    {
      if (this.m_MassLineSubCategory != null)
        ((CurveElement) modelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
      this.m_ProposedElementSet.Insert((Element) modelCurve);
    }
  }

  public void CreateNewProposedElementSet(
    Document _Document,
    EPTransactionContainer _TransactionContainer)
  {
    if (this.m_MassLineSubCategory == null)
      this.m_MassLineSubCategory = RevitUtility.GetSiteComponentLineSubCategory(_Document, this.m_CurrentLandcaddId);
    if (this.m_ProposedElementSet == null)
      this.m_ProposedElementSet = new ElementSet();
    else
      this.m_ProposedElementSet.Clear();
    SketchPlane _SketchPlane = (SketchPlane) null;
    Element firstExistingElement = this.GetFirstExistingElement();
    if (firstExistingElement != null && firstExistingElement is CurveElement curveElement)
      _SketchPlane = curveElement.SketchPlane;
    _TransactionContainer.BeginTransaction();
    ModelCurveArray modelCurveArray = _SketchPlane == null ? RevitUtility.NewModelCurveArray(_Document, this.m_ProposedLeg) : RevitUtility.NewModelCurveArray(_Document, this.m_ProposedLeg, _SketchPlane, true);
    _TransactionContainer.EndTransaction();
    foreach (ModelCurve modelCurve in modelCurveArray)
    {
      if (this.m_MassLineSubCategory != null)
        ((CurveElement) modelCurve).LineStyle = (Element) this.m_MassLineSubCategory.GetGraphicsStyle((GraphicsStyleType) 1);
      this.m_ProposedElementSet.Insert((Element) modelCurve);
    }
  }

  public void CreateParkingLotBreaklineLegs(TopographySurfaceContainer _Surface)
  {
    this.CreateParkingLotBreaklineLegs(new List<TopographySurfaceContainer>()
    {
      _Surface
    }, (Phase) null);
  }

  public void CreateParkingLotBreaklineLegs(List<TopographySurfaceContainer> _SurfaceList)
  {
    this.CreateParkingLotBreaklineLegs(_SurfaceList, (Phase) null);
  }

  public void CreateParkingLotBreaklineLegs(
    List<TopographySurfaceContainer> _SurfaceList,
    Phase _CurPhase)
  {
    List<Eps_Line> epsLineList = new List<Eps_Line>();
    List<Eps_Arc> epsArcList = new List<Eps_Arc>();
    this.m_ParkingLotBreaklineLinearPointIntervals.Clear();
    bool flag1 = false;
    if (this.m_ParkingLotBreaklineFamilyInstanceList.Count == this.m_ParkingLotBreaklineElementList.Count)
      flag1 = true;
    for (int index = 0; index < this.m_ParkingLotBreaklineElementList.Count; ++index)
    {
      Element breaklineElement = this.m_ParkingLotBreaklineElementList[index];
      if (breaklineElement != null && breaklineElement.Location is LocationCurve location)
      {
        Curve curve = location.Curve;
        if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
        {
          if (flag1 && this.m_ParkingLotBreaklineFamilyInstanceList[index] != null)
          {
            Parameter parameter = ((Element) this.m_ParkingLotBreaklineFamilyInstanceList[index]).LookupParameter(RevitParameters.LinearPointIntervalParameter);
            if (parameter != null)
              this.m_ParkingLotBreaklineLinearPointIntervals.Add(parameter.AsDouble());
          }
          switch (curve)
          {
            case Arc _:
              Eps_Arc epsArc = new Eps_Arc((Arc) curve);
              epsArcList.Add(epsArc);
              continue;
            case Line _:
              Eps_Line epsLine = new Eps_Line((Line) curve);
              epsLineList.Add(epsLine);
              continue;
            case Ellipse _:
            case NurbSpline _:
            case HermiteSpline _:
              for (Eps_Leg epsLeg = RevitGeometry.GetLegFromSpline(breaklineElement, curve, false); epsLeg != null; epsLeg = epsLeg.Next)
              {
                if (epsLeg.Line != null)
                  epsLineList.Add(new Eps_Line(epsLeg.Line));
                else if (epsLeg.Arc != null)
                  epsArcList.Add(new Eps_Arc(epsLeg.Arc));
              }
              continue;
            default:
              continue;
          }
        }
      }
    }
    bool flag2 = false;
    while (epsLineList.Count > 0 || epsArcList.Count > 0)
    {
      for (int index1 = 0; index1 < this.m_ParkingLotBreaklineList.Count; ++index1)
      {
        Eps_Leg parkingLotBreakline = this.m_ParkingLotBreaklineList[index1];
        for (int index2 = epsLineList.Count - 1; index2 >= 0; --index2)
        {
          Eps_Line _CurrentLine = epsLineList[index2];
          if (Eps_Leg.InsertLineLegSegment(ref parkingLotBreakline, _CurrentLine))
          {
            this.m_ParkingLotBreaklineList[index1] = parkingLotBreakline;
            flag2 = true;
            epsLineList.RemoveAt(index2);
          }
        }
        for (int index3 = epsArcList.Count - 1; index3 >= 0; --index3)
        {
          Eps_Arc _CurrentArc = epsArcList[index3];
          if (Eps_Leg.InsertArcLegSegment(ref parkingLotBreakline, _CurrentArc))
          {
            this.m_ParkingLotBreaklineList[index1] = parkingLotBreakline;
            flag2 = true;
            epsArcList.RemoveAt(index3);
          }
        }
      }
      if (!flag2)
      {
        if (epsLineList.Count > 0)
        {
          this.m_ParkingLotBreaklineList.Add(new Eps_Leg()
          {
            Line = epsLineList[0]
          });
          epsLineList.RemoveAt(0);
        }
        else if (epsArcList.Count > 0)
        {
          this.m_ParkingLotBreaklineList.Add(new Eps_Leg()
          {
            Arc = epsArcList[0]
          });
          epsArcList.RemoveAt(0);
        }
      }
      else
        flag2 = false;
    }
    for (int index = 0; index < this.m_ParkingLotBreaklineList.Count; ++index)
      this.m_ParkingLotBreaklineList[index] = this.m_ParkingLotBreaklineList[index].TopographySurfaceLeg(_SurfaceList, _CurPhase);
  }

  public int FindBreaklineIndexFromElementId(Element CurElement)
  {
    if (CurElement != null && CurElement.Location is LocationCurve location)
    {
      Curve curve = location.Curve;
      if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
      {
        for (int index = 0; index < this.m_ParkingLotBreaklineList.Count; ++index)
        {
          for (Eps_Leg epsLeg1 = this.m_ParkingLotBreaklineList[index]; epsLeg1 != null; epsLeg1 = epsLeg1.Next)
          {
            switch (curve)
            {
              case Arc _ when epsLeg1.Arc != null:
                if (new Eps_Arc((Arc) curve).IsEqual((BaseArc) epsLeg1.Arc))
                  return index;
                break;
              case Line _ when epsLeg1.Line != null:
                if (new Eps_Line((Line) curve).IsEqual((BaseLine) epsLeg1.Line))
                  return index;
                break;
              case Ellipse _:
              case NurbSpline _:
              case HermiteSpline _:
                for (Eps_Leg epsLeg2 = RevitGeometry.GetLegFromSpline(CurElement, curve, false); epsLeg2 != null; epsLeg2 = epsLeg2.Next)
                {
                  if (epsLeg2.Line != null && epsLeg1.Line != null)
                  {
                    if (epsLeg2.Line.IsEqual((BaseLine) epsLeg1.Line))
                      return index;
                  }
                  else if (epsLeg2.Arc != null && epsLeg1.Arc != null && epsLeg2.Arc.IsEqual((BaseArc) epsLeg1.Arc))
                    return index;
                }
                break;
            }
          }
        }
      }
    }
    return -1;
  }

  public ElementSet RemoveBreaklineAndElementsFromList(int _nRemoveBreaklineIndex)
  {
    ElementSet elementSet = new ElementSet();
    bool flag1 = false;
    bool flag2 = false;
    if (this.m_ParkingLotBreaklineFamilyInstanceList.Count == this.m_ParkingLotBreaklineElementList.Count)
      flag2 = true;
    bool flag3 = false;
    if (this.m_ParkingLotBreaklineLinearPointIntervals.Count == this.m_ParkingLotBreaklineElementList.Count)
      flag3 = true;
    if (_nRemoveBreaklineIndex >= 0 && _nRemoveBreaklineIndex < this.m_ParkingLotBreaklineList.Count)
    {
label_41:
      for (Eps_Leg epsLeg1 = this.m_ParkingLotBreaklineList[_nRemoveBreaklineIndex]; epsLeg1 != null; epsLeg1 = epsLeg1.Next)
      {
        for (int index = this.m_ParkingLotBreaklineElementList.Count - 1; index >= 0; --index)
        {
          Element breaklineElement = this.m_ParkingLotBreaklineElementList[index];
          if (breaklineElement != null && breaklineElement.Location is LocationCurve location)
          {
            Curve curve = location.Curve;
            if (GeometryObject.op_Inequality((GeometryObject) curve, (GeometryObject) null))
            {
              switch (curve)
              {
                case Arc _ when epsLeg1.Arc != null:
                  if (new Eps_Arc((Arc) curve).IsEqual((BaseArc) epsLeg1.Arc))
                  {
                    elementSet.Insert(this.m_ParkingLotBreaklineElementList[index]);
                    this.m_ParkingLotBreaklineElementList.RemoveAt(index);
                    if (flag2)
                    {
                      elementSet.Insert((Element) this.m_ParkingLotBreaklineFamilyInstanceList[index]);
                      this.m_ParkingLotBreaklineFamilyInstanceList.RemoveAt(index);
                    }
                    if (flag3)
                    {
                      this.m_ParkingLotBreaklineLinearPointIntervals.RemoveAt(index);
                      goto label_41;
                    }
                    goto label_41;
                  }
                  continue;
                case Line _ when epsLeg1.Line != null:
                  if (new Eps_Line((Line) curve).IsEqual((BaseLine) epsLeg1.Line))
                  {
                    elementSet.Insert(this.m_ParkingLotBreaklineElementList[index]);
                    this.m_ParkingLotBreaklineElementList.RemoveAt(index);
                    if (flag2)
                    {
                      elementSet.Insert((Element) this.m_ParkingLotBreaklineFamilyInstanceList[index]);
                      this.m_ParkingLotBreaklineFamilyInstanceList.RemoveAt(index);
                    }
                    if (flag3)
                    {
                      this.m_ParkingLotBreaklineLinearPointIntervals.RemoveAt(index);
                      goto label_41;
                    }
                    goto label_41;
                  }
                  continue;
                case Ellipse _:
                case NurbSpline _:
                case HermiteSpline _:
                  for (Eps_Leg epsLeg2 = RevitGeometry.GetLegFromSpline(breaklineElement, curve, false); epsLeg2 != null; epsLeg2 = epsLeg2.Next)
                  {
                    if (epsLeg2.Line != null && epsLeg1.Line != null)
                    {
                      if (epsLeg2.Line.IsEqual((BaseLine) epsLeg1.Line))
                      {
                        elementSet.Insert(this.m_ParkingLotBreaklineElementList[index]);
                        this.m_ParkingLotBreaklineElementList.RemoveAt(index);
                        if (flag2)
                        {
                          elementSet.Insert((Element) this.m_ParkingLotBreaklineFamilyInstanceList[index]);
                          this.m_ParkingLotBreaklineFamilyInstanceList.RemoveAt(index);
                        }
                        if (flag3)
                          this.m_ParkingLotBreaklineLinearPointIntervals.RemoveAt(index);
                        flag1 = true;
                        break;
                      }
                    }
                    else if (epsLeg2.Arc != null && epsLeg1.Arc != null && epsLeg2.Arc.IsEqual((BaseArc) epsLeg1.Arc))
                    {
                      elementSet.Insert(this.m_ParkingLotBreaklineElementList[index]);
                      this.m_ParkingLotBreaklineElementList.RemoveAt(index);
                      if (flag2)
                      {
                        elementSet.Insert((Element) this.m_ParkingLotBreaklineFamilyInstanceList[index]);
                        this.m_ParkingLotBreaklineFamilyInstanceList.RemoveAt(index);
                      }
                      if (flag3)
                        this.m_ParkingLotBreaklineLinearPointIntervals.RemoveAt(index);
                      flag1 = true;
                      break;
                    }
                  }
                  if (flag1)
                  {
                    flag1 = false;
                    goto label_41;
                  }
                  continue;
                default:
                  continue;
              }
            }
          }
        }
      }
      this.m_ParkingLotBreaklineList.RemoveAt(_nRemoveBreaklineIndex);
    }
    return elementSet;
  }

  public string ChainID => this.m_strChainID;

  public List<FamilyInstanceComponentContainer> FamilyContainerList => this.m_FamilyContainerList;

  public Eps_Leg ProposedLeg
  {
    get => this.m_ProposedLeg;
    set => this.m_ProposedLeg = value;
  }

  public Eps_Leg InstanceLeg
  {
    get
    {
      if (this.m_ProposedLeg != null)
        return this.m_ProposedLeg;
      return this.m_OriginalLeg != null ? this.m_OriginalLeg : (Eps_Leg) null;
    }
    set => this.m_ProposedLeg = value;
  }

  public ElementSet ProposedElementSet
  {
    get => this.m_ProposedElementSet;
    set => this.m_ProposedElementSet = value;
  }

  public Eps_Leg OriginalLeg => this.m_OriginalLeg;

  public int DrawOrder
  {
    get => this.m_nDrawOrder;
    set => this.m_nDrawOrder = value;
  }

  public FamilySymbol ProposedFamilySymbol
  {
    get => this.m_ProposedFamilySymbol;
    set
    {
      this.m_ProposedFamilySymbol = value;
      if (this.m_OriginalFamilySymbol == null)
        this.m_OriginalFamilySymbol = value;
      this.ApplyFormDepthToLegs();
    }
  }

  public FamilySymbol OriginalFamilySymbol => this.m_OriginalFamilySymbol;

  public FamilySymbol IntersectionFamilySymbol
  {
    get => this.m_IntersectionFamilySymbol;
    set => this.m_IntersectionFamilySymbol = value;
  }

  public List<FamilyInstance> IntersectionFamilyInstanceList
  {
    get => this.m_IntersectionFamilyInstanceList;
    set => this.m_IntersectionFamilyInstanceList = value;
  }

  public FamilyInstance FindIntersectionFamilyInstance(ElementId id)
  {
    foreach (FamilyInstance intersectionFamilyInstance in this.IntersectionFamilyInstanceList)
    {
      if (ElementId.op_Equality(((Element) intersectionFamilyInstance).Id, id))
        return intersectionFamilyInstance;
    }
    return (FamilyInstance) null;
  }

  public void AddIntersectionFamilyInstances(List<FamilyInstance> familyInstances)
  {
    foreach (FamilyInstance familyInstance in familyInstances)
    {
      if (this.FindIntersectionFamilyInstance(((Element) familyInstance).Id) == null)
        this.IntersectionFamilyInstanceList.Add(familyInstance);
    }
  }

  public TopographySurfaceContainer ParkingLotTopographySurface
  {
    get => this.m_ParkingLotTopographySurface;
    set => this.m_ParkingLotTopographySurface = value;
  }

  public List<Eps_Leg> ParkingLotBreaklineList
  {
    get => this.m_ParkingLotBreaklineList;
    set => this.m_ParkingLotBreaklineList = value;
  }

  public List<Element> ParkingLotBreaklineElementList
  {
    get => this.m_ParkingLotBreaklineElementList;
    set => this.m_ParkingLotBreaklineElementList = value;
  }

  public ElementSet ParkingLotBreaklineElementSet
  {
    get
    {
      ElementSet breaklineElementSet = new ElementSet();
      for (int index = this.m_ParkingLotBreaklineElementList.Count - 1; index >= 0; --index)
        breaklineElementSet.Insert(this.m_ParkingLotBreaklineElementList[index]);
      return breaklineElementSet;
    }
  }

  public List<FamilyInstance> ParkingLotBreaklineFamilyInstanceList
  {
    get => this.m_ParkingLotBreaklineFamilyInstanceList;
    set => this.m_ParkingLotBreaklineFamilyInstanceList = value;
  }

  public FamilyInstance PrimarySiteComponentMass
  {
    get => this.m_PrimarySiteComponentMass;
    set => this.m_PrimarySiteComponentMass = value;
  }

  public FamilyInstance AdditionalSiteComponentMass
  {
    get => this.m_AdditionalSiteComponentMass;
    set => this.m_AdditionalSiteComponentMass = value;
  }

  public DirectShape PrimarySiteComponentDirectShape
  {
    get => this.m_PrimarySiteComponentDirectShape;
    set => this.m_PrimarySiteComponentDirectShape = value;
  }

  public DirectShape AdditionalSiteComponentDirectShape
  {
    get => this.m_AdditionalSiteComponentDirectShape;
    set => this.m_AdditionalSiteComponentDirectShape = value;
  }

  public LandcaddID LandcaddId => this.m_CurrentLandcaddId;

  public List<double> ParkingLotBreaklineLinearPointIntervals
  {
    get => this.m_ParkingLotBreaklineLinearPointIntervals;
    set => this.m_ParkingLotBreaklineLinearPointIntervals = value;
  }

  public List<IntersectionStationContainer> LeftIntersectionStations
  {
    get => this.m_LeftIntersectionStations;
    set => this.m_LeftIntersectionStations = value;
  }

  public List<IntersectionStationContainer> RightIntersectionStations
  {
    get => this.m_RightIntersectionStations;
    set => this.m_RightIntersectionStations = value;
  }

  public List<IntersectionStationContainer> CenterIntersectionStations
  {
    get => this.m_CenterIntersectionStations;
    set => this.m_CenterIntersectionStations = value;
  }

  public List<IntersectionContainer> IntersectionContainerList
  {
    get => this.m_IntersectionContainerList;
    set => this.m_IntersectionContainerList = value;
  }

  public bool RedrawForm
  {
    get => this.m_bRedrawForm;
    set => this.m_bRedrawForm = value;
  }
}
