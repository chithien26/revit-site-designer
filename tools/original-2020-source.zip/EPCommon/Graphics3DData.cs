﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Graphics3DData
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class Graphics3DData
{
  private const double m_dRotateAngle = 0.034906585039886591;
  private readonly List<List<Vector>> m_IniCurves = new List<List<Vector>>();
  private readonly List<List<Vector>> m_Curves = new List<List<Vector>>();
  private readonly int m_NumPoints;
  private BoundingBoxXYZ m_BoundingBox = new BoundingBoxXYZ();
  private UCS m_CurrentUCS = new UCS();
  private static readonly UCS[] SpecialUCSs = new UCS[7];
  private static readonly UCS RotateXUCS;
  private static readonly UCS RotateAntiXUCS;
  private static readonly UCS RotateYUCS;
  private static readonly UCS RotateAntiYUCS;
  private static readonly UCS RotateZUCS;
  private static readonly UCS RotateAntiZUCS;

  public UCS CurrentUCS
  {
    get => this.m_CurrentUCS;
    set
    {
      this.m_CurrentUCS = value;
      this.UpdateDisplayData(this.m_CurrentUCS);
      if (this.UpdateViewEvent == null)
        return;
      this.UpdateViewEvent();
    }
  }

  public int NumPoints => this.m_NumPoints;

  static Graphics3DData()
  {
    double num1 = Math.PI / 90.0;
    double num2 = -1.0 * Math.PI / 90.0;
    double num3 = Math.Sin(num1);
    double num4 = Math.Cos(num1);
    double num5 = Math.Sin(num2);
    double num6 = Math.Cos(num2);
    Vector origin = new Vector();
    Graphics3DData.RotateXUCS = new UCS(origin, new Vector(1.0, 0.0, 0.0), new Vector(0.0, num4, num3));
    Graphics3DData.RotateAntiXUCS = new UCS(origin, new Vector(1.0, 0.0, 0.0), new Vector(0.0, num6, num5));
    Graphics3DData.RotateYUCS = new UCS(origin, new Vector(num4, 0.0, -num3), new Vector(0.0, 1.0, 0.0));
    Graphics3DData.RotateAntiYUCS = new UCS(origin, new Vector(num6, 0.0, -num5), new Vector(0.0, 1.0, 0.0));
    Graphics3DData.RotateZUCS = new UCS(origin, new Vector(num4, num3, 0.0), new Vector(-num3, num4, 0.0));
    Graphics3DData.RotateAntiZUCS = new UCS(origin, new Vector(num6, num5, 0.0), new Vector(-num5, num6, 0.0));
    Graphics3DData.SpecialUCSs[6] = new UCS(origin, new Vector(-0.408248290463863, 0.408248290463863, 0.816496580927726), new Vector(0.707106781186548, 0.707106781186548, 0.0));
    Graphics3DData.SpecialUCSs[0] = new UCS(origin, new Vector(1.0, 0.0, 0.0), new Vector(0.0, 1.0, 0.0));
    Graphics3DData.SpecialUCSs[1] = new UCS(origin, new Vector(-1.0, 0.0, 0.0), new Vector(0.0, 0.0, 1.0));
    Graphics3DData.SpecialUCSs[2] = new UCS(origin, new Vector(0.0, -1.0, 0.0), new Vector(0.0, 0.0, 1.0));
    Graphics3DData.SpecialUCSs[3] = new UCS(origin, new Vector(0.0, 1.0, 0.0), new Vector(0.0, 0.0, 1.0));
    Graphics3DData.SpecialUCSs[4] = new UCS(origin, new Vector(-1.0, 0.0, 0.0), new Vector(0.0, 1.0, 0.0));
    Graphics3DData.SpecialUCSs[5] = new UCS(origin, new Vector(1.0, 0.0, 0.0), new Vector(0.0, 0.0, 1.0));
  }

  public event UpdateViewDelegate UpdateViewEvent;

  public List<List<Vector>> ConstCurves => this.m_Curves;

  public BoundingBoxXYZ BoundingBox => this.m_BoundingBox;

  public Graphics3DData(List<IList<XYZ>> _Curves, BoundingBoxXYZ _BoundingBox)
  {
    if (_BoundingBox == null)
      return;
    foreach (UCS specialUcS in Graphics3DData.SpecialUCSs)
      specialUcS.Origin = this.FindBBoxCenter(_BoundingBox);
    foreach (IList<XYZ> curve in _Curves)
    {
      List<Vector> vectorList = new List<Vector>();
      this.m_IniCurves.Add(vectorList);
      foreach (XYZ xyz in (IEnumerable<XYZ>) curve)
      {
        vectorList.Add(new Vector(xyz.X, xyz.Y, xyz.Z));
        ++this.m_NumPoints;
      }
    }
    this.SetViewDirection(Graphics3DData.ViewDirections.IsoMetric);
    this.InitializeBBox(_BoundingBox);
  }

  public void SetViewDirection(Graphics3DData.ViewDirections viewDirection)
  {
    this.m_CurrentUCS = Graphics3DData.SpecialUCSs[(int) viewDirection];
    this.UpdateDisplayData(this.m_CurrentUCS);
  }

  public void RotateZ(bool _bDirection)
  {
    if (_bDirection)
    {
      this.m_CurrentUCS += Graphics3DData.RotateZUCS;
      this.UpdateDisplayData(this.m_CurrentUCS);
    }
    else
    {
      this.m_CurrentUCS += Graphics3DData.RotateAntiZUCS;
      this.UpdateDisplayData(this.m_CurrentUCS);
    }
  }

  public void RotateY(bool _bDirection)
  {
    if (_bDirection)
    {
      this.m_CurrentUCS += Graphics3DData.RotateYUCS;
      this.UpdateDisplayData(this.m_CurrentUCS);
    }
    else
    {
      this.m_CurrentUCS += Graphics3DData.RotateAntiYUCS;
      this.UpdateDisplayData(this.m_CurrentUCS);
    }
  }

  public void RotateX(bool _bDirection)
  {
    if (_bDirection)
    {
      this.m_CurrentUCS += Graphics3DData.RotateXUCS;
      this.UpdateDisplayData(this.m_CurrentUCS);
    }
    else
    {
      this.m_CurrentUCS += Graphics3DData.RotateAntiXUCS;
      this.UpdateDisplayData(this.m_CurrentUCS);
    }
  }

  private void UpdateDisplayData(UCS _LC)
  {
    this.m_Curves.Clear();
    foreach (List<Vector> iniCurve in this.m_IniCurves)
    {
      List<Vector> vectorList = new List<Vector>();
      this.m_Curves.Add(vectorList);
      for (int index = 0; index < iniCurve.Count; ++index)
        vectorList.Add(_LC.GC2LC(iniCurve[index]));
    }
    if (this.UpdateViewEvent == null)
      return;
    this.UpdateViewEvent();
  }

  private void InitializeBBox(BoundingBoxXYZ _BoundingBox)
  {
    XYZ lhs = MathUtil.SubXYZ(_BoundingBox.Max, _BoundingBox.Min);
    this.m_BoundingBox.Max = MathUtil.DivideXYZ(lhs, 2.0);
    this.m_BoundingBox.Min = MathUtil.DivideXYZ(lhs, -2.0);
  }

  private Vector FindBBoxCenter(BoundingBoxXYZ _BoundingBox)
  {
    return MathUtil.XYZ2Vector(MathUtil.DivideXYZ(MathUtil.AddXYZ(_BoundingBox.Max, _BoundingBox.Min), 2.0));
  }

  public enum ViewDirections
  {
    Top,
    Front,
    Left,
    Right,
    Bottom,
    Back,
    IsoMetric,
  }
}
