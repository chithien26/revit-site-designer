﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantBookletForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantBookletForm : EPForm
{
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private int m_nMixtListViewSortColumn = -1;
  private PlantBooklet m_dataBuffer;
  private List<FamilySymbol> m_LocalList = new List<FamilySymbol>();
  private IContainer components;
  private Button m_ExportButton;
  private Button m_CancelButton;
  private GroupBox m_DynGroupBox;
  private ListView m_TypeListView;
  private RadioButton m_AllInstancesRadioButton;
  private GroupBox m_SelectionMethodsGroupBox;
  private RadioButton m_WindowSelectRadioButton;
  private RadioButton m_SelectionSetRadioButton;
  private Button m_PickButton;
  private GroupBox m_ExportOptionsGroupBox;
  private TextBox m_ExportFileTextBox;
  private Button m_ExportFileButton;
  private Label m_ExportFileLabel;
  private RichTextBox m_RTFTextBox;

  public PlantBookletForm(PlantBooklet _dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("PlantBookletDialog");
    this.m_SelectionMethodsGroupBox.Text = EPShared.LocalRM.GetString("SelectionMethodsDialog");
    this.m_SelectionSetRadioButton.Text = EPShared.LocalRM.GetString("AMP_SelectionSetDialog");
    this.m_WindowSelectRadioButton.Text = EPShared.LocalRM.GetString("AMP_WindowSelectDialog");
    this.m_AllInstancesRadioButton.Text = EPShared.LocalRM.GetString("All_AMP_InstancesDialog");
    this.m_PickButton.Text = EPShared.LocalRM.GetString("AMP_PickDialog");
    this.m_DynGroupBox.Text = EPShared.LocalRM.GetString("PlantsDialog");
    this.m_ExportOptionsGroupBox.Text = EPShared.LocalRM.GetString("ExportOptionsDialog");
    this.m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_ExportButton.Text = EPShared.LocalRM.GetString("AMP_ExportDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.EPToolTip.SetToolTip((Control) this.m_ExportFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
    this.m_dataBuffer = _dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    this.GetDialogPosition();
    this.m_SelectionSetRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantBookletSelectMethodOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_SelectionSetRadioButton.Checked = true;
          break;
        case 1:
          this.m_WindowSelectRadioButton.Checked = true;
          break;
        default:
          this.m_AllInstancesRadioButton.Checked = true;
          break;
      }
    }
    string empty = string.Empty;
    ApplicationUtility.Settings.eplSetE_GetSetting("PlantBookletExportTextField", ref empty);
    this.m_ExportFileTextBox.Text = empty;
    this.SetupListView();
  }

  private void SetupListView()
  {
    this.m_LocalList = this.m_dataBuffer.ExistingPlantSymbolList;
    this.m_TypeListView.View = View.Details;
    this.m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("FamilyString"));
    this.m_TypeListView.Columns.Add(EPShared.LocalRM.GetString("TypeNamePlantFamilyType"));
    int num = (this.m_TypeListView.Width - 5) / this.m_TypeListView.Columns.Count;
    for (int index = 0; index < this.m_TypeListView.Columns.Count; ++index)
      this.m_TypeListView.Columns[index].Width = num;
  }

  public void UpdateListView()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    string empty = string.Empty;
    this.m_LocalList.Clear();
    this.m_TypeListView.Items.Clear();
    foreach (Element instance in this.m_dataBuffer.InstanceSet)
    {
      if (instance is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
        this.UpdateFamilySymbolContainerList(familyInstance.Symbol);
    }
    for (int index = 0; index < this.m_LocalList.Count; ++index)
    {
      string name = EPShared.LocalRM.GetString("NotAvailableString");
      ListViewItem listViewItem2 = this.m_TypeListView.Items.Insert(index, ((Element) this.m_LocalList[index].Family).Name, ((Element) this.m_LocalList[index].Family).Name, string.Empty);
      listViewItem2.Tag = (object) ((Element) this.m_LocalList[index].Family).Name;
      if (string.Compare(((Element) this.m_LocalList[index]).Name, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
        name = ((Element) this.m_LocalList[index]).Name;
      listViewItem2.SubItems.Add(name);
    }
  }

  private void UpdateFamilySymbolContainerList(FamilySymbol _SelectedSymbol)
  {
    FamilySymbolContainer familySymbolContainer = (FamilySymbolContainer) null;
    familySymbolContainer = new FamilySymbolContainer();
    for (int index = 0; index < this.m_LocalList.Count; ++index)
    {
      if (string.Compare(((Element) this.m_LocalList[index]).Name, ((Element) _SelectedSymbol).Name, true) == 0)
        return;
    }
    this.m_LocalList.Add(_SelectedSymbol);
  }

  private void OnExportPlantBookletButtonClicked(object sender, EventArgs e)
  {
    this.CreateRTFFile();
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void CancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnPlantBookletFormFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantBookletSelectMethodOption", !this.m_SelectionSetRadioButton.Checked ? (!this.m_WindowSelectRadioButton.Checked ? 2 : 1) : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantBookletExportTextField", this.m_ExportFileTextBox.Text);
  }

  private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nMixtListViewSortColumn)
    {
      this.m_nMixtListViewSortColumn = e.Column;
      this.m_TypeListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_TypeListView.Sorting = this.m_TypeListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_TypeListView.Sort();
    this.m_TypeListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_TypeListView.Sorting);
  }

  private void UpdateList(int _nSelectedListIndex)
  {
    this.m_TypeListView.Items.RemoveAt(_nSelectedListIndex);
    ListViewItem listViewItem1 = (ListViewItem) null;
    string name = EPShared.LocalRM.GetString("NotAvailableString");
    listViewItem1 = new ListViewItem();
    ListViewItem listViewItem2 = this.m_TypeListView.Items.Insert(_nSelectedListIndex, ((Element) this.m_LocalList[_nSelectedListIndex].Family).Name, ((Element) this.m_LocalList[_nSelectedListIndex].Family).Name, string.Empty);
    if (string.Compare(((Element) this.m_LocalList[_nSelectedListIndex]).Name, EPShared.LocalRM.GetString("NotAvailableString"), true) != 0)
      name = ((Element) this.m_LocalList[_nSelectedListIndex]).Name;
    listViewItem2.SubItems.Add(name);
  }

  private void OnExportFileButtonClicked(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.Filter = ApplicationUtility.GetString("RTFFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.CheckFileExists)
    {
      switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("OverwriteMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxButtons.YesNo, MessageBoxIcon.Hand))
      {
        case DialogResult.Cancel:
          return;
        case DialogResult.No:
          return;
      }
    }
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_ExportFileTextBox.Text = saveFileDialog.FileName;
  }

  private void OnExportFileTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.AddExtensionToExportFile();
  }

  private void CreateRTFFile()
  {
    if (this.m_ExportFileTextBox.Text == string.Empty)
      return;
    ElementSet elementSet = new ElementSet();
    List<FamilySymbol> familySymbolList = new List<FamilySymbol>();
    if (this.m_TypeListView.SelectedItems.Count >= 1)
    {
      for (int index = 0; index < this.m_TypeListView.SelectedIndices.Count; ++index)
        familySymbolList.Add(this.m_LocalList[this.m_TypeListView.SelectedIndices[index]]);
      foreach (Element instance in this.m_dataBuffer.InstanceSet)
      {
        if (instance is FamilyInstance familyInstance)
        {
          for (int index = 0; index < familySymbolList.Count; ++index)
          {
            if (string.Compare(((Element) familyInstance.Symbol).Name, ((Element) familySymbolList[index]).Name, true) == 0)
            {
              elementSet.Insert((Element) familyInstance);
              break;
            }
          }
        }
      }
      if (familySymbolList.Count <= 0)
        return;
      bool flag1 = false;
      List<string> stringList = new List<string>();
      stringList.Add(EPShared.LocalRM.GetString("TrunkRadiusPlantParameter"));
      stringList.Add(EPShared.LocalRM.GetString("TrunkHeightPlantParameter"));
      stringList.Add(EPShared.LocalRM.GetString("TickLengthPlantParameter"));
      stringList.Add(EPShared.LocalRM.GetString("RadiusPlantParameter"));
      stringList.Add(EPShared.LocalRM.GetString("OmniClassTitlePlantParameter"));
      stringList.Add(EPShared.LocalRM.GetString("OmniClassNumberPlantParameter"));
      stringList.Add(EPShared.LocalRM.GetString("RPCRenderAppearancePropertiesFamilyParameter"));
      stringList.Add(EPShared.LocalRM.GetString("RPCRenderAppearanceFamilyParameter"));
      if (this.m_ExportFileTextBox.Text.IndexOf(".rtf") < 0)
      {
        if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
        {
          int length = -1;
          if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
            length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
          else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
            length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
          if (Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
          {
            this.m_ExportFileTextBox.Text += ".rtf";
          }
          else
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return;
        }
      }
      else if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
      {
        int length = -1;
        if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
        else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
        if (!Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return;
        }
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return;
      }
      if (File.Exists(this.m_ExportFileTextBox.Text))
      {
        if (RevitMessageBox.Show(EPShared.LocalRM.GetString("FileOverwriteMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
          File.Delete(this.m_ExportFileTextBox.Text);
        else
          flag1 = true;
      }
      if (flag1)
        this.m_RTFTextBox.LoadFile(this.m_ExportFileTextBox.Text);
      else
        this.m_RTFTextBox.Text = "";
      Font font1 = new Font("Arial", 16f, FontStyle.Bold);
      Font font2 = new Font("Arial", 14f, FontStyle.Bold);
      Font font3 = new Font("Arial", 12f, FontStyle.Bold);
      Font font4 = new Font("Arial", 12f, FontStyle.Regular);
      this.m_RTFTextBox.Multiline = true;
      Dictionary<string, string> source1 = new Dictionary<string, string>();
      Dictionary<string, string> source2 = new Dictionary<string, string>();
      Dictionary<string, string> source3 = new Dictionary<string, string>();
      Dictionary<string, string> source4 = new Dictionary<string, string>();
      Dictionary<string, string> source5 = new Dictionary<string, string>();
      Dictionary<string, string> source6 = new Dictionary<string, string>();
      List<Element> list = new FilteredElementCollector(this.m_dataBuffer.Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements().ToList<Element>();
      this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
      foreach (FamilySymbol _FamilySymbol in familySymbolList)
      {
        string empty1 = string.Empty;
        string empty2 = string.Empty;
        bool flag2 = false;
        bool flag3 = false;
        Parameter parameter1 = (Parameter) null;
        Parameter parameter2 = (Parameter) null;
        Eps_Point _SecondCheckPnt = new Eps_Point();
        if (_FamilySymbol != null)
        {
          List<Eps_Point> _PointList = (List<Eps_Point>) null;
          foreach (Element element in list)
          {
            if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) _FamilySymbol).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
            {
              if (_PointList == null)
                _PointList = new List<Eps_Point>();
              Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
              if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
                _PointList.Add(_FindPoint);
            }
          }
          if (_PointList != null && _PointList.Count > 0)
          {
            bool flag4 = true;
            while (flag4)
            {
              flag4 = false;
              for (int index = 0; index < _PointList.Count; ++index)
              {
                if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index], _SecondCheckPnt))
                {
                  ++_SecondCheckPnt.z;
                  flag4 = true;
                  break;
                }
              }
            }
          }
          EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
          FamilyInstance familyInstance1 = RevitUtility.NewFamilyInstance(this.m_dataBuffer.Document, _SecondCheckPnt.XYZ, _FamilySymbol, (Element) null, this.m_dataBuffer.Document.ActiveView.GenLevel, (StructuralType) 0, ref transactionContainer);
          this.m_dataBuffer.TransactionContainer = transactionContainer;
          if (familyInstance1 != null)
          {
            parameter1 = ((Element) familyInstance1).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
            if (parameter1 != null)
              flag2 = true;
            parameter2 = ((Element) familyInstance1).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
            if (parameter2 != null)
              flag3 = true;
          }
          this.m_RTFTextBox.SelectedText += "\t\t\t\t\t";
          this.m_RTFTextBox.SelectionFont = font1;
          this.m_RTFTextBox.SelectedText += ((Element) _FamilySymbol).Name;
          this.m_RTFTextBox.SelectedText += "\n";
          this.m_RTFTextBox.SelectedText += "\n";
          foreach (Parameter parameter3 in ((Element) _FamilySymbol).Parameters)
          {
            string name = parameter3.Definition.Name;
            string str = (parameter3.StorageType != 3 ? parameter3.AsValueString() : parameter3.AsString()) ?? string.Empty;
            if (name.StartsWith(EPShared.LocalRM.GetString("Plant"), true, CultureInfo.CurrentCulture))
            {
              if (str != string.Empty && (string.Compare(name, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) != 0 || !flag2) && (string.Compare(name, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) != 0 || flag3))
              {
                try
                {
                  source1.Add(name, str);
                }
                catch
                {
                }
              }
            }
            else if (name.StartsWith(EPShared.LocalRM.GetString("Characteristics"), true, CultureInfo.CurrentCulture))
            {
              if (str != string.Empty)
              {
                string key = name.Remove(0, EPShared.LocalRM.GetString("Characteristics").Length + 1);
                try
                {
                  source2.Add(key, str);
                }
                catch
                {
                }
              }
            }
            else if (name.StartsWith(EPShared.LocalRM.GetString("Condition"), true, CultureInfo.CurrentCulture))
            {
              if (str != string.Empty)
              {
                string key = name.Remove(0, EPShared.LocalRM.GetString("Condition").Length + 1);
                try
                {
                  source3.Add(key, str);
                }
                catch
                {
                }
              }
            }
            else if (name.StartsWith(EPShared.LocalRM.GetString("Growth"), true, CultureInfo.CurrentCulture))
            {
              if (str != string.Empty)
              {
                string key = name.Remove(0, EPShared.LocalRM.GetString("Growth").Length + 1);
                try
                {
                  source4.Add(key, str);
                }
                catch
                {
                }
              }
            }
            else if (name.StartsWith(EPShared.LocalRM.GetString("Maintenance"), true, CultureInfo.CurrentCulture))
            {
              if (str != string.Empty)
              {
                string key = name.Remove(0, EPShared.LocalRM.GetString("Maintenance").Length + 1);
                try
                {
                  source5.Add(key, str);
                }
                catch
                {
                }
              }
            }
            else if (str != string.Empty && (string.Compare(name, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) != 0 || !flag2))
            {
              try
              {
                source6.Add(name, str);
              }
              catch
              {
              }
            }
          }
          if (flag2)
            source1.Add(parameter1.Definition.Name, parameter1.AsValueString());
          if (flag3)
            source1.Add(parameter2.Definition.Name, parameter2.AsValueString());
          this.m_dataBuffer.TransactionContainer.BeginTransaction();
          this.m_dataBuffer.Document.Delete(((Element) familyInstance1).Id);
          this.m_dataBuffer.TransactionContainer.EndTransaction();
          KeyValuePair<string, string> keyValuePair;
          for (int index = 0; index < source1.Count; ++index)
          {
            keyValuePair = source1.ElementAt<KeyValuePair<string, string>>(index);
            if (keyValuePair.Value != string.Empty)
            {
              List<string> _List = stringList;
              keyValuePair = source1.ElementAt<KeyValuePair<string, string>>(index);
              string key1 = keyValuePair.Key;
              if (!PlantBookletForm.FindMatch(_List, key1))
              {
                this.m_RTFTextBox.SelectionFont = font3;
                RichTextBox rtfTextBox1 = this.m_RTFTextBox;
                string selectedText1 = rtfTextBox1.SelectedText;
                keyValuePair = source1.ElementAt<KeyValuePair<string, string>>(index);
                string key2 = keyValuePair.Key;
                rtfTextBox1.SelectedText = selectedText1 + key2;
                keyValuePair = source1.ElementAt<KeyValuePair<string, string>>(index);
                if (keyValuePair.Value != string.Empty)
                {
                  this.m_RTFTextBox.SelectionFont = font4;
                  this.m_RTFTextBox.SelectedText += " = ";
                  RichTextBox rtfTextBox2 = this.m_RTFTextBox;
                  string selectedText2 = rtfTextBox2.SelectedText;
                  keyValuePair = source1.ElementAt<KeyValuePair<string, string>>(index);
                  string str = keyValuePair.Value;
                  rtfTextBox2.SelectedText = selectedText2 + str;
                }
                this.m_RTFTextBox.SelectedText += "\n";
              }
            }
          }
          if (source2.Count > 0)
          {
            this.m_RTFTextBox.SelectionFont = font2;
            this.m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Characteristics");
            this.m_RTFTextBox.SelectedText += "\n";
            for (int index = 0; index < source2.Count; ++index)
            {
              keyValuePair = source2.ElementAt<KeyValuePair<string, string>>(index);
              if (keyValuePair.Value != string.Empty)
              {
                List<string> _List = stringList;
                keyValuePair = source2.ElementAt<KeyValuePair<string, string>>(index);
                string key3 = keyValuePair.Key;
                if (!PlantBookletForm.FindMatch(_List, key3))
                {
                  this.m_RTFTextBox.SelectedText += "\t";
                  this.m_RTFTextBox.SelectionFont = font3;
                  RichTextBox rtfTextBox3 = this.m_RTFTextBox;
                  string selectedText3 = rtfTextBox3.SelectedText;
                  keyValuePair = source2.ElementAt<KeyValuePair<string, string>>(index);
                  string key4 = keyValuePair.Key;
                  rtfTextBox3.SelectedText = selectedText3 + key4;
                  keyValuePair = source2.ElementAt<KeyValuePair<string, string>>(index);
                  if (keyValuePair.Value != string.Empty)
                  {
                    this.m_RTFTextBox.SelectionFont = font4;
                    this.m_RTFTextBox.SelectedText += " = ";
                    RichTextBox rtfTextBox4 = this.m_RTFTextBox;
                    string selectedText4 = rtfTextBox4.SelectedText;
                    keyValuePair = source2.ElementAt<KeyValuePair<string, string>>(index);
                    string str = keyValuePair.Value;
                    rtfTextBox4.SelectedText = selectedText4 + str;
                  }
                  this.m_RTFTextBox.SelectedText += "\n";
                }
              }
            }
          }
          if (source3.Count > 0)
          {
            this.m_RTFTextBox.SelectionFont = font3;
            this.m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Condition");
            this.m_RTFTextBox.SelectedText += "\n";
            for (int index = 0; index < source3.Count; ++index)
            {
              keyValuePair = source3.ElementAt<KeyValuePair<string, string>>(index);
              if (keyValuePair.Value != string.Empty)
              {
                List<string> _List = stringList;
                keyValuePair = source3.ElementAt<KeyValuePair<string, string>>(index);
                string key5 = keyValuePair.Key;
                if (!PlantBookletForm.FindMatch(_List, key5))
                {
                  this.m_RTFTextBox.SelectionFont = font3;
                  this.m_RTFTextBox.SelectedText += "\t";
                  RichTextBox rtfTextBox5 = this.m_RTFTextBox;
                  string selectedText5 = rtfTextBox5.SelectedText;
                  keyValuePair = source3.ElementAt<KeyValuePair<string, string>>(index);
                  string key6 = keyValuePair.Key;
                  rtfTextBox5.SelectedText = selectedText5 + key6;
                  keyValuePair = source3.ElementAt<KeyValuePair<string, string>>(index);
                  if (keyValuePair.Value != string.Empty)
                  {
                    this.m_RTFTextBox.SelectionFont = font4;
                    this.m_RTFTextBox.SelectedText += " = ";
                    RichTextBox rtfTextBox6 = this.m_RTFTextBox;
                    string selectedText6 = rtfTextBox6.SelectedText;
                    keyValuePair = source3.ElementAt<KeyValuePair<string, string>>(index);
                    string str = keyValuePair.Value;
                    rtfTextBox6.SelectedText = selectedText6 + str;
                  }
                  this.m_RTFTextBox.SelectedText += "\n";
                }
              }
            }
          }
          if (source4.Count > 0)
          {
            this.m_RTFTextBox.SelectionFont = font2;
            this.m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Growth");
            this.m_RTFTextBox.SelectedText += "\n";
            for (int index = 0; index < source4.Count; ++index)
            {
              keyValuePair = source4.ElementAt<KeyValuePair<string, string>>(index);
              if (keyValuePair.Value != string.Empty)
              {
                List<string> _List = stringList;
                keyValuePair = source4.ElementAt<KeyValuePair<string, string>>(index);
                string key7 = keyValuePair.Key;
                if (!PlantBookletForm.FindMatch(_List, key7))
                {
                  this.m_RTFTextBox.SelectedText += "\t";
                  this.m_RTFTextBox.SelectionFont = font3;
                  RichTextBox rtfTextBox7 = this.m_RTFTextBox;
                  string selectedText7 = rtfTextBox7.SelectedText;
                  keyValuePair = source4.ElementAt<KeyValuePair<string, string>>(index);
                  string key8 = keyValuePair.Key;
                  rtfTextBox7.SelectedText = selectedText7 + key8;
                  keyValuePair = source4.ElementAt<KeyValuePair<string, string>>(index);
                  if (keyValuePair.Value != string.Empty)
                  {
                    this.m_RTFTextBox.SelectionFont = font4;
                    this.m_RTFTextBox.SelectedText += " = ";
                    RichTextBox rtfTextBox8 = this.m_RTFTextBox;
                    string selectedText8 = rtfTextBox8.SelectedText;
                    keyValuePair = source4.ElementAt<KeyValuePair<string, string>>(index);
                    string str = keyValuePair.Value;
                    rtfTextBox8.SelectedText = selectedText8 + str;
                  }
                  this.m_RTFTextBox.SelectedText += "\n";
                }
              }
            }
          }
          if (source5.Count > 0)
          {
            this.m_RTFTextBox.SelectionFont = font2;
            this.m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Maintenance");
            this.m_RTFTextBox.SelectedText += "\n";
            for (int index = 0; index < source5.Count; ++index)
            {
              keyValuePair = source5.ElementAt<KeyValuePair<string, string>>(index);
              if (keyValuePair.Value != string.Empty)
              {
                List<string> _List = stringList;
                keyValuePair = source5.ElementAt<KeyValuePair<string, string>>(index);
                string key9 = keyValuePair.Key;
                if (!PlantBookletForm.FindMatch(_List, key9))
                {
                  this.m_RTFTextBox.SelectedText += "\t";
                  this.m_RTFTextBox.SelectionFont = font3;
                  RichTextBox rtfTextBox9 = this.m_RTFTextBox;
                  string selectedText9 = rtfTextBox9.SelectedText;
                  keyValuePair = source5.ElementAt<KeyValuePair<string, string>>(index);
                  string key10 = keyValuePair.Key;
                  rtfTextBox9.SelectedText = selectedText9 + key10;
                  keyValuePair = source5.ElementAt<KeyValuePair<string, string>>(index);
                  if (keyValuePair.Value != string.Empty)
                  {
                    this.m_RTFTextBox.SelectionFont = font4;
                    this.m_RTFTextBox.SelectedText += " = ";
                    RichTextBox rtfTextBox10 = this.m_RTFTextBox;
                    string selectedText10 = rtfTextBox10.SelectedText;
                    keyValuePair = source5.ElementAt<KeyValuePair<string, string>>(index);
                    string str = keyValuePair.Value;
                    rtfTextBox10.SelectedText = selectedText10 + str;
                  }
                  this.m_RTFTextBox.SelectedText += "\n";
                }
              }
            }
          }
          if (source6.Count > 0)
          {
            this.m_RTFTextBox.SelectionFont = font2;
            this.m_RTFTextBox.SelectedText += EPShared.LocalRM.GetString("Others");
            this.m_RTFTextBox.SelectedText += "\n";
            for (int index = 0; index < source6.Count; ++index)
            {
              keyValuePair = source6.ElementAt<KeyValuePair<string, string>>(index);
              if (keyValuePair.Value != string.Empty)
              {
                List<string> _List = stringList;
                keyValuePair = source6.ElementAt<KeyValuePair<string, string>>(index);
                string key11 = keyValuePair.Key;
                if (!PlantBookletForm.FindMatch(_List, key11))
                {
                  this.m_RTFTextBox.SelectionFont = font3;
                  this.m_RTFTextBox.SelectedText += "\t";
                  RichTextBox rtfTextBox11 = this.m_RTFTextBox;
                  string selectedText11 = rtfTextBox11.SelectedText;
                  keyValuePair = source6.ElementAt<KeyValuePair<string, string>>(index);
                  string key12 = keyValuePair.Key;
                  rtfTextBox11.SelectedText = selectedText11 + key12;
                  keyValuePair = source6.ElementAt<KeyValuePair<string, string>>(index);
                  if (keyValuePair.Value != string.Empty)
                  {
                    this.m_RTFTextBox.SelectionFont = font4;
                    this.m_RTFTextBox.SelectedText += " = ";
                    RichTextBox rtfTextBox12 = this.m_RTFTextBox;
                    string selectedText12 = rtfTextBox12.SelectedText;
                    keyValuePair = source6.ElementAt<KeyValuePair<string, string>>(index);
                    string str = keyValuePair.Value;
                    rtfTextBox12.SelectedText = selectedText12 + str;
                  }
                  this.m_RTFTextBox.SelectedText += "\n";
                }
              }
            }
          }
          this.m_RTFTextBox.SelectedText += "\n\n\n";
          source1.Clear();
          source2.Clear();
          source3.Clear();
          source4.Clear();
          source5.Clear();
          source6.Clear();
        }
      }
      this.m_dataBuffer.TransactionContainer.Rollback();
      this.m_RTFTextBox.SaveFile(this.m_ExportFileTextBox.Text, RichTextBoxStreamType.RichText);
      Process.Start($"\"{this.m_ExportFileTextBox.Text}\"");
    }
    else
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantSymbolSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private static bool FindMatch(List<string> _List, string _strCurrentString)
  {
    foreach (string strA in _List)
    {
      if (string.Compare(strA, _strCurrentString, true) == 0)
        return true;
    }
    return false;
  }

  private void OnPickButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void AddExtensionToExportFile()
  {
    if (string.IsNullOrEmpty(this.m_ExportFileTextBox.Text) || !(new FileInfo(this.m_ExportFileTextBox.Text).Extension == string.Empty))
      return;
    this.m_ExportFileTextBox.Text += ".rtf";
  }

  private void OnExportFileTextBoxLeave(object sender, EventArgs e)
  {
    this.AddExtensionToExportFile();
  }

  public bool SelectionSetChecked => this.m_SelectionSetRadioButton.Checked;

  public bool WindowSelectChecked => this.m_WindowSelectRadioButton.Checked;

  public bool AllInstancesChecked => this.m_AllInstancesRadioButton.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ExportButton = new Button();
    this.m_CancelButton = new Button();
    this.m_DynGroupBox = new GroupBox();
    this.m_TypeListView = new ListView();
    this.m_AllInstancesRadioButton = new RadioButton();
    this.m_SelectionMethodsGroupBox = new GroupBox();
    this.m_PickButton = new Button();
    this.m_WindowSelectRadioButton = new RadioButton();
    this.m_SelectionSetRadioButton = new RadioButton();
    this.m_ExportOptionsGroupBox = new GroupBox();
    this.m_ExportFileTextBox = new TextBox();
    this.m_ExportFileButton = new Button();
    this.m_ExportFileLabel = new Label();
    this.m_RTFTextBox = new RichTextBox();
    this.m_DynGroupBox.SuspendLayout();
    this.m_SelectionMethodsGroupBox.SuspendLayout();
    this.m_ExportOptionsGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_ExportButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ExportButton.Location = new Point(230, 384);
    this.m_ExportButton.Name = "m_ExportButton";
    this.m_ExportButton.Size = new Size(77, 23);
    this.m_ExportButton.TabIndex = 3;
    this.m_ExportButton.Text = "&Export";
    this.m_ExportButton.UseVisualStyleBackColor = true;
    this.m_ExportButton.Click += new EventHandler(this.OnExportPlantBookletButtonClicked);
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.Location = new Point(313, 384);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.CancelButtonClicked);
    this.m_DynGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DynGroupBox.Controls.Add((Control) this.m_TypeListView);
    this.m_DynGroupBox.Location = new Point(12, 93);
    this.m_DynGroupBox.Name = "m_DynGroupBox";
    this.m_DynGroupBox.Size = new Size(376, 217);
    this.m_DynGroupBox.TabIndex = 1;
    this.m_DynGroupBox.TabStop = false;
    this.m_DynGroupBox.Text = "Plants";
    this.m_TypeListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_TypeListView.FullRowSelect = true;
    this.m_TypeListView.HideSelection = false;
    this.m_TypeListView.Location = new Point(7, 13);
    this.m_TypeListView.Name = "m_TypeListView";
    this.m_TypeListView.Size = new Size(358, 198);
    this.m_TypeListView.TabIndex = 0;
    this.m_TypeListView.UseCompatibleStateImageBehavior = false;
    this.m_TypeListView.ColumnClick += new ColumnClickEventHandler(this.OnMixListViewColumnClick);
    this.m_AllInstancesRadioButton.AutoSize = true;
    this.m_AllInstancesRadioButton.Location = new Point(6, 64 /*0x40*/);
    this.m_AllInstancesRadioButton.Name = "m_AllInstancesRadioButton";
    this.m_AllInstancesRadioButton.Size = new Size(85, 17);
    this.m_AllInstancesRadioButton.TabIndex = 2;
    this.m_AllInstancesRadioButton.TabStop = true;
    this.m_AllInstancesRadioButton.Text = "All &Instances";
    this.m_AllInstancesRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionMethodsGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_PickButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_AllInstancesRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_WindowSelectRadioButton);
    this.m_SelectionMethodsGroupBox.Controls.Add((Control) this.m_SelectionSetRadioButton);
    this.m_SelectionMethodsGroupBox.Location = new Point(12, 0);
    this.m_SelectionMethodsGroupBox.Name = "m_SelectionMethodsGroupBox";
    this.m_SelectionMethodsGroupBox.Size = new Size(376, 87);
    this.m_SelectionMethodsGroupBox.TabIndex = 0;
    this.m_SelectionMethodsGroupBox.TabStop = false;
    this.m_SelectionMethodsGroupBox.Text = "Selection Methods";
    this.m_PickButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_PickButton.Location = new Point(290, 35);
    this.m_PickButton.Name = "m_PickButton";
    this.m_PickButton.Size = new Size(75, 23);
    this.m_PickButton.TabIndex = 3;
    this.m_PickButton.Text = "&Pick";
    this.m_PickButton.UseVisualStyleBackColor = true;
    this.m_PickButton.Click += new EventHandler(this.OnPickButtonClicked);
    this.m_WindowSelectRadioButton.AutoSize = true;
    this.m_WindowSelectRadioButton.Location = new Point(6, 41);
    this.m_WindowSelectRadioButton.Name = "m_WindowSelectRadioButton";
    this.m_WindowSelectRadioButton.Size = new Size(97, 17);
    this.m_WindowSelectRadioButton.TabIndex = 1;
    this.m_WindowSelectRadioButton.TabStop = true;
    this.m_WindowSelectRadioButton.Text = "Window S&elect";
    this.m_WindowSelectRadioButton.UseVisualStyleBackColor = true;
    this.m_SelectionSetRadioButton.AutoSize = true;
    this.m_SelectionSetRadioButton.Location = new Point(6, 19);
    this.m_SelectionSetRadioButton.Name = "m_SelectionSetRadioButton";
    this.m_SelectionSetRadioButton.Size = new Size(88, 17);
    this.m_SelectionSetRadioButton.TabIndex = 0;
    this.m_SelectionSetRadioButton.TabStop = true;
    this.m_SelectionSetRadioButton.Text = "&Selection Set";
    this.m_SelectionSetRadioButton.UseVisualStyleBackColor = true;
    this.m_ExportOptionsGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileTextBox);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileLabel);
    this.m_ExportOptionsGroupBox.Location = new Point(12, 315);
    this.m_ExportOptionsGroupBox.Name = "m_ExportOptionsGroupBox";
    this.m_ExportOptionsGroupBox.Size = new Size(376, 57);
    this.m_ExportOptionsGroupBox.TabIndex = 2;
    this.m_ExportOptionsGroupBox.TabStop = false;
    this.m_ExportOptionsGroupBox.Text = "Export Options";
    this.m_ExportFileTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ExportFileTextBox.Location = new Point(57, 23);
    this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
    this.m_ExportFileTextBox.Size = new Size(282, 20);
    this.m_ExportFileTextBox.TabIndex = 1;
    this.m_ExportFileTextBox.KeyDown += new KeyEventHandler(this.OnExportFileTextBoxKeyDown);
    this.m_ExportFileTextBox.Leave += new EventHandler(this.OnExportFileTextBoxLeave);
    this.m_ExportFileButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ExportFileButton.Location = new Point(345, 23);
    this.m_ExportFileButton.Name = "m_ExportFileButton";
    this.m_ExportFileButton.Size = new Size(24, 20);
    this.m_ExportFileButton.TabIndex = 2;
    this.m_ExportFileButton.TabStop = false;
    this.m_ExportFileButton.Text = "...";
    this.m_ExportFileButton.UseVisualStyleBackColor = true;
    this.m_ExportFileButton.Click += new EventHandler(this.OnExportFileButtonClicked);
    this.m_ExportFileLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ExportFileLabel.AutoSize = true;
    this.m_ExportFileLabel.Location = new Point(5, 26);
    this.m_ExportFileLabel.Name = "m_ExportFileLabel";
    this.m_ExportFileLabel.Size = new Size(26, 13);
    this.m_ExportFileLabel.TabIndex = 0;
    this.m_ExportFileLabel.Text = "Fi&le:";
    this.m_RTFTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_RTFTextBox.BulletIndent = 5;
    this.m_RTFTextBox.Location = new Point(12, 37);
    this.m_RTFTextBox.Margin = new Padding(5);
    this.m_RTFTextBox.Name = "m_RTFTextBox";
    this.m_RTFTextBox.Size = new Size(317, 197);
    this.m_RTFTextBox.TabIndex = 0;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(400, 419);
    this.Controls.Add((Control) this.m_ExportOptionsGroupBox);
    this.Controls.Add((Control) this.m_SelectionMethodsGroupBox);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_ExportButton);
    this.Controls.Add((Control) this.m_DynGroupBox);
    this.MinimumSize = new Size(408, 446);
    this.Name = nameof (PlantBookletForm);
    this.Text = "Plant Booklet";
    this.FormClosing += new FormClosingEventHandler(this.OnPlantBookletFormFormClosing);
    this.m_DynGroupBox.ResumeLayout(false);
    this.m_SelectionMethodsGroupBox.ResumeLayout(false);
    this.m_SelectionMethodsGroupBox.PerformLayout();
    this.m_ExportOptionsGroupBox.ResumeLayout(false);
    this.m_ExportOptionsGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ExportButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
