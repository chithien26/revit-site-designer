﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Vector
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;

#nullable disable
namespace EPCommon;

public struct Vector
{
  private double m_x;
  private double m_y;
  private double m_z;

  public double X
  {
    get => this.m_x;
    set => this.m_x = value;
  }

  public double Y
  {
    get => this.m_y;
    set => this.m_y = value;
  }

  public double Z
  {
    get => this.m_z;
    set => this.m_z = value;
  }

  public double this[int index]
  {
    get
    {
      switch (index)
      {
        case 0:
          return this.m_x;
        case 1:
          return this.m_y;
        case 2:
          return this.m_z;
        default:
          throw new ArgumentOutOfRangeException();
      }
    }
    set
    {
      switch (index)
      {
        case 0:
          this.m_x = value;
          break;
        case 1:
          this.m_y = value;
          break;
        case 2:
          this.m_z = value;
          break;
        default:
          throw new ArgumentOutOfRangeException();
      }
    }
  }

  public Vector(Vector rhs)
  {
    this.m_x = rhs.X;
    this.m_y = rhs.Y;
    this.m_z = rhs.Z;
  }

  public Vector(double x, double y, double z)
  {
    this.m_x = x;
    this.m_y = y;
    this.m_z = z;
  }

  public Vector GetNormal()
  {
    Vector normal = new Vector();
    double length = this.GetLength();
    if (length < double.Epsilon)
      return new Vector();
    normal.X = this.m_x / length;
    normal.Y = this.m_y / length;
    normal.Z = this.m_z / length;
    return normal;
  }

  public static Vector operator +(Vector lhs, Vector rhs)
  {
    Vector vector = new Vector(lhs);
    vector.X += rhs.X;
    vector.Y += rhs.Y;
    vector.Z += rhs.Z;
    return vector;
  }

  public static Vector operator -(Vector lhs, Vector rhs)
  {
    Vector vector = new Vector(lhs);
    vector.X -= rhs.X;
    vector.Y -= rhs.Y;
    vector.Z -= rhs.Z;
    return vector;
  }

  public static Vector operator -(Vector lhs)
  {
    return new Vector(lhs)
    {
      X = -lhs.X,
      Y = -lhs.Y,
      Z = -lhs.Z
    };
  }

  public static Vector operator &(Vector lhs, Vector rhs)
  {
    double x1 = lhs.X;
    double y1 = lhs.Y;
    double z1 = lhs.Z;
    double x2 = rhs.X;
    double y2 = rhs.Y;
    double z2 = rhs.Z;
    return new Vector(y1 * z2 - z1 * y2, z1 * x2 - x1 * z2, x1 * y2 - y1 * x2);
  }

  public static double operator *(Vector lhs, Vector rhs)
  {
    return lhs.X * rhs.X + lhs.Y * rhs.Y + lhs.Z * rhs.Z;
  }

  public static Vector operator *(Vector lhs, double rhs)
  {
    return new Vector(lhs.X * rhs, lhs.Y * rhs, lhs.Z * rhs);
  }

  public static bool operator !=(Vector lhs, Vector rhs) => !Vector.IsEqual(lhs, rhs);

  public static bool operator ==(Vector lhs, Vector rhs) => Vector.IsEqual(lhs, rhs);

  public static double operator ~(Vector lhs) => lhs.GetLength();

  public static Vector operator /(Vector lhs, double rhs)
  {
    return new Vector(lhs.m_x / rhs, lhs.m_y / rhs, lhs.m_z / rhs);
  }

  public static double GetAngleOf2Vectors(Vector lhs, Vector rhs, bool acuteAngleDesired)
  {
    double angleOf2Vectors = Math.Acos(lhs.GetNormal() * rhs.GetNormal());
    if (acuteAngleDesired && angleOf2Vectors > Math.PI / 2.0)
      angleOf2Vectors = Math.PI - angleOf2Vectors;
    return angleOf2Vectors;
  }

  public override bool Equals(object obj)
  {
    try
    {
      return Vector.IsEqual(this, (Vector) obj);
    }
    catch
    {
    }
    return false;
  }

  public override int GetHashCode()
  {
    return this.m_x.GetHashCode() ^ this.m_y.GetHashCode() ^ this.m_z.GetHashCode();
  }

  public double GetLength()
  {
    return Math.Sqrt(this.m_x * this.m_x + this.m_y * this.m_y + this.m_z * this.m_z);
  }

  private static bool IsEqual(Vector lhs, Vector rhs)
  {
    return lhs.X == rhs.X && lhs.X == rhs.X && lhs.X == rhs.X;
  }

  public static Vector[] MultiCross3X3Matrix(Vector[] m1, Vector[] m2)
  {
    Vector[] vectorArray = new Vector[3];
    for (int index1 = 0; index1 < 3; ++index1)
    {
      for (int index2 = 0; index2 < 3; ++index2)
      {
        for (int index3 = 0; index3 < 3; ++index3)
        {
          switch (index2)
          {
            case 0:
              vectorArray[index1].X += m1[index1][index3] * m2[index3][index2];
              break;
            case 1:
              vectorArray[index1].Y += m1[index1][index3] * m2[index3][index2];
              break;
            case 2:
              vectorArray[index1].Z += m1[index1][index3] * m2[index3][index2];
              break;
          }
        }
      }
    }
    return vectorArray;
  }
}
