using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class PlantSearchForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private int m_nInitialSettingsCount;

	private string m_strSettingsPrefix;

	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Button m_CancelButton;

	private Button m_FindButton;

	private ComboBox m_ParameterComboBox;

	private ComboBox m_FilterComboBox;

	private Label m_ParameterLabel;

	private ListView m_SearchPlantListView;

	private Button m_ModifyButton;

	private Button m_AddButton;

	private TextBox m_FilterTextBox;

	private Label m_FilterLabel;

	private Button m_DeleteButton;

	public List<KeyValuePair<string, SearchPlantParameter>> SearchParameterResults
	{
		get
		{
			ProgressBarForm progressBarForm = new ProgressBarForm();
			progressBarForm.MinValue = 0;
			progressBarForm.MaxValue = m_SearchPlantListView.Items.Count;
			progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSearchingMessage");
			progressBarForm.ShowForm();
			progressBarForm.Refresh();
			List<KeyValuePair<string, SearchPlantParameter>> list = new List<KeyValuePair<string, SearchPlantParameter>>();
			SearchPlantParameter searchPlantParameter = null;
			for (int i = 0; i < m_SearchPlantListView.Items.Count; i++)
			{
				if (string.Compare(m_SearchPlantListView.Items[i].Text, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[i].Text, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[i].Text, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[i].Text, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[i].Text, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), ignoreCase: true) != 0)
				{
					searchPlantParameter = new SearchPlantParameter(ManagePlants.FindPlantComparisonType(m_SearchPlantListView.Items[i].SubItems[1].Text), m_SearchPlantListView.Items[i].SubItems[2].Text);
				}
				else
				{
					double _dReturnedDouble = 0.0;
					RevitGeometry.Units_ConvertStringToDouble(m_SearchPlantListView.Items[i].SubItems[2].Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false);
					searchPlantParameter = new SearchPlantParameter(ManagePlants.FindPlantComparisonType(m_SearchPlantListView.Items[i].SubItems[1].Text), ValueConversion.ToString(_dReturnedDouble));
				}
				list.Add(new KeyValuePair<string, SearchPlantParameter>(m_SearchPlantListView.Items[i].Text, searchPlantParameter));
				progressBarForm.UpdateProgressBar(1);
			}
			progressBarForm.SetMaxValue();
			Thread.Sleep(300);
			progressBarForm.Close();
			return list;
		}
	}

	public PlantSearchForm(string _strFormName, Document _Document)
	{
		InitializeComponent();
		m_nInitialSettingsCount = 0;
		Text = _strFormName;
		m_ParameterLabel.Text = EPShared.LocalRM.GetString("AMP_ParameterDialog");
		m_FilterLabel.Text = EPShared.LocalRM.GetString("Fi_AMP_lterDialog");
		m_AddButton.Text = EPShared.LocalRM.GetString("AMP_AddDialog");
		m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
		m_DeleteButton.Text = EPShared.LocalRM.GetString("AMP_DeleteDialog");
		m_FindButton.Text = EPShared.LocalRM.GetString("AMP_FindDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_strSettingsPrefix = _strFormName.Replace(" ", "");
		m_FormatOptions = _Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = _Document.DisplayUnitSystem;
		m_Units = _Document.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = _Document.GetUnits().DecimalSymbol;
		InitializeControls();
	}

	private void InitializeControls()
	{
		int num = 0;
		string _strToDisplay = string.Empty;
		GetDialogPosition();
		foreach (string item in ManagePlants.PlantAllParamenterList())
		{
			if (string.Compare(item, EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(item, EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(item, EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(item, EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), ignoreCase: true) != 0)
			{
				m_ParameterComboBox.Items.Add(item);
			}
		}
		if (m_ParameterComboBox.Items.Count > 0)
		{
			m_ParameterComboBox.SelectedIndex = 0;
		}
		foreach (string item2 in ManagePlants.ComparisonList())
		{
			m_FilterComboBox.Items.Add(item2);
		}
		if (m_FilterComboBox.Items.Count > 0)
		{
			m_FilterComboBox.SelectedIndex = 0;
		}
		m_SearchPlantListView.View = System.Windows.Forms.View.Details;
		m_SearchPlantListView.Columns.Add(EPShared.LocalRM.GetString("ParameterString"), 140, HorizontalAlignment.Left);
		m_SearchPlantListView.Columns.Add(EPShared.LocalRM.GetString("ComparisonTypeString"), 140, HorizontalAlignment.Left);
		m_SearchPlantListView.Columns.Add(EPShared.LocalRM.GetString("FilterString"), 140, HorizontalAlignment.Left);
		string _strReturnValue = string.Empty;
		string _strReturnValue2 = string.Empty;
		string _strReturnValue3 = string.Empty;
		while (true)
		{
			num++;
			if (!ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ParameterName" + Convert.ToString(num), ref _strReturnValue) || !ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "ComparisionType" + Convert.ToString(num), ref _strReturnValue2) || !ApplicationUtility.Settings.eplSetE_GetSetting(m_strSettingsPrefix + "Filter" + Convert.ToString(num), ref _strReturnValue3))
			{
				break;
			}
			ListViewItem listViewItem = new ListViewItem(_strReturnValue);
			listViewItem.SubItems.Add(_strReturnValue2);
			if (string.Compare(_strReturnValue, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(_strReturnValue, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(_strReturnValue, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(_strReturnValue, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(_strReturnValue, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), ignoreCase: true) != 0)
			{
				listViewItem.SubItems.Add(_strReturnValue3);
			}
			else
			{
				RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(_strReturnValue3), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				listViewItem.SubItems.Add(_strToDisplay);
			}
			m_SearchPlantListView.Items.Add(listViewItem);
		}
		m_nInitialSettingsCount = num - 1;
		if (m_SearchPlantListView.Items.Count > 0)
		{
			m_SearchPlantListView.Items[0].Selected = true;
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		for (num = 0; num < m_SearchPlantListView.Items.Count; num++)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ParameterName" + Convert.ToString(num + 1), m_SearchPlantListView.Items[num].Text);
			ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "ComparisionType" + Convert.ToString(num + 1), m_SearchPlantListView.Items[num].SubItems[1].Text);
			if (string.Compare(m_SearchPlantListView.Items[num].Text, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[num].Text, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[num].Text, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[num].Text, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), ignoreCase: true) != 0 && string.Compare(m_SearchPlantListView.Items[num].Text, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), ignoreCase: true) != 0)
			{
				ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "Filter" + Convert.ToString(num + 1), m_SearchPlantListView.Items[num].SubItems[2].Text);
				continue;
			}
			double _dReturnedDouble = 0.0;
			RevitGeometry.Units_ConvertStringToDouble(m_SearchPlantListView.Items[num].SubItems[2].Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false);
			ApplicationUtility.Settings.eplSetE_SetSetting(m_strSettingsPrefix + "Filter" + Convert.ToString(num + 1), ValueConversion.ToString(_dReturnedDouble));
		}
		for (; num < m_nInitialSettingsCount; num++)
		{
			ApplicationUtility.Settings.eplSetE_DeleteStringSetting(m_strSettingsPrefix + "ParameterName" + Convert.ToString(num + 1));
			ApplicationUtility.Settings.eplSetE_DeleteStringSetting("PlantSearchComparisionType" + Convert.ToString(num + 1));
			ApplicationUtility.Settings.eplSetE_DeleteStringSetting("PlantSearchFilter" + Convert.ToString(num + 1));
		}
	}

	private void OnFindButtonClick(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void OnAddButtonClick(object sender, EventArgs e)
	{
		ListViewItem listViewItem = new ListViewItem((string)m_ParameterComboBox.SelectedItem);
		listViewItem.SubItems.Add((string)m_FilterComboBox.SelectedItem);
		listViewItem.SubItems.Add(m_FilterTextBox.Text);
		m_SearchPlantListView.Items.Add(listViewItem);
	}

	private void OnDeleteButtonClick(object sender, EventArgs e)
	{
		for (int i = 0; i < m_SearchPlantListView.SelectedIndices.Count; i++)
		{
			m_SearchPlantListView.Items.RemoveAt(m_SearchPlantListView.SelectedIndices[i]);
		}
	}

	private void OnModifyButtonClick(object sender, EventArgs e)
	{
		if (m_SearchPlantListView.SelectedItems.Count > 0)
		{
			ListViewItem listViewItem = m_SearchPlantListView.SelectedItems[0];
			listViewItem.Text = (string)m_ParameterComboBox.SelectedItem;
			listViewItem.SubItems[1].Text = (string)m_FilterComboBox.SelectedItem;
			listViewItem.SubItems[2].Text = m_FilterTextBox.Text;
		}
		else
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ParameterNotSelectedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	private void SearchPlantListViewIndexChanged(object sender, EventArgs e)
	{
		if (m_SearchPlantListView.SelectedItems.Count > 0)
		{
			ListViewItem listViewItem = m_SearchPlantListView.SelectedItems[0];
			int num = m_ParameterComboBox.FindString(listViewItem.Text);
			if (num >= 0)
			{
				m_ParameterComboBox.SelectedIndex = num;
			}
			num = m_FilterComboBox.FindString(listViewItem.SubItems[1].Text);
			if (num >= 0)
			{
				m_FilterComboBox.SelectedIndex = num;
			}
			m_FilterTextBox.Text = listViewItem.SubItems[2].Text;
		}
	}

	private void OnPlantSearchFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void OnFilterTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatFilterValue();
		}
	}

	private void OnFilterTextBoxLeave(object sender, EventArgs e)
	{
		FormatFilterValue();
	}

	private void FormatFilterValue()
	{
		string strA = (string)m_ParameterComboBox.SelectedItem;
		if (string.Compare(strA, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), ignoreCase: true) == 0 || string.Compare(strA, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), ignoreCase: true) == 0 || string.Compare(strA, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), ignoreCase: true) == 0 || string.Compare(strA, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), ignoreCase: true) == 0 || string.Compare(strA, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), ignoreCase: true) == 0)
		{
			string _strToDisplay = string.Empty;
			double _dReturnedDouble = 0.0;
			if (RevitGeometry.Units_ConvertStringToDouble(m_FilterTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
			{
				RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_FilterTextBox.Text = _strToDisplay;
			}
			else
			{
				SiteDesigner.UI.WpfFocus.Focus(m_FilterTextBox);
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_FindButton = new System.Windows.Forms.Button();
		this.m_ParameterComboBox = new System.Windows.Forms.ComboBox();
		this.m_FilterComboBox = new System.Windows.Forms.ComboBox();
		this.m_ParameterLabel = new System.Windows.Forms.Label();
		this.m_SearchPlantListView = new System.Windows.Forms.ListView();
		this.m_ModifyButton = new System.Windows.Forms.Button();
		this.m_AddButton = new System.Windows.Forms.Button();
		this.m_FilterTextBox = new System.Windows.Forms.TextBox();
		this.m_FilterLabel = new System.Windows.Forms.Label();
		this.m_DeleteButton = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(459, 231);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(77, 23);
		this.m_CancelButton.TabIndex = 10;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_FindButton.Location = new System.Drawing.Point(376, 231);
		this.m_FindButton.Name = "m_FindButton";
		this.m_FindButton.Size = new System.Drawing.Size(79, 23);
		this.m_FindButton.TabIndex = 9;
		this.m_FindButton.Text = "&Find";
		this.m_FindButton.UseVisualStyleBackColor = true;
		this.m_FindButton.Click += new System.EventHandler(this.OnFindButtonClick);
		this.m_ParameterComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ParameterComboBox.FormattingEnabled = true;
		this.m_ParameterComboBox.Location = new System.Drawing.Point(95, 12);
		this.m_ParameterComboBox.Name = "m_ParameterComboBox";
		this.m_ParameterComboBox.Size = new System.Drawing.Size(242, 21);
		this.m_ParameterComboBox.Sorted = true;
		this.m_ParameterComboBox.TabIndex = 1;
		this.m_FilterComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_FilterComboBox.FormattingEnabled = true;
		this.m_FilterComboBox.Location = new System.Drawing.Point(346, 12);
		this.m_FilterComboBox.Name = "m_FilterComboBox";
		this.m_FilterComboBox.Size = new System.Drawing.Size(190, 21);
		this.m_FilterComboBox.TabIndex = 2;
		this.m_ParameterLabel.AutoSize = true;
		this.m_ParameterLabel.Location = new System.Drawing.Point(9, 15);
		this.m_ParameterLabel.Name = "m_ParameterLabel";
		this.m_ParameterLabel.Size = new System.Drawing.Size(58, 13);
		this.m_ParameterLabel.TabIndex = 0;
		this.m_ParameterLabel.Text = "&Parameter:";
		this.m_SearchPlantListView.FullRowSelect = true;
		this.m_SearchPlantListView.HideSelection = false;
		this.m_SearchPlantListView.Location = new System.Drawing.Point(12, 73);
		this.m_SearchPlantListView.Name = "m_SearchPlantListView";
		this.m_SearchPlantListView.Size = new System.Drawing.Size(443, 152);
		this.m_SearchPlantListView.TabIndex = 5;
		this.m_SearchPlantListView.UseCompatibleStateImageBehavior = false;
		this.m_SearchPlantListView.SelectedIndexChanged += new System.EventHandler(this.SearchPlantListViewIndexChanged);
		this.m_ModifyButton.Location = new System.Drawing.Point(461, 102);
		this.m_ModifyButton.Name = "m_ModifyButton";
		this.m_ModifyButton.Size = new System.Drawing.Size(75, 23);
		this.m_ModifyButton.TabIndex = 7;
		this.m_ModifyButton.Text = "&Modify";
		this.m_ModifyButton.UseVisualStyleBackColor = true;
		this.m_ModifyButton.Click += new System.EventHandler(this.OnModifyButtonClick);
		this.m_AddButton.Location = new System.Drawing.Point(461, 73);
		this.m_AddButton.Name = "m_AddButton";
		this.m_AddButton.Size = new System.Drawing.Size(75, 23);
		this.m_AddButton.TabIndex = 6;
		this.m_AddButton.Text = "&Add";
		this.m_AddButton.UseVisualStyleBackColor = true;
		this.m_AddButton.Click += new System.EventHandler(this.OnAddButtonClick);
		this.m_FilterTextBox.Location = new System.Drawing.Point(95, 40);
		this.m_FilterTextBox.Name = "m_FilterTextBox";
		this.m_FilterTextBox.Size = new System.Drawing.Size(242, 20);
		this.m_FilterTextBox.TabIndex = 4;
		this.m_FilterTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnFilterTextBoxKeyDown);
		this.m_FilterTextBox.Leave += new System.EventHandler(this.OnFilterTextBoxLeave);
		this.m_FilterLabel.AutoSize = true;
		this.m_FilterLabel.Location = new System.Drawing.Point(12, 43);
		this.m_FilterLabel.Name = "m_FilterLabel";
		this.m_FilterLabel.Size = new System.Drawing.Size(32, 13);
		this.m_FilterLabel.TabIndex = 3;
		this.m_FilterLabel.Text = "Fil&ter:";
		this.m_DeleteButton.Location = new System.Drawing.Point(461, 131);
		this.m_DeleteButton.Name = "m_DeleteButton";
		this.m_DeleteButton.Size = new System.Drawing.Size(75, 23);
		this.m_DeleteButton.TabIndex = 8;
		this.m_DeleteButton.Text = "&Delete";
		this.m_DeleteButton.UseVisualStyleBackColor = true;
		this.m_DeleteButton.Click += new System.EventHandler(this.OnDeleteButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(547, 266);
		base.Controls.Add(this.m_DeleteButton);
		base.Controls.Add(this.m_FilterLabel);
		base.Controls.Add(this.m_FilterTextBox);
		base.Controls.Add(this.m_AddButton);
		base.Controls.Add(this.m_ModifyButton);
		base.Controls.Add(this.m_SearchPlantListView);
		base.Controls.Add(this.m_ParameterLabel);
		base.Controls.Add(this.m_FilterComboBox);
		base.Controls.Add(this.m_ParameterComboBox);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_FindButton);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "PlantSearchForm";
		this.Text = "Plant Search";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantSearchFormClosing);
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_FindButton;
		base.CancelButton = this.m_CancelButton;
	}
}
