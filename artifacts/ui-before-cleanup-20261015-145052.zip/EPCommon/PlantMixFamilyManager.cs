using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;

namespace EPCommon;

public class PlantMixFamilyManager : EPForm
{
	private Units m_Units;

	private List<Document> m_OpenDocumentList;

	private string m_strSourceFile = string.Empty;

	private List<KeyValuePair<string, string>> m_RecenFilesList;

	private Document m_CurDocument;

	private List<FamilyParameterTypeWrapper> m_ParameterList;

	private List<FamilyTypeContainer> m_PlantListFamilyTypeList;

	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private DialogType m_DlgType;

	private int m_nMixtListViewSortColumn = -1;

	private EPTransactionContainer m_TransactionContainer;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private GroupBox m_DynGroupBox;

	private GroupBox m_DestinationGroupBox;

	private ListView m_MixListView;

	private TextBox m_DestinationTextBox;

	private Button m_DestinationFileChooserBtn;

	private Label m_DestinationFileLbl;

	private Button m_EqualButton;

	private Button m_DeleteButton;

	private Button m_AddButton;

	private Button m_SearchButton;

	private Button m_ModifyButton;

	private Button m_SaveFamilyButton;

	private Button m_CancelButton;

	private GroupBox m_SourceGroupBox;

	private TextBox m_SourceTxtBox;

	private Button m_RFAOpenFileButton;

	private Label m_SourceFileLbl;

	public PlantMixFamilyManager(DialogType _Type, Document _CurDocument)
	{
		InitializeComponent();
		EPToolTip.SetToolTip(m_RFAOpenFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		EPToolTip.SetToolTip(m_DestinationFileChooserBtn, EPShared.LocalRM.GetString("NewFamilyToolTip"));
		m_CurDocument = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_CurDocument);
		m_FormatOptions = m_CurDocument.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_CurDocument.DisplayUnitSystem;
		m_Units = m_CurDocument.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_CurDocument.GetUnits().DecimalSymbol;
		m_DlgType = _Type;
		SetStringValues();
		SetDefaultValues();
	}

	private void SetStringValues()
	{
		string text = string.Empty;
		switch (m_DlgType)
		{
		case DialogType.PlantMix:
			text = EPShared.LocalRM.GetString("PlantMixFamilyDialog") + " " + EPShared.LocalRM.GetString("CollectionDialog");
			Text = EPShared.LocalRM.GetString("PlantMixFamilyDialog") + " " + EPShared.LocalRM.GetString("ManagerDialog");
			m_ParameterList = ManagePlants.PlantMixParamenterList();
			m_SearchButton.Visible = true;
			m_EqualButton.Visible = true;
			break;
		case DialogType.Patio:
			text = EPShared.LocalRM.GetString("PathWalkFamilyDialog") + " " + EPShared.LocalRM.GetString("CollectionDialog");
			Text = EPShared.LocalRM.GetString("PathWalkFamilyDialog") + " " + EPShared.LocalRM.GetString("ManagerDialog");
			m_ParameterList = ManagePlants.PatioWalkParamenterList();
			m_SearchButton.Visible = false;
			m_EqualButton.Visible = false;
			break;
		}
		m_MixListView.View = System.Windows.Forms.View.Details;
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) != 0 && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) != 0 && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) != 0 && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) != 0)
			{
				m_MixListView.Columns.Add(m_ParameterList[i].ParameterDisplayName);
			}
		}
		m_DynGroupBox.Text = text;
		m_SourceFileLbl.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_DestinationFileLbl.Text = EPShared.LocalRM.GetString("Fi_AMP_leDialog");
		m_SourceGroupBox.Text = EPShared.LocalRM.GetString("SourceDialog");
		m_DestinationGroupBox.Text = EPShared.LocalRM.GetString("DestinationDialog");
		m_SearchButton.Text = EPShared.LocalRM.GetString("AMP_SearchDialog");
		m_AddButton.Text = EPShared.LocalRM.GetString("AMP_AddDialog");
		m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
		m_DeleteButton.Text = EPShared.LocalRM.GetString("AMP_DeleteDialog");
		m_EqualButton.Text = EPShared.LocalRM.GetString("AMP_EqualDialog");
		m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("Save_AMP_FamilyDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
	}

	private void SetDefaultValues()
	{
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		if (m_DlgType == DialogType.PlantMix)
		{
			if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixFamilyManagerSourcePath", ref _strReturnValue))
			{
				m_SourceTxtBox.Text = _strReturnValue;
			}
			if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantMixFamilyManagerDestinationPath", ref _strReturnValue))
			{
				m_DestinationTextBox.Text = _strReturnValue;
			}
		}
		else
		{
			if (ApplicationUtility.Settings.eplSetE_GetSetting("PatioWalkFamilyManagerSourcePath", ref _strReturnValue))
			{
				m_SourceTxtBox.Text = _strReturnValue;
			}
			if (ApplicationUtility.Settings.eplSetE_GetSetting("PatioWalkFamilyManagerDestinationPath", ref _strReturnValue))
			{
				m_DestinationTextBox.Text = _strReturnValue;
			}
		}
	}

	private void FindRecentFileList()
	{
		m_RecenFilesList = Settings.eplSetE_GetSectionValuesAsList("Recent File List", ApplicationUtility.RevitIniFilename);
	}

	private void ResetRecentFileList()
	{
		if (m_RecenFilesList == null || m_RecenFilesList.Count <= 0 || !Settings.eplSetE_DeleteSection("Recent File List", ApplicationUtility.RevitIniFilename))
		{
			return;
		}
		foreach (KeyValuePair<string, string> recenFiles in m_RecenFilesList)
		{
			Settings.eplSetE_SetSetting("Recent File List", recenFiles.Key, recenFiles.Value, ApplicationUtility.RevitIniFilename);
		}
	}

	private void CloseOpenDocuments()
	{
		if (m_OpenDocumentList != null && m_OpenDocumentList.Count > 0)
		{
			for (int num = m_OpenDocumentList.Count - 1; num >= 0; num--)
			{
				m_OpenDocumentList[num].Close(saveModified: false);
				m_OpenDocumentList.RemoveAt(num);
			}
		}
		ResetRecentFileList();
	}

	private void VerifyFileAndPopulateFamilyTypeSetList(FileInfo _CurrentFile)
	{
		Document CurDocument = null;
		List<FamilyTypeContainer> list = null;
		string text = _CurrentFile.Name.Substring(0, _CurrentFile.Name.Length - _CurrentFile.Extension.Length);
		int num = text.LastIndexOf('.');
		if (num >= 0 && text.Length - 1 == num + 4)
		{
			int result = -1;
			if (int.TryParse(text.Substring(num + 1), out result))
			{
				return;
			}
		}
		bool flag = ManagePlants.IsDocumentOpen(m_CurDocument.Application, _CurrentFile.FullName, ref CurDocument);
		if (!flag)
		{
			CurDocument = m_CurDocument.Application.OpenDocumentFile(_CurrentFile.FullName);
		}
		EPTransactionContainer ePTransactionContainer = new EPTransactionContainer(CurDocument);
		ePTransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
		ePTransactionContainer.BeginTransaction();
		list = PopulateFamilyTypeSetList(CurDocument.FamilyManager);
		if (list == null || list.Count <= 0)
		{
			if (m_DlgType == DialogType.PlantMix)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NotValidLANDCADDPlantMixFamilyMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_SourceTxtBox.Text = string.Empty;
				SiteDesigner.UI.WpfFocus.Focus(m_SourceTxtBox);
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NotValidLANDCADDPatioWalkFamilyMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_SourceTxtBox.Text = string.Empty;
				SiteDesigner.UI.WpfFocus.Focus(m_SourceTxtBox);
			}
		}
		ePTransactionContainer.EndTransaction();
		ePTransactionContainer.Rollback();
		if (list != null)
		{
			if (m_OpenDocumentList == null)
			{
				m_OpenDocumentList = new List<Document>();
			}
			if (!flag)
			{
				m_OpenDocumentList.Add(CurDocument);
			}
			foreach (FamilyTypeContainer item in list)
			{
				m_PlantListFamilyTypeList.Add(item);
			}
		}
		else if (!flag)
		{
			CurDocument.Close(saveModified: false);
		}
		CleanMix();
	}

	private List<FamilyTypeContainer> PopulateFamilyTypeSetList(FamilyManager _FamilyManager)
	{
		List<FamilyTypeContainer> list = null;
		string empty = string.Empty;
		string empty2 = string.Empty;
		bool flag = false;
		LandcaddID landcaddID = LandcaddID.PatioWalk;
		if (m_DlgType == DialogType.PlantMix)
		{
			landcaddID = LandcaddID.PlantMix;
		}
		ProgressBarForm progressBarForm = new ProgressBarForm();
		progressBarForm.MinValue = 0;
		progressBarForm.MaxValue = _FamilyManager.Types.Size;
		progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarLoadingFamilyMessage");
		progressBarForm.ShowForm();
		progressBarForm.Refresh();
		foreach (FamilyType type in _FamilyManager.Types)
		{
			FamilyParameter familyParameter = _FamilyManager.get_Parameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
			if (familyParameter == null || !type.HasValue(familyParameter) || string.Compare(type.AsString(familyParameter), Convert.ToInt32(landcaddID).ToString("000"), ignoreCase: true) != 0)
			{
				continue;
			}
			empty2 = type.Name.Trim();
			if (empty2 != string.Empty)
			{
				foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
				{
					if (string.Compare(empty2, plantListFamilyType.FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					ListViewItem listViewItem = new ListViewItem();
					for (int i = 0; i < m_ParameterList.Count; i++)
					{
						if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
						{
							continue;
						}
						if (m_DlgType == DialogType.PlantMix)
						{
							empty = string.Empty;
							FindParamenterValue(_FamilyManager, type, m_ParameterList[i].ParameterName, ref empty);
							if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
							{
								double dConvertedDouble = 1.0;
								if (empty != string.Empty)
								{
									dConvertedDouble = ValueConversion.ToDouble(empty);
								}
								RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
							}
							else if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
							{
								if (empty == null || empty == string.Empty)
								{
									empty = "1.0";
								}
							}
							else if (empty == string.Empty && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.TypeNamePlantFamilyType, ignoreCase: true) == 0)
							{
								empty = empty2;
							}
							if (i == 0)
							{
								listViewItem = m_MixListView.Items.Add(empty2, empty, string.Empty);
								listViewItem.Tag = empty2;
							}
							else
							{
								listViewItem.SubItems.Add(empty);
							}
							continue;
						}
						empty = string.Empty;
						FindParamenterValue(_FamilyManager, type, m_ParameterList[i].ParameterName, ref empty);
						if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
						{
							double dConvertedDouble2 = 0.0;
							if (empty != string.Empty)
							{
								dConvertedDouble2 = ValueConversion.ToDouble(empty);
							}
							RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble2, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
						}
						else if (string.Compare(m_ParameterList[i].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(m_ParameterList[i].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
						{
							if (string.Compare(empty, "1", ignoreCase: true) != 0)
							{
								empty = ((string.Compare(empty, "0", ignoreCase: true) != 0) ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString"));
							}
							else
							{
								empty = EPShared.LocalRM.GetString("YesString");
							}
						}
						else if (empty == string.Empty && string.Compare(m_ParameterList[i].ParameterName, RevitParameters.TypeNamePlantFamilyType, ignoreCase: true) == 0)
						{
							empty = empty2;
						}
						if (i == 0)
						{
							listViewItem = m_MixListView.Items.Add(empty2, empty, string.Empty);
							listViewItem.Tag = empty2;
						}
						else
						{
							listViewItem.SubItems.Add(empty);
						}
					}
					if (list == null)
					{
						list = new List<FamilyTypeContainer>();
					}
					if (m_DlgType == DialogType.PlantMix)
					{
						list.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetPlantMixFamilyParameterSetForType(type, _FamilyManager)));
					}
					else
					{
						list.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetPatioWalkFamilyParameterSetForType(type, _FamilyManager)));
					}
				}
				else
				{
					flag = false;
				}
			}
			progressBarForm.UpdateProgressBar(1);
		}
		progressBarForm.SetMaxValue();
		Thread.Sleep(300);
		progressBarForm.Close();
		return list;
	}

	private bool FindParamenterValue(FamilyManager FamilyManager, FamilyType type, string _strParamter, ref string _strValue)
	{
		bool result = false;
		FamilyParameter familyParameter = FamilyManager.get_Parameter(_strParamter);
		if (familyParameter != null && type.HasValue(familyParameter))
		{
			switch (familyParameter.StorageType)
			{
			case StorageType.Double:
				if (type.AsDouble(familyParameter) is double)
				{
					result = true;
					_strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
				}
				break;
			case StorageType.Integer:
				if (type.AsInteger(familyParameter) is int)
				{
					result = true;
					_strValue = Convert.ToString(type.AsInteger(familyParameter));
				}
				break;
			case StorageType.String:
				if (type.AsString(familyParameter) != null)
				{
					result = true;
					_strValue = type.AsString(familyParameter);
				}
				break;
			}
		}
		return result;
	}

	private void OnSingleFileTextBoxLeaveFocus(object sender, EventArgs e)
	{
		LoadData();
	}

	private void OnSourceTxtBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			LoadData();
		}
	}

	private void LoadData()
	{
		if (!string.IsNullOrEmpty(m_SourceTxtBox.Text))
		{
			FileInfo fileInfo = new FileInfo(m_SourceTxtBox.Text);
			if (fileInfo.Extension == string.Empty)
			{
				m_SourceTxtBox.Text += ".rfa";
			}
		}
		if (RevitUtility.CompareFileNames(m_strSourceFile, m_SourceTxtBox.Text) == 0)
		{
			return;
		}
		CloseOpenDocuments();
		FindRecentFileList();
		m_strSourceFile = m_SourceTxtBox.Text;
		m_MixListView.Items.Clear();
		m_nMixtListViewSortColumn = -1;
		m_MixListView.Sorting = SortOrder.None;
		m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
		if (m_OpenDocumentList != null)
		{
			m_OpenDocumentList.Clear();
		}
		if (string.IsNullOrEmpty(m_strSourceFile))
		{
			return;
		}
		FileInfo fileInfo2 = new FileInfo(m_strSourceFile);
		if (File.Exists(m_strSourceFile))
		{
			if (string.Compare(fileInfo2.Extension, ".rfa", ignoreCase: true) != 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("Source") + " " + EPShared.LocalRM.GetString("NoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
			else
			{
				VerifyFileAndPopulateFamilyTypeSetList(fileInfo2);
			}
		}
	}

	private bool ValidateFields()
	{
		string text = m_DestinationTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("Source") + " " + EPShared.LocalRM.GetString("NoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_DestinationTextBox);
			return false;
		}
		string empty = string.Empty;
		empty = ".rfa";
		if (text.IndexOf(empty) < 0)
		{
			if (text.IndexOf("\\") <= 0 && text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length = -1;
			if (text.IndexOf("\\") > 0)
			{
				length = text.LastIndexOf("\\");
			}
			else if (text.IndexOf("/") > 0)
			{
				length = text.LastIndexOf("/");
			}
			if (!Directory.Exists(text.Substring(0, length)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			text += empty;
		}
		else
		{
			if (text.IndexOf("\\") <= 0 && text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length2 = -1;
			if (text.IndexOf("\\") > 0)
			{
				length2 = text.LastIndexOf("\\");
			}
			else if (text.IndexOf("/") > 0)
			{
				length2 = text.LastIndexOf("/");
			}
			if (!Directory.Exists(text.Substring(0, length2)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
		}
		m_DestinationTextBox.Text = text;
		if (File.Exists(text))
		{
			if (RevitUtility.CompareFileNames(m_CurDocument.PathName, text) != 0)
			{
				switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation))
				{
				case DialogResult.Yes:
				{
					Document CurDocument = null;
					if (ManagePlants.IsDocumentOpen(m_CurDocument.Application, text, ref CurDocument))
					{
						bool flag = false;
						if (m_OpenDocumentList != null && m_OpenDocumentList.Count > 0)
						{
							for (int num = m_OpenDocumentList.Count - 1; num >= 0; num--)
							{
								if (RevitUtility.CompareFileNames(m_OpenDocumentList[num].PathName, CurDocument.PathName) == 0)
								{
									m_OpenDocumentList[num].Close(saveModified: false);
									m_OpenDocumentList.RemoveAt(num);
									flag = true;
									break;
								}
							}
						}
						if (!flag)
						{
							CurDocument.Close(saveModified: false);
						}
					}
					File.Delete(text);
					break;
				}
				case DialogResult.Cancel:
					return false;
				}
			}
			else
			{
				DialogResult dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationFamilyOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
				if (dialogResult == DialogResult.No)
				{
					return false;
				}
			}
		}
		return true;
	}

	private bool FindSelectedPlantList(ref List<FamilyTypeContainer> _SelectedPlantList)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		if ((num = m_MixListView.SelectedItems.Count) >= 1)
		{
			for (num2 = 0; num2 < num; num2++)
			{
				for (num3 = 0; num3 < m_PlantListFamilyTypeList.Count; num3++)
				{
					if (m_PlantListFamilyTypeList[num3].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string)m_MixListView.SelectedItems[num2].Tag, m_PlantListFamilyTypeList[num3].FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
					{
						_SelectedPlantList.Add(m_PlantListFamilyTypeList[num3]);
						break;
					}
				}
			}
			return true;
		}
		string empty = string.Empty;
		empty = ((m_DlgType != DialogType.PlantMix) ? EPShared.LocalRM.GetString("NoPatioWalkSelected") : EPShared.LocalRM.GetString("NoPlantsSelected"));
		RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		return false;
	}

	private void SaveFamilyButtonClicked(object sender, EventArgs e)
	{
		if (!ValidateFields())
		{
			return;
		}
		FileInfo fileInfo = new FileInfo(RevitUtility.GetFormattedFileName(m_DestinationTextBox.Text, _bCreateDirectory: true));
		List<FamilyTypeContainer> _SelectedPlantList = new List<FamilyTypeContainer>();
		if (m_DlgType == DialogType.PlantMix)
		{
			if (CheckPercentage())
			{
				if (FindSelectedPlantList(ref _SelectedPlantList))
				{
					if (ManagePlants.CreateNewMixFamilyDocument(m_CurDocument, _SelectedPlantList, m_DlgType, fileInfo.FullName))
					{
						CloseOpenDocuments();
						m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantMixFamilyTransaction") + fileInfo.Name);
						RevitUtility.LoadFamily(m_CurDocument, fileInfo.FullName, _bUseFailureHandling: true, ref m_TransactionContainer);
						m_TransactionContainer.Commit();
					}
					SaveSettings();
				}
			}
			else if (m_PlantListFamilyTypeList == null || m_PlantListFamilyTypeList.Count <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("PercentageError"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		else if (FindSelectedPlantList(ref _SelectedPlantList))
		{
			if (ManagePlants.CreateNewMixFamilyDocument(m_CurDocument, _SelectedPlantList, m_DlgType, fileInfo.FullName))
			{
				CloseOpenDocuments();
				m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPatioWalkFamilyTransaction") + fileInfo.Name);
				RevitUtility.LoadFamily(m_CurDocument, fileInfo.FullName, _bUseFailureHandling: true, ref m_TransactionContainer);
				m_TransactionContainer.Commit();
			}
			SaveSettings();
		}
	}

	private void CancelButtonClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	private void OnSearchButtonClicked(object sender, EventArgs e)
	{
		PlantMixSearchForm plantMixSearchForm = new PlantMixSearchForm(m_CurDocument);
		plantMixSearchForm.ShowDialog();
		if (plantMixSearchForm.DialogResult == DialogResult.OK)
		{
			List<string> list = new List<string>();
			if (m_PlantListFamilyTypeList == null)
			{
				m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
			}
			for (int i = 0; i < m_PlantListFamilyTypeList.Count; i++)
			{
				list.Add(m_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName);
			}
			CheckForDuplicates(plantMixSearchForm.SelectedPlantListFamilyTypeList, list);
		}
	}

	private void CheckForDuplicates(List<FamilyTypeContainer> _PlantListFamilyTypeList, List<string> _TypeNames)
	{
		bool flag = false;
		bool flag2 = false;
		string empty = string.Empty;
		for (int i = 0; i < _PlantListFamilyTypeList.Count; i++)
		{
			if (!(_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName != string.Empty))
			{
				continue;
			}
			if (flag)
			{
				_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName = ManagePlants.GetUniqueTypeName(_TypeNames, _PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName);
				m_PlantListFamilyTypeList.Add(_PlantListFamilyTypeList[i]);
				UpdateList(m_MixListView.Items.Count, m_PlantListFamilyTypeList.Count, _bModify: false);
			}
			else if (ManagePlants.IsTypeNameDuplicate(_TypeNames, _PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName))
			{
				if (!flag2)
				{
					flag2 = true;
					DialogResult dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateTypeAppendMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
					if (dialogResult == DialogResult.Yes)
					{
						flag = true;
						_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName = ManagePlants.GetUniqueTypeName(_TypeNames, _PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName);
						m_PlantListFamilyTypeList.Add(_PlantListFamilyTypeList[i]);
						UpdateList(m_MixListView.Items.Count, m_PlantListFamilyTypeList.Count, _bModify: false);
					}
				}
			}
			else
			{
				m_PlantListFamilyTypeList.Add(_PlantListFamilyTypeList[i]);
				UpdateList(m_MixListView.Items.Count, m_PlantListFamilyTypeList.Count, _bModify: false);
			}
		}
	}

	private void OnPlantMixFamilyManagerFormClosing(object sender, FormClosingEventArgs e)
	{
		CloseOpenDocuments();
		SetDialogPosition();
	}

	private void SaveSettings()
	{
		if (m_DlgType == DialogType.PlantMix)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixFamilyManagerSourcePath", m_SourceTxtBox.Text);
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantMixFamilyManagerDestinationPath", m_DestinationTextBox.Text);
		}
		else
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PatioWalkFamilyManagerSourcePath", m_SourceTxtBox.Text);
			ApplicationUtility.Settings.eplSetE_SetSetting("PatioWalkFamilyManagerDestinationPath", m_DestinationTextBox.Text);
		}
	}

	private void OnAddButtonClicked(object sender, EventArgs e)
	{
		FamilyTypeContainer familyTypeContainer = new FamilyTypeContainer();
		int nSelectedIndex = -1;
		if (m_PlantListFamilyTypeList == null)
		{
			m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
		}
		using AddModifyMix addModifyMix = new AddModifyMix(m_ParameterList, ref m_PlantListFamilyTypeList, m_CurDocument.GetUnits(), m_DisplayUnitSystem, m_FormatOptions, m_UnitSymbolType, m_DecimalSymbolType, nSelectedIndex, m_DlgType);
		addModifyMix.ShowDialog();
		if (addModifyMix.DialogResult == DialogResult.OK)
		{
			UpdateList(m_MixListView.Items.Count, m_PlantListFamilyTypeList.Count, _bModify: false);
		}
	}

	private void OnModifyButtonClicked(object sender, EventArgs e)
	{
		if (m_MixListView.Items.Count > 0)
		{
			Modify();
		}
	}

	private void Modify()
	{
		int num = -1;
		int num2 = -1;
		if (m_MixListView.SelectedItems.Count >= 1)
		{
			for (num2 = 0; num2 < m_PlantListFamilyTypeList.Count; num2++)
			{
				if (m_PlantListFamilyTypeList[num2].Status != FamilyParameterWrapperStatus.Excluded)
				{
					num = m_MixListView.SelectedItems.IndexOfKey(m_PlantListFamilyTypeList[num2].FamilyTypeWrapper.FamilyTypeName);
					if (num >= 0)
					{
						break;
					}
				}
			}
			using AddModifyMix addModifyMix = new AddModifyMix(m_ParameterList, ref m_PlantListFamilyTypeList, m_CurDocument.GetUnits(), m_DisplayUnitSystem, m_FormatOptions, m_UnitSymbolType, m_DecimalSymbolType, num2, m_DlgType);
			addModifyMix.ShowDialog();
			if (addModifyMix.DialogResult == DialogResult.OK)
			{
				UpdateList(m_MixListView.SelectedIndices[num], num2, _bModify: true);
			}
			return;
		}
		string empty = string.Empty;
		empty = ((m_DlgType != DialogType.PlantMix) ? EPShared.LocalRM.GetString("NoPatioWalkSelected") : EPShared.LocalRM.GetString("NoPlantsSelected"));
		RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
	}

	private void OnDeleteButtonClicked(object sender, EventArgs e)
	{
		int num = -1;
		int num2 = -1;
		if (m_MixListView.SelectedItems.Count >= 1)
		{
			for (num2 = m_PlantListFamilyTypeList.Count - 1; num2 >= 0; num2--)
			{
				num = m_MixListView.SelectedItems.IndexOfKey(m_PlantListFamilyTypeList[num2].FamilyTypeWrapper.FamilyTypeName);
				if (num >= 0)
				{
					m_PlantListFamilyTypeList.RemoveAt(num2);
					m_MixListView.SelectedItems[num].Remove();
					if (m_MixListView.SelectedItems.Count == 0)
					{
						break;
					}
				}
			}
		}
		else
		{
			string empty = string.Empty;
			empty = ((m_DlgType != DialogType.PlantMix) ? EPShared.LocalRM.GetString("NoPatioWalkSelected") : EPShared.LocalRM.GetString("NoPlantsSelected"));
			RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		}
	}

	private void CleanMix()
	{
		List<FamilyParameterTypeWrapper> list = new List<FamilyParameterTypeWrapper>();
		list = ((m_DlgType != DialogType.PlantMix) ? ManagePlants.PatioWalkParamenterList() : ManagePlants.PlantMixParamenterList());
		List<FamilyParameterWrapper> list2 = null;
		FamilyParameterWrapper familyParameterWrapper = null;
		bool flag = false;
		for (int i = 0; i < m_PlantListFamilyTypeList.Count; i++)
		{
			list2 = new List<FamilyParameterWrapper>();
			for (int j = 0; j < list.Count; j++)
			{
				for (int k = 0; k < m_PlantListFamilyTypeList[i].FamilyParameterList.Count; k++)
				{
					if (string.Compare(list[j].ParameterName, m_PlantListFamilyTypeList[i].FamilyParameterList[k].ParameterName, ignoreCase: true) == 0)
					{
						list2.Add(m_PlantListFamilyTypeList[i].FamilyParameterList[k]);
						flag = true;
						break;
					}
				}
				if (flag)
				{
					continue;
				}
				if (m_DlgType == DialogType.PlantMix)
				{
					if (string.Compare(list[j].ParameterName, RevitParameters.TypeNamePlantFamilyType, ignoreCase: true) == 0)
					{
						familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, m_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName, StorageType.String);
						list2.Add(familyParameterWrapper);
					}
					else if (string.Compare(list[j].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[j].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[j].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[j].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
					{
						familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, "", StorageType.String);
						list2.Add(familyParameterWrapper);
					}
					else if (string.Compare(list[j].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, RevitParameters.PlantMixSpacingMethodTriangular, StorageType.String);
						list2.Add(familyParameterWrapper);
					}
					else if (string.Compare(list[j].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[j].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
					{
						familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, "0.0", StorageType.Double);
						list2.Add(familyParameterWrapper);
					}
				}
				else if (string.Compare(list[j].ParameterName, RevitParameters.TypeNamePlantFamilyType, ignoreCase: true) == 0)
				{
					familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, m_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName, StorageType.String);
					list2.Add(familyParameterWrapper);
				}
				else if (string.Compare(list[j].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0)
				{
					familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, "", StorageType.String);
					list2.Add(familyParameterWrapper);
				}
				else if (string.Compare(list[j].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
				{
					familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, "", StorageType.String);
					list2.Add(familyParameterWrapper);
				}
				else if (string.Compare(list[j].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[j].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
				{
					familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, RevitParameters.NoString, StorageType.Integer);
					list2.Add(familyParameterWrapper);
				}
				else if (string.Compare(list[j].ParameterName, RevitParameters.MaterialPathWalkFamilyParameter, ignoreCase: true) == 0)
				{
					familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, ApplicationUtility.GetString(" "), StorageType.String);
					list2.Add(familyParameterWrapper);
				}
				else if (string.Compare(list[j].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[j].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
				{
					familyParameterWrapper = new FamilyParameterWrapper(list[j].ParameterDisplayName, list[j].ParameterName, "0.0", StorageType.Double);
					list2.Add(familyParameterWrapper);
				}
			}
			flag = false;
			string empty = string.Empty;
			StorageType storageType = StorageType.String;
			for (int l = 0; l < list.Count; l++)
			{
				for (int m = 0; m < list2.Count; m++)
				{
					if (string.Compare(list[l].ParameterName, list2[m].ParameterName, ignoreCase: true) == 0)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					if (string.Compare(list[l].ParameterName, RevitParameters.PlantSpacingPlantFamilyParameter, ignoreCase: true) == 0)
					{
						storageType = StorageType.Double;
						empty = "0.0";
					}
					else
					{
						storageType = StorageType.String;
						empty = "";
					}
					familyParameterWrapper = new FamilyParameterWrapper(list[l].ParameterDisplayName, list[l].ParameterName, empty, storageType);
					list2.Insert(l, familyParameterWrapper);
				}
				flag = false;
			}
			m_PlantListFamilyTypeList[i].FamilyParameterList = list2;
		}
	}

	private void UpdateList(int _nSelectedListIndex, int _nFamilyTypeListIndex, bool _bModify)
	{
		if (_bModify)
		{
			m_MixListView.Items.RemoveAt(_nSelectedListIndex);
		}
		else
		{
			_nFamilyTypeListIndex--;
		}
		List<FamilyParameterTypeWrapper> list = new List<FamilyParameterTypeWrapper>();
		list = ManagePlants.PlantMixParamenterList();
		List<FamilyParameterWrapper> list2 = new List<FamilyParameterWrapper>();
		if (!_bModify)
		{
			if (m_DlgType == DialogType.PlantMix)
			{
				FamilyParameterWrapper familyParameterWrapper = null;
				bool flag = false;
				for (int i = 0; i < list.Count; i++)
				{
					for (int j = 0; j < m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList.Count; j++)
					{
						if (string.Compare(list[i].ParameterName, m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList[j].ParameterName, ignoreCase: true) == 0)
						{
							list2.Add(m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList[j]);
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						if (string.Compare(list[i].ParameterName, RevitParameters.TypeNamePlantFamilyType, ignoreCase: true) == 0)
						{
							familyParameterWrapper = new FamilyParameterWrapper(list[i].ParameterDisplayName, list[i].ParameterName, m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, StorageType.String);
							list2.Add(familyParameterWrapper);
							continue;
						}
						if (string.Compare(list[i].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[i].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[i].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[i].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
						{
							familyParameterWrapper = new FamilyParameterWrapper(list[i].ParameterDisplayName, list[i].ParameterName, "", StorageType.String);
							list2.Add(familyParameterWrapper);
							continue;
						}
						if (string.Compare(list[i].ParameterName, RevitParameters.SpacingMethodPlantMixFamilyParameter, ignoreCase: true) == 0)
						{
							familyParameterWrapper = new FamilyParameterWrapper(list[i].ParameterDisplayName, list[i].ParameterName, RevitParameters.PlantMixSpacingMethodTriangular, StorageType.String);
							list2.Add(familyParameterWrapper);
							continue;
						}
						if (string.Compare(list[i].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0 || string.Compare(list[i].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
						{
							familyParameterWrapper = new FamilyParameterWrapper(list[i].ParameterDisplayName, list[i].ParameterName, "0.0", StorageType.Double);
							list2.Add(familyParameterWrapper);
							continue;
						}
					}
					flag = false;
				}
				flag = false;
				string empty = string.Empty;
				StorageType storageType = StorageType.String;
				for (int k = 0; k < list.Count; k++)
				{
					for (int l = 0; l < list2.Count; l++)
					{
						if (string.Compare(list[k].ParameterName, list2[l].ParameterName, ignoreCase: true) == 0)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						storageType = StorageType.String;
						empty = "";
						familyParameterWrapper = new FamilyParameterWrapper(list[k].ParameterDisplayName, list[k].ParameterName, empty, storageType);
						list2.Insert(k, familyParameterWrapper);
					}
					flag = false;
				}
			}
			else
			{
				list2 = m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList;
			}
		}
		else
		{
			list2 = m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList;
		}
		string empty2 = string.Empty;
		ListViewItem listViewItem = new ListViewItem();
		listViewItem.Tag = m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
		for (int m = 0; m < list2.Count; m++)
		{
			empty2 = list2[m].Value;
			if (string.Compare(list2[m].ParameterName, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list2[m].ParameterName, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list2[m].ParameterName, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(list2[m].ParameterName, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
			{
				continue;
			}
			if (m_DlgType == DialogType.PlantMix)
			{
				if (empty2 == null)
				{
					empty2 = string.Empty;
				}
				if (string.Compare(list2[m].ParameterName, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					double dConvertedDouble = 1.0;
					if (empty2 != string.Empty)
					{
						dConvertedDouble = ValueConversion.ToDouble(empty2);
					}
					RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty2);
				}
				else if (string.Compare(list2[m].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					double num = 1.0;
					if (empty2 != string.Empty)
					{
						num = ValueConversion.ToDouble(empty2);
					}
					empty2 = Convert.ToString(num);
				}
			}
			else if (string.Compare(list2[m].ParameterName, RevitParameters.ThicknessPathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(list2[m].ParameterName, RevitParameters.EdgeWidthPathWalkFamilyParameter, ignoreCase: true) == 0)
			{
				double dConvertedDouble2 = 1.0;
				if (empty2 != string.Empty)
				{
					dConvertedDouble2 = ValueConversion.ToDouble(empty2);
				}
				RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble2, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty2);
			}
			else if (string.Compare(list2[m].ParameterName, RevitParameters.EdgePathWalkFamilyParameter, ignoreCase: true) == 0 || string.Compare(list2[m].ParameterName, RevitParameters.MowingStripPathWalkFamilyParameter, ignoreCase: true) == 0)
			{
				if (string.Compare(empty2, "1", ignoreCase: true) != 0)
				{
					empty2 = ((string.Compare(empty2, "0", ignoreCase: true) != 0) ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("NoString"));
				}
				else
				{
					empty2 = EPShared.LocalRM.GetString("YesString");
				}
			}
			else if (empty2 == string.Empty && string.Compare(list2[m].ParameterName, RevitParameters.MaterialPathWalkFamilyParameter, ignoreCase: true) == 0)
			{
				empty2 = m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
			}
			if (m == 0)
			{
				listViewItem = ((!_bModify) ? m_MixListView.Items.Add(m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, empty2, string.Empty) : m_MixListView.Items.Insert(_nSelectedListIndex, m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName, empty2, string.Empty));
				listViewItem.Tag = m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyTypeWrapper.FamilyTypeName;
			}
			else
			{
				listViewItem.SubItems.Add(empty2);
			}
		}
		m_PlantListFamilyTypeList[_nFamilyTypeListIndex].FamilyParameterList = list2;
	}

	private void DestinationFileChooserBtnClicked(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_DestinationTextBox.Text = saveFileDialog.FileName;
		}
	}

	private void OnEqualButtonClick(object sender, EventArgs e)
	{
		string empty = string.Empty;
		string empty2 = string.Empty;
		double num = 0.0;
		for (int i = 0; i < m_PlantListFamilyTypeList.Count; i++)
		{
			int count = m_PlantListFamilyTypeList[i].FamilyParameterList.Count;
			for (int j = 0; j < count; j++)
			{
				if (string.Compare(m_PlantListFamilyTypeList[i].FamilyParameterList[j].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					num = 100.0 / (double)m_PlantListFamilyTypeList.Count;
					m_PlantListFamilyTypeList[i].FamilyParameterList[j].Value = ValueConversion.Format("{0:F2}", num);
					break;
				}
			}
		}
		RefreshListView();
	}

	private void RefreshListView()
	{
		string empty = string.Empty;
		string empty2 = string.Empty;
		m_MixListView.Items.Clear();
		string empty3 = string.Empty;
		string empty4 = string.Empty;
		for (int i = 0; i < m_PlantListFamilyTypeList.Count; i++)
		{
			int count = m_PlantListFamilyTypeList[i].FamilyParameterList.Count;
			ListViewItem listViewItem = new ListViewItem();
			for (int j = 0; j < count; j++)
			{
				empty3 = m_PlantListFamilyTypeList[i].FamilyParameterList[j].ParameterName;
				empty4 = m_PlantListFamilyTypeList[i].FamilyParameterList[j].Value;
				if (string.Compare(empty3, RevitParameters.RegionNameGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(empty3, RevitParameters.UniqueIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(empty3, RevitParameters.LandcaddIDGenericModelFamilyParameter, ignoreCase: true) == 0 || string.Compare(empty3, RevitParameters.AssemblyCodeGenericFamilyParameter, ignoreCase: true) == 0)
				{
					continue;
				}
				if (string.Compare(empty3, RevitParameters.PlantSpacingPlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					double dConvertedDouble = 1.0;
					if (empty4 != string.Empty)
					{
						dConvertedDouble = ValueConversion.ToDouble(empty4);
					}
					RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty4);
				}
				if (j == 0)
				{
					listViewItem = m_MixListView.Items.Add(m_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName, empty4, string.Empty);
					listViewItem.Tag = m_PlantListFamilyTypeList[i].FamilyTypeWrapper.FamilyTypeName;
				}
				else
				{
					listViewItem.SubItems.Add(empty4);
				}
			}
		}
	}

	private bool CheckPercentage()
	{
		if (m_PlantListFamilyTypeList == null || m_PlantListFamilyTypeList.Count <= 0)
		{
			return false;
		}
		string empty = string.Empty;
		string empty2 = string.Empty;
		double num = 0.0;
		for (int i = 0; i < m_PlantListFamilyTypeList.Count; i++)
		{
			int count = m_PlantListFamilyTypeList[i].FamilyParameterList.Count;
			for (int j = 0; j < count; j++)
			{
				if (string.Compare(m_PlantListFamilyTypeList[i].FamilyParameterList[j].ParameterName, RevitParameters.PercentagePlantMixFamilyParameter, ignoreCase: true) == 0)
				{
					if (m_PlantListFamilyTypeList[i].FamilyParameterList[j].Value != null && m_PlantListFamilyTypeList[i].FamilyParameterList[j].Value != string.Empty)
					{
						num += ValueConversion.ToDouble(m_PlantListFamilyTypeList[i].FamilyParameterList[j].Value);
					}
					break;
				}
			}
		}
		if (Math.Round(num) > 100.0)
		{
			return false;
		}
		return true;
	}

	private void MixListViewDoubleClicked(object sender, EventArgs e)
	{
		Modify();
	}

	private void OnMixListViewColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column != m_nMixtListViewSortColumn)
		{
			m_nMixtListViewSortColumn = e.Column;
			m_MixListView.Sorting = SortOrder.Ascending;
		}
		else if (m_MixListView.Sorting == SortOrder.Ascending)
		{
			m_MixListView.Sorting = SortOrder.Descending;
		}
		else
		{
			m_MixListView.Sorting = SortOrder.Ascending;
		}
		m_MixListView.Sort();
		m_MixListView.ListViewItemSorter = new ListViewItemComparer(e.Column, m_MixListView.Sorting);
	}

	private void OnDestinationTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			AddExtensionToDestination();
		}
	}

	private void RFAOpenFileButtonClicked(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		openFileDialog.FilterIndex = 1;
		openFileDialog.RestoreDirectory = true;
		if (openFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_SourceTxtBox.Text = openFileDialog.FileName;
			LoadData();
		}
	}

	private void AddExtensionToDestination()
	{
		if (!string.IsNullOrEmpty(m_DestinationTextBox.Text))
		{
			FileInfo fileInfo = new FileInfo(m_DestinationTextBox.Text);
			if (fileInfo.Extension == string.Empty)
			{
				m_DestinationTextBox.Text += ".rfa";
			}
		}
	}

	private void OnDestinationTextBoxLeaveFocus(object sender, EventArgs e)
	{
		AddExtensionToDestination();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_DynGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ModifyButton = new System.Windows.Forms.Button();
		this.m_EqualButton = new System.Windows.Forms.Button();
		this.m_DeleteButton = new System.Windows.Forms.Button();
		this.m_AddButton = new System.Windows.Forms.Button();
		this.m_SearchButton = new System.Windows.Forms.Button();
		this.m_MixListView = new System.Windows.Forms.ListView();
		this.m_DestinationGroupBox = new System.Windows.Forms.GroupBox();
		this.m_DestinationTextBox = new System.Windows.Forms.TextBox();
		this.m_DestinationFileChooserBtn = new System.Windows.Forms.Button();
		this.m_DestinationFileLbl = new System.Windows.Forms.Label();
		this.m_SaveFamilyButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_SourceGroupBox = new System.Windows.Forms.GroupBox();
		this.m_SourceTxtBox = new System.Windows.Forms.TextBox();
		this.m_RFAOpenFileButton = new System.Windows.Forms.Button();
		this.m_SourceFileLbl = new System.Windows.Forms.Label();
		this.m_DynGroupBox.SuspendLayout();
		this.m_DestinationGroupBox.SuspendLayout();
		this.m_SourceGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_DynGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DynGroupBox.Controls.Add(this.m_ModifyButton);
		this.m_DynGroupBox.Controls.Add(this.m_EqualButton);
		this.m_DynGroupBox.Controls.Add(this.m_DeleteButton);
		this.m_DynGroupBox.Controls.Add(this.m_AddButton);
		this.m_DynGroupBox.Controls.Add(this.m_SearchButton);
		this.m_DynGroupBox.Controls.Add(this.m_MixListView);
		this.m_DynGroupBox.Location = new System.Drawing.Point(12, 2);
		this.m_DynGroupBox.Name = "m_DynGroupBox";
		this.m_DynGroupBox.Size = new System.Drawing.Size(573, 255);
		this.m_DynGroupBox.TabIndex = 0;
		this.m_DynGroupBox.TabStop = false;
		this.m_DynGroupBox.Text = "PlantMix";
		this.m_ModifyButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ModifyButton.Location = new System.Drawing.Point(491, 41);
		this.m_ModifyButton.Name = "m_ModifyButton";
		this.m_ModifyButton.Size = new System.Drawing.Size(75, 23);
		this.m_ModifyButton.TabIndex = 2;
		this.m_ModifyButton.Text = "Modify";
		this.m_ModifyButton.UseVisualStyleBackColor = true;
		this.m_ModifyButton.Click += new System.EventHandler(this.OnModifyButtonClicked);
		this.m_EqualButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_EqualButton.Location = new System.Drawing.Point(491, 100);
		this.m_EqualButton.Name = "m_EqualButton";
		this.m_EqualButton.Size = new System.Drawing.Size(75, 23);
		this.m_EqualButton.TabIndex = 4;
		this.m_EqualButton.Text = "Equal";
		this.m_EqualButton.UseVisualStyleBackColor = true;
		this.m_EqualButton.Click += new System.EventHandler(this.OnEqualButtonClick);
		this.m_DeleteButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_DeleteButton.Location = new System.Drawing.Point(491, 70);
		this.m_DeleteButton.Name = "m_DeleteButton";
		this.m_DeleteButton.Size = new System.Drawing.Size(75, 24);
		this.m_DeleteButton.TabIndex = 3;
		this.m_DeleteButton.Text = "Delete";
		this.m_DeleteButton.UseVisualStyleBackColor = true;
		this.m_DeleteButton.Click += new System.EventHandler(this.OnDeleteButtonClicked);
		this.m_AddButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_AddButton.Location = new System.Drawing.Point(491, 12);
		this.m_AddButton.Name = "m_AddButton";
		this.m_AddButton.Size = new System.Drawing.Size(75, 23);
		this.m_AddButton.TabIndex = 1;
		this.m_AddButton.Text = "Add";
		this.m_AddButton.UseVisualStyleBackColor = true;
		this.m_AddButton.Click += new System.EventHandler(this.OnAddButtonClicked);
		this.m_SearchButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_SearchButton.Location = new System.Drawing.Point(491, 129);
		this.m_SearchButton.Name = "m_SearchButton";
		this.m_SearchButton.Size = new System.Drawing.Size(75, 23);
		this.m_SearchButton.TabIndex = 5;
		this.m_SearchButton.Text = "Search";
		this.m_SearchButton.UseVisualStyleBackColor = true;
		this.m_SearchButton.Click += new System.EventHandler(this.OnSearchButtonClicked);
		this.m_MixListView.Anchor = System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_MixListView.FullRowSelect = true;
		this.m_MixListView.HideSelection = false;
		this.m_MixListView.Location = new System.Drawing.Point(7, 13);
		this.m_MixListView.Name = "m_MixListView";
		this.m_MixListView.Size = new System.Drawing.Size(479, 235);
		this.m_MixListView.TabIndex = 0;
		this.m_MixListView.UseCompatibleStateImageBehavior = false;
		this.m_MixListView.DoubleClick += new System.EventHandler(this.MixListViewDoubleClicked);
		this.m_MixListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.OnMixListViewColumnClick);
		this.m_DestinationGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationGroupBox.Controls.Add(this.m_DestinationTextBox);
		this.m_DestinationGroupBox.Controls.Add(this.m_DestinationFileChooserBtn);
		this.m_DestinationGroupBox.Controls.Add(this.m_DestinationFileLbl);
		this.m_DestinationGroupBox.Location = new System.Drawing.Point(12, 309);
		this.m_DestinationGroupBox.Name = "m_DestinationGroupBox";
		this.m_DestinationGroupBox.Size = new System.Drawing.Size(573, 49);
		this.m_DestinationGroupBox.TabIndex = 2;
		this.m_DestinationGroupBox.TabStop = false;
		this.m_DestinationGroupBox.Text = "Destination";
		this.m_DestinationTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationTextBox.Location = new System.Drawing.Point(68, 17);
		this.m_DestinationTextBox.Name = "m_DestinationTextBox";
		this.m_DestinationTextBox.Size = new System.Drawing.Size(468, 20);
		this.m_DestinationTextBox.TabIndex = 1;
		this.m_DestinationTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnDestinationTextBoxKeyDown);
		this.m_DestinationTextBox.Leave += new System.EventHandler(this.OnDestinationTextBoxLeaveFocus);
		this.m_DestinationFileChooserBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationFileChooserBtn.Location = new System.Drawing.Point(542, 16);
		this.m_DestinationFileChooserBtn.Name = "m_DestinationFileChooserBtn";
		this.m_DestinationFileChooserBtn.Size = new System.Drawing.Size(24, 20);
		this.m_DestinationFileChooserBtn.TabIndex = 2;
		this.m_DestinationFileChooserBtn.Text = "...";
		this.m_DestinationFileChooserBtn.UseVisualStyleBackColor = true;
		this.m_DestinationFileChooserBtn.Click += new System.EventHandler(this.DestinationFileChooserBtnClicked);
		this.m_DestinationFileLbl.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationFileLbl.AutoSize = true;
		this.m_DestinationFileLbl.Location = new System.Drawing.Point(4, 20);
		this.m_DestinationFileLbl.Name = "m_DestinationFileLbl";
		this.m_DestinationFileLbl.Size = new System.Drawing.Size(23, 13);
		this.m_DestinationFileLbl.TabIndex = 0;
		this.m_DestinationFileLbl.Text = "File";
		this.m_SaveFamilyButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_SaveFamilyButton.Location = new System.Drawing.Point(412, 364);
		this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
		this.m_SaveFamilyButton.Size = new System.Drawing.Size(92, 23);
		this.m_SaveFamilyButton.TabIndex = 3;
		this.m_SaveFamilyButton.Text = "Save Family";
		this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
		this.m_SaveFamilyButton.Click += new System.EventHandler(this.SaveFamilyButtonClicked);
		this.m_CancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CancelButton.Location = new System.Drawing.Point(510, 364);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.CancelButtonClicked);
		this.m_SourceGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SourceGroupBox.Controls.Add(this.m_SourceTxtBox);
		this.m_SourceGroupBox.Controls.Add(this.m_RFAOpenFileButton);
		this.m_SourceGroupBox.Controls.Add(this.m_SourceFileLbl);
		this.m_SourceGroupBox.Location = new System.Drawing.Point(12, 259);
		this.m_SourceGroupBox.Name = "m_SourceGroupBox";
		this.m_SourceGroupBox.Size = new System.Drawing.Size(573, 46);
		this.m_SourceGroupBox.TabIndex = 1;
		this.m_SourceGroupBox.TabStop = false;
		this.m_SourceGroupBox.Text = "Source";
		this.m_SourceTxtBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SourceTxtBox.Location = new System.Drawing.Point(68, 17);
		this.m_SourceTxtBox.Name = "m_SourceTxtBox";
		this.m_SourceTxtBox.Size = new System.Drawing.Size(468, 20);
		this.m_SourceTxtBox.TabIndex = 1;
		this.m_SourceTxtBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnSourceTxtBoxKeyDown);
		this.m_SourceTxtBox.Leave += new System.EventHandler(this.OnSingleFileTextBoxLeaveFocus);
		this.m_RFAOpenFileButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_RFAOpenFileButton.Location = new System.Drawing.Point(542, 16);
		this.m_RFAOpenFileButton.Name = "m_RFAOpenFileButton";
		this.m_RFAOpenFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_RFAOpenFileButton.TabIndex = 2;
		this.m_RFAOpenFileButton.Text = "...";
		this.m_RFAOpenFileButton.UseVisualStyleBackColor = true;
		this.m_RFAOpenFileButton.Click += new System.EventHandler(this.RFAOpenFileButtonClicked);
		this.m_SourceFileLbl.AutoSize = true;
		this.m_SourceFileLbl.Location = new System.Drawing.Point(6, 20);
		this.m_SourceFileLbl.Name = "m_SourceFileLbl";
		this.m_SourceFileLbl.Size = new System.Drawing.Size(23, 13);
		this.m_SourceFileLbl.TabIndex = 0;
		this.m_SourceFileLbl.Text = "File";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(590, 399);
		base.Controls.Add(this.m_SourceGroupBox);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_SaveFamilyButton);
		base.Controls.Add(this.m_DestinationGroupBox);
		base.Controls.Add(this.m_DynGroupBox);
		this.MinimumSize = new System.Drawing.Size(598, 426);
		base.Name = "PlantMixFamilyManager";
		this.Text = "PlantMixFamilyManager";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantMixFamilyManagerFormClosing);
		this.m_DynGroupBox.ResumeLayout(false);
		this.m_DestinationGroupBox.ResumeLayout(false);
		this.m_DestinationGroupBox.PerformLayout();
		this.m_SourceGroupBox.ResumeLayout(false);
		this.m_SourceGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.AcceptButton = this.m_SaveFamilyButton;
		base.CancelButton = this.m_CancelButton;
	}
}
