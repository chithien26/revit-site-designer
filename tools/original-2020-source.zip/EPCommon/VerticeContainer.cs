﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.VerticeContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class VerticeContainer
{
  private uint m_nVerticeNumber;
  private Eps_Point m_VerticePoint;

  public VerticeContainer(uint _nVerticeNumber, Eps_Point _VerticePoint)
  {
    this.m_nVerticeNumber = _nVerticeNumber;
    this.m_VerticePoint = _VerticePoint;
  }

  public uint VerticeNumber => this.m_nVerticeNumber;

  public Eps_Point VerticePoint => this.m_VerticePoint;
}
