﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.IntersectionStationContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class IntersectionStationContainer
{
  private string m_strPrimaryPlacementId;
  private string m_strSecondaryPlacementId;
  private List<IntersectionStation> m_IntersectionStations;

  public IntersectionStationContainer()
  {
    this.m_strPrimaryPlacementId = string.Empty;
    this.m_strSecondaryPlacementId = string.Empty;
    this.m_IntersectionStations = new List<IntersectionStation>();
  }

  public IntersectionStationContainer(double _dStation)
  {
    this.m_strPrimaryPlacementId = string.Empty;
    this.m_strSecondaryPlacementId = string.Empty;
    this.m_IntersectionStations = new List<IntersectionStation>();
    this.m_IntersectionStations.Add(new IntersectionStation(_dStation));
  }

  public List<IntersectionStation> IntersectionStations
  {
    get => this.m_IntersectionStations;
    set => this.m_IntersectionStations = value;
  }

  public string PrimaryPlacementId
  {
    get => this.m_strPrimaryPlacementId;
    set => this.m_strPrimaryPlacementId = value;
  }

  public string SecondaryPlacementId
  {
    get => this.m_strSecondaryPlacementId;
    set => this.m_strSecondaryPlacementId = value;
  }
}
