﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilySymbolComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class FamilySymbolComparer : IComparer<FamilySymbol>
{
  int IComparer<FamilySymbol>.Compare(FamilySymbol first, FamilySymbol second)
  {
    int num = 0;
    if (first != null && ((Element) first).Name != null)
      num = second == null || ((Element) second).Name == null ? -1 : string.Compare(((Element) first).Name, ((Element) second).Name);
    else if (second != null && ((Element) second).Name != null)
      num = 1;
    return num;
  }
}
