﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RegistryPaths
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class RegistryPaths
{
  private const string m_strSupportPath = "\\Data\\Support\\";
  private string m_strProgramPath;
  private const string m_strHelpPath = "\\Data\\Help\\";
  private const string m_strLibraryPath = "\\Data\\Library\\";
  private const string m_strSamplePath = "\\Data\\Samples\\";

  public string SupportPath => "\\Data\\Support\\";

  public string ProgramPath
  {
    get => this.m_strProgramPath;
    set => this.m_strProgramPath = value;
  }

  public int GetSupportPath(string _strFileName, ref string _strSupportPath)
  {
    _strSupportPath = this.m_strProgramPath + "\\Data\\Support\\";
    if (!_strSupportPath.EndsWith("\\") && !_strSupportPath.EndsWith("/"))
      _strSupportPath += "\\";
    _strSupportPath += _strFileName;
    return 0;
  }

  public int GetProgramPath(string _strFileName, ref string _strProgramPath)
  {
    _strProgramPath = this.m_strProgramPath;
    if (!_strProgramPath.EndsWith("\\") && !_strProgramPath.EndsWith("/"))
      _strProgramPath += "\\";
    _strProgramPath += _strFileName;
    return 0;
  }

  public int GetHelpPath(string _strFileName, ref string _strHelpPath)
  {
    _strHelpPath = this.m_strProgramPath + "\\Data\\Help\\";
    if (!_strHelpPath.EndsWith("\\") && !_strHelpPath.EndsWith("/"))
      _strHelpPath += "\\";
    _strHelpPath += _strFileName;
    return 0;
  }

  public int GetLibraryPath(string _strFileName, ref string _strLibraryPath)
  {
    int libraryPath;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LibraryPath", ref _strLibraryPath) && _strLibraryPath != string.Empty)
    {
      if (!_strLibraryPath.EndsWith("\\") && !_strLibraryPath.EndsWith("/"))
        _strLibraryPath += "\\";
      _strLibraryPath += _strFileName;
      libraryPath = 0;
    }
    else
    {
      _strLibraryPath = this.m_strProgramPath + "\\Data\\Library\\";
      if (!_strLibraryPath.EndsWith("\\") && !_strLibraryPath.EndsWith("/"))
        _strLibraryPath += "\\";
      _strLibraryPath += _strFileName;
      libraryPath = 0;
    }
    return libraryPath;
  }

  public int GetSamplePath(string _strFileName, ref string _strSamplePath)
  {
    int samplePath;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("SamplePath", ref _strSamplePath) && _strSamplePath != string.Empty)
    {
      if (!_strSamplePath.EndsWith("\\") && !_strSamplePath.EndsWith("/"))
        _strSamplePath += "\\";
      _strSamplePath += _strFileName;
      samplePath = 0;
    }
    else
    {
      _strSamplePath = this.m_strProgramPath + "\\Data\\Samples\\";
      if (!_strSamplePath.EndsWith("\\") && !_strSamplePath.EndsWith("/"))
        _strSamplePath += "\\";
      _strSamplePath += _strFileName;
      samplePath = 0;
    }
    return samplePath;
  }
}
