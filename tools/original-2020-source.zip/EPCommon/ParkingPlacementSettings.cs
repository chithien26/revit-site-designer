﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParkingPlacementSettings
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class ParkingPlacementSettings
{
  private FamilySymbol m_ADAStallSymbol;
  private FamilySymbol m_IslandSymbol;
  private FamilySymbol m_BumperSymbol;
  private double m_dStallAdjustWidth;
  private double m_dADAStallWidth;
  private double m_dADAStallAdjustWidth;
  private double m_dBumperHeight;
  private double m_dBumperWidth;
  private double m_dBumperOffset;
  private double m_dBumperSetback;
  private double m_dIslandHeight;
  private double m_dIslandWidth;
  private double m_dStallLength;
  private double m_dStripeLength;
  private double m_dAdjustAisleWidth;
  private double m_dADAStallAisleAdjustWidth;
  private double m_dADAStallAdjustWidthNoAisleWidth;
  private double m_dAreaDistanceBetweenCenterlines;
  private double m_dAreaAisleWidth;
  private bool m_bPlaceIsland;
  private bool m_bPlaceBumper;
  private bool m_bSidesOnIsland;
  private bool m_bCenterIsland;
  private bool m_bOptimizeParking;
  private bool m_bAreaBiDirectionalAisles;
  private bool m_bGetAisleWidthAdjustment;
  private bool m_bPromptForDirection;
  private bool m_bMiddleStallPlacement;
  private bool m_bADAStallSharedAccessibleAisle;
  private int m_nCurrentStallCount;
  private int m_nStallCount;
  private int m_nCurrentADAStallCount;
  private int m_nADAStallCount;
  private int m_nAreaRowCount;
  private int m_nAreaRowSpacingOptions;

  public ParkingPlacementSettings()
  {
    this.m_ADAStallSymbol = (FamilySymbol) null;
    this.m_IslandSymbol = (FamilySymbol) null;
    this.m_BumperSymbol = (FamilySymbol) null;
    this.m_dADAStallWidth = 0.0;
    this.m_dBumperHeight = 0.0;
    this.m_dBumperWidth = 0.0;
    this.m_dBumperOffset = 0.0;
    this.m_dBumperSetback = 0.0;
    this.m_dIslandHeight = 0.0;
    this.m_dIslandWidth = 0.0;
    this.m_dStallLength = 0.0;
    this.m_dAreaDistanceBetweenCenterlines = 0.0;
    this.m_dAreaAisleWidth = 0.0;
    this.m_bPlaceIsland = false;
    this.m_bPlaceBumper = false;
    this.m_bOptimizeParking = false;
    this.m_bAreaBiDirectionalAisles = false;
    this.m_bPromptForDirection = false;
    this.m_bADAStallSharedAccessibleAisle = false;
    this.m_nStallCount = 0;
    this.m_nADAStallCount = 0;
    this.m_nAreaRowCount = 0;
    this.m_nAreaRowSpacingOptions = 0;
    this.m_bMiddleStallPlacement = false;
    this.m_bSidesOnIsland = false;
    this.m_bCenterIsland = false;
    this.m_bGetAisleWidthAdjustment = false;
    this.m_dStripeLength = 0.0;
    this.m_dADAStallAdjustWidth = 0.0;
    this.m_dADAStallAisleAdjustWidth = 0.0;
    this.m_dStallAdjustWidth = 0.0;
    this.m_nCurrentStallCount = 0;
    this.m_nCurrentADAStallCount = 0;
    this.m_dAdjustAisleWidth = 0.0;
    this.m_dADAStallAdjustWidthNoAisleWidth = 0.0;
  }

  public FamilySymbol ADAStallSymbol
  {
    get => this.m_ADAStallSymbol;
    set => this.m_ADAStallSymbol = value;
  }

  public FamilySymbol IslandSymbol
  {
    get => this.m_IslandSymbol;
    set => this.m_IslandSymbol = value;
  }

  public FamilySymbol BumperSymbol
  {
    get => this.m_BumperSymbol;
    set => this.m_BumperSymbol = value;
  }

  public double ADAStallWidth
  {
    get => this.m_dADAStallWidth;
    set => this.m_dADAStallWidth = value;
  }

  public double BumperHeight
  {
    get => this.m_dBumperHeight;
    set => this.m_dBumperHeight = value;
  }

  public double BumperWidth
  {
    get => this.m_dBumperWidth;
    set => this.m_dBumperWidth = value;
  }

  public double BumperOffset
  {
    get => this.m_dBumperOffset;
    set => this.m_dBumperOffset = value;
  }

  public double BumperSetback
  {
    get => this.m_dBumperSetback;
    set => this.m_dBumperSetback = value;
  }

  public double IslandHeight
  {
    get => this.m_dIslandHeight;
    set => this.m_dIslandHeight = value;
  }

  public double IslandWidth
  {
    get => this.m_dIslandWidth;
    set => this.m_dIslandWidth = value;
  }

  public double StallLength
  {
    get => this.m_dStallLength;
    set => this.m_dStallLength = value;
  }

  public double AreaDistanceBetweenCenterlines
  {
    get => this.m_dAreaDistanceBetweenCenterlines;
    set => this.m_dAreaDistanceBetweenCenterlines = value;
  }

  public double AreaAisleWidth
  {
    get => this.m_dAreaAisleWidth;
    set => this.m_dAreaAisleWidth = value;
  }

  public bool PlaceIsland
  {
    get => this.m_bPlaceIsland;
    set => this.m_bPlaceIsland = value;
  }

  public bool PlaceBumper
  {
    get => this.m_bPlaceBumper;
    set => this.m_bPlaceBumper = value;
  }

  public bool OptimizeParking
  {
    get => this.m_bOptimizeParking;
    set => this.m_bOptimizeParking = value;
  }

  public bool AreaBiDirectionalAisles
  {
    get => this.m_bAreaBiDirectionalAisles;
    set => this.m_bAreaBiDirectionalAisles = value;
  }

  public bool PromptForDirection
  {
    get => this.m_bPromptForDirection;
    set => this.m_bPromptForDirection = value;
  }

  public bool ADAStallSharedAccessibleAisle
  {
    get => this.m_bADAStallSharedAccessibleAisle;
    set => this.m_bADAStallSharedAccessibleAisle = value;
  }

  public int StallCount
  {
    get => this.m_nStallCount;
    set
    {
      if (value >= 0)
        this.m_nStallCount = value;
      else
        this.m_nStallCount = 0;
    }
  }

  public int ADAStallCount
  {
    get => this.m_nADAStallCount;
    set
    {
      if (value >= 0)
        this.m_nADAStallCount = value;
      else
        this.m_nADAStallCount = 0;
    }
  }

  public int AreaRowCount
  {
    get => this.m_nAreaRowCount;
    set => this.m_nAreaRowCount = value;
  }

  public int AreaRowSpacingOptions
  {
    get => this.m_nAreaRowSpacingOptions;
    set => this.m_nAreaRowSpacingOptions = value;
  }

  public bool MiddleStallPlacement
  {
    get => this.m_bMiddleStallPlacement;
    set => this.m_bMiddleStallPlacement = value;
  }

  public bool SidesOnIsland
  {
    get => this.m_bSidesOnIsland;
    set => this.m_bSidesOnIsland = value;
  }

  public bool CenterIsland
  {
    get => this.m_bCenterIsland;
    set => this.m_bCenterIsland = value;
  }

  public bool GetAisleWidthAdjustment
  {
    get => this.m_bGetAisleWidthAdjustment;
    set => this.m_bGetAisleWidthAdjustment = value;
  }

  public double StallAdjustWidth
  {
    get => this.m_dStallAdjustWidth;
    set => this.m_dStallAdjustWidth = value;
  }

  public double ADAStallAdjustWidth
  {
    get => this.m_dADAStallAdjustWidth;
    set => this.m_dADAStallAdjustWidth = value;
  }

  public double StripeLength
  {
    get => this.m_dStripeLength;
    set => this.m_dStripeLength = value;
  }

  public int CurrentStallCount
  {
    get => this.m_nCurrentStallCount;
    set => this.m_nCurrentStallCount = value;
  }

  public int CurrentADAStallCount
  {
    get => this.m_nCurrentADAStallCount;
    set => this.m_nCurrentADAStallCount = value;
  }

  public double AdjustAisleWidth
  {
    get => this.m_dAdjustAisleWidth;
    set => this.m_dAdjustAisleWidth = value;
  }

  public double ADAStallAisleAdjustWidth
  {
    get => this.m_dADAStallAisleAdjustWidth;
    set => this.m_dADAStallAisleAdjustWidth = value;
  }

  public double ADAStallAdjustWidthNoAisleWidth
  {
    get => this.m_dADAStallAdjustWidthNoAisleWidth;
    set => this.m_dADAStallAdjustWidthNoAisleWidth = value;
  }
}
