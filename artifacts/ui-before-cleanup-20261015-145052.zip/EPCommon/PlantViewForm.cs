using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;

namespace EPCommon;

public class PlantViewForm : EPForm
{
	private Units m_Units;

	private Document m_CurDocument;

	private List<FamilyTypeContainer> m_PlantListFamilyTypeList;

	private string m_strSourceDirectory = string.Empty;

	private string m_strSourceFile = string.Empty;

	private string m_strSymbolFile = string.Empty;

	private List<Document> m_OpenDocumentList;

	private List<KeyValuePair<string, string>> m_RecenFilesList;

	private List<ParameterColumn> m_ParameterList;

	private int m_nPlantListViewSortColumn = -1;

	private FormatOptions m_FormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_UnitSymbolType;

	private EPTransactionContainer m_TransactionContainer;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Button m_CancelButton;

	private Button m_SaveFamilyButton;

	private Button m_DWGSymbolBaseButton;

	private GroupBox m_SourceGroupBox;

	private GroupBox m_SingleFileGroupBox;

	private RadioButton m_TabSingleFileRadioButton;

	private RadioButton m_CommaSingleFileRadioButton;

	private RadioButton m_RFASingleFileRadioButton;

	private GroupBox m_DestinationGroupBox;

	private TextBox m_DestinationFileTextBox;

	private Button m_DestinationFileButton;

	private Label m_DestinationFileLabel;

	private RadioButton m_SingleFileRadioButton;

	private TextBox m_SingleFileTextBox;

	private Button m_SingleFileButton;

	private Label m_SingleFileLabel;

	private RadioButton m_DirectoryRadioButton;

	private TextBox m_DirectoryTextBox;

	private Button m_DirectoryButton;

	private Label m_DirectoryLabel;

	private GroupBox m_FamilySymbolGroupBox;

	private Label m_SymbolNameLabel;

	private ComboBox m_SymbolNameComboBox;

	private TextBox m_FamilySymbolFileTextBox;

	private Button m_FamilySymbolFileButton;

	private Label m_FamilySymbolFileLabel;

	private CheckBox m_CreateSymbolFromDWGCheckBox;

	private Button m_ExportButton;

	private GroupBox m_PlantCollectionGroupBox;

	private Button m_ShowAllFamiliesButton;

	private Button m_DeleteFamiliesButton;

	private Button m_ColumnDisplayButton;

	private Button m_UseParametersButton;

	private Button m_SearchButton;

	private ListView m_PlantListView;

	public PlantViewForm(Document _CurDocument)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("PlantFamilyManagerDialog");
		m_SourceGroupBox.Text = EPShared.LocalRM.GetString("SourceDialog");
		m_SingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleFileDialog");
		m_DirectoryRadioButton.Text = EPShared.LocalRM.GetString("AMP_DirectoryMultipleFilesDialog");
		m_SingleFileGroupBox.Text = EPShared.LocalRM.GetString("SingleFileDialog");
		m_RFASingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_RFAFileDialog");
		m_CommaSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
		m_TabSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
		m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
		m_DirectoryLabel.Text = EPShared.LocalRM.GetString("AMP_DirectoryDialog");
		m_PlantCollectionGroupBox.Text = EPShared.LocalRM.GetString("PlantDialog") + " " + EPShared.LocalRM.GetString("CollectionDialog");
		m_SearchButton.Text = EPShared.LocalRM.GetString("Searc_AMP_hDialog");
		m_UseParametersButton.Text = EPShared.LocalRM.GetString("AMP_UseParametersDialog");
		m_ColumnDisplayButton.Text = EPShared.LocalRM.GetString("Column_AMP_DisplayDialog");
		m_DeleteFamiliesButton.Text = EPShared.LocalRM.GetString("DeleteFromL_AMP_ampDialog");
		m_ShowAllFamiliesButton.Text = EPShared.LocalRM.GetString("Sho_AMP_wAllDialog");
		m_FamilySymbolGroupBox.Text = EPShared.LocalRM.GetString("FamilySymbolOptionsDialog");
		m_FamilySymbolFileLabel.Text = EPShared.LocalRM.GetString("S_AMP_ymbolFileDialog");
		m_SymbolNameLabel.Text = EPShared.LocalRM.GetString("Sym_AMP_bolNameDialog");
		m_CreateSymbolFromDWGCheckBox.Text = EPShared.LocalRM.GetString("Cr_AMP_eateSymbolDWGDialog");
		m_DWGSymbolBaseButton.Text = EPShared.LocalRM.GetString("D_AMP_WGSymbolDialog");
		m_DestinationGroupBox.Text = EPShared.LocalRM.GetString("DestinationDialog");
		m_DestinationFileLabel.Text = EPShared.LocalRM.GetString("Fi_AMP_leDialog");
		m_ExportButton.Text = EPShared.LocalRM.GetString("E_AMP_xportDialog");
		m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("AMP_AddToFamilyDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_CurDocument = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(_CurDocument);
		m_FormatOptions = m_CurDocument.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_DisplayUnitSystem = m_CurDocument.DisplayUnitSystem;
		m_Units = m_CurDocument.GetUnits();
		try
		{
			m_UnitSymbolType = m_FormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_UnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_CurDocument.GetUnits().DecimalSymbol;
		InitializeControls();
		if (m_SingleFileRadioButton.Checked && m_RFASingleFileRadioButton.Checked)
		{
			EPToolTip.SetToolTip(m_SingleFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		}
		else if ((m_SingleFileRadioButton.Checked && m_CommaSingleFileRadioButton.Checked) || m_TabSingleFileRadioButton.Checked)
		{
			EPToolTip.SetToolTip(m_SingleFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
		}
		EPToolTip.SetToolTip(m_FamilySymbolFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		EPToolTip.SetToolTip(m_DestinationFileButton, EPShared.LocalRM.GetString("NewFamilyToolTip"));
		m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
		m_PlantListView.View = System.Windows.Forms.View.Details;
		ManagePlants.VerifySharedParameters(m_CurDocument, m_TransactionContainer);
		EnableDisableDialogFields();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		m_SingleFileRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewSourceOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_SingleFileRadioButton.Checked = true;
			}
			else
			{
				m_DirectoryRadioButton.Checked = true;
			}
		}
		m_RFASingleFileRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewSingleFileOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_RFASingleFileRadioButton.Checked = true;
				break;
			case 1:
				m_CommaSingleFileRadioButton.Checked = true;
				break;
			default:
				m_TabSingleFileRadioButton.Checked = true;
				break;
			}
		}
		m_CreateSymbolFromDWGCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewCreateSymbolFromDWGCheck", ref _nReturnValue) && _nReturnValue == 1)
		{
			m_CreateSymbolFromDWGCheckBox.Checked = true;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewDirectoryName", ref _strReturnValue))
		{
			m_DirectoryTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewSingleFileName", ref _strReturnValue))
		{
			m_SingleFileTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewFamilySymbolFileName", ref _strReturnValue))
		{
			m_FamilySymbolFileTextBox.Text = _strReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewDestinationFileName", ref _strReturnValue))
		{
			m_DestinationFileTextBox.Text = _strReturnValue;
		}
		m_SymbolNameComboBox.Items.Add(EPShared.LocalRM.GetString("AllGeometryString"));
		m_SymbolNameComboBox.SelectedIndex = 0;
		LoadColumnSettings();
	}

	private void LoadColumnSettings()
	{
		m_ParameterList = ManagePlants.GetParameterList("PlantView");
		m_PlantListView.Columns.Clear();
		string empty = string.Empty;
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			empty = ManagePlants.GetPlantParamenterName(m_ParameterList[i].PlantField);
			m_PlantListView.Columns.Add(empty, empty.Length * 10, HorizontalAlignment.Left);
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		num = Convert.ToInt32(!m_SingleFileRadioButton.Checked);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewSourceOption", num);
		num = ((!m_RFASingleFileRadioButton.Checked) ? (m_CommaSingleFileRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewSingleFileOption", num);
		num = (m_CreateSymbolFromDWGCheckBox.Checked ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewCreateSymbolFromDWGCheck", num);
		if (m_DirectoryTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewDirectoryName", m_DirectoryTextBox.Text);
		}
		if (m_SingleFileTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewSingleFileName", m_SingleFileTextBox.Text);
		}
		if (m_FamilySymbolFileTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewFamilySymbolFileName", m_FamilySymbolFileTextBox.Text);
		}
		if (m_DestinationFileTextBox.Text != string.Empty)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewDestinationFileName", m_DestinationFileTextBox.Text);
		}
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("PlantView" + m_ParameterList[i].PlantField.ToString() + "ColumnOrder", m_ParameterList[i].Order);
		}
	}

	private void EnableDisableDialogFields()
	{
		EnableDisableDialogFields(_bApplyToListButtons: true);
	}

	private void EnableDisableDialogFields(bool _bApplyToListButtons)
	{
		bool flag = false;
		if (m_PlantListView.Items.Count > 0)
		{
			flag = true;
		}
		m_PlantListView.Enabled = flag;
		if (_bApplyToListButtons)
		{
			m_SearchButton.Enabled = flag;
			m_UseParametersButton.Enabled = flag;
			m_ColumnDisplayButton.Enabled = flag;
			m_ShowAllFamiliesButton.Enabled = flag;
		}
		m_DeleteFamiliesButton.Enabled = flag;
		m_FamilySymbolGroupBox.Enabled = flag;
		if (flag && !m_CreateSymbolFromDWGCheckBox.Checked)
		{
			m_FamilySymbolFileLabel.Enabled = true;
			m_FamilySymbolFileTextBox.Enabled = true;
			m_FamilySymbolFileButton.Enabled = true;
			m_SymbolNameLabel.Enabled = true;
			m_SymbolNameComboBox.Enabled = true;
		}
		else
		{
			m_FamilySymbolFileLabel.Enabled = false;
			m_FamilySymbolFileTextBox.Enabled = false;
			m_FamilySymbolFileButton.Enabled = false;
			m_SymbolNameLabel.Enabled = false;
			m_SymbolNameComboBox.Enabled = false;
		}
		m_CreateSymbolFromDWGCheckBox.Enabled = flag;
		if (flag && m_CreateSymbolFromDWGCheckBox.Checked)
		{
			m_DWGSymbolBaseButton.Enabled = flag;
		}
		else
		{
			m_DWGSymbolBaseButton.Enabled = false;
		}
		m_DestinationGroupBox.Enabled = flag;
		m_DestinationFileLabel.Enabled = flag;
		m_DestinationFileTextBox.Enabled = flag;
		m_DestinationFileButton.Enabled = flag;
		m_ExportButton.Enabled = flag;
		m_SaveFamilyButton.Enabled = flag;
	}

	private List<FamilyTypeContainer> PopulateFamilyTypeSetList(FamilyManager _FamilyManager, List<ExternalDefinitionContainer> _ExternalDefinitionList)
	{
		List<FamilyTypeContainer> list = null;
		string empty = string.Empty;
		string empty2 = string.Empty;
		bool flag = false;
		ProgressBarForm progressBarForm = null;
		if (m_RFASingleFileRadioButton.Checked && m_SingleFileRadioButton.Checked)
		{
			progressBarForm = new ProgressBarForm();
			progressBarForm.MinValue = 0;
			progressBarForm.MaxValue = 10000;
			progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarImportMessage");
			progressBarForm.ShowForm();
			progressBarForm.Refresh();
		}
		foreach (FamilyType type in _FamilyManager.Types)
		{
			empty2 = type.Name.Trim();
			if (empty2 != string.Empty)
			{
				foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
				{
					if (string.Compare(empty2, plantListFamilyType.FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					ListViewItem listViewItem = new ListViewItem();
					for (int i = 0; i < m_ParameterList.Count; i++)
					{
						empty = string.Empty;
						FindParamenterValue(_FamilyManager, type, ManagePlants.GetPlantParamenterName(m_ParameterList[i].PlantField), ref empty);
						if (m_ParameterList[i].PlantField == PlantField.Height || m_ParameterList[i].PlantField == PlantField.PlantHeight || m_ParameterList[i].PlantField == PlantField.PlantWidth || m_ParameterList[i].PlantField == PlantField.CharacteristicsFoliageSize || m_ParameterList[i].PlantField == PlantField.PlantSpacing)
						{
							double dConvertedDouble = 1.0;
							if (empty != string.Empty)
							{
								dConvertedDouble = ValueConversion.ToDouble(empty);
							}
							RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
						}
						if (i == 0)
						{
							listViewItem = m_PlantListView.Items.Add(empty2, empty, string.Empty);
							listViewItem.Tag = empty2;
						}
						else
						{
							listViewItem.SubItems.Add(empty);
						}
						if (m_RFASingleFileRadioButton.Checked && m_SingleFileRadioButton.Checked)
						{
							progressBarForm.UpdateProgressBar(1);
						}
					}
					if (list == null)
					{
						list = new List<FamilyTypeContainer>();
					}
					list.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetFamilyParameterSetForType(type, _FamilyManager, _ExternalDefinitionList)));
				}
				else
				{
					flag = false;
				}
			}
			if (m_RFASingleFileRadioButton.Checked && m_SingleFileRadioButton.Checked)
			{
				progressBarForm.UpdateProgressBar(1);
			}
		}
		if (m_RFASingleFileRadioButton.Checked && m_SingleFileRadioButton.Checked)
		{
			progressBarForm.SetMaxValue();
			Thread.Sleep(300);
			progressBarForm.Close();
		}
		return list;
	}

	private bool FindParamenterValue(FamilyManager FamilyManager, FamilyType type, string _strParamter, ref string _strValue)
	{
		PlantField plantField = PlantField.None;
		bool result = false;
		FamilyParameter familyParameter = FamilyManager.get_Parameter(_strParamter);
		if (familyParameter != null && ManagePlants.GetPlantFieldFromParamenter(familyParameter.Definition.Name) != PlantField.None && type.HasValue(familyParameter))
		{
			switch (familyParameter.StorageType)
			{
			case StorageType.Double:
				if (type.AsDouble(familyParameter) is double)
				{
					result = true;
					_strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
				}
				break;
			case StorageType.Integer:
				if (type.AsInteger(familyParameter) is int)
				{
					result = true;
					_strValue = Convert.ToString(type.AsInteger(familyParameter));
				}
				break;
			case StorageType.String:
				if (type.AsString(familyParameter) != null)
				{
					result = true;
					_strValue = type.AsString(familyParameter);
				}
				break;
			}
		}
		return result;
	}

	private void OnSearchButton(object sender, EventArgs e)
	{
		SetSelectedPlantList();
		if (ManagePlants.FindFamilyTypes(EPShared.LocalRM.GetString("PlantViewSearchTitle"), m_CurDocument, ref m_PlantListFamilyTypeList))
		{
			int num = -1;
			for (num = 0; num < m_PlantListView.Items.Count; num++)
			{
				if (!m_PlantListView.SelectedIndices.Contains(num))
				{
					m_PlantListView.Items.RemoveAt(num);
					num--;
				}
			}
			m_nPlantListViewSortColumn = -1;
			m_PlantListView.Sorting = SortOrder.None;
			string empty = string.Empty;
			foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
			{
				if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
				{
					PopulatePlantListView(plantListFamilyType);
				}
			}
		}
		EnableDisableDialogFields(_bApplyToListButtons: false);
	}

	private bool ValidateFields()
	{
		string text = m_FamilySymbolFileTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySymbolFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FamilySymbolFileTextBox);
			return false;
		}
		string empty = string.Empty;
		empty = ".rfa";
		if (text.IndexOf(empty) < 0)
		{
			if (text.IndexOf("\\") <= 0 && text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length = -1;
			if (text.IndexOf("\\") > 0)
			{
				length = text.LastIndexOf("\\");
			}
			else if (text.IndexOf("/") > 0)
			{
				length = text.LastIndexOf("/");
			}
			if (!Directory.Exists(text.Substring(0, length)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			text += empty;
		}
		else
		{
			if (text.IndexOf("\\") <= 0 && text.IndexOf("/") <= 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
			int length2 = -1;
			if (text.IndexOf("\\") > 0)
			{
				length2 = text.LastIndexOf("\\");
			}
			else if (text.IndexOf("/") > 0)
			{
				length2 = text.LastIndexOf("/");
			}
			if (!Directory.Exists(text.Substring(0, length2)))
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				return false;
			}
		}
		m_FamilySymbolFileTextBox.Text = text;
		if (!File.Exists(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ExistingSymbolFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FamilySymbolFileTextBox);
			return false;
		}
		FileInfo fileInfo = new FileInfo(text);
		if (string.Compare(fileInfo.Extension, ".rfa", ignoreCase: true) != 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SymbolNoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_FamilySymbolFileTextBox);
			return false;
		}
		text = m_DestinationFileTextBox.Text;
		if (string.IsNullOrEmpty(text))
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyDestinationFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_DestinationFileTextBox);
			return false;
		}
		FileInfo fileInfo2 = new FileInfo(text);
		if (string.Compare(fileInfo2.Extension, ".rfa", ignoreCase: true) != 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRFAExtforDestinationMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_DestinationFileTextBox);
			return false;
		}
		if (m_SingleFileRadioButton.Checked && RevitUtility.CompareFileNames(m_SingleFileTextBox.Text, text) == 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("SameSourceAndDestinationFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			SiteDesigner.UI.WpfFocus.Focus(m_DestinationFileTextBox);
			return false;
		}
		if (File.Exists(text))
		{
			if (RevitUtility.CompareFileNames(m_CurDocument.PathName, text) != 0)
			{
				switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation))
				{
				case DialogResult.Yes:
				{
					Document CurDocument = null;
					if (ManagePlants.IsDocumentOpen(m_CurDocument.Application, text, ref CurDocument))
					{
						bool flag = false;
						if (m_OpenDocumentList != null && m_OpenDocumentList.Count > 0)
						{
							for (int num = m_OpenDocumentList.Count - 1; num >= 0; num--)
							{
								if (RevitUtility.CompareFileNames(m_OpenDocumentList[num].PathName, CurDocument.PathName) == 0)
								{
									m_OpenDocumentList[num].Close(saveModified: false);
									m_OpenDocumentList.RemoveAt(num);
									flag = true;
									break;
								}
							}
						}
						if (!flag)
						{
							CurDocument.Close(saveModified: false);
						}
					}
					File.Delete(text);
					break;
				}
				case DialogResult.Cancel:
					return false;
				}
			}
			else
			{
				DialogResult dialogResult = RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
				if (dialogResult == DialogResult.No)
				{
					return false;
				}
			}
		}
		return true;
	}

	private void SetSelectedPlantList()
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		if ((num = m_PlantListView.SelectedItems.Count) < 1)
		{
			return;
		}
		for (num2 = 0; num2 < num; num2++)
		{
			for (num3 = 0; num3 < m_PlantListFamilyTypeList.Count; num3++)
			{
				if (m_PlantListFamilyTypeList[num3].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string)m_PlantListView.SelectedItems[num2].Tag, m_PlantListFamilyTypeList[num3].FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
				{
					m_PlantListFamilyTypeList[num3].Status = FamilyParameterWrapperStatus.Selected;
					break;
				}
			}
		}
	}

	private bool FindSelectedPlantList(ref List<FamilyTypeContainer> _SelectedPlantList)
	{
		int num = -1;
		int num2 = -1;
		int num3 = -1;
		if ((num = m_PlantListView.SelectedItems.Count) >= 1)
		{
			for (num2 = 0; num2 < num; num2++)
			{
				for (num3 = 0; num3 < m_PlantListFamilyTypeList.Count; num3++)
				{
					if (m_PlantListFamilyTypeList[num3].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string)m_PlantListView.SelectedItems[num2].Tag, m_PlantListFamilyTypeList[num3].FamilyTypeWrapper.FamilyTypeName, ignoreCase: true) == 0)
					{
						_SelectedPlantList.Add(m_PlantListFamilyTypeList[num3]);
						break;
					}
				}
			}
			return true;
		}
		RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		return false;
	}

	private void OnSaveFamilyButton(object sender, EventArgs e)
	{
		List<FamilyTypeContainer> _SelectedPlantList = new List<FamilyTypeContainer>();
		if (FindSelectedPlantList(ref _SelectedPlantList) && ValidateFields())
		{
			FileInfo fileInfo = new FileInfo(RevitUtility.GetFormattedFileName(m_DestinationFileTextBox.Text, _bCreateDirectory: true));
			if (ManagePlants.CreateNewFamilyDocument(m_CurDocument, _SelectedPlantList, m_FamilySymbolFileTextBox.Text, (string)m_SymbolNameComboBox.SelectedItem, fileInfo.FullName))
			{
				m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + fileInfo.Name);
				RevitUtility.LoadFamily(m_CurDocument, fileInfo.FullName, _bUseFailureHandling: true, ref m_TransactionContainer);
				m_TransactionContainer.Commit();
			}
			SaveSettings();
		}
	}

	private void OnSingleFileButton(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		if (m_RFASingleFileRadioButton.Checked)
		{
			openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		}
		else if (m_CommaSingleFileRadioButton.Checked)
		{
			openFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
		}
		else
		{
			openFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
		}
		openFileDialog.FilterIndex = 1;
		openFileDialog.RestoreDirectory = true;
		if (openFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_SingleFileTextBox.Text = openFileDialog.FileName;
			LoadFileFamilyInformation();
		}
	}

	private void OnFamilySymbolFileButton(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		openFileDialog.FilterIndex = 1;
		openFileDialog.RestoreDirectory = true;
		if (openFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_FamilySymbolFileTextBox.Text = openFileDialog.FileName;
			LoadFamilySymbolInformation();
		}
	}

	private void OnDestinationFileButton(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		saveFileDialog.FilterIndex = 1;
		saveFileDialog.RestoreDirectory = true;
		if (saveFileDialog.ShowDialog() == DialogResult.OK)
		{
			m_DestinationFileTextBox.Text = saveFileDialog.FileName;
			SiteDesigner.UI.WpfFocus.Focus(m_DestinationFileTextBox);
		}
	}

	private void OnDirectoryPickerButton(object sender, EventArgs e)
	{
		FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
		folderBrowserDialog.Description = EPShared.LocalRM.GetString("SelectRFADir");
		folderBrowserDialog.ShowNewFolderButton = false;
		if (m_DirectoryTextBox.Text != string.Empty)
		{
			folderBrowserDialog.SelectedPath = Path.GetDirectoryName(m_DirectoryTextBox.Text);
		}
		if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
		{
			m_DirectoryTextBox.Text = folderBrowserDialog.SelectedPath;
			LoadDirectoryFamilyInformation();
		}
	}

	private void OnDirectoryTextBoxLeaveFocus(object sender, EventArgs e)
	{
		LoadDirectoryFamilyInformation();
	}

	private void LoadDirectoryFamilyInformation()
	{
		if (RevitUtility.CompareDirectoryNames(m_strSourceDirectory, m_DirectoryTextBox.Text) == 0)
		{
			return;
		}
		CloseOpenDocuments();
		FindRecentFileList();
		m_strSourceDirectory = m_DirectoryTextBox.Text;
		m_PlantListView.Items.Clear();
		m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
		if (m_OpenDocumentList != null)
		{
			m_OpenDocumentList.Clear();
		}
		if (m_strSourceDirectory != string.Empty)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(m_strSourceDirectory);
			if (Directory.Exists(m_strSourceDirectory))
			{
				FileInfo[] files = directoryInfo.GetFiles("*.rfa");
				ProgressBarForm progressBarForm = new ProgressBarForm();
				progressBarForm.MinValue = 0;
				progressBarForm.MaxValue = files.Length;
				progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarLoadingFilesMessage");
				progressBarForm.ShowForm();
				progressBarForm.Refresh();
				FileInfo[] array = files;
				foreach (FileInfo currentFile in array)
				{
					VerifyFileAndPopulateFamilyTypeSetList(currentFile);
					progressBarForm.UpdateProgressBar(1);
				}
				progressBarForm.SetMaxValue();
				Thread.Sleep(300);
				progressBarForm.Close();
			}
		}
		EnableDisableDialogFields();
		LoadFamilySymbolInformation();
	}

	private void FindRecentFileList()
	{
		m_RecenFilesList = Settings.eplSetE_GetSectionValuesAsList("Recent File List", ApplicationUtility.RevitIniFilename);
	}

	private void ResetRecentFileList()
	{
		if (m_RecenFilesList == null || m_RecenFilesList.Count <= 0 || !Settings.eplSetE_DeleteSection("Recent File List", ApplicationUtility.RevitIniFilename))
		{
			return;
		}
		foreach (KeyValuePair<string, string> recenFiles in m_RecenFilesList)
		{
			Settings.eplSetE_SetSetting("Recent File List", recenFiles.Key, recenFiles.Value, ApplicationUtility.RevitIniFilename);
		}
	}

	private void CloseOpenDocuments()
	{
		if (m_OpenDocumentList != null && m_OpenDocumentList.Count > 0)
		{
			for (int num = m_OpenDocumentList.Count - 1; num >= 0; num--)
			{
				m_OpenDocumentList[num].Close(saveModified: false);
				m_OpenDocumentList.RemoveAt(num);
			}
		}
		ResetRecentFileList();
	}

	private void OnPlantViewFormClosing(object sender, FormClosingEventArgs e)
	{
		CloseOpenDocuments();
		SetDialogPosition();
	}

	private void OnSymbolBaseButton(object sender, EventArgs e)
	{
		PlantDWGViewer viewer = new PlantDWGViewer(m_CurDocument, m_TransactionContainer);
		using PlantDWGCreatorForm plantDWGCreatorForm = new PlantDWGCreatorForm(viewer);
		if (plantDWGCreatorForm.ShowDialog() != DialogResult.Cancel)
		{
			m_FamilySymbolFileTextBox.Text = plantDWGCreatorForm.SaveAsFileName;
		}
	}

	private void OnSourceChecked(object sender, EventArgs e)
	{
		m_DirectoryLabel.Visible = !m_SingleFileRadioButton.Checked;
		m_DirectoryTextBox.Visible = !m_SingleFileRadioButton.Checked;
		m_DirectoryButton.Visible = !m_SingleFileRadioButton.Checked;
		m_SingleFileLabel.Visible = m_SingleFileRadioButton.Checked;
		m_SingleFileTextBox.Visible = m_SingleFileRadioButton.Checked;
		m_SingleFileButton.Visible = m_SingleFileRadioButton.Checked;
		m_RFASingleFileRadioButton.Enabled = m_SingleFileRadioButton.Checked;
		m_CommaSingleFileRadioButton.Enabled = m_SingleFileRadioButton.Checked;
		m_TabSingleFileRadioButton.Enabled = m_SingleFileRadioButton.Checked;
	}

	private void FileRadioButtonCheckedChanged(object sender, EventArgs e)
	{
		if (m_SingleFileRadioButton.Checked && m_RFASingleFileRadioButton.Checked)
		{
			EPToolTip.SetToolTip(m_SingleFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		}
		else if ((m_SingleFileRadioButton.Checked && m_CommaSingleFileRadioButton.Checked) || m_TabSingleFileRadioButton.Checked)
		{
			EPToolTip.SetToolTip(m_SingleFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
		}
	}

	private void LoadFileFamilyInformation()
	{
		if (RevitUtility.CompareFileNames(m_strSourceFile, m_SingleFileTextBox.Text) == 0)
		{
			return;
		}
		CloseOpenDocuments();
		FindRecentFileList();
		m_strSourceFile = m_SingleFileTextBox.Text;
		m_PlantListView.Items.Clear();
		m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
		if (m_OpenDocumentList != null)
		{
			m_OpenDocumentList.Clear();
		}
		if (!string.IsNullOrEmpty(m_strSourceFile))
		{
			FileInfo fileInfo = new FileInfo(m_strSourceFile);
			if (File.Exists(m_strSourceFile))
			{
				if (m_RFASingleFileRadioButton.Checked)
				{
					if (string.Compare(fileInfo.Extension, ".rfa", ignoreCase: true) != 0)
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("SingleFileNoRFAMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return;
					}
					VerifyFileAndPopulateFamilyTypeSetList(fileInfo);
				}
				else
				{
					if (string.Compare(fileInfo.Extension, ".txt", ignoreCase: true) != 0 && string.Compare(fileInfo.Extension, ".csv", ignoreCase: true) != 0)
					{
						RevitMessageBox.Show(EPShared.LocalRM.GetString("SingleFileNoCSVTXTMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
						return;
					}
					string strSeparator = string.Empty;
					if (m_CommaSingleFileRadioButton.Checked)
					{
						strSeparator = ",";
					}
					else if (m_TabSingleFileRadioButton.Checked)
					{
						strSeparator = "\t";
					}
					List<FamilyTypeContainer> list = new List<FamilyTypeContainer>();
					ImportExport.ImportFileWithSeparator(m_CurDocument, m_strSourceFile, strSeparator, ref m_PlantListFamilyTypeList);
					foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
					{
						PopulatePlantListView(plantListFamilyType);
					}
				}
			}
		}
		EnableDisableDialogFields();
		LoadFamilySymbolInformation();
	}

	private void OnSingleFileTextBoxLeaveFocus(object sender, EventArgs e)
	{
		LoadFileFamilyInformation();
	}

	private void PopulatePlantListView(FamilyTypeContainer _CurFamilyTypeContainer)
	{
		bool flag = false;
		string empty = string.Empty;
		ListViewItem listViewItem = new ListViewItem();
		for (int i = 0; i < m_ParameterList.Count; i++)
		{
			empty = ManagePlants.GetPlantParamenterName(m_ParameterList[i].PlantField);
			for (int j = 0; j < _CurFamilyTypeContainer.FamilyParameterList.Count; j++)
			{
				if (string.Compare(empty, _CurFamilyTypeContainer.FamilyParameterList[j].ParameterName, ignoreCase: true) != 0)
				{
					continue;
				}
				flag = true;
				string _strToDisplay = _CurFamilyTypeContainer.FamilyParameterList[j].Value;
				if (m_ParameterList[i].PlantField == PlantField.Height || m_ParameterList[i].PlantField == PlantField.PlantHeight || m_ParameterList[i].PlantField == PlantField.PlantWidth || m_ParameterList[i].PlantField == PlantField.CharacteristicsFoliageSize || m_ParameterList[i].PlantField == PlantField.PlantSpacing)
				{
					double dConvertedDouble = 1.0;
					if (_strToDisplay != null && _strToDisplay != string.Empty)
					{
						dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
					}
					RevitGeometry.Units_ConvertDoubleToString(dConvertedDouble, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				}
				if (i == 0)
				{
					listViewItem = m_PlantListView.Items.Add(_CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName, _strToDisplay, string.Empty);
					listViewItem.Tag = _CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName;
				}
				else
				{
					listViewItem.SubItems.Add(_strToDisplay);
				}
				break;
			}
			if (!flag)
			{
				if (i == 0)
				{
					listViewItem = m_PlantListView.Items.Add(_CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName, string.Empty, string.Empty);
					listViewItem.Tag = _CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName;
				}
				else
				{
					listViewItem.SubItems.Add(string.Empty);
				}
			}
			else
			{
				flag = false;
			}
		}
	}

	private void VerifyFileAndPopulateFamilyTypeSetList(FileInfo _CurrentFile)
	{
		Document CurDocument = null;
		List<FamilyTypeContainer> list = null;
		string text = _CurrentFile.Name.Substring(0, _CurrentFile.Name.Length - _CurrentFile.Extension.Length);
		int num = text.LastIndexOf('.');
		if (num >= 0 && text.Length - 1 == num + 4)
		{
			int result = -1;
			if (int.TryParse(text.Substring(num + 1), out result))
			{
				return;
			}
		}
		bool flag = ManagePlants.IsDocumentOpen(m_CurDocument.Application, _CurrentFile.FullName, ref CurDocument);
		if (!flag)
		{
			CurDocument = m_CurDocument.Application.OpenDocumentFile(_CurrentFile.FullName);
		}
		EPTransactionContainer ePTransactionContainer = new EPTransactionContainer(CurDocument);
		ePTransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
		ePTransactionContainer.BeginTransaction();
		try
		{
			list = PopulateFamilyTypeSetList(CurDocument.FamilyManager, ManagePlants.PopulateExternalDefinitionList(ManagePlants.GetAllCurPlantingSharedParameters(m_CurDocument.Application)));
		}
		catch
		{
		}
		ePTransactionContainer.EndTransaction();
		ePTransactionContainer.Rollback();
		if (list != null)
		{
			if (m_OpenDocumentList == null)
			{
				m_OpenDocumentList = new List<Document>();
			}
			if (m_OpenDocumentList.Count == 0)
			{
				if (m_FamilySymbolFileTextBox.Text == string.Empty)
				{
					m_FamilySymbolFileTextBox.Text = _CurrentFile.FullName;
				}
				if (m_DestinationFileTextBox.Text == string.Empty)
				{
					m_DestinationFileTextBox.Text = m_strSourceDirectory;
				}
			}
			if (!flag)
			{
				m_OpenDocumentList.Add(CurDocument);
			}
			{
				foreach (FamilyTypeContainer item in list)
				{
					m_PlantListFamilyTypeList.Add(item);
				}
				return;
			}
		}
		if (!flag)
		{
			CurDocument.Close(saveModified: false);
		}
	}

	private void OnFamilySymbolFileTextBoxLeave(object sender, EventArgs e)
	{
		LoadFamilySymbolInformation();
	}

	private void LoadFamilySymbolInformation()
	{
		if (!string.IsNullOrEmpty(m_FamilySymbolFileTextBox.Text))
		{
			FileInfo fileInfo = new FileInfo(m_FamilySymbolFileTextBox.Text);
			if (fileInfo.Extension == string.Empty)
			{
				m_FamilySymbolFileTextBox.Text += ".rfa";
			}
		}
		if (RevitUtility.CompareFileNames(m_strSymbolFile, m_FamilySymbolFileTextBox.Text) == 0)
		{
			return;
		}
		m_strSymbolFile = m_FamilySymbolFileTextBox.Text;
		m_SymbolNameComboBox.Items.Clear();
		if (string.IsNullOrEmpty(m_FamilySymbolFileTextBox.Text) || !File.Exists(m_FamilySymbolFileTextBox.Text))
		{
			m_SymbolNameComboBox.Items.Add(EPShared.LocalRM.GetString("AllGeometryString"));
			m_SymbolNameComboBox.SelectedIndex = 0;
			return;
		}
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetPlantSymbolTransaction"));
		m_TransactionContainer.BeginTransaction();
		Family _Family = null;
		string empty = string.Empty;
		if (RevitUtility.LoadFamily(m_CurDocument, m_FamilySymbolFileTextBox.Text, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer) && _Family != null)
		{
			empty = _Family.Name;
		}
		else
		{
			FileInfo fileInfo2 = new FileInfo(m_FamilySymbolFileTextBox.Text);
			empty = ((!(fileInfo2.Extension != string.Empty)) ? fileInfo2.Name : fileInfo2.Name.Substring(0, fileInfo2.Name.LastIndexOf(fileInfo2.Extension)));
		}
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_CurDocument);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		foreach (Element item in list)
		{
			if (item is FamilySymbol { Category: not null } familySymbol && familySymbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(familySymbol.Family.Name, empty, ignoreCase: true) == 0)
			{
				m_SymbolNameComboBox.Items.Add(familySymbol.Name);
			}
		}
		if (m_SymbolNameComboBox.Items.Count > 0)
		{
			m_SymbolNameComboBox.Items.Insert(0, EPShared.LocalRM.GetString("AllSymbolsString"));
		}
		else
		{
			filteredElementCollector = new FilteredElementCollector(m_CurDocument);
			list = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_GenericModel).ToElements();
			bool flag = false;
			Parameter parameter = null;
			foreach (Element item2 in list)
			{
				if (!(item2 is FamilySymbol { Category: not null } familySymbol2) || familySymbol2.Category.Id.Value64() != BuiltInCategory.OST_GenericModel.GetHashCode() || string.Compare(familySymbol2.Family.Name, empty, ignoreCase: true) != 0)
				{
					continue;
				}
				parameter = familySymbol2.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
				if (parameter != null)
				{
					if (string.Compare(parameter.AsString(), Convert.ToInt32(LandcaddID.Planting).ToString("000"), ignoreCase: true) == 0)
					{
						flag = true;
					}
					m_SymbolNameComboBox.Items.Add(familySymbol2.Name);
				}
			}
			if (!flag)
			{
				m_SymbolNameComboBox.Items.Clear();
			}
			if (m_SymbolNameComboBox.Items.Count > 0)
			{
				m_SymbolNameComboBox.Items.Insert(0, EPShared.LocalRM.GetString("AllSymbolsString"));
			}
			else
			{
				m_SymbolNameComboBox.Items.Add(EPShared.LocalRM.GetString("AllGeometryString"));
			}
		}
		m_TransactionContainer.AbortTransaction();
		m_TransactionContainer.Rollback();
		m_SymbolNameComboBox.SelectedIndex = 0;
	}

	private void OnUseParametersButtonClick(object sender, EventArgs e)
	{
		using PlantFieldsForm plantFieldsForm = new PlantFieldsForm(_bIsDisplayFields: false, "PlantFields");
		plantFieldsForm.ShowDialog();
	}

	private void OnColumnDisplayButtonClick(object sender, EventArgs e)
	{
		using PlantFieldsForm plantFieldsForm = new PlantFieldsForm(_bIsDisplayFields: true, "PlantView");
		if (plantFieldsForm.ShowDialog() == DialogResult.Cancel)
		{
			return;
		}
		LoadColumnSettings();
		m_PlantListView.Items.Clear();
		foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
		{
			if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
			{
				plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
				PopulatePlantListView(plantListFamilyType);
			}
		}
	}

	private void OnCreateSymbolFromDWGCheckBoxChecked(object sender, EventArgs e)
	{
		m_DWGSymbolBaseButton.Enabled = m_CreateSymbolFromDWGCheckBox.Checked;
		m_FamilySymbolFileLabel.Enabled = !m_CreateSymbolFromDWGCheckBox.Checked;
		m_FamilySymbolFileTextBox.Enabled = !m_CreateSymbolFromDWGCheckBox.Checked;
		m_FamilySymbolFileButton.Enabled = !m_CreateSymbolFromDWGCheckBox.Checked;
		m_SymbolNameLabel.Enabled = !m_CreateSymbolFromDWGCheckBox.Checked;
		m_SymbolNameComboBox.Enabled = !m_CreateSymbolFromDWGCheckBox.Checked;
	}

	private void OnExportButtonClick(object sender, EventArgs e)
	{
		List<FamilyTypeContainer> _SelectedPlantList = new List<FamilyTypeContainer>();
		if (FindSelectedPlantList(ref _SelectedPlantList))
		{
			using (PlantExportForm plantExportForm = new PlantExportForm(m_CurDocument, _SelectedPlantList, ManagePlants.GetParameterList("PlantFields", _bPopulateDefaultParameters: true)))
			{
				plantExportForm.ShowDialog();
			}
		}
	}

	private void OnPlantListViewColumnClick(object sender, ColumnClickEventArgs e)
	{
		if (e.Column != m_nPlantListViewSortColumn)
		{
			m_nPlantListViewSortColumn = e.Column;
			m_PlantListView.Sorting = SortOrder.Ascending;
		}
		else if (m_PlantListView.Sorting == SortOrder.Ascending)
		{
			m_PlantListView.Sorting = SortOrder.Descending;
		}
		else
		{
			m_PlantListView.Sorting = SortOrder.Ascending;
		}
		m_PlantListView.Sort();
		m_PlantListView.ListViewItemSorter = new ListViewItemComparer(e.Column, m_PlantListView.Sorting);
	}

	private void OnShowAllFamiliesButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		int nPlantListViewSortColumn = m_nPlantListViewSortColumn;
		SortOrder sorting = m_PlantListView.Sorting;
		SetSelectedPlantList();
		for (num = 0; num < m_PlantListView.Items.Count; num++)
		{
			if (!m_PlantListView.SelectedIndices.Contains(num))
			{
				m_PlantListView.Items.RemoveAt(num);
				num--;
			}
		}
		m_nPlantListViewSortColumn = -1;
		m_PlantListView.Sorting = SortOrder.None;
		string empty = string.Empty;
		foreach (FamilyTypeContainer plantListFamilyType in m_PlantListFamilyTypeList)
		{
			if (plantListFamilyType.Status != FamilyParameterWrapperStatus.Selected)
			{
				plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
				PopulatePlantListView(plantListFamilyType);
			}
		}
		EnableDisableDialogFields(_bApplyToListButtons: false);
		if (sorting != SortOrder.None)
		{
			m_nPlantListViewSortColumn = nPlantListViewSortColumn;
			m_PlantListView.Sorting = sorting;
			m_PlantListView.Sort();
			m_PlantListView.ListViewItemSorter = new ListViewItemComparer(m_nPlantListViewSortColumn, m_PlantListView.Sorting);
		}
	}

	private void OnDeleteFamiliesButtonClick(object sender, EventArgs e)
	{
		int num = -1;
		int num2 = -1;
		if (m_PlantListView.SelectedItems.Count >= 1)
		{
			for (num2 = 0; num2 < m_PlantListFamilyTypeList.Count; num2++)
			{
				if (m_PlantListFamilyTypeList[num2].Status == FamilyParameterWrapperStatus.Excluded)
				{
					continue;
				}
				num = m_PlantListView.SelectedItems.IndexOfKey(m_PlantListFamilyTypeList[num2].FamilyTypeWrapper.FamilyTypeName);
				if (num >= 0)
				{
					m_PlantListFamilyTypeList[num2].Status = FamilyParameterWrapperStatus.Excluded;
					m_PlantListView.SelectedItems[num].Remove();
					if (m_PlantListView.SelectedItems.Count == 0)
					{
						break;
					}
				}
			}
			EnableDisableDialogFields(_bApplyToListButtons: false);
		}
		else
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
		}
	}

	private void OnDirectoryTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			LoadDirectoryFamilyInformation();
		}
	}

	private void OnSingleFileTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			LoadFileFamilyInformation();
		}
	}

	private void OnFamilySymbolFileTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			LoadFamilySymbolInformation();
		}
	}

	private void AddExtensionToDestination()
	{
		if (!string.IsNullOrEmpty(m_DestinationFileTextBox.Text))
		{
			FileInfo fileInfo = new FileInfo(m_DestinationFileTextBox.Text);
			if (fileInfo.Extension == string.Empty)
			{
				m_DestinationFileTextBox.Text += ".rfa";
			}
		}
	}

	private void OnDestinationFileTextBoxLeave(object sender, EventArgs e)
	{
		AddExtensionToDestination();
	}

	private void OnDestinationFileTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			AddExtensionToDestination();
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_SaveFamilyButton = new System.Windows.Forms.Button();
		this.m_DWGSymbolBaseButton = new System.Windows.Forms.Button();
		this.m_SourceGroupBox = new System.Windows.Forms.GroupBox();
		this.m_DirectoryTextBox = new System.Windows.Forms.TextBox();
		this.m_DirectoryButton = new System.Windows.Forms.Button();
		this.m_SingleFileTextBox = new System.Windows.Forms.TextBox();
		this.m_SingleFileButton = new System.Windows.Forms.Button();
		this.m_DirectoryLabel = new System.Windows.Forms.Label();
		this.m_SingleFileLabel = new System.Windows.Forms.Label();
		this.m_SingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_DirectoryRadioButton = new System.Windows.Forms.RadioButton();
		this.m_SingleFileGroupBox = new System.Windows.Forms.GroupBox();
		this.m_TabSingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_CommaSingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_RFASingleFileRadioButton = new System.Windows.Forms.RadioButton();
		this.m_DestinationGroupBox = new System.Windows.Forms.GroupBox();
		this.m_DestinationFileTextBox = new System.Windows.Forms.TextBox();
		this.m_DestinationFileButton = new System.Windows.Forms.Button();
		this.m_DestinationFileLabel = new System.Windows.Forms.Label();
		this.m_FamilySymbolGroupBox = new System.Windows.Forms.GroupBox();
		this.m_CreateSymbolFromDWGCheckBox = new System.Windows.Forms.CheckBox();
		this.m_SymbolNameLabel = new System.Windows.Forms.Label();
		this.m_SymbolNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_FamilySymbolFileTextBox = new System.Windows.Forms.TextBox();
		this.m_FamilySymbolFileButton = new System.Windows.Forms.Button();
		this.m_FamilySymbolFileLabel = new System.Windows.Forms.Label();
		this.m_ExportButton = new System.Windows.Forms.Button();
		this.m_PlantCollectionGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ShowAllFamiliesButton = new System.Windows.Forms.Button();
		this.m_DeleteFamiliesButton = new System.Windows.Forms.Button();
		this.m_ColumnDisplayButton = new System.Windows.Forms.Button();
		this.m_UseParametersButton = new System.Windows.Forms.Button();
		this.m_SearchButton = new System.Windows.Forms.Button();
		this.m_PlantListView = new System.Windows.Forms.ListView();
		this.m_SourceGroupBox.SuspendLayout();
		this.m_SingleFileGroupBox.SuspendLayout();
		this.m_DestinationGroupBox.SuspendLayout();
		this.m_FamilySymbolGroupBox.SuspendLayout();
		this.m_PlantCollectionGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_CancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
		this.m_CancelButton.Location = new System.Drawing.Point(523, 538);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(77, 23);
		this.m_CancelButton.TabIndex = 6;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_SaveFamilyButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_SaveFamilyButton.Location = new System.Drawing.Point(432, 538);
		this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
		this.m_SaveFamilyButton.Size = new System.Drawing.Size(85, 23);
		this.m_SaveFamilyButton.TabIndex = 5;
		this.m_SaveFamilyButton.Text = "Sa&ve Family";
		this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
		this.m_SaveFamilyButton.Click += new System.EventHandler(this.OnSaveFamilyButton);
		this.m_DWGSymbolBaseButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_DWGSymbolBaseButton.Enabled = false;
		this.m_DWGSymbolBaseButton.Location = new System.Drawing.Point(221, 72);
		this.m_DWGSymbolBaseButton.Name = "m_DWGSymbolBaseButton";
		this.m_DWGSymbolBaseButton.Size = new System.Drawing.Size(110, 23);
		this.m_DWGSymbolBaseButton.TabIndex = 6;
		this.m_DWGSymbolBaseButton.Text = "D&WG Symbol";
		this.m_DWGSymbolBaseButton.UseVisualStyleBackColor = true;
		this.m_DWGSymbolBaseButton.Click += new System.EventHandler(this.OnSymbolBaseButton);
		this.m_SourceGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SourceGroupBox.Controls.Add(this.m_DirectoryTextBox);
		this.m_SourceGroupBox.Controls.Add(this.m_DirectoryButton);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileTextBox);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileButton);
		this.m_SourceGroupBox.Controls.Add(this.m_DirectoryLabel);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileLabel);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileRadioButton);
		this.m_SourceGroupBox.Controls.Add(this.m_DirectoryRadioButton);
		this.m_SourceGroupBox.Controls.Add(this.m_SingleFileGroupBox);
		this.m_SourceGroupBox.Location = new System.Drawing.Point(12, 12);
		this.m_SourceGroupBox.Name = "m_SourceGroupBox";
		this.m_SourceGroupBox.Size = new System.Drawing.Size(587, 128);
		this.m_SourceGroupBox.TabIndex = 0;
		this.m_SourceGroupBox.TabStop = false;
		this.m_SourceGroupBox.Text = "Source";
		this.m_DirectoryTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DirectoryTextBox.Location = new System.Drawing.Point(80, 99);
		this.m_DirectoryTextBox.Name = "m_DirectoryTextBox";
		this.m_DirectoryTextBox.Size = new System.Drawing.Size(471, 20);
		this.m_DirectoryTextBox.TabIndex = 4;
		this.m_DirectoryTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnDirectoryTextBoxKeyDown);
		this.m_DirectoryTextBox.Leave += new System.EventHandler(this.OnDirectoryTextBoxLeaveFocus);
		this.m_DirectoryButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_DirectoryButton.Location = new System.Drawing.Point(557, 98);
		this.m_DirectoryButton.Name = "m_DirectoryButton";
		this.m_DirectoryButton.Size = new System.Drawing.Size(24, 20);
		this.m_DirectoryButton.TabIndex = 5;
		this.m_DirectoryButton.TabStop = false;
		this.m_DirectoryButton.Text = "...";
		this.m_DirectoryButton.UseVisualStyleBackColor = true;
		this.m_DirectoryButton.Click += new System.EventHandler(this.OnDirectoryPickerButton);
		this.m_SingleFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SingleFileTextBox.Location = new System.Drawing.Point(80, 99);
		this.m_SingleFileTextBox.Name = "m_SingleFileTextBox";
		this.m_SingleFileTextBox.Size = new System.Drawing.Size(471, 20);
		this.m_SingleFileTextBox.TabIndex = 4;
		this.m_SingleFileTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnSingleFileTextBoxKeyDown);
		this.m_SingleFileTextBox.Leave += new System.EventHandler(this.OnSingleFileTextBoxLeaveFocus);
		this.m_SingleFileButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_SingleFileButton.Location = new System.Drawing.Point(557, 99);
		this.m_SingleFileButton.Name = "m_SingleFileButton";
		this.m_SingleFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_SingleFileButton.TabIndex = 5;
		this.m_SingleFileButton.TabStop = false;
		this.m_SingleFileButton.Text = "...";
		this.m_SingleFileButton.UseVisualStyleBackColor = true;
		this.m_SingleFileButton.Click += new System.EventHandler(this.OnSingleFileButton);
		this.m_DirectoryLabel.AutoSize = true;
		this.m_DirectoryLabel.Location = new System.Drawing.Point(9, 102);
		this.m_DirectoryLabel.Name = "m_DirectoryLabel";
		this.m_DirectoryLabel.Size = new System.Drawing.Size(52, 13);
		this.m_DirectoryLabel.TabIndex = 3;
		this.m_DirectoryLabel.Text = "Direct&ory:";
		this.m_SingleFileLabel.AutoSize = true;
		this.m_SingleFileLabel.Location = new System.Drawing.Point(9, 102);
		this.m_SingleFileLabel.Name = "m_SingleFileLabel";
		this.m_SingleFileLabel.Size = new System.Drawing.Size(26, 13);
		this.m_SingleFileLabel.TabIndex = 3;
		this.m_SingleFileLabel.Text = "&File:";
		this.m_SingleFileRadioButton.AutoSize = true;
		this.m_SingleFileRadioButton.Location = new System.Drawing.Point(12, 19);
		this.m_SingleFileRadioButton.Name = "m_SingleFileRadioButton";
		this.m_SingleFileRadioButton.Size = new System.Drawing.Size(73, 17);
		this.m_SingleFileRadioButton.TabIndex = 0;
		this.m_SingleFileRadioButton.TabStop = true;
		this.m_SingleFileRadioButton.Text = "&Single File";
		this.m_SingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_SingleFileRadioButton.CheckedChanged += new System.EventHandler(this.OnSourceChecked);
		this.m_DirectoryRadioButton.AutoSize = true;
		this.m_DirectoryRadioButton.Location = new System.Drawing.Point(164, 19);
		this.m_DirectoryRadioButton.Name = "m_DirectoryRadioButton";
		this.m_DirectoryRadioButton.Size = new System.Drawing.Size(168, 17);
		this.m_DirectoryRadioButton.TabIndex = 1;
		this.m_DirectoryRadioButton.TabStop = true;
		this.m_DirectoryRadioButton.Text = "&Directory (Multiple Family Files)";
		this.m_DirectoryRadioButton.UseVisualStyleBackColor = true;
		this.m_DirectoryRadioButton.CheckedChanged += new System.EventHandler(this.OnSourceChecked);
		this.m_SingleFileGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SingleFileGroupBox.Controls.Add(this.m_TabSingleFileRadioButton);
		this.m_SingleFileGroupBox.Controls.Add(this.m_CommaSingleFileRadioButton);
		this.m_SingleFileGroupBox.Controls.Add(this.m_RFASingleFileRadioButton);
		this.m_SingleFileGroupBox.Location = new System.Drawing.Point(6, 42);
		this.m_SingleFileGroupBox.Name = "m_SingleFileGroupBox";
		this.m_SingleFileGroupBox.Size = new System.Drawing.Size(575, 51);
		this.m_SingleFileGroupBox.TabIndex = 2;
		this.m_SingleFileGroupBox.TabStop = false;
		this.m_SingleFileGroupBox.Text = "Single File Options";
		this.m_TabSingleFileRadioButton.AutoSize = true;
		this.m_TabSingleFileRadioButton.Location = new System.Drawing.Point(362, 23);
		this.m_TabSingleFileRadioButton.Name = "m_TabSingleFileRadioButton";
		this.m_TabSingleFileRadioButton.Size = new System.Drawing.Size(139, 17);
		this.m_TabSingleFileRadioButton.TabIndex = 2;
		this.m_TabSingleFileRadioButton.TabStop = true;
		this.m_TabSingleFileRadioButton.Text = "&Tab Delimited (Text File)";
		this.m_TabSingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_TabSingleFileRadioButton.CheckedChanged += new System.EventHandler(this.FileRadioButtonCheckedChanged);
		this.m_CommaSingleFileRadioButton.AutoSize = true;
		this.m_CommaSingleFileRadioButton.Location = new System.Drawing.Point(158, 23);
		this.m_CommaSingleFileRadioButton.Name = "m_CommaSingleFileRadioButton";
		this.m_CommaSingleFileRadioButton.Size = new System.Drawing.Size(155, 17);
		this.m_CommaSingleFileRadioButton.TabIndex = 1;
		this.m_CommaSingleFileRadioButton.TabStop = true;
		this.m_CommaSingleFileRadioButton.Text = "&Comma Delimited (CSV File)";
		this.m_CommaSingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_CommaSingleFileRadioButton.CheckedChanged += new System.EventHandler(this.FileRadioButtonCheckedChanged);
		this.m_RFASingleFileRadioButton.AutoSize = true;
		this.m_RFASingleFileRadioButton.Location = new System.Drawing.Point(6, 23);
		this.m_RFASingleFileRadioButton.Name = "m_RFASingleFileRadioButton";
		this.m_RFASingleFileRadioButton.Size = new System.Drawing.Size(103, 17);
		this.m_RFASingleFileRadioButton.TabIndex = 0;
		this.m_RFASingleFileRadioButton.TabStop = true;
		this.m_RFASingleFileRadioButton.Text = "&RFA (Family File)";
		this.m_RFASingleFileRadioButton.UseVisualStyleBackColor = true;
		this.m_RFASingleFileRadioButton.CheckedChanged += new System.EventHandler(this.FileRadioButtonCheckedChanged);
		this.m_DestinationGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationGroupBox.Controls.Add(this.m_DestinationFileTextBox);
		this.m_DestinationGroupBox.Controls.Add(this.m_DestinationFileButton);
		this.m_DestinationGroupBox.Controls.Add(this.m_DestinationFileLabel);
		this.m_DestinationGroupBox.Location = new System.Drawing.Point(13, 489);
		this.m_DestinationGroupBox.Name = "m_DestinationGroupBox";
		this.m_DestinationGroupBox.Size = new System.Drawing.Size(587, 42);
		this.m_DestinationGroupBox.TabIndex = 3;
		this.m_DestinationGroupBox.TabStop = false;
		this.m_DestinationGroupBox.Text = "Destination";
		this.m_DestinationFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationFileTextBox.Location = new System.Drawing.Point(58, 16);
		this.m_DestinationFileTextBox.Name = "m_DestinationFileTextBox";
		this.m_DestinationFileTextBox.Size = new System.Drawing.Size(492, 20);
		this.m_DestinationFileTextBox.TabIndex = 1;
		this.m_DestinationFileTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnDestinationFileTextBoxKeyDown);
		this.m_DestinationFileTextBox.Leave += new System.EventHandler(this.OnDestinationFileTextBoxLeave);
		this.m_DestinationFileButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_DestinationFileButton.Location = new System.Drawing.Point(556, 15);
		this.m_DestinationFileButton.Name = "m_DestinationFileButton";
		this.m_DestinationFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_DestinationFileButton.TabIndex = 2;
		this.m_DestinationFileButton.TabStop = false;
		this.m_DestinationFileButton.Text = "...";
		this.m_DestinationFileButton.UseVisualStyleBackColor = true;
		this.m_DestinationFileButton.Click += new System.EventHandler(this.OnDestinationFileButton);
		this.m_DestinationFileLabel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_DestinationFileLabel.AutoSize = true;
		this.m_DestinationFileLabel.Location = new System.Drawing.Point(6, 19);
		this.m_DestinationFileLabel.Name = "m_DestinationFileLabel";
		this.m_DestinationFileLabel.Size = new System.Drawing.Size(26, 13);
		this.m_DestinationFileLabel.TabIndex = 0;
		this.m_DestinationFileLabel.Text = "Fi&le:";
		this.m_FamilySymbolGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_CreateSymbolFromDWGCheckBox);
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_SymbolNameLabel);
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_SymbolNameComboBox);
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_FamilySymbolFileTextBox);
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_FamilySymbolFileButton);
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_DWGSymbolBaseButton);
		this.m_FamilySymbolGroupBox.Controls.Add(this.m_FamilySymbolFileLabel);
		this.m_FamilySymbolGroupBox.Location = new System.Drawing.Point(12, 382);
		this.m_FamilySymbolGroupBox.Name = "m_FamilySymbolGroupBox";
		this.m_FamilySymbolGroupBox.Size = new System.Drawing.Size(588, 101);
		this.m_FamilySymbolGroupBox.TabIndex = 2;
		this.m_FamilySymbolGroupBox.TabStop = false;
		this.m_FamilySymbolGroupBox.Text = "Family Symbol Options";
		this.m_CreateSymbolFromDWGCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_CreateSymbolFromDWGCheckBox.AutoSize = true;
		this.m_CreateSymbolFromDWGCheckBox.Location = new System.Drawing.Point(9, 76);
		this.m_CreateSymbolFromDWGCheckBox.Name = "m_CreateSymbolFromDWGCheckBox";
		this.m_CreateSymbolFromDWGCheckBox.Size = new System.Drawing.Size(161, 17);
		this.m_CreateSymbolFromDWGCheckBox.TabIndex = 5;
		this.m_CreateSymbolFromDWGCheckBox.Text = "Cr&eate Symbol From DWG(s)";
		this.m_CreateSymbolFromDWGCheckBox.UseVisualStyleBackColor = true;
		this.m_CreateSymbolFromDWGCheckBox.CheckedChanged += new System.EventHandler(this.OnCreateSymbolFromDWGCheckBoxChecked);
		this.m_SymbolNameLabel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_SymbolNameLabel.AutoSize = true;
		this.m_SymbolNameLabel.Location = new System.Drawing.Point(6, 48);
		this.m_SymbolNameLabel.Name = "m_SymbolNameLabel";
		this.m_SymbolNameLabel.Size = new System.Drawing.Size(75, 13);
		this.m_SymbolNameLabel.TabIndex = 3;
		this.m_SymbolNameLabel.Text = "Sym&bol Name:";
		this.m_SymbolNameComboBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_SymbolNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_SymbolNameComboBox.FormattingEnabled = true;
		this.m_SymbolNameComboBox.Location = new System.Drawing.Point(141, 45);
		this.m_SymbolNameComboBox.Name = "m_SymbolNameComboBox";
		this.m_SymbolNameComboBox.Size = new System.Drawing.Size(411, 21);
		this.m_SymbolNameComboBox.TabIndex = 4;
		this.m_FamilySymbolFileTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_FamilySymbolFileTextBox.Location = new System.Drawing.Point(141, 19);
		this.m_FamilySymbolFileTextBox.Name = "m_FamilySymbolFileTextBox";
		this.m_FamilySymbolFileTextBox.Size = new System.Drawing.Size(411, 20);
		this.m_FamilySymbolFileTextBox.TabIndex = 1;
		this.m_FamilySymbolFileTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnFamilySymbolFileTextBoxKeyDown);
		this.m_FamilySymbolFileTextBox.Leave += new System.EventHandler(this.OnFamilySymbolFileTextBoxLeave);
		this.m_FamilySymbolFileButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_FamilySymbolFileButton.Location = new System.Drawing.Point(558, 19);
		this.m_FamilySymbolFileButton.Name = "m_FamilySymbolFileButton";
		this.m_FamilySymbolFileButton.Size = new System.Drawing.Size(24, 20);
		this.m_FamilySymbolFileButton.TabIndex = 2;
		this.m_FamilySymbolFileButton.TabStop = false;
		this.m_FamilySymbolFileButton.Text = "...";
		this.m_FamilySymbolFileButton.UseVisualStyleBackColor = true;
		this.m_FamilySymbolFileButton.Click += new System.EventHandler(this.OnFamilySymbolFileButton);
		this.m_FamilySymbolFileLabel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
		this.m_FamilySymbolFileLabel.AutoSize = true;
		this.m_FamilySymbolFileLabel.Location = new System.Drawing.Point(6, 22);
		this.m_FamilySymbolFileLabel.Name = "m_FamilySymbolFileLabel";
		this.m_FamilySymbolFileLabel.Size = new System.Drawing.Size(63, 13);
		this.m_FamilySymbolFileLabel.TabIndex = 0;
		this.m_FamilySymbolFileLabel.Text = "S&ymbol File:";
		this.m_ExportButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
		this.m_ExportButton.Location = new System.Drawing.Point(351, 538);
		this.m_ExportButton.Name = "m_ExportButton";
		this.m_ExportButton.Size = new System.Drawing.Size(75, 23);
		this.m_ExportButton.TabIndex = 4;
		this.m_ExportButton.Text = "E&xport";
		this.m_ExportButton.UseVisualStyleBackColor = true;
		this.m_ExportButton.Click += new System.EventHandler(this.OnExportButtonClick);
		this.m_PlantCollectionGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_PlantCollectionGroupBox.Controls.Add(this.m_ShowAllFamiliesButton);
		this.m_PlantCollectionGroupBox.Controls.Add(this.m_DeleteFamiliesButton);
		this.m_PlantCollectionGroupBox.Controls.Add(this.m_ColumnDisplayButton);
		this.m_PlantCollectionGroupBox.Controls.Add(this.m_UseParametersButton);
		this.m_PlantCollectionGroupBox.Controls.Add(this.m_SearchButton);
		this.m_PlantCollectionGroupBox.Controls.Add(this.m_PlantListView);
		this.m_PlantCollectionGroupBox.Location = new System.Drawing.Point(12, 146);
		this.m_PlantCollectionGroupBox.Name = "m_PlantCollectionGroupBox";
		this.m_PlantCollectionGroupBox.Size = new System.Drawing.Size(588, 230);
		this.m_PlantCollectionGroupBox.TabIndex = 1;
		this.m_PlantCollectionGroupBox.TabStop = false;
		this.m_PlantCollectionGroupBox.Text = "Plant Collection";
		this.m_ShowAllFamiliesButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ShowAllFamiliesButton.Location = new System.Drawing.Point(473, 136);
		this.m_ShowAllFamiliesButton.Name = "m_ShowAllFamiliesButton";
		this.m_ShowAllFamiliesButton.Size = new System.Drawing.Size(109, 23);
		this.m_ShowAllFamiliesButton.TabIndex = 5;
		this.m_ShowAllFamiliesButton.Text = "Show &All";
		this.m_ShowAllFamiliesButton.UseVisualStyleBackColor = true;
		this.m_ShowAllFamiliesButton.Click += new System.EventHandler(this.OnShowAllFamiliesButtonClick);
		this.m_DeleteFamiliesButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_DeleteFamiliesButton.Location = new System.Drawing.Point(473, 107);
		this.m_DeleteFamiliesButton.Name = "m_DeleteFamiliesButton";
		this.m_DeleteFamiliesButton.Size = new System.Drawing.Size(109, 23);
		this.m_DeleteFamiliesButton.TabIndex = 4;
		this.m_DeleteFamiliesButton.Text = "Delete From L&ist";
		this.m_DeleteFamiliesButton.UseVisualStyleBackColor = true;
		this.m_DeleteFamiliesButton.Click += new System.EventHandler(this.OnDeleteFamiliesButtonClick);
		this.m_ColumnDisplayButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_ColumnDisplayButton.Location = new System.Drawing.Point(473, 77);
		this.m_ColumnDisplayButton.Name = "m_ColumnDisplayButton";
		this.m_ColumnDisplayButton.Size = new System.Drawing.Size(110, 23);
		this.m_ColumnDisplayButton.TabIndex = 3;
		this.m_ColumnDisplayButton.Text = "Colu&mn Display";
		this.m_ColumnDisplayButton.UseVisualStyleBackColor = true;
		this.m_ColumnDisplayButton.Click += new System.EventHandler(this.OnColumnDisplayButtonClick);
		this.m_UseParametersButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_UseParametersButton.Location = new System.Drawing.Point(473, 48);
		this.m_UseParametersButton.Name = "m_UseParametersButton";
		this.m_UseParametersButton.Size = new System.Drawing.Size(110, 23);
		this.m_UseParametersButton.TabIndex = 2;
		this.m_UseParametersButton.Text = "&Use Parameters";
		this.m_UseParametersButton.UseVisualStyleBackColor = true;
		this.m_UseParametersButton.Click += new System.EventHandler(this.OnUseParametersButtonClick);
		this.m_SearchButton.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.m_SearchButton.Location = new System.Drawing.Point(473, 19);
		this.m_SearchButton.Name = "m_SearchButton";
		this.m_SearchButton.Size = new System.Drawing.Size(109, 23);
		this.m_SearchButton.TabIndex = 1;
		this.m_SearchButton.Text = "Searc&h";
		this.m_SearchButton.UseVisualStyleBackColor = true;
		this.m_SearchButton.Click += new System.EventHandler(this.OnSearchButton);
		this.m_PlantListView.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.m_PlantListView.FullRowSelect = true;
		this.m_PlantListView.HideSelection = false;
		this.m_PlantListView.Location = new System.Drawing.Point(9, 19);
		this.m_PlantListView.Name = "m_PlantListView";
		this.m_PlantListView.Size = new System.Drawing.Size(458, 205);
		this.m_PlantListView.TabIndex = 0;
		this.m_PlantListView.UseCompatibleStateImageBehavior = false;
		this.m_PlantListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.OnPlantListViewColumnClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(612, 573);
		base.Controls.Add(this.m_PlantCollectionGroupBox);
		base.Controls.Add(this.m_ExportButton);
		base.Controls.Add(this.m_FamilySymbolGroupBox);
		base.Controls.Add(this.m_DestinationGroupBox);
		base.Controls.Add(this.m_SourceGroupBox);
		base.Controls.Add(this.m_SaveFamilyButton);
		base.Controls.Add(this.m_CancelButton);
		this.MinimumSize = new System.Drawing.Size(620, 600);
		base.Name = "PlantViewForm";
		this.Text = "Plant Family Manager";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnPlantViewFormClosing);
		this.m_SourceGroupBox.ResumeLayout(false);
		this.m_SourceGroupBox.PerformLayout();
		this.m_SingleFileGroupBox.ResumeLayout(false);
		this.m_SingleFileGroupBox.PerformLayout();
		this.m_DestinationGroupBox.ResumeLayout(false);
		this.m_DestinationGroupBox.PerformLayout();
		this.m_FamilySymbolGroupBox.ResumeLayout(false);
		this.m_FamilySymbolGroupBox.PerformLayout();
		this.m_PlantCollectionGroupBox.ResumeLayout(false);
		base.ResumeLayout(false);
		base.AcceptButton = this.m_SaveFamilyButton;
		base.CancelButton = this.m_CancelButton;
	}
}
