﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantBooklet
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using System.Collections.Generic;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantBooklet
{
  private Application m_CurApplication;
  private Document m_Document;
  private PlantBookletForm m_DisplayForm;
  private List<FamilySymbol> m_ExistingPlantSymbolList;
  private ElementSet m_InstanceSet = new ElementSet();
  private EPTransactionContainer m_TransactionContainer;

  public PlantBooklet(Document _CurDocument)
  {
    this.m_CurApplication = _CurDocument.Application;
    this.m_ExistingPlantSymbolList = new List<FamilySymbol>();
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.InitializeListData();
  }

  private void InitializeListData() => this.PopulateExistingPlantList();

  private void PopulateExistingPlantList()
  {
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements())
    {
      if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
        this.UpdateFamilySymbolContainerList(familyInstance.Symbol);
    }
  }

  private void UpdateFamilySymbolContainerList(FamilySymbol _SelectedSymbol)
  {
    FamilySymbolContainer familySymbolContainer = (FamilySymbolContainer) null;
    familySymbolContainer = new FamilySymbolContainer();
    for (int index = 0; index < this.m_ExistingPlantSymbolList.Count; ++index)
    {
      if (string.Compare(((Element) this.m_ExistingPlantSymbolList[index]).Name, ((Element) _SelectedSymbol).Name, true) == 0)
        return;
    }
    this.m_ExistingPlantSymbolList.Add(_SelectedSymbol);
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    if (this.m_ExistingPlantSymbolList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantBookletNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      return false;
    }
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_DisplayForm = new PlantBookletForm(this))
    {
      while (_DialogResult != DialogResult.Cancel)
        flag = this.ShowDialog(ref _DialogResult);
    }
    return flag;
  }

  private bool GetSinglePoint(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
      return false;
    foreach (Element element in _Elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        }
      }
      else
      {
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    return true;
  }

  private bool GetWindowPoints(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
      return false;
    foreach (Element element in _Elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
      }
    }
    return true;
  }

  private bool GetAllPointsWithType(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
  {
    IList<Element> elements = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements();
    if (elements == null || elements.Count == 0)
      return false;
    foreach (Element element in (IEnumerable<Element>) elements)
    {
      FamilyInstance familyInstance = element as FamilyInstance;
      LocationPoint location = element.Location as LocationPoint;
      if (familyInstance != null && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && location != null)
      {
        Eps_Point _FindPoint = new Eps_Point(location.Point);
        if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
        {
          _PointList.Add(_FindPoint);
          _InstanceSet.Insert(element);
        }
      }
    }
    return true;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    bool flag = false;
    int num = (int) this.m_DisplayForm.ShowDialog();
    _DialogResult = this.m_DisplayForm.DialogResult;
    if (_DialogResult == DialogResult.Cancel)
      flag = false;
    else if (_DialogResult == DialogResult.Retry)
    {
      ElementSet _InstanceSet = new ElementSet();
      List<Eps_Point> _PointList = new List<Eps_Point>();
      if (this.m_DisplayForm.SelectionSetChecked)
      {
        if (!this.GetSinglePoint(ref _InstanceSet, ref _PointList))
          return false;
      }
      else if (this.m_DisplayForm.WindowSelectChecked)
      {
        if (!this.GetWindowPoints(ref _InstanceSet, ref _PointList))
          return false;
      }
      else if (this.m_DisplayForm.AllInstancesChecked && !this.GetAllPointsWithType(ref _InstanceSet, ref _PointList))
        return false;
      this.m_InstanceSet = _InstanceSet;
      flag = true;
      this.m_DisplayForm.UpdateListView();
    }
    return flag;
  }

  public Document Document => this.m_Document;

  public List<FamilySymbol> ExistingPlantSymbolList
  {
    get => this.m_ExistingPlantSymbolList;
    set => this.m_ExistingPlantSymbolList = value;
  }

  public ElementSet InstanceSet => this.m_InstanceSet;

  public EPTransactionContainer TransactionContainer
  {
    set => this.m_TransactionContainer = value;
    get => this.m_TransactionContainer;
  }
}
