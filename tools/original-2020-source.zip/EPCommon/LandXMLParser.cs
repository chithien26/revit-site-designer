﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandXMLParser
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

#nullable disable
namespace EPCommon;

public class LandXMLParser
{
  public const double EPC_GRADS_TO_RADIANS = 0.015707963267948967;
  private List<LandXMLSurface> m_Surfaces;
  private List<LandXMLAlignment> m_Alignments;
  private string m_strFileName = string.Empty;
  private int m_nSpiralMessageCount;
  private bool m_bHasSpiral;
  private Dictionary<int, CgPoint> m_CgPntList;

  public LandXMLParser(string _strFileName)
  {
    this.m_Surfaces = new List<LandXMLSurface>();
    this.m_Alignments = new List<LandXMLAlignment>();
    this.m_strFileName = _strFileName;
    this.m_CgPntList = (Dictionary<int, CgPoint>) null;
  }

  public void ParseLandXMLSurfaces()
  {
    char[] chArray = new char[1]{ ' ' };
    XmlDocument xmlDocument = new XmlDocument();
    xmlDocument.Load(this.m_strFileName);
    XmlNodeList elementsByTagName1 = xmlDocument.GetElementsByTagName("Units");
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    foreach (XmlNode xmlNode in elementsByTagName1)
    {
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode.FirstChild.Attributes)
      {
        if (string.Compare(attribute.Name, "areaUnit", true) == 0)
          empty1 = attribute.Value;
        else if (string.Compare(attribute.Name, "linearUnit", true) == 0)
          empty2 = attribute.Value;
        else if (string.Compare(attribute.Name, "volumeUnit", true) == 0)
          empty3 = attribute.Value;
      }
    }
    XmlNodeList elementsByTagName2 = xmlDocument.GetElementsByTagName("Surface");
    int num = 1;
    foreach (XmlNode xmlNode in elementsByTagName2)
    {
      LandXMLSurface _SelectedSurface = new LandXMLSurface();
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode.Attributes)
      {
        if (string.Compare(attribute.Name, "name", true) == 0)
          _SelectedSurface.SurfaceName = attribute.Value;
        else if (string.Compare(attribute.Name, "desc", true) == 0)
          _SelectedSurface.SurfaceDescription = attribute.Value;
      }
      foreach (XmlNode childNode1 in xmlNode.ChildNodes)
      {
        if (string.Compare(childNode1.Name, "Definition", true) == 0)
        {
          foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode1.Attributes)
          {
            if (string.Compare(attribute.Name, "area2DSurf", true) == 0)
              _SelectedSurface.SurfaceArea2D = attribute.Value;
            else if (string.Compare(attribute.Name, "area3DSurf", true) == 0)
              _SelectedSurface.SurfaceArea3D = attribute.Value;
            else if (string.Compare(attribute.Name, "elevMax", true) == 0)
              _SelectedSurface.MaxElevation = attribute.Value;
            else if (string.Compare(attribute.Name, "elevMin", true) == 0)
              _SelectedSurface.MinElevation = attribute.Value;
          }
          foreach (XmlNode childNode2 in childNode1.ChildNodes)
          {
            if (string.Compare(childNode2.Name, "Pnts", true) == 0)
              _SelectedSurface.SurfacePointCount += childNode2.ChildNodes.Count;
          }
        }
      }
      _SelectedSurface.LinearUnit = empty2;
      _SelectedSurface.AreaUnit = empty1;
      _SelectedSurface.VolumeUnit = empty3;
      if (this.CheckForDuplicateSurfaces(_SelectedSurface))
      {
        _SelectedSurface.SurfaceName += num.ToString();
        ++num;
      }
      _SelectedSurface.XMLSurfaceName = _SelectedSurface.SurfaceName;
      if (_SelectedSurface.SurfacePointCount > 0)
        this.m_Surfaces.Add(_SelectedSurface);
    }
  }

  public void ParseLandXMLSurfacePoints(
    ref LandXMLSurface _CurrentSurface,
    ref ProgressBarForm ProgressFrm,
    int _nTotalPointCount)
  {
    char[] chArray = new char[1]{ ' ' };
    XmlDocument _CurrentXMLDocument = new XmlDocument();
    _CurrentXMLDocument.Load(this.m_strFileName);
    if (this.m_CgPntList == null)
      this.m_CgPntList = this.ParseCgPnts(_CurrentXMLDocument, _CurrentSurface.LinearUnit);
    if (ProgressFrm == null)
    {
      ProgressFrm = new ProgressBarForm();
      ProgressFrm.ShowForm();
      ProgressFrm.Refresh();
      ProgressFrm.MinValue = 0;
      ProgressFrm.MaxValue = _nTotalPointCount;
    }
    ProgressFrm.Message = EPShared.LocalRM.GetString("ProgressBarProcessingPointsForSurfaceMessage") + _CurrentSurface.SurfaceName;
    XmlNodeList elementsByTagName = _CurrentXMLDocument.GetElementsByTagName("Surface");
    int num1 = 0;
    foreach (XmlNode xmlNode1 in elementsByTagName)
    {
      bool flag1 = false;
      List<Eps_Point> _AllPnts = new List<Eps_Point>();
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode1.Attributes)
      {
        if (string.Compare(attribute.Name, "name", true) == 0)
        {
          if (string.Compare(attribute.Value, _CurrentSurface.XMLSurfaceName, true) == 0)
          {
            flag1 = true;
            break;
          }
          if (_CurrentSurface.XMLSurfaceName.StartsWith(attribute.Value))
          {
            if (_CurrentSurface.XMLSurfaceName.Length > attribute.Value.Length)
            {
              if (_CurrentSurface.XMLSurfaceName.LastIndexOf(Convert.ToString(num1), attribute.Value.Length) >= 0)
              {
                flag1 = true;
                break;
              }
              ++num1;
              break;
            }
            break;
          }
          break;
        }
      }
      if (flag1)
      {
        foreach (XmlNode childNode1 in xmlNode1.ChildNodes)
        {
          if (string.Compare(childNode1.Name, "Definition", true) == 0)
          {
            foreach (XmlNode childNode2 in childNode1.ChildNodes)
            {
              if (string.Compare(childNode2.Name, "Pnts", true) == 0)
              {
                XmlNodeList childNodes = childNode2.ChildNodes;
                int count = childNodes.Count;
                int _nValue = 0;
                for (int i = 0; i < count; ++i)
                {
                  ++_nValue;
                  XmlNode xmlNode2 = childNodes[i];
                  bool flag2 = false;
                  Eps_Point epsPoint = new Eps_Point();
                  if (xmlNode2.Attributes.Count > 0)
                  {
                    foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode2.Attributes)
                    {
                      if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                      {
                        bool flag3 = true;
                        for (int index = 0; index < attribute.Value.Length; ++index)
                        {
                          if (!char.IsDigit(attribute.Value[index]))
                          {
                            flag3 = false;
                            break;
                          }
                        }
                        if (flag3)
                        {
                          epsPoint = this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt;
                        }
                        else
                        {
                          for (int key = 0; key < this.m_CgPntList.Count; ++key)
                          {
                            if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                            {
                              epsPoint = this.m_CgPntList[key].CgPnt;
                              break;
                            }
                          }
                        }
                        flag2 = true;
                      }
                    }
                  }
                  if (!flag2)
                  {
                    int num2 = 1;
                    foreach (string _strValue in xmlNode2.InnerText.Split(chArray))
                    {
                      switch (num2)
                      {
                        case 1:
                          epsPoint.y = ValueConversion.Parse(_strValue);
                          break;
                        case 2:
                          epsPoint.x = ValueConversion.Parse(_strValue);
                          break;
                        case 3:
                          epsPoint.z = ValueConversion.Parse(_strValue);
                          break;
                      }
                      ++num2;
                    }
                  }
                  _AllPnts.Add(epsPoint);
                  if (_nValue == 100)
                  {
                    ProgressFrm.UpdateProgressBar(100);
                    _nValue = 0;
                  }
                }
                if (_nValue > 0)
                  ProgressFrm.UpdateProgressBar(_nValue);
              }
            }
          }
        }
        List<Eps_Point> _RevitPntList = new List<Eps_Point>();
        this.ConvertPntsToUnitsPnts(_AllPnts, ref _RevitPntList, _CurrentSurface.LinearUnit);
        _CurrentSurface.SurfacePoints = _RevitPntList;
        break;
      }
    }
  }

  public void ParseLandXMLAlignments()
  {
    char[] chArray = new char[1]{ ' ' };
    XmlDocument xmlDocument = new XmlDocument();
    xmlDocument.Load(this.m_strFileName);
    XmlNodeList elementsByTagName1 = xmlDocument.GetElementsByTagName("Units");
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    string empty4 = string.Empty;
    string empty5 = string.Empty;
    foreach (XmlNode xmlNode in elementsByTagName1)
    {
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode.FirstChild.Attributes)
      {
        if (string.Compare(attribute.Name, "areaUnit", true) == 0)
          empty1 = attribute.Value;
        else if (string.Compare(attribute.Name, "linearUnit", true) == 0)
          empty2 = attribute.Value;
        else if (string.Compare(attribute.Name, "volumeUnit", true) == 0)
          empty3 = attribute.Value;
        else if (string.Compare(attribute.Name, "angularUnit", true) == 0)
          empty4 = attribute.Value;
        else if (string.Compare(attribute.Name, "directionUnit", true) == 0)
          empty5 = attribute.Value;
      }
    }
    XmlNodeList elementsByTagName2 = xmlDocument.GetElementsByTagName("Alignment");
    int num1 = 1;
    bool flag = false;
    foreach (XmlNode xmlNode in elementsByTagName2)
    {
      LandXMLAlignment _SelectedAlignment = new LandXMLAlignment();
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode.Attributes)
      {
        if (string.Compare(attribute.Name, "name", true) == 0)
          _SelectedAlignment.Name = attribute.Value;
        else if (string.Compare(attribute.Name, "length", true) == 0)
          _SelectedAlignment.Length = attribute.Value;
        else if (string.Compare(attribute.Name, "staStart", true) == 0)
          _SelectedAlignment.StartStation = attribute.Value;
      }
      foreach (XmlNode childNode1 in xmlNode.ChildNodes)
      {
        if (string.Compare(childNode1.Name, "CoordGeom", true) == 0)
        {
          foreach (XmlNode childNode2 in childNode1.ChildNodes)
          {
            if (string.Compare(childNode2.Name, "Spiral", true) == 0)
            {
              flag = true;
              break;
            }
          }
          if (flag)
            break;
        }
      }
      if (!flag)
      {
        _SelectedAlignment.LinearUnit = empty2;
        _SelectedAlignment.AreaUnit = empty1;
        _SelectedAlignment.VolumeUnit = empty3;
        _SelectedAlignment.AngularUnit = empty4;
        if (this.CheckForDuplicateAlignments(_SelectedAlignment))
        {
          _SelectedAlignment.Name += num1.ToString();
          ++num1;
        }
        this.m_Alignments.Add(_SelectedAlignment);
      }
      else
      {
        if (this.m_nSpiralMessageCount == 0)
        {
          int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpiralsNotSupportedMessages"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Hand);
          ++this.m_nSpiralMessageCount;
        }
        flag = false;
      }
    }
    if (this.m_nSpiralMessageCount <= 0)
      return;
    this.m_bHasSpiral = true;
  }

  public void ParseLandXMLAlignmentSegments(
    ref LandXMLAlignment _CurrentAlignment,
    ref ProgressBarForm ProgressFrm,
    int _nAlignmentCount)
  {
    char[] chArray = new char[1]{ ' ' };
    XmlDocument _CurrentXMLDocument = new XmlDocument();
    _CurrentXMLDocument.Load(this.m_strFileName);
    if (this.m_CgPntList == null)
      this.m_CgPntList = this.ParseCgPnts(_CurrentXMLDocument, _CurrentAlignment.LinearUnit);
    if (ProgressFrm == null)
    {
      ProgressFrm = new ProgressBarForm();
      ProgressFrm.ShowForm();
      ProgressFrm.Refresh();
      ProgressFrm.MinValue = 0;
      ProgressFrm.MaxValue = _nAlignmentCount;
    }
    ProgressFrm.Message = EPShared.LocalRM.GetString("ProgressBarProcessingPointsForAlignmentMessage") + _CurrentAlignment.Name;
    XmlNodeList elementsByTagName = _CurrentXMLDocument.GetElementsByTagName("Alignment");
    bool flag1 = false;
    foreach (XmlNode xmlNode in elementsByTagName)
    {
      bool flag2 = false;
      int num1 = 1;
      foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode.Attributes)
      {
        if (string.Compare(attribute.Name, "name", true) == 0)
        {
          if (string.Compare(attribute.Value, _CurrentAlignment.Name, true) == 0)
          {
            flag2 = true;
            break;
          }
          if (_CurrentAlignment.Name.StartsWith(attribute.Value) && _CurrentAlignment.Name.Length > attribute.Value.Length)
          {
            if (_CurrentAlignment.Name.LastIndexOf(Convert.ToString(num1), attribute.Value.Length) >= 0)
            {
              flag2 = true;
              break;
            }
            ++num1;
          }
        }
      }
      if (flag2)
      {
        foreach (XmlNode childNode1 in xmlNode.ChildNodes)
        {
          if (string.Compare(childNode1.Name, "Start", true) == 0)
          {
            bool flag3 = false;
            Eps_Point epsPoint = new Eps_Point();
            if (childNode1.Attributes.Count > 0)
            {
              foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode1.Attributes)
              {
                if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                {
                  bool flag4 = true;
                  for (int index = 0; index < attribute.Value.Length; ++index)
                  {
                    if (!char.IsDigit(attribute.Value[index]))
                    {
                      flag4 = false;
                      break;
                    }
                  }
                  if (flag4)
                  {
                    epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt, _CurrentAlignment.LinearUnit);
                  }
                  else
                  {
                    for (int key = 0; key < this.m_CgPntList.Count; ++key)
                    {
                      if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                      {
                        epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[key].CgPnt, _CurrentAlignment.LinearUnit);
                        break;
                      }
                    }
                  }
                  flag3 = true;
                }
              }
            }
            if (!flag3)
            {
              int num2 = 1;
              foreach (string _strValue in childNode1.InnerText.Split(chArray))
              {
                switch (num2)
                {
                  case 1:
                    epsPoint.y = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                    break;
                  case 2:
                    epsPoint.x = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                    break;
                  case 3:
                    epsPoint.z = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                    break;
                }
                ++num2;
              }
            }
            _CurrentAlignment.StartPoint = epsPoint;
          }
          else if (string.Compare(childNode1.Name, "CoordGeom", true) == 0)
          {
            foreach (XmlNode childNode2 in childNode1.ChildNodes)
            {
              if (string.Compare(childNode2.Name, "Spiral", true) == 0)
              {
                flag1 = true;
                break;
              }
              if (string.Compare(childNode2.Name, "Line", true) == 0)
              {
                Eps_Line epsLine = new Eps_Line();
                foreach (XmlNode childNode3 in childNode2.ChildNodes)
                {
                  if (string.Compare(childNode3.Name, "start", true) == 0)
                  {
                    bool flag5 = false;
                    Eps_Point epsPoint = new Eps_Point();
                    if (childNode3.Attributes.Count > 0)
                    {
                      foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode3.Attributes)
                      {
                        if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                        {
                          bool flag6 = true;
                          for (int index = 0; index < attribute.Value.Length; ++index)
                          {
                            if (!char.IsDigit(attribute.Value[index]))
                            {
                              flag6 = false;
                              break;
                            }
                          }
                          if (flag6)
                          {
                            epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt, _CurrentAlignment.LinearUnit);
                          }
                          else
                          {
                            for (int key = 0; key < this.m_CgPntList.Count; ++key)
                            {
                              if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                              {
                                epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[key].CgPnt, _CurrentAlignment.LinearUnit);
                                break;
                              }
                            }
                          }
                          flag5 = true;
                        }
                      }
                    }
                    if (!flag5)
                    {
                      int num3 = 1;
                      foreach (string _strValue in childNode3.InnerText.Split(chArray))
                      {
                        switch (num3)
                        {
                          case 1:
                            epsPoint.y = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 2:
                            epsPoint.x = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 3:
                            epsPoint.z = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                        }
                        ++num3;
                      }
                    }
                    epsLine.StartPnt = epsPoint;
                  }
                  else if (string.Compare(childNode3.Name, "end", true) == 0)
                  {
                    bool flag7 = false;
                    Eps_Point epsPoint = new Eps_Point();
                    if (childNode3.Attributes.Count > 0)
                    {
                      foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode3.Attributes)
                      {
                        if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                        {
                          bool flag8 = true;
                          for (int index = 0; index < attribute.Value.Length; ++index)
                          {
                            if (!char.IsDigit(attribute.Value[index]))
                            {
                              flag8 = false;
                              break;
                            }
                          }
                          if (flag8)
                          {
                            epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt, _CurrentAlignment.LinearUnit);
                          }
                          else
                          {
                            for (int key = 0; key < this.m_CgPntList.Count; ++key)
                            {
                              if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                              {
                                epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[key].CgPnt, _CurrentAlignment.LinearUnit);
                                break;
                              }
                            }
                          }
                          flag7 = true;
                        }
                      }
                    }
                    if (!flag7)
                    {
                      int num4 = 1;
                      foreach (string _strValue in childNode3.InnerText.Split(chArray))
                      {
                        switch (num4)
                        {
                          case 1:
                            epsPoint.y = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 2:
                            epsPoint.x = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 3:
                            epsPoint.z = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                        }
                        ++num4;
                      }
                    }
                    epsLine.EndPnt = epsPoint;
                  }
                }
                _CurrentAlignment.Lines.Add(epsLine);
              }
              else if (string.Compare(childNode2.Name, "Curve", true) == 0)
              {
                Eps_Arc epsArc = new Eps_Arc();
                foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode2.Attributes)
                {
                  if (string.Compare(attribute.Name, "rot", true) == 0)
                  {
                    if (string.Compare(attribute.Value, "cw", true) == 0)
                      epsArc.Direction = -1;
                    else
                      epsArc.Direction = 1;
                  }
                  else if (string.Compare(attribute.Name, "delta", true) == 0)
                  {
                    if (attribute.Value != string.Empty)
                    {
                      if (_CurrentAlignment.AngularUnit == string.Empty)
                        _CurrentAlignment.AngularUnit = "radians";
                      epsArc.Delta = this.ConvertToRevitAngularUnits(_CurrentAlignment.AngularUnit, ValueConversion.ToDouble(attribute.Value));
                    }
                  }
                  else if (string.Compare(attribute.Name, "radius", true) == 0 && attribute.Value != string.Empty)
                    epsArc.Radius = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.ToDouble(attribute.Value));
                }
                foreach (XmlNode childNode4 in childNode2.ChildNodes)
                {
                  if (string.Compare(childNode4.Name, "start", true) == 0)
                  {
                    bool flag9 = false;
                    Eps_Point epsPoint = new Eps_Point();
                    if (childNode4.Attributes.Count > 0)
                    {
                      foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode4.Attributes)
                      {
                        if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                        {
                          bool flag10 = true;
                          for (int index = 0; index < attribute.Value.Length; ++index)
                          {
                            if (!char.IsDigit(attribute.Value[index]))
                            {
                              flag10 = false;
                              break;
                            }
                          }
                          if (flag10)
                          {
                            epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt, _CurrentAlignment.LinearUnit);
                          }
                          else
                          {
                            for (int key = 0; key < this.m_CgPntList.Count; ++key)
                            {
                              if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                              {
                                epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[key].CgPnt, _CurrentAlignment.LinearUnit);
                                break;
                              }
                            }
                          }
                          flag9 = true;
                        }
                      }
                    }
                    if (!flag9)
                    {
                      int num5 = 1;
                      foreach (string _strValue in childNode4.InnerText.Split(chArray))
                      {
                        switch (num5)
                        {
                          case 1:
                            epsPoint.y = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 2:
                            epsPoint.x = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 3:
                            epsPoint.z = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                        }
                        ++num5;
                      }
                    }
                    epsArc.StartPnt = epsPoint;
                  }
                  else if (string.Compare(childNode4.Name, "end", true) == 0)
                  {
                    bool flag11 = false;
                    Eps_Point epsPoint = new Eps_Point();
                    if (childNode4.Attributes.Count > 0)
                    {
                      foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode4.Attributes)
                      {
                        if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                        {
                          bool flag12 = true;
                          for (int index = 0; index < attribute.Value.Length; ++index)
                          {
                            if (!char.IsDigit(attribute.Value[index]))
                            {
                              flag12 = false;
                              break;
                            }
                          }
                          if (flag12)
                          {
                            epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt, _CurrentAlignment.LinearUnit);
                          }
                          else
                          {
                            for (int key = 0; key < this.m_CgPntList.Count; ++key)
                            {
                              if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                              {
                                epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[key].CgPnt, _CurrentAlignment.LinearUnit);
                                break;
                              }
                            }
                          }
                          flag11 = true;
                        }
                      }
                    }
                    if (!flag11)
                    {
                      int num6 = 1;
                      foreach (string _strValue in childNode4.InnerText.Split(chArray))
                      {
                        switch (num6)
                        {
                          case 1:
                            epsPoint.y = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 2:
                            epsPoint.x = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 3:
                            epsPoint.z = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                        }
                        ++num6;
                      }
                    }
                    epsArc.EndPnt = epsPoint;
                  }
                  else if (string.Compare(childNode4.Name, "center", true) == 0)
                  {
                    bool flag13 = false;
                    Eps_Point epsPoint = new Eps_Point();
                    if (childNode4.Attributes.Count > 0)
                    {
                      foreach (XmlAttribute attribute in (XmlNamedNodeMap) childNode4.Attributes)
                      {
                        if (string.Compare(attribute.Name, "pntRef", true) == 0 && attribute.Value != string.Empty)
                        {
                          bool flag14 = true;
                          for (int index = 0; index < attribute.Value.Length; ++index)
                          {
                            if (!char.IsDigit(attribute.Value[index]))
                            {
                              flag14 = false;
                              break;
                            }
                          }
                          if (flag14)
                          {
                            epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[Convert.ToInt32(attribute.Value)].CgPnt, _CurrentAlignment.LinearUnit);
                          }
                          else
                          {
                            for (int key = 0; key < this.m_CgPntList.Count; ++key)
                            {
                              if (string.Compare(attribute.Value, this.m_CgPntList[key].NameUnit, true) == 0)
                              {
                                epsPoint = this.ConvertPntToUnitsPnt(this.m_CgPntList[key].CgPnt, _CurrentAlignment.LinearUnit);
                                break;
                              }
                            }
                          }
                          flag13 = true;
                        }
                      }
                    }
                    if (!flag13)
                    {
                      int num7 = 1;
                      foreach (string _strValue in childNode4.InnerText.Split(chArray))
                      {
                        switch (num7)
                        {
                          case 1:
                            epsPoint.y = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 2:
                            epsPoint.x = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                          case 3:
                            epsPoint.z = this.ConvertToRevitUnits(_CurrentAlignment.LinearUnit, ValueConversion.Parse(_strValue));
                            break;
                        }
                        ++num7;
                      }
                    }
                    epsArc.RadiusPnt = epsPoint;
                  }
                }
                _CurrentAlignment.Curves.Add(epsArc);
              }
            }
            if (flag1)
              break;
          }
        }
        if (flag1)
        {
          if (this.m_nSpiralMessageCount == 0)
          {
            int num8 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpiralsNotSupportedMessages"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Hand);
            ++this.m_nSpiralMessageCount;
          }
          break;
        }
        break;
      }
    }
    if (this.m_nSpiralMessageCount > 0)
      this.m_bHasSpiral = true;
    ProgressFrm.UpdateProgressBar(1);
  }

  private Dictionary<int, CgPoint> ParseCgPnts(
    XmlDocument _CurrentXMLDocument,
    string strLinearUnit)
  {
    char[] chArray = new char[1]{ ' ' };
    Dictionary<int, CgPoint> cgPnts = new Dictionary<int, CgPoint>();
    foreach (XmlNode xmlNode1 in _CurrentXMLDocument.GetElementsByTagName("CgPoints"))
    {
      XmlNodeList childNodes = xmlNode1.ChildNodes;
      ProgressBarForm progressBarForm = new ProgressBarForm();
      progressBarForm.ShowForm();
      progressBarForm.Refresh();
      progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarProcessingCogoPointsMessage");
      progressBarForm.MinValue = 0;
      progressBarForm.MaxValue = childNodes.Count;
      int num1 = 0;
      int key = 0;
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      CgPoint cgPoint1 = (CgPoint) null;
      int num2 = 0;
      foreach (XmlNode xmlNode2 in childNodes)
      {
        string empty4 = string.Empty;
        string empty5 = string.Empty;
        string empty6 = string.Empty;
        bool flag1 = false;
        cgPoint1 = (CgPoint) null;
        foreach (XmlAttribute attribute in (XmlNamedNodeMap) xmlNode2.Attributes)
        {
          if (string.Compare(attribute.Name, "name", true) == 0)
          {
            empty6 = attribute.Value;
            bool flag2 = true;
            for (int index = 0; index < empty6.Length; ++index)
            {
              if (!char.IsDigit(empty6[index]))
              {
                flag2 = false;
                break;
              }
            }
            if (flag2)
              num1 = Convert.ToInt32(empty6);
            else
              ++num1;
          }
          else if (string.Compare(attribute.Name, "code", true) == 0)
            empty4 = attribute.Value;
          else if (string.Compare(attribute.Name, "desc", true) == 0)
            empty5 = attribute.Value;
          else if (string.Compare(attribute.Name, "PntRef", true) == 0)
          {
            bool flag3 = true;
            for (int index = 0; index < attribute.Value.Length; ++index)
            {
              if (!char.IsDigit(attribute.Value[index]))
              {
                flag3 = false;
                break;
              }
            }
            if (flag3)
              key = Convert.ToInt32(attribute.Value);
            else
              ++key;
            flag1 = true;
          }
        }
        if (!flag1 || !cgPnts.ContainsKey(key))
        {
          Eps_Point _CgPnt = new Eps_Point();
          int num3 = 1;
          foreach (string _strValue in xmlNode2.InnerText.Split(chArray))
          {
            switch (num3)
            {
              case 1:
                _CgPnt.y = ValueConversion.Parse(_strValue);
                break;
              case 2:
                _CgPnt.x = ValueConversion.Parse(_strValue);
                break;
              case 3:
                _CgPnt.z = ValueConversion.Parse(_strValue);
                break;
            }
            ++num3;
          }
          CgPoint cgPoint2 = new CgPoint(num1, empty4, empty5, empty6, _CgPnt);
          if (num1 >= 0)
          {
            while (cgPnts.ContainsKey(num1))
              ++num1;
            cgPnts.Add(num1, cgPoint2);
          }
          ++num2;
          if (num2 == 100)
          {
            progressBarForm.UpdateProgressBar(100);
            num2 = 0;
          }
        }
      }
      progressBarForm.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm.Close();
    }
    return cgPnts;
  }

  private bool CheckForDuplicateAlignments(LandXMLAlignment _SelectedAlignment)
  {
    foreach (LandXMLAlignment alignment in this.m_Alignments)
    {
      if (string.Compare(_SelectedAlignment.Name, alignment.Name, false) == 0)
        return true;
    }
    return false;
  }

  private bool CheckForDuplicateSurfaces(LandXMLSurface _SelectedSurface)
  {
    foreach (LandXMLSurface surface in this.m_Surfaces)
    {
      if (string.Compare(_SelectedSurface.SurfaceName, surface.SurfaceName, false) == 0)
        return true;
    }
    return false;
  }

  private double ConvertToRevitUnits(string _strLandXMLUnit, double _dValue)
  {
    DisplayUnitType _InputLinearDistanceType = (DisplayUnitType) 3;
    if (string.Compare(_strLandXMLUnit, EPShared.LocalRM.GetString("LinearUnitfootString_Lower"), true) == 0 || string.Compare(_strLandXMLUnit, EPShared.LocalRM.GetString("LinearUnitfeetString_Lower"), true) == 0 || string.Compare(_strLandXMLUnit, EPShared.LocalRM.GetString("LinearUnitFootString_Upper"), true) == 0 || string.Compare(_strLandXMLUnit, EPShared.LocalRM.GetString("LinearUnitFeetString_Upper"), true) == 0 || string.Compare(_strLandXMLUnit, "USSurveyFoot", true) == 0)
      return _dValue;
    if (string.Compare(_strLandXMLUnit, "inch", true) == 0)
    {
      _InputLinearDistanceType = (DisplayUnitType) 6;
    }
    else
    {
      if (string.Compare(_strLandXMLUnit, "mile", true) == 0)
        return 5280.0 * _dValue;
      if (string.Compare(_strLandXMLUnit, "millimeter", true) == 0)
        _InputLinearDistanceType = (DisplayUnitType) 2;
      else if (string.Compare(_strLandXMLUnit, "centimeter", true) == 0)
        _InputLinearDistanceType = (DisplayUnitType) 1;
      else if (string.Compare(_strLandXMLUnit, "meter", true) == 0)
        _InputLinearDistanceType = (DisplayUnitType) 0;
      else if (string.Compare(_strLandXMLUnit, "kilometer", true) == 0)
        return 3280.8399 * _dValue;
    }
    return RevitGeometry.ConvertLinearValue(_dValue, _InputLinearDistanceType, (DisplayUnitType) 3);
  }

  private double ConvertToRevitAngularUnits(string _strLandXMLUnit, double _dValue)
  {
    double revitAngularUnits = 0.0;
    if (string.Compare(_strLandXMLUnit, "radians", true) == 0)
      revitAngularUnits = _dValue;
    else if (string.Compare(_strLandXMLUnit, "grads", true) == 0)
      revitAngularUnits = Math.PI / 200.0 * _dValue;
    else if (string.Compare(_strLandXMLUnit, "decimal degrees", true) == 0)
      revitAngularUnits = LandXMLParser.DecimalDegreesToRadians(_dValue);
    else if (string.Compare(_strLandXMLUnit, "decimal dd.mm.ss", true) == 0)
      revitAngularUnits = this.ConvertDMSToRadians(_dValue.ToString("000.0000"));
    return revitAngularUnits;
  }

  private void ConvertPntsToUnitsPnts(
    List<Eps_Point> _AllPnts,
    ref List<Eps_Point> _RevitPntList,
    string _strLinearUnit)
  {
    _RevitPntList.Clear();
    DisplayUnitType _InputLinearDistanceType = (DisplayUnitType) 3;
    bool flag = false;
    if (string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitfootString_Lower"), true) == 0 || string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitfeetString_Lower"), true) == 0 || string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitFootString_Upper"), true) == 0 || string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitFeetString_Upper"), true) == 0 || string.Compare(_strLinearUnit, "USSurveyFoot", true) == 0)
      flag = true;
    else if (string.Compare(_strLinearUnit, "inch", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 6;
    else if (string.Compare(_strLinearUnit, "millimeter", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 2;
    else if (string.Compare(_strLinearUnit, "centimeter", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 1;
    else if (string.Compare(_strLinearUnit, "meter", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 0;
    foreach (Eps_Point allPnt in _AllPnts)
    {
      Eps_Point epsPoint = !flag ? (string.Compare(_strLinearUnit, "mile", true) != 0 ? (string.Compare(_strLinearUnit, "kilometer", true) != 0 ? new Eps_Point(RevitGeometry.ConvertLinearValue(allPnt.x, _InputLinearDistanceType, (DisplayUnitType) 3), RevitGeometry.ConvertLinearValue(allPnt.y, _InputLinearDistanceType, (DisplayUnitType) 3), RevitGeometry.ConvertLinearValue(allPnt.z, _InputLinearDistanceType, (DisplayUnitType) 3)) : new Eps_Point(allPnt.x * 3280.8399, allPnt.y * 3280.8399, allPnt.z * 3280.8399)) : new Eps_Point(allPnt.x * 5280.0, allPnt.y * 5280.0, allPnt.z * 5280.0)) : new Eps_Point(allPnt.x, allPnt.y, allPnt.z);
      _RevitPntList.Add(epsPoint);
    }
  }

  private Eps_Point ConvertPntToUnitsPnt(Eps_Point CurPoint, string _strLinearUnit)
  {
    DisplayUnitType _InputLinearDistanceType = (DisplayUnitType) 3;
    bool flag = false;
    if (string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitfootString_Lower"), true) == 0 || string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitfeetString_Lower"), true) == 0 || string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitFootString_Upper"), true) == 0 || string.Compare(_strLinearUnit, EPShared.LocalRM.GetString("LinearUnitFeetString_Upper"), true) == 0 || string.Compare(_strLinearUnit, "USSurveyFoot", true) == 0)
      flag = true;
    else if (string.Compare(_strLinearUnit, "inch", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 6;
    else if (string.Compare(_strLinearUnit, "millimeter", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 2;
    else if (string.Compare(_strLinearUnit, "centimeter", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 1;
    else if (string.Compare(_strLinearUnit, "meter", true) == 0)
      _InputLinearDistanceType = (DisplayUnitType) 0;
    return !flag ? (string.Compare(_strLinearUnit, "mile", true) != 0 ? (string.Compare(_strLinearUnit, "kilometer", true) != 0 ? new Eps_Point(RevitGeometry.ConvertLinearValue(CurPoint.x, _InputLinearDistanceType, (DisplayUnitType) 3), RevitGeometry.ConvertLinearValue(CurPoint.y, _InputLinearDistanceType, (DisplayUnitType) 3), RevitGeometry.ConvertLinearValue(CurPoint.z, _InputLinearDistanceType, (DisplayUnitType) 3)) : new Eps_Point(CurPoint.x * 3280.8399, CurPoint.y * 3280.8399, CurPoint.z * 3280.8399)) : new Eps_Point(CurPoint.x * 5280.0, CurPoint.y * 5280.0, CurPoint.z * 5280.0)) : new Eps_Point(CurPoint.x, CurPoint.y, CurPoint.z);
  }

  public static double DecimalDegreesToRadians(double _dDecimalDegrees)
  {
    return _dDecimalDegrees * (Math.PI / 180.0);
  }

  private double ConvertDMSToRadians(string _strDMS)
  {
    double _dRadians = 0.0;
    int _nDegree = 0;
    int _nMin = 0;
    double _dSec = 0.0;
    this.SeperateDMS(_strDMS, ref _nDegree, ref _nMin, ref _dSec);
    if (_nDegree >= 0)
      LandXMLParser.DMSToRadians(ref _dRadians, 1, _nDegree, _nMin, _dSec);
    else
      LandXMLParser.DMSToRadians(ref _dRadians, -1, _nDegree, _nMin, _dSec);
    return _dRadians;
  }

  private void SeperateDMS(string _strDMS, ref int _nDegree, ref int _nMin, ref double _dSec)
  {
    string str1 = _strDMS.Substring(0, 3);
    string str2 = _strDMS.Substring(4, 2);
    string _strValue = _strDMS.Substring(6, 2);
    _nDegree = Convert.ToInt32(str1);
    _nMin = Convert.ToInt32(str2);
    _dSec = ValueConversion.ToDouble(_strValue);
  }

  public static void DMSToRadians(
    ref double _dRadians,
    int _nSign,
    int _nDegrees,
    int _nMinutes,
    double _dSeconds)
  {
    _dRadians = (double) _nSign * (((double) Math.Abs(_nDegrees) + (double) Math.Abs(_nMinutes) / 60.0 + Math.Abs(_dSeconds) / 3600.0) * (Math.PI / 180.0));
  }

  public List<LandXMLSurface> Surfaces => this.m_Surfaces;

  public List<LandXMLAlignment> Allignments => this.m_Alignments;

  public string FileName => this.m_strFileName;

  public bool HasSpiral => this.m_bHasSpiral;
}
