﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyManagerForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class FamilyManagerForm : EPForm
{
  private Document m_Document;
  private List<FamilyBinder> m_FamilyList;
  private EPTransactionContainer m_TransactionContainer;
  private LandcaddID m_CurrentFamilyType = LandcaddID.Street;
  private int m_nMixtListViewSortColumn = -1;
  private List<string> m_OpenedFileList = new List<string>();
  private IContainer components;
  private GroupBox m_FamilyManagerGrpBox;
  private ListView m_FamilyManagerListView;
  private Button m_CopyButton;
  private Button m_ModifyButton;
  private Button m_AddButton;
  private Button m_CloseButton;
  private Button m_SaveButton;
  private Label m_FamilyManagerLbl;
  private Button m_LoadButton;

  public Document Document => this.m_Document;

  public ReadOnlyCollection<FamilyBinder> FamilyList
  {
    get => new ReadOnlyCollection<FamilyBinder>((IList<FamilyBinder>) this.m_FamilyList);
  }

  public EPTransactionContainer TransactionContainer => this.m_TransactionContainer;

  public FamilyManagerForm(Document _CurDocument, LandcaddID _CurrType)
  {
    this.InitializeComponent();
    this.m_CurrentFamilyType = _CurrType;
    this.SetStringValues();
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_FamilyList = new List<FamilyBinder>();
    this.PopulateFamilyAndSymbolLists(true);
    this.UpdateListView();
    this.GetDialogPosition();
  }

  private void UpdateListView()
  {
    this.m_FamilyManagerListView.Items.Clear();
    foreach (FamilyBinder family in this.m_FamilyList)
    {
      ListViewItem listViewItem1 = new ListViewItem();
      ListViewItem listViewItem2 = this.m_FamilyManagerListView.Items.Add(family.FamilyName);
      listViewItem2.Tag = (object) family.FamilyName;
      listViewItem2.SubItems.Add(family.FamilyPath);
    }
    if (this.m_FamilyManagerListView.Items.Count <= 0)
      return;
    this.m_FamilyManagerListView.Items[0].Selected = true;
  }

  private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
  {
    string strCurrentFamilyType = Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000");
    this.m_FamilyList.Clear();
    foreach (Document document in this.m_Document.Application.Documents)
      this.m_OpenedFileList.Add(document.PathName);
    Parameter CurLanddCadID = (Parameter) null;
    FamilySymbol familySymbol1 = (FamilySymbol) null;
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurLanddCadID = CurrentElement.LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(CurLanddCadID.AsString(), strCurrentFamilyType, true) == 0)).ToList<Element>();
    familySymbol1 = (FamilySymbol) null;
    foreach (Element element in list)
    {
      if (element is FamilySymbol familySymbol2 && ((Element) familySymbol2).Category != null)
      {
        CurLanddCadID = ((Element) familySymbol2).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (CurLanddCadID != null && string.Compare(CurLanddCadID.AsString(), Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000"), true) == 0)
        {
          bool flag = false;
          for (int index = 0; index < this.m_FamilyList.Count; ++index)
          {
            if (string.Compare(this.m_FamilyList[index].FamilyName, ((Element) familySymbol2.Family).Name, true) == 0)
            {
              flag = true;
              break;
            }
          }
          if (!flag)
          {
            string empty = string.Empty;
            Document _FamilyDocument = this.m_Document.EditFamily(familySymbol2.Family);
            if (_FamilyDocument != null)
            {
              string pathName = _FamilyDocument.PathName;
              this.m_FamilyList.Add(new FamilyBinder(((Element) familySymbol2.Family).Name, pathName, (Document) null, familySymbol2.Family)
              {
                FamilyTypeList = this.PopulateFamilyTypeSetList(_FamilyDocument, ((Element) familySymbol2.Family).Name),
                FamilyDocument = _FamilyDocument,
                Loaded = true
              });
            }
          }
        }
      }
    }
  }

  private int CheckForDuplicates(FamilyBinder _Binder)
  {
    if (_Binder == null)
      return -1;
    for (int index = 0; index < this.m_FamilyList.Count; ++index)
    {
      FamilyBinder family = this.m_FamilyList[index];
      if (string.Compare(family.FamilyName, _Binder.FamilyName, false) == 0 && string.Compare(family.FamilyPath, _Binder.FamilyPath, false) == 0)
        return index;
    }
    return -1;
  }

  private void CheckForDuplicates(DialogResult _CurrentResult)
  {
    if (_CurrentResult != DialogResult.OK)
      return;
    FamilyBinder family = this.m_FamilyList[this.m_FamilyList.Count - 1];
    string familyName = family.FamilyName;
    string familyPath = family.FamilyPath;
    bool flag = false;
    for (int index = 0; index < this.m_FamilyManagerListView.Items.Count - 1; ++index)
    {
      if (string.Compare(this.m_FamilyManagerListView.Items[index].SubItems[0].Text, familyName, false) == 0 && string.Compare(this.m_FamilyManagerListView.Items[index].SubItems[1].Text, familyPath, false) == 0)
      {
        flag = true;
        break;
      }
    }
    if (!flag)
      return;
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateFamilyInFamilyManagerMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    this.m_FamilyList.RemoveAt(this.m_FamilyList.Count - 1);
    this.UpdateListView();
  }

  private void SetStringValues()
  {
    this.m_LoadButton.Text = EPShared.LocalRM.GetString("AMP_LoadDialog");
    this.m_AddButton.Text = EPShared.LocalRM.GetString("AMP_New_NewFamilyDialog");
    this.m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
    this.m_CopyButton.Text = EPShared.LocalRM.GetString("AMP_CopyDialog");
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    empty1 = EPShared.LocalRM.GetString("FamilyManagerRibbonPanel");
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.PlantMix:
        empty2 = ApplicationUtility.GetString("");
        break;
      case LandcaddID.PatioWalk:
        empty2 = ApplicationUtility.GetString("");
        break;
      case LandcaddID.SoftTerrain:
        empty2 = EPShared.LocalRM.GetString("SoftTerrainManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblSoftTerrainText");
        this.ContextualHelpID = "HID_SDfamilyMgrSoftTerrain";
        break;
      case LandcaddID.Street:
        empty2 = EPShared.LocalRM.GetString("StreetTypeManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblStreetText");
        this.ContextualHelpID = "HID_SDfamilyMgrStreet";
        break;
      case LandcaddID.Curb:
        empty2 = EPShared.LocalRM.GetString("CurbTypeManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblCurbText");
        this.ContextualHelpID = "HID_SDfamilyMgrCurb";
        break;
      case LandcaddID.Sidewalk:
        empty2 = EPShared.LocalRM.GetString("SidewalkTypeManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblSidewalkText");
        this.ContextualHelpID = "HID_SDfamilyMgrSidewalk";
        break;
      case LandcaddID.RetainingWall:
        empty2 = EPShared.LocalRM.GetString("RetainingWallManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblRetainingWallText");
        this.ContextualHelpID = "HID_SDfamilyMgrRetainingWall";
        break;
      case LandcaddID.Steps:
        empty2 = EPShared.LocalRM.GetString("StepsManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblStepsText");
        break;
      case LandcaddID.ParkingLot:
        empty2 = EPShared.LocalRM.GetString("ParkingLotManagerString");
        this.m_FamilyManagerLbl.Text = EPShared.LocalRM.GetString("FamilyManagerLblParkingLotText");
        this.ContextualHelpID = "HID_SDfamilyMgrParkinglot";
        break;
    }
    this.Text = empty2 + EPShared.LocalRM.GetString("_FamilyManagerString");
    this.m_FamilyManagerGrpBox.Text = empty2 + EPShared.LocalRM.GetString("_FamiliesInModelString");
    List<string> stringList = new List<string>();
    stringList.Add(EPShared.LocalRM.GetString("FamilyString"));
    stringList.Add(EPShared.LocalRM.GetString("Path"));
    this.m_FamilyManagerListView.View = View.Details;
    this.m_FamilyManagerListView.MultiSelect = false;
    for (int index = 0; index < stringList.Count; ++index)
      this.m_FamilyManagerListView.Columns.Add(stringList[index], (this.m_FamilyManagerListView.Width - 6) / 2, HorizontalAlignment.Center);
    this.m_FamilyManagerListView.Columns[1].TextAlign = HorizontalAlignment.Left;
  }

  private void OnFamilyManagerModifyClicked(object sender, EventArgs e) => this.Modify();

  private void Modify()
  {
    int _nSelectedIndex = -1;
    List<FamilyBinder> familyBinderList = new List<FamilyBinder>();
    this.FindSelectedFamilyIndex(ref _nSelectedIndex);
    Document CurDocument = (Document) null;
    if (_nSelectedIndex < 0)
      return;
    FamilyBinder family = this.m_FamilyList[_nSelectedIndex];
    try
    {
      if (family.FamilyDocument == null)
        CurDocument = this.m_Document.Application.OpenDocumentFile(family.FamilyPath);
      else if (File.Exists(family.FamilyDocument.PathName))
      {
        if (!ManagePlants.IsDocumentOpen(family.FamilyDocument.Application, family.FamilyPath, ref CurDocument))
          CurDocument = this.m_Document.Application.OpenDocumentFile(family.FamilyPath);
      }
      else
        CurDocument = family.FamilyDocument;
    }
    catch (Exception ex)
    {
      if (!ManagePlants.IsDocumentOpen(family.FamilyDocument.Application, family.FamilyPath, ref CurDocument))
        CurDocument = this.m_Document.Application.OpenDocumentFile(family.FamilyPath);
    }
    if (new TypeManagerForm(ref family, CurDocument, this.m_CurrentFamilyType, this.m_Document).ShowDialog() == DialogResult.OK)
      this.m_FamilyList[_nSelectedIndex] = family;
    this.m_FamilyManagerListView.Items[_nSelectedIndex].Selected = true;
  }

  private void OnFamilyManagerAddClicked(object sender, EventArgs e) => this.AddFamily();

  private void AddFamily()
  {
    FamilyBinder _NewFamily = new FamilyBinder();
    Document _FamilyDocument = (Document) null;
    List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
    NewFamilyForm newFamilyForm = new NewFamilyForm(ref _NewFamily, this.m_Document, this.m_CurrentFamilyType);
    int num1 = (int) newFamilyForm.ShowDialog();
    if (newFamilyForm.DialogResult != DialogResult.OK)
      return;
    if (this.CheckForDuplicates(_NewFamily) >= 0)
    {
      int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("DuplicateFamilyInFamilyManagerMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      if (!_NewFamily.IsModified)
        return;
      _NewFamily.IsModified = true;
      if (ManageFamily.CreateNewFamilyDocument(this.m_Document, _NewFamily.FamilyTypeList, this.m_CurrentFamilyType, _NewFamily.FamilyPath, ref _FamilyDocument))
      {
        _NewFamily.FamilyDocument = _FamilyDocument;
        if (_FamilyDocument != null)
          _NewFamily.FamilyTypeList = this.PopulateFamilyTypeSetList(_FamilyDocument, _NewFamily.FamilyName);
        this.m_FamilyList.Add(_NewFamily);
        this.UpdateListView();
        if (this.m_FamilyManagerListView.Items.Count <= 0)
          return;
        this.m_FamilyManagerListView.Items[this.m_FamilyManagerListView.Items.Count - 1].Selected = true;
        this.Modify();
      }
      else
      {
        int num3 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("UnableCreateFamilyString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
  }

  private bool FindSelectedFamilyIndex(ref int _nSelectedIndex)
  {
    int num1 = -1;
    _nSelectedIndex = num1;
    int count;
    if ((count = this.m_FamilyManagerListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = 0; index1 < count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_FamilyList.Count; ++index2)
        {
          if (string.Compare((string) this.m_FamilyManagerListView.SelectedItems[index1].Tag, this.m_FamilyList[index2].FamilyName, true) == 0)
            _nSelectedIndex = index2;
        }
      }
      return true;
    }
    string empty = string.Empty;
    int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamilySelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private List<FamilyTypeContainer> PopulateFamilyTypeSetList(
    Document _FamilyDocument,
    string _strFamilyName)
  {
    EPTransactionContainer transactionContainer = new EPTransactionContainer(_FamilyDocument);
    transactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
    transactionContainer.BeginTransaction();
    FamilyManager familyManager = _FamilyDocument.FamilyManager;
    List<FamilyTypeContainer> familyTypeContainerList = (List<FamilyTypeContainer>) null;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    List<FamilyParameterTypeWrapper> parameterTypeWrapperList;
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.PlantMix:
        parameterTypeWrapperList = ManagePlants.PlantMixParamenterList();
        break;
      case LandcaddID.PatioWalk:
        parameterTypeWrapperList = ManagePlants.PatioWalkParamenterList();
        break;
      case LandcaddID.SoftTerrain:
        parameterTypeWrapperList = ManageFamily.SoftTerrainParameterList();
        break;
      case LandcaddID.Street:
        parameterTypeWrapperList = ManageFamily.StreetParamenterList();
        break;
      case LandcaddID.Curb:
        parameterTypeWrapperList = ManageFamily.CurbParameterList();
        break;
      case LandcaddID.Sidewalk:
        parameterTypeWrapperList = ManageFamily.SideWalkParamterList();
        break;
      case LandcaddID.RetainingWall:
        parameterTypeWrapperList = ManageFamily.RetainingWallParameterList();
        break;
      case LandcaddID.Steps:
        parameterTypeWrapperList = ManageFamily.StepsParameterList();
        break;
      case LandcaddID.ParkingLot:
        parameterTypeWrapperList = ManageFamily.ParkingLotParameterList();
        break;
    }
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = familyManager.Types.Size;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarLoadingFamilyMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    foreach (FamilyType type in familyManager.Types)
    {
      FamilyParameter familyParameter = familyManager[RevitParameters.SiteworksIDFamilyParameter];
      if (familyParameter != null && type.HasValue(familyParameter) && string.Compare(type.AsString(familyParameter), Convert.ToInt32((object) this.m_CurrentFamilyType).ToString("000"), true) == 0)
      {
        if (familyTypeContainerList == null)
          familyTypeContainerList = new List<FamilyTypeContainer>();
        FamilyTypeWrapper _FamilyTypeWrapper = new FamilyTypeWrapper(type);
        if (_FamilyTypeWrapper.FamilyTypeName.Trim() == string.Empty)
          _FamilyTypeWrapper.FamilyTypeName = _strFamilyName;
        switch (this.m_CurrentFamilyType)
        {
          case LandcaddID.PlantMix:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManagePlants.GetPlantMixFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.PatioWalk:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManagePlants.GetPatioWalkFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.SoftTerrain:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetSoftTerrainFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.Street:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetStreetFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.Curb:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetCurbFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.Sidewalk:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetSidewalkFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.RetainingWall:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetRetainingWallFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.Steps:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetStepsFamilyParameterSetForType(type, familyManager)));
            break;
          case LandcaddID.ParkingLot:
            familyTypeContainerList.Add(new FamilyTypeContainer(_FamilyTypeWrapper, ManageFamily.GetParkingLotFamilyParameterSetForType(type, familyManager)));
            break;
        }
        progressBarForm.UpdateProgressBar(1);
      }
    }
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    transactionContainer.EndTransaction();
    transactionContainer.Rollback();
    return familyTypeContainerList;
  }

  private bool FindParamenterValue(
    FamilyManager FamilyManager,
    FamilyType type,
    string _strParamter,
    ref string _strValue)
  {
    bool paramenterValue = false;
    FamilyParameter familyParameter = FamilyManager[_strParamter];
    if (familyParameter != null && type.HasValue(familyParameter))
    {
      switch (familyParameter.StorageType - 1)
      {
        case 0:
          if ((ValueType) type.AsInteger(familyParameter) is int)
          {
            paramenterValue = true;
            _strValue = Convert.ToString((object) type.AsInteger(familyParameter));
            break;
          }
          break;
        case 1:
          if ((ValueType) type.AsDouble(familyParameter) is double)
          {
            paramenterValue = true;
            _strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
            break;
          }
          break;
        case 2:
          if (type.AsString(familyParameter) != null)
          {
            paramenterValue = true;
            _strValue = type.AsString(familyParameter);
            break;
          }
          break;
      }
    }
    return paramenterValue;
  }

  private void OnCloseButtonClicked(object sender, EventArgs e)
  {
    bool flag = false;
    foreach (FamilyBinder family in this.m_FamilyList)
    {
      if (family.IsModified)
      {
        flag = true;
        break;
      }
    }
    if (flag)
    {
      if (RevitMessageBox.Show(EPShared.LocalRM.GetString("SaveFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
        return;
      this.CloseDocuments();
      this.DialogResult = DialogResult.OK;
    }
    else
    {
      this.CloseDocuments();
      this.DialogResult = DialogResult.OK;
    }
  }

  private void OnSaveButtonClicked(object sender, EventArgs e)
  {
    List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
    switch (this.m_CurrentFamilyType)
    {
      case LandcaddID.SoftTerrain:
      case LandcaddID.Street:
      case LandcaddID.Curb:
      case LandcaddID.Sidewalk:
      case LandcaddID.RetainingWall:
      case LandcaddID.Steps:
      case LandcaddID.ParkingLot:
        using (List<FamilyBinder>.Enumerator enumerator = this.m_FamilyList.GetEnumerator())
        {
          while (enumerator.MoveNext())
          {
            FamilyBinder current = enumerator.Current;
            if (current.FamilyTypeList.Count <= 0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidTypeMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              return;
            }
            if (current.IsModified)
            {
              bool flag = true;
              if (current.FamilyPath == string.Empty)
              {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.FilterIndex = 1;
                saveFileDialog.RestoreDirectory = true;
                saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                  current.FamilyPath = saveFileDialog.FileName;
                else
                  flag = false;
              }
              if (current.FamilyDocument.IsReadOnlyFile)
              {
                if (RevitMessageBox.Show(EPShared.LocalRM.GetString("ReadOnlySaveAsMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
                  return;
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.FilterIndex = 1;
                saveFileDialog.RestoreDirectory = true;
                saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                  current.FamilyPath = saveFileDialog.FileName;
                else
                  return;
              }
              if (flag)
              {
                if (current.BinderFamily != null)
                {
                  EPTransactionContainer transactionContainer = new EPTransactionContainer(this.m_Document);
                  transactionContainer.Start(EPShared.LocalRM.GetString("UpdatingFamilyTransaction"));
                  transactionContainer.BeginTransaction();
                  this.m_Document.Delete(((Element) current.BinderFamily).Id);
                  transactionContainer.EndTransaction();
                  transactionContainer.Commit();
                }
                if (current.FamilyPath != string.Empty)
                {
                  current.FamilyDocument.SaveAs(current.FamilyPath, new SaveAsOptions()
                  {
                    OverwriteExistingFile = true
                  });
                  this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadFamilyToolTip") + current.FamilyPath);
                  RevitUtility.LoadFamily(this.m_Document, current.FamilyPath, true, ref this.m_TransactionContainer);
                  this.m_TransactionContainer.Commit();
                }
              }
            }
            else if (!current.Loaded && current.FamilyPath != string.Empty)
            {
              this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadFamilyToolTip") + current.FamilyPath);
              this.m_TransactionContainer.BeginTransaction();
              RevitUtility.LoadFamily(this.m_Document, current.FamilyPath, true, ref this.m_TransactionContainer);
              this.m_TransactionContainer.EndTransaction();
              this.m_TransactionContainer.Commit();
            }
          }
          break;
        }
    }
    this.CloseDocuments();
    this.DialogResult = DialogResult.OK;
  }

  private void OnRowSelected(object sender, EventArgs e) => this.Modify();

  private void OnListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nMixtListViewSortColumn)
    {
      this.m_nMixtListViewSortColumn = e.Column;
      this.m_FamilyManagerListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_FamilyManagerListView.Sorting = this.m_FamilyManagerListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_FamilyManagerListView.Sort();
    this.m_FamilyManagerListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_FamilyManagerListView.Sorting);
  }

  private void CloseDocuments()
  {
    foreach (Document document in this.m_Document.Application.Documents)
    {
      bool flag = false;
      foreach (string openedFile in this.m_OpenedFileList)
      {
        if (RevitUtility.CompareFileNames(openedFile, document.PathName) == 0)
        {
          flag = true;
          break;
        }
      }
      if (!flag)
        document.Close(false);
    }
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  private void OnCopyButtonClicked(object sender, EventArgs e)
  {
    int _nSelectedIndex = -1;
    List<FamilyBinder> familyBinderList = new List<FamilyBinder>();
    this.FindSelectedFamilyIndex(ref _nSelectedIndex);
    if (_nSelectedIndex < 0)
      return;
    FamilyBinder family = this.m_FamilyList[_nSelectedIndex];
    CopyFamilyForm copyFamilyForm = new CopyFamilyForm(family, this.m_Document, this.m_CurrentFamilyType);
    if (copyFamilyForm.ShowDialog() != DialogResult.OK)
      return;
    FamilyBinder familyBinder = new FamilyBinder();
    Document _FamilyDocument = (Document) null;
    string newPath = copyFamilyForm.NewPath;
    if (newPath != string.Empty)
    {
      familyBinder.FamilyName = Path.GetFileNameWithoutExtension(newPath);
      familyBinder.FamilyPath = newPath;
      familyBinder.IsModified = true;
    }
    if (!familyBinder.IsModified)
      return;
    List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
    List<FamilyTypeContainer> familyTypeList = family.FamilyTypeList;
    if (ManageFamily.CreateNewFamilyDocument(this.m_Document, familyBinder.FamilyTypeList, this.m_CurrentFamilyType, familyBinder.FamilyPath, ref _FamilyDocument))
    {
      familyBinder.FamilyDocument = _FamilyDocument;
      if (_FamilyDocument != null)
      {
        if (familyBinder.FamilyTypeList == null)
          familyBinder.FamilyTypeList = new List<FamilyTypeContainer>();
        if (familyTypeList != null)
        {
          foreach (FamilyTypeContainer familyTypeContainer in familyTypeList)
            familyBinder.FamilyTypeList.Add(familyTypeContainer);
        }
      }
      this.m_FamilyList.Add(familyBinder);
      this.UpdateListView();
      if (this.m_FamilyManagerListView.Items.Count <= 0)
        return;
      this.m_FamilyManagerListView.Items[this.m_FamilyManagerListView.Items.Count - 1].Selected = true;
      this.Modify();
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("UnableCreateFamilyString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void OnLoadButtonClicked(object sender, EventArgs e)
  {
    OpenFileDialog openFileDialog = new OpenFileDialog();
    openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    openFileDialog.FilterIndex = 1;
    openFileDialog.RestoreDirectory = true;
    openFileDialog.Multiselect = false;
    DialogResult _CurrentResult = openFileDialog.ShowDialog();
    if (_CurrentResult == DialogResult.OK)
      this.LoadFamily(openFileDialog.FileName);
    this.CheckForDuplicates(_CurrentResult);
  }

  private void LoadFamily(string _strFilePath)
  {
    FamilyBinder _Binder = new FamilyBinder();
    Document _FamilyDocument = (Document) null;
    string str1 = _strFilePath;
    string str2 = str1.Substring(str1.LastIndexOf("\\") + 1);
    string str3 = str2.Substring(0, str2.LastIndexOf('.'));
    _Binder.FamilyName = str3;
    _Binder.FamilyPath = _strFilePath;
    _Binder.IsModified = true;
    if (!_Binder.IsModified)
      return;
    int index = this.CheckForDuplicates(_Binder);
    if (index >= 0)
    {
      if (RevitMessageBox.Show($"{EPShared.LocalRM.GetString("DuplicateFamilyInFamilyManagerMessage")} {EPShared.LocalRM.GetString("OverwriteMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxButtons.YesNo, MessageBoxIcon.Hand) != DialogResult.Yes)
        return;
      this.m_FamilyList.RemoveAt(index);
    }
    if (ManageFamily.CreateNewFamilyDocument(this.m_Document, _Binder.FamilyTypeList, this.m_CurrentFamilyType, _Binder.FamilyPath, ref _FamilyDocument))
    {
      _Binder.IsModified = true;
      _Binder.FamilyDocument = _FamilyDocument;
      if (_FamilyDocument != null)
        _Binder.FamilyTypeList = this.PopulateFamilyTypeSetList(_FamilyDocument, _Binder.FamilyName);
      this.m_FamilyList.Add(_Binder);
      this.UpdateListView();
      if (this.m_FamilyManagerListView.Items.Count <= 0)
        return;
      this.m_FamilyManagerListView.Items[this.m_FamilyManagerListView.Items.Count - 1].Selected = true;
      this.Modify();
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("UnableCreateFamilyString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void OnFamilyManagerFormKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Escape)
      return;
    this.OnCloseButtonClicked((object) null, (EventArgs) null);
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_FamilyManagerGrpBox = new GroupBox();
    this.m_LoadButton = new Button();
    this.m_CopyButton = new Button();
    this.m_ModifyButton = new Button();
    this.m_AddButton = new Button();
    this.m_FamilyManagerListView = new ListView();
    this.m_CloseButton = new Button();
    this.m_SaveButton = new Button();
    this.m_FamilyManagerLbl = new Label();
    this.m_FamilyManagerGrpBox.SuspendLayout();
    this.SuspendLayout();
    this.m_FamilyManagerGrpBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_FamilyManagerGrpBox.Controls.Add((Control) this.m_LoadButton);
    this.m_FamilyManagerGrpBox.Controls.Add((Control) this.m_CopyButton);
    this.m_FamilyManagerGrpBox.Controls.Add((Control) this.m_ModifyButton);
    this.m_FamilyManagerGrpBox.Controls.Add((Control) this.m_AddButton);
    this.m_FamilyManagerGrpBox.Controls.Add((Control) this.m_FamilyManagerListView);
    this.m_FamilyManagerGrpBox.Location = new Point(12, 43);
    this.m_FamilyManagerGrpBox.Name = "m_FamilyManagerGrpBox";
    this.m_FamilyManagerGrpBox.Size = new Size(500, 289);
    this.m_FamilyManagerGrpBox.TabIndex = 1;
    this.m_FamilyManagerGrpBox.TabStop = false;
    this.m_FamilyManagerGrpBox.Text = "Family Manager";
    this.m_LoadButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_LoadButton.Location = new Point(419, 106);
    this.m_LoadButton.Name = "m_LoadButton";
    this.m_LoadButton.Size = new Size(75, 23);
    this.m_LoadButton.TabIndex = 4;
    this.m_LoadButton.Text = "Load";
    this.m_LoadButton.UseVisualStyleBackColor = true;
    this.m_LoadButton.Click += new EventHandler(this.OnLoadButtonClicked);
    this.m_CopyButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_CopyButton.Location = new Point(419, 77);
    this.m_CopyButton.Name = "m_CopyButton";
    this.m_CopyButton.Size = new Size(75, 23);
    this.m_CopyButton.TabIndex = 3;
    this.m_CopyButton.Text = "Copy";
    this.m_CopyButton.UseVisualStyleBackColor = true;
    this.m_CopyButton.Click += new EventHandler(this.OnCopyButtonClicked);
    this.m_ModifyButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ModifyButton.Location = new Point(419, 48 /*0x30*/);
    this.m_ModifyButton.Name = "m_ModifyButton";
    this.m_ModifyButton.Size = new Size(75, 23);
    this.m_ModifyButton.TabIndex = 2;
    this.m_ModifyButton.Text = "Modify";
    this.m_ModifyButton.UseVisualStyleBackColor = true;
    this.m_ModifyButton.Click += new EventHandler(this.OnFamilyManagerModifyClicked);
    this.m_AddButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_AddButton.Location = new Point(419, 19);
    this.m_AddButton.Name = "m_AddButton";
    this.m_AddButton.Size = new Size(75, 23);
    this.m_AddButton.TabIndex = 1;
    this.m_AddButton.Text = "Add";
    this.m_AddButton.UseVisualStyleBackColor = true;
    this.m_AddButton.Click += new EventHandler(this.OnFamilyManagerAddClicked);
    this.m_FamilyManagerListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_FamilyManagerListView.FullRowSelect = true;
    this.m_FamilyManagerListView.Location = new Point(6, 19);
    this.m_FamilyManagerListView.MultiSelect = false;
    this.m_FamilyManagerListView.Name = "m_FamilyManagerListView";
    this.m_FamilyManagerListView.Size = new Size(407, 264);
    this.m_FamilyManagerListView.TabIndex = 0;
    this.m_FamilyManagerListView.UseCompatibleStateImageBehavior = false;
    this.m_FamilyManagerListView.ColumnClick += new ColumnClickEventHandler(this.OnListViewColumnClick);
    this.m_FamilyManagerListView.DoubleClick += new EventHandler(this.OnRowSelected);
    this.m_CloseButton.Location = new Point(435, 338);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(75, 23);
    this.m_CloseButton.TabIndex = 3;
    this.m_CloseButton.Text = "Close";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClicked);
    this.m_SaveButton.Location = new Point(354, 338);
    this.m_SaveButton.Name = "m_SaveButton";
    this.m_SaveButton.Size = new Size(75, 23);
    this.m_SaveButton.TabIndex = 2;
    this.m_SaveButton.Text = "Save";
    this.m_SaveButton.UseVisualStyleBackColor = true;
    this.m_SaveButton.Click += new EventHandler(this.OnSaveButtonClicked);
    this.m_FamilyManagerLbl.AutoSize = true;
    this.m_FamilyManagerLbl.Location = new Point(18, 13);
    this.m_FamilyManagerLbl.Name = "m_FamilyManagerLbl";
    this.m_FamilyManagerLbl.Size = new Size(35, 13);
    this.m_FamilyManagerLbl.TabIndex = 0;
    this.m_FamilyManagerLbl.Text = "label1";
    this.AcceptButton = (IButtonControl) this.m_SaveButton;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(524, 373);
    this.Controls.Add((Control) this.m_FamilyManagerLbl);
    this.Controls.Add((Control) this.m_SaveButton);
    this.Controls.Add((Control) this.m_CloseButton);
    this.Controls.Add((Control) this.m_FamilyManagerGrpBox);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(530, 337);
    this.Name = nameof (FamilyManagerForm);
    this.Text = "FamilyManager";
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.KeyDown += new KeyEventHandler(this.OnFamilyManagerFormKeyDown);
    this.m_FamilyManagerGrpBox.ResumeLayout(false);
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
