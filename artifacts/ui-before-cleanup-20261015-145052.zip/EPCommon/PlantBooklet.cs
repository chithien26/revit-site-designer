using System.Collections.Generic;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;

namespace EPCommon;

public class PlantBooklet
{
	private Autodesk.Revit.ApplicationServices.Application m_CurApplication;

	private Document m_Document;

	private PlantBookletForm m_DisplayForm;

	private List<FamilySymbol> m_ExistingPlantSymbolList;

	private ElementSet m_InstanceSet = new ElementSet();

	private EPTransactionContainer m_TransactionContainer;

	public Document Document => m_Document;

	public List<FamilySymbol> ExistingPlantSymbolList
	{
		get
		{
			return m_ExistingPlantSymbolList;
		}
		set
		{
			m_ExistingPlantSymbolList = value;
		}
	}

	public ElementSet InstanceSet => m_InstanceSet;

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public PlantBooklet(Document _CurDocument)
	{
		m_CurApplication = _CurDocument.Application;
		m_ExistingPlantSymbolList = new List<FamilySymbol>();
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		InitializeListData();
	}

	private void InitializeListData()
	{
		PopulateExistingPlantList();
	}

	private void PopulateExistingPlantList()
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		foreach (Element item in list)
		{
			if (item is FamilyInstance { Symbol: not null } familyInstance && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode())
			{
				UpdateFamilySymbolContainerList(familyInstance.Symbol);
			}
		}
	}

	private void UpdateFamilySymbolContainerList(FamilySymbol _SelectedSymbol)
	{
		FamilySymbolContainer familySymbolContainer = null;
		familySymbolContainer = new FamilySymbolContainer();
		for (int i = 0; i < m_ExistingPlantSymbolList.Count; i++)
		{
			if (string.Compare(m_ExistingPlantSymbolList[i].Name, _SelectedSymbol.Name, ignoreCase: true) == 0)
			{
				return;
			}
		}
		m_ExistingPlantSymbolList.Add(_SelectedSymbol);
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		bool result = false;
		if (m_ExistingPlantSymbolList.Count <= 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantBookletNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			return false;
		}
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new PlantBookletForm(this))
		{
			while (_DialogResult != DialogResult.Cancel)
			{
				result = ShowDialog(ref _DialogResult);
			}
			return result;
		}
	}

	private bool GetSinglePoint(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, _bDisplayError: true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
				else
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				}
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		return true;
	}

	private bool GetWindowPoints(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, _bDisplayError: true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
			}
		}
		return true;
	}

	private bool GetAllPointsWithType(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		if (list == null || list.Count == 0)
		{
			return false;
		}
		foreach (Element item in list)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
			}
		}
		return true;
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		bool result = false;
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult == DialogResult.Cancel)
		{
			result = false;
		}
		else if (_DialogResult == DialogResult.Retry)
		{
			ElementSet _InstanceSet = new ElementSet();
			List<Eps_Point> _PointList = new List<Eps_Point>();
			if (m_DisplayForm.SelectionSetChecked)
			{
				if (!GetSinglePoint(ref _InstanceSet, ref _PointList))
				{
					return false;
				}
			}
			else if (m_DisplayForm.WindowSelectChecked)
			{
				if (!GetWindowPoints(ref _InstanceSet, ref _PointList))
				{
					return false;
				}
			}
			else if (m_DisplayForm.AllInstancesChecked && !GetAllPointsWithType(ref _InstanceSet, ref _PointList))
			{
				return false;
			}
			m_InstanceSet = _InstanceSet;
			result = true;
			m_DisplayForm.UpdateListView();
		}
		return result;
	}
}
