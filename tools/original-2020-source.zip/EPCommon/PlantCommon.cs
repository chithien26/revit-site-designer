﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantCommon
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantCommon
{
  public static bool PickPlantToTag(
    Document _Document,
    ElementSet _FamilyList,
    ref Eps_Point _PickPoint,
    ref FamilyInstance _FoundFamily)
  {
    if (_FamilyList.Size == 1)
    {
      IEnumerator enumerator = _FamilyList.GetEnumerator();
      try
      {
        if (enumerator.MoveNext())
        {
          Element current = (Element) enumerator.Current;
          _FoundFamily = current as FamilyInstance;
          return true;
        }
      }
      finally
      {
        if (enumerator is IDisposable disposable)
          disposable.Dispose();
      }
    }
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(_Document, EPShared.LocalRM.GetString("PickPlantTagMessage"), ref _Elements, true))
      return false;
    foreach (Element element in _Elements)
    {
      if (element is FamilyInstance && element.Location is LocationPoint location1)
      {
        foreach (Element family in _FamilyList)
        {
          if (family is FamilyInstance familyInstance && ((Element) familyInstance).Location is LocationPoint location && EPShared.eplGeoE_ArePntsDuplicates2D(new Eps_Point(location1.Point), new Eps_Point(location.Point), 1E-05))
          {
            _PickPoint = new Eps_Point(location1.Point);
            _FoundFamily = familyInstance;
            return true;
          }
        }
      }
    }
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectPickedPlantMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    _Document.Regenerate();
    return PlantCommon.PickPlantToTag(_Document, _FamilyList, ref _PickPoint, ref _FoundFamily);
  }

  public static void CreateTag(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    View _View,
    ElementSet _FamilyList,
    double _dTagSpacing,
    bool _bPlaceGroupTagChecked,
    bool _bLeaderedTagChecked,
    bool _bCreateTag)
  {
    if (!_bPlaceGroupTagChecked || _FamilyList.IsEmpty)
      return;
    if (_bCreateTag)
    {
      FilteredElementIterator elementIterator = new FilteredElementCollector(_Document).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2005021).GetElementIterator();
      bool flag1 = false;
      elementIterator.Reset();
      BuiltInCategory builtInCategory;
      while (elementIterator.MoveNext())
      {
        if (elementIterator.Current is FamilySymbol current && ((Element) current).Category != null)
        {
          int integerValue = ((Element) current).Category.Id.IntegerValue;
          builtInCategory = (BuiltInCategory) -2005021;
          int hashCode = builtInCategory.GetHashCode();
          if (integerValue == hashCode)
          {
            flag1 = true;
            break;
          }
        }
      }
      if (!flag1)
      {
        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
          openFileDialog.Title = EPShared.LocalRM.GetString("NoTag");
          openFileDialog.RestoreDirectory = true;
          openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
          Family _Family = (Family) null;
          bool flag2 = false;
          DialogResult dialogResult = DialogResult.OK;
          while (dialogResult != DialogResult.Cancel)
          {
            dialogResult = openFileDialog.ShowDialog();
            if (dialogResult != DialogResult.Cancel)
            {
              try
              {
                flag2 = RevitUtility.LoadFamily(_Document, openFileDialog.FileName, out _Family, true, ref _TransactionContainer);
                if (_Family != null && ((Element) _Family).Category != null)
                {
                  int integerValue = ((Element) _Family).Category.Id.IntegerValue;
                  builtInCategory = (BuiltInCategory) -2005021;
                  int hashCode = builtInCategory.GetHashCode();
                  if (integerValue == hashCode)
                    break;
                }
                int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotPlantingTagMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
                break;
              }
              catch (SEHException ex)
              {
                flag2 = false;
                if (string.Compare(ex.Message, EPShared.LocalRM.GetString("ExternalComponentExceptionMessage"), true) == 0)
                {
                  int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("LoadingFamilyProblemLoadNewMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
                }
              }
            }
          }
          if (!flag2)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantPlaceTagNotPlacedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
        }
      }
      _Document.Regenerate();
      FamilyInstance _FoundFamily = (FamilyInstance) null;
      Eps_Point _PickPoint = new Eps_Point();
      if (!PlantCommon.PickPlantToTag(_Document, _FamilyList, ref _PickPoint, ref _FoundFamily))
        return;
      _TransactionContainer.BeginTransaction();
      if (_FoundFamily != null)
      {
        ((Element) _FoundFamily).LookupParameter(RevitParameters.PlantCountPlantFamilyParameter)?.Set(_FamilyList.Size);
        Eps_Point _StartPnt = (Eps_Point) null;
        Eps_Point _NewPnt1 = (Eps_Point) null;
        Eps_Point _NewPnt2 = (Eps_Point) null;
        Eps_Point _Point = new Eps_Point();
        ElementSet elementSet = new ElementSet();
        ModelCurve modelCurve = (ModelCurve) null;
        string empty = string.Empty;
        string _strPrompt = !_bLeaderedTagChecked ? EPShared.LocalRM.GetString("PickTagPointPrompt") : EPShared.LocalRM.GetString("PickLeaderStartPointPrompt");
        bool flag3 = true;
        while (flag3)
        {
          flag3 = RevitUtility.GetPointFromProject(_Document, _strPrompt, ref _Point, false);
          if (flag3)
          {
            if (_bLeaderedTagChecked && _StartPnt == null)
            {
              _StartPnt = _Point;
              _strPrompt = EPShared.LocalRM.GetString("PickLeaderElbowPointPrompt");
            }
            else if (_bLeaderedTagChecked && _NewPnt1 == null)
            {
              _NewPnt1 = _Point;
              Eps_Line _Line = new Eps_Line();
              _Line.StartPnt = _StartPnt;
              _Line.EndPnt = _NewPnt1;
              modelCurve = RevitUtility.NewModelCurve(_Document, _Line);
              _strPrompt = EPShared.LocalRM.GetString("PickTagPointPrompt");
            }
            else if (_NewPnt2 == null)
            {
              _NewPnt2 = _Point;
              flag3 = false;
            }
          }
        }
        if (modelCurve != null)
          _Document.Delete(((Element) modelCurve).Id);
        if (_bLeaderedTagChecked && _StartPnt == null || !_bLeaderedTagChecked && _NewPnt2 == null)
        {
          _StartPnt = _PickPoint;
          _NewPnt1 = new Eps_Point();
          _NewPnt2 = new Eps_Point();
          EPShared.eplGeoE_CalcPolarToXY(_StartPnt, 3.0 * Math.PI / 4.0, _dTagSpacing, ref _NewPnt1);
          EPShared.eplGeoE_CalcPolarToXY(_NewPnt1, Math.PI, _dTagSpacing, ref _NewPnt2);
        }
        IndependentTag independentTag1 = (IndependentTag) null;
        if (_bLeaderedTagChecked)
        {
          if (_NewPnt1 == null)
          {
            _NewPnt1 = _StartPnt;
            _NewPnt2 = _StartPnt;
          }
          else if (_NewPnt2 == null)
            _NewPnt2 = _NewPnt1;
          IndependentTag independentTag2 = IndependentTag.Create(_Document, ((Element) _View).Id, new Reference((Element) _FoundFamily), true, (TagMode) 0, (TagOrientation) 0, _PickPoint.XYZ);
          independentTag2.LeaderEndCondition = (LeaderEndCondition) 1;
          independentTag2.LeaderEnd = _StartPnt.XYZ;
          independentTag2.LeaderElbow = _NewPnt1.XYZ;
          independentTag2.TagHeadPosition = _NewPnt2.XYZ;
        }
        else
          independentTag1 = IndependentTag.Create(_Document, ((Element) _View).Id, new Reference((Element) _FoundFamily), false, (TagMode) 0, (TagOrientation) 0, _NewPnt2.XYZ);
      }
      ((ItemFactoryBase) _Document.Create).NewGroup((ICollection<ElementId>) ElementSetConverter.ToIDList(_FamilyList));
      _TransactionContainer.EndTransaction();
    }
    else
      ((ItemFactoryBase) _Document.Create).NewGroup((ICollection<ElementId>) ElementSetConverter.ToIDList(_FamilyList));
  }

  public static bool PlaceLegList(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _CurrentLeg)
  {
    if (_PlantPlacementSettings.PlacementType == PlacementType.Single)
      PlantCommon.PlaceSingleOnLeg(_Document, _PlantPlacementSettings, _CurrentLeg);
    else if (_PlantPlacementSettings.PlacementType == PlacementType.GroveSquare || _PlantPlacementSettings.PlacementType == PlacementType.GroveTrianglular)
    {
      if (!EPShared.eplGeoE_ArePntsDuplicates2D(_CurrentLeg.LegStartPnt, _CurrentLeg.LegEndPnt, 1E-05))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("BoundaryClosedChainMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
      List<Eps_Leg> _IslandList = new List<Eps_Leg>();
      PlantCommon.PickIslandLegs(_Document, ref _IslandList);
      PlantCommon.PlaceHedgeGrove(_Document, _PlantPlacementSettings, _CurrentLeg, _IslandList);
      if (_PlantPlacementSettings.DeleteExistingChecked)
      {
        _PlantPlacementSettings.TransactionContainer.BeginTransaction();
        for (int index = 0; index < _IslandList.Count; ++index)
        {
          if (_IslandList[index].ElementSet != null && _IslandList[index].ElementSet.Size > 0)
            _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_IslandList[index].ElementSet));
        }
        _PlantPlacementSettings.TransactionContainer.EndTransaction();
      }
    }
    else if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowCenter || _PlantPlacementSettings.PlacementType == PlacementType.HedgeRowAlternate || _PlantPlacementSettings.PlacementType == PlacementType.HedgeRowSide)
    {
      if (_PlantPlacementSettings.ExistingElementChecked && !RevitUtility.EvaluateLeg(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.PlantSpacing, ref _CurrentLeg))
        return false;
      _PlantPlacementSettings.IsReverse = _CurrentLeg.IsReverse;
      if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowCenter)
        PlantCommon.PlaceCenterRowOnLeg(_Document, _PlantPlacementSettings, _CurrentLeg);
      else if (_PlantPlacementSettings.PlacementType == PlacementType.HedgeRowAlternate)
      {
        PlantCommon.PlaceAltRowOnLeg(_Document, _PlantPlacementSettings, _CurrentLeg);
      }
      else
      {
        Eps_Leg ppOffsetLegList1 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, _PlantPlacementSettings.SetbackSpacing, 1, ref ppOffsetLegList1, true);
        Eps_Leg ppOffsetLegList2 = new Eps_Leg();
        RevitGeometry.OffsetLegList(_CurrentLeg, _PlantPlacementSettings.SetbackSpacing, 2, ref ppOffsetLegList2, true);
        _PlantPlacementSettings.TransactionContainer.BeginTransaction();
        ModelCurveArray modelCurveArray1 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList1);
        ModelCurveArray modelCurveArray2 = RevitUtility.NewModelCurveArray(_Document, ppOffsetLegList2);
        _PlantPlacementSettings.TransactionContainer.EndTransaction();
        _Document.Regenerate();
        bool _UseRightSide = true;
        bool flag = RevitUtility.PickSideLeg(_Document, _CurrentLeg, ref _UseRightSide);
        ElementSet elm_set = new ElementSet();
        foreach (ModelCurve modelCurve in modelCurveArray1)
          elm_set.Insert((Element) modelCurve);
        foreach (ModelCurve modelCurve in modelCurveArray2)
          elm_set.Insert((Element) modelCurve);
        _PlantPlacementSettings.TransactionContainer.BeginTransaction();
        _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(elm_set));
        _PlantPlacementSettings.TransactionContainer.EndTransaction();
        if (!flag)
          return false;
        _PlantPlacementSettings.UseRightSide = _UseRightSide;
        if (_UseRightSide)
          PlantCommon.PlaceCenterRowOnLeg(_Document, _PlantPlacementSettings, ppOffsetLegList1, _CurrentLeg.ElementList);
        else
          PlantCommon.PlaceCenterRowOnLeg(_Document, _PlantPlacementSettings, ppOffsetLegList2, _CurrentLeg.ElementList);
      }
    }
    if (_PlantPlacementSettings.DeleteExistingChecked && _CurrentLeg.ElementSet != null && _CurrentLeg.ElementSet.Size > 0)
    {
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
      _Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_CurrentLeg.ElementSet));
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    }
    return true;
  }

  public static void PickIslandLegs(Document _Document, ref List<Eps_Leg> _IslandList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(_Document, EPShared.LocalRM.GetString("PickIslandsMessage"), ref _Elements, false, PickMethod.PickObjects))
      return;
    bool flag1 = false;
    bool flag2 = false;
    foreach (Element _LocationElement in _Elements)
    {
      if (_LocationElement.Location is LocationCurve location && GeometryObject.op_Inequality((GeometryObject) location.Curve, (GeometryObject) null))
      {
        flag2 = true;
        Eps_Leg legFromElementList = RevitGeometry.GetLegFromElementList((Eps_Leg) null, _LocationElement);
        if (legFromElementList != null)
        {
          if (EPShared.eplGeoE_ArePntsDuplicates2D(legFromElementList.LegStartPnt, legFromElementList.LegEndPnt, 1E-05))
            _IslandList.Add(legFromElementList);
        }
        else
        {
          Curve curve = location.Curve;
          if (!curve.IsBound)
          {
            switch (curve)
            {
              case Arc _:
                Arc _Arc = (Arc) curve;
                _IslandList.Add(new Eps_Leg()
                {
                  Arc = new Eps_Arc(_Arc)
                });
                continue;
              case Ellipse _:
              case NurbSpline _:
              case HermiteSpline _:
                IList<XYZ> xyzList = curve.Tessellate();
                int count = xyzList.Count;
                if (count > 1)
                {
                  Eps_Point epsPoint1 = new Eps_Point();
                  Eps_Point epsPoint2 = new Eps_Point();
                  Eps_Leg epsLeg1 = (Eps_Leg) null;
                  int index;
                  for (index = 0; index < count; index += 2)
                  {
                    Eps_Point epsPoint3 = new Eps_Point(xyzList[index]);
                    if (index > 0)
                    {
                      Eps_Leg epsLeg2 = new Eps_Leg();
                      epsLeg2.Line = new Eps_Line();
                      epsLeg2.Line.StartPnt = epsPoint1;
                      epsLeg2.Line.EndPnt = epsPoint3;
                      if (epsLeg1 == null)
                      {
                        epsLeg1 = epsLeg2;
                        epsLeg1.Element = _LocationElement;
                      }
                      else
                      {
                        epsLeg1.Last.Next = epsLeg2;
                        epsLeg1.Last.Element = _LocationElement;
                      }
                    }
                    epsPoint1 = epsPoint3;
                  }
                  if (index == count)
                  {
                    Eps_Leg epsLeg3 = new Eps_Leg();
                    epsLeg3.Line = new Eps_Line();
                    epsLeg3.Line.StartPnt = epsPoint1;
                    epsLeg3.Line.EndPnt = new Eps_Point(xyzList[count - 1]);
                    if (epsLeg1 == null)
                    {
                      epsLeg1 = epsLeg3;
                      epsLeg1.Element = _LocationElement;
                    }
                    else
                    {
                      epsLeg1.Last.Next = epsLeg3;
                      epsLeg1.Last.Element = _LocationElement;
                    }
                  }
                  _IslandList.Add(epsLeg1);
                  continue;
                }
                continue;
              default:
                continue;
            }
          }
          else if (!flag1 && curve is Ellipse)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IslandEclipsePickMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            flag1 = true;
          }
        }
      }
    }
    if (!flag2 || _IslandList != null && _IslandList.Count != 0)
      return;
    if (!flag1)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IslandClosedChainMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    PlantCommon.PickIslandLegs(_Document, ref _IslandList);
  }

  public static void PlaceHedgeGrove(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _BoundaryLeg,
    List<Eps_Leg> _IslandList)
  {
    PlantCommon.PlaceHedgeGrove(_Document, _PlantPlacementSettings, _BoundaryLeg, _IslandList, (List<FamilyInstance>) null);
  }

  public static void PlaceHedgeGrove(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _BoundaryLeg,
    List<Eps_Leg> _IslandList,
    List<FamilyInstance> _ExistingPlantList)
  {
    List<Eps_Leg> _IslandList1 = new List<Eps_Leg>();
    for (int index = 0; index < _IslandList.Count; ++index)
      _IslandList1.Add(Eps_Leg.CopyLeg(_IslandList[index]));
    PlantCommon.OffsetBoundaries(_PlantPlacementSettings.SetbackSpacing, ref _BoundaryLeg, ref _IslandList1);
    if (_BoundaryLeg == null)
      return;
    PlantCommon.DrawOrderedGrove(_Document, _PlantPlacementSettings, _BoundaryLeg, _IslandList1, _ExistingPlantList);
  }

  private static void OffsetBoundaries(
    double dSetbackSpacing,
    ref Eps_Leg _BoundaryLeg,
    ref List<Eps_Leg> _IslandList)
  {
    double num = dSetbackSpacing;
    int OffsetDir1 = 1;
    Eps_Leg ppOffsetLegList = new Eps_Leg();
    if (!RevitDefines.GT(num, 0.0))
      return;
    int Direction = 0;
    if (_BoundaryLeg != null)
    {
      RevitGeometry.eplGeoE_CalcLegDirection(_BoundaryLeg, ref Direction, 1E-05);
      if (Direction == 1)
        OffsetDir1 = 2;
      RevitGeometry.OffsetLegList(_BoundaryLeg, num, OffsetDir1, ref ppOffsetLegList, true);
      _BoundaryLeg = ppOffsetLegList;
    }
    if (_IslandList == null)
      return;
    for (int index = 0; index < _IslandList.Count; ++index)
    {
      RevitGeometry.eplGeoE_CalcLegDirection(_IslandList[index], ref Direction, 1E-05);
      int OffsetDir2 = Direction != 1 ? 2 : 1;
      RevitGeometry.OffsetLegList(_IslandList[index], num, OffsetDir2, ref ppOffsetLegList, true);
      _IslandList[index] = ppOffsetLegList;
    }
  }

  private static void DrawOrderedGrove(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _BoundaryLeg,
    List<Eps_Leg> _IslandList,
    List<FamilyInstance> _ExistingPlantList)
  {
    if (_BoundaryLeg == null)
      return;
    List<Eps_Point> epsPointList = new List<Eps_Point>();
    Eps_Point pMinPnt = new Eps_Point();
    Eps_Point pMaxPnt = new Eps_Point();
    RevitGeometry.eplGeoE_FindMinMaxOfLegList(_BoundaryLeg, ref pMinPnt, ref pMaxPnt);
    bool _bSpacingType = false;
    if (_PlantPlacementSettings.PlacementType == PlacementType.GroveTrianglular)
      _bSpacingType = true;
    RevitGeometry.CreatePointListFromMinMaxOfArea(ref epsPointList, pMinPnt, pMaxPnt, _PlantPlacementSettings.RotationAngle, _PlantPlacementSettings.PlantSpacing, _bSpacingType);
    RevitGeometry.GetAllPointsInBoundary(ref epsPointList, _BoundaryLeg, _IslandList);
    ElementSet _FamilyList = new ElementSet();
    bool flag1 = true;
    bool flag2 = true;
    bool flag3 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag4 = false;
    bool flag5 = false;
    int index1 = 0;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = epsPointList.Count;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag5 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlantPlacementSettings.GenericModelIDList;
    }
    for (int index2 = 0; index2 < epsPointList.Count; ++index2)
    {
      KeyValuePair<string, string> keyValuePair;
      if (_BoundaryLeg.Element != null && flag3 && !flag4)
      {
        if (flag5)
        {
          flag5 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
          {
            Guid _ChainID1 = Guid.NewGuid();
            keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _BoundaryLeg.ElementList, string.Empty, _ChainID1);
            if (keyValuePairList.Count > 0)
            {
              for (int index3 = 0; index3 < _IslandList.Count; ++index3)
              {
                Document _Document1 = _Document;
                PlacementSettings _PlacementSettings = _PlantPlacementSettings;
                List<Element> elementList = _IslandList[index3].ElementList;
                keyValuePair = keyValuePairList[0];
                string _strBoundaryID = keyValuePair.Value;
                Guid _ChainID2 = _ChainID1;
                RevitUtility.CreatePlacementGenericModel(_Document1, _PlacementSettings, elementList, _strBoundaryID, _ChainID2);
              }
            }
          }
          else
          {
            int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag3 = false;
          }
        }
        if (index1 < keyValuePairList.Count)
        {
          keyValuePair = keyValuePairList[index1];
          if (string.Compare(keyValuePair.Key, _BoundaryLeg.Element.UniqueId, true) == 0)
          {
            flag4 = true;
          }
          else
          {
            for (int index4 = 0; index4 < keyValuePairList.Count; ++index4)
            {
              keyValuePair = keyValuePairList[index4];
              if (string.Compare(keyValuePair.Key, _BoundaryLeg.Element.UniqueId, true) == 0)
              {
                index1 = index4;
                flag4 = true;
                break;
              }
            }
          }
        }
      }
      Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPointList[index2], _PlantPlacementSettings.SurfaceList);
      FamilyInstance familyInstance;
      if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
      {
        familyInstance = _ExistingPlantList[0];
        if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPointList[index2], new Eps_Point(location.Point)))
        {
          XYZ xyz = new XYZ(epsPointList[index2].XYZ.X - location.Point.X, epsPointList[index2].XYZ.Y - location.Point.Y, 0.0);
          ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
        }
        _ExistingPlantList.RemoveAt(0);
      }
      else
      {
        EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
        familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPointList[index2].XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
        _PlantPlacementSettings.TransactionContainer = transactionContainer;
      }
      if (flag1)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
        if (parameter != null)
        {
          if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
          {
            double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
            double num = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
            parameter.Set(num);
          }
        }
        else
          flag1 = false;
      }
      if (flag2)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
        if (parameter != null)
        {
          if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
          {
            double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
            double num = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
            parameter.Set(num);
          }
        }
        else
          flag2 = false;
      }
      if (_BoundaryLeg.Element != null && flag3 && flag4)
      {
        Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
        if (parameter1 != null)
        {
          Parameter parameter2 = parameter1;
          keyValuePair = keyValuePairList[index1];
          string str = keyValuePair.Value;
          parameter2.Set(str);
        }
        else
          flag3 = false;
      }
      _FamilyList.Insert((Element) familyInstance);
      progressBarForm.UpdateProgressBar(1);
      flag4 = false;
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index5 = 0; index5 < _ExistingPlantList.Count; ++index5)
        _Document.Delete(((Element) _ExistingPlantList[index5]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_FamilyList.IsEmpty)
      return;
    bool _bCreateTag = false;
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _bCreateTag = true;
    PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
  }

  public static void PlaceSingleOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg)
  {
    PlantCommon.PlaceSingleOnLeg(_Document, _PlantPlacementSettings, _Leg, (FamilyInstance) null);
  }

  public static void PlaceSingleOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg,
    FamilyInstance _ExistingPlant)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    double _dDistance = 0.0;
    if (_Leg == null)
      return;
    ElementSet _FamilyList = new ElementSet();
    double num1 = 0.0;
    double _dX = 0.0;
    double num2 = RevitGeometry.eplGeoE_CalcLegListLength(_Leg);
    bool flag1 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag2 = false;
    bool flag3 = false;
    int index1 = 0;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(num2 / 2.0);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag3 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlantPlacementSettings.GenericModelIDList;
    }
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      bool flag4;
      bool flag5;
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
        _dX += _dDistance;
        if (RevitDefines.GE(_dX, num2 / 2.0))
        {
          if (epsLeg.Element != null && flag1 && !flag2)
          {
            if (flag3)
            {
              flag4 = false;
              if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
              {
                keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Leg.ElementList);
              }
              else
              {
                int num3 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                flag1 = false;
              }
            }
            if (index1 < keyValuePairList.Count)
            {
              if (string.Compare(keyValuePairList[index1].Key, epsLeg.Element.UniqueId, true) == 0)
              {
                flag2 = true;
              }
              else
              {
                for (int index2 = 0; index2 < keyValuePairList.Count; ++index2)
                {
                  if (string.Compare(keyValuePairList[index2].Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    index1 = index2;
                    flag2 = true;
                    break;
                  }
                }
              }
            }
          }
          EPShared.eplGeoE_FindStaOffPointAlongLine(epsLeg.Line, num2 / 2.0, 0.0, ref _StaOffPnt);
          Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_StaOffPnt, _PlantPlacementSettings.SurfaceList);
          FamilyInstance familyInstance;
          if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlant != null)
          {
            familyInstance = _ExistingPlant;
            if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(_StaOffPnt, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_StaOffPnt.XYZ.X - location.Point.X, _StaOffPnt.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
            }
          }
          else
          {
            EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
            familyInstance = RevitUtility.NewFamilyInstance(_Document, _StaOffPnt.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
            _PlantPlacementSettings.TransactionContainer = transactionContainer;
          }
          Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
          if (parameter1 != null && (!RevitDefines.EQ(parameter1.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0))
          {
            double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
            num1 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
          }
          Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
          if (parameter2 != null && (!RevitDefines.EQ(parameter2.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0))
          {
            double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
            double num4 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
            parameter2.Set(num4);
          }
          if (epsLeg.Element != null && flag1 && flag2)
          {
            Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
            if (parameter3 != null)
              parameter3.Set(keyValuePairList[index1].Value);
            else
              flag5 = false;
          }
          _FamilyList.Insert((Element) familyInstance);
          break;
        }
      }
      else if (epsLeg.Arc != null)
      {
        num2 = EPShared.eplGeoE_SolveArcLenByRadiusAndDelta(epsLeg.Arc.Radius, epsLeg.Arc.Delta);
        EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, num2 / 2.0, 0.0, ref _StaOffPnt);
        _dX += _dDistance;
        if (RevitDefines.GE(_dX, num2 / 2.0))
        {
          if (epsLeg.Element != null && flag1 && !flag2)
          {
            if (flag3)
            {
              flag4 = false;
              if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
              {
                keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Leg.ElementList);
              }
              else
              {
                int num5 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                flag1 = false;
              }
            }
            if (index1 < keyValuePairList.Count)
            {
              if (string.Compare(keyValuePairList[index1].Key, epsLeg.Element.UniqueId, true) == 0)
              {
                flag2 = true;
              }
              else
              {
                for (int index3 = 0; index3 < keyValuePairList.Count; ++index3)
                {
                  if (string.Compare(keyValuePairList[index3].Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    index1 = index3;
                    flag2 = true;
                    break;
                  }
                }
              }
            }
          }
          EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, num2 / 2.0, 0.0, ref _StaOffPnt);
          Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_StaOffPnt, _PlantPlacementSettings.SurfaceList);
          FamilyInstance familyInstance;
          if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlant != null)
          {
            familyInstance = _ExistingPlant;
            if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(_StaOffPnt, new Eps_Point(location.Point)))
            {
              XYZ xyz = new XYZ(_StaOffPnt.XYZ.X - location.Point.X, _StaOffPnt.XYZ.Y - location.Point.Y, 0.0);
              ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
            }
          }
          else
          {
            EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
            familyInstance = RevitUtility.NewFamilyInstance(_Document, _StaOffPnt.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
            _PlantPlacementSettings.TransactionContainer = transactionContainer;
          }
          Parameter parameter4 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
          if (parameter4 != null && (!RevitDefines.EQ(parameter4.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0))
          {
            double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
            double num6 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
            parameter4.Set(num6);
          }
          Parameter parameter5 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
          if (parameter5 != null && (!RevitDefines.EQ(parameter5.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0))
          {
            double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
            double num7 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
            parameter5.Set(num7);
          }
          if (epsLeg.Element != null && flag1 && flag2)
          {
            Parameter parameter6 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
            if (parameter6 != null)
              parameter6.Set(keyValuePairList[index1].Value);
            else
              flag5 = false;
          }
          _FamilyList.Insert((Element) familyInstance);
          break;
        }
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(_dDistance));
      flag2 = false;
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_FamilyList.IsEmpty)
      return;
    bool _bCreateTag = false;
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _bCreateTag = true;
    PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg)
  {
    PlantCommon.PlaceCenterRowOnLeg(_Document, _PlantPlacementSettings, _Leg, _Leg.ElementList, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg,
    List<Element> _OrigLegElementSet)
  {
    PlantCommon.PlaceCenterRowOnLeg(_Document, _PlantPlacementSettings, _Leg, _OrigLegElementSet, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg,
    List<FamilyInstance> _MovePlantList)
  {
    PlantCommon.PlaceCenterRowOnLeg(_Document, _PlantPlacementSettings, _Leg, _Leg.ElementList, _MovePlantList);
  }

  public static void PlaceCenterRowOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg,
    List<Element> _OrigLegElementSet,
    List<FamilyInstance> _ExistingPlantList)
  {
    Eps_Point epsPoint = new Eps_Point();
    double _dDistance = 0.0;
    double _dDirection = 0.0;
    double num1 = _PlantPlacementSettings.StartingDistance;
    double plantSpacing = _PlantPlacementSettings.PlantSpacing;
    if (_Leg == null)
      return;
    ElementSet _FamilyList = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = true;
    bool flag2 = true;
    bool flag3 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag4 = false;
    bool flag5 = false;
    int index1 = 0;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(RevitGeometry.eplGeoE_CalcLegListLength(_Leg) - num1);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag5 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlantPlacementSettings.GenericModelIDList;
    }
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      KeyValuePair<string, string> keyValuePair;
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDirection);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
        if (num1 > _dDistance)
        {
          num1 -= _dDistance;
        }
        else
        {
          double _dPolarDistance;
          for (_dPolarDistance = num1; _dPolarDistance <= _dDistance; _dPolarDistance += plantSpacing)
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, _dDirection, _dPolarDistance, ref epsPoint);
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag3 && !flag4)
              {
                if (flag5)
                {
                  flag5 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _OrigLegElementSet);
                  }
                  else
                  {
                    int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag3 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag4 = true;
                  }
                  else
                  {
                    for (int index2 = 0; index2 < keyValuePairList.Count; ++index2)
                    {
                      keyValuePair = keyValuePairList[index2];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index2;
                        flag4 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlantPlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
              {
                familyInstance = _ExistingPlantList[0];
                if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                {
                  XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                  ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                }
                _ExistingPlantList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlantPlacementSettings.TransactionContainer = transactionContainer;
              }
              if (flag1)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
                    double num3 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num3);
                  }
                }
                else
                  flag1 = false;
              }
              if (flag2)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
                    double num4 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num4);
                  }
                }
                else
                  flag2 = false;
              }
              if (epsLeg.Element != null && flag3 && flag4)
              {
                Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter1 != null)
                {
                  Parameter parameter2 = parameter1;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter2.Set(str);
                }
                else
                  flag3 = false;
              }
              _FamilyList.Insert((Element) familyInstance);
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
          }
          num1 = _dPolarDistance - _dDistance;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance = epsLeg.Arc.Radius * epsLeg.Arc.Delta;
        if (num1 > _dDistance)
        {
          num1 -= _dDistance;
        }
        else
        {
          double _dStation;
          for (_dStation = num1; _dStation <= _dDistance; _dStation += plantSpacing)
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dStation, 0.0, ref epsPoint);
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag3 && !flag4)
              {
                if (flag5)
                {
                  flag5 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _OrigLegElementSet);
                  }
                  else
                  {
                    int num5 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag3 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag4 = true;
                  }
                  else
                  {
                    for (int index3 = 0; index3 < keyValuePairList.Count; ++index3)
                    {
                      keyValuePair = keyValuePairList[index3];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index3;
                        flag4 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlantPlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
              {
                familyInstance = _ExistingPlantList[0];
                if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                {
                  XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                  ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                }
                _ExistingPlantList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlantPlacementSettings.TransactionContainer = transactionContainer;
              }
              if (flag1)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
                    double num6 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num6);
                  }
                }
                else
                  flag1 = false;
              }
              if (flag2)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
                    double num7 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num7);
                  }
                }
                else
                  flag2 = false;
              }
              if (epsLeg.Element != null && flag3 && flag4)
              {
                Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter3 != null)
                {
                  Parameter parameter4 = parameter3;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter4.Set(str);
                }
                else
                  flag3 = false;
              }
              _FamilyList.Insert((Element) familyInstance);
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
          }
          num1 = _dStation - _dDistance;
        }
      }
      flag4 = false;
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index4 = 0; index4 < _ExistingPlantList.Count; ++index4)
        _Document.Delete(((Element) _ExistingPlantList[index4]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_FamilyList.IsEmpty)
      return;
    bool _bCreateTag = false;
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _bCreateTag = true;
    PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
  }

  public static void PlaceAltRowOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg)
  {
    PlantCommon.PlaceAltRowOnLeg(_Document, _PlantPlacementSettings, _Leg, (List<FamilyInstance>) null);
  }

  public static void PlaceAltRowOnLeg(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Eps_Leg _Leg,
    List<FamilyInstance> _ExistingPlantList)
  {
    Eps_Point epsPoint = new Eps_Point();
    double _dDistance = 0.0;
    double _dPolarDirection = 0.0;
    double num1 = _PlantPlacementSettings.StartingDistance;
    double setbackSpacing = _PlantPlacementSettings.SetbackSpacing;
    double plantSpacing = _PlantPlacementSettings.PlantSpacing;
    bool flag1 = true;
    if (_Leg == null)
      return;
    ElementSet _FamilyList = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag2 = true;
    bool flag3 = true;
    bool flag4 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag5 = false;
    bool flag6 = false;
    int index1 = 0;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(RevitGeometry.eplGeoE_CalcLegListLength(_Leg) - num1);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag6 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePairList = _PlantPlacementSettings.GenericModelIDList;
    }
    for (Eps_Leg epsLeg = _Leg; epsLeg != null; epsLeg = epsLeg.Next)
    {
      KeyValuePair<string, string> keyValuePair;
      if (epsLeg.Line != null)
      {
        EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dPolarDirection);
        EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(epsLeg.Line.StartPnt, epsLeg.Line.EndPnt, ref _dDistance);
        if (num1 > _dDistance)
        {
          num1 -= _dDistance;
        }
        else
        {
          double _dPolarDistance;
          for (_dPolarDistance = num1; _dPolarDistance <= _dDistance; _dPolarDistance += plantSpacing / 2.0)
          {
            EPShared.eplGeoE_CalcPolarToXY(epsLeg.Line.StartPnt, _dPolarDirection, _dPolarDistance, ref epsPoint);
            if (flag1)
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), setbackSpacing, ref epsPoint);
            else
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), setbackSpacing, ref epsPoint);
            flag1 = !flag1;
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag4 && !flag5)
              {
                if (flag6)
                {
                  flag6 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Leg.ElementList);
                  }
                  else
                  {
                    int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag4 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag5 = true;
                  }
                  else
                  {
                    for (int index2 = 0; index2 < keyValuePairList.Count; ++index2)
                    {
                      keyValuePair = keyValuePairList[index2];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index2;
                        flag5 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlantPlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
              {
                familyInstance = _ExistingPlantList[0];
                if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                {
                  XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                  ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                }
                _ExistingPlantList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlantPlacementSettings.TransactionContainer = transactionContainer;
              }
              if (flag2)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
                    double num3 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num3);
                  }
                }
                else
                  flag2 = false;
              }
              if (flag3)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
                    double num4 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num4);
                  }
                }
                else
                  flag3 = false;
              }
              if (epsLeg.Element != null && flag4 && flag5)
              {
                Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter1 != null)
                {
                  Parameter parameter2 = parameter1;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter2.Set(str);
                }
                else
                  flag4 = false;
              }
              _FamilyList.Insert((Element) familyInstance);
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
          }
          num1 = _dPolarDistance - _dDistance;
        }
      }
      else if (epsLeg.Arc != null)
      {
        _dDistance = epsLeg.Arc.Radius * epsLeg.Arc.Delta;
        if (num1 > _dDistance)
        {
          num1 -= _dDistance;
        }
        else
        {
          double _dStation;
          for (_dStation = num1; _dStation <= _dDistance; _dStation += plantSpacing / 2.0)
          {
            EPShared.eplGeoE_FindStaOffPointAlongArc(epsLeg.Arc, _dStation, 0.0, ref epsPoint);
            EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint, epsLeg.Arc.RadiusPnt, epsLeg.Arc.Direction, ref _dPolarDirection);
            if (flag1)
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection - Math.PI / 2.0), setbackSpacing, ref epsPoint);
            else
              EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dPolarDirection + Math.PI / 2.0), setbackSpacing, ref epsPoint);
            flag1 = !flag1;
            if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
            {
              if (epsLeg.Element != null && flag4 && !flag5)
              {
                if (flag6)
                {
                  flag6 = false;
                  if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
                  {
                    keyValuePairList = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Leg.ElementList);
                  }
                  else
                  {
                    int num5 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
                    flag4 = false;
                  }
                }
                if (index1 < keyValuePairList.Count)
                {
                  keyValuePair = keyValuePairList[index1];
                  if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                  {
                    flag5 = true;
                  }
                  else
                  {
                    for (int index3 = 0; index3 < keyValuePairList.Count; ++index3)
                    {
                      keyValuePair = keyValuePairList[index3];
                      if (string.Compare(keyValuePair.Key, epsLeg.Element.UniqueId, true) == 0)
                      {
                        index1 = index3;
                        flag5 = true;
                        break;
                      }
                    }
                  }
                }
              }
              _PointList.Add(epsPoint);
              Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlantPlacementSettings.SurfaceList);
              FamilyInstance familyInstance;
              if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
              {
                familyInstance = _ExistingPlantList[0];
                if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
                {
                  XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
                  ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
                }
                _ExistingPlantList.RemoveAt(0);
              }
              else
              {
                EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
                familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
                _PlantPlacementSettings.TransactionContainer = transactionContainer;
              }
              if (flag2)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
                    double num6 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num6);
                  }
                }
                else
                  flag2 = false;
              }
              if (flag3)
              {
                Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
                if (parameter != null)
                {
                  if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
                  {
                    double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
                    double num7 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
                    parameter.Set(num7);
                  }
                }
                else
                  flag3 = false;
              }
              if (epsLeg.Element != null && flag4 && flag5)
              {
                Parameter parameter3 = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
                if (parameter3 != null)
                {
                  Parameter parameter4 = parameter3;
                  keyValuePair = keyValuePairList[index1];
                  string str = keyValuePair.Value;
                  parameter4.Set(str);
                }
                else
                  flag4 = false;
              }
              _FamilyList.Insert((Element) familyInstance);
            }
            progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
          }
          num1 = _dStation - _dDistance;
        }
      }
      flag5 = false;
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index4 = 0; index4 < _ExistingPlantList.Count; ++index4)
        _Document.Delete(((Element) _ExistingPlantList[index4]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_FamilyList.IsEmpty)
      return;
    bool _bCreateTag = false;
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _bCreateTag = true;
    PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
  }

  public static ElementSet PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Line _Line)
  {
    return PlantCommon.PlaceCenterRowOnLine(_Document, _PlantPlacementSettings, _Element, _Line, true, (List<FamilyInstance>) null);
  }

  public static ElementSet PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Line _Line,
    List<FamilyInstance> _ExistingPlantList)
  {
    return PlantCommon.PlaceCenterRowOnLine(_Document, _PlantPlacementSettings, _Element, _Line, true, _ExistingPlantList);
  }

  public static ElementSet PlaceCenterRowOnLine(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Line _Line,
    bool _bCreateGroupTag,
    List<FamilyInstance> _ExistingPlantList)
  {
    Eps_Point _NewPnt = new Eps_Point();
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    double plantSpacing = _PlantPlacementSettings.PlantSpacing;
    if (_Line == null)
      return (ElementSet) null;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDistance);
    ElementSet _FamilyList = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = true;
    bool flag2 = true;
    bool flag3 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag4 = false;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(_dDistance - _PlantPlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag4 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlantPlacementSettings.GenericModelIDList[0];
    }
    for (double startingDistance = _PlantPlacementSettings.StartingDistance; startingDistance <= _dDistance; startingDistance += plantSpacing)
    {
      EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, startingDistance, ref _NewPnt);
      if (!RevitUtility.IsPointInPointList(_NewPnt, _PointList))
      {
        if (_Element != null && flag3 && flag4)
        {
          flag4 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Element);
          }
          else
          {
            int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag3 = false;
          }
        }
        _PointList.Add(_NewPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlantPlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
        {
          familyInstance = _ExistingPlantList[0];
          if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(_NewPnt, new Eps_Point(location.Point)))
          {
            XYZ xyz = new XYZ(_NewPnt.XYZ.X - location.Point.X, _NewPnt.XYZ.Y - location.Point.Y, 0.0);
            ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
          }
          _ExistingPlantList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, _NewPnt.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlantPlacementSettings.TransactionContainer = transactionContainer;
        }
        if (flag1)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
              double num = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num);
            }
          }
          else
            flag1 = false;
        }
        if (flag2)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
              double num = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num);
            }
          }
          else
            flag2 = false;
        }
        if (_Element != null && flag3 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag3 = false;
        }
        _FamilyList.Insert((Element) familyInstance);
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index = 0; index < _ExistingPlantList.Count; ++index)
        _Document.Delete(((Element) _ExistingPlantList[index]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_bCreateGroupTag && !_FamilyList.IsEmpty)
    {
      bool _bCreateTag = false;
      if (_PlantPlacementSettings.GenericModelIDList == null)
        _bCreateTag = true;
      PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
    }
    return _FamilyList;
  }

  public static ElementSet PlaceAltRowOnLine(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Line _Line)
  {
    bool _bOffsetRight = true;
    return PlantCommon.PlaceAltRowOnLine(_Document, _PlantPlacementSettings, _Element, _Line, ref _bOffsetRight, true, (List<FamilyInstance>) null);
  }

  public static ElementSet PlaceAltRowOnLine(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Line _Line,
    List<FamilyInstance> _ExistingPlantList)
  {
    bool _bOffsetRight = true;
    return PlantCommon.PlaceAltRowOnLine(_Document, _PlantPlacementSettings, _Element, _Line, ref _bOffsetRight, true, _ExistingPlantList);
  }

  public static ElementSet PlaceAltRowOnLine(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Line _Line,
    ref bool _bOffsetRight,
    bool _bCreateGroupTag,
    List<FamilyInstance> _ExistingPlantList)
  {
    Eps_Point _NewPnt = new Eps_Point();
    double _dDirection = 0.0;
    double _dDistance = 0.0;
    double setbackSpacing = _PlantPlacementSettings.SetbackSpacing;
    double plantSpacing = _PlantPlacementSettings.PlantSpacing;
    if (_Line == null)
      return (ElementSet) null;
    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDirection);
    EPShared.eplGeoE_CalcHorzDistBtwnTwoPnts(_Line.StartPnt, _Line.EndPnt, ref _dDistance);
    ElementSet _FamilyList = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = true;
    bool flag2 = true;
    bool flag3 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag4 = false;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(_dDistance - _PlantPlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag4 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlantPlacementSettings.GenericModelIDList[0];
    }
    for (double startingDistance = _PlantPlacementSettings.StartingDistance; startingDistance <= _dDistance; startingDistance += plantSpacing / 2.0)
    {
      EPShared.eplGeoE_CalcPolarToXY(_Line.StartPnt, _dDirection, startingDistance, ref _NewPnt);
      if (_bOffsetRight)
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection - Math.PI / 2.0), setbackSpacing, ref _NewPnt);
      else
        EPShared.eplGeoE_CalcPolarToXY(_NewPnt, EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI / 2.0), setbackSpacing, ref _NewPnt);
      _bOffsetRight = !_bOffsetRight;
      if (!RevitUtility.IsPointInPointList(_NewPnt, _PointList))
      {
        if (_Element != null && flag3 && flag4)
        {
          flag4 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Element);
          }
          else
          {
            int num = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag3 = false;
          }
        }
        _PointList.Add(_NewPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_NewPnt, _PlantPlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
        {
          familyInstance = _ExistingPlantList[0];
          if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(_NewPnt, new Eps_Point(location.Point)))
          {
            XYZ xyz = new XYZ(_NewPnt.XYZ.X - location.Point.X, _NewPnt.XYZ.Y - location.Point.Y, 0.0);
            ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
          }
          _ExistingPlantList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, _NewPnt.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlantPlacementSettings.TransactionContainer = transactionContainer;
        }
        if (flag1)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
              double num = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num);
            }
          }
          else
            flag1 = false;
        }
        if (flag2)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
              double num = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num);
            }
          }
          else
            flag2 = false;
        }
        if (_Element != null && flag3 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag3 = false;
        }
        _FamilyList.Insert((Element) familyInstance);
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index = 0; index < _ExistingPlantList.Count; ++index)
        _Document.Delete(((Element) _ExistingPlantList[index]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_bCreateGroupTag && !_FamilyList.IsEmpty)
    {
      bool _bCreateTag = false;
      if (_PlantPlacementSettings.GenericModelIDList == null)
        _bCreateTag = true;
      PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
    }
    return _FamilyList;
  }

  public static void PlaceCenterRowOnArc(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Arc _Arc)
  {
    PlantCommon.PlaceCenterRowOnArc(_Document, _PlantPlacementSettings, _Element, _Arc, (List<FamilyInstance>) null);
  }

  public static void PlaceCenterRowOnArc(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Arc _Arc,
    List<FamilyInstance> _ExistingPlantList)
  {
    Eps_Point _StaOffPnt = new Eps_Point();
    double plantSpacing = _PlantPlacementSettings.PlantSpacing;
    if (_Arc == null)
      return;
    double num1 = _Arc.Radius * _Arc.Delta;
    ElementSet _FamilyList = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag1 = true;
    bool flag2 = true;
    bool flag3 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag4 = false;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(num1 - _PlantPlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag4 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlantPlacementSettings.GenericModelIDList[0];
    }
    for (double startingDistance = _PlantPlacementSettings.StartingDistance; startingDistance <= num1; startingDistance += plantSpacing)
    {
      EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, startingDistance, 0.0, ref _StaOffPnt);
      if (!RevitUtility.IsPointInPointList(_StaOffPnt, _PointList))
      {
        if (_Element != null && flag3 && flag4)
        {
          flag4 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Element);
          }
          else
          {
            int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag3 = false;
          }
        }
        _PointList.Add(_StaOffPnt);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(_StaOffPnt, _PlantPlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
        {
          familyInstance = _ExistingPlantList[0];
          if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(_StaOffPnt, new Eps_Point(location.Point)))
          {
            XYZ xyz = new XYZ(_StaOffPnt.XYZ.X - location.Point.X, _StaOffPnt.XYZ.Y - location.Point.Y, 0.0);
            ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
          }
          _ExistingPlantList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, _StaOffPnt.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlantPlacementSettings.TransactionContainer = transactionContainer;
        }
        if (flag1)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
              double num3 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num3);
            }
          }
          else
            flag1 = false;
        }
        if (flag2)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
              double num4 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num4);
            }
          }
          else
            flag2 = false;
        }
        if (_Element != null && flag3 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag3 = false;
        }
        _FamilyList.Insert((Element) familyInstance);
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index = 0; index < _ExistingPlantList.Count; ++index)
        _Document.Delete(((Element) _ExistingPlantList[index]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_FamilyList.IsEmpty)
      return;
    bool _bCreateTag = false;
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _bCreateTag = true;
    PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
  }

  public static void PlaceAltRowOnArc(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Arc _Arc)
  {
    PlantCommon.PlaceAltRowOnArc(_Document, _PlantPlacementSettings, _Element, _Arc, (List<FamilyInstance>) null);
  }

  public static void PlaceAltRowOnArc(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Arc _Arc,
    List<FamilyInstance> _ExistingPlantList)
  {
    Eps_Point epsPoint = new Eps_Point();
    double _dTangentDir = 0.0;
    bool flag1 = true;
    double setbackSpacing = _PlantPlacementSettings.SetbackSpacing;
    double plantSpacing = _PlantPlacementSettings.PlantSpacing;
    if (_Arc == null)
      return;
    double num1 = _Arc.Radius * _Arc.Delta;
    ElementSet _FamilyList = new ElementSet();
    List<Eps_Point> _PointList = new List<Eps_Point>();
    bool flag2 = true;
    bool flag3 = true;
    bool flag4 = !_PlantPlacementSettings.DeleteExistingChecked;
    bool flag5 = false;
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = Convert.ToInt32(num1 - _PlantPlacementSettings.StartingDistance);
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarPlacingPlantsMessage");
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      flag5 = true;
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlantPlacementSettings.GenericModelIDList[0];
    }
    for (double startingDistance = _PlantPlacementSettings.StartingDistance; startingDistance <= num1; startingDistance += plantSpacing / 2.0)
    {
      EPShared.eplGeoE_FindStaOffPointAlongArc(_Arc, startingDistance, 0.0, ref epsPoint);
      EPShared.eplGeoE_CalcTangentDirOfArc(epsPoint, _Arc.RadiusPnt, _Arc.Direction, ref _dTangentDir);
      if (flag1)
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dTangentDir - Math.PI / 2.0), setbackSpacing, ref epsPoint);
      else
        EPShared.eplGeoE_CalcPolarToXY(epsPoint, EPShared.eplGeoE_NormalizeRadians(_dTangentDir + Math.PI / 2.0), setbackSpacing, ref epsPoint);
      flag1 = !flag1;
      if (!RevitUtility.IsPointInPointList(epsPoint, _PointList))
      {
        if (_Element != null && flag4 && flag5)
        {
          flag5 = false;
          if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
          {
            keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Element);
          }
          else
          {
            int num2 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
            flag4 = false;
          }
        }
        _PointList.Add(epsPoint);
        Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(epsPoint, _PlantPlacementSettings.SurfaceList);
        FamilyInstance familyInstance;
        if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlantList != null && _ExistingPlantList.Count > 0)
        {
          familyInstance = _ExistingPlantList[0];
          if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint, new Eps_Point(location.Point)))
          {
            XYZ xyz = new XYZ(epsPoint.XYZ.X - location.Point.X, epsPoint.XYZ.Y - location.Point.Y, 0.0);
            ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
          }
          _ExistingPlantList.RemoveAt(0);
        }
        else
        {
          EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
          familyInstance = RevitUtility.NewFamilyInstance(_Document, epsPoint.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
          _PlantPlacementSettings.TransactionContainer = transactionContainer;
        }
        if (flag2)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
              double num3 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num3);
            }
          }
          else
            flag2 = false;
        }
        if (flag3)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
          if (parameter != null)
          {
            if (!RevitDefines.EQ(parameter.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0)
            {
              double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
              double num4 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
              parameter.Set(num4);
            }
          }
          else
            flag3 = false;
        }
        if (_Element != null && flag4 && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null)
            parameter.Set(keyValuePair.Value);
          else
            flag4 = false;
        }
        _FamilyList.Insert((Element) familyInstance);
      }
      progressBarForm.UpdateProgressBar(Convert.ToInt32(plantSpacing));
    }
    if (_ExistingPlantList != null && _ExistingPlantList.Count > 0)
    {
      for (int index = 0; index < _ExistingPlantList.Count; ++index)
        _Document.Delete(((Element) _ExistingPlantList[index]).Id);
    }
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    if (_FamilyList.IsEmpty)
      return;
    bool _bCreateTag = false;
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _bCreateTag = true;
    PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
  }

  public static FamilyInstance PlaceSingleOnPoint(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Point originPoint)
  {
    return PlantCommon.PlaceSingleOnPoint(_Document, _PlantPlacementSettings, _Element, originPoint, true, (FamilyInstance) null);
  }

  public static FamilyInstance PlaceSingleOnPoint(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Point originPoint,
    FamilyInstance _ExistingPlant)
  {
    return PlantCommon.PlaceSingleOnPoint(_Document, _PlantPlacementSettings, _Element, originPoint, true, _ExistingPlant);
  }

  public static FamilyInstance PlaceSingleOnPoint(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Point originPoint,
    bool _bCreateTag)
  {
    return PlantCommon.PlaceSingleOnPoint(_Document, _PlantPlacementSettings, _Element, originPoint, _bCreateTag, (FamilyInstance) null);
  }

  public static FamilyInstance PlaceSingleOnPoint(
    Document _Document,
    PlacementSettings _PlantPlacementSettings,
    Element _Element,
    Eps_Point originPoint,
    bool _bCreateGroupTag,
    FamilyInstance _ExistingPlant)
  {
    KeyValuePair<string, string> keyValuePair = new KeyValuePair<string, string>();
    bool _bUseFailureHandling = true;
    if (_PlantPlacementSettings.GenericModelIDList == null)
    {
      _PlantPlacementSettings.TransactionContainer.BeginTransaction();
    }
    else
    {
      _bUseFailureHandling = false;
      keyValuePair = _PlantPlacementSettings.GenericModelIDList[0];
    }
    _Document.GetUnits().GetFormatOptions((UnitType) 0);
    if (!_PlantPlacementSettings.DeleteExistingChecked && _Element != null && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
    {
      if (RevitUtility.IsParameterIDOnFamily(_Document, _PlantPlacementSettings, _PlantPlacementSettings.Type))
      {
        if (_PlantPlacementSettings.GenericModelIDList == null)
          keyValuePair = RevitUtility.CreatePlacementGenericModel(_Document, _PlantPlacementSettings, _Element);
      }
      else
      {
        int num1 = (int) new WarningOptionsForm(EPShared.LocalRM.GetString("WarningDialog"), _Document.PathName, "PlacePlantNoPositioning", EPShared.LocalRM.GetString("PositionPlantsMessage") + EPShared.LocalRM.GetString("_PlacedWontUpdateWithHost_Message") + EPShared.LocalRM.GetString("PlacementIDFamilyParameter") + EPShared.LocalRM.GetString("_ParametersNotPartOfFamilyMessage"), new List<string>(), -1, false).ShowDialog();
      }
    }
    Element surfaceContainingPoint = RevitUtility.GetSurfaceContainingPoint(originPoint, _PlantPlacementSettings.SurfaceList);
    FamilyInstance familyInstance;
    if ((surfaceContainingPoint == null || _PlantPlacementSettings.GenericModelIDList != null) && _ExistingPlant != null)
    {
      familyInstance = _ExistingPlant;
      if (((Element) familyInstance).Location is LocationPoint location && !EPShared.eplGeoE_ArePntsDuplicates3D(originPoint, new Eps_Point(location.Point)))
      {
        XYZ xyz = new XYZ(originPoint.XYZ.X - location.Point.X, originPoint.XYZ.Y - location.Point.Y, 0.0);
        ElementTransformUtils.MoveElement(_Document, ((Element) familyInstance).Id, xyz);
      }
    }
    else
    {
      EPTransactionContainer transactionContainer = _PlantPlacementSettings.TransactionContainer;
      familyInstance = RevitUtility.NewFamilyInstance(_Document, originPoint.XY, _PlantPlacementSettings.Type, surfaceContainingPoint, _PlantPlacementSettings.Level, (StructuralType) 0, _bUseFailureHandling, ref transactionContainer);
      _PlantPlacementSettings.TransactionContainer = transactionContainer;
    }
    Parameter parameter1 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
    if (parameter1 != null && (!RevitDefines.EQ(parameter1.AsDouble(), _PlantPlacementSettings.Height) || Math.Abs(_PlantPlacementSettings.HeightVariance) > 0.0))
    {
      double MaxValue = Math.Abs(_PlantPlacementSettings.HeightVariance);
      double num2 = MaxValue <= 0.0 ? _PlantPlacementSettings.Height : _PlantPlacementSettings.Height + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
      parameter1.Set(num2);
    }
    Parameter parameter2 = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
    if (parameter2 != null && (!RevitDefines.EQ(parameter2.AsDouble(), _PlantPlacementSettings.Width) || Math.Abs(_PlantPlacementSettings.WidthVariance) > 0.0))
    {
      double MaxValue = Math.Abs(_PlantPlacementSettings.WidthVariance);
      double num3 = MaxValue <= 0.0 ? _PlantPlacementSettings.Width : _PlantPlacementSettings.Width + RevitGeometry.RandomDouble(-MaxValue, MaxValue);
      parameter2.Set(num3);
    }
    if (!_PlantPlacementSettings.DeleteExistingChecked && _Element != null && string.Compare(keyValuePair.Key, _Element.UniqueId, true) == 0)
      ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter)?.Set(keyValuePair.Value);
    if (_PlantPlacementSettings.GenericModelIDList == null)
      _PlantPlacementSettings.TransactionContainer.EndTransaction();
    if (_bCreateGroupTag)
    {
      ElementSet _FamilyList = new ElementSet();
      _FamilyList.Insert((Element) familyInstance);
      bool _bCreateTag = false;
      if (_PlantPlacementSettings.GenericModelIDList == null)
        _bCreateTag = true;
      PlantCommon.CreateTag(_Document, _PlantPlacementSettings.TransactionContainer, _PlantPlacementSettings.View, _FamilyList, _PlantPlacementSettings.PlantSpacing, _PlantPlacementSettings.PlaceGroupTagChecked, _PlantPlacementSettings.LeaderedTagChecked, _bCreateTag);
    }
    return familyInstance;
  }
}
