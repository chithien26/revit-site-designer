using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace SITES;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class WinFormStrings
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				ResourceManager resourceManager = new ResourceManager("SITES.WinFormStrings", typeof(WinFormStrings).Assembly);
				resourceMan = resourceManager;
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static string __GenericModelFamilyString => ResourceManager.GetString("__GenericModelFamilyString", resourceCulture);

	internal static string _And_ => ResourceManager.GetString("_And_", resourceCulture);

	internal static string _AssignFor_Message => ResourceManager.GetString("_AssignFor_Message", resourceCulture);

	internal static string _AssignTo_Message => ResourceManager.GetString("_AssignTo_Message", resourceCulture);

	internal static string _FamiliesInModelString => ResourceManager.GetString("_FamiliesInModelString", resourceCulture);

	internal static string _Family_ => ResourceManager.GetString("_Family_", resourceCulture);

	internal static string _FamilyCannotBePlaceMessage => ResourceManager.GetString("_FamilyCannotBePlaceMessage", resourceCulture);

	internal static string _FamilyFileMessage => ResourceManager.GetString("_FamilyFileMessage", resourceCulture);

	internal static string _FamilyManagerString => ResourceManager.GetString("_FamilyManagerString", resourceCulture);

	internal static string _FamilyNotLoaded_Message => ResourceManager.GetString("_FamilyNotLoaded_Message", resourceCulture);

	internal static string _FamilyTypeNotFoundDeleteMessage => ResourceManager.GetString("_FamilyTypeNotFoundDeleteMessage", resourceCulture);

	internal static string _FamilyTypeNotFoundMessage => ResourceManager.GetString("_FamilyTypeNotFoundMessage", resourceCulture);

	internal static string _FeaturesInThisModelString => ResourceManager.GetString("_FeaturesInThisModelString", resourceCulture);

	internal static string _From_Message => ResourceManager.GetString("_From_Message", resourceCulture);

	internal static string _HostLineString => ResourceManager.GetString("_HostLineString", resourceCulture);

	internal static string _InSettingString => ResourceManager.GetString("_InSettingString", resourceCulture);

	internal static string _InvalidTypeNameMessage => ResourceManager.GetString("_InvalidTypeNameMessage", resourceCulture);

	internal static string _LeadingAndTrailingSpacesMessage => ResourceManager.GetString("_LeadingAndTrailingSpacesMessage", resourceCulture);

	internal static string _ParametersNotPartOfFamilyMessage => ResourceManager.GetString("_ParametersNotPartOfFamilyMessage", resourceCulture);

	internal static string _PlacedWontUpdateWithHost_Message => ResourceManager.GetString("_PlacedWontUpdateWithHost_Message", resourceCulture);

	internal static string _RegionNameAlreadyAssigned_Message => ResourceManager.GetString("_RegionNameAlreadyAssigned_Message", resourceCulture);

	internal static string _TypeParameterPFamilyNotLoadedMessage => ResourceManager.GetString("_TypeParameterPFamilyNotLoadedMessage", resourceCulture);

	internal static string _TypeParameterString => ResourceManager.GetString("_TypeParameterString", resourceCulture);

	internal static string _TypeString => ResourceManager.GetString("_TypeString", resourceCulture);

	internal static string A_AMP_ddDialog => ResourceManager.GetString("A_AMP_ddDialog", resourceCulture);

	internal static string A_AMP_geDialog => ResourceManager.GetString("A_AMP_geDialog", resourceCulture);

	internal static string AboutLANDCADDForRevitDialog => ResourceManager.GetString("AboutLANDCADDForRevitDialog", resourceCulture);

	internal static string AboutRibbonButton => ResourceManager.GetString("AboutRibbonButton", resourceCulture);

	internal static string AboutSiteDesignerForRevitDialog => ResourceManager.GetString("AboutSiteDesignerForRevitDialog", resourceCulture);

	internal static string AboutSiteworksRibbonToolTip => ResourceManager.GetString("AboutSiteworksRibbonToolTip", resourceCulture);

	internal static string ADASpacingDialog => ResourceManager.GetString("ADASpacingDialog", resourceCulture);

	internal static string ADAStallCountGenericModelFamilyParameter => ResourceManager.GetString("ADAStallCountGenericModelFamilyParameter", resourceCulture);

	internal static string ADAStallSharedAccessibleAisleGenericModelFamilyParameter => ResourceManager.GetString("ADAStallSharedAccessibleAisleGenericModelFamilyParameter", resourceCulture);

	internal static string ADAStallSymbolIDGenericFamilyParameter => ResourceManager.GetString("ADAStallSymbolIDGenericFamilyParameter", resourceCulture);

	internal static string ADAStallWidthGenericModelFamilyParameter => ResourceManager.GetString("ADAStallWidthGenericModelFamilyParameter", resourceCulture);

	internal static string Add_AMP_BreaklineDialog => ResourceManager.GetString("Add_AMP_BreaklineDialog", resourceCulture);

	internal static string Add_AMP_NewSurfaceSurfaceInfoDialog => ResourceManager.GetString("Add_AMP_NewSurfaceSurfaceInfoDialog", resourceCulture);

	internal static string Add_AMP_VertexDialog => ResourceManager.GetString("Add_AMP_VertexDialog", resourceCulture);

	internal static string AddBreaklineDialog => ResourceManager.GetString("AddBreaklineDialog", resourceCulture);

	internal static string AddBuildingPadsPointsToSurfacesMessage => ResourceManager.GetString("AddBuildingPadsPointsToSurfacesMessage", resourceCulture);

	internal static string AddBuildingPadsToProposedSurfaceMessage => ResourceManager.GetString("AddBuildingPadsToProposedSurfaceMessage", resourceCulture);

	internal static string AddBuildingPadsToSurfaceTransaction => ResourceManager.GetString("AddBuildingPadsToSurfaceTransaction", resourceCulture);

	internal static string AddDialog => ResourceManager.GetString("AddDialog", resourceCulture);

	internal static string AddInsRibbonTabIDValue => ResourceManager.GetString("AddInsRibbonTabIDValue", resourceCulture);

	internal static string AdditionalFormIDFamilyParameter => ResourceManager.GetString("AdditionalFormIDFamilyParameter", resourceCulture);

	internal static string AddParametersToFamilyTransaction => ResourceManager.GetString("AddParametersToFamilyTransaction", resourceCulture);

	internal static string AddSubRegionsToProposedSurfaceMessage => ResourceManager.GetString("AddSubRegionsToProposedSurfaceMessage", resourceCulture);

	internal static string AisleWidthString => ResourceManager.GetString("AisleWidthString", resourceCulture);

	internal static string Ali_AMP_gnToDialog => ResourceManager.GetString("Ali_AMP_gnToDialog", resourceCulture);

	internal static string AlignmentNotSelectedString => ResourceManager.GetString("AlignmentNotSelectedString", resourceCulture);

	internal static string AlignmentSelectionDialog => ResourceManager.GetString("AlignmentSelectionDialog", resourceCulture);

	internal static string AlignmentToExportDialog => ResourceManager.GetString("AlignmentToExportDialog", resourceCulture);

	internal static string AlignToGenericFamilyParameter => ResourceManager.GetString("AlignToGenericFamilyParameter", resourceCulture);

	internal static string All_AMP_InstancesDialog => ResourceManager.GetString("All_AMP_InstancesDialog", resourceCulture);

	internal static string AllGeometryString => ResourceManager.GetString("AllGeometryString", resourceCulture);

	internal static string AllGeometryStringQuotes => ResourceManager.GetString("AllGeometryStringQuotes", resourceCulture);

	internal static string AllignmentString => ResourceManager.GetString("AllignmentString", resourceCulture);

	internal static string AllString => ResourceManager.GetString("AllString", resourceCulture);

	internal static string AllSymbolsString => ResourceManager.GetString("AllSymbolsString", resourceCulture);

	internal static string AllwaysLoadDefaultFamiliesOption => ResourceManager.GetString("AllwaysLoadDefaultFamiliesOption", resourceCulture);

	internal static string AMP_AddAllDialog => ResourceManager.GetString("AMP_AddAllDialog", resourceCulture);

	internal static string AMP_AddDialog => ResourceManager.GetString("AMP_AddDialog", resourceCulture);

	internal static string AMP_AddToFamilyDialog => ResourceManager.GetString("AMP_AddToFamilyDialog", resourceCulture);

	internal static string AMP_AllCirclesDialog => ResourceManager.GetString("AMP_AllCirclesDialog", resourceCulture);

	internal static string AMP_AlternateDialog => ResourceManager.GetString("AMP_AlternateDialog", resourceCulture);

	internal static string AMP_AngleDialog => ResourceManager.GetString("AMP_AngleDialog", resourceCulture);

	internal static string AMP_ApplyDialog => ResourceManager.GetString("AMP_ApplyDialog", resourceCulture);

	internal static string AMP_AreaDialog => ResourceManager.GetString("AMP_AreaDialog", resourceCulture);

	internal static string AMP_BeginningElevationDialog => ResourceManager.GetString("AMP_BeginningElevationDialog", resourceCulture);

	internal static string AMP_BlackAndWhiteDialog => ResourceManager.GetString("AMP_BlackAndWhiteDialog", resourceCulture);

	internal static string AMP_CancelDialog => ResourceManager.GetString("AMP_CancelDialog", resourceCulture);

	internal static string AMP_ChainDialog => ResourceManager.GetString("AMP_ChainDialog", resourceCulture);

	internal static string AMP_ChangeElevationDialog => ResourceManager.GetString("AMP_ChangeElevationDialog", resourceCulture);

	internal static string AMP_CloseDialog => ResourceManager.GetString("AMP_CloseDialog", resourceCulture);

	internal static string AMP_CompanyExportXMLDialog => ResourceManager.GetString("AMP_CompanyExportXMLDialog", resourceCulture);

	internal static string AMP_ComponentFamilyDialog => ResourceManager.GetString("AMP_ComponentFamilyDialog", resourceCulture);

	internal static string AMP_ConvertDialog => ResourceManager.GetString("AMP_ConvertDialog", resourceCulture);

	internal static string AMP_CopyDialog => ResourceManager.GetString("AMP_CopyDialog", resourceCulture);

	internal static string AMP_CSVFileDialog => ResourceManager.GetString("AMP_CSVFileDialog", resourceCulture);

	internal static string AMP_CurbFamilyDialog => ResourceManager.GetString("AMP_CurbFamilyDialog", resourceCulture);

	internal static string AMP_CurrentRadiusDialog => ResourceManager.GetString("AMP_CurrentRadiusDialog", resourceCulture);

	internal static string AMP_DeleteDialog => ResourceManager.GetString("AMP_DeleteDialog", resourceCulture);

	internal static string AMP_DetailLevelDialog => ResourceManager.GetString("AMP_DetailLevelDialog", resourceCulture);

	internal static string AMP_DirectoryDialog => ResourceManager.GetString("AMP_DirectoryDialog", resourceCulture);

	internal static string AMP_DirectoryMultipleFilesDialog => ResourceManager.GetString("AMP_DirectoryMultipleFilesDialog", resourceCulture);

	internal static string AMP_DoNotShowMessageDialog => ResourceManager.GetString("AMP_DoNotShowMessageDialog", resourceCulture);

	internal static string AMP_DoubleRowDialog => ResourceManager.GetString("AMP_DoubleRowDialog", resourceCulture);

	internal static string AMP_DownloadNow => ResourceManager.GetString("AMP_DownloadNow", resourceCulture);

	internal static string AMP_DrawHostLineDialog => ResourceManager.GetString("AMP_DrawHostLineDialog", resourceCulture);

	internal static string AMP_ElevationDialog => ResourceManager.GetString("AMP_ElevationDialog", resourceCulture);

	internal static string AMP_ElevationsDialog => ResourceManager.GetString("AMP_ElevationsDialog", resourceCulture);

	internal static string AMP_EqualDialog => ResourceManager.GetString("AMP_EqualDialog", resourceCulture);

	internal static string AMP_ExportDialog => ResourceManager.GetString("AMP_ExportDialog", resourceCulture);

	internal static string AMP_FamilyDialog => ResourceManager.GetString("AMP_FamilyDialog", resourceCulture);

	internal static string AMP_FenceFamilyDialog => ResourceManager.GetString("AMP_FenceFamilyDialog", resourceCulture);

	internal static string AMP_FileDialog => ResourceManager.GetString("AMP_FileDialog", resourceCulture);

	internal static string AMP_FileNameExportXMLDialog => ResourceManager.GetString("AMP_FileNameExportXMLDialog", resourceCulture);

	internal static string AMP_FileNameImportXMLDialog => ResourceManager.GetString("AMP_FileNameImportXMLDialog", resourceCulture);

	internal static string AMP_FindDialog => ResourceManager.GetString("AMP_FindDialog", resourceCulture);

	internal static string AMP_FinishDialog => ResourceManager.GetString("AMP_FinishDialog", resourceCulture);

	internal static string AMP_GradeDialog => ResourceManager.GetString("AMP_GradeDialog", resourceCulture);

	internal static string AMP_GradesDialog => ResourceManager.GetString("AMP_GradesDialog", resourceCulture);

	internal static string AMP_GroveDialog => ResourceManager.GetString("AMP_GroveDialog", resourceCulture);

	internal static string AMP_HedgeRowDialog => ResourceManager.GetString("AMP_HedgeRowDialog", resourceCulture);

	internal static string AMP_HeightDialog => ResourceManager.GetString("AMP_HeightDialog", resourceCulture);

	internal static string AMP_ImageTypeDialog => ResourceManager.GetString("AMP_ImageTypeDialog", resourceCulture);

	internal static string AMP_InsertDialog => ResourceManager.GetString("AMP_InsertDialog", resourceCulture);

	internal static string AMP_LayersDialog => ResourceManager.GetString("AMP_LayersDialog", resourceCulture);

	internal static string AMP_LengthDialog => ResourceManager.GetString("AMP_LengthDialog", resourceCulture);

	internal static string AMP_LevelDialog => ResourceManager.GetString("AMP_LevelDialog", resourceCulture);

	internal static string AMP_LoadDialog => ResourceManager.GetString("AMP_LoadDialog", resourceCulture);

	internal static string AMP_ModifyDialog => ResourceManager.GetString("AMP_ModifyDialog", resourceCulture);

	internal static string AMP_ModifyPlantTypeDialog => ResourceManager.GetString("AMP_ModifyPlantTypeDialog", resourceCulture);

	internal static string AMP_MoveDialog => ResourceManager.GetString("AMP_MoveDialog", resourceCulture);

	internal static string AMP_MoveUpDialog => ResourceManager.GetString("AMP_MoveUpDialog", resourceCulture);

	internal static string AMP_NameDialog => ResourceManager.GetString("AMP_NameDialog", resourceCulture);

	internal static string AMP_New_NewFamilyDialog => ResourceManager.GetString("AMP_New_NewFamilyDialog", resourceCulture);

	internal static string AMP_NewElevationDialog => ResourceManager.GetString("AMP_NewElevationDialog", resourceCulture);

	internal static string AMP_NewFamilyDialog => ResourceManager.GetString("AMP_NewFamilyDialog", resourceCulture);

	internal static string AMP_NewGradeDialog => ResourceManager.GetString("AMP_NewGradeDialog", resourceCulture);

	internal static string AMP_NewLinearDialog => ResourceManager.GetString("AMP_NewLinearDialog", resourceCulture);

	internal static string AMP_NewRadiusDialog => ResourceManager.GetString("AMP_NewRadiusDialog", resourceCulture);

	internal static string AMP_NewViewScaleDialog => ResourceManager.GetString("AMP_NewViewScaleDialog", resourceCulture);

	internal static string AMP_NumberOfRowsDialog => ResourceManager.GetString("AMP_NumberOfRowsDialog", resourceCulture);

	internal static string AMP_OffsetDialog => ResourceManager.GetString("AMP_OffsetDialog", resourceCulture);

	internal static string AMP_OKDialog => ResourceManager.GetString("AMP_OKDialog", resourceCulture);

	internal static string AMP_OptimizeDialog => ResourceManager.GetString("AMP_OptimizeDialog", resourceCulture);

	internal static string AMP_OverwriteExistingSurfaceSurfaceInfoDialog => ResourceManager.GetString("AMP_OverwriteExistingSurfaceSurfaceInfoDialog", resourceCulture);

	internal static string AMP_ParameterDialog => ResourceManager.GetString("AMP_ParameterDialog", resourceCulture);

	internal static string AMP_ParkingLotFamilyDialog => ResourceManager.GetString("AMP_ParkingLotFamilyDialog", resourceCulture);

	internal static string AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog => ResourceManager.GetString("AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog", resourceCulture);

	internal static string AMP_PickDialog => ResourceManager.GetString("AMP_PickDialog", resourceCulture);

	internal static string AMP_PlaceAlongDialog => ResourceManager.GetString("AMP_PlaceAlongDialog", resourceCulture);

	internal static string AMP_PlantFamilyDialog => ResourceManager.GetString("AMP_PlantFamilyDialog", resourceCulture);

	internal static string AMP_PositioningDialog => ResourceManager.GetString("AMP_PositioningDialog", resourceCulture);

	internal static string AMP_PreserveColorsDialog => ResourceManager.GetString("AMP_PreserveColorsDialog", resourceCulture);

	internal static string AMP_ProjectNameExportXMLDialog => ResourceManager.GetString("AMP_ProjectNameExportXMLDialog", resourceCulture);

	internal static string AMP_RadiusDialog => ResourceManager.GetString("AMP_RadiusDialog", resourceCulture);

	internal static string AMP_RegionNameDialog => ResourceManager.GetString("AMP_RegionNameDialog", resourceCulture);

	internal static string AMP_RemoveDialog => ResourceManager.GetString("AMP_RemoveDialog", resourceCulture);

	internal static string AMP_RetainingWallFamilyDialog => ResourceManager.GetString("AMP_RetainingWallFamilyDialog", resourceCulture);

	internal static string AMP_RFAFileDialog => ResourceManager.GetString("AMP_RFAFileDialog", resourceCulture);

	internal static string AMP_RotateDialog => ResourceManager.GetString("AMP_RotateDialog", resourceCulture);

	internal static string AMP_ScaleFactorDialog => ResourceManager.GetString("AMP_ScaleFactorDialog", resourceCulture);

	internal static string AMP_SearchDialog => ResourceManager.GetString("AMP_SearchDialog", resourceCulture);

	internal static string AMP_SegmentDialog => ResourceManager.GetString("AMP_SegmentDialog", resourceCulture);

	internal static string AMP_Select => ResourceManager.GetString("AMP_Select", resourceCulture);

	internal static string AMP_SelectionSetDialog => ResourceManager.GetString("AMP_SelectionSetDialog", resourceCulture);

	internal static string AMP_SetbackDialog => ResourceManager.GetString("AMP_SetbackDialog", resourceCulture);

	internal static string AMP_ShowDialog => ResourceManager.GetString("AMP_ShowDialog", resourceCulture);

	internal static string AMP_SideDialog => ResourceManager.GetString("AMP_SideDialog", resourceCulture);

	internal static string AMP_SingleDialog => ResourceManager.GetString("AMP_SingleDialog", resourceCulture);

	internal static string AMP_SingleFileDialog => ResourceManager.GetString("AMP_SingleFileDialog", resourceCulture);

	internal static string AMP_SingleRowDialog => ResourceManager.GetString("AMP_SingleRowDialog", resourceCulture);

	internal static string AMP_TabFileDialog => ResourceManager.GetString("AMP_TabFileDialog", resourceCulture);

	internal static string AMP_TextTypeDialog => ResourceManager.GetString("AMP_TextTypeDialog", resourceCulture);

	internal static string AMP_ToposurfaceNameDialog => ResourceManager.GetString("AMP_ToposurfaceNameDialog", resourceCulture);

	internal static string AMP_ToposurfaceToOverwriteSurfaceInfoDialog => ResourceManager.GetString("AMP_ToposurfaceToOverwriteSurfaceInfoDialog", resourceCulture);

	internal static string AMP_UseBiDirectionalAislesDialog => ResourceManager.GetString("AMP_UseBiDirectionalAislesDialog", resourceCulture);

	internal static string AMP_UseExistingHostLineDialog => ResourceManager.GetString("AMP_UseExistingHostLineDialog", resourceCulture);

	internal static string AMP_UseParametersDialog => ResourceManager.GetString("AMP_UseParametersDialog", resourceCulture);

	internal static string AMP_VarianceDialog => ResourceManager.GetString("AMP_VarianceDialog", resourceCulture);

	internal static string AMP_ViewDirectionDialog => ResourceManager.GetString("AMP_ViewDirectionDialog", resourceCulture);

	internal static string AMP_WidthDialog => ResourceManager.GetString("AMP_WidthDialog", resourceCulture);

	internal static string AMP_WindowSelectDialog => ResourceManager.GetString("AMP_WindowSelectDialog", resourceCulture);

	internal static string AnnotateRibbonButton => ResourceManager.GetString("AnnotateRibbonButton", resourceCulture);

	internal static string AnnotateRibbonToolTip => ResourceManager.GetString("AnnotateRibbonToolTip", resourceCulture);

	internal static string AnnotateSiteComponentTransaction => ResourceManager.GetString("AnnotateSiteComponentTransaction", resourceCulture);

	internal static string AnnotateTitleDialog => ResourceManager.GetString("AnnotateTitleDialog", resourceCulture);

	internal static string ArcPickedClosedProjectInnerSlopesMessage => ResourceManager.GetString("ArcPickedClosedProjectInnerSlopesMessage", resourceCulture);

	internal static string AreaAisleWidthGenericModelFamilyParameter => ResourceManager.GetString("AreaAisleWidthGenericModelFamilyParameter", resourceCulture);

	internal static string AreaBidirectionalAislesGenericModelFamilyParameter => ResourceManager.GetString("AreaBidirectionalAislesGenericModelFamilyParameter", resourceCulture);

	internal static string AreaDistanceBetweenCenterlinesGenericModelFamilyParameter => ResourceManager.GetString("AreaDistanceBetweenCenterlinesGenericModelFamilyParameter", resourceCulture);

	internal static string AreaPlantMixFamilyParameter => ResourceManager.GetString("AreaPlantMixFamilyParameter", resourceCulture);

	internal static string AreaRegionParameter => ResourceManager.GetString("AreaRegionParameter", resourceCulture);

	internal static string AreaRowCountGenericModelFamilyParameter => ResourceManager.GetString("AreaRowCountGenericModelFamilyParameter", resourceCulture);

	internal static string AreaRowSpacingOptionsGenericModelFamilyParameter => ResourceManager.GetString("AreaRowSpacingOptionsGenericModelFamilyParameter", resourceCulture);

	internal static string AreaString => ResourceManager.GetString("AreaString", resourceCulture);

	internal static string AssemblyCodeGenericFamilyParameter => ResourceManager.GetString("AssemblyCodeGenericFamilyParameter", resourceCulture);

	internal static string Assign_Message => ResourceManager.GetString("Assign_Message", resourceCulture);

	internal static string AssignDialog => ResourceManager.GetString("AssignDialog", resourceCulture);

	internal static string AssignPatioWalkTransaction => ResourceManager.GetString("AssignPatioWalkTransaction", resourceCulture);

	internal static string AssignPlantMixTransaction => ResourceManager.GetString("AssignPlantMixTransaction", resourceCulture);

	internal static string AutodeskSiteDesignerForRevitDialog => ResourceManager.GetString("AutodeskSiteDesignerForRevitDialog", resourceCulture);

	internal static string AutoDetectUnit => ResourceManager.GetString("AutoDetectUnit", resourceCulture);

	internal static string AutomaticallyPlaceDialog => ResourceManager.GetString("AutomaticallyPlaceDialog", resourceCulture);

	internal static string AvailableParametersDialog => ResourceManager.GetString("AvailableParametersDialog", resourceCulture);

	internal static string B_AMP_ySharedCoordinatesDialog => ResourceManager.GetString("B_AMP_ySharedCoordinatesDialog", resourceCulture);

	internal static string B_AMP_ySurveyPointsDialog => ResourceManager.GetString("B_AMP_ySurveyPointsDialog", resourceCulture);

	internal static string BackViewDirection => ResourceManager.GetString("BackViewDirection", resourceCulture);

	internal static string BaseSurfaceLinkBrokenMessage => ResourceManager.GetString("BaseSurfaceLinkBrokenMessage", resourceCulture);

	internal static string BaseToposurfaceAlreadySeteMessage => ResourceManager.GetString("BaseToposurfaceAlreadySeteMessage", resourceCulture);

	internal static string BaseToposurfaceCreatedFamilyParameter => ResourceManager.GetString("BaseToposurfaceCreatedFamilyParameter", resourceCulture);

	internal static string BaseToposurfaceString => ResourceManager.GetString("BaseToposurfaceString", resourceCulture);

	internal static string BeginningElevationFamilyParameter => ResourceManager.GetString("BeginningElevationFamilyParameter", resourceCulture);

	internal static string BlackAndWhiteColorMode => ResourceManager.GetString("BlackAndWhiteColorMode", resourceCulture);

	internal static string BorrowLicenseRibbonButton => ResourceManager.GetString("BorrowLicenseRibbonButton", resourceCulture);

	internal static string BorrowLicenseRibbonToolTip => ResourceManager.GetString("BorrowLicenseRibbonToolTip", resourceCulture);

	internal static string BottomViewDirection => ResourceManager.GetString("BottomViewDirection", resourceCulture);

	internal static string BoundaryClosedChainMessage => ResourceManager.GetString("BoundaryClosedChainMessage", resourceCulture);

	internal static string BoundaryIslandIDGenericFamilyParameter => ResourceManager.GetString("BoundaryIslandIDGenericFamilyParameter", resourceCulture);

	internal static string BreaklinesNotInParkingLotBoundaryMessage => ResourceManager.GetString("BreaklinesNotInParkingLotBoundaryMessage", resourceCulture);

	internal static string BuildingPadString => ResourceManager.GetString("BuildingPadString", resourceCulture);

	internal static string BumperDialog => ResourceManager.GetString("BumperDialog", resourceCulture);

	internal static string BumperHeightGenericModelFamilyParameter => ResourceManager.GetString("BumperHeightGenericModelFamilyParameter", resourceCulture);

	internal static string BumperOffsetGenericModelFamilyParameter => ResourceManager.GetString("BumperOffsetGenericModelFamilyParameter", resourceCulture);

	internal static string BumperSetbackGenericModelFamilyParameter => ResourceManager.GetString("BumperSetbackGenericModelFamilyParameter", resourceCulture);

	internal static string BumperSymbolIDGenericFamilyParameter => ResourceManager.GetString("BumperSymbolIDGenericFamilyParameter", resourceCulture);

	internal static string BumperWidthGenericModelFamilyParameter => ResourceManager.GetString("BumperWidthGenericModelFamilyParameter", resourceCulture);

	internal static string ByN_AMP_umberDialog => ResourceManager.GetString("ByN_AMP_umberDialog", resourceCulture);

	internal static string C_AMP_enterDialog => ResourceManager.GetString("C_AMP_enterDialog", resourceCulture);

	internal static string C_AMP_hangeIntervalDialog => ResourceManager.GetString("C_AMP_hangeIntervalDialog", resourceCulture);

	internal static string C_AMP_hangeTypeDialog => ResourceManager.GetString("C_AMP_hangeTypeDialog", resourceCulture);

	internal static string C_AMP_omponentNameDialog => ResourceManager.GetString("C_AMP_omponentNameDialog", resourceCulture);

	internal static string CannotImport_String => ResourceManager.GetString("CannotImport_String", resourceCulture);

	internal static string CantEditElementsUntilUserResavesMessage => ResourceManager.GetString("CantEditElementsUntilUserResavesMessage", resourceCulture);

	internal static string CantObtainPermissionToEditElementMessage => ResourceManager.GetString("CantObtainPermissionToEditElementMessage", resourceCulture);

	internal static string Cen_AMP_terToCenterDialog => ResourceManager.GetString("Cen_AMP_terToCenterDialog", resourceCulture);

	internal static string CenterString => ResourceManager.GetString("CenterString", resourceCulture);

	internal static string CenterToCenterPlacement => ResourceManager.GetString("CenterToCenterPlacement", resourceCulture);

	internal static string ChainIDGenericFamilyParameter => ResourceManager.GetString("ChainIDGenericFamilyParameter", resourceCulture);

	internal static string ChainPickedClosedProjectInnerSlopesMessage => ResourceManager.GetString("ChainPickedClosedProjectInnerSlopesMessage", resourceCulture);

	internal static string ChangeElevationDialog => ResourceManager.GetString("ChangeElevationDialog", resourceCulture);

	internal static string ChangeFamilyTypeDialog => ResourceManager.GetString("ChangeFamilyTypeDialog", resourceCulture);

	internal static string ChangeGradeDialog => ResourceManager.GetString("ChangeGradeDialog", resourceCulture);

	internal static string ChangeLinearIntervalDialog => ResourceManager.GetString("ChangeLinearIntervalDialog", resourceCulture);

	internal static string ChangeRadiusDialogTitle => ResourceManager.GetString("ChangeRadiusDialogTitle", resourceCulture);

	internal static string ChangeView_AMP_ScaleDialog => ResourceManager.GetString("ChangeView_AMP_ScaleDialog", resourceCulture);

	internal static string ChangeViewScaleDialog => ResourceManager.GetString("ChangeViewScaleDialog", resourceCulture);

	internal static string Characteristics => ResourceManager.GetString("Characteristics", resourceCulture);

	internal static string CharacteristicsAdmirationPointPlantFamilyParameter => ResourceManager.GetString("CharacteristicsAdmirationPointPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsBarkColorPlantFamilyParameter => ResourceManager.GetString("CharacteristicsBarkColorPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsBarkSurfacePlantFamilyParameter => ResourceManager.GetString("CharacteristicsBarkSurfacePlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsBloomEffectPlantFamilyParameter => ResourceManager.GetString("CharacteristicsBloomEffectPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsBloomPeriodPlantFamilyParameter => ResourceManager.GetString("CharacteristicsBloomPeriodPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsCrownDensityPlantFamilyParameter => ResourceManager.GetString("CharacteristicsCrownDensityPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFallColorPlantFamilyParameter => ResourceManager.GetString("CharacteristicsFallColorPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFoliageColorPlantFamilyParameter => ResourceManager.GetString("CharacteristicsFoliageColorPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFoliageSizePlantFamilyParameter => ResourceManager.GetString("CharacteristicsFoliageSizePlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFoliageSurfacePlantFamilyParameter => ResourceManager.GetString("CharacteristicsFoliageSurfacePlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFragrancePlantFamilyParameter => ResourceManager.GetString("CharacteristicsFragrancePlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFruitColorPlantFamilyParameter => ResourceManager.GetString("CharacteristicsFruitColorPlantFamilyParameter", resourceCulture);

	internal static string CharacteristicsFruitPeriodPlantFamilyParameter => ResourceManager.GetString("CharacteristicsFruitPeriodPlantFamilyParameter", resourceCulture);

	internal static string CheckForUpdateNotification => ResourceManager.GetString("CheckForUpdateNotification", resourceCulture);

	internal static string CircleAlreadyPickedMessage => ResourceManager.GetString("CircleAlreadyPickedMessage", resourceCulture);

	internal static string Co_AMP_nstantElevationDialog => ResourceManager.GetString("Co_AMP_nstantElevationDialog", resourceCulture);

	internal static string CoarseDetailLevel => ResourceManager.GetString("CoarseDetailLevel", resourceCulture);

	internal static string CodeNamePlantMixFamilyParameter => ResourceManager.GetString("CodeNamePlantMixFamilyParameter", resourceCulture);

	internal static string CollectionDialog => ResourceManager.GetString("CollectionDialog", resourceCulture);

	internal static string Column_AMP_DisplayDialog => ResourceManager.GetString("Column_AMP_DisplayDialog", resourceCulture);

	internal static string ColumnDisplayFormDialog => ResourceManager.GetString("ColumnDisplayFormDialog", resourceCulture);

	internal static string ColumnMisMatchMessage => ResourceManager.GetString("ColumnMisMatchMessage", resourceCulture);

	internal static string ColumnOrderString => ResourceManager.GetString("ColumnOrderString", resourceCulture);

	internal static string CommonNamePlantMixFamilyParameter => ResourceManager.GetString("CommonNamePlantMixFamilyParameter", resourceCulture);

	internal static string ComparisonTypeString => ResourceManager.GetString("ComparisonTypeString", resourceCulture);

	internal static string Component_AMP_SpacingDialog => ResourceManager.GetString("Component_AMP_SpacingDialog", resourceCulture);

	internal static string ComponentFamilyCantBeLoadedMessage => ResourceManager.GetString("ComponentFamilyCantBeLoadedMessage", resourceCulture);

	internal static string ComponentFamilyNotLoadedMessage => ResourceManager.GetString("ComponentFamilyNotLoadedMessage", resourceCulture);

	internal static string ConceptualMassFolder => ResourceManager.GetString("ConceptualMassFolder", resourceCulture);

	internal static string Condition => ResourceManager.GetString("Condition", resourceCulture);

	internal static string ConditionsExposurePlantFamilyParameter => ResourceManager.GetString("ConditionsExposurePlantFamilyParameter", resourceCulture);

	internal static string ConditionsMiscellaneousPlantFamilyParameter => ResourceManager.GetString("ConditionsMiscellaneousPlantFamilyParameter", resourceCulture);

	internal static string ConditionsSoilConditionPlantFamilyParameter => ResourceManager.GetString("ConditionsSoilConditionPlantFamilyParameter", resourceCulture);

	internal static string ConditionsTolerancesPlantFamilyParameter => ResourceManager.GetString("ConditionsTolerancesPlantFamilyParameter", resourceCulture);

	internal static string Constant_AMP_ElevationsDialog => ResourceManager.GetString("Constant_AMP_ElevationsDialog", resourceCulture);

	internal static string ConstantElevationDialog => ResourceManager.GetString("ConstantElevationDialog", resourceCulture);

	internal static string ContainsComparator => ResourceManager.GetString("ContainsComparator", resourceCulture);

	internal static string ContentInstalledName => ResourceManager.GetString("ContentInstalledName", resourceCulture);

	internal static string ContinueWOLoadFamiliesOption => ResourceManager.GetString("ContinueWOLoadFamiliesOption", resourceCulture);

	internal static string ContinueWOLoadFamilyOption => ResourceManager.GetString("ContinueWOLoadFamilyOption", resourceCulture);

	internal static string ConvertObjectToToposurfaceRibbonToolTip => ResourceManager.GetString("ConvertObjectToToposurfaceRibbonToolTip", resourceCulture);

	internal static string ConvertObjectToToposurfaceRibbonToolTipLongDescription => ResourceManager.GetString("ConvertObjectToToposurfaceRibbonToolTipLongDescription", resourceCulture);

	internal static string ConvertObjectToToposurfaceTitle => ResourceManager.GetString("ConvertObjectToToposurfaceTitle", resourceCulture);

	internal static string ConvertObjectToToposurfaceTransaction => ResourceManager.GetString("ConvertObjectToToposurfaceTransaction", resourceCulture);

	internal static string ConvertPlantsDialog => ResourceManager.GetString("ConvertPlantsDialog", resourceCulture);

	internal static string ConvertPlantSearchTitle => ResourceManager.GetString("ConvertPlantSearchTitle", resourceCulture);

	internal static string ConvertPlantsTransaction => ResourceManager.GetString("ConvertPlantsTransaction", resourceCulture);

	internal static string ConvertRibbonPanel => ResourceManager.GetString("ConvertRibbonPanel", resourceCulture);

	internal static string Copy_ => ResourceManager.GetString("Copy_", resourceCulture);

	internal static string CopyrightDialog => ResourceManager.GetString("CopyrightDialog", resourceCulture);

	internal static string CostGenericFamilyParameter => ResourceManager.GetString("CostGenericFamilyParameter", resourceCulture);

	internal static string CostPlantFamilyParameter => ResourceManager.GetString("CostPlantFamilyParameter", resourceCulture);

	internal static string Cr_AMP_eateSymbolDWGDialog => ResourceManager.GetString("Cr_AMP_eateSymbolDWGDialog", resourceCulture);

	internal static string Create_ => ResourceManager.GetString("Create_", resourceCulture);

	internal static string Create_AMP_ACopyDialog => ResourceManager.GetString("Create_AMP_ACopyDialog", resourceCulture);

	internal static string Created_AMP_ByExportXMLDialog => ResourceManager.GetString("Created_AMP_ByExportXMLDialog", resourceCulture);

	internal static string CreatedBy_AMP_EmailExportXMLDialog => ResourceManager.GetString("CreatedBy_AMP_EmailExportXMLDialog", resourceCulture);

	internal static string CreateLineSubCategoriesTransaction => ResourceManager.GetString("CreateLineSubCategoriesTransaction", resourceCulture);

	internal static string CreateMassFormTransaction => ResourceManager.GetString("CreateMassFormTransaction", resourceCulture);

	internal static string CreateNewToposurfaceOption => ResourceManager.GetString("CreateNewToposurfaceOption", resourceCulture);

	internal static string CreatePatioWalkFamilyTransaction => ResourceManager.GetString("CreatePatioWalkFamilyTransaction", resourceCulture);

	internal static string CreatePlant_AMP_GroupTagDialog => ResourceManager.GetString("CreatePlant_AMP_GroupTagDialog", resourceCulture);

	internal static string CreatePlantFamilyTransaction => ResourceManager.GetString("CreatePlantFamilyTransaction", resourceCulture);

	internal static string CreatePlantMixFamilyTransaction => ResourceManager.GetString("CreatePlantMixFamilyTransaction", resourceCulture);

	internal static string CreateSharedParameterFileDialog => ResourceManager.GetString("CreateSharedParameterFileDialog", resourceCulture);

	internal static string CreatingFamilyTypeMessage => ResourceManager.GetString("CreatingFamilyTypeMessage", resourceCulture);

	internal static string CurbBaseSurfaceParameter => ResourceManager.GetString("CurbBaseSurfaceParameter", resourceCulture);

	internal static string CurbFamilyDialog => ResourceManager.GetString("CurbFamilyDialog", resourceCulture);

	internal static string CurbFamilyManagerRibbonButton => ResourceManager.GetString("CurbFamilyManagerRibbonButton", resourceCulture);

	internal static string CurbFamilyManagerToolTip => ResourceManager.GetString("CurbFamilyManagerToolTip", resourceCulture);

	internal static string CurbFamilyNotLoadedMessage => ResourceManager.GetString("CurbFamilyNotLoadedMessage", resourceCulture);

	internal static string CurbGutterHeightParameter => ResourceManager.GetString("CurbGutterHeightParameter", resourceCulture);

	internal static string CurbGutterSlopeParameter => ResourceManager.GetString("CurbGutterSlopeParameter", resourceCulture);

	internal static string CurbGutterTabString => ResourceManager.GetString("CurbGutterTabString", resourceCulture);

	internal static string CurbLineSubCategoryColor => ResourceManager.GetString("CurbLineSubCategoryColor", resourceCulture);

	internal static string CurbLineSubCategoryLineWeight => ResourceManager.GetString("CurbLineSubCategoryLineWeight", resourceCulture);

	internal static string CurbLineSubCategoryName => ResourceManager.GetString("CurbLineSubCategoryName", resourceCulture);

	internal static string CurbMassSubCategoryName => ResourceManager.GetString("CurbMassSubCategoryName", resourceCulture);

	internal static string CurbMassTemplateFileNameString => ResourceManager.GetString("CurbMassTemplateFileNameString", resourceCulture);

	internal static string CurbMaterialParameter => ResourceManager.GetString("CurbMaterialParameter", resourceCulture);

	internal static string CurbNa_AMP_meDialog => ResourceManager.GetString("CurbNa_AMP_meDialog", resourceCulture);

	internal static string CurbNameDialog => ResourceManager.GetString("CurbNameDialog", resourceCulture);

	internal static string CurbString => ResourceManager.GetString("CurbString", resourceCulture);

	internal static string CurbSubbaseSurfaceParameter => ResourceManager.GetString("CurbSubbaseSurfaceParameter", resourceCulture);

	internal static string CurbT_AMP_ypeDialog => ResourceManager.GetString("CurbT_AMP_ypeDialog", resourceCulture);

	internal static string CurbTemplateNotMassTypeMessage => ResourceManager.GetString("CurbTemplateNotMassTypeMessage", resourceCulture);

	internal static string CurbTypeDialog => ResourceManager.GetString("CurbTypeDialog", resourceCulture);

	internal static string CurbTypeManagerString => ResourceManager.GetString("CurbTypeManagerString", resourceCulture);

	internal static string CurrentElevationDialog => ResourceManager.GetString("CurrentElevationDialog", resourceCulture);

	internal static string CurrentFamilyDialog => ResourceManager.GetString("CurrentFamilyDialog", resourceCulture);

	internal static string CurrentFamilyNameString => ResourceManager.GetString("CurrentFamilyNameString", resourceCulture);

	internal static string CurrentGradeDialog => ResourceManager.GetString("CurrentGradeDialog", resourceCulture);

	internal static string CurrentLinearDialog => ResourceManager.GetString("CurrentLinearDialog", resourceCulture);

	internal static string CurrentSlopeUnitString => ResourceManager.GetString("CurrentSlopeUnitString", resourceCulture);

	internal static string CurrentTypeDialog => ResourceManager.GetString("CurrentTypeDialog", resourceCulture);

	internal static string CurrentViewScaleDialog => ResourceManager.GetString("CurrentViewScaleDialog", resourceCulture);

	internal static string CurveIncrementParameter => ResourceManager.GetString("CurveIncrementParameter", resourceCulture);

	internal static string CustomUnit => ResourceManager.GetString("CustomUnit", resourceCulture);

	internal static string D_AMP_eleteVertexDialog => ResourceManager.GetString("D_AMP_eleteVertexDialog", resourceCulture);

	internal static string D_AMP_WGSymbolDialog => ResourceManager.GetString("D_AMP_WGSymbolDialog", resourceCulture);

	internal static string De_AMP_leteBreaklineDialog => ResourceManager.GetString("De_AMP_leteBreaklineDialog", resourceCulture);

	internal static string DefaultLineColor => ResourceManager.GetString("DefaultLineColor", resourceCulture);

	internal static string DeleteE_AMP_xistingElementDialog => ResourceManager.GetString("DeleteE_AMP_xistingElementDialog", resourceCulture);

	internal static string DeleteFromL_AMP_ampDialog => ResourceManager.GetString("DeleteFromL_AMP_ampDialog", resourceCulture);

	internal static string DeleteSiteComponentLineMessage => ResourceManager.GetString("DeleteSiteComponentLineMessage", resourceCulture);

	internal static string DeleteSiteComponentOption => ResourceManager.GetString("DeleteSiteComponentOption", resourceCulture);

	internal static string DescriptionGenericFamilyParameter => ResourceManager.GetString("DescriptionGenericFamilyParameter", resourceCulture);

	internal static string DescriptionPlantFamilyParameter => ResourceManager.GetString("DescriptionPlantFamilyParameter", resourceCulture);

	internal static string DestinationDialog => ResourceManager.GetString("DestinationDialog", resourceCulture);

	internal static string DestinationFamilyOverWrite => ResourceManager.GetString("DestinationFamilyOverWrite", resourceCulture);

	internal static string DestinationOverWrite => ResourceManager.GetString("DestinationOverWrite", resourceCulture);

	internal static string DestinationPlantFamilyParametersFormDialog => ResourceManager.GetString("DestinationPlantFamilyParametersFormDialog", resourceCulture);

	internal static string DetailFilledRegionElementName => ResourceManager.GetString("DetailFilledRegionElementName", resourceCulture);

	internal static string DifferentPhasingForBuildingPadsMessage => ResourceManager.GetString("DifferentPhasingForBuildingPadsMessage", resourceCulture);

	internal static string DisplayAnd_AMP_UseExistingHostLineDialog => ResourceManager.GetString("DisplayAnd_AMP_UseExistingHostLineDialog", resourceCulture);

	internal static string DistBetweenLinesString => ResourceManager.GetString("DistBetweenLinesString", resourceCulture);

	internal static string DuplicateEdgeString => ResourceManager.GetString("DuplicateEdgeString", resourceCulture);

	internal static string DuplicateFamilyInFamilyManagerMessage => ResourceManager.GetString("DuplicateFamilyInFamilyManagerMessage", resourceCulture);

	internal static string DuplicateFamilySymbolMessage => ResourceManager.GetString("DuplicateFamilySymbolMessage", resourceCulture);

	internal static string DuplicateTypeAppendMessage => ResourceManager.GetString("DuplicateTypeAppendMessage", resourceCulture);

	internal static string DuplicateTypeNameMessage => ResourceManager.GetString("DuplicateTypeNameMessage", resourceCulture);

	internal static string E_AMP_xportDialog => ResourceManager.GetString("E_AMP_xportDialog", resourceCulture);

	internal static string E_AMP_xportFamilyInformationDialog => ResourceManager.GetString("E_AMP_xportFamilyInformationDialog", resourceCulture);

	internal static string EaglePointLANDCADDForRevitDialog => ResourceManager.GetString("EaglePointLANDCADDForRevitDialog", resourceCulture);

	internal static string EastWestBasePointParameter => ResourceManager.GetString("EastWestBasePointParameter", resourceCulture);

	internal static string EdgePathWalkFamilyParameter => ResourceManager.GetString("EdgePathWalkFamilyParameter", resourceCulture);

	internal static string EdgeWidthPathWalkFamilyParameter => ResourceManager.GetString("EdgeWidthPathWalkFamilyParameter", resourceCulture);

	internal static string Ele_AMP_vationDialog => ResourceManager.GetString("Ele_AMP_vationDialog", resourceCulture);

	internal static string Elevatio_AMP_nRangeDialog => ResourceManager.GetString("Elevatio_AMP_nRangeDialog", resourceCulture);

	internal static string ElevationBasePointParameter => ResourceManager.GetString("ElevationBasePointParameter", resourceCulture);

	internal static string ElevationFamilyParameter => ResourceManager.GetString("ElevationFamilyParameter", resourceCulture);

	internal static string EndingEle_AMP_vationDialog => ResourceManager.GetString("EndingEle_AMP_vationDialog", resourceCulture);

	internal static string EndingElevationFamilyParameter => ResourceManager.GetString("EndingElevationFamilyParameter", resourceCulture);

	internal static string EndsWithComparator => ResourceManager.GetString("EndsWithComparator", resourceCulture);

	internal static string ENU_ImperialTemplateFolderName => ResourceManager.GetString("ENU-ImperialTemplateFolderName", resourceCulture);

	internal static string ENU_MetricTemplateFolderName => ResourceManager.GetString("ENU-MetricTemplateFolderName", resourceCulture);

	internal static string EqualComparator => ResourceManager.GetString("EqualComparator", resourceCulture);

	internal static string Error => ResourceManager.GetString("Error", resourceCulture);

	internal static string ErrorParsingXMLFileString => ResourceManager.GetString("ErrorParsingXMLFileString", resourceCulture);

	internal static string ExistingEle_AMP_mentDialog => ResourceManager.GetString("ExistingEle_AMP_mentDialog", resourceCulture);

	internal static string ExistingPlantsInProjDialog => ResourceManager.GetString("ExistingPlantsInProjDialog", resourceCulture);

	internal static string ExistingSymbolFileName => ResourceManager.GetString("ExistingSymbolFileName", resourceCulture);

	internal static string Export_AMP_AligmentsExportXMLDialog => ResourceManager.GetString("Export_AMP_AligmentsExportXMLDialog", resourceCulture);

	internal static string Export_AMP_RegionInformationDialog => ResourceManager.GetString("Export_AMP_RegionInformationDialog", resourceCulture);

	internal static string Export_AMP_TopoSurfacesExportXMLDialog => ResourceManager.GetString("Export_AMP_TopoSurfacesExportXMLDialog", resourceCulture);

	internal static string ExportAlignmentLandXMLCompleteString => ResourceManager.GetString("ExportAlignmentLandXMLCompleteString", resourceCulture);

	internal static string ExportCompleteMessage => ResourceManager.GetString("ExportCompleteMessage", resourceCulture);

	internal static string ExportLandXMLComponentsCompleteString => ResourceManager.GetString("ExportLandXMLComponentsCompleteString", resourceCulture);

	internal static string ExportLandXMLRibbonButton => ResourceManager.GetString("ExportLandXMLRibbonButton", resourceCulture);

	internal static string ExportLandXMLRibbonToolTip => ResourceManager.GetString("ExportLandXMLRibbonToolTip", resourceCulture);

	internal static string ExportLandXMLString => ResourceManager.GetString("ExportLandXMLString", resourceCulture);

	internal static string ExportOptionsDialog => ResourceManager.GetString("ExportOptionsDialog", resourceCulture);

	internal static string ExportSurfaceLandXMLCompleteString => ResourceManager.GetString("ExportSurfaceLandXMLCompleteString", resourceCulture);

	internal static string ExportType_AMP_InformationDialog => ResourceManager.GetString("ExportType_AMP_InformationDialog", resourceCulture);

	internal static string ExternalComponentExceptionMessage => ResourceManager.GetString("ExternalComponentExceptionMessage", resourceCulture);

	internal static string F_AMP_enceNameDialog => ResourceManager.GetString("F_AMP_enceNameDialog", resourceCulture);

	internal static string FailedCreatingSharedParameterMessage => ResourceManager.GetString("FailedCreatingSharedParameterMessage", resourceCulture);

	internal static string Family_AMP_Name_CopyFamilyDialog => ResourceManager.GetString("Family_AMP_Name_CopyFamilyDialog", resourceCulture);

	internal static string Family_AMP_Name_NewFamilyDialog => ResourceManager.GetString("Family_AMP_Name_NewFamilyDialog", resourceCulture);

	internal static string FamilyCannotbeLoadedPickanother_Message => ResourceManager.GetString("FamilyCannotbeLoadedPickanother_Message", resourceCulture);

	internal static string FamilyLoadedNotA_Message => ResourceManager.GetString("FamilyLoadedNotA_Message", resourceCulture);

	internal static string FamilyManagerLblCurbText => ResourceManager.GetString("FamilyManagerLblCurbText", resourceCulture);

	internal static string FamilyManagerLblParkingLotText => ResourceManager.GetString("FamilyManagerLblParkingLotText", resourceCulture);

	internal static string FamilyManagerLblRetainingWallText => ResourceManager.GetString("FamilyManagerLblRetainingWallText", resourceCulture);

	internal static string FamilyManagerLblSidewalkText => ResourceManager.GetString("FamilyManagerLblSidewalkText", resourceCulture);

	internal static string FamilyManagerLblSoftTerrainText => ResourceManager.GetString("FamilyManagerLblSoftTerrainText", resourceCulture);

	internal static string FamilyManagerLblStepsText => ResourceManager.GetString("FamilyManagerLblStepsText", resourceCulture);

	internal static string FamilyManagerLblStreetText => ResourceManager.GetString("FamilyManagerLblStreetText", resourceCulture);

	internal static string FamilyManagerRibbonPanel => ResourceManager.GetString("FamilyManagerRibbonPanel", resourceCulture);

	internal static string FamilyNameFamilyParameter => ResourceManager.GetString("FamilyNameFamilyParameter", resourceCulture);

	internal static string FamilyNameString => ResourceManager.GetString("FamilyNameString", resourceCulture);

	internal static string FamilyNotComponentMessage => ResourceManager.GetString("FamilyNotComponentMessage", resourceCulture);

	internal static string FamilyNotFenceMessage => ResourceManager.GetString("FamilyNotFenceMessage", resourceCulture);

	internal static string FamilyNotParkingMessage => ResourceManager.GetString("FamilyNotParkingMessage", resourceCulture);

	internal static string FamilyNotPlantingMessage => ResourceManager.GetString("FamilyNotPlantingMessage", resourceCulture);

	internal static string FamilyNotPlantingTagMessage => ResourceManager.GetString("FamilyNotPlantingTagMessage", resourceCulture);

	internal static string FamilyNotSoftTerrainMessage => ResourceManager.GetString("FamilyNotSoftTerrainMessage", resourceCulture);

	internal static string FamilyString => ResourceManager.GetString("FamilyString", resourceCulture);

	internal static string FamilySymbolNameFamilyParameter => ResourceManager.GetString("FamilySymbolNameFamilyParameter", resourceCulture);

	internal static string FamilySymbolOptionsDialog => ResourceManager.GetString("FamilySymbolOptionsDialog", resourceCulture);

	internal static string FamilyTemplatePath => ResourceManager.GetString("FamilyTemplatePath", resourceCulture);

	internal static string FamilyTypeString => ResourceManager.GetString("FamilyTypeString", resourceCulture);

	internal static string FeatureLineLineSubCategoryColor => ResourceManager.GetString("FeatureLineLineSubCategoryColor", resourceCulture);

	internal static string FeatureLineLineSubCategoryLineWeight => ResourceManager.GetString("FeatureLineLineSubCategoryLineWeight", resourceCulture);

	internal static string FeatureLineLineSubCategoryName => ResourceManager.GetString("FeatureLineLineSubCategoryName", resourceCulture);

	internal static string FeatureLineRibbonButton => ResourceManager.GetString("FeatureLineRibbonButton", resourceCulture);

	internal static string FeatureLineString => ResourceManager.GetString("FeatureLineString", resourceCulture);

	internal static string Fence_AMP_HeightDialog => ResourceManager.GetString("Fence_AMP_HeightDialog", resourceCulture);

	internal static string FenceError => ResourceManager.GetString("FenceError", resourceCulture);

	internal static string FenceFamilyAngleParameter => ResourceManager.GetString("FenceFamilyAngleParameter", resourceCulture);

	internal static string FenceFamilyCantBeLoadedMessage => ResourceManager.GetString("FenceFamilyCantBeLoadedMessage", resourceCulture);

	internal static string FenceFamilyHeightParameter => ResourceManager.GetString("FenceFamilyHeightParameter", resourceCulture);

	internal static string FenceFamilyNotLoadedMessage => ResourceManager.GetString("FenceFamilyNotLoadedMessage", resourceCulture);

	internal static string FenceFamilyNotLoadedWithIDMessage => ResourceManager.GetString("FenceFamilyNotLoadedWithIDMessage", resourceCulture);

	internal static string FenceFamilySpanParameter => ResourceManager.GetString("FenceFamilySpanParameter", resourceCulture);

	internal static string FenceLeftVisiability => ResourceManager.GetString("FenceLeftVisiability", resourceCulture);

	internal static string FenceRightVisiability => ResourceManager.GetString("FenceRightVisiability", resourceCulture);

	internal static string FenceS_AMP_panDialog => ResourceManager.GetString("FenceS_AMP_panDialog", resourceCulture);

	internal static string Fi_AMP_leDialog => ResourceManager.GetString("Fi_AMP_leDialog", resourceCulture);

	internal static string Fi_AMP_lterDialog => ResourceManager.GetString("Fi_AMP_lterDialog", resourceCulture);

	internal static string FieldsFoundWithLengthMessage => ResourceManager.GetString("FieldsFoundWithLengthMessage", resourceCulture);

	internal static string FileExistsOverwriteMessage => ResourceManager.GetString("FileExistsOverwriteMessage", resourceCulture);

	internal static string FileOverwriteMessage => ResourceManager.GetString("FileOverwriteMessage", resourceCulture);

	internal static string FilterString => ResourceManager.GetString("FilterString", resourceCulture);

	internal static string FindFamilySymbolsTransaction => ResourceManager.GetString("FindFamilySymbolsTransaction", resourceCulture);

	internal static string FineDetailLevel => ResourceManager.GetString("FineDetailLevel", resourceCulture);

	internal static string FrontViewDirection => ResourceManager.GetString("FrontViewDirection", resourceCulture);

	internal static string GeneralParametersTabString => ResourceManager.GetString("GeneralParametersTabString", resourceCulture);

	internal static string GeneralString => ResourceManager.GetString("GeneralString", resourceCulture);

	internal static string GenericImperialTemplate => ResourceManager.GetString("GenericImperialTemplate", resourceCulture);

	internal static string GenericMetricTemplate => ResourceManager.GetString("GenericMetricTemplate", resourceCulture);

	internal static string GenericModelLandcaddID_String => ResourceManager.GetString("GenericModelLandcaddID_String", resourceCulture);

	internal static string GenericModelSymbolPlantFamilyParameter => ResourceManager.GetString("GenericModelSymbolPlantFamilyParameter", resourceCulture);

	internal static string GetFamilyInformationTransaction => ResourceManager.GetString("GetFamilyInformationTransaction", resourceCulture);

	internal static string GetFamilyTypesTransaction => ResourceManager.GetString("GetFamilyTypesTransaction", resourceCulture);

	internal static string GetNewRevitVersionMessage => ResourceManager.GetString("GetNewRevitVersionMessage", resourceCulture);

	internal static string GetPlantSymbolTransaction => ResourceManager.GetString("GetPlantSymbolTransaction", resourceCulture);

	internal static string GreaterThanComparator => ResourceManager.GetString("GreaterThanComparator", resourceCulture);

	internal static string GreaterThanOrEqualToComparator => ResourceManager.GetString("GreaterThanOrEqualToComparator", resourceCulture);

	internal static string GroveRotationGenericFamilyParameter => ResourceManager.GetString("GroveRotationGenericFamilyParameter", resourceCulture);

	internal static string Growth => ResourceManager.GetString("Growth", resourceCulture);

	internal static string GrowthFormPlantFamilyParameter => ResourceManager.GetString("GrowthFormPlantFamilyParameter", resourceCulture);

	internal static string GrowthGrowthRatePlantFamilyParameter => ResourceManager.GetString("GrowthGrowthRatePlantFamilyParameter", resourceCulture);

	internal static string GrowthPatternPlantFamilyParameter => ResourceManager.GetString("GrowthPatternPlantFamilyParameter", resourceCulture);

	internal static string GrowthServiceLifePlantFamilyParameter => ResourceManager.GetString("GrowthServiceLifePlantFamilyParameter", resourceCulture);

	internal static string GrowthSimulationNoFamilyMessage => ResourceManager.GetString("GrowthSimulationNoFamilyMessage", resourceCulture);

	internal static string GrowthSimulationNoLandCaddFamilyMessage => ResourceManager.GetString("GrowthSimulationNoLandCaddFamilyMessage", resourceCulture);

	internal static string GrowthSimulationTransaction => ResourceManager.GetString("GrowthSimulationTransaction", resourceCulture);

	internal static string HeightGenericFamilyParameter => ResourceManager.GetString("HeightGenericFamilyParameter", resourceCulture);

	internal static string HeightPlantFamilyParameter => ResourceManager.GetString("HeightPlantFamilyParameter", resourceCulture);

	internal static string HeightVarianceGenericFamilyParameter => ResourceManager.GetString("HeightVarianceGenericFamilyParameter", resourceCulture);

	internal static string I_AMP_nvertColorsDialog => ResourceManager.GetString("I_AMP_nvertColorsDialog", resourceCulture);

	internal static string IDString => ResourceManager.GetString("IDString", resourceCulture);

	internal static string ImperialTemplateCabName => ResourceManager.GetString("ImperialTemplateCabName", resourceCulture);

	internal static string ImperialTemplatesDirectory => ResourceManager.GetString("ImperialTemplatesDirectory", resourceCulture);

	internal static string Import_AMP_AligmentsInXMLImportXMLDialog => ResourceManager.GetString("Import_AMP_AligmentsInXMLImportXMLDialog", resourceCulture);

	internal static string Import_AMP_ToposurfacesInXMLImportXMLDialog => ResourceManager.GetString("Import_AMP_ToposurfacesInXMLImportXMLDialog", resourceCulture);

	internal static string Import_AMP_UnitsDialog => ResourceManager.GetString("Import_AMP_UnitsDialog", resourceCulture);

	internal static string ImportDrawingTransaction => ResourceManager.GetString("ImportDrawingTransaction", resourceCulture);

	internal static string ImportDWGTitle => ResourceManager.GetString("ImportDWGTitle", resourceCulture);

	internal static string ImportExportRibbonPanel => ResourceManager.GetString("ImportExportRibbonPanel", resourceCulture);

	internal static string ImportFailedString => ResourceManager.GetString("ImportFailedString", resourceCulture);

	internal static string ImportingToposurfaceString => ResourceManager.GetString("ImportingToposurfaceString", resourceCulture);

	internal static string ImportLandTitleString => ResourceManager.GetString("ImportLandTitleString", resourceCulture);

	internal static string ImportLandXMLComponentsCompleteString => ResourceManager.GetString("ImportLandXMLComponentsCompleteString", resourceCulture);

	internal static string ImportLandXMLRibbonButton => ResourceManager.GetString("ImportLandXMLRibbonButton", resourceCulture);

	internal static string ImportLandXMLRibbonToolTip => ResourceManager.GetString("ImportLandXMLRibbonToolTip", resourceCulture);

	internal static string ImportLandXMLString => ResourceManager.GetString("ImportLandXMLString", resourceCulture);

	internal static string ImportString => ResourceManager.GetString("ImportString", resourceCulture);

	internal static string IncorrectFamilySymbolMessage => ResourceManager.GetString("IncorrectFamilySymbolMessage", resourceCulture);

	internal static string IncorrectLevelMessage => ResourceManager.GetString("IncorrectLevelMessage", resourceCulture);

	internal static string InformationString => ResourceManager.GetString("InformationString", resourceCulture);

	internal static string InstallUpdate1ToRunLANDCADDMessage => ResourceManager.GetString("InstallUpdate1ToRunLANDCADDMessage", resourceCulture);

	internal static string InstallUpdate1ToRunSiteworksMessage => ResourceManager.GetString("InstallUpdate1ToRunSiteworksMessage", resourceCulture);

	internal static string IntersectionDetectedMessage => ResourceManager.GetString("IntersectionDetectedMessage", resourceCulture);

	internal static string IntersectionLineSubCategoryColor => ResourceManager.GetString("IntersectionLineSubCategoryColor", resourceCulture);

	internal static string IntersectionLineSubCategoryLineWeight => ResourceManager.GetString("IntersectionLineSubCategoryLineWeight", resourceCulture);

	internal static string IntersectionLineSubCategoryName => ResourceManager.GetString("IntersectionLineSubCategoryName", resourceCulture);

	internal static string IntersectionSWStreetMass => ResourceManager.GetString("IntersectionSWStreetMass", resourceCulture);

	internal static string InvalidAgeMessage => ResourceManager.GetString("InvalidAgeMessage", resourceCulture);

	internal static string InvalidComponentSpacingMessage => ResourceManager.GetString("InvalidComponentSpacingMessage", resourceCulture);

	internal static string InvalidCutFillSlopeValue => ResourceManager.GetString("InvalidCutFillSlopeValue", resourceCulture);

	internal static string InvalidDirectoryMessage => ResourceManager.GetString("InvalidDirectoryMessage", resourceCulture);

	internal static string InvalidFamilyNameMessage => ResourceManager.GetString("InvalidFamilyNameMessage", resourceCulture);

	internal static string InvalidFenceHeightMessage => ResourceManager.GetString("InvalidFenceHeightMessage", resourceCulture);

	internal static string InvalidFileNameLocationMessageString => ResourceManager.GetString("InvalidFileNameLocationMessageString", resourceCulture);

	internal static string InvalidInputString => ResourceManager.GetString("InvalidInputString", resourceCulture);

	internal static string InValidNewFamily_Message => ResourceManager.GetString("InValidNewFamily_Message", resourceCulture);

	internal static string InvalidNumberOfLanesMessage => ResourceManager.GetString("InvalidNumberOfLanesMessage", resourceCulture);

	internal static string InvalidOffsetMessage => ResourceManager.GetString("InvalidOffsetMessage", resourceCulture);

	internal static string InvalidRadiusForStreetMessage => ResourceManager.GetString("InvalidRadiusForStreetMessage", resourceCulture);

	internal static string InvalidRadiusMessage => ResourceManager.GetString("InvalidRadiusMessage", resourceCulture);

	internal static string InvalidRadiusString => ResourceManager.GetString("InvalidRadiusString", resourceCulture);

	internal static string InvalidRadiusValueString => ResourceManager.GetString("InvalidRadiusValueString", resourceCulture);

	internal static string InvalidServiceLifeMessage => ResourceManager.GetString("InvalidServiceLifeMessage", resourceCulture);

	internal static string InvalidSetbackMessage => ResourceManager.GetString("InvalidSetbackMessage", resourceCulture);

	internal static string InvalidSlopeValue => ResourceManager.GetString("InvalidSlopeValue", resourceCulture);

	internal static string InvalidSpenceSpanMessage => ResourceManager.GetString("InvalidSpenceSpanMessage", resourceCulture);

	internal static string InvalidSurfaceNameString => ResourceManager.GetString("InvalidSurfaceNameString", resourceCulture);

	internal static string InvalidTypeNameMessage_ => ResourceManager.GetString("InvalidTypeNameMessage_", resourceCulture);

	internal static string InvalidViewForImportString => ResourceManager.GetString("InvalidViewForImportString", resourceCulture);

	internal static string InvalidXMLFileName => ResourceManager.GetString("InvalidXMLFileName", resourceCulture);

	internal static string InvertColorsColorMode => ResourceManager.GetString("InvertColorsColorMode", resourceCulture);

	internal static string IsBreaklineFamilyParameter => ResourceManager.GetString("IsBreaklineFamilyParameter", resourceCulture);

	internal static string IsFirstLegSegmentGenericFamilyParameter => ResourceManager.GetString("IsFirstLegSegmentGenericFamilyParameter", resourceCulture);

	internal static string IsFirstPlacementSegmentGenericFamilyParameter => ResourceManager.GetString("IsFirstPlacementSegmentGenericFamilyParameter", resourceCulture);

	internal static string IslandClosedChainMessage => ResourceManager.GetString("IslandClosedChainMessage", resourceCulture);

	internal static string IslandDialog => ResourceManager.GetString("IslandDialog", resourceCulture);

	internal static string IslandEclipsePickMessage => ResourceManager.GetString("IslandEclipsePickMessage", resourceCulture);

	internal static string IslandHeightGenericModelFamilyParameter => ResourceManager.GetString("IslandHeightGenericModelFamilyParameter", resourceCulture);

	internal static string IslandSurfaceIdFamilyParameter => ResourceManager.GetString("IslandSurfaceIdFamilyParameter", resourceCulture);

	internal static string IslandSymbolIDGenericFamilyParameter => ResourceManager.GetString("IslandSymbolIDGenericFamilyParameter", resourceCulture);

	internal static string IslandWidthGenericModelFamilyParameter => ResourceManager.GetString("IslandWidthGenericModelFamilyParameter", resourceCulture);

	internal static string IsLastLegSegmentGenericFamilyParameter => ResourceManager.GetString("IsLastLegSegmentGenericFamilyParameter", resourceCulture);

	internal static string IsoMetricViewDirection => ResourceManager.GetString("IsoMetricViewDirection", resourceCulture);

	internal static string IsPrimaryLeftParameter => ResourceManager.GetString("IsPrimaryLeftParameter", resourceCulture);

	internal static string IsProposedSurfaceFamilyParameter => ResourceManager.GetString("IsProposedSurfaceFamilyParameter", resourceCulture);

	internal static string IsReverseGenericFamilyParameter => ResourceManager.GetString("IsReverseGenericFamilyParameter", resourceCulture);

	internal static string IsSecondaryLeftParameter => ResourceManager.GetString("IsSecondaryLeftParameter", resourceCulture);

	internal static string IsSingleSegmentGenericFamilyParameter => ResourceManager.GetString("IsSingleSegmentGenericFamilyParameter", resourceCulture);

	internal static string IsStartingParameter => ResourceManager.GetString("IsStartingParameter", resourceCulture);

	internal static string KeynoteGenericFamilyParameter => ResourceManager.GetString("KeynoteGenericFamilyParameter", resourceCulture);

	internal static string KeynotePlantFamilyParameter => ResourceManager.GetString("KeynotePlantFamilyParameter", resourceCulture);

	internal static string LabelFamilyInstanceParameter => ResourceManager.GetString("LabelFamilyInstanceParameter", resourceCulture);

	internal static string LandcaddIDGenericModelFamilyParameter => ResourceManager.GetString("LandcaddIDGenericModelFamilyParameter", resourceCulture);

	internal static string LandcaddRibbonTab => ResourceManager.GetString("LandcaddRibbonTab", resourceCulture);

	internal static string LandcaddSitesRibbonTab => ResourceManager.GetString("LandcaddSitesRibbonTab", resourceCulture);

	internal static string LaunchPatioWalkFamilyManagerOption => ResourceManager.GetString("LaunchPatioWalkFamilyManagerOption", resourceCulture);

	internal static string LaunchPlantMixFamilyManagerOption => ResourceManager.GetString("LaunchPlantMixFamilyManagerOption", resourceCulture);

	internal static string LayerLevelColorsDialog => ResourceManager.GetString("LayerLevelColorsDialog", resourceCulture);

	internal static string Lea_AMP_deredTagDialog => ResourceManager.GetString("Lea_AMP_deredTagDialog", resourceCulture);

	internal static string LeftViewDirection => ResourceManager.GetString("LeftViewDirection", resourceCulture);

	internal static string LengthString => ResourceManager.GetString("LengthString", resourceCulture);

	internal static string LessThanComparator => ResourceManager.GetString("LessThanComparator", resourceCulture);

	internal static string LessThanOrEqualToComparator => ResourceManager.GetString("LessThanOrEqualToComparator", resourceCulture);

	internal static string LibraryPath => ResourceManager.GetString("LibraryPath", resourceCulture);

	internal static string LicenseBorrowedFromNetworkMessage => ResourceManager.GetString("LicenseBorrowedFromNetworkMessage", resourceCulture);

	internal static string LicenseBorrowedFromNetworkMessageError => ResourceManager.GetString("LicenseBorrowedFromNetworkMessageError", resourceCulture);

	internal static string LicenseReturnedToNetworkMessage => ResourceManager.GetString("LicenseReturnedToNetworkMessage", resourceCulture);

	internal static string LicensingRibbonPanel => ResourceManager.GetString("LicensingRibbonPanel", resourceCulture);

	internal static string Linear_AMP_PointIntervalDialog => ResourceManager.GetString("Linear_AMP_PointIntervalDialog", resourceCulture);

	internal static string LinearIncrementParameter => ResourceManager.GetString("LinearIncrementParameter", resourceCulture);

	internal static string LinearPointIntervalParameter => ResourceManager.GetString("LinearPointIntervalParameter", resourceCulture);

	internal static string LinearUnitfeetString_Lower => ResourceManager.GetString("LinearUnitfeetString_Lower", resourceCulture);

	internal static string LinearUnitFeetString_Upper => ResourceManager.GetString("LinearUnitFeetString_Upper", resourceCulture);

	internal static string LinearUnitfootString_Lower => ResourceManager.GetString("LinearUnitfootString_Lower", resourceCulture);

	internal static string LinearUnitFootString_Upper => ResourceManager.GetString("LinearUnitFootString_Upper", resourceCulture);

	internal static string LineSegmentsInsideBuildingPadMessage => ResourceManager.GetString("LineSegmentsInsideBuildingPadMessage", resourceCulture);

	internal static string LineSegmentsOutsideToposurfaceMessage => ResourceManager.GetString("LineSegmentsOutsideToposurfaceMessage", resourceCulture);

	internal static string LineSubCategoryLineWeight => ResourceManager.GetString("LineSubCategoryLineWeight", resourceCulture);

	internal static string LoadADAParkingFamilyTransaction => ResourceManager.GetString("LoadADAParkingFamilyTransaction", resourceCulture);

	internal static string LoadComponentFamilyTransaction => ResourceManager.GetString("LoadComponentFamilyTransaction", resourceCulture);

	internal static string LoadCurbFamilyTransaction => ResourceManager.GetString("LoadCurbFamilyTransaction", resourceCulture);

	internal static string LoadDefaultFamiliesOption => ResourceManager.GetString("LoadDefaultFamiliesOption", resourceCulture);

	internal static string LoadDefaultFamilyOption => ResourceManager.GetString("LoadDefaultFamilyOption", resourceCulture);

	internal static string LoadDrawingToolTip => ResourceManager.GetString("LoadDrawingToolTip", resourceCulture);

	internal static string LoadFamilyToolTip => ResourceManager.GetString("LoadFamilyToolTip", resourceCulture);

	internal static string LoadFenceFamilyTransaction => ResourceManager.GetString("LoadFenceFamilyTransaction", resourceCulture);

	internal static string LoadFileToolTip => ResourceManager.GetString("LoadFileToolTip", resourceCulture);

	internal static string LoadingFamilyProblemLoadNewMessage => ResourceManager.GetString("LoadingFamilyProblemLoadNewMessage", resourceCulture);

	internal static string LoadParkingBumperFamilyTransaction => ResourceManager.GetString("LoadParkingBumperFamilyTransaction", resourceCulture);

	internal static string LoadParkingFamilyTransaction => ResourceManager.GetString("LoadParkingFamilyTransaction", resourceCulture);

	internal static string LoadParkingIslandFamilyTransaction => ResourceManager.GetString("LoadParkingIslandFamilyTransaction", resourceCulture);

	internal static string LoadParkingLotFamilyTransaction => ResourceManager.GetString("LoadParkingLotFamilyTransaction", resourceCulture);

	internal static string LoadPatioWalkFamilyTransaction => ResourceManager.GetString("LoadPatioWalkFamilyTransaction", resourceCulture);

	internal static string LoadPlantFamilyTransaction => ResourceManager.GetString("LoadPlantFamilyTransaction", resourceCulture);

	internal static string LoadPlantingTagFamilyTransaction => ResourceManager.GetString("LoadPlantingTagFamilyTransaction", resourceCulture);

	internal static string LoadPlantMixFamilyTransaction => ResourceManager.GetString("LoadPlantMixFamilyTransaction", resourceCulture);

	internal static string LoadRetainingWallFamilyTransaction => ResourceManager.GetString("LoadRetainingWallFamilyTransaction", resourceCulture);

	internal static string LoadSidewalkFamilyTransaction => ResourceManager.GetString("LoadSidewalkFamilyTransaction", resourceCulture);

	internal static string LoadSoftTerrainFamilyTransaction => ResourceManager.GetString("LoadSoftTerrainFamilyTransaction", resourceCulture);

	internal static string LoadStreetFamilyTransaction => ResourceManager.GetString("LoadStreetFamilyTransaction", resourceCulture);

	internal static string LoadTopoPlacementFamilyTransaction => ResourceManager.GetString("LoadTopoPlacementFamilyTransaction", resourceCulture);

	internal static string LocateComponentsDialog => ResourceManager.GetString("LocateComponentsDialog", resourceCulture);

	internal static string LocateComponentsNoFamilyMessage => ResourceManager.GetString("LocateComponentsNoFamilyMessage", resourceCulture);

	internal static string LocateComponentsTransaction => ResourceManager.GetString("LocateComponentsTransaction", resourceCulture);

	internal static string LocateCurbDialog => ResourceManager.GetString("LocateCurbDialog", resourceCulture);

	internal static string LocateCurbRibbonButton => ResourceManager.GetString("LocateCurbRibbonButton", resourceCulture);

	internal static string LocateCurbRibbonToolTip => ResourceManager.GetString("LocateCurbRibbonToolTip", resourceCulture);

	internal static string LocateCurbRibbonToolTipLongDescription => ResourceManager.GetString("LocateCurbRibbonToolTipLongDescription", resourceCulture);

	internal static string LocateCurbTransaction => ResourceManager.GetString("LocateCurbTransaction", resourceCulture);

	internal static string LocateFeatureLineDialog => ResourceManager.GetString("LocateFeatureLineDialog", resourceCulture);

	internal static string LocateFeatureLineRibbonToolTip => ResourceManager.GetString("LocateFeatureLineRibbonToolTip", resourceCulture);

	internal static string LocateFeatureLineTransaction => ResourceManager.GetString("LocateFeatureLineTransaction", resourceCulture);

	internal static string LocateFenceDialog => ResourceManager.GetString("LocateFenceDialog", resourceCulture);

	internal static string LocateFenceTransaction => ResourceManager.GetString("LocateFenceTransaction", resourceCulture);

	internal static string LocateParkingLotDialog => ResourceManager.GetString("LocateParkingLotDialog", resourceCulture);

	internal static string LocateParkingLotRibbonButton => ResourceManager.GetString("LocateParkingLotRibbonButton", resourceCulture);

	internal static string LocateParkingLotRibbonToolTip => ResourceManager.GetString("LocateParkingLotRibbonToolTip", resourceCulture);

	internal static string LocateParkingLotRibbonToolTipLongDescription => ResourceManager.GetString("LocateParkingLotRibbonToolTipLongDescription", resourceCulture);

	internal static string LocateParkingLotTransaction => ResourceManager.GetString("LocateParkingLotTransaction", resourceCulture);

	internal static string LocatePlacementFamilyTransaction => ResourceManager.GetString("LocatePlacementFamilyTransaction", resourceCulture);

	internal static string LocatePlantsDialog => ResourceManager.GetString("LocatePlantsDialog", resourceCulture);

	internal static string LocatePlantSearchTitle => ResourceManager.GetString("LocatePlantSearchTitle", resourceCulture);

	internal static string LocatePlantsTransaction => ResourceManager.GetString("LocatePlantsTransaction", resourceCulture);

	internal static string LocatePointWipeoutDialog => ResourceManager.GetString("LocatePointWipeoutDialog", resourceCulture);

	internal static string LocatePointWipeoutRibbonToolTip => ResourceManager.GetString("LocatePointWipeoutRibbonToolTip", resourceCulture);

	internal static string LocatePointWipeoutTransaction => ResourceManager.GetString("LocatePointWipeoutTransaction", resourceCulture);

	internal static string LocateRetainingWallDialog => ResourceManager.GetString("LocateRetainingWallDialog", resourceCulture);

	internal static string LocateRetainingWallRibbonButton => ResourceManager.GetString("LocateRetainingWallRibbonButton", resourceCulture);

	internal static string LocateRetainingWallRibbonToolTip => ResourceManager.GetString("LocateRetainingWallRibbonToolTip", resourceCulture);

	internal static string LocateRetainingWallTransaction => ResourceManager.GetString("LocateRetainingWallTransaction", resourceCulture);

	internal static string LocateRibbonPanel => ResourceManager.GetString("LocateRibbonPanel", resourceCulture);

	internal static string LocateSidewalkDialog => ResourceManager.GetString("LocateSidewalkDialog", resourceCulture);

	internal static string LocateSidewalkRibbonButton => ResourceManager.GetString("LocateSidewalkRibbonButton", resourceCulture);

	internal static string LocateSidewalkRibbonToolTip => ResourceManager.GetString("LocateSidewalkRibbonToolTip", resourceCulture);

	internal static string LocateSidewalkRibbonToolTipLongDescription => ResourceManager.GetString("LocateSidewalkRibbonToolTipLongDescription", resourceCulture);

	internal static string LocateSidewalkTransaction => ResourceManager.GetString("LocateSidewalkTransaction", resourceCulture);

	internal static string LocateSoftTerrainDialog => ResourceManager.GetString("LocateSoftTerrainDialog", resourceCulture);

	internal static string LocateSoftTerrainRibbonButton => ResourceManager.GetString("LocateSoftTerrainRibbonButton", resourceCulture);

	internal static string LocateSoftTerrainRibbonToolTip => ResourceManager.GetString("LocateSoftTerrainRibbonToolTip", resourceCulture);

	internal static string LocateSoftTerrainRibbonToolTipLongDescription => ResourceManager.GetString("LocateSoftTerrainRibbonToolTipLongDescription", resourceCulture);

	internal static string LocateSoftTerrainTransaction => ResourceManager.GetString("LocateSoftTerrainTransaction", resourceCulture);

	internal static string LocateStreetDialog => ResourceManager.GetString("LocateStreetDialog", resourceCulture);

	internal static string LocateStreetRibbonButton => ResourceManager.GetString("LocateStreetRibbonButton", resourceCulture);

	internal static string LocateStreetRibbonToolTip => ResourceManager.GetString("LocateStreetRibbonToolTip", resourceCulture);

	internal static string LocateStreetTransaction => ResourceManager.GetString("LocateStreetTransaction", resourceCulture);

	internal static string LocateTypeGenericFamilyParameter => ResourceManager.GetString("LocateTypeGenericFamilyParameter", resourceCulture);

	internal static string M_AMP_odifyPlantWidthDialog => ResourceManager.GetString("M_AMP_odifyPlantWidthDialog", resourceCulture);

	internal static string Maintenance => ResourceManager.GetString("Maintenance", resourceCulture);

	internal static string MaintenanceDetrimentsPlantFamilyParameter => ResourceManager.GetString("MaintenanceDetrimentsPlantFamilyParameter", resourceCulture);

	internal static string MaintenanceFertilizingTimePlantFamilyParameter => ResourceManager.GetString("MaintenanceFertilizingTimePlantFamilyParameter", resourceCulture);

	internal static string MaintenancePlantingTimePlantFamilyParameter => ResourceManager.GetString("MaintenancePlantingTimePlantFamilyParameter", resourceCulture);

	internal static string MaintenancePruningTimePlantFamilyParameter => ResourceManager.GetString("MaintenancePruningTimePlantFamilyParameter", resourceCulture);

	internal static string MaintenanceTransplantingTimePlantFamilyParameter => ResourceManager.GetString("MaintenanceTransplantingTimePlantFamilyParameter", resourceCulture);

	internal static string MaintenanceTransplantPlantFamilyParameter => ResourceManager.GetString("MaintenanceTransplantPlantFamilyParameter", resourceCulture);

	internal static string MaintenanceWaterRequirementsPlantFamilyParameter => ResourceManager.GetString("MaintenanceWaterRequirementsPlantFamilyParameter", resourceCulture);

	internal static string ManageLicenseRibbonButton => ResourceManager.GetString("ManageLicenseRibbonButton", resourceCulture);

	internal static string ManageLicenseRibbonToolTip => ResourceManager.GetString("ManageLicenseRibbonToolTip", resourceCulture);

	internal static string ManagerDialog => ResourceManager.GetString("ManagerDialog", resourceCulture);

	internal static string ManufacturerGenericFamilyParameter => ResourceManager.GetString("ManufacturerGenericFamilyParameter", resourceCulture);

	internal static string ManufacturerPlantFamilyParameter => ResourceManager.GetString("ManufacturerPlantFamilyParameter", resourceCulture);

	internal static string MassBaseVolume => ResourceManager.GetString("MassBaseVolume", resourceCulture);

	internal static string MassCreationOnlyMode => ResourceManager.GetString("MassCreationOnlyMode", resourceCulture);

	internal static string MassCreationOnlyModeOnMessage => ResourceManager.GetString("MassCreationOnlyModeOnMessage", resourceCulture);

	internal static string MassCreationString => ResourceManager.GetString("MassCreationString", resourceCulture);

	internal static string MassGrossSurfaceAreaParameter => ResourceManager.GetString("MassGrossSurfaceAreaParameter", resourceCulture);

	internal static string MassGrossVolumeParameter => ResourceManager.GetString("MassGrossVolumeParameter", resourceCulture);

	internal static string MassImperialTemplate => ResourceManager.GetString("MassImperialTemplate", resourceCulture);

	internal static string MassingFamilyNameAlreadyUsedMessage => ResourceManager.GetString("MassingFamilyNameAlreadyUsedMessage", resourceCulture);

	internal static string MassMetricTemplate => ResourceManager.GetString("MassMetricTemplate", resourceCulture);

	internal static string MassSubBaseVolume => ResourceManager.GetString("MassSubBaseVolume", resourceCulture);

	internal static string MassTemplateFileNameString => ResourceManager.GetString("MassTemplateFileNameString", resourceCulture);

	internal static string MassTemplatesString => ResourceManager.GetString("MassTemplatesString", resourceCulture);

	internal static string MaterialPathWalkFamilyParameter => ResourceManager.GetString("MaterialPathWalkFamilyParameter", resourceCulture);

	internal static string MaterialString => ResourceManager.GetString("MaterialString", resourceCulture);

	internal static string MaximumString => ResourceManager.GetString("MaximumString", resourceCulture);

	internal static string MediumDetailLevel => ResourceManager.GetString("MediumDetailLevel", resourceCulture);

	internal static string MessagesDialog => ResourceManager.GetString("MessagesDialog", resourceCulture);

	internal static string MetricTemplateCabName => ResourceManager.GetString("MetricTemplateCabName", resourceCulture);

	internal static string MetricTemplatesDirectory => ResourceManager.GetString("MetricTemplatesDirectory", resourceCulture);

	internal static string MiddleStallPlacementGenericFamilyParameter => ResourceManager.GetString("MiddleStallPlacementGenericFamilyParameter", resourceCulture);

	internal static string MinimumValueIsMessage_ => ResourceManager.GetString("MinimumValueIsMessage_", resourceCulture);

	internal static string MissingSharedParametersMessage => ResourceManager.GetString("MissingSharedParametersMessage", resourceCulture);

	internal static string Mo_AMP_difyPlantWidthDialog => ResourceManager.GetString("Mo_AMP_difyPlantWidthDialog", resourceCulture);

	internal static string Mo_AMP_veDownDialog => ResourceManager.GetString("Mo_AMP_veDownDialog", resourceCulture);

	internal static string ModelGenericFamilyParameter => ResourceManager.GetString("ModelGenericFamilyParameter", resourceCulture);

	internal static string ModelPlantFamilyParameter => ResourceManager.GetString("ModelPlantFamilyParameter", resourceCulture);

	internal static string ModifyCurbDialog => ResourceManager.GetString("ModifyCurbDialog", resourceCulture);

	internal static string ModifyCurbRibbonButton => ResourceManager.GetString("ModifyCurbRibbonButton", resourceCulture);

	internal static string ModifyCurbRibbonToolTip => ResourceManager.GetString("ModifyCurbRibbonToolTip", resourceCulture);

	internal static string ModifyCurbRibbonToolTipLongDescription => ResourceManager.GetString("ModifyCurbRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifyDialog => ResourceManager.GetString("ModifyDialog", resourceCulture);

	internal static string ModifyFeatureLineDialog => ResourceManager.GetString("ModifyFeatureLineDialog", resourceCulture);

	internal static string ModifyFeatureLineRibbonToolTip => ResourceManager.GetString("ModifyFeatureLineRibbonToolTip", resourceCulture);

	internal static string ModifyFeatureLineRibbonToolTipLongDescription => ResourceManager.GetString("ModifyFeatureLineRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifyParkingLotDialog => ResourceManager.GetString("ModifyParkingLotDialog", resourceCulture);

	internal static string ModifyParkingLotRibbonButton => ResourceManager.GetString("ModifyParkingLotRibbonButton", resourceCulture);

	internal static string ModifyParkingLotRibbonToolTip => ResourceManager.GetString("ModifyParkingLotRibbonToolTip", resourceCulture);

	internal static string ModifyParkingLotRibbonToolTipLongDescription => ResourceManager.GetString("ModifyParkingLotRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifyPlantNoFamilyMessage => ResourceManager.GetString("ModifyPlantNoFamilyMessage", resourceCulture);

	internal static string ModifyPlantsDialog => ResourceManager.GetString("ModifyPlantsDialog", resourceCulture);

	internal static string ModifyPlantSearchTitle => ResourceManager.GetString("ModifyPlantSearchTitle", resourceCulture);

	internal static string ModifyPlantsInProjDialog => ResourceManager.GetString("ModifyPlantsInProjDialog", resourceCulture);

	internal static string ModifyPlantsTransaction => ResourceManager.GetString("ModifyPlantsTransaction", resourceCulture);

	internal static string ModifyPointWipeoutDialog => ResourceManager.GetString("ModifyPointWipeoutDialog", resourceCulture);

	internal static string ModifyPointWipeoutRibbonToolTip => ResourceManager.GetString("ModifyPointWipeoutRibbonToolTip", resourceCulture);

	internal static string ModifyPointWipeoutRibbonToolTipLongDescription => ResourceManager.GetString("ModifyPointWipeoutRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifyRetainingWallDialog => ResourceManager.GetString("ModifyRetainingWallDialog", resourceCulture);

	internal static string ModifyRetainingWallRibbonButton => ResourceManager.GetString("ModifyRetainingWallRibbonButton", resourceCulture);

	internal static string ModifyRetainingWallRibbonToolTip => ResourceManager.GetString("ModifyRetainingWallRibbonToolTip", resourceCulture);

	internal static string ModifyRetainingWallRibbonToolTipLongDescription => ResourceManager.GetString("ModifyRetainingWallRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifyRibbonPanel => ResourceManager.GetString("ModifyRibbonPanel", resourceCulture);

	internal static string ModifySidewalkDialog => ResourceManager.GetString("ModifySidewalkDialog", resourceCulture);

	internal static string ModifySidewalkRibbonButton => ResourceManager.GetString("ModifySidewalkRibbonButton", resourceCulture);

	internal static string ModifySidewalkRibbonToolTip => ResourceManager.GetString("ModifySidewalkRibbonToolTip", resourceCulture);

	internal static string ModifySidewalkRibbonToolTipLongDescription => ResourceManager.GetString("ModifySidewalkRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifySiteComponentInformationDialog => ResourceManager.GetString("ModifySiteComponentInformationDialog", resourceCulture);

	internal static string ModifySiteComponentTransaction => ResourceManager.GetString("ModifySiteComponentTransaction", resourceCulture);

	internal static string ModifySoftTerrainDialog => ResourceManager.GetString("ModifySoftTerrainDialog", resourceCulture);

	internal static string ModifySoftTerrainRibbonButton => ResourceManager.GetString("ModifySoftTerrainRibbonButton", resourceCulture);

	internal static string ModifySoftTerrainRibbonToolTip => ResourceManager.GetString("ModifySoftTerrainRibbonToolTip", resourceCulture);

	internal static string ModifySoftTerrainRibbonToolTipLongDescription => ResourceManager.GetString("ModifySoftTerrainRibbonToolTipLongDescription", resourceCulture);

	internal static string ModifyStepsDialog => ResourceManager.GetString("ModifyStepsDialog", resourceCulture);

	internal static string ModifyStreetDialog => ResourceManager.GetString("ModifyStreetDialog", resourceCulture);

	internal static string ModifyStreetRibbonButton => ResourceManager.GetString("ModifyStreetRibbonButton", resourceCulture);

	internal static string ModifyStreetRibbonToolTip => ResourceManager.GetString("ModifyStreetRibbonToolTip", resourceCulture);

	internal static string ModifyStreetRibbonToolTipLongDescription => ResourceManager.GetString("ModifyStreetRibbonToolTipLongDescription", resourceCulture);

	internal static string MowingStripPathWalkFamilyParameter => ResourceManager.GetString("MowingStripPathWalkFamilyParameter", resourceCulture);

	internal static string NameString => ResourceManager.GetString("NameString", resourceCulture);

	internal static string NameSubRegionParameter => ResourceManager.GetString("NameSubRegionParameter", resourceCulture);

	internal static string NeedEdgeMowingYes => ResourceManager.GetString("NeedEdgeMowingYes", resourceCulture);

	internal static string NeedValidEdgeWidth => ResourceManager.GetString("NeedValidEdgeWidth", resourceCulture);

	internal static string NeedValidInputFor_ => ResourceManager.GetString("NeedValidInputFor_", resourceCulture);

	internal static string NeedValidInputMessage => ResourceManager.GetString("NeedValidInputMessage", resourceCulture);

	internal static string NeedValidTypeName => ResourceManager.GetString("NeedValidTypeName", resourceCulture);

	internal static string New_ => ResourceManager.GetString("New_", resourceCulture);

	internal static string New_AMP_TypeDialog => ResourceManager.GetString("New_AMP_TypeDialog", resourceCulture);

	internal static string NewConstructionString => ResourceManager.GetString("NewConstructionString", resourceCulture);

	internal static string NewCurb => ResourceManager.GetString("NewCurb", resourceCulture);

	internal static string NewerVersionAvailableForDownloadDialog => ResourceManager.GetString("NewerVersionAvailableForDownloadDialog", resourceCulture);

	internal static string NewFami_AMP_lySymbolDialog => ResourceManager.GetString("NewFami_AMP_lySymbolDialog", resourceCulture);

	internal static string NewFamilyToolTip => ResourceManager.GetString("NewFamilyToolTip", resourceCulture);

	internal static string NewParkingLot => ResourceManager.GetString("NewParkingLot", resourceCulture);

	internal static string NewRetainingWall => ResourceManager.GetString("NewRetainingWall", resourceCulture);

	internal static string NewSidewalk => ResourceManager.GetString("NewSidewalk", resourceCulture);

	internal static string NewSoftTerrain => ResourceManager.GetString("NewSoftTerrain", resourceCulture);

	internal static string NewStreet => ResourceManager.GetString("NewStreet", resourceCulture);

	internal static string NoAlignmentInLandXMLString => ResourceManager.GetString("NoAlignmentInLandXMLString", resourceCulture);

	internal static string NoAlignmentInProjectString => ResourceManager.GetString("NoAlignmentInProjectString", resourceCulture);

	internal static string NoAlignmentSelectedToExportString => ResourceManager.GetString("NoAlignmentSelectedToExportString", resourceCulture);

	internal static string NoAlignmentToExportString => ResourceManager.GetString("NoAlignmentToExportString", resourceCulture);

	internal static string NoAreaSpacingMethod => ResourceManager.GetString("NoAreaSpacingMethod", resourceCulture);

	internal static string NoComponentSpacingMessage => ResourceManager.GetString("NoComponentSpacingMessage", resourceCulture);

	internal static string NoCSVTXT => ResourceManager.GetString("NoCSVTXT", resourceCulture);

	internal static string NoEdgingYesMowingMessage => ResourceManager.GetString("NoEdgingYesMowingMessage", resourceCulture);

	internal static string NoExistingSurfacesString => ResourceManager.GetString("NoExistingSurfacesString", resourceCulture);

	internal static string NoExportOptionsSelectedString => ResourceManager.GetString("NoExportOptionsSelectedString", resourceCulture);

	internal static string NoFamiliesGenericCreateMessage => ResourceManager.GetString("NoFamiliesGenericCreateMessage", resourceCulture);

	internal static string NoFamiliesGenericMessage => ResourceManager.GetString("NoFamiliesGenericMessage", resourceCulture);

	internal static string NoFamiliesSitesMessage => ResourceManager.GetString("NoFamiliesSitesMessage", resourceCulture);

	internal static string NoFamilySelectedMessage => ResourceManager.GetString("NoFamilySelectedMessage", resourceCulture);

	internal static string NoFenceHeightMessage => ResourceManager.GetString("NoFenceHeightMessage", resourceCulture);

	internal static string NoFenceSpanMessage => ResourceManager.GetString("NoFenceSpanMessage", resourceCulture);

	internal static string NoGenericModelRFTMessage => ResourceManager.GetString("NoGenericModelRFTMessage", resourceCulture);

	internal static string NoImportOptionsSelectedString => ResourceManager.GetString("NoImportOptionsSelectedString", resourceCulture);

	internal static string NoIslandOnArcMessage => ResourceManager.GetString("NoIslandOnArcMessage", resourceCulture);

	internal static string NoLinearFootageMessage => ResourceManager.GetString("NoLinearFootageMessage", resourceCulture);

	internal static string NoMassRFTMessage => ResourceManager.GetString("NoMassRFTMessage", resourceCulture);

	internal static string NoObject => ResourceManager.GetString("NoObject", resourceCulture);

	internal static string NoOptionsSelectedMessage => ResourceManager.GetString("NoOptionsSelectedMessage", resourceCulture);

	internal static string NoParkingSpacesOnArc => ResourceManager.GetString("NoParkingSpacesOnArc", resourceCulture);

	internal static string NoPatioWalkSelected => ResourceManager.GetString("NoPatioWalkSelected", resourceCulture);

	internal static string NoPlantingRFTMessage => ResourceManager.GetString("NoPlantingRFTMessage", resourceCulture);

	internal static string NoPlantsFoundMessage => ResourceManager.GetString("NoPlantsFoundMessage", resourceCulture);

	internal static string NoPlantsMatchingCriteriaMessage => ResourceManager.GetString("NoPlantsMatchingCriteriaMessage", resourceCulture);

	internal static string NoPlantsSelected => ResourceManager.GetString("NoPlantsSelected", resourceCulture);

	internal static string NoPlantSymbolSelectedMessage => ResourceManager.GetString("NoPlantSymbolSelectedMessage", resourceCulture);

	internal static string NoPlantTypePickedMessage => ResourceManager.GetString("NoPlantTypePickedMessage", resourceCulture);

	internal static string NoPointPickedMessage => ResourceManager.GetString("NoPointPickedMessage", resourceCulture);

	internal static string NoPointsFoundMessage => ResourceManager.GetString("NoPointsFoundMessage", resourceCulture);

	internal static string NoPreviousPositionAvailableMessage => ResourceManager.GetString("NoPreviousPositionAvailableMessage", resourceCulture);

	internal static string NoProjectMessage => ResourceManager.GetString("NoProjectMessage", resourceCulture);

	internal static string NoRegion => ResourceManager.GetString("NoRegion", resourceCulture);

	internal static string NoRFAExtension => ResourceManager.GetString("NoRFAExtension", resourceCulture);

	internal static string NoRFAExtforDestinationMessage => ResourceManager.GetString("NoRFAExtforDestinationMessage", resourceCulture);

	internal static string NorthSouthBasePointParameter => ResourceManager.GetString("NorthSouthBasePointParameter", resourceCulture);

	internal static string NoSelectionMadeMessage => ResourceManager.GetString("NoSelectionMadeMessage", resourceCulture);

	internal static string NoSetbackMessage => ResourceManager.GetString("NoSetbackMessage", resourceCulture);

	internal static string NoSiteComponentsInProjectMessage => ResourceManager.GetString("NoSiteComponentsInProjectMessage", resourceCulture);

	internal static string NoSiteRFTMessage => ResourceManager.GetString("NoSiteRFTMessage", resourceCulture);

	internal static string NoString => ResourceManager.GetString("NoString", resourceCulture);

	internal static string NoSurfacesInLandXMLString => ResourceManager.GetString("NoSurfacesInLandXMLString", resourceCulture);

	internal static string NoSurfacesInProjectString => ResourceManager.GetString("NoSurfacesInProjectString", resourceCulture);

	internal static string NoSurfacesSelectedMessage => ResourceManager.GetString("NoSurfacesSelectedMessage", resourceCulture);

	internal static string NoSurfacesSelectedToExportString => ResourceManager.GetString("NoSurfacesSelectedToExportString", resourceCulture);

	internal static string NoSurfacesToExportString => ResourceManager.GetString("NoSurfacesToExportString", resourceCulture);

	internal static string NoTag => ResourceManager.GetString("NoTag", resourceCulture);

	internal static string NotAllObjectsAppearDialog => ResourceManager.GetString("NotAllObjectsAppearDialog", resourceCulture);

	internal static string NotAvailableString => ResourceManager.GetString("NotAvailableString", resourceCulture);

	internal static string NotEqualComparator => ResourceManager.GetString("NotEqualComparator", resourceCulture);

	internal static string NoToposurfaceCanBeModifiedMessage => ResourceManager.GetString("NoToposurfaceCanBeModifiedMessage", resourceCulture);

	internal static string NotSiteComponentHostLineMessage => ResourceManager.GetString("NotSiteComponentHostLineMessage", resourceCulture);

	internal static string NotSiteComponentMessage_ => ResourceManager.GetString("NotSiteComponentMessage_", resourceCulture);

	internal static string NotValidLANDCADDPatioWalkFamilyMessage => ResourceManager.GetString("NotValidLANDCADDPatioWalkFamilyMessage", resourceCulture);

	internal static string NotValidLANDCADDPlantMixFamilyMessage => ResourceManager.GetString("NotValidLANDCADDPlantMixFamilyMessage", resourceCulture);

	internal static string NoTypeSelectedMessage => ResourceManager.GetString("NoTypeSelectedMessage", resourceCulture);

	internal static string NoXMLExtension => ResourceManager.GetString("NoXMLExtension", resourceCulture);

	internal static string Nu_AMP_mberOfSpacesDialog => ResourceManager.GetString("Nu_AMP_mberOfSpacesDialog", resourceCulture);

	internal static string NumberOfPntsString => ResourceManager.GetString("NumberOfPntsString", resourceCulture);

	internal static string O_AMP_riginToOriginDialog => ResourceManager.GetString("O_AMP_riginToOriginDialog", resourceCulture);

	internal static string ObjectNotSupportConvertPlantMessage => ResourceManager.GetString("ObjectNotSupportConvertPlantMessage", resourceCulture);

	internal static string ObjectNotSupportedForPlantsMessage => ResourceManager.GetString("ObjectNotSupportedForPlantsMessage", resourceCulture);

	internal static string ObjectNotSupportforModifyingPlantMessage => ResourceManager.GetString("ObjectNotSupportforModifyingPlantMessage", resourceCulture);

	internal static string ObjectPickedPlantMessage => ResourceManager.GetString("ObjectPickedPlantMessage", resourceCulture);

	internal static string ObjectSelectedNotOnSideMessage => ResourceManager.GetString("ObjectSelectedNotOnSideMessage", resourceCulture);

	internal static string ObjectSelectedNotSupportedMessage => ResourceManager.GetString("ObjectSelectedNotSupportedMessage", resourceCulture);

	internal static string ObjectSelectedNotSupportedPlantingMessage => ResourceManager.GetString("ObjectSelectedNotSupportedPlantingMessage", resourceCulture);

	internal static string ObjectSelectedNotToposurfaceMessage => ResourceManager.GetString("ObjectSelectedNotToposurfaceMessage", resourceCulture);

	internal static string ObtainDrawingImageTransaction => ResourceManager.GetString("ObtainDrawingImageTransaction", resourceCulture);

	internal static string OmniClassNumberPlantParameter => ResourceManager.GetString("OmniClassNumberPlantParameter", resourceCulture);

	internal static string OmniClassTitlePlantParameter => ResourceManager.GetString("OmniClassTitlePlantParameter", resourceCulture);

	internal static string OptimizeParkingGenericModelFamilyParameter => ResourceManager.GetString("OptimizeParkingGenericModelFamilyParameter", resourceCulture);

	internal static string OriginToOriginPlacement => ResourceManager.GetString("OriginToOriginPlacement", resourceCulture);

	internal static string Others => ResourceManager.GetString("Others", resourceCulture);

	internal static string OutOfRangeArgumentMessage => ResourceManager.GetString("OutOfRangeArgumentMessage", resourceCulture);

	internal static string OverWrite_Message => ResourceManager.GetString("OverWrite_Message", resourceCulture);

	internal static string OverwriteMessage => ResourceManager.GetString("OverwriteMessage", resourceCulture);

	internal static string OverwriteToposurfaceOption => ResourceManager.GetString("OverwriteToposurfaceOption", resourceCulture);

	internal static string P_AMP_lantNameDialog => ResourceManager.GetString("P_AMP_lantNameDialog", resourceCulture);

	internal static string Par_AMP_kingLotTypeDialog => ResourceManager.GetString("Par_AMP_kingLotTypeDialog", resourceCulture);

	internal static string Parameter => ResourceManager.GetString("Parameter", resourceCulture);

	internal static string ParameterNotSelectedMessage => ResourceManager.GetString("ParameterNotSelectedMessage", resourceCulture);

	internal static string ParameterString => ResourceManager.GetString("ParameterString", resourceCulture);

	internal static string ParametersUsedDialog => ResourceManager.GetString("ParametersUsedDialog", resourceCulture);

	internal static string ParentSurfaceIDFamilyParameter => ResourceManager.GetString("ParentSurfaceIDFamilyParameter", resourceCulture);

	internal static string Parki_AMP_ngLotNameDialog => ResourceManager.GetString("Parki_AMP_ngLotNameDialog", resourceCulture);

	internal static string ParkingFamiliesNotLoadedMessage => ResourceManager.GetString("ParkingFamiliesNotLoadedMessage", resourceCulture);

	internal static string ParkingFamilyCantBeLoadedMessage => ResourceManager.GetString("ParkingFamilyCantBeLoadedMessage", resourceCulture);

	internal static string ParkingFamilyNotLoadedMessage => ResourceManager.GetString("ParkingFamilyNotLoadedMessage", resourceCulture);

	internal static string ParkingLotAreaSettingsDialog => ResourceManager.GetString("ParkingLotAreaSettingsDialog", resourceCulture);

	internal static string ParkingLotBoundaryClosedChainMessage => ResourceManager.GetString("ParkingLotBoundaryClosedChainMessage", resourceCulture);

	internal static string ParkingLotDialog => ResourceManager.GetString("ParkingLotDialog", resourceCulture);

	internal static string ParkingLotFamilyManagerRibbonButton => ResourceManager.GetString("ParkingLotFamilyManagerRibbonButton", resourceCulture);

	internal static string ParkingLotFamilyManagerToolTip => ResourceManager.GetString("ParkingLotFamilyManagerToolTip", resourceCulture);

	internal static string ParkingLotFamilyNotLoadedMessage => ResourceManager.GetString("ParkingLotFamilyNotLoadedMessage", resourceCulture);

	internal static string ParkingLotIslandToposurfaceMaterialParameter => ResourceManager.GetString("ParkingLotIslandToposurfaceMaterialParameter", resourceCulture);

	internal static string ParkingLotLineSubCategoryColor => ResourceManager.GetString("ParkingLotLineSubCategoryColor", resourceCulture);

	internal static string ParkingLotLineSubCategoryLineWeight => ResourceManager.GetString("ParkingLotLineSubCategoryLineWeight", resourceCulture);

	internal static string ParkingLotLineSubCategoryName => ResourceManager.GetString("ParkingLotLineSubCategoryName", resourceCulture);

	internal static string ParkingLotManagerString => ResourceManager.GetString("ParkingLotManagerString", resourceCulture);

	internal static string ParkingLotParkingBaseDepthParameter => ResourceManager.GetString("ParkingLotParkingBaseDepthParameter", resourceCulture);

	internal static string ParkingLotParkingPavementSurfaceParameter => ResourceManager.GetString("ParkingLotParkingPavementSurfaceParameter", resourceCulture);

	internal static string ParkingLotParkingSubBaseDepthParameter => ResourceManager.GetString("ParkingLotParkingSubBaseDepthParameter", resourceCulture);

	internal static string ParkingLotPavementDepthParameter => ResourceManager.GetString("ParkingLotPavementDepthParameter", resourceCulture);

	internal static string ParkingLotString => ResourceManager.GetString("ParkingLotString", resourceCulture);

	internal static string ParkingLotSurfaceIDFamilyParameter => ResourceManager.GetString("ParkingLotSurfaceIDFamilyParameter", resourceCulture);

	internal static string ParkingLotTransaction => ResourceManager.GetString("ParkingLotTransaction", resourceCulture);

	internal static string ParkingNotObjectSelectedMessage => ResourceManager.GetString("ParkingNotObjectSelectedMessage", resourceCulture);

	internal static string ParkingPlacementDialog => ResourceManager.GetString("ParkingPlacementDialog", resourceCulture);

	internal static string ParkingStyleDialog => ResourceManager.GetString("ParkingStyleDialog", resourceCulture);

	internal static string Path => ResourceManager.GetString("Path", resourceCulture);

	internal static string PathWalkDialog => ResourceManager.GetString("PathWalkDialog", resourceCulture);

	internal static string PathWalkFamilyDialog => ResourceManager.GetString("PathWalkFamilyDialog", resourceCulture);

	internal static string PatioWalkFamilyManagerRibbonButton => ResourceManager.GetString("PatioWalkFamilyManagerRibbonButton", resourceCulture);

	internal static string PatioWalkFamilyNotLoadedMessage => ResourceManager.GetString("PatioWalkFamilyNotLoadedMessage", resourceCulture);

	internal static string PatioWalkReportDialog => ResourceManager.GetString("PatioWalkReportDialog", resourceCulture);

	internal static string PatiowalkReportNoFamilyMessage => ResourceManager.GetString("PatiowalkReportNoFamilyMessage", resourceCulture);

	internal static string PatioWalkString => ResourceManager.GetString("PatioWalkString", resourceCulture);

	internal static string PercentageError => ResourceManager.GetString("PercentageError", resourceCulture);

	internal static string PercentagePlantMixFamilyParameter => ResourceManager.GetString("PercentagePlantMixFamilyParameter", resourceCulture);

	internal static string PhaseCreatedDialog => ResourceManager.GetString("PhaseCreatedDialog", resourceCulture);

	internal static string Pic_AMP_kPlantDialog => ResourceManager.GetString("Pic_AMP_kPlantDialog", resourceCulture);

	internal static string Pick_AMP_Toposurface => ResourceManager.GetString("Pick_AMP_Toposurface", resourceCulture);

	internal static string PickAddVertexPointPrompt => ResourceManager.GetString("PickAddVertexPointPrompt", resourceCulture);

	internal static string PickCenterPointPrompt => ResourceManager.GetString("PickCenterPointPrompt", resourceCulture);

	internal static string PickCircleMessage => ResourceManager.GetString("PickCircleMessage", resourceCulture);

	internal static string PickClosedBoundaryMessage => ResourceManager.GetString("PickClosedBoundaryMessage", resourceCulture);

	internal static string PickDeleteVertexPointPrompt => ResourceManager.GetString("PickDeleteVertexPointPrompt", resourceCulture);

	internal static string PickElevationGradePointPrompt => ResourceManager.GetString("PickElevationGradePointPrompt", resourceCulture);

	internal static string PickEndPointPrompt => ResourceManager.GetString("PickEndPointPrompt", resourceCulture);

	internal static string PickFirstPointForRotationPrompt => ResourceManager.GetString("PickFirstPointForRotationPrompt", resourceCulture);

	internal static string PickIslandsMessage => ResourceManager.GetString("PickIslandsMessage", resourceCulture);

	internal static string PickLeaderElbowPointPrompt => ResourceManager.GetString("PickLeaderElbowPointPrompt", resourceCulture);

	internal static string PickLeaderStartPointPrompt => ResourceManager.GetString("PickLeaderStartPointPrompt", resourceCulture);

	internal static string PickObjectMessage => ResourceManager.GetString("PickObjectMessage", resourceCulture);

	internal static string PickOffsetSideMessage => ResourceManager.GetString("PickOffsetSideMessage", resourceCulture);

	internal static string PickPlantMessage => ResourceManager.GetString("PickPlantMessage", resourceCulture);

	internal static string PickPlantsMessage => ResourceManager.GetString("PickPlantsMessage", resourceCulture);

	internal static string PickPlantTagMessage => ResourceManager.GetString("PickPlantTagMessage", resourceCulture);

	internal static string PickPointElevationToolTip => ResourceManager.GetString("PickPointElevationToolTip", resourceCulture);

	internal static string PickPointPrompt => ResourceManager.GetString("PickPointPrompt", resourceCulture);

	internal static string PickPointsForBoundaryPrompt => ResourceManager.GetString("PickPointsForBoundaryPrompt", resourceCulture);

	internal static string PickRegionSubRegionMessage => ResourceManager.GetString("PickRegionSubRegionMessage", resourceCulture);

	internal static string PickRotationPointPrompt => ResourceManager.GetString("PickRotationPointPrompt", resourceCulture);

	internal static string PickSecondPointForRotationPrompt => ResourceManager.GetString("PickSecondPointForRotationPrompt", resourceCulture);

	internal static string PickSideForFaceOfCurbMessage => ResourceManager.GetString("PickSideForFaceOfCurbMessage", resourceCulture);

	internal static string PickSideForGradeToPlaceMessage => ResourceManager.GetString("PickSideForGradeToPlaceMessage", resourceCulture);

	internal static string PickSiteComponentLineMessage => ResourceManager.GetString("PickSiteComponentLineMessage", resourceCulture);

	internal static string PickStartingDirectionMessage => ResourceManager.GetString("PickStartingDirectionMessage", resourceCulture);

	internal static string PickStartingSideMessage => ResourceManager.GetString("PickStartingSideMessage", resourceCulture);

	internal static string PickStartPointPrompt => ResourceManager.GetString("PickStartPointPrompt", resourceCulture);

	internal static string PickTagPointPrompt => ResourceManager.GetString("PickTagPointPrompt", resourceCulture);

	internal static string PickToposurfaceInformationDialog => ResourceManager.GetString("PickToposurfaceInformationDialog", resourceCulture);

	internal static string PickToposurfacePrompt => ResourceManager.GetString("PickToposurfacePrompt", resourceCulture);

	internal static string PickToposurfacesPrompt => ResourceManager.GetString("PickToposurfacesPrompt", resourceCulture);

	internal static string PickViewOptionForMassMessage => ResourceManager.GetString("PickViewOptionForMassMessage", resourceCulture);

	internal static string Plac_AMP_eAtLevelDialog => ResourceManager.GetString("Plac_AMP_eAtLevelDialog", resourceCulture);

	internal static string Place_AMP_ADAParkingSpacesDialog => ResourceManager.GetString("Place_AMP_ADAParkingSpacesDialog", resourceCulture);

	internal static string Place_AMP_BumpersDialog => ResourceManager.GetString("Place_AMP_BumpersDialog", resourceCulture);

	internal static string Place_AMP_IslandsDialog => ResourceManager.GetString("Place_AMP_IslandsDialog", resourceCulture);

	internal static string PlaceBumperGenericModelFamilyParameter => ResourceManager.GetString("PlaceBumperGenericModelFamilyParameter", resourceCulture);

	internal static string PlaceIn_AMP_AreaDialog => ResourceManager.GetString("PlaceIn_AMP_AreaDialog", resourceCulture);

	internal static string PlaceIslandGenericModelFamilyParameter => ResourceManager.GetString("PlaceIslandGenericModelFamilyParameter", resourceCulture);

	internal static string PlacementFamilyNotLoadedMessage => ResourceManager.GetString("PlacementFamilyNotLoadedMessage", resourceCulture);

	internal static string PlacementIDFamilyParameter => ResourceManager.GetString("PlacementIDFamilyParameter", resourceCulture);

	internal static string PlacementTypeGenericFamilyParameter => ResourceManager.GetString("PlacementTypeGenericFamilyParameter", resourceCulture);

	internal static string PlaceTagDialog => ResourceManager.GetString("PlaceTagDialog", resourceCulture);

	internal static string PlacingStallMessage => ResourceManager.GetString("PlacingStallMessage", resourceCulture);

	internal static string Plan_AMP_tSpacingDialog => ResourceManager.GetString("Plan_AMP_tSpacingDialog", resourceCulture);

	internal static string Plant => ResourceManager.GetString("Plant", resourceCulture);

	internal static string Plant_AMP_FamilyDialog => ResourceManager.GetString("Plant_AMP_FamilyDialog", resourceCulture);

	internal static string Plant_AMP_HeightDialog => ResourceManager.GetString("Plant_AMP_HeightDialog", resourceCulture);

	internal static string Plant_AMP_NameDialog => ResourceManager.GetString("Plant_AMP_NameDialog", resourceCulture);

	internal static string Plant_AMP_WidthDialog => ResourceManager.GetString("Plant_AMP_WidthDialog", resourceCulture);

	internal static string PlantAlreadyPickedMessage => ResourceManager.GetString("PlantAlreadyPickedMessage", resourceCulture);

	internal static string PlantBookletDialog => ResourceManager.GetString("PlantBookletDialog", resourceCulture);

	internal static string PlantBookletNoFamilyMessage => ResourceManager.GetString("PlantBookletNoFamilyMessage", resourceCulture);

	internal static string PlantClimateAndZonePlantFamilyParameter => ResourceManager.GetString("PlantClimateAndZonePlantFamilyParameter", resourceCulture);

	internal static string PlantCodeNamePlantFamilyParameter => ResourceManager.GetString("PlantCodeNamePlantFamilyParameter", resourceCulture);

	internal static string PlantCommentsPlantFamilyParameter => ResourceManager.GetString("PlantCommentsPlantFamilyParameter", resourceCulture);

	internal static string PlantCommonNamePlantFamilyParameter => ResourceManager.GetString("PlantCommonNamePlantFamilyParameter", resourceCulture);

	internal static string PlantCountPlantFamilyParameter => ResourceManager.GetString("PlantCountPlantFamilyParameter", resourceCulture);

	internal static string PlantDialog => ResourceManager.GetString("PlantDialog", resourceCulture);

	internal static string PlantDWGCreatorDialog => ResourceManager.GetString("PlantDWGCreatorDialog", resourceCulture);

	internal static string PlantExportDialog => ResourceManager.GetString("PlantExportDialog", resourceCulture);

	internal static string PlantFamilyManagerDialog => ResourceManager.GetString("PlantFamilyManagerDialog", resourceCulture);

	internal static string PlantGrowthAgeDialog => ResourceManager.GetString("PlantGrowthAgeDialog", resourceCulture);

	internal static string PlantGrowthDialog => ResourceManager.GetString("PlantGrowthDialog", resourceCulture);

	internal static string PlantGrowthSimulationDialog => ResourceManager.GetString("PlantGrowthSimulationDialog", resourceCulture);

	internal static string PlantHeightPlantFamilyParameter => ResourceManager.GetString("PlantHeightPlantFamilyParameter", resourceCulture);

	internal static string PlantingDefinitionGroup => ResourceManager.GetString("PlantingDefinitionGroup", resourceCulture);

	internal static string PlantingFamilyCantBeLoadedMessage => ResourceManager.GetString("PlantingFamilyCantBeLoadedMessage", resourceCulture);

	internal static string PlantingFamilyNotLoadedMessage => ResourceManager.GetString("PlantingFamilyNotLoadedMessage", resourceCulture);

	internal static string PlantingImperialTemplate => ResourceManager.GetString("PlantingImperialTemplate", resourceCulture);

	internal static string PlantingMetricTemplate => ResourceManager.GetString("PlantingMetricTemplate", resourceCulture);

	internal static string PlantingSizePlantFamilyParameter => ResourceManager.GetString("PlantingSizePlantFamilyParameter", resourceCulture);

	internal static string PlantingSymbolPlantFamilyParameter => ResourceManager.GetString("PlantingSymbolPlantFamilyParameter", resourceCulture);

	internal static string PlantingTagFamiliesNotLoadedMessage => ResourceManager.GetString("PlantingTagFamiliesNotLoadedMessage", resourceCulture);

	internal static string PlantMixDialog => ResourceManager.GetString("PlantMixDialog", resourceCulture);

	internal static string PlantMixFamilyDialog => ResourceManager.GetString("PlantMixFamilyDialog", resourceCulture);

	internal static string PlantMixFamilyManagerRibbonButton => ResourceManager.GetString("PlantMixFamilyManagerRibbonButton", resourceCulture);

	internal static string PlantMixFamilyNotLoadedMessage => ResourceManager.GetString("PlantMixFamilyNotLoadedMessage", resourceCulture);

	internal static string PlantMixMessage => ResourceManager.GetString("PlantMixMessage", resourceCulture);

	internal static string PlantMixPlantSearchTitle => ResourceManager.GetString("PlantMixPlantSearchTitle", resourceCulture);

	internal static string PlantMixReportDialog => ResourceManager.GetString("PlantMixReportDialog", resourceCulture);

	internal static string PlantMixReportNoFamilyMessage => ResourceManager.GetString("PlantMixReportNoFamilyMessage", resourceCulture);

	internal static string PlantMixSpacingMethodSquare => ResourceManager.GetString("PlantMixSpacingMethodSquare", resourceCulture);

	internal static string PlantMixSpacingMethodTriangular => ResourceManager.GetString("PlantMixSpacingMethodTriangular", resourceCulture);

	internal static string PlantMixString => ResourceManager.GetString("PlantMixString", resourceCulture);

	internal static string PlantPlaceTagNotPlacedMessage => ResourceManager.GetString("PlantPlaceTagNotPlacedMessage", resourceCulture);

	internal static string PlantScientificNamePlantFamilyParameter => ResourceManager.GetString("PlantScientificNamePlantFamilyParameter", resourceCulture);

	internal static string PlantsDialog => ResourceManager.GetString("PlantsDialog", resourceCulture);

	internal static string PlantSearchDialog => ResourceManager.GetString("PlantSearchDialog", resourceCulture);

	internal static string PlantSizePlantMixFamilyParameter => ResourceManager.GetString("PlantSizePlantMixFamilyParameter", resourceCulture);

	internal static string PlantSpacingPlantFamilyParameter => ResourceManager.GetString("PlantSpacingPlantFamilyParameter", resourceCulture);

	internal static string PlantSpacingPlantMixFamilyParameter => ResourceManager.GetString("PlantSpacingPlantMixFamilyParameter", resourceCulture);

	internal static string PlantTypePlantFamilyParameter => ResourceManager.GetString("PlantTypePlantFamilyParameter", resourceCulture);

	internal static string PlantUsesPlantFamilyParameter => ResourceManager.GetString("PlantUsesPlantFamilyParameter", resourceCulture);

	internal static string PlantViewSearchTitle => ResourceManager.GetString("PlantViewSearchTitle", resourceCulture);

	internal static string PlantWidthPlantFamilyParameter => ResourceManager.GetString("PlantWidthPlantFamilyParameter", resourceCulture);

	internal static string PleaseSelectComponentFamilyFileMessage => ResourceManager.GetString("PleaseSelectComponentFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectCurbFamilyFileMessage => ResourceManager.GetString("PleaseSelectCurbFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectFenceFamilyFileMessage => ResourceManager.GetString("PleaseSelectFenceFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectParkingLotFamilyFileMessage => ResourceManager.GetString("PleaseSelectParkingLotFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectPlantingFamilyFileMessage => ResourceManager.GetString("PleaseSelectPlantingFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectRetainingWallFamilyFileMessage => ResourceManager.GetString("PleaseSelectRetainingWallFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectSidewalkFamilyFileMessage => ResourceManager.GetString("PleaseSelectSidewalkFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectSoftTerrainFamilyFileMessage => ResourceManager.GetString("PleaseSelectSoftTerrainFamilyFileMessage", resourceCulture);

	internal static string PleaseSelectStreetFamilyFileMessage => ResourceManager.GetString("PleaseSelectStreetFamilyFileMessage", resourceCulture);

	internal static string PointNotInParkingLotBoundaryMessage => ResourceManager.GetString("PointNotInParkingLotBoundaryMessage", resourceCulture);

	internal static string PointNotInProposedBoundaryMessage => ResourceManager.GetString("PointNotInProposedBoundaryMessage", resourceCulture);

	internal static string PointsInBoundaryWillBeRemovedMessage => ResourceManager.GetString("PointsInBoundaryWillBeRemovedMessage", resourceCulture);

	internal static string PointsNotInParkingLotBoundaryMessage => ResourceManager.GetString("PointsNotInParkingLotBoundaryMessage", resourceCulture);

	internal static string PointWipeoutBoundaryClosedChainMessage => ResourceManager.GetString("PointWipeoutBoundaryClosedChainMessage", resourceCulture);

	internal static string PointWipeoutLineSubCategoryColor => ResourceManager.GetString("PointWipeoutLineSubCategoryColor", resourceCulture);

	internal static string PointWipeoutLineSubCategoryLineWeight => ResourceManager.GetString("PointWipeoutLineSubCategoryLineWeight", resourceCulture);

	internal static string PointWipeoutLineSubCategoryName => ResourceManager.GetString("PointWipeoutLineSubCategoryName", resourceCulture);

	internal static string PointWipeoutRibbonButton => ResourceManager.GetString("PointWipeoutRibbonButton", resourceCulture);

	internal static string PointWipeoutString => ResourceManager.GetString("PointWipeoutString", resourceCulture);

	internal static string PositionComponetsMessage => ResourceManager.GetString("PositionComponetsMessage", resourceCulture);

	internal static string PositionDistanceLandXMLSurfacePlacementFamilyInstanceParameter => ResourceManager.GetString("PositionDistanceLandXMLSurfacePlacementFamilyInstanceParameter", resourceCulture);

	internal static string PositionFenceMessage => ResourceManager.GetString("PositionFenceMessage", resourceCulture);

	internal static string PositionHzDirectionLandXMLSurfacePlacementFamilyInstanceParameter => ResourceManager.GetString("PositionHzDirectionLandXMLSurfacePlacementFamilyInstanceParameter", resourceCulture);

	internal static string PositioningAutoCenterToCenter => ResourceManager.GetString("PositioningAutoCenterToCenter", resourceCulture);

	internal static string PositioningAutoOriginToOrigin => ResourceManager.GetString("PositioningAutoOriginToOrigin", resourceCulture);

	internal static string PositioningBySharedCoordinates => ResourceManager.GetString("PositioningBySharedCoordinates", resourceCulture);

	internal static string PositioningBySurveyPoints => ResourceManager.GetString("PositioningBySurveyPoints", resourceCulture);

	internal static string PositioningDialog => ResourceManager.GetString("PositioningDialog", resourceCulture);

	internal static string PositioningManualCenter => ResourceManager.GetString("PositioningManualCenter", resourceCulture);

	internal static string PositioningMethodLandXMLSurfacePlacementFamilyInstanceParameter => ResourceManager.GetString("PositioningMethodLandXMLSurfacePlacementFamilyInstanceParameter", resourceCulture);

	internal static string PositioningUsePreviousValues => ResourceManager.GetString("PositioningUsePreviousValues", resourceCulture);

	internal static string PositionParkingLotsMessage => ResourceManager.GetString("PositionParkingLotsMessage", resourceCulture);

	internal static string PositionPlantsMessage => ResourceManager.GetString("PositionPlantsMessage", resourceCulture);

	internal static string PositionVzDirectionLandXMLSurfacePlacementFamilyInstanceParameter => ResourceManager.GetString("PositionVzDirectionLandXMLSurfacePlacementFamilyInstanceParameter", resourceCulture);

	internal static string PreserveColorsColorMode => ResourceManager.GetString("PreserveColorsColorMode", resourceCulture);

	internal static string PreviewDialog => ResourceManager.GetString("PreviewDialog", resourceCulture);

	internal static string PrimaryFormIDFamilyParameter => ResourceManager.GetString("PrimaryFormIDFamilyParameter", resourceCulture);

	internal static string PrimaryPlacementIDParameter => ResourceManager.GetString("PrimaryPlacementIDParameter", resourceCulture);

	internal static string PrimaryStationParameter => ResourceManager.GetString("PrimaryStationParameter", resourceCulture);

	internal static string ProductDownloadIntructionsDialog => ResourceManager.GetString("ProductDownloadIntructionsDialog", resourceCulture);

	internal static string ProductUpdateAvailableTitle => ResourceManager.GetString("ProductUpdateAvailableTitle", resourceCulture);

	internal static string ProgressbarConvertingPlantsMessage => ResourceManager.GetString("ProgressbarConvertingPlantsMessage", resourceCulture);

	internal static string ProgressBarCreatingCurbMassMessage => ResourceManager.GetString("ProgressBarCreatingCurbMassMessage", resourceCulture);

	internal static string ProgressbarCreatingFamilyMessage => ResourceManager.GetString("ProgressbarCreatingFamilyMessage", resourceCulture);

	internal static string ProgressBarCreatingNewBaseToposurfaceMessage => ResourceManager.GetString("ProgressBarCreatingNewBaseToposurfaceMessage", resourceCulture);

	internal static string ProgressBarCreatingNewProposedToposurfaceMessage => ResourceManager.GetString("ProgressBarCreatingNewProposedToposurfaceMessage", resourceCulture);

	internal static string ProgressBarCreatingNewToposurfaceMessage => ResourceManager.GetString("ProgressBarCreatingNewToposurfaceMessage", resourceCulture);

	internal static string ProgressBarCreatingRetainingWallMassMessage => ResourceManager.GetString("ProgressBarCreatingRetainingWallMassMessage", resourceCulture);

	internal static string ProgressBarCreatingSidewalkMassMessage => ResourceManager.GetString("ProgressBarCreatingSidewalkMassMessage", resourceCulture);

	internal static string ProgressBarCreatingStreetMassMessage => ResourceManager.GetString("ProgressBarCreatingStreetMassMessage", resourceCulture);

	internal static string ProgressBarGradingToposurfaceMessage => ResourceManager.GetString("ProgressBarGradingToposurfaceMessage", resourceCulture);

	internal static string ProgressbarGrowingPlantsMessage => ResourceManager.GetString("ProgressbarGrowingPlantsMessage", resourceCulture);

	internal static string ProgressbarImportMessage => ResourceManager.GetString("ProgressbarImportMessage", resourceCulture);

	internal static string ProgressbarLoadingFamilyMessage => ResourceManager.GetString("ProgressbarLoadingFamilyMessage", resourceCulture);

	internal static string ProgressbarLoadingFilesMessage => ResourceManager.GetString("ProgressbarLoadingFilesMessage", resourceCulture);

	internal static string ProgressBarObtainingSiteComponentsMessage => ResourceManager.GetString("ProgressBarObtainingSiteComponentsMessage", resourceCulture);

	internal static string ProgressBarPlacingComponentsMessage => ResourceManager.GetString("ProgressBarPlacingComponentsMessage", resourceCulture);

	internal static string ProgressBarPlacingCurbMassMessage => ResourceManager.GetString("ProgressBarPlacingCurbMassMessage", resourceCulture);

	internal static string ProgressBarPlacingPlantsMessage => ResourceManager.GetString("ProgressBarPlacingPlantsMessage", resourceCulture);

	internal static string ProgressBarPlacingRetainingWallMassMessage => ResourceManager.GetString("ProgressBarPlacingRetainingWallMassMessage", resourceCulture);

	internal static string ProgressBarPlacingSidewalkMassMessage => ResourceManager.GetString("ProgressBarPlacingSidewalkMassMessage", resourceCulture);

	internal static string ProgressBarPlacingStreetMassMessage => ResourceManager.GetString("ProgressBarPlacingStreetMassMessage", resourceCulture);

	internal static string ProgressBarProcessingCogoPointsMessage => ResourceManager.GetString("ProgressBarProcessingCogoPointsMessage", resourceCulture);

	internal static string ProgressBarProcessingPointsForAlignmentMessage => ResourceManager.GetString("ProgressBarProcessingPointsForAlignmentMessage", resourceCulture);

	internal static string ProgressBarProcessingPointsForSurfaceMessage => ResourceManager.GetString("ProgressBarProcessingPointsForSurfaceMessage", resourceCulture);

	internal static string ProgressBarProcessingSelectedSiteComponentPointsMessage => ResourceManager.GetString("ProgressBarProcessingSelectedSiteComponentPointsMessage", resourceCulture);

	internal static string ProgressbarSavingModifiedPlantsMessage => ResourceManager.GetString("ProgressbarSavingModifiedPlantsMessage", resourceCulture);

	internal static string ProgressbarSearchingMessage => ResourceManager.GetString("ProgressbarSearchingMessage", resourceCulture);

	internal static string ProgressbarSettingParametersMessage => ResourceManager.GetString("ProgressbarSettingParametersMessage", resourceCulture);

	internal static string ProgressBarUpdatingModelMessage => ResourceManager.GetString("ProgressBarUpdatingModelMessage", resourceCulture);

	internal static string ProgressDialog => ResourceManager.GetString("ProgressDialog", resourceCulture);

	internal static string ProgressPlacingFenceMessage => ResourceManager.GetString("ProgressPlacingFenceMessage", resourceCulture);

	internal static string ProjectedAreaSubRegionParameter => ResourceManager.GetString("ProjectedAreaSubRegionParameter", resourceCulture);

	internal static string ProjectInnerSlopesFamilyParameter => ResourceManager.GetString("ProjectInnerSlopesFamilyParameter", resourceCulture);

	internal static string ProposedSurfaceLinkBrokenMessage => ResourceManager.GetString("ProposedSurfaceLinkBrokenMessage", resourceCulture);

	internal static string ProposedToposurfaceMaterialParameter => ResourceManager.GetString("ProposedToposurfaceMaterialParameter", resourceCulture);

	internal static string ProposedToposurfaceString => ResourceManager.GetString("ProposedToposurfaceString", resourceCulture);

	internal static string QuantityOfString => ResourceManager.GetString("QuantityOfString", resourceCulture);

	internal static string R_AMP_emoveAllDialog => ResourceManager.GetString("R_AMP_emoveAllDialog", resourceCulture);

	internal static string R_AMP_etainingWallNameDialog => ResourceManager.GetString("R_AMP_etainingWallNameDialog", resourceCulture);

	internal static string R_AMP_otationDialog => ResourceManager.GetString("R_AMP_otationDialog", resourceCulture);

	internal static string RadiusMakesArcLengthMoreThanHostLineMessage => ResourceManager.GetString("RadiusMakesArcLengthMoreThanHostLineMessage", resourceCulture);

	internal static string RadiusParameter => ResourceManager.GetString("RadiusParameter", resourceCulture);

	internal static string RadiusPlantParameter => ResourceManager.GetString("RadiusPlantParameter", resourceCulture);

	internal static string RadiusSettingsGroupTitle => ResourceManager.GetString("RadiusSettingsGroupTitle", resourceCulture);

	internal static string Re_AMP_lativeElevationFromToposurfaceDialog => ResourceManager.GetString("Re_AMP_lativeElevationFromToposurfaceDialog", resourceCulture);

	internal static string Re_AMP_lativeElevationsDialog => ResourceManager.GetString("Re_AMP_lativeElevationsDialog", resourceCulture);

	internal static string ReadOnlySaveAsMessage => ResourceManager.GetString("ReadOnlySaveAsMessage", resourceCulture);

	internal static string RedLineColor => ResourceManager.GetString("RedLineColor", resourceCulture);

	internal static string RegionNameGenericModelFamilyParameter => ResourceManager.GetString("RegionNameGenericModelFamilyParameter", resourceCulture);

	internal static string RegionSelectedNotAssignedMessage => ResourceManager.GetString("RegionSelectedNotAssignedMessage", resourceCulture);

	internal static string RegionString => ResourceManager.GetString("RegionString", resourceCulture);

	internal static string RelativeElevationFromToposurfaceDialog => ResourceManager.GetString("RelativeElevationFromToposurfaceDialog", resourceCulture);

	internal static string RelinkSurfacesTransaction => ResourceManager.GetString("RelinkSurfacesTransaction", resourceCulture);

	internal static string ReloadFamilyTransaction => ResourceManager.GetString("ReloadFamilyTransaction", resourceCulture);

	internal static string ReportRibbonPanel => ResourceManager.GetString("ReportRibbonPanel", resourceCulture);

	internal static string Retaining_AMP_WallTypeDialog => ResourceManager.GetString("Retaining_AMP_WallTypeDialog", resourceCulture);

	internal static string RetainingWallBaseSurfaceParameter => ResourceManager.GetString("RetainingWallBaseSurfaceParameter", resourceCulture);

	internal static string RetainingwallCo_AMP_nstantElevationDialog => ResourceManager.GetString("RetainingwallCo_AMP_nstantElevationDialog", resourceCulture);

	internal static string RetainingwallConstantElevationDialog => ResourceManager.GetString("RetainingwallConstantElevationDialog", resourceCulture);

	internal static string RetainingWallCutSlopeParameter => ResourceManager.GetString("RetainingWallCutSlopeParameter", resourceCulture);

	internal static string RetainingWallFamilyDialog => ResourceManager.GetString("RetainingWallFamilyDialog", resourceCulture);

	internal static string RetainingWallFamilyManagerRibbonButton => ResourceManager.GetString("RetainingWallFamilyManagerRibbonButton", resourceCulture);

	internal static string RetainingWallFamilyManagerToolTip => ResourceManager.GetString("RetainingWallFamilyManagerToolTip", resourceCulture);

	internal static string RetainingWallFamilyNotLoadedMessage => ResourceManager.GetString("RetainingWallFamilyNotLoadedMessage", resourceCulture);

	internal static string RetainingWallFillSlopeParameter => ResourceManager.GetString("RetainingWallFillSlopeParameter", resourceCulture);

	internal static string RetainingWallHeightParameter => ResourceManager.GetString("RetainingWallHeightParameter", resourceCulture);

	internal static string RetainingWallLineSubCategoryColor => ResourceManager.GetString("RetainingWallLineSubCategoryColor", resourceCulture);

	internal static string RetainingWallLineSubCategoryLineWeight => ResourceManager.GetString("RetainingWallLineSubCategoryLineWeight", resourceCulture);

	internal static string RetainingWallLineSubCategoryName => ResourceManager.GetString("RetainingWallLineSubCategoryName", resourceCulture);

	internal static string RetainingWallManagerString => ResourceManager.GetString("RetainingWallManagerString", resourceCulture);

	internal static string RetainingWallMassSubCategoryName => ResourceManager.GetString("RetainingWallMassSubCategoryName", resourceCulture);

	internal static string RetainingWallMassTemplateFileNameString => ResourceManager.GetString("RetainingWallMassTemplateFileNameString", resourceCulture);

	internal static string RetainingWallMaterialParameter => ResourceManager.GetString("RetainingWallMaterialParameter", resourceCulture);

	internal static string RetainingWallNameDialog => ResourceManager.GetString("RetainingWallNameDialog", resourceCulture);

	internal static string RetainingwallRe_AMP_lativeElevationFromToposurfaceDialog => ResourceManager.GetString("RetainingwallRe_AMP_lativeElevationFromToposurfaceDialog", resourceCulture);

	internal static string RetainingwallRelativeElevationFromToposurfaceDialog => ResourceManager.GetString("RetainingwallRelativeElevationFromToposurfaceDialog", resourceCulture);

	internal static string RetainingWallSlopeProjectionParameter => ResourceManager.GetString("RetainingWallSlopeProjectionParameter", resourceCulture);

	internal static string RetainingWallString => ResourceManager.GetString("RetainingWallString", resourceCulture);

	internal static string RetainingWallSubbaseSurfaceParameter => ResourceManager.GetString("RetainingWallSubbaseSurfaceParameter", resourceCulture);

	internal static string RetainingWallTemplateNotMassTypeMessage => ResourceManager.GetString("RetainingWallTemplateNotMassTypeMessage", resourceCulture);

	internal static string RetainingWallTypeDialog => ResourceManager.GetString("RetainingWallTypeDialog", resourceCulture);

	internal static string RetainingWallWidthParameter => ResourceManager.GetString("RetainingWallWidthParameter", resourceCulture);

	internal static string ReturnLicenseRibbonButton => ResourceManager.GetString("ReturnLicenseRibbonButton", resourceCulture);

	internal static string ReturnLicenseRibbonToolTip => ResourceManager.GetString("ReturnLicenseRibbonToolTip", resourceCulture);

	internal static string RevitExceptionError => ResourceManager.GetString("RevitExceptionError", resourceCulture);

	internal static string RevitINIFileMissingMessage => ResourceManager.GetString("RevitINIFileMissingMessage", resourceCulture);

	internal static string RevitLevelString => ResourceManager.GetString("RevitLevelString", resourceCulture);

	internal static string RGBString => ResourceManager.GetString("RGBString", resourceCulture);

	internal static string RightViewDirection => ResourceManager.GetString("RightViewDirection", resourceCulture);

	internal static string RightVisibleParameter => ResourceManager.GetString("RightVisibleParameter", resourceCulture);

	internal static string RowSpacingDialog => ResourceManager.GetString("RowSpacingDialog", resourceCulture);

	internal static string RPCRenderAppearanceFamilyParameter => ResourceManager.GetString("RPCRenderAppearanceFamilyParameter", resourceCulture);

	internal static string RPCRenderAppearancePropertiesFamilyParameter => ResourceManager.GetString("RPCRenderAppearancePropertiesFamilyParameter", resourceCulture);

	internal static string RunLocateSiteComponentsMessage => ResourceManager.GetString("RunLocateSiteComponentsMessage", resourceCulture);

	internal static string S_AMP_haredAccessibleAisleDialog => ResourceManager.GetString("S_AMP_haredAccessibleAisleDialog", resourceCulture);

	internal static string S_AMP_howAffectedPointsDialog => ResourceManager.GetString("S_AMP_howAffectedPointsDialog", resourceCulture);

	internal static string S_AMP_ideWalkTypeDialog => ResourceManager.GetString("S_AMP_ideWalkTypeDialog", resourceCulture);

	internal static string S_AMP_oftTerrainNameDialog => ResourceManager.GetString("S_AMP_oftTerrainNameDialog", resourceCulture);

	internal static string S_AMP_quareDialog => ResourceManager.GetString("S_AMP_quareDialog", resourceCulture);

	internal static string S_AMP_tartingDistanceDialog => ResourceManager.GetString("S_AMP_tartingDistanceDialog", resourceCulture);

	internal static string S_AMP_treetFamilyDialog => ResourceManager.GetString("S_AMP_treetFamilyDialog", resourceCulture);

	internal static string S_AMP_urfaceDialog => ResourceManager.GetString("S_AMP_urfaceDialog", resourceCulture);

	internal static string S_AMP_ymbolFileDialog => ResourceManager.GetString("S_AMP_ymbolFileDialog", resourceCulture);

	internal static string SameSourceAndDestinationFileMessage => ResourceManager.GetString("SameSourceAndDestinationFileMessage", resourceCulture);

	internal static string SameTypeNameAsFamilyNameMessage => ResourceManager.GetString("SameTypeNameAsFamilyNameMessage", resourceCulture);

	internal static string SamplePath => ResourceManager.GetString("SamplePath", resourceCulture);

	internal static string Save_AMP_FamilyDialog => ResourceManager.GetString("Save_AMP_FamilyDialog", resourceCulture);

	internal static string SaveFamilyMessage => ResourceManager.GetString("SaveFamilyMessage", resourceCulture);

	internal static string ScalingDialog => ResourceManager.GetString("ScalingDialog", resourceCulture);

	internal static string ScientificNamePlantMixFamilyParameter => ResourceManager.GetString("ScientificNamePlantMixFamilyParameter", resourceCulture);

	internal static string Se_AMP_ttingsDialog => ResourceManager.GetString("Se_AMP_ttingsDialog", resourceCulture);

	internal static string Sea_AMP_rchDialog => ResourceManager.GetString("Sea_AMP_rchDialog", resourceCulture);

	internal static string Searc_AMP_hDialog => ResourceManager.GetString("Searc_AMP_hDialog", resourceCulture);

	internal static string SecondaryPlacementIDParameter => ResourceManager.GetString("SecondaryPlacementIDParameter", resourceCulture);

	internal static string SecondaryStationParameter => ResourceManager.GetString("SecondaryStationParameter", resourceCulture);

	internal static string Select__String => ResourceManager.GetString("Select__String", resourceCulture);

	internal static string SelectedFileHasLengthMessage => ResourceManager.GetString("SelectedFileHasLengthMessage", resourceCulture);

	internal static string SelectExportTopoAlignmentLabelString => ResourceManager.GetString("SelectExportTopoAlignmentLabelString", resourceCulture);

	internal static string SelectExportTopoSurfaceLabelString => ResourceManager.GetString("SelectExportTopoSurfaceLabelString", resourceCulture);

	internal static string SelectionMethodsDialog => ResourceManager.GetString("SelectionMethodsDialog", resourceCulture);

	internal static string SelectRFADir => ResourceManager.GetString("SelectRFADir", resourceCulture);

	internal static string SelectSurfaceNameAndPhaseDialog => ResourceManager.GetString("SelectSurfaceNameAndPhaseDialog", resourceCulture);

	internal static string SelectTemplateMessage => ResourceManager.GetString("SelectTemplateMessage", resourceCulture);

	internal static string SelectTopoAlignmentLabelString => ResourceManager.GetString("SelectTopoAlignmentLabelString", resourceCulture);

	internal static string SelectTopoSurfaceLabelString => ResourceManager.GetString("SelectTopoSurfaceLabelString", resourceCulture);

	internal static string Set_AMP_backDialog => ResourceManager.GetString("Set_AMP_backDialog", resourceCulture);

	internal static string SetbackGenericFamilyParameter => ResourceManager.GetString("SetbackGenericFamilyParameter", resourceCulture);

	internal static string SetBaseToposurfaceDialog => ResourceManager.GetString("SetBaseToposurfaceDialog", resourceCulture);

	internal static string SetBaseToposurfaceInformationDialog => ResourceManager.GetString("SetBaseToposurfaceInformationDialog", resourceCulture);

	internal static string SetBaseTopoSurfaceRibbonButton => ResourceManager.GetString("SetBaseTopoSurfaceRibbonButton", resourceCulture);

	internal static string SetBaseTopoSurfaceRibbonToolTip => ResourceManager.GetString("SetBaseTopoSurfaceRibbonToolTip", resourceCulture);

	internal static string SetBaseTopoSurfaceRibbonToolTipLongDescription => ResourceManager.GetString("SetBaseTopoSurfaceRibbonToolTipLongDescription", resourceCulture);

	internal static string SetBaseToposurfaceTransaction => ResourceManager.GetString("SetBaseToposurfaceTransaction", resourceCulture);

	internal static string SetFamilyTypeForSiteComponentOption => ResourceManager.GetString("SetFamilyTypeForSiteComponentOption", resourceCulture);

	internal static string SettingRibbonButton => ResourceManager.GetString("SettingRibbonButton", resourceCulture);

	internal static string SettingRibbonToolTip => ResourceManager.GetString("SettingRibbonToolTip", resourceCulture);

	internal static string SharedParametersDontExistDialog => ResourceManager.GetString("SharedParametersDontExistDialog", resourceCulture);

	internal static string Sho_AMP_wAllDialog => ResourceManager.GetString("Sho_AMP_wAllDialog", resourceCulture);

	internal static string ShowMassInActiveViewOption => ResourceManager.GetString("ShowMassInActiveViewOption", resourceCulture);

	internal static string ShowMassInAllViewsOption => ResourceManager.GetString("ShowMassInAllViewsOption", resourceCulture);

	internal static string Si_AMP_deWalkNameDialog => ResourceManager.GetString("Si_AMP_deWalkNameDialog", resourceCulture);

	internal static string Side_AMP_WalkFamilyDialog => ResourceManager.GetString("Side_AMP_WalkFamilyDialog", resourceCulture);

	internal static string SideString => ResourceManager.GetString("SideString", resourceCulture);

	internal static string SideWalkBaseSurfaceParameter => ResourceManager.GetString("SideWalkBaseSurfaceParameter", resourceCulture);

	internal static string SideWalkCutSlopeParameter => ResourceManager.GetString("SideWalkCutSlopeParameter", resourceCulture);

	internal static string SideWalkFamilyDialog => ResourceManager.GetString("SideWalkFamilyDialog", resourceCulture);

	internal static string SidewalkFamilyManagerRibbonButton => ResourceManager.GetString("SidewalkFamilyManagerRibbonButton", resourceCulture);

	internal static string SidewalkFamilyManagerToolTip => ResourceManager.GetString("SidewalkFamilyManagerToolTip", resourceCulture);

	internal static string SideWalkFamilyNotLoadedMessage => ResourceManager.GetString("SideWalkFamilyNotLoadedMessage", resourceCulture);

	internal static string SideWalkFillSlopeParameter => ResourceManager.GetString("SideWalkFillSlopeParameter", resourceCulture);

	internal static string SidewalkIntersectionDefaultRadius => ResourceManager.GetString("SidewalkIntersectionDefaultRadius", resourceCulture);

	internal static string SidewalkIntersectionDefaultTransitioningDistance => ResourceManager.GetString("SidewalkIntersectionDefaultTransitioningDistance", resourceCulture);

	internal static string SidewalkIntersectionNotOnStraightLinesMessage => ResourceManager.GetString("SidewalkIntersectionNotOnStraightLinesMessage", resourceCulture);

	internal static string SidewalkLineSubCategoryColor => ResourceManager.GetString("SidewalkLineSubCategoryColor", resourceCulture);

	internal static string SidewalkLineSubCategoryLineWeight => ResourceManager.GetString("SidewalkLineSubCategoryLineWeight", resourceCulture);

	internal static string SidewalkLineSubCategoryName => ResourceManager.GetString("SidewalkLineSubCategoryName", resourceCulture);

	internal static string SideWalkLocationLineParameter => ResourceManager.GetString("SideWalkLocationLineParameter", resourceCulture);

	internal static string SidewalkMassSubCategoryName => ResourceManager.GetString("SidewalkMassSubCategoryName", resourceCulture);

	internal static string SidewalkMassTemplateFileNameString => ResourceManager.GetString("SidewalkMassTemplateFileNameString", resourceCulture);

	internal static string SideWalkNameDialog => ResourceManager.GetString("SideWalkNameDialog", resourceCulture);

	internal static string SideWalkPavementDepthParameter => ResourceManager.GetString("SideWalkPavementDepthParameter", resourceCulture);

	internal static string SideWalkPavementSurfaceParameter => ResourceManager.GetString("SideWalkPavementSurfaceParameter", resourceCulture);

	internal static string SidewalkString => ResourceManager.GetString("SidewalkString", resourceCulture);

	internal static string SideWalkSubbaseSurfaceParameter => ResourceManager.GetString("SideWalkSubbaseSurfaceParameter", resourceCulture);

	internal static string SidewalkTemplateNotMassTypeMessage => ResourceManager.GetString("SidewalkTemplateNotMassTypeMessage", resourceCulture);

	internal static string SideWalkTypeDialog => ResourceManager.GetString("SideWalkTypeDialog", resourceCulture);

	internal static string SidewalkTypeManagerString => ResourceManager.GetString("SidewalkTypeManagerString", resourceCulture);

	internal static string SideWalkWidthParameter => ResourceManager.GetString("SideWalkWidthParameter", resourceCulture);

	internal static string SingleFileDialog => ResourceManager.GetString("SingleFileDialog", resourceCulture);

	internal static string SingleFileNoCSVTXTMessage => ResourceManager.GetString("SingleFileNoCSVTXTMessage", resourceCulture);

	internal static string SingleFileNoRFAMessage => ResourceManager.GetString("SingleFileNoRFAMessage", resourceCulture);

	internal static string SiteComponentAnnotationBeginElevationIDParameter => ResourceManager.GetString("SiteComponentAnnotationBeginElevationIDParameter", resourceCulture);

	internal static string SiteComponentAnnotationEndElevationIDParameter => ResourceManager.GetString("SiteComponentAnnotationEndElevationIDParameter", resourceCulture);

	internal static string SiteComponentAnnotationGradeIDParameter => ResourceManager.GetString("SiteComponentAnnotationGradeIDParameter", resourceCulture);

	internal static string SiteComponentFamilyManagerToolTip => ResourceManager.GetString("SiteComponentFamilyManagerToolTip", resourceCulture);

	internal static string SiteComponentHasElevationAnnotationParameter => ResourceManager.GetString("SiteComponentHasElevationAnnotationParameter", resourceCulture);

	internal static string SiteComponentHasGradeAnnotationParameter => ResourceManager.GetString("SiteComponentHasGradeAnnotationParameter", resourceCulture);

	internal static string SiteComponentIsRelativeElevationParameter => ResourceManager.GetString("SiteComponentIsRelativeElevationParameter", resourceCulture);

	internal static string SiteComponentLineCreationString => ResourceManager.GetString("SiteComponentLineCreationString", resourceCulture);

	internal static string SiteComponentNameFamilyParameter => ResourceManager.GetString("SiteComponentNameFamilyParameter", resourceCulture);

	internal static string SiteComponentPromptForStartingSide => ResourceManager.GetString("SiteComponentPromptForStartingSide", resourceCulture);

	internal static string SiteComponentsFoundInProjectMessage => ResourceManager.GetString("SiteComponentsFoundInProjectMessage", resourceCulture);

	internal static string SiteImperialTemplate => ResourceManager.GetString("SiteImperialTemplate", resourceCulture);

	internal static string SiteMetricTemplate => ResourceManager.GetString("SiteMetricTemplate", resourceCulture);

	internal static string SitesReportDialog => ResourceManager.GetString("SitesReportDialog", resourceCulture);

	internal static string SitesReportRibbonButton => ResourceManager.GetString("SitesReportRibbonButton", resourceCulture);

	internal static string SitesReportRibbonToolTip => ResourceManager.GetString("SitesReportRibbonToolTip", resourceCulture);

	internal static string SitesReportRibbonToolTipLongDescription => ResourceManager.GetString("SitesReportRibbonToolTipLongDescription", resourceCulture);

	internal static string SiteString => ResourceManager.GetString("SiteString", resourceCulture);

	internal static string SiteworksIDFamilyParameter => ResourceManager.GetString("SiteworksIDFamilyParameter", resourceCulture);

	internal static string SiteworksNetworkLicenseBorrowError => ResourceManager.GetString("SiteworksNetworkLicenseBorrowError", resourceCulture);

	internal static string SiteworksNetworkLicenseError => ResourceManager.GetString("SiteworksNetworkLicenseError", resourceCulture);

	internal static string Slope_ => ResourceManager.GetString("Slope_", resourceCulture);

	internal static string SlopeProjectionTabString => ResourceManager.GetString("SlopeProjectionTabString", resourceCulture);

	internal static string SlopeUnitDegrees => ResourceManager.GetString("SlopeUnitDegrees", resourceCulture);

	internal static string SlopeUnitPercentage => ResourceManager.GetString("SlopeUnitPercentage", resourceCulture);

	internal static string SlopeUnitRatio10 => ResourceManager.GetString("SlopeUnitRatio10", resourceCulture);

	internal static string SlopeUnitRatio12 => ResourceManager.GetString("SlopeUnitRatio12", resourceCulture);

	internal static string SlopeUnitRiseFeet => ResourceManager.GetString("SlopeUnitRiseFeet", resourceCulture);

	internal static string SlopeUnitRiseInches => ResourceManager.GetString("SlopeUnitRiseInches", resourceCulture);

	internal static string SlopeUnitRiseMM => ResourceManager.GetString("SlopeUnitRiseMM", resourceCulture);

	internal static string So_AMP_ftTerrainTypeDialog => ResourceManager.GetString("So_AMP_ftTerrainTypeDialog", resourceCulture);

	internal static string Soft_AMP_TerrainFamilyDialog => ResourceManager.GetString("Soft_AMP_TerrainFamilyDialog", resourceCulture);

	internal static string SoftTerrainCutSlopeParameter => ResourceManager.GetString("SoftTerrainCutSlopeParameter", resourceCulture);

	internal static string SoftTerrainFamilyCantBeLoadedMessage => ResourceManager.GetString("SoftTerrainFamilyCantBeLoadedMessage", resourceCulture);

	internal static string SoftTerrainFamilyDialog => ResourceManager.GetString("SoftTerrainFamilyDialog", resourceCulture);

	internal static string SoftTerrainFamilyManagerRibbonButton => ResourceManager.GetString("SoftTerrainFamilyManagerRibbonButton", resourceCulture);

	internal static string SoftTerrainFamilyManagerRibbonToolTip => ResourceManager.GetString("SoftTerrainFamilyManagerRibbonToolTip", resourceCulture);

	internal static string SoftTerrainFamilyNotLoadedMessage => ResourceManager.GetString("SoftTerrainFamilyNotLoadedMessage", resourceCulture);

	internal static string SoftTerrainFamilyNotLoadedWithIDMessage => ResourceManager.GetString("SoftTerrainFamilyNotLoadedWithIDMessage", resourceCulture);

	internal static string SoftTerrainFillSlopeParameter => ResourceManager.GetString("SoftTerrainFillSlopeParameter", resourceCulture);

	internal static string SoftTerrainLeftOffsetWidthParameter => ResourceManager.GetString("SoftTerrainLeftOffsetWidthParameter", resourceCulture);

	internal static string SoftTerrainLineSubCategoryColor => ResourceManager.GetString("SoftTerrainLineSubCategoryColor", resourceCulture);

	internal static string SoftTerrainLineSubCategoryLineWeight => ResourceManager.GetString("SoftTerrainLineSubCategoryLineWeight", resourceCulture);

	internal static string SoftTerrainLineSubCategoryName => ResourceManager.GetString("SoftTerrainLineSubCategoryName", resourceCulture);

	internal static string SoftTerrainManagerString => ResourceManager.GetString("SoftTerrainManagerString", resourceCulture);

	internal static string SoftTerrainNameDialog => ResourceManager.GetString("SoftTerrainNameDialog", resourceCulture);

	internal static string SoftTerrainRightOffsetWidthParameter => ResourceManager.GetString("SoftTerrainRightOffsetWidthParameter", resourceCulture);

	internal static string SoftTerrainString => ResourceManager.GetString("SoftTerrainString", resourceCulture);

	internal static string SoftTerrainTypeDialog => ResourceManager.GetString("SoftTerrainTypeDialog", resourceCulture);

	internal static string Source => ResourceManager.GetString("Source", resourceCulture);

	internal static string SourceDialog => ResourceManager.GetString("SourceDialog", resourceCulture);

	internal static string SpacingGenericFamilyParameter => ResourceManager.GetString("SpacingGenericFamilyParameter", resourceCulture);

	internal static string SpacingMethodPlantMixFamilyParameter => ResourceManager.GetString("SpacingMethodPlantMixFamilyParameter", resourceCulture);

	internal static string Specify_Message => ResourceManager.GetString("Specify_Message", resourceCulture);

	internal static string SpecifyDestinationFileMessage => ResourceManager.GetString("SpecifyDestinationFileMessage", resourceCulture);

	internal static string SpecifyFileNameMessage => ResourceManager.GetString("SpecifyFileNameMessage", resourceCulture);

	internal static string SpecifyFolderFileNameMessage => ResourceManager.GetString("SpecifyFolderFileNameMessage", resourceCulture);

	internal static string SpecifyPlantHeightMessage => ResourceManager.GetString("SpecifyPlantHeightMessage", resourceCulture);

	internal static string SpecifyPlantSpacingMessage => ResourceManager.GetString("SpecifyPlantSpacingMessage", resourceCulture);

	internal static string SpecifyPlantWidthMessage => ResourceManager.GetString("SpecifyPlantWidthMessage", resourceCulture);

	internal static string SpecifySharedParameterFileNameMessage => ResourceManager.GetString("SpecifySharedParameterFileNameMessage", resourceCulture);

	internal static string SpecifySourceFileNameMessage => ResourceManager.GetString("SpecifySourceFileNameMessage", resourceCulture);

	internal static string SpecifySymbolFileNameMessage => ResourceManager.GetString("SpecifySymbolFileNameMessage", resourceCulture);

	internal static string SpiralsNotSupportedMessages => ResourceManager.GetString("SpiralsNotSupportedMessages", resourceCulture);

	internal static string StallCountGenericModelFamilyParameter => ResourceManager.GetString("StallCountGenericModelFamilyParameter", resourceCulture);

	internal static string StallLengthGenericModelFamilyParameter => ResourceManager.GetString("StallLengthGenericModelFamilyParameter", resourceCulture);

	internal static string StallOnArcMessage => ResourceManager.GetString("StallOnArcMessage", resourceCulture);

	internal static string StallOnLineMessage => ResourceManager.GetString("StallOnLineMessage", resourceCulture);

	internal static string StartingDistanceGenericFamilyParameter => ResourceManager.GetString("StartingDistanceGenericFamilyParameter", resourceCulture);

	internal static string StartingDistanceGreaterThanLineLengthMessage => ResourceManager.GetString("StartingDistanceGreaterThanLineLengthMessage", resourceCulture);

	internal static string StartsWithComparator => ResourceManager.GetString("StartsWithComparator", resourceCulture);

	internal static string StepsHeightParameter => ResourceManager.GetString("StepsHeightParameter", resourceCulture);

	internal static string StepsManagerString => ResourceManager.GetString("StepsManagerString", resourceCulture);

	internal static string StepsMaterialParameter => ResourceManager.GetString("StepsMaterialParameter", resourceCulture);

	internal static string StepsTreadParameter => ResourceManager.GetString("StepsTreadParameter", resourceCulture);

	internal static string StepsWidthParameter => ResourceManager.GetString("StepsWidthParameter", resourceCulture);

	internal static string StreetBaseSurfaceParameter => ResourceManager.GetString("StreetBaseSurfaceParameter", resourceCulture);

	internal static string StreetBoulevardWidthParameter => ResourceManager.GetString("StreetBoulevardWidthParameter", resourceCulture);

	internal static string StreetCrossSlopeParameter => ResourceManager.GetString("StreetCrossSlopeParameter", resourceCulture);

	internal static string StreetCurbDisplayParameter => ResourceManager.GetString("StreetCurbDisplayParameter", resourceCulture);

	internal static string StreetCurbHeightParameter => ResourceManager.GetString("StreetCurbHeightParameter", resourceCulture);

	internal static string StreetCurbMaterialParameter => ResourceManager.GetString("StreetCurbMaterialParameter", resourceCulture);

	internal static string StreetCurbOffsetParameter => ResourceManager.GetString("StreetCurbOffsetParameter", resourceCulture);

	internal static string StreetCurbWidthParameter => ResourceManager.GetString("StreetCurbWidthParameter", resourceCulture);

	internal static string StreetCutSlopeParameter => ResourceManager.GetString("StreetCutSlopeParameter", resourceCulture);

	internal static string StreetFamilyDialog => ResourceManager.GetString("StreetFamilyDialog", resourceCulture);

	internal static string StreetFamilyManagerRibbonButton => ResourceManager.GetString("StreetFamilyManagerRibbonButton", resourceCulture);

	internal static string StreetFamilyManagerToolTip => ResourceManager.GetString("StreetFamilyManagerToolTip", resourceCulture);

	internal static string StreetFamilyNotLoadedMessage => ResourceManager.GetString("StreetFamilyNotLoadedMessage", resourceCulture);

	internal static string StreetFillSlopeParameter => ResourceManager.GetString("StreetFillSlopeParameter", resourceCulture);

	internal static string StreetGutterSlopeParameter => ResourceManager.GetString("StreetGutterSlopeParameter", resourceCulture);

	internal static string StreetGutterWidthParameter => ResourceManager.GetString("StreetGutterWidthParameter", resourceCulture);

	internal static string StreetInfoTabString => ResourceManager.GetString("StreetInfoTabString", resourceCulture);

	internal static string StreetIntersectionDefaultRadius => ResourceManager.GetString("StreetIntersectionDefaultRadius", resourceCulture);

	internal static string StreetIntersectionDefaultTransitioningDistance => ResourceManager.GetString("StreetIntersectionDefaultTransitioningDistance", resourceCulture);

	internal static string StreetIntersectionNotOnStraightLinesMessage => ResourceManager.GetString("StreetIntersectionNotOnStraightLinesMessage", resourceCulture);

	internal static string StreetLaneWidthParameter => ResourceManager.GetString("StreetLaneWidthParameter", resourceCulture);

	internal static string StreetLineSubCategoryColor => ResourceManager.GetString("StreetLineSubCategoryColor", resourceCulture);

	internal static string StreetLineSubCategoryLineWeight => ResourceManager.GetString("StreetLineSubCategoryLineWeight", resourceCulture);

	internal static string StreetLineSubCategoryName => ResourceManager.GetString("StreetLineSubCategoryName", resourceCulture);

	internal static string StreetMassSubCategoryName => ResourceManager.GetString("StreetMassSubCategoryName", resourceCulture);

	internal static string StreetMassTemplateFileNameString => ResourceManager.GetString("StreetMassTemplateFileNameString", resourceCulture);

	internal static string StreetNa_AMP_meDialog => ResourceManager.GetString("StreetNa_AMP_meDialog", resourceCulture);

	internal static string StreetNameDialog => ResourceManager.GetString("StreetNameDialog", resourceCulture);

	internal static string StreetNumberOfLanesParameter => ResourceManager.GetString("StreetNumberOfLanesParameter", resourceCulture);

	internal static string StreetPavementDepthParameter => ResourceManager.GetString("StreetPavementDepthParameter", resourceCulture);

	internal static string StreetPavementSurfaceParameter => ResourceManager.GetString("StreetPavementSurfaceParameter", resourceCulture);

	internal static string StreetString => ResourceManager.GetString("StreetString", resourceCulture);

	internal static string StreetSubbaseSurfaceParameter => ResourceManager.GetString("StreetSubbaseSurfaceParameter", resourceCulture);

	internal static string StreetT_AMP_ypeDialog => ResourceManager.GetString("StreetT_AMP_ypeDialog", resourceCulture);

	internal static string StreetTemplateNotMassTypeMessage => ResourceManager.GetString("StreetTemplateNotMassTypeMessage", resourceCulture);

	internal static string StreetTypeDialog => ResourceManager.GetString("StreetTypeDialog", resourceCulture);

	internal static string StreetTypeManagerString => ResourceManager.GetString("StreetTypeManagerString", resourceCulture);

	internal static string SubregionBuildingPadBoundaryErrorMessage => ResourceManager.GetString("SubregionBuildingPadBoundaryErrorMessage", resourceCulture);

	internal static string SubRegionElement => ResourceManager.GetString("SubRegionElement", resourceCulture);

	internal static string SubRegionsInProposedSurfaceMessage => ResourceManager.GetString("SubRegionsInProposedSurfaceMessage", resourceCulture);

	internal static string SubRegionString => ResourceManager.GetString("SubRegionString", resourceCulture);

	internal static string SurfaceAreaSubRegionParameter => ResourceManager.GetString("SurfaceAreaSubRegionParameter", resourceCulture);

	internal static string SurfaceCleanUpTransaction => ResourceManager.GetString("SurfaceCleanUpTransaction", resourceCulture);

	internal static string SurfaceNameDialog => ResourceManager.GetString("SurfaceNameDialog", resourceCulture);

	internal static string SurfaceNameString => ResourceManager.GetString("SurfaceNameString", resourceCulture);

	internal static string SurfaceNotSelectedString => ResourceManager.GetString("SurfaceNotSelectedString", resourceCulture);

	internal static string SWCurbLineNameString => ResourceManager.GetString("SWCurbLineNameString", resourceCulture);

	internal static string SWFeatureLineLineNameString => ResourceManager.GetString("SWFeatureLineLineNameString", resourceCulture);

	internal static string SWIntersectionLineNameString => ResourceManager.GetString("SWIntersectionLineNameString", resourceCulture);

	internal static string SWParkingLotLineNameString => ResourceManager.GetString("SWParkingLotLineNameString", resourceCulture);

	internal static string SWPointWipeoutLineNameString => ResourceManager.GetString("SWPointWipeoutLineNameString", resourceCulture);

	internal static string SWRetainingWallLineNameString => ResourceManager.GetString("SWRetainingWallLineNameString", resourceCulture);

	internal static string SWSidewalkLineNameString => ResourceManager.GetString("SWSidewalkLineNameString", resourceCulture);

	internal static string SWSoftTerrainLineNameString => ResourceManager.GetString("SWSoftTerrainLineNameString", resourceCulture);

	internal static string SWStreetLineNameString => ResourceManager.GetString("SWStreetLineNameString", resourceCulture);

	internal static string Sym_AMP_bolNameDialog => ResourceManager.GetString("Sym_AMP_bolNameDialog", resourceCulture);

	internal static string SymbolIDGenericFamilyParameter => ResourceManager.GetString("SymbolIDGenericFamilyParameter", resourceCulture);

	internal static string SymbolNoRFAExtension => ResourceManager.GetString("SymbolNoRFAExtension", resourceCulture);

	internal static string TemperatureRangePlantFamilyParameter => ResourceManager.GetString("TemperatureRangePlantFamilyParameter", resourceCulture);

	internal static string TemplateNotLoadedErrorMessage => ResourceManager.GetString("TemplateNotLoadedErrorMessage", resourceCulture);

	internal static string TemplateNotPickedFamilyNotCreatedMessage => ResourceManager.GetString("TemplateNotPickedFamilyNotCreatedMessage", resourceCulture);

	internal static string The_String => ResourceManager.GetString("The_String", resourceCulture);

	internal static string ThereAreNoString_ => ResourceManager.GetString("ThereAreNoString_", resourceCulture);

	internal static string ThicknessPathWalkFamilyParameter => ResourceManager.GetString("ThicknessPathWalkFamilyParameter", resourceCulture);

	internal static string ThreeDDWGSymbolDimensionType => ResourceManager.GetString("ThreeDDWGSymbolDimensionType", resourceCulture);

	internal static string ThreeDString => ResourceManager.GetString("ThreeDString", resourceCulture);

	internal static string TickLengthPlantParameter => ResourceManager.GetString("TickLengthPlantParameter", resourceCulture);

	internal static string TopoDrawOrderFamilyParameter => ResourceManager.GetString("TopoDrawOrderFamilyParameter", resourceCulture);

	internal static string TopographySurfaceArcPointInterval => ResourceManager.GetString("TopographySurfaceArcPointInterval", resourceCulture);

	internal static string Toposurface_AMP_NameSurfaceInfoDialog => ResourceManager.GetString("Toposurface_AMP_NameSurfaceInfoDialog", resourceCulture);

	internal static string ToposurfaceAlreadyPickedMessage => ResourceManager.GetString("ToposurfaceAlreadyPickedMessage", resourceCulture);

	internal static string ToposurfaceAssociationDialog => ResourceManager.GetString("ToposurfaceAssociationDialog", resourceCulture);

	internal static string ToposurfaceConversionRibbonButton => ResourceManager.GetString("ToposurfaceConversionRibbonButton", resourceCulture);

	internal static string ToposurfaceDialog => ResourceManager.GetString("ToposurfaceDialog", resourceCulture);

	internal static string ToposurfaceIDFamilyParameter => ResourceManager.GetString("ToposurfaceIDFamilyParameter", resourceCulture);

	internal static string ToposurfaceNotCreatedMessage => ResourceManager.GetString("ToposurfaceNotCreatedMessage", resourceCulture);

	internal static string ToposurfaceSameNameAndPhaseMessage => ResourceManager.GetString("ToposurfaceSameNameAndPhaseMessage", resourceCulture);

	internal static string ToposurfaceSelectionDialog => ResourceManager.GetString("ToposurfaceSelectionDialog", resourceCulture);

	internal static string ToposurfacesString => ResourceManager.GetString("ToposurfacesString", resourceCulture);

	internal static string ToposurfacesToExportDialog => ResourceManager.GetString("ToposurfacesToExportDialog", resourceCulture);

	internal static string ToposurfaceString => ResourceManager.GetString("ToposurfaceString", resourceCulture);

	internal static string ToposurfacNotInProjectMessage => ResourceManager.GetString("ToposurfacNotInProjectMessage", resourceCulture);

	internal static string TopViewDirection => ResourceManager.GetString("TopViewDirection", resourceCulture);

	internal static string TransitioningDistanceAndRadiusInvalidMessage => ResourceManager.GetString("TransitioningDistanceAndRadiusInvalidMessage", resourceCulture);

	internal static string TransitioningDistanceMakesDistanceMoreThanHostLineMessage => ResourceManager.GetString("TransitioningDistanceMakesDistanceMoreThanHostLineMessage", resourceCulture);

	internal static string TransitioningDistanceParameter => ResourceManager.GetString("TransitioningDistanceParameter", resourceCulture);

	internal static string Triang_AMP_ularDialog => ResourceManager.GetString("Triang_AMP_ularDialog", resourceCulture);

	internal static string TrunkHeightPlantParameter => ResourceManager.GetString("TrunkHeightPlantParameter", resourceCulture);

	internal static string TrunkRadiusPlantParameter => ResourceManager.GetString("TrunkRadiusPlantParameter", resourceCulture);

	internal static string TwoDDWGSymbolDimensionType => ResourceManager.GetString("TwoDDWGSymbolDimensionType", resourceCulture);

	internal static string TypeCommentsGenericFamilyParameter => ResourceManager.GetString("TypeCommentsGenericFamilyParameter", resourceCulture);

	internal static string TypeCommentsPlantFamilyParameter => ResourceManager.GetString("TypeCommentsPlantFamilyParameter", resourceCulture);

	internal static string TypeManagerDialog => ResourceManager.GetString("TypeManagerDialog", resourceCulture);

	internal static string TypeNameGenericModelFamilyParameter => ResourceManager.GetString("TypeNameGenericModelFamilyParameter", resourceCulture);

	internal static string TypeNameMissing => ResourceManager.GetString("TypeNameMissing", resourceCulture);

	internal static string TypeNamePlantFamilyType => ResourceManager.GetString("TypeNamePlantFamilyType", resourceCulture);

	internal static string TypeParameterFamilyFileMessage => ResourceManager.GetString("TypeParameterFamilyFileMessage", resourceCulture);

	internal static string TypeParameterFamilyMessage => ResourceManager.GetString("TypeParameterFamilyMessage", resourceCulture);

	internal static string TypeParameterFamilyNotLoadedMessage => ResourceManager.GetString("TypeParameterFamilyNotLoadedMessage", resourceCulture);

	internal static string UnableCreateFamilyString => ResourceManager.GetString("UnableCreateFamilyString", resourceCulture);

	internal static string UnableToCeateBlendGeometry => ResourceManager.GetString("UnableToCeateBlendGeometry", resourceCulture);

	internal static string UnableToCreateMassMessage => ResourceManager.GetString("UnableToCreateMassMessage", resourceCulture);

	internal static string Unassign_Message => ResourceManager.GetString("Unassign_Message", resourceCulture);

	internal static string UnassignDialog => ResourceManager.GetString("UnassignDialog", resourceCulture);

	internal static string UndefinedDetailLevel => ResourceManager.GetString("UndefinedDetailLevel", resourceCulture);

	internal static string UniqueIDGenericModelFamilyParameter => ResourceManager.GetString("UniqueIDGenericModelFamilyParameter", resourceCulture);

	internal static string UnnamedSurfaceDialog => ResourceManager.GetString("UnnamedSurfaceDialog", resourceCulture);

	internal static string UpdatingFamilyTransaction => ResourceManager.GetString("UpdatingFamilyTransaction", resourceCulture);

	internal static string URLGenericFamilyParameter => ResourceManager.GetString("URLGenericFamilyParameter", resourceCulture);

	internal static string URLPlantFamilyParameter => ResourceManager.GetString("URLPlantFamilyParameter", resourceCulture);

	internal static string UseCentimeterUnitsOption => ResourceManager.GetString("UseCentimeterUnitsOption", resourceCulture);

	internal static string UseFeetUnitsOption => ResourceManager.GetString("UseFeetUnitsOption", resourceCulture);

	internal static string UseInchUnitsOption => ResourceManager.GetString("UseInchUnitsOption", resourceCulture);

	internal static string UseMeterUnitsOption => ResourceManager.GetString("UseMeterUnitsOption", resourceCulture);

	internal static string UseMillimeterUnitsOption => ResourceManager.GetString("UseMillimeterUnitsOption", resourceCulture);

	internal static string UsePlacementElevationsFamilyParameter => ResourceManager.GetString("UsePlacementElevationsFamilyParameter", resourceCulture);

	internal static string UseRightSideGenericFamilyParameter => ResourceManager.GetString("UseRightSideGenericFamilyParameter", resourceCulture);

	internal static string UserInformationString => ResourceManager.GetString("UserInformationString", resourceCulture);

	internal static string UseSharedElevation => ResourceManager.GetString("UseSharedElevation", resourceCulture);

	internal static string ValidEdgeWidth => ResourceManager.GetString("ValidEdgeWidth", resourceCulture);

	internal static string ValidFields => ResourceManager.GetString("ValidFields", resourceCulture);

	internal static string ValidLineWeightValuesMessage => ResourceManager.GetString("ValidLineWeightValuesMessage", resourceCulture);

	internal static string ValidPlantHeightMessage => ResourceManager.GetString("ValidPlantHeightMessage", resourceCulture);

	internal static string ValidPlantHeightVarianceMessage => ResourceManager.GetString("ValidPlantHeightVarianceMessage", resourceCulture);

	internal static string ValidPlantSpacingMessage => ResourceManager.GetString("ValidPlantSpacingMessage", resourceCulture);

	internal static string ValidPlantWidthMessage => ResourceManager.GetString("ValidPlantWidthMessage", resourceCulture);

	internal static string ValidPlantWidthVarianceMessage => ResourceManager.GetString("ValidPlantWidthVarianceMessage", resourceCulture);

	internal static string ValidSetbackMessage => ResourceManager.GetString("ValidSetbackMessage", resourceCulture);

	internal static string ValidTypeCommonOrScientificName => ResourceManager.GetString("ValidTypeCommonOrScientificName", resourceCulture);

	internal static string ValidTypeMessage => ResourceManager.GetString("ValidTypeMessage", resourceCulture);

	internal static string Value => ResourceManager.GetString("Value", resourceCulture);

	internal static string Varianc_AMP_eDialog => ResourceManager.GetString("Varianc_AMP_eDialog", resourceCulture);

	internal static string VarianceMoreThanPlantHeightMessage => ResourceManager.GetString("VarianceMoreThanPlantHeightMessage", resourceCulture);

	internal static string VarianceMoreThanPlantWidthMessage => ResourceManager.GetString("VarianceMoreThanPlantWidthMessage", resourceCulture);

	internal static string VersionDialog => ResourceManager.GetString("VersionDialog", resourceCulture);

	internal static string ViewNameString => ResourceManager.GetString("ViewNameString", resourceCulture);

	internal static string VisibleString => ResourceManager.GetString("VisibleString", resourceCulture);

	internal static string VolumeString => ResourceManager.GetString("VolumeString", resourceCulture);

	internal static string WallCantBePlacedWithDaylightingMessage => ResourceManager.GetString("WallCantBePlacedWithDaylightingMessage", resourceCulture);

	internal static string WallCantBePlacedWithGreaterElevationMessage => ResourceManager.GetString("WallCantBePlacedWithGreaterElevationMessage", resourceCulture);

	internal static string Warning => ResourceManager.GetString("Warning", resourceCulture);

	internal static string WarningDialog => ResourceManager.GetString("WarningDialog", resourceCulture);

	internal static string WidthGenericFamilyParameter => ResourceManager.GetString("WidthGenericFamilyParameter", resourceCulture);

	internal static string WidthVarianceGenericFamilyParameter => ResourceManager.GetString("WidthVarianceGenericFamilyParameter", resourceCulture);

	internal static string WorksetPermissionErrorDialog => ResourceManager.GetString("WorksetPermissionErrorDialog", resourceCulture);

	internal static string YesString => ResourceManager.GetString("YesString", resourceCulture);

	internal WinFormStrings()
	{
	}
}
