﻿// Decompiled with JetBrains decompiler
// Type: SITES.WinFormStrings
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace SITES;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class WinFormStrings
{
  private static ResourceManager resourceMan;
  private static CultureInfo resourceCulture;

  internal WinFormStrings()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      if (WinFormStrings.resourceMan == null)
        WinFormStrings.resourceMan = new ResourceManager("SITES.WinFormStrings", typeof (WinFormStrings).Assembly);
      return WinFormStrings.resourceMan;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get => WinFormStrings.resourceCulture;
    set => WinFormStrings.resourceCulture = value;
  }

  internal static string __GenericModelFamilyString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (__GenericModelFamilyString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _And_
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (_And_), WinFormStrings.resourceCulture);
  }

  internal static string _AssignFor_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_AssignFor_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string _AssignTo_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_AssignTo_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamiliesInModelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamiliesInModelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _Family_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_Family_), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamilyCannotBePlaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamilyCannotBePlaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamilyManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamilyManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamilyNotLoaded_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamilyNotLoaded_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamilyTypeNotFoundDeleteMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamilyTypeNotFoundDeleteMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FamilyTypeNotFoundMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FamilyTypeNotFoundMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _FeaturesInThisModelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_FeaturesInThisModelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _From_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_From_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string _HostLineString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_HostLineString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _InSettingString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_InSettingString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _InvalidTypeNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_InvalidTypeNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _LeadingAndTrailingSpacesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_LeadingAndTrailingSpacesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _ParametersNotPartOfFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_ParametersNotPartOfFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _PlacedWontUpdateWithHost_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_PlacedWontUpdateWithHost_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string _RegionNameAlreadyAssigned_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_RegionNameAlreadyAssigned_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string _TypeParameterPFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_TypeParameterPFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string _TypeParameterString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_TypeParameterString), WinFormStrings.resourceCulture);
    }
  }

  internal static string _TypeString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (_TypeString), WinFormStrings.resourceCulture);
    }
  }

  internal static string A_AMP_ddDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (A_AMP_ddDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string A_AMP_geDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (A_AMP_geDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AboutLANDCADDForRevitDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AboutLANDCADDForRevitDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AboutRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AboutRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string AboutSiteDesignerForRevitDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AboutSiteDesignerForRevitDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AboutSiteworksRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AboutSiteworksRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ADASpacingDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ADASpacingDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ADAStallCountGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ADAStallCountGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ADAStallSharedAccessibleAisleGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ADAStallSharedAccessibleAisleGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ADAStallSymbolIDGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ADAStallSymbolIDGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ADAStallWidthGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ADAStallWidthGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Add_AMP_BreaklineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Add_AMP_BreaklineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Add_AMP_NewSurfaceSurfaceInfoDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Add_AMP_NewSurfaceSurfaceInfoDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Add_AMP_VertexDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Add_AMP_VertexDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddBreaklineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddBreaklineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddBuildingPadsPointsToSurfacesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddBuildingPadsPointsToSurfacesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddBuildingPadsToProposedSurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddBuildingPadsToProposedSurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddBuildingPadsToSurfaceTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddBuildingPadsToSurfaceTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddInsRibbonTabIDValue
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddInsRibbonTabIDValue), WinFormStrings.resourceCulture);
    }
  }

  internal static string AdditionalFormIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AdditionalFormIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddParametersToFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddParametersToFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string AddSubRegionsToProposedSurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AddSubRegionsToProposedSurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string AisleWidthString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AisleWidthString), WinFormStrings.resourceCulture);
    }
  }

  internal static string Ali_AMP_gnToDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Ali_AMP_gnToDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AlignmentNotSelectedString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AlignmentNotSelectedString), WinFormStrings.resourceCulture);
    }
  }

  internal static string AlignmentSelectionDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AlignmentSelectionDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AlignmentToExportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AlignmentToExportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AlignToGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AlignToGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string All_AMP_InstancesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (All_AMP_InstancesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AllGeometryString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AllGeometryString), WinFormStrings.resourceCulture);
    }
  }

  internal static string AllGeometryStringQuotes
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AllGeometryStringQuotes), WinFormStrings.resourceCulture);
    }
  }

  internal static string AllignmentString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AllignmentString), WinFormStrings.resourceCulture);
    }
  }

  internal static string AllString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AllString), WinFormStrings.resourceCulture);
    }
  }

  internal static string AllSymbolsString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AllSymbolsString), WinFormStrings.resourceCulture);
    }
  }

  internal static string AllwaysLoadDefaultFamiliesOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AllwaysLoadDefaultFamiliesOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AddAllDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AddAllDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AddDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AddDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AddToFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AddToFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AllCirclesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AllCirclesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AlternateDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AlternateDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AngleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AngleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ApplyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ApplyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_AreaDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_AreaDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_BeginningElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_BeginningElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_BlackAndWhiteDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_BlackAndWhiteDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CancelDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CancelDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ChainDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ChainDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ChangeElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ChangeElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CloseDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CloseDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CompanyExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CompanyExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ComponentFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ComponentFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ConvertDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ConvertDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CopyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CopyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CSVFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CSVFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CurbFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CurbFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_CurrentRadiusDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_CurrentRadiusDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DeleteDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DeleteDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DetailLevelDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DetailLevelDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DirectoryDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DirectoryDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DirectoryMultipleFilesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DirectoryMultipleFilesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DoNotShowMessageDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DoNotShowMessageDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DoubleRowDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DoubleRowDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DownloadNow
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DownloadNow), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_DrawHostLineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_DrawHostLineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ElevationsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ElevationsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_EqualDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_EqualDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ExportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ExportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FenceFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FenceFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FileNameExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FileNameExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FileNameImportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FileNameImportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FindDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FindDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_FinishDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_FinishDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_GradeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_GradeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_GradesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_GradesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_GroveDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_GroveDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_HedgeRowDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_HedgeRowDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_HeightDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_HeightDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ImageTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ImageTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_InsertDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_InsertDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_LayersDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_LayersDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_LengthDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_LengthDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_LevelDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_LevelDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_LoadDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_LoadDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ModifyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ModifyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ModifyPlantTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ModifyPlantTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_MoveDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_MoveDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_MoveUpDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_MoveUpDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_New_NewFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_New_NewFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NewElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NewElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NewFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NewFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NewGradeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NewGradeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NewLinearDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NewLinearDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NewRadiusDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NewRadiusDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NewViewScaleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NewViewScaleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_NumberOfRowsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_NumberOfRowsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_OffsetDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_OffsetDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_OKDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_OKDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_OptimizeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_OptimizeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_OverwriteExistingSurfaceSurfaceInfoDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_OverwriteExistingSurfaceSurfaceInfoDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ParameterDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ParameterDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ParkingLotFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ParkingLotFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_PhaseCreatedFamilyParameterSurfaceInfoDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_PickDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_PickDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_PlaceAlongDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_PlaceAlongDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_PlantFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_PlantFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_PositioningDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_PositioningDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_PreserveColorsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_PreserveColorsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ProjectNameExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ProjectNameExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_RadiusDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_RadiusDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_RegionNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_RegionNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_RemoveDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_RemoveDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_RetainingWallFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_RetainingWallFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_RFAFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_RFAFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_RotateDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_RotateDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ScaleFactorDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ScaleFactorDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SearchDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SearchDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SegmentDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SegmentDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_Select
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_Select), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SelectionSetDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SelectionSetDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SetbackDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SetbackDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ShowDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ShowDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SideDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SideDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SingleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SingleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SingleFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SingleFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_SingleRowDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_SingleRowDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_TabFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_TabFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_TextTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_TextTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ToposurfaceNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ToposurfaceNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ToposurfaceToOverwriteSurfaceInfoDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ToposurfaceToOverwriteSurfaceInfoDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_UseBiDirectionalAislesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_UseBiDirectionalAislesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_UseExistingHostLineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_UseExistingHostLineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_UseParametersDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_UseParametersDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_VarianceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_VarianceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_ViewDirectionDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_ViewDirectionDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_WidthDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_WidthDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AMP_WindowSelectDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AMP_WindowSelectDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AnnotateRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AnnotateRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string AnnotateRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AnnotateRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string AnnotateSiteComponentTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AnnotateSiteComponentTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string AnnotateTitleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AnnotateTitleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ArcPickedClosedProjectInnerSlopesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ArcPickedClosedProjectInnerSlopesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaAisleWidthGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaAisleWidthGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaBidirectionalAislesGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaBidirectionalAislesGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaDistanceBetweenCenterlinesGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaDistanceBetweenCenterlinesGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaPlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaPlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaRegionParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaRegionParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaRowCountGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaRowCountGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaRowSpacingOptionsGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaRowSpacingOptionsGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string AreaString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AreaString), WinFormStrings.resourceCulture);
    }
  }

  internal static string AssemblyCodeGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AssemblyCodeGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Assign_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Assign_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string AssignDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AssignDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AssignPatioWalkTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AssignPatioWalkTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string AssignPlantMixTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AssignPlantMixTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string AutodeskSiteDesignerForRevitDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AutodeskSiteDesignerForRevitDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AutoDetectUnit
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AutoDetectUnit), WinFormStrings.resourceCulture);
    }
  }

  internal static string AutomaticallyPlaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AutomaticallyPlaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string AvailableParametersDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (AvailableParametersDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string B_AMP_ySharedCoordinatesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (B_AMP_ySharedCoordinatesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string B_AMP_ySurveyPointsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (B_AMP_ySurveyPointsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string BackViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BackViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string BaseSurfaceLinkBrokenMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BaseSurfaceLinkBrokenMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string BaseToposurfaceAlreadySeteMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BaseToposurfaceAlreadySeteMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string BaseToposurfaceCreatedFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BaseToposurfaceCreatedFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BaseToposurfaceString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BaseToposurfaceString), WinFormStrings.resourceCulture);
    }
  }

  internal static string BeginningElevationFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BeginningElevationFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BlackAndWhiteColorMode
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BlackAndWhiteColorMode), WinFormStrings.resourceCulture);
    }
  }

  internal static string BorrowLicenseRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BorrowLicenseRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string BorrowLicenseRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BorrowLicenseRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string BottomViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BottomViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string BoundaryClosedChainMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BoundaryClosedChainMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string BoundaryIslandIDGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BoundaryIslandIDGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BreaklinesNotInParkingLotBoundaryMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BreaklinesNotInParkingLotBoundaryMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string BuildingPadString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BuildingPadString), WinFormStrings.resourceCulture);
    }
  }

  internal static string BumperDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BumperDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string BumperHeightGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BumperHeightGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BumperOffsetGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BumperOffsetGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BumperSetbackGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BumperSetbackGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BumperSymbolIDGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BumperSymbolIDGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string BumperWidthGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (BumperWidthGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ByN_AMP_umberDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ByN_AMP_umberDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string C_AMP_enterDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (C_AMP_enterDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string C_AMP_hangeIntervalDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (C_AMP_hangeIntervalDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string C_AMP_hangeTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (C_AMP_hangeTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string C_AMP_omponentNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (C_AMP_omponentNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CannotImport_String
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CannotImport_String), WinFormStrings.resourceCulture);
    }
  }

  internal static string CantEditElementsUntilUserResavesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CantEditElementsUntilUserResavesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string CantObtainPermissionToEditElementMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CantObtainPermissionToEditElementMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Cen_AMP_terToCenterDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Cen_AMP_terToCenterDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CenterString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CenterString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CenterToCenterPlacement
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CenterToCenterPlacement), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChainIDGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChainIDGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChainPickedClosedProjectInnerSlopesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChainPickedClosedProjectInnerSlopesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeFamilyTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeFamilyTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeGradeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeGradeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeLinearIntervalDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeLinearIntervalDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeRadiusDialogTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeRadiusDialogTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeView_AMP_ScaleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeView_AMP_ScaleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ChangeViewScaleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ChangeViewScaleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Characteristics
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Characteristics), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsAdmirationPointPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsAdmirationPointPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsBarkColorPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsBarkColorPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsBarkSurfacePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsBarkSurfacePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsBloomEffectPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsBloomEffectPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsBloomPeriodPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsBloomPeriodPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsCrownDensityPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsCrownDensityPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFallColorPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFallColorPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFoliageColorPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFoliageColorPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFoliageSizePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFoliageSizePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFoliageSurfacePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFoliageSurfacePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFragrancePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFragrancePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFruitColorPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFruitColorPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CharacteristicsFruitPeriodPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CharacteristicsFruitPeriodPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CheckForUpdateNotification
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CheckForUpdateNotification), WinFormStrings.resourceCulture);
    }
  }

  internal static string CircleAlreadyPickedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CircleAlreadyPickedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Co_AMP_nstantElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Co_AMP_nstantElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CoarseDetailLevel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CoarseDetailLevel), WinFormStrings.resourceCulture);
    }
  }

  internal static string CodeNamePlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CodeNamePlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CollectionDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CollectionDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Column_AMP_DisplayDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Column_AMP_DisplayDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ColumnDisplayFormDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ColumnDisplayFormDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ColumnMisMatchMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ColumnMisMatchMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ColumnOrderString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ColumnOrderString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CommonNamePlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CommonNamePlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ComparisonTypeString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ComparisonTypeString), WinFormStrings.resourceCulture);
    }
  }

  internal static string Component_AMP_SpacingDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Component_AMP_SpacingDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ComponentFamilyCantBeLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ComponentFamilyCantBeLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ComponentFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ComponentFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConceptualMassFolder
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConceptualMassFolder), WinFormStrings.resourceCulture);
    }
  }

  internal static string Condition
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Condition), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConditionsExposurePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConditionsExposurePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConditionsMiscellaneousPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConditionsMiscellaneousPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConditionsSoilConditionPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConditionsSoilConditionPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConditionsTolerancesPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConditionsTolerancesPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Constant_AMP_ElevationsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Constant_AMP_ElevationsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConstantElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConstantElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ContainsComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ContainsComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string ContentInstalledName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ContentInstalledName), WinFormStrings.resourceCulture);
    }
  }

  internal static string ContinueWOLoadFamiliesOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ContinueWOLoadFamiliesOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string ContinueWOLoadFamilyOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ContinueWOLoadFamilyOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertObjectToToposurfaceRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertObjectToToposurfaceRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertObjectToToposurfaceRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertObjectToToposurfaceRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertObjectToToposurfaceTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertObjectToToposurfaceTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertObjectToToposurfaceTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertObjectToToposurfaceTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertPlantsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertPlantsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertPlantSearchTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertPlantSearchTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertPlantsTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertPlantsTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ConvertRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ConvertRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string Copy_
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (Copy_), WinFormStrings.resourceCulture);
  }

  internal static string CopyrightDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CopyrightDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CostGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CostGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CostPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CostPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Cr_AMP_eateSymbolDWGDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Cr_AMP_eateSymbolDWGDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Create_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Create_), WinFormStrings.resourceCulture);
    }
  }

  internal static string Create_AMP_ACopyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Create_AMP_ACopyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Created_AMP_ByExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Created_AMP_ByExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreatedBy_AMP_EmailExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreatedBy_AMP_EmailExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreateLineSubCategoriesTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreateLineSubCategoriesTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreateMassFormTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreateMassFormTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreateNewToposurfaceOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreateNewToposurfaceOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreatePatioWalkFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreatePatioWalkFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreatePlant_AMP_GroupTagDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreatePlant_AMP_GroupTagDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreatePlantFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreatePlantFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreatePlantMixFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreatePlantMixFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreateSharedParameterFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreateSharedParameterFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CreatingFamilyTypeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CreatingFamilyTypeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbBaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbBaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbFamilyManagerToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbFamilyManagerToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbGutterHeightParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbGutterHeightParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbGutterSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbGutterSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbGutterTabString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbGutterTabString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbMassSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbMassSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbMassTemplateFileNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbMassTemplateFileNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbMaterialParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbMaterialParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbNa_AMP_meDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbNa_AMP_meDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbSubbaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbSubbaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbT_AMP_ypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbT_AMP_ypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbTemplateNotMassTypeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbTemplateNotMassTypeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurbTypeManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurbTypeManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentFamilyNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentFamilyNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentGradeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentGradeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentLinearDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentLinearDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentSlopeUnitString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentSlopeUnitString), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurrentViewScaleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurrentViewScaleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string CurveIncrementParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CurveIncrementParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string CustomUnit
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (CustomUnit), WinFormStrings.resourceCulture);
    }
  }

  internal static string D_AMP_eleteVertexDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (D_AMP_eleteVertexDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string D_AMP_WGSymbolDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (D_AMP_WGSymbolDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string De_AMP_leteBreaklineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (De_AMP_leteBreaklineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string DefaultLineColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DefaultLineColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string DeleteE_AMP_xistingElementDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DeleteE_AMP_xistingElementDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string DeleteFromL_AMP_ampDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DeleteFromL_AMP_ampDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string DeleteSiteComponentLineMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DeleteSiteComponentLineMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string DeleteSiteComponentOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DeleteSiteComponentOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string DescriptionGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DescriptionGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string DescriptionPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DescriptionPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string DestinationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DestinationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string DestinationFamilyOverWrite
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DestinationFamilyOverWrite), WinFormStrings.resourceCulture);
    }
  }

  internal static string DestinationOverWrite
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DestinationOverWrite), WinFormStrings.resourceCulture);
    }
  }

  internal static string DestinationPlantFamilyParametersFormDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DestinationPlantFamilyParametersFormDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string DetailFilledRegionElementName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DetailFilledRegionElementName), WinFormStrings.resourceCulture);
    }
  }

  internal static string DifferentPhasingForBuildingPadsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DifferentPhasingForBuildingPadsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string DisplayAnd_AMP_UseExistingHostLineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DisplayAnd_AMP_UseExistingHostLineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string DistBetweenLinesString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DistBetweenLinesString), WinFormStrings.resourceCulture);
    }
  }

  internal static string DuplicateEdgeString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DuplicateEdgeString), WinFormStrings.resourceCulture);
    }
  }

  internal static string DuplicateFamilyInFamilyManagerMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DuplicateFamilyInFamilyManagerMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string DuplicateFamilySymbolMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DuplicateFamilySymbolMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string DuplicateTypeAppendMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DuplicateTypeAppendMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string DuplicateTypeNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (DuplicateTypeNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string E_AMP_xportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (E_AMP_xportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string E_AMP_xportFamilyInformationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (E_AMP_xportFamilyInformationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string EaglePointLANDCADDForRevitDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EaglePointLANDCADDForRevitDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string EastWestBasePointParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EastWestBasePointParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string EdgePathWalkFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EdgePathWalkFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string EdgeWidthPathWalkFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EdgeWidthPathWalkFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Ele_AMP_vationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Ele_AMP_vationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Elevatio_AMP_nRangeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Elevatio_AMP_nRangeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ElevationBasePointParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ElevationBasePointParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ElevationFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ElevationFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string EndingEle_AMP_vationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EndingEle_AMP_vationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string EndingElevationFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EndingElevationFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string EndsWithComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EndsWithComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string ENU_ImperialTemplateFolderName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString("ENU-ImperialTemplateFolderName", WinFormStrings.resourceCulture);
    }
  }

  internal static string ENU_MetricTemplateFolderName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString("ENU-MetricTemplateFolderName", WinFormStrings.resourceCulture);
    }
  }

  internal static string EqualComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (EqualComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string Error
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (Error), WinFormStrings.resourceCulture);
  }

  internal static string ErrorParsingXMLFileString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ErrorParsingXMLFileString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExistingEle_AMP_mentDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExistingEle_AMP_mentDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExistingPlantsInProjDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExistingPlantsInProjDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExistingSymbolFileName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExistingSymbolFileName), WinFormStrings.resourceCulture);
    }
  }

  internal static string Export_AMP_AligmentsExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Export_AMP_AligmentsExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Export_AMP_RegionInformationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Export_AMP_RegionInformationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Export_AMP_TopoSurfacesExportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Export_AMP_TopoSurfacesExportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportAlignmentLandXMLCompleteString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportAlignmentLandXMLCompleteString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportCompleteMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportCompleteMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportLandXMLComponentsCompleteString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportLandXMLComponentsCompleteString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportLandXMLRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportLandXMLRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportLandXMLRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportLandXMLRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportLandXMLString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportLandXMLString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportOptionsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportOptionsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportSurfaceLandXMLCompleteString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportSurfaceLandXMLCompleteString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExportType_AMP_InformationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExportType_AMP_InformationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ExternalComponentExceptionMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ExternalComponentExceptionMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string F_AMP_enceNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (F_AMP_enceNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string FailedCreatingSharedParameterMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FailedCreatingSharedParameterMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Family_AMP_Name_CopyFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Family_AMP_Name_CopyFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Family_AMP_Name_NewFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Family_AMP_Name_NewFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyCannotbeLoadedPickanother_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyCannotbeLoadedPickanother_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyLoadedNotA_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyLoadedNotA_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblCurbText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblCurbText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblParkingLotText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblParkingLotText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblRetainingWallText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblRetainingWallText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblSidewalkText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblSidewalkText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblSoftTerrainText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblSoftTerrainText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblStepsText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblStepsText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerLblStreetText
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerLblStreetText), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyManagerRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyManagerRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNameFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNameFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNotComponentMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNotComponentMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNotFenceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNotFenceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNotParkingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNotParkingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNotPlantingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNotPlantingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNotPlantingTagMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNotPlantingTagMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyNotSoftTerrainMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyNotSoftTerrainMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyString), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilySymbolNameFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilySymbolNameFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilySymbolOptionsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilySymbolOptionsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyTemplatePath
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyTemplatePath), WinFormStrings.resourceCulture);
    }
  }

  internal static string FamilyTypeString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FamilyTypeString), WinFormStrings.resourceCulture);
    }
  }

  internal static string FeatureLineLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FeatureLineLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string FeatureLineLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FeatureLineLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string FeatureLineLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FeatureLineLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string FeatureLineRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FeatureLineRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string FeatureLineString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FeatureLineString), WinFormStrings.resourceCulture);
    }
  }

  internal static string Fence_AMP_HeightDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Fence_AMP_HeightDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceError
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceError), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceFamilyAngleParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceFamilyAngleParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceFamilyCantBeLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceFamilyCantBeLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceFamilyHeightParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceFamilyHeightParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceFamilyNotLoadedWithIDMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceFamilyNotLoadedWithIDMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceFamilySpanParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceFamilySpanParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceLeftVisiability
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceLeftVisiability), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceRightVisiability
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceRightVisiability), WinFormStrings.resourceCulture);
    }
  }

  internal static string FenceS_AMP_panDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FenceS_AMP_panDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Fi_AMP_leDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Fi_AMP_leDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Fi_AMP_lterDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Fi_AMP_lterDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string FieldsFoundWithLengthMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FieldsFoundWithLengthMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FileExistsOverwriteMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FileExistsOverwriteMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FileOverwriteMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FileOverwriteMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string FilterString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FilterString), WinFormStrings.resourceCulture);
    }
  }

  internal static string FindFamilySymbolsTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FindFamilySymbolsTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string FineDetailLevel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FineDetailLevel), WinFormStrings.resourceCulture);
    }
  }

  internal static string FrontViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (FrontViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string GeneralParametersTabString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GeneralParametersTabString), WinFormStrings.resourceCulture);
    }
  }

  internal static string GeneralString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GeneralString), WinFormStrings.resourceCulture);
    }
  }

  internal static string GenericImperialTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GenericImperialTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string GenericMetricTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GenericMetricTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string GenericModelLandcaddID_String
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GenericModelLandcaddID_String), WinFormStrings.resourceCulture);
    }
  }

  internal static string GenericModelSymbolPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GenericModelSymbolPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string GetFamilyInformationTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GetFamilyInformationTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string GetFamilyTypesTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GetFamilyTypesTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string GetNewRevitVersionMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GetNewRevitVersionMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string GetPlantSymbolTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GetPlantSymbolTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string GreaterThanComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GreaterThanComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string GreaterThanOrEqualToComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GreaterThanOrEqualToComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string GroveRotationGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GroveRotationGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Growth
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Growth), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthFormPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthFormPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthGrowthRatePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthGrowthRatePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthPatternPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthPatternPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthServiceLifePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthServiceLifePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthSimulationNoFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthSimulationNoFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthSimulationNoLandCaddFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthSimulationNoLandCaddFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string GrowthSimulationTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (GrowthSimulationTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string HeightGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (HeightGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string HeightPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (HeightPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string HeightVarianceGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (HeightVarianceGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string I_AMP_nvertColorsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (I_AMP_nvertColorsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string IDString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IDString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImperialTemplateCabName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImperialTemplateCabName), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImperialTemplatesDirectory
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImperialTemplatesDirectory), WinFormStrings.resourceCulture);
    }
  }

  internal static string Import_AMP_AligmentsInXMLImportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Import_AMP_AligmentsInXMLImportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Import_AMP_ToposurfacesInXMLImportXMLDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Import_AMP_ToposurfacesInXMLImportXMLDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Import_AMP_UnitsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Import_AMP_UnitsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportDrawingTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportDrawingTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportDWGTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportDWGTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportExportRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportExportRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportFailedString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportFailedString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportingToposurfaceString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportingToposurfaceString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportLandTitleString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportLandTitleString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportLandXMLComponentsCompleteString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportLandXMLComponentsCompleteString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportLandXMLRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportLandXMLRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportLandXMLRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportLandXMLRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportLandXMLString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportLandXMLString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ImportString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ImportString), WinFormStrings.resourceCulture);
    }
  }

  internal static string IncorrectFamilySymbolMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IncorrectFamilySymbolMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string IncorrectLevelMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IncorrectLevelMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InformationString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InformationString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InstallUpdate1ToRunLANDCADDMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InstallUpdate1ToRunLANDCADDMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InstallUpdate1ToRunSiteworksMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InstallUpdate1ToRunSiteworksMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string IntersectionDetectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IntersectionDetectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string IntersectionLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IntersectionLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string IntersectionLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IntersectionLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string IntersectionLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IntersectionLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string IntersectionSWStreetMass
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IntersectionSWStreetMass), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidAgeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidAgeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidComponentSpacingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidComponentSpacingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidCutFillSlopeValue
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidCutFillSlopeValue), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidDirectoryMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidDirectoryMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidFamilyNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidFamilyNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidFenceHeightMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidFenceHeightMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidFileNameLocationMessageString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidFileNameLocationMessageString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidInputString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidInputString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InValidNewFamily_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InValidNewFamily_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidNumberOfLanesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidNumberOfLanesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidOffsetMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidOffsetMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidRadiusForStreetMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidRadiusForStreetMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidRadiusMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidRadiusMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidRadiusString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidRadiusString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidRadiusValueString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidRadiusValueString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidServiceLifeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidServiceLifeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidSetbackMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidSetbackMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidSlopeValue
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidSlopeValue), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidSpenceSpanMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidSpenceSpanMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidSurfaceNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidSurfaceNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidTypeNameMessage_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidTypeNameMessage_), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidViewForImportString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidViewForImportString), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvalidXMLFileName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvalidXMLFileName), WinFormStrings.resourceCulture);
    }
  }

  internal static string InvertColorsColorMode
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (InvertColorsColorMode), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsBreaklineFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsBreaklineFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsFirstLegSegmentGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsFirstLegSegmentGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsFirstPlacementSegmentGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsFirstPlacementSegmentGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandClosedChainMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandClosedChainMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandEclipsePickMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandEclipsePickMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandHeightGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandHeightGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandSurfaceIdFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandSurfaceIdFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandSymbolIDGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandSymbolIDGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IslandWidthGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IslandWidthGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsLastLegSegmentGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsLastLegSegmentGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsoMetricViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsoMetricViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsPrimaryLeftParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsPrimaryLeftParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsProposedSurfaceFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsProposedSurfaceFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsReverseGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsReverseGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsSecondaryLeftParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsSecondaryLeftParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsSingleSegmentGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsSingleSegmentGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string IsStartingParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (IsStartingParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string KeynoteGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (KeynoteGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string KeynotePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (KeynotePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string LabelFamilyInstanceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LabelFamilyInstanceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string LandcaddIDGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LandcaddIDGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string LandcaddRibbonTab
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LandcaddRibbonTab), WinFormStrings.resourceCulture);
    }
  }

  internal static string LandcaddSitesRibbonTab
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LandcaddSitesRibbonTab), WinFormStrings.resourceCulture);
    }
  }

  internal static string LaunchPatioWalkFamilyManagerOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LaunchPatioWalkFamilyManagerOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string LaunchPlantMixFamilyManagerOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LaunchPlantMixFamilyManagerOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string LayerLevelColorsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LayerLevelColorsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Lea_AMP_deredTagDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Lea_AMP_deredTagDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LeftViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LeftViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string LengthString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LengthString), WinFormStrings.resourceCulture);
    }
  }

  internal static string LessThanComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LessThanComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string LessThanOrEqualToComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LessThanOrEqualToComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string LibraryPath
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LibraryPath), WinFormStrings.resourceCulture);
    }
  }

  internal static string LicenseBorrowedFromNetworkMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LicenseBorrowedFromNetworkMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string LicenseBorrowedFromNetworkMessageError
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LicenseBorrowedFromNetworkMessageError), WinFormStrings.resourceCulture);
    }
  }

  internal static string LicenseReturnedToNetworkMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LicenseReturnedToNetworkMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string LicensingRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LicensingRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string Linear_AMP_PointIntervalDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Linear_AMP_PointIntervalDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LinearIncrementParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LinearIncrementParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string LinearPointIntervalParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LinearPointIntervalParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string LinearUnitfeetString_Lower
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LinearUnitfeetString_Lower), WinFormStrings.resourceCulture);
    }
  }

  internal static string LinearUnitFeetString_Upper
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LinearUnitFeetString_Upper), WinFormStrings.resourceCulture);
    }
  }

  internal static string LinearUnitfootString_Lower
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LinearUnitfootString_Lower), WinFormStrings.resourceCulture);
    }
  }

  internal static string LinearUnitFootString_Upper
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LinearUnitFootString_Upper), WinFormStrings.resourceCulture);
    }
  }

  internal static string LineSegmentsInsideBuildingPadMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LineSegmentsInsideBuildingPadMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string LineSegmentsOutsideToposurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LineSegmentsOutsideToposurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string LineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadADAParkingFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadADAParkingFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadComponentFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadComponentFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadCurbFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadCurbFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadDefaultFamiliesOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadDefaultFamiliesOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadDefaultFamilyOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadDefaultFamilyOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadDrawingToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadDrawingToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadFamilyToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadFamilyToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadFenceFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadFenceFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadFileToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadFileToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadingFamilyProblemLoadNewMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadingFamilyProblemLoadNewMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadParkingBumperFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadParkingBumperFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadParkingFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadParkingFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadParkingIslandFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadParkingIslandFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadParkingLotFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadParkingLotFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadPatioWalkFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadPatioWalkFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadPlantFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadPlantFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadPlantingTagFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadPlantingTagFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadPlantMixFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadPlantMixFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadRetainingWallFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadRetainingWallFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadSidewalkFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadSidewalkFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadSoftTerrainFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadSoftTerrainFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadStreetFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadStreetFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LoadTopoPlacementFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LoadTopoPlacementFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateComponentsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateComponentsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateComponentsNoFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateComponentsNoFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateComponentsTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateComponentsTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateCurbDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateCurbDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateCurbRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateCurbRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateCurbRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateCurbRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateCurbRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateCurbRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateCurbTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateCurbTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateFeatureLineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateFeatureLineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateFeatureLineRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateFeatureLineRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateFeatureLineTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateFeatureLineTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateFenceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateFenceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateFenceTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateFenceTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateParkingLotDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateParkingLotDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateParkingLotRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateParkingLotRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateParkingLotRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateParkingLotRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateParkingLotRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateParkingLotRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateParkingLotTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateParkingLotTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePlacementFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePlacementFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePlantsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePlantsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePlantSearchTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePlantSearchTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePlantsTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePlantsTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePointWipeoutDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePointWipeoutDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePointWipeoutRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePointWipeoutRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocatePointWipeoutTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocatePointWipeoutTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateRetainingWallDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateRetainingWallDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateRetainingWallRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateRetainingWallRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateRetainingWallRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateRetainingWallRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateRetainingWallTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateRetainingWallTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSidewalkDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSidewalkDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSidewalkRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSidewalkRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSidewalkRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSidewalkRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSidewalkRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSidewalkRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSidewalkTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSidewalkTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSoftTerrainDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSoftTerrainDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSoftTerrainRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSoftTerrainRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSoftTerrainRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSoftTerrainRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSoftTerrainRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSoftTerrainRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateSoftTerrainTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateSoftTerrainTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateStreetDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateStreetDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateStreetRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateStreetRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateStreetRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateStreetRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateStreetTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateStreetTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string LocateTypeGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (LocateTypeGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string M_AMP_odifyPlantWidthDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (M_AMP_odifyPlantWidthDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Maintenance
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Maintenance), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenanceDetrimentsPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenanceDetrimentsPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenanceFertilizingTimePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenanceFertilizingTimePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenancePlantingTimePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenancePlantingTimePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenancePruningTimePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenancePruningTimePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenanceTransplantingTimePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenanceTransplantingTimePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenanceTransplantPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenanceTransplantPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaintenanceWaterRequirementsPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaintenanceWaterRequirementsPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ManageLicenseRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ManageLicenseRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ManageLicenseRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ManageLicenseRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ManagerDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ManagerDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ManufacturerGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ManufacturerGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ManufacturerPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ManufacturerPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassBaseVolume
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassBaseVolume), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassCreationOnlyMode
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassCreationOnlyMode), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassCreationOnlyModeOnMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassCreationOnlyModeOnMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassCreationString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassCreationString), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassGrossSurfaceAreaParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassGrossSurfaceAreaParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassGrossVolumeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassGrossVolumeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassImperialTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassImperialTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassingFamilyNameAlreadyUsedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassingFamilyNameAlreadyUsedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassMetricTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassMetricTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassSubBaseVolume
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassSubBaseVolume), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassTemplateFileNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassTemplateFileNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string MassTemplatesString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MassTemplatesString), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaterialPathWalkFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaterialPathWalkFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaterialString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaterialString), WinFormStrings.resourceCulture);
    }
  }

  internal static string MaximumString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MaximumString), WinFormStrings.resourceCulture);
    }
  }

  internal static string MediumDetailLevel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MediumDetailLevel), WinFormStrings.resourceCulture);
    }
  }

  internal static string MessagesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MessagesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string MetricTemplateCabName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MetricTemplateCabName), WinFormStrings.resourceCulture);
    }
  }

  internal static string MetricTemplatesDirectory
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MetricTemplatesDirectory), WinFormStrings.resourceCulture);
    }
  }

  internal static string MiddleStallPlacementGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MiddleStallPlacementGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string MinimumValueIsMessage_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MinimumValueIsMessage_), WinFormStrings.resourceCulture);
    }
  }

  internal static string MissingSharedParametersMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MissingSharedParametersMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Mo_AMP_difyPlantWidthDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Mo_AMP_difyPlantWidthDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Mo_AMP_veDownDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Mo_AMP_veDownDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModelGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModelGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModelPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModelPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyCurbDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyCurbDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyCurbRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyCurbRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyCurbRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyCurbRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyCurbRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyCurbRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyFeatureLineDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyFeatureLineDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyFeatureLineRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyFeatureLineRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyFeatureLineRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyFeatureLineRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyParkingLotDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyParkingLotDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyParkingLotRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyParkingLotRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyParkingLotRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyParkingLotRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyParkingLotRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyParkingLotRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPlantNoFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPlantNoFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPlantsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPlantsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPlantSearchTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPlantSearchTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPlantsInProjDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPlantsInProjDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPlantsTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPlantsTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPointWipeoutDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPointWipeoutDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPointWipeoutRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPointWipeoutRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyPointWipeoutRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyPointWipeoutRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyRetainingWallDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyRetainingWallDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyRetainingWallRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyRetainingWallRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyRetainingWallRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyRetainingWallRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyRetainingWallRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyRetainingWallRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySidewalkDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySidewalkDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySidewalkRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySidewalkRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySidewalkRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySidewalkRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySidewalkRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySidewalkRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySiteComponentInformationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySiteComponentInformationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySiteComponentTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySiteComponentTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySoftTerrainDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySoftTerrainDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySoftTerrainRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySoftTerrainRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySoftTerrainRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySoftTerrainRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifySoftTerrainRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifySoftTerrainRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyStepsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyStepsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyStreetDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyStreetDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyStreetRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyStreetRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyStreetRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyStreetRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ModifyStreetRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ModifyStreetRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string MowingStripPathWalkFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (MowingStripPathWalkFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string NameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NameSubRegionParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NameSubRegionParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string NeedEdgeMowingYes
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NeedEdgeMowingYes), WinFormStrings.resourceCulture);
    }
  }

  internal static string NeedValidEdgeWidth
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NeedValidEdgeWidth), WinFormStrings.resourceCulture);
    }
  }

  internal static string NeedValidInputFor_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NeedValidInputFor_), WinFormStrings.resourceCulture);
    }
  }

  internal static string NeedValidInputMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NeedValidInputMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NeedValidTypeName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NeedValidTypeName), WinFormStrings.resourceCulture);
    }
  }

  internal static string New_
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (New_), WinFormStrings.resourceCulture);
  }

  internal static string New_AMP_TypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (New_AMP_TypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewConstructionString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewConstructionString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewCurb
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewCurb), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewerVersionAvailableForDownloadDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewerVersionAvailableForDownloadDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewFami_AMP_lySymbolDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewFami_AMP_lySymbolDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewFamilyToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewFamilyToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewParkingLot
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewParkingLot), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewRetainingWall
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewRetainingWall), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewSidewalk
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewSidewalk), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewSoftTerrain
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewSoftTerrain), WinFormStrings.resourceCulture);
    }
  }

  internal static string NewStreet
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NewStreet), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoAlignmentInLandXMLString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoAlignmentInLandXMLString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoAlignmentInProjectString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoAlignmentInProjectString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoAlignmentSelectedToExportString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoAlignmentSelectedToExportString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoAlignmentToExportString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoAlignmentToExportString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoAreaSpacingMethod
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoAreaSpacingMethod), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoComponentSpacingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoComponentSpacingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoCSVTXT
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoCSVTXT), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoEdgingYesMowingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoEdgingYesMowingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoExistingSurfacesString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoExistingSurfacesString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoExportOptionsSelectedString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoExportOptionsSelectedString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoFamiliesGenericCreateMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoFamiliesGenericCreateMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoFamiliesGenericMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoFamiliesGenericMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoFamiliesSitesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoFamiliesSitesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoFamilySelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoFamilySelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoFenceHeightMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoFenceHeightMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoFenceSpanMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoFenceSpanMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoGenericModelRFTMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoGenericModelRFTMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoImportOptionsSelectedString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoImportOptionsSelectedString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoIslandOnArcMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoIslandOnArcMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoLinearFootageMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoLinearFootageMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoMassRFTMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoMassRFTMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoObject
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoObject), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoOptionsSelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoOptionsSelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoParkingSpacesOnArc
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoParkingSpacesOnArc), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPatioWalkSelected
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPatioWalkSelected), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPlantingRFTMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPlantingRFTMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPlantsFoundMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPlantsFoundMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPlantsMatchingCriteriaMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPlantsMatchingCriteriaMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPlantsSelected
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPlantsSelected), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPlantSymbolSelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPlantSymbolSelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPlantTypePickedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPlantTypePickedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPointPickedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPointPickedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPointsFoundMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPointsFoundMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoPreviousPositionAvailableMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoPreviousPositionAvailableMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoProjectMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoProjectMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoRegion
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoRegion), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoRFAExtension
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoRFAExtension), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoRFAExtforDestinationMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoRFAExtforDestinationMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NorthSouthBasePointParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NorthSouthBasePointParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSelectionMadeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSelectionMadeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSetbackMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSetbackMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSiteComponentsInProjectMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSiteComponentsInProjectMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSiteRFTMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSiteRFTMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSurfacesInLandXMLString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSurfacesInLandXMLString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSurfacesInProjectString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSurfacesInProjectString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSurfacesSelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSurfacesSelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSurfacesSelectedToExportString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSurfacesSelectedToExportString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoSurfacesToExportString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoSurfacesToExportString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoTag
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (NoTag), WinFormStrings.resourceCulture);
  }

  internal static string NotAllObjectsAppearDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotAllObjectsAppearDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string NotAvailableString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotAvailableString), WinFormStrings.resourceCulture);
    }
  }

  internal static string NotEqualComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotEqualComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoToposurfaceCanBeModifiedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoToposurfaceCanBeModifiedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NotSiteComponentHostLineMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotSiteComponentHostLineMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NotSiteComponentMessage_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotSiteComponentMessage_), WinFormStrings.resourceCulture);
    }
  }

  internal static string NotValidLANDCADDPatioWalkFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotValidLANDCADDPatioWalkFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NotValidLANDCADDPlantMixFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NotValidLANDCADDPlantMixFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoTypeSelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoTypeSelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string NoXMLExtension
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NoXMLExtension), WinFormStrings.resourceCulture);
    }
  }

  internal static string Nu_AMP_mberOfSpacesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Nu_AMP_mberOfSpacesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string NumberOfPntsString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (NumberOfPntsString), WinFormStrings.resourceCulture);
    }
  }

  internal static string O_AMP_riginToOriginDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (O_AMP_riginToOriginDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectNotSupportConvertPlantMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectNotSupportConvertPlantMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectNotSupportedForPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectNotSupportedForPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectNotSupportforModifyingPlantMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectNotSupportforModifyingPlantMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectPickedPlantMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectPickedPlantMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectSelectedNotOnSideMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectSelectedNotOnSideMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectSelectedNotSupportedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectSelectedNotSupportedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectSelectedNotSupportedPlantingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectSelectedNotSupportedPlantingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObjectSelectedNotToposurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObjectSelectedNotToposurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ObtainDrawingImageTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ObtainDrawingImageTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string OmniClassNumberPlantParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OmniClassNumberPlantParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string OmniClassTitlePlantParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OmniClassTitlePlantParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string OptimizeParkingGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OptimizeParkingGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string OriginToOriginPlacement
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OriginToOriginPlacement), WinFormStrings.resourceCulture);
    }
  }

  internal static string Others
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Others), WinFormStrings.resourceCulture);
    }
  }

  internal static string OutOfRangeArgumentMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OutOfRangeArgumentMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string OverWrite_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OverWrite_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string OverwriteMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OverwriteMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string OverwriteToposurfaceOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (OverwriteToposurfaceOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string P_AMP_lantNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (P_AMP_lantNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Par_AMP_kingLotTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Par_AMP_kingLotTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Parameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Parameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParameterNotSelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParameterNotSelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParameterString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParameterString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParametersUsedDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParametersUsedDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParentSurfaceIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParentSurfaceIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Parki_AMP_ngLotNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Parki_AMP_ngLotNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingFamiliesNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingFamiliesNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingFamilyCantBeLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingFamilyCantBeLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotAreaSettingsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotAreaSettingsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotBoundaryClosedChainMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotBoundaryClosedChainMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotFamilyManagerToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotFamilyManagerToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotIslandToposurfaceMaterialParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotIslandToposurfaceMaterialParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotParkingBaseDepthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotParkingBaseDepthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotParkingPavementSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotParkingPavementSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotParkingSubBaseDepthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotParkingSubBaseDepthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotPavementDepthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotPavementDepthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotSurfaceIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotSurfaceIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingLotTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingLotTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingNotObjectSelectedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingNotObjectSelectedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingPlacementDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingPlacementDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ParkingStyleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ParkingStyleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Path
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (Path), WinFormStrings.resourceCulture);
  }

  internal static string PathWalkDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PathWalkDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PathWalkFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PathWalkFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PatioWalkFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PatioWalkFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string PatioWalkFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PatioWalkFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PatioWalkReportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PatioWalkReportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PatiowalkReportNoFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PatiowalkReportNoFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PatioWalkString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PatioWalkString), WinFormStrings.resourceCulture);
    }
  }

  internal static string PercentageError
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PercentageError), WinFormStrings.resourceCulture);
    }
  }

  internal static string PercentagePlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PercentagePlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PhaseCreatedDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PhaseCreatedDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Pic_AMP_kPlantDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Pic_AMP_kPlantDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Pick_AMP_Toposurface
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Pick_AMP_Toposurface), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickAddVertexPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickAddVertexPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickCenterPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickCenterPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickCircleMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickCircleMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickClosedBoundaryMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickClosedBoundaryMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickDeleteVertexPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickDeleteVertexPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickElevationGradePointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickElevationGradePointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickEndPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickEndPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickFirstPointForRotationPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickFirstPointForRotationPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickIslandsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickIslandsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickLeaderElbowPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickLeaderElbowPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickLeaderStartPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickLeaderStartPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickObjectMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickObjectMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickOffsetSideMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickOffsetSideMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickPlantMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickPlantMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickPlantTagMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickPlantTagMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickPointElevationToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickPointElevationToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickPointsForBoundaryPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickPointsForBoundaryPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickRegionSubRegionMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickRegionSubRegionMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickRotationPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickRotationPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickSecondPointForRotationPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickSecondPointForRotationPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickSideForFaceOfCurbMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickSideForFaceOfCurbMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickSideForGradeToPlaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickSideForGradeToPlaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickSiteComponentLineMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickSiteComponentLineMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickStartingDirectionMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickStartingDirectionMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickStartingSideMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickStartingSideMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickStartPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickStartPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickTagPointPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickTagPointPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickToposurfaceInformationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickToposurfaceInformationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickToposurfacePrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickToposurfacePrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickToposurfacesPrompt
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickToposurfacesPrompt), WinFormStrings.resourceCulture);
    }
  }

  internal static string PickViewOptionForMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PickViewOptionForMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Plac_AMP_eAtLevelDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Plac_AMP_eAtLevelDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Place_AMP_ADAParkingSpacesDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Place_AMP_ADAParkingSpacesDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Place_AMP_BumpersDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Place_AMP_BumpersDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Place_AMP_IslandsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Place_AMP_IslandsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlaceBumperGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlaceBumperGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlaceIn_AMP_AreaDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlaceIn_AMP_AreaDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlaceIslandGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlaceIslandGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlacementFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlacementFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlacementIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlacementIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlacementTypeGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlacementTypeGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlaceTagDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlaceTagDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlacingStallMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlacingStallMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Plan_AMP_tSpacingDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Plan_AMP_tSpacingDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Plant
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (Plant), WinFormStrings.resourceCulture);
  }

  internal static string Plant_AMP_FamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Plant_AMP_FamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Plant_AMP_HeightDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Plant_AMP_HeightDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Plant_AMP_NameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Plant_AMP_NameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Plant_AMP_WidthDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Plant_AMP_WidthDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantAlreadyPickedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantAlreadyPickedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantBookletDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantBookletDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantBookletNoFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantBookletNoFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantClimateAndZonePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantClimateAndZonePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantCodeNamePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantCodeNamePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantCommentsPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantCommentsPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantCommonNamePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantCommonNamePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantCountPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantCountPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantDWGCreatorDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantDWGCreatorDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantExportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantExportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantFamilyManagerDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantFamilyManagerDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantGrowthAgeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantGrowthAgeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantGrowthDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantGrowthDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantGrowthSimulationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantGrowthSimulationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantHeightPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantHeightPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingDefinitionGroup
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingDefinitionGroup), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingFamilyCantBeLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingFamilyCantBeLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingImperialTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingImperialTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingMetricTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingMetricTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingSizePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingSizePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingSymbolPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingSymbolPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantingTagFamiliesNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantingTagFamiliesNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixPlantSearchTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixPlantSearchTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixReportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixReportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixReportNoFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixReportNoFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixSpacingMethodSquare
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixSpacingMethodSquare), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixSpacingMethodTriangular
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixSpacingMethodTriangular), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantMixString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantMixString), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantPlaceTagNotPlacedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantPlaceTagNotPlacedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantScientificNamePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantScientificNamePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantSearchDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantSearchDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantSizePlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantSizePlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantSpacingPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantSpacingPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantSpacingPlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantSpacingPlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantTypePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantTypePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantUsesPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantUsesPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantViewSearchTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantViewSearchTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string PlantWidthPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PlantWidthPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectComponentFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectComponentFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectCurbFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectCurbFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectFenceFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectFenceFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectParkingLotFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectParkingLotFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectPlantingFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectPlantingFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectRetainingWallFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectRetainingWallFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectSidewalkFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectSidewalkFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectSoftTerrainFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectSoftTerrainFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PleaseSelectStreetFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PleaseSelectStreetFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointNotInParkingLotBoundaryMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointNotInParkingLotBoundaryMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointNotInProposedBoundaryMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointNotInProposedBoundaryMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointsInBoundaryWillBeRemovedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointsInBoundaryWillBeRemovedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointsNotInParkingLotBoundaryMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointsNotInParkingLotBoundaryMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointWipeoutBoundaryClosedChainMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointWipeoutBoundaryClosedChainMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointWipeoutLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointWipeoutLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointWipeoutLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointWipeoutLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointWipeoutLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointWipeoutLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointWipeoutRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointWipeoutRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string PointWipeoutString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PointWipeoutString), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionComponetsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionComponetsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionDistanceLandXMLSurfacePlacementFamilyInstanceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionDistanceLandXMLSurfacePlacementFamilyInstanceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionFenceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionFenceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionHzDirectionLandXMLSurfacePlacementFamilyInstanceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionHzDirectionLandXMLSurfacePlacementFamilyInstanceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningAutoCenterToCenter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningAutoCenterToCenter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningAutoOriginToOrigin
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningAutoOriginToOrigin), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningBySharedCoordinates
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningBySharedCoordinates), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningBySurveyPoints
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningBySurveyPoints), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningManualCenter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningManualCenter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningMethodLandXMLSurfacePlacementFamilyInstanceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningMethodLandXMLSurfacePlacementFamilyInstanceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositioningUsePreviousValues
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositioningUsePreviousValues), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionParkingLotsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionParkingLotsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string PositionVzDirectionLandXMLSurfacePlacementFamilyInstanceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PositionVzDirectionLandXMLSurfacePlacementFamilyInstanceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PreserveColorsColorMode
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PreserveColorsColorMode), WinFormStrings.resourceCulture);
    }
  }

  internal static string PreviewDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PreviewDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string PrimaryFormIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PrimaryFormIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PrimaryPlacementIDParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PrimaryPlacementIDParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string PrimaryStationParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (PrimaryStationParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProductDownloadIntructionsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProductDownloadIntructionsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProductUpdateAvailableTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProductUpdateAvailableTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarConvertingPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarConvertingPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingCurbMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingCurbMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarCreatingFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarCreatingFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingNewBaseToposurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingNewBaseToposurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingNewProposedToposurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingNewProposedToposurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingNewToposurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingNewToposurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingRetainingWallMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingRetainingWallMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingSidewalkMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingSidewalkMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarCreatingStreetMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarCreatingStreetMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarGradingToposurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarGradingToposurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarGrowingPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarGrowingPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarImportMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarImportMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarLoadingFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarLoadingFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarLoadingFilesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarLoadingFilesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarObtainingSiteComponentsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarObtainingSiteComponentsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarPlacingComponentsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarPlacingComponentsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarPlacingCurbMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarPlacingCurbMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarPlacingPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarPlacingPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarPlacingRetainingWallMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarPlacingRetainingWallMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarPlacingSidewalkMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarPlacingSidewalkMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarPlacingStreetMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarPlacingStreetMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarProcessingCogoPointsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarProcessingCogoPointsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarProcessingPointsForAlignmentMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarProcessingPointsForAlignmentMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarProcessingPointsForSurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarProcessingPointsForSurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarProcessingSelectedSiteComponentPointsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarProcessingSelectedSiteComponentPointsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarSavingModifiedPlantsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarSavingModifiedPlantsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarSearchingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarSearchingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressbarSettingParametersMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressbarSettingParametersMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressBarUpdatingModelMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressBarUpdatingModelMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProgressPlacingFenceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProgressPlacingFenceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProjectedAreaSubRegionParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProjectedAreaSubRegionParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProjectInnerSlopesFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProjectInnerSlopesFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProposedSurfaceLinkBrokenMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProposedSurfaceLinkBrokenMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProposedToposurfaceMaterialParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProposedToposurfaceMaterialParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ProposedToposurfaceString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ProposedToposurfaceString), WinFormStrings.resourceCulture);
    }
  }

  internal static string QuantityOfString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (QuantityOfString), WinFormStrings.resourceCulture);
    }
  }

  internal static string R_AMP_emoveAllDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (R_AMP_emoveAllDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string R_AMP_etainingWallNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (R_AMP_etainingWallNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string R_AMP_otationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (R_AMP_otationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RadiusMakesArcLengthMoreThanHostLineMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RadiusMakesArcLengthMoreThanHostLineMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string RadiusParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RadiusParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RadiusPlantParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RadiusPlantParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RadiusSettingsGroupTitle
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RadiusSettingsGroupTitle), WinFormStrings.resourceCulture);
    }
  }

  internal static string Re_AMP_lativeElevationFromToposurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Re_AMP_lativeElevationFromToposurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Re_AMP_lativeElevationsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Re_AMP_lativeElevationsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ReadOnlySaveAsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ReadOnlySaveAsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string RedLineColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RedLineColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string RegionNameGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RegionNameGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RegionSelectedNotAssignedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RegionSelectedNotAssignedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string RegionString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RegionString), WinFormStrings.resourceCulture);
    }
  }

  internal static string RelativeElevationFromToposurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RelativeElevationFromToposurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RelinkSurfacesTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RelinkSurfacesTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ReloadFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ReloadFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string ReportRibbonPanel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ReportRibbonPanel), WinFormStrings.resourceCulture);
    }
  }

  internal static string Retaining_AMP_WallTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Retaining_AMP_WallTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallBaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallBaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingwallCo_AMP_nstantElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingwallCo_AMP_nstantElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingwallConstantElevationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingwallConstantElevationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallCutSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallCutSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallFamilyManagerToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallFamilyManagerToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallFillSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallFillSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallHeightParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallHeightParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallMassSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallMassSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallMassTemplateFileNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallMassTemplateFileNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallMaterialParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallMaterialParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingwallRe_AMP_lativeElevationFromToposurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingwallRe_AMP_lativeElevationFromToposurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingwallRelativeElevationFromToposurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingwallRelativeElevationFromToposurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallSlopeProjectionParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallSlopeProjectionParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallString), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallSubbaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallSubbaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallTemplateNotMassTypeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallTemplateNotMassTypeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RetainingWallWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RetainingWallWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ReturnLicenseRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ReturnLicenseRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ReturnLicenseRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ReturnLicenseRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string RevitExceptionError
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RevitExceptionError), WinFormStrings.resourceCulture);
    }
  }

  internal static string RevitINIFileMissingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RevitINIFileMissingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string RevitLevelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RevitLevelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string RGBString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RGBString), WinFormStrings.resourceCulture);
    }
  }

  internal static string RightViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RightViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string RightVisibleParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RightVisibleParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RowSpacingDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RowSpacingDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string RPCRenderAppearanceFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RPCRenderAppearanceFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RPCRenderAppearancePropertiesFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RPCRenderAppearancePropertiesFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string RunLocateSiteComponentsMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (RunLocateSiteComponentsMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_haredAccessibleAisleDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_haredAccessibleAisleDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_howAffectedPointsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_howAffectedPointsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_ideWalkTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_ideWalkTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_oftTerrainNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_oftTerrainNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_quareDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_quareDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_tartingDistanceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_tartingDistanceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_treetFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_treetFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_urfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_urfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string S_AMP_ymbolFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (S_AMP_ymbolFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SameSourceAndDestinationFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SameSourceAndDestinationFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SameTypeNameAsFamilyNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SameTypeNameAsFamilyNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SamplePath
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SamplePath), WinFormStrings.resourceCulture);
    }
  }

  internal static string Save_AMP_FamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Save_AMP_FamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SaveFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SaveFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ScalingDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ScalingDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ScientificNamePlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ScientificNamePlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Se_AMP_ttingsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Se_AMP_ttingsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Sea_AMP_rchDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Sea_AMP_rchDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Searc_AMP_hDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Searc_AMP_hDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SecondaryPlacementIDParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SecondaryPlacementIDParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SecondaryStationParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SecondaryStationParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Select__String
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Select__String), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectedFileHasLengthMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectedFileHasLengthMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectExportTopoAlignmentLabelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectExportTopoAlignmentLabelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectExportTopoSurfaceLabelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectExportTopoSurfaceLabelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectionMethodsDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectionMethodsDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectRFADir
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectRFADir), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectSurfaceNameAndPhaseDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectSurfaceNameAndPhaseDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectTemplateMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectTemplateMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectTopoAlignmentLabelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectTopoAlignmentLabelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SelectTopoSurfaceLabelString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SelectTopoSurfaceLabelString), WinFormStrings.resourceCulture);
    }
  }

  internal static string Set_AMP_backDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Set_AMP_backDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetbackGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetbackGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetBaseToposurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetBaseToposurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetBaseToposurfaceInformationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetBaseToposurfaceInformationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetBaseTopoSurfaceRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetBaseTopoSurfaceRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetBaseTopoSurfaceRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetBaseTopoSurfaceRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetBaseTopoSurfaceRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetBaseTopoSurfaceRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetBaseToposurfaceTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetBaseToposurfaceTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string SetFamilyTypeForSiteComponentOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SetFamilyTypeForSiteComponentOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string SettingRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SettingRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string SettingRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SettingRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string SharedParametersDontExistDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SharedParametersDontExistDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Sho_AMP_wAllDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Sho_AMP_wAllDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ShowMassInActiveViewOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ShowMassInActiveViewOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string ShowMassInAllViewsOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ShowMassInAllViewsOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string Si_AMP_deWalkNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Si_AMP_deWalkNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Side_AMP_WalkFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Side_AMP_WalkFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkBaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkBaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkCutSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkCutSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkFamilyManagerToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkFamilyManagerToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkFillSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkFillSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkIntersectionDefaultRadius
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkIntersectionDefaultRadius), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkIntersectionDefaultTransitioningDistance
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkIntersectionDefaultTransitioningDistance), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkIntersectionNotOnStraightLinesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkIntersectionNotOnStraightLinesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkLocationLineParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkLocationLineParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkMassSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkMassSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkMassTemplateFileNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkMassTemplateFileNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkPavementDepthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkPavementDepthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkPavementSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkPavementSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkSubbaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkSubbaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkTemplateNotMassTypeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkTemplateNotMassTypeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SidewalkTypeManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SidewalkTypeManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SideWalkWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SideWalkWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SingleFileDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SingleFileDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SingleFileNoCSVTXTMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SingleFileNoCSVTXTMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SingleFileNoRFAMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SingleFileNoRFAMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentAnnotationBeginElevationIDParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentAnnotationBeginElevationIDParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentAnnotationEndElevationIDParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentAnnotationEndElevationIDParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentAnnotationGradeIDParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentAnnotationGradeIDParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentFamilyManagerToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentFamilyManagerToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentHasElevationAnnotationParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentHasElevationAnnotationParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentHasGradeAnnotationParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentHasGradeAnnotationParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentIsRelativeElevationParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentIsRelativeElevationParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentLineCreationString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentLineCreationString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentNameFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentNameFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentPromptForStartingSide
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentPromptForStartingSide), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteComponentsFoundInProjectMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteComponentsFoundInProjectMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteImperialTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteImperialTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteMetricTemplate
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteMetricTemplate), WinFormStrings.resourceCulture);
    }
  }

  internal static string SitesReportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SitesReportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SitesReportRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SitesReportRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string SitesReportRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SitesReportRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string SitesReportRibbonToolTipLongDescription
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SitesReportRibbonToolTipLongDescription), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteworksIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteworksIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteworksNetworkLicenseBorrowError
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteworksNetworkLicenseBorrowError), WinFormStrings.resourceCulture);
    }
  }

  internal static string SiteworksNetworkLicenseError
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SiteworksNetworkLicenseError), WinFormStrings.resourceCulture);
    }
  }

  internal static string Slope_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Slope_), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeProjectionTabString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeProjectionTabString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitDegrees
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitDegrees), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitPercentage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitPercentage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitRatio10
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitRatio10), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitRatio12
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitRatio12), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitRiseFeet
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitRiseFeet), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitRiseInches
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitRiseInches), WinFormStrings.resourceCulture);
    }
  }

  internal static string SlopeUnitRiseMM
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SlopeUnitRiseMM), WinFormStrings.resourceCulture);
    }
  }

  internal static string So_AMP_ftTerrainTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (So_AMP_ftTerrainTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Soft_AMP_TerrainFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Soft_AMP_TerrainFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainCutSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainCutSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFamilyCantBeLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFamilyCantBeLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFamilyManagerRibbonToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFamilyManagerRibbonToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFamilyNotLoadedWithIDMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFamilyNotLoadedWithIDMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainFillSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainFillSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainLeftOffsetWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainLeftOffsetWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainRightOffsetWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainRightOffsetWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SoftTerrainTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SoftTerrainTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string Source
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Source), WinFormStrings.resourceCulture);
    }
  }

  internal static string SourceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SourceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpacingGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpacingGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpacingMethodPlantMixFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpacingMethodPlantMixFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Specify_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Specify_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifyDestinationFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifyDestinationFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifyFileNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifyFileNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifyFolderFileNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifyFolderFileNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifyPlantHeightMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifyPlantHeightMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifyPlantSpacingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifyPlantSpacingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifyPlantWidthMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifyPlantWidthMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifySharedParameterFileNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifySharedParameterFileNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifySourceFileNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifySourceFileNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpecifySymbolFileNameMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpecifySymbolFileNameMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SpiralsNotSupportedMessages
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SpiralsNotSupportedMessages), WinFormStrings.resourceCulture);
    }
  }

  internal static string StallCountGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StallCountGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StallLengthGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StallLengthGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StallOnArcMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StallOnArcMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string StallOnLineMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StallOnLineMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string StartingDistanceGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StartingDistanceGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StartingDistanceGreaterThanLineLengthMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StartingDistanceGreaterThanLineLengthMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string StartsWithComparator
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StartsWithComparator), WinFormStrings.resourceCulture);
    }
  }

  internal static string StepsHeightParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StepsHeightParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StepsManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StepsManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string StepsMaterialParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StepsMaterialParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StepsTreadParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StepsTreadParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StepsWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StepsWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetBaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetBaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetBoulevardWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetBoulevardWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCrossSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCrossSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCurbDisplayParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCurbDisplayParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCurbHeightParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCurbHeightParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCurbMaterialParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCurbMaterialParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCurbOffsetParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCurbOffsetParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCurbWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCurbWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetCutSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetCutSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetFamilyDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetFamilyDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetFamilyManagerRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetFamilyManagerRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetFamilyManagerToolTip
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetFamilyManagerToolTip), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetFillSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetFillSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetGutterSlopeParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetGutterSlopeParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetGutterWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetGutterWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetInfoTabString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetInfoTabString), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetIntersectionDefaultRadius
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetIntersectionDefaultRadius), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetIntersectionDefaultTransitioningDistance
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetIntersectionDefaultTransitioningDistance), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetIntersectionNotOnStraightLinesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetIntersectionNotOnStraightLinesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetLaneWidthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetLaneWidthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetLineSubCategoryColor
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetLineSubCategoryColor), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetLineSubCategoryLineWeight
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetLineSubCategoryLineWeight), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetLineSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetLineSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetMassSubCategoryName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetMassSubCategoryName), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetMassTemplateFileNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetMassTemplateFileNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetNa_AMP_meDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetNa_AMP_meDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetNumberOfLanesParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetNumberOfLanesParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetPavementDepthParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetPavementDepthParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetPavementSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetPavementSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetString), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetSubbaseSurfaceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetSubbaseSurfaceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetT_AMP_ypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetT_AMP_ypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetTemplateNotMassTypeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetTemplateNotMassTypeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetTypeDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetTypeDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string StreetTypeManagerString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (StreetTypeManagerString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SubregionBuildingPadBoundaryErrorMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SubregionBuildingPadBoundaryErrorMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SubRegionElement
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SubRegionElement), WinFormStrings.resourceCulture);
    }
  }

  internal static string SubRegionsInProposedSurfaceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SubRegionsInProposedSurfaceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string SubRegionString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SubRegionString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SurfaceAreaSubRegionParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SurfaceAreaSubRegionParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SurfaceCleanUpTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SurfaceCleanUpTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string SurfaceNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SurfaceNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SurfaceNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SurfaceNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SurfaceNotSelectedString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SurfaceNotSelectedString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWCurbLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWCurbLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWFeatureLineLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWFeatureLineLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWIntersectionLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWIntersectionLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWParkingLotLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWParkingLotLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWPointWipeoutLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWPointWipeoutLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWRetainingWallLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWRetainingWallLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWSidewalkLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWSidewalkLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWSoftTerrainLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWSoftTerrainLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string SWStreetLineNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SWStreetLineNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string Sym_AMP_bolNameDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Sym_AMP_bolNameDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string SymbolIDGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SymbolIDGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string SymbolNoRFAExtension
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (SymbolNoRFAExtension), WinFormStrings.resourceCulture);
    }
  }

  internal static string TemperatureRangePlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TemperatureRangePlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TemplateNotLoadedErrorMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TemplateNotLoadedErrorMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string TemplateNotPickedFamilyNotCreatedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TemplateNotPickedFamilyNotCreatedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string The_String
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (The_String), WinFormStrings.resourceCulture);
    }
  }

  internal static string ThereAreNoString_
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ThereAreNoString_), WinFormStrings.resourceCulture);
    }
  }

  internal static string ThicknessPathWalkFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ThicknessPathWalkFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ThreeDDWGSymbolDimensionType
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ThreeDDWGSymbolDimensionType), WinFormStrings.resourceCulture);
    }
  }

  internal static string ThreeDString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ThreeDString), WinFormStrings.resourceCulture);
    }
  }

  internal static string TickLengthPlantParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TickLengthPlantParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TopoDrawOrderFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TopoDrawOrderFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TopographySurfaceArcPointInterval
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TopographySurfaceArcPointInterval), WinFormStrings.resourceCulture);
    }
  }

  internal static string Toposurface_AMP_NameSurfaceInfoDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Toposurface_AMP_NameSurfaceInfoDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceAlreadyPickedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceAlreadyPickedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceAssociationDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceAssociationDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceConversionRibbonButton
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceConversionRibbonButton), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceIDFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceIDFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceNotCreatedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceNotCreatedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceSameNameAndPhaseMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceSameNameAndPhaseMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceSelectionDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceSelectionDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfacesString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfacesString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfacesToExportDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfacesToExportDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfaceString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfaceString), WinFormStrings.resourceCulture);
    }
  }

  internal static string ToposurfacNotInProjectMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ToposurfacNotInProjectMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string TopViewDirection
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TopViewDirection), WinFormStrings.resourceCulture);
    }
  }

  internal static string TransitioningDistanceAndRadiusInvalidMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TransitioningDistanceAndRadiusInvalidMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string TransitioningDistanceMakesDistanceMoreThanHostLineMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TransitioningDistanceMakesDistanceMoreThanHostLineMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string TransitioningDistanceParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TransitioningDistanceParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string Triang_AMP_ularDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Triang_AMP_ularDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string TrunkHeightPlantParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TrunkHeightPlantParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TrunkRadiusPlantParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TrunkRadiusPlantParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TwoDDWGSymbolDimensionType
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TwoDDWGSymbolDimensionType), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeCommentsGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeCommentsGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeCommentsPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeCommentsPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeManagerDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeManagerDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeNameGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeNameGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeNameMissing
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeNameMissing), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeNamePlantFamilyType
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeNamePlantFamilyType), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeParameterFamilyFileMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeParameterFamilyFileMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeParameterFamilyMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeParameterFamilyMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string TypeParameterFamilyNotLoadedMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (TypeParameterFamilyNotLoadedMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string UnableCreateFamilyString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UnableCreateFamilyString), WinFormStrings.resourceCulture);
    }
  }

  internal static string UnableToCeateBlendGeometry
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UnableToCeateBlendGeometry), WinFormStrings.resourceCulture);
    }
  }

  internal static string UnableToCreateMassMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UnableToCreateMassMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Unassign_Message
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Unassign_Message), WinFormStrings.resourceCulture);
    }
  }

  internal static string UnassignDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UnassignDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string UndefinedDetailLevel
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UndefinedDetailLevel), WinFormStrings.resourceCulture);
    }
  }

  internal static string UniqueIDGenericModelFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UniqueIDGenericModelFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string UnnamedSurfaceDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UnnamedSurfaceDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string UpdatingFamilyTransaction
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UpdatingFamilyTransaction), WinFormStrings.resourceCulture);
    }
  }

  internal static string URLGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (URLGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string URLPlantFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (URLPlantFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseCentimeterUnitsOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseCentimeterUnitsOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseFeetUnitsOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseFeetUnitsOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseInchUnitsOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseInchUnitsOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseMeterUnitsOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseMeterUnitsOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseMillimeterUnitsOption
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseMillimeterUnitsOption), WinFormStrings.resourceCulture);
    }
  }

  internal static string UsePlacementElevationsFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UsePlacementElevationsFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseRightSideGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseRightSideGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string UserInformationString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UserInformationString), WinFormStrings.resourceCulture);
    }
  }

  internal static string UseSharedElevation
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (UseSharedElevation), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidEdgeWidth
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidEdgeWidth), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidFields
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidFields), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidLineWeightValuesMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidLineWeightValuesMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidPlantHeightMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidPlantHeightMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidPlantHeightVarianceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidPlantHeightVarianceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidPlantSpacingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidPlantSpacingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidPlantWidthMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidPlantWidthMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidPlantWidthVarianceMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidPlantWidthVarianceMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidSetbackMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidSetbackMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidTypeCommonOrScientificName
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidTypeCommonOrScientificName), WinFormStrings.resourceCulture);
    }
  }

  internal static string ValidTypeMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ValidTypeMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Value
  {
    get => WinFormStrings.ResourceManager.GetString(nameof (Value), WinFormStrings.resourceCulture);
  }

  internal static string Varianc_AMP_eDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Varianc_AMP_eDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string VarianceMoreThanPlantHeightMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (VarianceMoreThanPlantHeightMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string VarianceMoreThanPlantWidthMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (VarianceMoreThanPlantWidthMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string VersionDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (VersionDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string ViewNameString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (ViewNameString), WinFormStrings.resourceCulture);
    }
  }

  internal static string VisibleString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (VisibleString), WinFormStrings.resourceCulture);
    }
  }

  internal static string VolumeString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (VolumeString), WinFormStrings.resourceCulture);
    }
  }

  internal static string WallCantBePlacedWithDaylightingMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (WallCantBePlacedWithDaylightingMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string WallCantBePlacedWithGreaterElevationMessage
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (WallCantBePlacedWithGreaterElevationMessage), WinFormStrings.resourceCulture);
    }
  }

  internal static string Warning
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (Warning), WinFormStrings.resourceCulture);
    }
  }

  internal static string WarningDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (WarningDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string WidthGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (WidthGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string WidthVarianceGenericFamilyParameter
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (WidthVarianceGenericFamilyParameter), WinFormStrings.resourceCulture);
    }
  }

  internal static string WorksetPermissionErrorDialog
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (WorksetPermissionErrorDialog), WinFormStrings.resourceCulture);
    }
  }

  internal static string YesString
  {
    get
    {
      return WinFormStrings.ResourceManager.GetString(nameof (YesString), WinFormStrings.resourceCulture);
    }
  }
}
