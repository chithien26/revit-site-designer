﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.RibbonService
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.UI;
using Autodesk.Windows;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using UIFramework;

#nullable disable
namespace EPCommon;

public static class RibbonService
{
  private static readonly RibbonControl m_RibbonControl;

  static RibbonService()
  {
    try
    {
      RibbonService.m_RibbonControl = (RibbonControl) RevitRibbonControl.RibbonControl;
    }
    catch (TypeInitializationException ex)
    {
      RibbonService.m_RibbonControl = (RibbonControl) null;
    }
  }

  public static RibbonTab CreateTab(
    string _strID,
    string _strTitle,
    bool _bIsVisible,
    int _nLandcaddRibbonIndex)
  {
    if (RibbonService.m_RibbonControl == null)
      return (RibbonTab) null;
    RibbonTab tab = new RibbonTab()
    {
      Id = _strID,
      Title = _strTitle,
      IsVisible = _bIsVisible
    };
    if (_nLandcaddRibbonIndex == -1)
    {
      for (int index = 0; index < ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs).Count; ++index)
      {
        if (string.Compare(((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs)[index].Id, EPShared.LocalRM.GetString("AddInsRibbonTabIDValue"), true) == 0)
        {
          _nLandcaddRibbonIndex = index + 1;
          break;
        }
      }
    }
    if (_nLandcaddRibbonIndex >= 0)
      ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs).Insert(_nLandcaddRibbonIndex, tab);
    return tab;
  }

  public static RibbonPanel CreatePanel(RibbonTab _RibbonTab, string _strPanelTitle)
  {
    try
    {
      if (_RibbonTab == null)
        throw new ArgumentNullException("ribbontab", "RibbonTab cannot be null");
      if (string.IsNullOrEmpty(_strPanelTitle))
        throw new ArgumentException("Panel title cannot be empty");
      RibbonPanelSource ribbonPanelSource = new RibbonPanelSource();
      RibbonPanel _Panel = new RibbonPanel()
      {
        Source = ribbonPanelSource
      };
      RibbonPanel panel = RibbonService.UIPanel(_Panel, _RibbonTab.Title);
      if (panel != null)
      {
        _Panel.Source.Name = _strPanelTitle;
        _Panel.Source.Title = _strPanelTitle;
        _Panel.Source.Id = "CustomCtrl_" + _strPanelTitle;
        ((Collection<RibbonPanel>) _RibbonTab.Panels).Add(_Panel);
      }
      return panel;
    }
    catch (Exception ex)
    {
      throw new Exception("Error creating panel :", ex);
    }
  }

  private static RibbonPanel UIPanel(RibbonPanel _Panel, string _strParentID)
  {
    try
    {
      RibbonPanel ribbonPanel = (RibbonPanel) null;
      Type type = typeof (RibbonPanel);
      ConstructorInfo[] constructors = type.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic);
      if (constructors != null && constructors.Length != 0)
      {
        ConstructorInfo constructorInfo = constructors[0];
        if (constructorInfo != (ConstructorInfo) null)
        {
          if (constructorInfo.GetParameters().Length == 2)
            ribbonPanel = constructorInfo.Invoke(new object[2]
            {
              (object) _Panel,
              (object) _strParentID
            }) as RibbonPanel;
          else if (constructorInfo.GetParameters().Length == 1)
            ribbonPanel = constructorInfo.Invoke(new object[1]
            {
              (object) _Panel
            }) as RibbonPanel;
        }
      }
      else
      {
        ConstructorInfo constructor = type.GetConstructor(BindingFlags.Instance | BindingFlags.NonPublic, (Binder) null, new Type[1]
        {
          typeof (RibbonPanel)
        }, (ParameterModifier[]) null);
        if (constructor != (ConstructorInfo) null)
          ribbonPanel = constructor.Invoke(new object[1]
          {
            (object) _Panel
          }) as RibbonPanel;
      }
      return ribbonPanel;
    }
    catch (Exception ex)
    {
      throw new Exception("Error creating Revit ribbon panel :", ex);
    }
  }

  public static List<KeyValuePair<string, bool>> GetRibbonVisibiltyStates()
  {
    List<KeyValuePair<string, bool>> ribbonVisibiltyStates = new List<KeyValuePair<string, bool>>();
    for (int index = 0; index < ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs).Count; ++index)
      ribbonVisibiltyStates.Add(new KeyValuePair<string, bool>(((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs)[index].Id, ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs)[index].IsVisible));
    return ribbonVisibiltyStates;
  }

  public static void SetRibbonVisibiltyStates(List<KeyValuePair<string, bool>> _RibbonList)
  {
    if (_RibbonList == null)
      return;
    for (int index1 = 0; index1 < ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs).Count; ++index1)
    {
      for (int index2 = 0; index2 < _RibbonList.Count; ++index2)
      {
        string id = ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs)[index1].Id;
        KeyValuePair<string, bool> ribbon = _RibbonList[index2];
        string key = ribbon.Key;
        if (string.Compare(id, key, true) == 0)
        {
          RibbonTab tab = ((Collection<RibbonTab>) RibbonService.m_RibbonControl.Tabs)[index1];
          ribbon = _RibbonList[index2];
          int num = ribbon.Value ? 1 : 0;
          tab.IsVisible = num != 0;
          _RibbonList.RemoveAt(index2);
          break;
        }
      }
    }
  }
}
