﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantViewForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantViewForm : EPForm
{
  private Units m_Units;
  private Document m_CurDocument;
  private List<FamilyTypeContainer> m_PlantListFamilyTypeList;
  private string m_strSourceDirectory = string.Empty;
  private string m_strSourceFile = string.Empty;
  private string m_strSymbolFile = string.Empty;
  private List<Document> m_OpenDocumentList;
  private List<KeyValuePair<string, string>> m_RecenFilesList;
  private List<ParameterColumn> m_ParameterList;
  private int m_nPlantListViewSortColumn = -1;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private EPTransactionContainer m_TransactionContainer;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_CancelButton;
  private Button m_SaveFamilyButton;
  private Button m_DWGSymbolBaseButton;
  private GroupBox m_SourceGroupBox;
  private GroupBox m_SingleFileGroupBox;
  private RadioButton m_TabSingleFileRadioButton;
  private RadioButton m_CommaSingleFileRadioButton;
  private RadioButton m_RFASingleFileRadioButton;
  private GroupBox m_DestinationGroupBox;
  private TextBox m_DestinationFileTextBox;
  private Button m_DestinationFileButton;
  private Label m_DestinationFileLabel;
  private RadioButton m_SingleFileRadioButton;
  private TextBox m_SingleFileTextBox;
  private Button m_SingleFileButton;
  private Label m_SingleFileLabel;
  private RadioButton m_DirectoryRadioButton;
  private TextBox m_DirectoryTextBox;
  private Button m_DirectoryButton;
  private Label m_DirectoryLabel;
  private GroupBox m_FamilySymbolGroupBox;
  private Label m_SymbolNameLabel;
  private ComboBox m_SymbolNameComboBox;
  private TextBox m_FamilySymbolFileTextBox;
  private Button m_FamilySymbolFileButton;
  private Label m_FamilySymbolFileLabel;
  private CheckBox m_CreateSymbolFromDWGCheckBox;
  private Button m_ExportButton;
  private GroupBox m_PlantCollectionGroupBox;
  private Button m_ShowAllFamiliesButton;
  private Button m_DeleteFamiliesButton;
  private Button m_ColumnDisplayButton;
  private Button m_UseParametersButton;
  private Button m_SearchButton;
  private ListView m_PlantListView;

  public PlantViewForm(Document _CurDocument)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("PlantFamilyManagerDialog");
    this.m_SourceGroupBox.Text = EPShared.LocalRM.GetString("SourceDialog");
    this.m_SingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleFileDialog");
    this.m_DirectoryRadioButton.Text = EPShared.LocalRM.GetString("AMP_DirectoryMultipleFilesDialog");
    this.m_SingleFileGroupBox.Text = EPShared.LocalRM.GetString("SingleFileDialog");
    this.m_RFASingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_RFAFileDialog");
    this.m_CommaSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
    this.m_TabSingleFileRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
    this.m_SingleFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_DirectoryLabel.Text = EPShared.LocalRM.GetString("AMP_DirectoryDialog");
    this.m_PlantCollectionGroupBox.Text = $"{EPShared.LocalRM.GetString("PlantDialog")} {EPShared.LocalRM.GetString("CollectionDialog")}";
    this.m_SearchButton.Text = EPShared.LocalRM.GetString("Searc_AMP_hDialog");
    this.m_UseParametersButton.Text = EPShared.LocalRM.GetString("AMP_UseParametersDialog");
    this.m_ColumnDisplayButton.Text = EPShared.LocalRM.GetString("Column_AMP_DisplayDialog");
    this.m_DeleteFamiliesButton.Text = EPShared.LocalRM.GetString("DeleteFromL_AMP_ampDialog");
    this.m_ShowAllFamiliesButton.Text = EPShared.LocalRM.GetString("Sho_AMP_wAllDialog");
    this.m_FamilySymbolGroupBox.Text = EPShared.LocalRM.GetString("FamilySymbolOptionsDialog");
    this.m_FamilySymbolFileLabel.Text = EPShared.LocalRM.GetString("S_AMP_ymbolFileDialog");
    this.m_SymbolNameLabel.Text = EPShared.LocalRM.GetString("Sym_AMP_bolNameDialog");
    this.m_CreateSymbolFromDWGCheckBox.Text = EPShared.LocalRM.GetString("Cr_AMP_eateSymbolDWGDialog");
    this.m_DWGSymbolBaseButton.Text = EPShared.LocalRM.GetString("D_AMP_WGSymbolDialog");
    this.m_DestinationGroupBox.Text = EPShared.LocalRM.GetString("DestinationDialog");
    this.m_DestinationFileLabel.Text = EPShared.LocalRM.GetString("Fi_AMP_leDialog");
    this.m_ExportButton.Text = EPShared.LocalRM.GetString("E_AMP_xportDialog");
    this.m_SaveFamilyButton.Text = EPShared.LocalRM.GetString("AMP_AddToFamilyDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_CurDocument = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(_CurDocument);
    this.m_FormatOptions = this.m_CurDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = this.m_CurDocument.DisplayUnitSystem;
    this.m_Units = this.m_CurDocument.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_CurDocument.GetUnits().DecimalSymbol;
    this.InitializeControls();
    if (this.m_SingleFileRadioButton.Checked && this.m_RFASingleFileRadioButton.Checked)
      this.EPToolTip.SetToolTip((Control) this.m_SingleFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    else if (this.m_SingleFileRadioButton.Checked && this.m_CommaSingleFileRadioButton.Checked || this.m_TabSingleFileRadioButton.Checked)
      this.EPToolTip.SetToolTip((Control) this.m_SingleFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_FamilySymbolFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_DestinationFileButton, EPShared.LocalRM.GetString("NewFamilyToolTip"));
    this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    this.m_PlantListView.View = View.Details;
    ManagePlants.VerifySharedParameters(this.m_CurDocument, this.m_TransactionContainer);
    this.EnableDisableDialogFields();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_SingleFileRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewSourceOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_SingleFileRadioButton.Checked = true;
      else
        this.m_DirectoryRadioButton.Checked = true;
    }
    this.m_RFASingleFileRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewSingleFileOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_RFASingleFileRadioButton.Checked = true;
          break;
        case 1:
          this.m_CommaSingleFileRadioButton.Checked = true;
          break;
        default:
          this.m_TabSingleFileRadioButton.Checked = true;
          break;
      }
    }
    this.m_CreateSymbolFromDWGCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewCreateSymbolFromDWGCheck", ref _nReturnValue) && _nReturnValue == 1)
      this.m_CreateSymbolFromDWGCheckBox.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewDirectoryName", ref empty))
      this.m_DirectoryTextBox.Text = empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewSingleFileName", ref empty))
      this.m_SingleFileTextBox.Text = empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewFamilySymbolFileName", ref empty))
      this.m_FamilySymbolFileTextBox.Text = empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantViewDestinationFileName", ref empty))
      this.m_DestinationFileTextBox.Text = empty;
    this.m_SymbolNameComboBox.Items.Add((object) EPShared.LocalRM.GetString("AllGeometryString"));
    this.m_SymbolNameComboBox.SelectedIndex = 0;
    this.LoadColumnSettings();
  }

  private void LoadColumnSettings()
  {
    this.m_ParameterList = ManagePlants.GetParameterList("PlantView");
    this.m_PlantListView.Columns.Clear();
    string empty = string.Empty;
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string plantParamenterName = ManagePlants.GetPlantParamenterName(this.m_ParameterList[index].PlantField);
      this.m_PlantListView.Columns.Add(plantParamenterName, plantParamenterName.Length * 10, HorizontalAlignment.Left);
    }
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewSourceOption", Convert.ToInt32(!this.m_SingleFileRadioButton.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewSingleFileOption", !this.m_RFASingleFileRadioButton.Checked ? (!this.m_CommaSingleFileRadioButton.Checked ? 2 : 1) : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewCreateSymbolFromDWGCheck", this.m_CreateSymbolFromDWGCheckBox.Checked ? 1 : 0);
    if (this.m_DirectoryTextBox.Text != string.Empty)
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewDirectoryName", this.m_DirectoryTextBox.Text);
    if (this.m_SingleFileTextBox.Text != string.Empty)
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewSingleFileName", this.m_SingleFileTextBox.Text);
    if (this.m_FamilySymbolFileTextBox.Text != string.Empty)
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewFamilySymbolFileName", this.m_FamilySymbolFileTextBox.Text);
    if (this.m_DestinationFileTextBox.Text != string.Empty)
      ApplicationUtility.Settings.eplSetE_SetSetting("PlantViewDestinationFileName", this.m_DestinationFileTextBox.Text);
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
      ApplicationUtility.Settings.eplSetE_SetSetting($"PlantView{this.m_ParameterList[index].PlantField.ToString()}ColumnOrder", this.m_ParameterList[index].Order);
  }

  private void EnableDisableDialogFields() => this.EnableDisableDialogFields(true);

  private void EnableDisableDialogFields(bool _bApplyToListButtons)
  {
    bool flag = false;
    if (this.m_PlantListView.Items.Count > 0)
      flag = true;
    this.m_PlantListView.Enabled = flag;
    if (_bApplyToListButtons)
    {
      this.m_SearchButton.Enabled = flag;
      this.m_UseParametersButton.Enabled = flag;
      this.m_ColumnDisplayButton.Enabled = flag;
      this.m_ShowAllFamiliesButton.Enabled = flag;
    }
    this.m_DeleteFamiliesButton.Enabled = flag;
    this.m_FamilySymbolGroupBox.Enabled = flag;
    if (flag && !this.m_CreateSymbolFromDWGCheckBox.Checked)
    {
      this.m_FamilySymbolFileLabel.Enabled = true;
      this.m_FamilySymbolFileTextBox.Enabled = true;
      this.m_FamilySymbolFileButton.Enabled = true;
      this.m_SymbolNameLabel.Enabled = true;
      this.m_SymbolNameComboBox.Enabled = true;
    }
    else
    {
      this.m_FamilySymbolFileLabel.Enabled = false;
      this.m_FamilySymbolFileTextBox.Enabled = false;
      this.m_FamilySymbolFileButton.Enabled = false;
      this.m_SymbolNameLabel.Enabled = false;
      this.m_SymbolNameComboBox.Enabled = false;
    }
    this.m_CreateSymbolFromDWGCheckBox.Enabled = flag;
    if (flag && this.m_CreateSymbolFromDWGCheckBox.Checked)
      this.m_DWGSymbolBaseButton.Enabled = flag;
    else
      this.m_DWGSymbolBaseButton.Enabled = false;
    this.m_DestinationGroupBox.Enabled = flag;
    this.m_DestinationFileLabel.Enabled = flag;
    this.m_DestinationFileTextBox.Enabled = flag;
    this.m_DestinationFileButton.Enabled = flag;
    this.m_ExportButton.Enabled = flag;
    this.m_SaveFamilyButton.Enabled = flag;
  }

  private List<FamilyTypeContainer> PopulateFamilyTypeSetList(
    FamilyManager _FamilyManager,
    List<ExternalDefinitionContainer> _ExternalDefinitionList)
  {
    List<FamilyTypeContainer> familyTypeContainerList = (List<FamilyTypeContainer>) null;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    bool flag = false;
    ProgressBarForm progressBarForm = (ProgressBarForm) null;
    if (this.m_RFASingleFileRadioButton.Checked && this.m_SingleFileRadioButton.Checked)
    {
      progressBarForm = new ProgressBarForm();
      progressBarForm.MinValue = 0;
      progressBarForm.MaxValue = 10000;
      progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarImportMessage");
      progressBarForm.ShowForm();
      progressBarForm.Refresh();
    }
    foreach (FamilyType type in _FamilyManager.Types)
    {
      string str = type.Name.Trim();
      if (str != string.Empty)
      {
        foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
        {
          if (string.Compare(str, plantListFamilyType.FamilyTypeWrapper.FamilyTypeName, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
        {
          ListViewItem listViewItem = new ListViewItem();
          for (int index = 0; index < this.m_ParameterList.Count; ++index)
          {
            string empty3 = string.Empty;
            this.FindParamenterValue(_FamilyManager, type, ManagePlants.GetPlantParamenterName(this.m_ParameterList[index].PlantField), ref empty3);
            if (this.m_ParameterList[index].PlantField == PlantField.Height || this.m_ParameterList[index].PlantField == PlantField.PlantHeight || this.m_ParameterList[index].PlantField == PlantField.PlantWidth || this.m_ParameterList[index].PlantField == PlantField.CharacteristicsFoliageSize || this.m_ParameterList[index].PlantField == PlantField.PlantSpacing)
            {
              double _dConvertedDouble = 1.0;
              if (empty3 != string.Empty)
                _dConvertedDouble = ValueConversion.ToDouble(empty3);
              RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty3);
            }
            if (index == 0)
            {
              listViewItem = this.m_PlantListView.Items.Add(str, empty3, string.Empty);
              listViewItem.Tag = (object) str;
            }
            else
              listViewItem.SubItems.Add(empty3);
            if (this.m_RFASingleFileRadioButton.Checked && this.m_SingleFileRadioButton.Checked)
              progressBarForm.UpdateProgressBar(1);
          }
          if (familyTypeContainerList == null)
            familyTypeContainerList = new List<FamilyTypeContainer>();
          familyTypeContainerList.Add(new FamilyTypeContainer(new FamilyTypeWrapper(type), ManagePlants.GetFamilyParameterSetForType(type, _FamilyManager, _ExternalDefinitionList)));
        }
        else
          flag = false;
      }
      if (this.m_RFASingleFileRadioButton.Checked && this.m_SingleFileRadioButton.Checked)
        progressBarForm.UpdateProgressBar(1);
    }
    if (this.m_RFASingleFileRadioButton.Checked && this.m_SingleFileRadioButton.Checked)
    {
      progressBarForm.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm.Close();
    }
    return familyTypeContainerList;
  }

  private bool FindParamenterValue(
    FamilyManager FamilyManager,
    FamilyType type,
    string _strParamter,
    ref string _strValue)
  {
    bool paramenterValue = false;
    FamilyParameter familyParameter = FamilyManager[_strParamter];
    if (familyParameter != null && ManagePlants.GetPlantFieldFromParamenter(familyParameter.Definition.Name) != PlantField.None && type.HasValue(familyParameter))
    {
      switch (familyParameter.StorageType - 1)
      {
        case 0:
          if ((ValueType) type.AsInteger(familyParameter) is int)
          {
            paramenterValue = true;
            _strValue = Convert.ToString((object) type.AsInteger(familyParameter));
            break;
          }
          break;
        case 1:
          if ((ValueType) type.AsDouble(familyParameter) is double)
          {
            paramenterValue = true;
            _strValue = ValueConversion.ToString(type.AsDouble(familyParameter).Value);
            break;
          }
          break;
        case 2:
          if (type.AsString(familyParameter) != null)
          {
            paramenterValue = true;
            _strValue = type.AsString(familyParameter);
            break;
          }
          break;
      }
    }
    return paramenterValue;
  }

  private void OnSearchButton(object sender, EventArgs e)
  {
    this.SetSelectedPlantList();
    if (ManagePlants.FindFamilyTypes(EPShared.LocalRM.GetString("PlantViewSearchTitle"), this.m_CurDocument, ref this.m_PlantListFamilyTypeList))
    {
      for (int index = 0; index < this.m_PlantListView.Items.Count; ++index)
      {
        if (!this.m_PlantListView.SelectedIndices.Contains(index))
        {
          this.m_PlantListView.Items.RemoveAt(index);
          --index;
        }
      }
      this.m_nPlantListViewSortColumn = -1;
      this.m_PlantListView.Sorting = SortOrder.None;
      string empty = string.Empty;
      foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
      {
        if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
          this.PopulatePlantListView(plantListFamilyType);
      }
    }
    this.EnableDisableDialogFields(false);
  }

  private bool ValidateFields()
  {
    string text1 = this.m_FamilySymbolFileTextBox.Text;
    if (string.IsNullOrEmpty(text1))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifySymbolFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FamilySymbolFileTextBox.Focus();
      return false;
    }
    string empty = string.Empty;
    string str = ".rfa";
    if (text1.IndexOf(str) < 0)
    {
      if (text1.IndexOf("\\") > 0 || text1.IndexOf("/") > 0)
      {
        int length = -1;
        if (text1.IndexOf("\\") > 0)
          length = text1.LastIndexOf("\\");
        else if (text1.IndexOf("/") > 0)
          length = text1.LastIndexOf("/");
        if (Directory.Exists(text1.Substring(0, length)))
        {
          text1 += str;
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else if (text1.IndexOf("\\") > 0 || text1.IndexOf("/") > 0)
    {
      int length = -1;
      if (text1.IndexOf("\\") > 0)
        length = text1.LastIndexOf("\\");
      else if (text1.IndexOf("/") > 0)
        length = text1.LastIndexOf("/");
      if (!Directory.Exists(text1.Substring(0, length)))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    this.m_FamilySymbolFileTextBox.Text = text1;
    if (!File.Exists(text1))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ExistingSymbolFileName"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FamilySymbolFileTextBox.Focus();
      return false;
    }
    if (string.Compare(new FileInfo(text1).Extension, ".rfa", true) != 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SymbolNoRFAExtension"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_FamilySymbolFileTextBox.Focus();
      return false;
    }
    string text2 = this.m_DestinationFileTextBox.Text;
    if (string.IsNullOrEmpty(text2))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyDestinationFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_DestinationFileTextBox.Focus();
      return false;
    }
    if (string.Compare(new FileInfo(text2).Extension, ".rfa", true) != 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoRFAExtforDestinationMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_DestinationFileTextBox.Focus();
      return false;
    }
    if (this.m_SingleFileRadioButton.Checked && RevitUtility.CompareFileNames(this.m_SingleFileTextBox.Text, text2) == 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SameSourceAndDestinationFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_DestinationFileTextBox.Focus();
      return false;
    }
    if (File.Exists(text2))
    {
      if (RevitUtility.CompareFileNames(this.m_CurDocument.PathName, text2) != 0)
      {
        switch (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation))
        {
          case DialogResult.Cancel:
            return false;
          case DialogResult.Yes:
            Document CurDocument = (Document) null;
            if (ManagePlants.IsDocumentOpen(this.m_CurDocument.Application, text2, ref CurDocument))
            {
              bool flag = false;
              if (this.m_OpenDocumentList != null && this.m_OpenDocumentList.Count > 0)
              {
                for (int index = this.m_OpenDocumentList.Count - 1; index >= 0; --index)
                {
                  if (RevitUtility.CompareFileNames(this.m_OpenDocumentList[index].PathName, CurDocument.PathName) == 0)
                  {
                    this.m_OpenDocumentList[index].Close(false);
                    this.m_OpenDocumentList.RemoveAt(index);
                    flag = true;
                    break;
                  }
                }
              }
              if (!flag)
                CurDocument.Close(false);
            }
            File.Delete(text2);
            break;
        }
      }
      else if (RevitMessageBox.Show(EPShared.LocalRM.GetString("DestinationOverWrite"), EPShared.LocalRM.GetString("Warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
        return false;
    }
    return true;
  }

  private void SetSelectedPlantList()
  {
    int count;
    if ((count = this.m_PlantListView.SelectedItems.Count) < 1)
      return;
    for (int index1 = 0; index1 < count; ++index1)
    {
      for (int index2 = 0; index2 < this.m_PlantListFamilyTypeList.Count; ++index2)
      {
        if (this.m_PlantListFamilyTypeList[index2].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string) this.m_PlantListView.SelectedItems[index1].Tag, this.m_PlantListFamilyTypeList[index2].FamilyTypeWrapper.FamilyTypeName, true) == 0)
        {
          this.m_PlantListFamilyTypeList[index2].Status = FamilyParameterWrapperStatus.Selected;
          break;
        }
      }
    }
  }

  private bool FindSelectedPlantList(ref List<FamilyTypeContainer> _SelectedPlantList)
  {
    int count;
    if ((count = this.m_PlantListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = 0; index1 < count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_PlantListFamilyTypeList.Count; ++index2)
        {
          if (this.m_PlantListFamilyTypeList[index2].Status != FamilyParameterWrapperStatus.Excluded && string.Compare((string) this.m_PlantListView.SelectedItems[index1].Tag, this.m_PlantListFamilyTypeList[index2].FamilyTypeWrapper.FamilyTypeName, true) == 0)
          {
            _SelectedPlantList.Add(this.m_PlantListFamilyTypeList[index2]);
            break;
          }
        }
      }
      return true;
    }
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private void OnSaveFamilyButton(object sender, EventArgs e)
  {
    List<FamilyTypeContainer> _SelectedPlantList = new List<FamilyTypeContainer>();
    if (!this.FindSelectedPlantList(ref _SelectedPlantList) || !this.ValidateFields())
      return;
    FileInfo fileInfo = new FileInfo(RevitUtility.GetFormattedFileName(this.m_DestinationFileTextBox.Text, true));
    if (ManagePlants.CreateNewFamilyDocument(this.m_CurDocument, _SelectedPlantList, this.m_FamilySymbolFileTextBox.Text, (string) this.m_SymbolNameComboBox.SelectedItem, fileInfo.FullName))
    {
      this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + fileInfo.Name);
      RevitUtility.LoadFamily(this.m_CurDocument, fileInfo.FullName, true, ref this.m_TransactionContainer);
      this.m_TransactionContainer.Commit();
    }
    this.SaveSettings();
  }

  private void OnSingleFileButton(object sender, EventArgs e)
  {
    OpenFileDialog openFileDialog = new OpenFileDialog();
    if (this.m_RFASingleFileRadioButton.Checked)
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    else if (this.m_CommaSingleFileRadioButton.Checked)
      openFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
    else
      openFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
    openFileDialog.FilterIndex = 1;
    openFileDialog.RestoreDirectory = true;
    if (openFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_SingleFileTextBox.Text = openFileDialog.FileName;
    this.LoadFileFamilyInformation();
  }

  private void OnFamilySymbolFileButton(object sender, EventArgs e)
  {
    OpenFileDialog openFileDialog = new OpenFileDialog();
    openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    openFileDialog.FilterIndex = 1;
    openFileDialog.RestoreDirectory = true;
    if (openFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_FamilySymbolFileTextBox.Text = openFileDialog.FileName;
    this.LoadFamilySymbolInformation();
  }

  private void OnDestinationFileButton(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    saveFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_DestinationFileTextBox.Text = saveFileDialog.FileName;
    this.m_DestinationFileTextBox.Focus();
  }

  private void OnDirectoryPickerButton(object sender, EventArgs e)
  {
    FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
    folderBrowserDialog.Description = EPShared.LocalRM.GetString("SelectRFADir");
    folderBrowserDialog.ShowNewFolderButton = false;
    if (this.m_DirectoryTextBox.Text != string.Empty)
      folderBrowserDialog.SelectedPath = Path.GetDirectoryName(this.m_DirectoryTextBox.Text);
    if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_DirectoryTextBox.Text = folderBrowserDialog.SelectedPath;
    this.LoadDirectoryFamilyInformation();
  }

  private void OnDirectoryTextBoxLeaveFocus(object sender, EventArgs e)
  {
    this.LoadDirectoryFamilyInformation();
  }

  private void LoadDirectoryFamilyInformation()
  {
    if (RevitUtility.CompareDirectoryNames(this.m_strSourceDirectory, this.m_DirectoryTextBox.Text) == 0)
      return;
    this.CloseOpenDocuments();
    this.FindRecentFileList();
    this.m_strSourceDirectory = this.m_DirectoryTextBox.Text;
    this.m_PlantListView.Items.Clear();
    this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    if (this.m_OpenDocumentList != null)
      this.m_OpenDocumentList.Clear();
    if (this.m_strSourceDirectory != string.Empty)
    {
      DirectoryInfo directoryInfo = new DirectoryInfo(this.m_strSourceDirectory);
      if (Directory.Exists(this.m_strSourceDirectory))
      {
        FileInfo[] files = directoryInfo.GetFiles("*.rfa");
        ProgressBarForm progressBarForm = new ProgressBarForm();
        progressBarForm.MinValue = 0;
        progressBarForm.MaxValue = files.Length;
        progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarLoadingFilesMessage");
        progressBarForm.ShowForm();
        progressBarForm.Refresh();
        foreach (FileInfo _CurrentFile in files)
        {
          this.VerifyFileAndPopulateFamilyTypeSetList(_CurrentFile);
          progressBarForm.UpdateProgressBar(1);
        }
        progressBarForm.SetMaxValue();
        Thread.Sleep(300);
        progressBarForm.Close();
      }
    }
    this.EnableDisableDialogFields();
    this.LoadFamilySymbolInformation();
  }

  private void FindRecentFileList()
  {
    this.m_RecenFilesList = Settings.eplSetE_GetSectionValuesAsList("Recent File List", ApplicationUtility.RevitIniFilename);
  }

  private void ResetRecentFileList()
  {
    if (this.m_RecenFilesList == null || this.m_RecenFilesList.Count <= 0 || !Settings.eplSetE_DeleteSection("Recent File List", ApplicationUtility.RevitIniFilename))
      return;
    foreach (KeyValuePair<string, string> recenFiles in this.m_RecenFilesList)
      Settings.eplSetE_SetSetting("Recent File List", recenFiles.Key, recenFiles.Value, ApplicationUtility.RevitIniFilename);
  }

  private void CloseOpenDocuments()
  {
    if (this.m_OpenDocumentList != null && this.m_OpenDocumentList.Count > 0)
    {
      for (int index = this.m_OpenDocumentList.Count - 1; index >= 0; --index)
      {
        this.m_OpenDocumentList[index].Close(false);
        this.m_OpenDocumentList.RemoveAt(index);
      }
    }
    this.ResetRecentFileList();
  }

  private void OnPlantViewFormClosing(object sender, FormClosingEventArgs e)
  {
    this.CloseOpenDocuments();
    this.SetDialogPosition();
  }

  private void OnSymbolBaseButton(object sender, EventArgs e)
  {
    using (PlantDWGCreatorForm plantDwgCreatorForm = new PlantDWGCreatorForm(new PlantDWGViewer(this.m_CurDocument, this.m_TransactionContainer)))
    {
      if (plantDwgCreatorForm.ShowDialog() == DialogResult.Cancel)
        return;
      this.m_FamilySymbolFileTextBox.Text = plantDwgCreatorForm.SaveAsFileName;
    }
  }

  private void OnSourceChecked(object sender, EventArgs e)
  {
    this.m_DirectoryLabel.Visible = !this.m_SingleFileRadioButton.Checked;
    this.m_DirectoryTextBox.Visible = !this.m_SingleFileRadioButton.Checked;
    this.m_DirectoryButton.Visible = !this.m_SingleFileRadioButton.Checked;
    this.m_SingleFileLabel.Visible = this.m_SingleFileRadioButton.Checked;
    this.m_SingleFileTextBox.Visible = this.m_SingleFileRadioButton.Checked;
    this.m_SingleFileButton.Visible = this.m_SingleFileRadioButton.Checked;
    this.m_RFASingleFileRadioButton.Enabled = this.m_SingleFileRadioButton.Checked;
    this.m_CommaSingleFileRadioButton.Enabled = this.m_SingleFileRadioButton.Checked;
    this.m_TabSingleFileRadioButton.Enabled = this.m_SingleFileRadioButton.Checked;
  }

  private void FileRadioButtonCheckedChanged(object sender, EventArgs e)
  {
    if (this.m_SingleFileRadioButton.Checked && this.m_RFASingleFileRadioButton.Checked)
    {
      this.EPToolTip.SetToolTip((Control) this.m_SingleFileButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    }
    else
    {
      if ((!this.m_SingleFileRadioButton.Checked || !this.m_CommaSingleFileRadioButton.Checked) && !this.m_TabSingleFileRadioButton.Checked)
        return;
      this.EPToolTip.SetToolTip((Control) this.m_SingleFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
    }
  }

  private void LoadFileFamilyInformation()
  {
    if (RevitUtility.CompareFileNames(this.m_strSourceFile, this.m_SingleFileTextBox.Text) == 0)
      return;
    this.CloseOpenDocuments();
    this.FindRecentFileList();
    this.m_strSourceFile = this.m_SingleFileTextBox.Text;
    this.m_PlantListView.Items.Clear();
    this.m_PlantListFamilyTypeList = new List<FamilyTypeContainer>();
    if (this.m_OpenDocumentList != null)
      this.m_OpenDocumentList.Clear();
    if (!string.IsNullOrEmpty(this.m_strSourceFile))
    {
      FileInfo _CurrentFile = new FileInfo(this.m_strSourceFile);
      if (File.Exists(this.m_strSourceFile))
      {
        if (this.m_RFASingleFileRadioButton.Checked)
        {
          if (string.Compare(_CurrentFile.Extension, ".rfa", true) != 0)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SingleFileNoRFAMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
          this.VerifyFileAndPopulateFamilyTypeSetList(_CurrentFile);
        }
        else
        {
          if (string.Compare(_CurrentFile.Extension, ".txt", true) != 0 && string.Compare(_CurrentFile.Extension, ".csv", true) != 0)
          {
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SingleFileNoCSVTXTMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            return;
          }
          string _strSeparator = string.Empty;
          if (this.m_CommaSingleFileRadioButton.Checked)
            _strSeparator = ",";
          else if (this.m_TabSingleFileRadioButton.Checked)
            _strSeparator = "\t";
          List<FamilyTypeContainer> familyTypeContainerList = new List<FamilyTypeContainer>();
          ImportExport.ImportFileWithSeparator(this.m_CurDocument, this.m_strSourceFile, _strSeparator, ref this.m_PlantListFamilyTypeList);
          foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
            this.PopulatePlantListView(plantListFamilyType);
        }
      }
    }
    this.EnableDisableDialogFields();
    this.LoadFamilySymbolInformation();
  }

  private void OnSingleFileTextBoxLeaveFocus(object sender, EventArgs e)
  {
    this.LoadFileFamilyInformation();
  }

  private void PopulatePlantListView(FamilyTypeContainer _CurFamilyTypeContainer)
  {
    bool flag = false;
    string empty = string.Empty;
    ListViewItem listViewItem = new ListViewItem();
    for (int index1 = 0; index1 < this.m_ParameterList.Count; ++index1)
    {
      string plantParamenterName = ManagePlants.GetPlantParamenterName(this.m_ParameterList[index1].PlantField);
      for (int index2 = 0; index2 < _CurFamilyTypeContainer.FamilyParameterList.Count; ++index2)
      {
        if (string.Compare(plantParamenterName, _CurFamilyTypeContainer.FamilyParameterList[index2].ParameterName, true) == 0)
        {
          flag = true;
          string _strToDisplay = _CurFamilyTypeContainer.FamilyParameterList[index2].Value;
          if (this.m_ParameterList[index1].PlantField == PlantField.Height || this.m_ParameterList[index1].PlantField == PlantField.PlantHeight || this.m_ParameterList[index1].PlantField == PlantField.PlantWidth || this.m_ParameterList[index1].PlantField == PlantField.CharacteristicsFoliageSize || this.m_ParameterList[index1].PlantField == PlantField.PlantSpacing)
          {
            double _dConvertedDouble = 1.0;
            if (_strToDisplay != null && _strToDisplay != string.Empty)
              _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
            RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
          }
          if (index1 == 0)
          {
            listViewItem = this.m_PlantListView.Items.Add(_CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName, _strToDisplay, string.Empty);
            listViewItem.Tag = (object) _CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName;
            break;
          }
          listViewItem.SubItems.Add(_strToDisplay);
          break;
        }
      }
      if (!flag)
      {
        if (index1 == 0)
        {
          listViewItem = this.m_PlantListView.Items.Add(_CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName, string.Empty, string.Empty);
          listViewItem.Tag = (object) _CurFamilyTypeContainer.FamilyTypeWrapper.FamilyTypeName;
        }
        else
          listViewItem.SubItems.Add(string.Empty);
      }
      else
        flag = false;
    }
  }

  private void VerifyFileAndPopulateFamilyTypeSetList(FileInfo _CurrentFile)
  {
    Document CurDocument = (Document) null;
    List<FamilyTypeContainer> familyTypeContainerList = (List<FamilyTypeContainer>) null;
    string str = _CurrentFile.Name.Substring(0, _CurrentFile.Name.Length - _CurrentFile.Extension.Length);
    int num = str.LastIndexOf('.');
    if (num >= 0 && str.Length - 1 == num + 4)
    {
      int result = -1;
      if (int.TryParse(str.Substring(num + 1), out result))
        return;
    }
    bool flag = ManagePlants.IsDocumentOpen(this.m_CurDocument.Application, _CurrentFile.FullName, ref CurDocument);
    if (!flag)
      CurDocument = this.m_CurDocument.Application.OpenDocumentFile(_CurrentFile.FullName);
    EPTransactionContainer transactionContainer = new EPTransactionContainer(CurDocument);
    transactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyTypesTransaction"));
    transactionContainer.BeginTransaction();
    try
    {
      familyTypeContainerList = this.PopulateFamilyTypeSetList(CurDocument.FamilyManager, ManagePlants.PopulateExternalDefinitionList(ManagePlants.GetAllCurPlantingSharedParameters(this.m_CurDocument.Application)));
    }
    catch
    {
    }
    transactionContainer.EndTransaction();
    transactionContainer.Rollback();
    if (familyTypeContainerList != null)
    {
      if (this.m_OpenDocumentList == null)
        this.m_OpenDocumentList = new List<Document>();
      if (this.m_OpenDocumentList.Count == 0)
      {
        if (this.m_FamilySymbolFileTextBox.Text == string.Empty)
          this.m_FamilySymbolFileTextBox.Text = _CurrentFile.FullName;
        if (this.m_DestinationFileTextBox.Text == string.Empty)
          this.m_DestinationFileTextBox.Text = this.m_strSourceDirectory;
      }
      if (!flag)
        this.m_OpenDocumentList.Add(CurDocument);
      foreach (FamilyTypeContainer familyTypeContainer in familyTypeContainerList)
        this.m_PlantListFamilyTypeList.Add(familyTypeContainer);
    }
    else
    {
      if (flag)
        return;
      CurDocument.Close(false);
    }
  }

  private void OnFamilySymbolFileTextBoxLeave(object sender, EventArgs e)
  {
    this.LoadFamilySymbolInformation();
  }

  private void LoadFamilySymbolInformation()
  {
    if (!string.IsNullOrEmpty(this.m_FamilySymbolFileTextBox.Text) && new FileInfo(this.m_FamilySymbolFileTextBox.Text).Extension == string.Empty)
      this.m_FamilySymbolFileTextBox.Text += ".rfa";
    if (RevitUtility.CompareFileNames(this.m_strSymbolFile, this.m_FamilySymbolFileTextBox.Text) == 0)
      return;
    this.m_strSymbolFile = this.m_FamilySymbolFileTextBox.Text;
    this.m_SymbolNameComboBox.Items.Clear();
    if (string.IsNullOrEmpty(this.m_FamilySymbolFileTextBox.Text) || !File.Exists(this.m_FamilySymbolFileTextBox.Text))
    {
      this.m_SymbolNameComboBox.Items.Add((object) EPShared.LocalRM.GetString("AllGeometryString"));
      this.m_SymbolNameComboBox.SelectedIndex = 0;
    }
    else
    {
      this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetPlantSymbolTransaction"));
      this.m_TransactionContainer.BeginTransaction();
      Family _Family = (Family) null;
      string empty = string.Empty;
      string strB;
      if (RevitUtility.LoadFamily(this.m_CurDocument, this.m_FamilySymbolFileTextBox.Text, out _Family, true, ref this.m_TransactionContainer) && _Family != null)
      {
        strB = ((Element) _Family).Name;
      }
      else
      {
        FileInfo fileInfo = new FileInfo(this.m_FamilySymbolFileTextBox.Text);
        strB = !(fileInfo.Extension != string.Empty) ? fileInfo.Name : fileInfo.Name.Substring(0, fileInfo.Name.LastIndexOf(fileInfo.Extension));
      }
      foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurDocument).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001360).ToElements())
      {
        if (element is FamilySymbol familySymbol && ((Element) familySymbol).Category != null && ((Element) familySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) familySymbol.Family).Name, strB, true) == 0)
          this.m_SymbolNameComboBox.Items.Add((object) ((Element) familySymbol).Name);
      }
      if (this.m_SymbolNameComboBox.Items.Count > 0)
      {
        this.m_SymbolNameComboBox.Items.Insert(0, (object) EPShared.LocalRM.GetString("AllSymbolsString"));
      }
      else
      {
        IList<Element> elements = new FilteredElementCollector(this.m_CurDocument).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2000151).ToElements();
        bool flag = false;
        foreach (Element element in (IEnumerable<Element>) elements)
        {
          if (element is FamilySymbol familySymbol && ((Element) familySymbol).Category != null && ((Element) familySymbol).Category.Id.IntegerValue == ((BuiltInCategory) -2000151).GetHashCode() && string.Compare(((Element) familySymbol.Family).Name, strB, true) == 0)
          {
            Parameter parameter = ((Element) familySymbol).LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
            if (parameter != null)
            {
              if (string.Compare(parameter.AsString(), Convert.ToInt32((object) LandcaddID.Planting).ToString("000"), true) == 0)
                flag = true;
              this.m_SymbolNameComboBox.Items.Add((object) ((Element) familySymbol).Name);
            }
          }
        }
        if (!flag)
          this.m_SymbolNameComboBox.Items.Clear();
        if (this.m_SymbolNameComboBox.Items.Count > 0)
          this.m_SymbolNameComboBox.Items.Insert(0, (object) EPShared.LocalRM.GetString("AllSymbolsString"));
        else
          this.m_SymbolNameComboBox.Items.Add((object) EPShared.LocalRM.GetString("AllGeometryString"));
      }
      this.m_TransactionContainer.AbortTransaction();
      this.m_TransactionContainer.Rollback();
      this.m_SymbolNameComboBox.SelectedIndex = 0;
    }
  }

  private void OnUseParametersButtonClick(object sender, EventArgs e)
  {
    using (PlantFieldsForm plantFieldsForm = new PlantFieldsForm(false, "PlantFields"))
    {
      int num = (int) plantFieldsForm.ShowDialog();
    }
  }

  private void OnColumnDisplayButtonClick(object sender, EventArgs e)
  {
    using (PlantFieldsForm plantFieldsForm = new PlantFieldsForm(true, "PlantView"))
    {
      if (plantFieldsForm.ShowDialog() == DialogResult.Cancel)
        return;
      this.LoadColumnSettings();
      this.m_PlantListView.Items.Clear();
      foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
      {
        if (plantListFamilyType.Status == FamilyParameterWrapperStatus.Included)
        {
          plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
          this.PopulatePlantListView(plantListFamilyType);
        }
      }
    }
  }

  private void OnCreateSymbolFromDWGCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_DWGSymbolBaseButton.Enabled = this.m_CreateSymbolFromDWGCheckBox.Checked;
    this.m_FamilySymbolFileLabel.Enabled = !this.m_CreateSymbolFromDWGCheckBox.Checked;
    this.m_FamilySymbolFileTextBox.Enabled = !this.m_CreateSymbolFromDWGCheckBox.Checked;
    this.m_FamilySymbolFileButton.Enabled = !this.m_CreateSymbolFromDWGCheckBox.Checked;
    this.m_SymbolNameLabel.Enabled = !this.m_CreateSymbolFromDWGCheckBox.Checked;
    this.m_SymbolNameComboBox.Enabled = !this.m_CreateSymbolFromDWGCheckBox.Checked;
  }

  private void OnExportButtonClick(object sender, EventArgs e)
  {
    List<FamilyTypeContainer> _SelectedPlantList = new List<FamilyTypeContainer>();
    if (!this.FindSelectedPlantList(ref _SelectedPlantList))
      return;
    using (PlantExportForm plantExportForm = new PlantExportForm(this.m_CurDocument, _SelectedPlantList, ManagePlants.GetParameterList("PlantFields", true)))
    {
      int num = (int) plantExportForm.ShowDialog();
    }
  }

  private void OnPlantListViewColumnClick(object sender, ColumnClickEventArgs e)
  {
    if (e.Column != this.m_nPlantListViewSortColumn)
    {
      this.m_nPlantListViewSortColumn = e.Column;
      this.m_PlantListView.Sorting = SortOrder.Ascending;
    }
    else
      this.m_PlantListView.Sorting = this.m_PlantListView.Sorting != SortOrder.Ascending ? SortOrder.Ascending : SortOrder.Descending;
    this.m_PlantListView.Sort();
    this.m_PlantListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(e.Column, this.m_PlantListView.Sorting);
  }

  private void OnShowAllFamiliesButtonClick(object sender, EventArgs e)
  {
    int listViewSortColumn = this.m_nPlantListViewSortColumn;
    SortOrder sorting = this.m_PlantListView.Sorting;
    this.SetSelectedPlantList();
    for (int index = 0; index < this.m_PlantListView.Items.Count; ++index)
    {
      if (!this.m_PlantListView.SelectedIndices.Contains(index))
      {
        this.m_PlantListView.Items.RemoveAt(index);
        --index;
      }
    }
    this.m_nPlantListViewSortColumn = -1;
    this.m_PlantListView.Sorting = SortOrder.None;
    string empty = string.Empty;
    foreach (FamilyTypeContainer plantListFamilyType in this.m_PlantListFamilyTypeList)
    {
      if (plantListFamilyType.Status != FamilyParameterWrapperStatus.Selected)
      {
        plantListFamilyType.Status = FamilyParameterWrapperStatus.Included;
        this.PopulatePlantListView(plantListFamilyType);
      }
    }
    this.EnableDisableDialogFields(false);
    if (sorting == SortOrder.None)
      return;
    this.m_nPlantListViewSortColumn = listViewSortColumn;
    this.m_PlantListView.Sorting = sorting;
    this.m_PlantListView.Sort();
    this.m_PlantListView.ListViewItemSorter = (IComparer) new ListViewItemComparer(this.m_nPlantListViewSortColumn, this.m_PlantListView.Sorting);
  }

  private void OnDeleteFamiliesButtonClick(object sender, EventArgs e)
  {
    if (this.m_PlantListView.SelectedItems.Count >= 1)
    {
      for (int index1 = 0; index1 < this.m_PlantListFamilyTypeList.Count; ++index1)
      {
        if (this.m_PlantListFamilyTypeList[index1].Status != FamilyParameterWrapperStatus.Excluded)
        {
          int index2 = this.m_PlantListView.SelectedItems.IndexOfKey(this.m_PlantListFamilyTypeList[index1].FamilyTypeWrapper.FamilyTypeName);
          if (index2 >= 0)
          {
            this.m_PlantListFamilyTypeList[index1].Status = FamilyParameterWrapperStatus.Excluded;
            this.m_PlantListView.SelectedItems[index2].Remove();
            if (this.m_PlantListView.SelectedItems.Count == 0)
              break;
          }
        }
      }
      this.EnableDisableDialogFields(false);
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoPlantsSelected"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
  }

  private void OnDirectoryTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.LoadDirectoryFamilyInformation();
  }

  private void OnSingleFileTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.LoadFileFamilyInformation();
  }

  private void OnFamilySymbolFileTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.LoadFamilySymbolInformation();
  }

  private void AddExtensionToDestination()
  {
    if (string.IsNullOrEmpty(this.m_DestinationFileTextBox.Text) || !(new FileInfo(this.m_DestinationFileTextBox.Text).Extension == string.Empty))
      return;
    this.m_DestinationFileTextBox.Text += ".rfa";
  }

  private void OnDestinationFileTextBoxLeave(object sender, EventArgs e)
  {
    this.AddExtensionToDestination();
  }

  private void OnDestinationFileTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.AddExtensionToDestination();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_CancelButton = new Button();
    this.m_SaveFamilyButton = new Button();
    this.m_DWGSymbolBaseButton = new Button();
    this.m_SourceGroupBox = new GroupBox();
    this.m_DirectoryTextBox = new TextBox();
    this.m_DirectoryButton = new Button();
    this.m_SingleFileTextBox = new TextBox();
    this.m_SingleFileButton = new Button();
    this.m_DirectoryLabel = new Label();
    this.m_SingleFileLabel = new Label();
    this.m_SingleFileRadioButton = new RadioButton();
    this.m_DirectoryRadioButton = new RadioButton();
    this.m_SingleFileGroupBox = new GroupBox();
    this.m_TabSingleFileRadioButton = new RadioButton();
    this.m_CommaSingleFileRadioButton = new RadioButton();
    this.m_RFASingleFileRadioButton = new RadioButton();
    this.m_DestinationGroupBox = new GroupBox();
    this.m_DestinationFileTextBox = new TextBox();
    this.m_DestinationFileButton = new Button();
    this.m_DestinationFileLabel = new Label();
    this.m_FamilySymbolGroupBox = new GroupBox();
    this.m_CreateSymbolFromDWGCheckBox = new CheckBox();
    this.m_SymbolNameLabel = new Label();
    this.m_SymbolNameComboBox = new ComboBox();
    this.m_FamilySymbolFileTextBox = new TextBox();
    this.m_FamilySymbolFileButton = new Button();
    this.m_FamilySymbolFileLabel = new Label();
    this.m_ExportButton = new Button();
    this.m_PlantCollectionGroupBox = new GroupBox();
    this.m_ShowAllFamiliesButton = new Button();
    this.m_DeleteFamiliesButton = new Button();
    this.m_ColumnDisplayButton = new Button();
    this.m_UseParametersButton = new Button();
    this.m_SearchButton = new Button();
    this.m_PlantListView = new ListView();
    this.m_SourceGroupBox.SuspendLayout();
    this.m_SingleFileGroupBox.SuspendLayout();
    this.m_DestinationGroupBox.SuspendLayout();
    this.m_FamilySymbolGroupBox.SuspendLayout();
    this.m_PlantCollectionGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(523, 538);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(77, 23);
    this.m_CancelButton.TabIndex = 6;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_SaveFamilyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_SaveFamilyButton.Location = new Point(432, 538);
    this.m_SaveFamilyButton.Name = "m_SaveFamilyButton";
    this.m_SaveFamilyButton.Size = new Size(85, 23);
    this.m_SaveFamilyButton.TabIndex = 5;
    this.m_SaveFamilyButton.Text = "Sa&ve Family";
    this.m_SaveFamilyButton.UseVisualStyleBackColor = true;
    this.m_SaveFamilyButton.Click += new EventHandler(this.OnSaveFamilyButton);
    this.m_DWGSymbolBaseButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_DWGSymbolBaseButton.Enabled = false;
    this.m_DWGSymbolBaseButton.Location = new Point(221, 72);
    this.m_DWGSymbolBaseButton.Name = "m_DWGSymbolBaseButton";
    this.m_DWGSymbolBaseButton.Size = new Size(110, 23);
    this.m_DWGSymbolBaseButton.TabIndex = 6;
    this.m_DWGSymbolBaseButton.Text = "D&WG Symbol";
    this.m_DWGSymbolBaseButton.UseVisualStyleBackColor = true;
    this.m_DWGSymbolBaseButton.Click += new EventHandler(this.OnSymbolBaseButton);
    this.m_SourceGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SourceGroupBox.Controls.Add((Control) this.m_DirectoryTextBox);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_DirectoryButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileTextBox);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_DirectoryLabel);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileLabel);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileRadioButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_DirectoryRadioButton);
    this.m_SourceGroupBox.Controls.Add((Control) this.m_SingleFileGroupBox);
    this.m_SourceGroupBox.Location = new Point(12, 12);
    this.m_SourceGroupBox.Name = "m_SourceGroupBox";
    this.m_SourceGroupBox.Size = new Size(587, 128 /*0x80*/);
    this.m_SourceGroupBox.TabIndex = 0;
    this.m_SourceGroupBox.TabStop = false;
    this.m_SourceGroupBox.Text = "Source";
    this.m_DirectoryTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DirectoryTextBox.Location = new Point(80 /*0x50*/, 99);
    this.m_DirectoryTextBox.Name = "m_DirectoryTextBox";
    this.m_DirectoryTextBox.Size = new Size(471, 20);
    this.m_DirectoryTextBox.TabIndex = 4;
    this.m_DirectoryTextBox.KeyDown += new KeyEventHandler(this.OnDirectoryTextBoxKeyDown);
    this.m_DirectoryTextBox.Leave += new EventHandler(this.OnDirectoryTextBoxLeaveFocus);
    this.m_DirectoryButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_DirectoryButton.Location = new Point(557, 98);
    this.m_DirectoryButton.Name = "m_DirectoryButton";
    this.m_DirectoryButton.Size = new Size(24, 20);
    this.m_DirectoryButton.TabIndex = 5;
    this.m_DirectoryButton.TabStop = false;
    this.m_DirectoryButton.Text = "...";
    this.m_DirectoryButton.UseVisualStyleBackColor = true;
    this.m_DirectoryButton.Click += new EventHandler(this.OnDirectoryPickerButton);
    this.m_SingleFileTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SingleFileTextBox.Location = new Point(80 /*0x50*/, 99);
    this.m_SingleFileTextBox.Name = "m_SingleFileTextBox";
    this.m_SingleFileTextBox.Size = new Size(471, 20);
    this.m_SingleFileTextBox.TabIndex = 4;
    this.m_SingleFileTextBox.KeyDown += new KeyEventHandler(this.OnSingleFileTextBoxKeyDown);
    this.m_SingleFileTextBox.Leave += new EventHandler(this.OnSingleFileTextBoxLeaveFocus);
    this.m_SingleFileButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_SingleFileButton.Location = new Point(557, 99);
    this.m_SingleFileButton.Name = "m_SingleFileButton";
    this.m_SingleFileButton.Size = new Size(24, 20);
    this.m_SingleFileButton.TabIndex = 5;
    this.m_SingleFileButton.TabStop = false;
    this.m_SingleFileButton.Text = "...";
    this.m_SingleFileButton.UseVisualStyleBackColor = true;
    this.m_SingleFileButton.Click += new EventHandler(this.OnSingleFileButton);
    this.m_DirectoryLabel.AutoSize = true;
    this.m_DirectoryLabel.Location = new Point(9, 102);
    this.m_DirectoryLabel.Name = "m_DirectoryLabel";
    this.m_DirectoryLabel.Size = new Size(52, 13);
    this.m_DirectoryLabel.TabIndex = 3;
    this.m_DirectoryLabel.Text = "Direct&ory:";
    this.m_SingleFileLabel.AutoSize = true;
    this.m_SingleFileLabel.Location = new Point(9, 102);
    this.m_SingleFileLabel.Name = "m_SingleFileLabel";
    this.m_SingleFileLabel.Size = new Size(26, 13);
    this.m_SingleFileLabel.TabIndex = 3;
    this.m_SingleFileLabel.Text = "&File:";
    this.m_SingleFileRadioButton.AutoSize = true;
    this.m_SingleFileRadioButton.Location = new Point(12, 19);
    this.m_SingleFileRadioButton.Name = "m_SingleFileRadioButton";
    this.m_SingleFileRadioButton.Size = new Size(73, 17);
    this.m_SingleFileRadioButton.TabIndex = 0;
    this.m_SingleFileRadioButton.TabStop = true;
    this.m_SingleFileRadioButton.Text = "&Single File";
    this.m_SingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_SingleFileRadioButton.CheckedChanged += new EventHandler(this.OnSourceChecked);
    this.m_DirectoryRadioButton.AutoSize = true;
    this.m_DirectoryRadioButton.Location = new Point(164, 19);
    this.m_DirectoryRadioButton.Name = "m_DirectoryRadioButton";
    this.m_DirectoryRadioButton.Size = new Size(168, 17);
    this.m_DirectoryRadioButton.TabIndex = 1;
    this.m_DirectoryRadioButton.TabStop = true;
    this.m_DirectoryRadioButton.Text = "&Directory (Multiple Family Files)";
    this.m_DirectoryRadioButton.UseVisualStyleBackColor = true;
    this.m_DirectoryRadioButton.CheckedChanged += new EventHandler(this.OnSourceChecked);
    this.m_SingleFileGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SingleFileGroupBox.Controls.Add((Control) this.m_TabSingleFileRadioButton);
    this.m_SingleFileGroupBox.Controls.Add((Control) this.m_CommaSingleFileRadioButton);
    this.m_SingleFileGroupBox.Controls.Add((Control) this.m_RFASingleFileRadioButton);
    this.m_SingleFileGroupBox.Location = new Point(6, 42);
    this.m_SingleFileGroupBox.Name = "m_SingleFileGroupBox";
    this.m_SingleFileGroupBox.Size = new Size(575, 51);
    this.m_SingleFileGroupBox.TabIndex = 2;
    this.m_SingleFileGroupBox.TabStop = false;
    this.m_SingleFileGroupBox.Text = "Single File Options";
    this.m_TabSingleFileRadioButton.AutoSize = true;
    this.m_TabSingleFileRadioButton.Location = new Point(362, 23);
    this.m_TabSingleFileRadioButton.Name = "m_TabSingleFileRadioButton";
    this.m_TabSingleFileRadioButton.Size = new Size(139, 17);
    this.m_TabSingleFileRadioButton.TabIndex = 2;
    this.m_TabSingleFileRadioButton.TabStop = true;
    this.m_TabSingleFileRadioButton.Text = "&Tab Delimited (Text File)";
    this.m_TabSingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_TabSingleFileRadioButton.CheckedChanged += new EventHandler(this.FileRadioButtonCheckedChanged);
    this.m_CommaSingleFileRadioButton.AutoSize = true;
    this.m_CommaSingleFileRadioButton.Location = new Point(158, 23);
    this.m_CommaSingleFileRadioButton.Name = "m_CommaSingleFileRadioButton";
    this.m_CommaSingleFileRadioButton.Size = new Size(155, 17);
    this.m_CommaSingleFileRadioButton.TabIndex = 1;
    this.m_CommaSingleFileRadioButton.TabStop = true;
    this.m_CommaSingleFileRadioButton.Text = "&Comma Delimited (CSV File)";
    this.m_CommaSingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_CommaSingleFileRadioButton.CheckedChanged += new EventHandler(this.FileRadioButtonCheckedChanged);
    this.m_RFASingleFileRadioButton.AutoSize = true;
    this.m_RFASingleFileRadioButton.Location = new Point(6, 23);
    this.m_RFASingleFileRadioButton.Name = "m_RFASingleFileRadioButton";
    this.m_RFASingleFileRadioButton.Size = new Size(103, 17);
    this.m_RFASingleFileRadioButton.TabIndex = 0;
    this.m_RFASingleFileRadioButton.TabStop = true;
    this.m_RFASingleFileRadioButton.Text = "&RFA (Family File)";
    this.m_RFASingleFileRadioButton.UseVisualStyleBackColor = true;
    this.m_RFASingleFileRadioButton.CheckedChanged += new EventHandler(this.FileRadioButtonCheckedChanged);
    this.m_DestinationGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DestinationGroupBox.Controls.Add((Control) this.m_DestinationFileTextBox);
    this.m_DestinationGroupBox.Controls.Add((Control) this.m_DestinationFileButton);
    this.m_DestinationGroupBox.Controls.Add((Control) this.m_DestinationFileLabel);
    this.m_DestinationGroupBox.Location = new Point(13, 489);
    this.m_DestinationGroupBox.Name = "m_DestinationGroupBox";
    this.m_DestinationGroupBox.Size = new Size(587, 42);
    this.m_DestinationGroupBox.TabIndex = 3;
    this.m_DestinationGroupBox.TabStop = false;
    this.m_DestinationGroupBox.Text = "Destination";
    this.m_DestinationFileTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_DestinationFileTextBox.Location = new Point(58, 16 /*0x10*/);
    this.m_DestinationFileTextBox.Name = "m_DestinationFileTextBox";
    this.m_DestinationFileTextBox.Size = new Size(492, 20);
    this.m_DestinationFileTextBox.TabIndex = 1;
    this.m_DestinationFileTextBox.KeyDown += new KeyEventHandler(this.OnDestinationFileTextBoxKeyDown);
    this.m_DestinationFileTextBox.Leave += new EventHandler(this.OnDestinationFileTextBoxLeave);
    this.m_DestinationFileButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_DestinationFileButton.Location = new Point(556, 15);
    this.m_DestinationFileButton.Name = "m_DestinationFileButton";
    this.m_DestinationFileButton.Size = new Size(24, 20);
    this.m_DestinationFileButton.TabIndex = 2;
    this.m_DestinationFileButton.TabStop = false;
    this.m_DestinationFileButton.Text = "...";
    this.m_DestinationFileButton.UseVisualStyleBackColor = true;
    this.m_DestinationFileButton.Click += new EventHandler(this.OnDestinationFileButton);
    this.m_DestinationFileLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_DestinationFileLabel.AutoSize = true;
    this.m_DestinationFileLabel.Location = new Point(6, 19);
    this.m_DestinationFileLabel.Name = "m_DestinationFileLabel";
    this.m_DestinationFileLabel.Size = new Size(26, 13);
    this.m_DestinationFileLabel.TabIndex = 0;
    this.m_DestinationFileLabel.Text = "Fi&le:";
    this.m_FamilySymbolGroupBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_CreateSymbolFromDWGCheckBox);
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_SymbolNameLabel);
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_SymbolNameComboBox);
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_FamilySymbolFileTextBox);
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_FamilySymbolFileButton);
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_DWGSymbolBaseButton);
    this.m_FamilySymbolGroupBox.Controls.Add((Control) this.m_FamilySymbolFileLabel);
    this.m_FamilySymbolGroupBox.Location = new Point(12, 382);
    this.m_FamilySymbolGroupBox.Name = "m_FamilySymbolGroupBox";
    this.m_FamilySymbolGroupBox.Size = new Size(588, 101);
    this.m_FamilySymbolGroupBox.TabIndex = 2;
    this.m_FamilySymbolGroupBox.TabStop = false;
    this.m_FamilySymbolGroupBox.Text = "Family Symbol Options";
    this.m_CreateSymbolFromDWGCheckBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_CreateSymbolFromDWGCheckBox.AutoSize = true;
    this.m_CreateSymbolFromDWGCheckBox.Location = new Point(9, 76);
    this.m_CreateSymbolFromDWGCheckBox.Name = "m_CreateSymbolFromDWGCheckBox";
    this.m_CreateSymbolFromDWGCheckBox.Size = new Size(161, 17);
    this.m_CreateSymbolFromDWGCheckBox.TabIndex = 5;
    this.m_CreateSymbolFromDWGCheckBox.Text = "Cr&eate Symbol From DWG(s)";
    this.m_CreateSymbolFromDWGCheckBox.UseVisualStyleBackColor = true;
    this.m_CreateSymbolFromDWGCheckBox.CheckedChanged += new EventHandler(this.OnCreateSymbolFromDWGCheckBoxChecked);
    this.m_SymbolNameLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_SymbolNameLabel.AutoSize = true;
    this.m_SymbolNameLabel.Location = new Point(6, 48 /*0x30*/);
    this.m_SymbolNameLabel.Name = "m_SymbolNameLabel";
    this.m_SymbolNameLabel.Size = new Size(75, 13);
    this.m_SymbolNameLabel.TabIndex = 3;
    this.m_SymbolNameLabel.Text = "Sym&bol Name:";
    this.m_SymbolNameComboBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SymbolNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_SymbolNameComboBox.FormattingEnabled = true;
    this.m_SymbolNameComboBox.Location = new Point(141, 45);
    this.m_SymbolNameComboBox.Name = "m_SymbolNameComboBox";
    this.m_SymbolNameComboBox.Size = new Size(411, 21);
    this.m_SymbolNameComboBox.TabIndex = 4;
    this.m_FamilySymbolFileTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_FamilySymbolFileTextBox.Location = new Point(141, 19);
    this.m_FamilySymbolFileTextBox.Name = "m_FamilySymbolFileTextBox";
    this.m_FamilySymbolFileTextBox.Size = new Size(411, 20);
    this.m_FamilySymbolFileTextBox.TabIndex = 1;
    this.m_FamilySymbolFileTextBox.KeyDown += new KeyEventHandler(this.OnFamilySymbolFileTextBoxKeyDown);
    this.m_FamilySymbolFileTextBox.Leave += new EventHandler(this.OnFamilySymbolFileTextBoxLeave);
    this.m_FamilySymbolFileButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_FamilySymbolFileButton.Location = new Point(558, 19);
    this.m_FamilySymbolFileButton.Name = "m_FamilySymbolFileButton";
    this.m_FamilySymbolFileButton.Size = new Size(24, 20);
    this.m_FamilySymbolFileButton.TabIndex = 2;
    this.m_FamilySymbolFileButton.TabStop = false;
    this.m_FamilySymbolFileButton.Text = "...";
    this.m_FamilySymbolFileButton.UseVisualStyleBackColor = true;
    this.m_FamilySymbolFileButton.Click += new EventHandler(this.OnFamilySymbolFileButton);
    this.m_FamilySymbolFileLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_FamilySymbolFileLabel.AutoSize = true;
    this.m_FamilySymbolFileLabel.Location = new Point(6, 22);
    this.m_FamilySymbolFileLabel.Name = "m_FamilySymbolFileLabel";
    this.m_FamilySymbolFileLabel.Size = new Size(63 /*0x3F*/, 13);
    this.m_FamilySymbolFileLabel.TabIndex = 0;
    this.m_FamilySymbolFileLabel.Text = "S&ymbol File:";
    this.m_ExportButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ExportButton.Location = new Point(351, 538);
    this.m_ExportButton.Name = "m_ExportButton";
    this.m_ExportButton.Size = new Size(75, 23);
    this.m_ExportButton.TabIndex = 4;
    this.m_ExportButton.Text = "E&xport";
    this.m_ExportButton.UseVisualStyleBackColor = true;
    this.m_ExportButton.Click += new EventHandler(this.OnExportButtonClick);
    this.m_PlantCollectionGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_PlantCollectionGroupBox.Controls.Add((Control) this.m_ShowAllFamiliesButton);
    this.m_PlantCollectionGroupBox.Controls.Add((Control) this.m_DeleteFamiliesButton);
    this.m_PlantCollectionGroupBox.Controls.Add((Control) this.m_ColumnDisplayButton);
    this.m_PlantCollectionGroupBox.Controls.Add((Control) this.m_UseParametersButton);
    this.m_PlantCollectionGroupBox.Controls.Add((Control) this.m_SearchButton);
    this.m_PlantCollectionGroupBox.Controls.Add((Control) this.m_PlantListView);
    this.m_PlantCollectionGroupBox.Location = new Point(12, 146);
    this.m_PlantCollectionGroupBox.Name = "m_PlantCollectionGroupBox";
    this.m_PlantCollectionGroupBox.Size = new Size(588, 230);
    this.m_PlantCollectionGroupBox.TabIndex = 1;
    this.m_PlantCollectionGroupBox.TabStop = false;
    this.m_PlantCollectionGroupBox.Text = "Plant Collection";
    this.m_ShowAllFamiliesButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ShowAllFamiliesButton.Location = new Point(473, 136);
    this.m_ShowAllFamiliesButton.Name = "m_ShowAllFamiliesButton";
    this.m_ShowAllFamiliesButton.Size = new Size(109, 23);
    this.m_ShowAllFamiliesButton.TabIndex = 5;
    this.m_ShowAllFamiliesButton.Text = "Show &All";
    this.m_ShowAllFamiliesButton.UseVisualStyleBackColor = true;
    this.m_ShowAllFamiliesButton.Click += new EventHandler(this.OnShowAllFamiliesButtonClick);
    this.m_DeleteFamiliesButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_DeleteFamiliesButton.Location = new Point(473, 107);
    this.m_DeleteFamiliesButton.Name = "m_DeleteFamiliesButton";
    this.m_DeleteFamiliesButton.Size = new Size(109, 23);
    this.m_DeleteFamiliesButton.TabIndex = 4;
    this.m_DeleteFamiliesButton.Text = "Delete From L&ist";
    this.m_DeleteFamiliesButton.UseVisualStyleBackColor = true;
    this.m_DeleteFamiliesButton.Click += new EventHandler(this.OnDeleteFamiliesButtonClick);
    this.m_ColumnDisplayButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_ColumnDisplayButton.Location = new Point(473, 77);
    this.m_ColumnDisplayButton.Name = "m_ColumnDisplayButton";
    this.m_ColumnDisplayButton.Size = new Size(110, 23);
    this.m_ColumnDisplayButton.TabIndex = 3;
    this.m_ColumnDisplayButton.Text = "Colu&mn Display";
    this.m_ColumnDisplayButton.UseVisualStyleBackColor = true;
    this.m_ColumnDisplayButton.Click += new EventHandler(this.OnColumnDisplayButtonClick);
    this.m_UseParametersButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_UseParametersButton.Location = new Point(473, 48 /*0x30*/);
    this.m_UseParametersButton.Name = "m_UseParametersButton";
    this.m_UseParametersButton.Size = new Size(110, 23);
    this.m_UseParametersButton.TabIndex = 2;
    this.m_UseParametersButton.Text = "&Use Parameters";
    this.m_UseParametersButton.UseVisualStyleBackColor = true;
    this.m_UseParametersButton.Click += new EventHandler(this.OnUseParametersButtonClick);
    this.m_SearchButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
    this.m_SearchButton.Location = new Point(473, 19);
    this.m_SearchButton.Name = "m_SearchButton";
    this.m_SearchButton.Size = new Size(109, 23);
    this.m_SearchButton.TabIndex = 1;
    this.m_SearchButton.Text = "Searc&h";
    this.m_SearchButton.UseVisualStyleBackColor = true;
    this.m_SearchButton.Click += new EventHandler(this.OnSearchButton);
    this.m_PlantListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_PlantListView.FullRowSelect = true;
    this.m_PlantListView.HideSelection = false;
    this.m_PlantListView.Location = new Point(9, 19);
    this.m_PlantListView.Name = "m_PlantListView";
    this.m_PlantListView.Size = new Size(458, 205);
    this.m_PlantListView.TabIndex = 0;
    this.m_PlantListView.UseCompatibleStateImageBehavior = false;
    this.m_PlantListView.ColumnClick += new ColumnClickEventHandler(this.OnPlantListViewColumnClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(612, 573);
    this.Controls.Add((Control) this.m_PlantCollectionGroupBox);
    this.Controls.Add((Control) this.m_ExportButton);
    this.Controls.Add((Control) this.m_FamilySymbolGroupBox);
    this.Controls.Add((Control) this.m_DestinationGroupBox);
    this.Controls.Add((Control) this.m_SourceGroupBox);
    this.Controls.Add((Control) this.m_SaveFamilyButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.MinimumSize = new Size(620, 600);
    this.Name = nameof (PlantViewForm);
    this.Text = "Plant Family Manager";
    this.FormClosing += new FormClosingEventHandler(this.OnPlantViewFormClosing);
    this.m_SourceGroupBox.ResumeLayout(false);
    this.m_SourceGroupBox.PerformLayout();
    this.m_SingleFileGroupBox.ResumeLayout(false);
    this.m_SingleFileGroupBox.PerformLayout();
    this.m_DestinationGroupBox.ResumeLayout(false);
    this.m_DestinationGroupBox.PerformLayout();
    this.m_FamilySymbolGroupBox.ResumeLayout(false);
    this.m_FamilySymbolGroupBox.PerformLayout();
    this.m_PlantCollectionGroupBox.ResumeLayout(false);
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_SaveFamilyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
