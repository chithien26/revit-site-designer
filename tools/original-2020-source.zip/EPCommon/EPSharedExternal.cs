﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.EPSharedExternal
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.Runtime.InteropServices;
using System.Text;

#nullable disable
namespace EPCommon;

public class EPSharedExternal
{
  public const int m_nMaxStringBuilderSize = 32767 /*0x7FFF*/;

  public static bool eplLicM_GetLicense()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_GetLicense() : EPSharedExternal.Externalx64.eplLM_GetLicense();
  }

  public static bool eplLicM_IsNodeLicense()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_IsNodeLicense() : EPSharedExternal.Externalx64.eplLM_IsNodeLicense();
  }

  public static bool eplLicM_LicenseManagement()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_LicenseManagement() : EPSharedExternal.Externalx64.eplLM_LicenseManagement();
  }

  public static bool eplLicM_IsBorrowedNetworkLicense()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_IsBorrowedNetworkLicense() : EPSharedExternal.Externalx64.eplLM_IsBorrowedNetworkLicense();
  }

  public static bool eplLicM_BorrowNetworkLicense()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_BorrowNetworkLicense() : EPSharedExternal.Externalx64.eplLM_BorrowNetworkLicense();
  }

  public static bool eplLicM_ReturnBorrowedLicense()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_ReturnBorrowedLicense() : EPSharedExternal.Externalx64.eplLM_ReturnBorrowedLicense();
  }

  public static bool eplLicM_ReturnLicense()
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplLM_ReturnLicense() : EPSharedExternal.Externalx64.eplLM_ReturnLicense();
  }

  public static bool eplGeoE_ArePntsDuplicates2D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt)
  {
    return EPSharedExternal.eplGeoE_ArePntsDuplicates2D(_FirstCheckPnt, _SecondCheckPnt, 1E-05);
  }

  public static bool eplGeoE_ArePntsDuplicates2D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt,
    double _dTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstCheckPnt));
    Marshal.StructureToPtr<Eps_Point>(_FirstCheckPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondCheckPnt));
    Marshal.StructureToPtr<Eps_Point>(_SecondCheckPnt, num2, true);
    bool flag = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_ArePntsDuplicates2D(num1, num2, _dTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_ArePntsDuplicates2D(num1, num2, _dTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return flag;
  }

  public static int eplGeoE_CalcHorzAngByThreePnts(
    Eps_Point _StartPnt,
    Eps_Point _Vertex,
    Eps_Point _EndPnt,
    int _nAngleType,
    ref double _dAngle,
    double _dPointTol)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_StartPnt));
    Marshal.StructureToPtr<Eps_Point>(_StartPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Vertex));
    Marshal.StructureToPtr<Eps_Point>(_Vertex, num2, true);
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_EndPnt));
    Marshal.StructureToPtr<Eps_Point>(_EndPnt, num3, true);
    int num4 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CalcHorzAngByThreePnts(num1, num2, num3, _nAngleType, ref _dAngle, _dPointTol) : EPSharedExternal.Externalx86.eplDLLGeoE_CalcHorzAngByThreePnts(num1, num2, num3, _nAngleType, ref _dAngle, _dPointTol);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    Marshal.FreeHGlobal(num3);
    return num4;
  }

  public static double eplGeoE_NormalizeRadians(double _dAngle)
  {
    double _dReturnValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_NormalizeRadians(_dAngle, ref _dReturnValue);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_NormalizeRadians(_dAngle, ref _dReturnValue);
    return _dReturnValue;
  }

  public static int eplGeoE_CalcHorzDirBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDirection)
  {
    return EPSharedExternal.eplGeoE_CalcHorzDirBtwnTwoPnts(_FirstPnt, _SecondPnt, ref _dDirection, 1E-05);
  }

  public static int eplGeoE_CalcHorzDirBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDirection,
    double _dMinDist)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstPnt));
    Marshal.StructureToPtr<Eps_Point>(_FirstPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondPnt));
    Marshal.StructureToPtr<Eps_Point>(_SecondPnt, num2, true);
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CalcHorzDirBtwnTwoPnts(num1, num2, ref _dDirection, _dMinDist) : EPSharedExternal.Externalx86.eplDLLGeoE_CalcHorzDirBtwnTwoPnts(num1, num2, ref _dDirection, _dMinDist);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static int eplGeoE_CalcHorzDistBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDistance)
  {
    return EPSharedExternal.eplGeoE_CalcHorzDistBtwnTwoPnts(_FirstPnt, _SecondPnt, ref _dDistance, 1E-05);
  }

  public static int eplGeoE_CalcHorzDistBtwnTwoPnts(
    Eps_Point _FirstPnt,
    Eps_Point _SecondPnt,
    ref double _dDistance,
    double _dMinDist)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstPnt));
    Marshal.StructureToPtr<Eps_Point>(_FirstPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondPnt));
    Marshal.StructureToPtr<Eps_Point>(_SecondPnt, num2, true);
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CalcHorzDistBtwnTwoPnts(num1, num2, ref _dDistance, _dMinDist) : EPSharedExternal.Externalx86.eplDLLGeoE_CalcHorzDistBtwnTwoPnts(num1, num2, ref _dDistance, _dMinDist);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static void eplGeoE_CalcPolarToXY(
    Eps_Point _StartPnt,
    double _dPolarDirection,
    double _dPolarDistance,
    ref Eps_Point _NewPnt)
  {
    _NewPnt = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_StartPnt));
    Marshal.StructureToPtr<Eps_Point>(_StartPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_NewPnt));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcPolarToXY(num1, _dPolarDirection, _dPolarDistance, num2);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcPolarToXY(num1, _dPolarDirection, _dPolarDistance, num2);
    Marshal.PtrToStructure<Eps_Point>(num2, _NewPnt);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static void eplGeoE_FindStaOffPointAlongArc(
    Eps_Arc _Arc,
    double _dStation,
    double _dOffset,
    ref Eps_Point _StaOffPnt)
  {
    _StaOffPnt = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_StaOffPnt));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_FindStaOffPointAlongArc(num1, _dStation, _dOffset, num2);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_FindStaOffPointAlongArc(num1, _dStation, _dOffset, num2);
    Marshal.PtrToStructure<Eps_Point>(num2, _StaOffPnt);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static void eplGeoE_FindStaOffPointAlongLine(
    Eps_Line _Line,
    double _dStation,
    double _dOffset,
    ref Eps_Point _StaOffPnt)
  {
    _StaOffPnt = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _Line));
    Marshal.StructureToPtr<Eps_Line>(_Line, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_StaOffPnt));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_FindStaOffPointAlongLine(num1, _dStation, _dOffset, num2);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_FindStaOffPointAlongLine(num1, _dStation, _dOffset, num2);
    Marshal.PtrToStructure<Eps_Point>(num2, _StaOffPnt);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static void eplGeoE_CalcTangentDirOfArc(
    Eps_Point _ArcPnt,
    Eps_Point _RadiusPnt,
    int _nArcDirection,
    ref double _dTangentDir)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_ArcPnt));
    Marshal.StructureToPtr<Eps_Point>(_ArcPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_RadiusPnt));
    Marshal.StructureToPtr<Eps_Point>(_RadiusPnt, num2, true);
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcTangentDirOfArc(num1, num2, _nArcDirection, ref _dTangentDir);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcTangentDirOfArc(num1, num2, _nArcDirection, ref _dTangentDir);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static int eplGeoE_CalcStationOffsetAlongLine(
    Eps_Point _Point,
    Eps_Line _Line,
    ref double _dStation,
    ref double _dOffset,
    double _dStaTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Point));
    Marshal.StructureToPtr<Eps_Point>(_Point, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _Line));
    Marshal.StructureToPtr<Eps_Line>(_Line, num2, true);
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CalcStationOffsetAlongLine(num1, num2, ref _dStation, ref _dOffset, _dStaTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_CalcStationOffsetAlongLine(num1, num2, ref _dStation, ref _dOffset, _dStaTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static int eplGeoE_CalcStationOffsetAlongArc(
    Eps_Point _Point,
    Eps_Arc _Arc,
    ref double _dStation,
    ref double _dOffset)
  {
    return EPSharedExternal.eplGeoE_CalcStationOffsetAlongArc(_Point, _Arc, ref _dStation, ref _dOffset, 1E-05);
  }

  public static int eplGeoE_CalcStationOffsetAlongArc(
    Eps_Point _Point,
    Eps_Arc _Arc,
    ref double _dStation,
    ref double _dOffset,
    double _dStaTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Point));
    Marshal.StructureToPtr<Eps_Point>(_Point, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num2, true);
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CalcStationOffsetAlongArc(num1, num2, ref _dStation, ref _dOffset, _dStaTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_CalcStationOffsetAlongArc(num1, num2, ref _dStation, ref _dOffset, _dStaTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static double eplGeoE_SolveArcLenByRadiusAndDelta(double _Radius, double _DeltaAngle)
  {
    double dReturnValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_SolveArcLenByRadiusAndDelta(_Radius, _DeltaAngle, ref dReturnValue);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_SolveArcLenByRadiusAndDelta(_Radius, _DeltaAngle, ref dReturnValue);
    return dReturnValue;
  }

  public static int eplGeoE_ConstructOffsetArc(
    Eps_Arc _OrigArc,
    double _dOffsetDist,
    int _nOffsetDir,
    ref Eps_Arc _OffsetArc)
  {
    _OffsetArc = new Eps_Arc();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _OrigArc));
    Marshal.StructureToPtr<Eps_Arc>(_OrigArc, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _OffsetArc));
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_ConstructOffsetArc(num1, _dOffsetDist, _nOffsetDir, num2) : EPSharedExternal.Externalx86.eplDLLGeoE_ConstructOffsetArc(num1, _dOffsetDist, _nOffsetDir, num2);
    BaseArc baseArc = new BaseArc();
    Marshal.PtrToStructure<BaseArc>(num2, baseArc);
    _OffsetArc = new Eps_Arc(baseArc);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static int eplGeoE_ConstructOffsetLine(
    Eps_Line _OrigLine,
    double _dOffsetDist,
    int _nOffsetDir,
    ref Eps_Line _OffsetLine)
  {
    _OffsetLine = new Eps_Line();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _OrigLine));
    Marshal.StructureToPtr<Eps_Line>(_OrigLine, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _OffsetLine));
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_ConstructOffsetLine(num1, _dOffsetDist, _nOffsetDir, num2) : EPSharedExternal.Externalx86.eplDLLGeoE_ConstructOffsetLine(num1, _dOffsetDist, _nOffsetDir, num2);
    BaseLine baseLine = new BaseLine();
    Marshal.PtrToStructure<BaseLine>(num2, baseLine);
    _OffsetLine = new Eps_Line(baseLine);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static int eplGeoE_CalcMidPointBetweenTwoPoints(
    Eps_Point _FirstPoint,
    Eps_Point _SecondPoint,
    ref Eps_Point _MidPoint)
  {
    _MidPoint = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstPoint));
    Marshal.StructureToPtr<Eps_Point>(_FirstPoint, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondPoint));
    Marshal.StructureToPtr<Eps_Point>(_SecondPoint, num2, true);
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_MidPoint));
    int num4 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CalcMidPointBetweenTwoPoints(num1, num2, num3) : EPSharedExternal.Externalx86.eplDLLGeoE_CalcMidPointBetweenTwoPoints(num1, num2, num3);
    Marshal.PtrToStructure<Eps_Point>(num3, _MidPoint);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    Marshal.FreeHGlobal(num3);
    return num4;
  }

  public static int eplGeoE_IntersectTwoDirs2D(
    Eps_Point _FirstPnt,
    double _dFirstDir,
    Eps_Point _SecondPnt,
    double _dSecondDir,
    ref Eps_Point _InterPnt,
    double _dTolerance)
  {
    _InterPnt = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstPnt));
    Marshal.StructureToPtr<Eps_Point>(_FirstPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondPnt));
    Marshal.StructureToPtr<Eps_Point>(_SecondPnt, num2, true);
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_InterPnt));
    int num4 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_IntersectTwoDirs2D(num1, _dFirstDir, num2, _dSecondDir, num3, _dTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_IntersectTwoDirs2D(num1, _dFirstDir, num2, _dSecondDir, num3, _dTolerance);
    Marshal.PtrToStructure<Eps_Point>(num3, _InterPnt);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    Marshal.FreeHGlobal(num3);
    return num4;
  }

  public static bool eplGeoE_ArePntsDuplicates3D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt)
  {
    return EPSharedExternal.eplGeoE_ArePntsDuplicates3D(_FirstCheckPnt, _SecondCheckPnt, 1E-05);
  }

  public static bool eplGeoE_ArePntsDuplicates3D(
    Eps_Point _FirstCheckPnt,
    Eps_Point _SecondCheckPnt,
    double _dTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstCheckPnt));
    Marshal.StructureToPtr<Eps_Point>(_FirstCheckPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondCheckPnt));
    Marshal.StructureToPtr<Eps_Point>(_SecondCheckPnt, num2, true);
    bool flag = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_ArePntsDuplicates3D(num1, num2, _dTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_ArePntsDuplicates3D(num1, num2, _dTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return flag;
  }

  public static void eplGeoE_CalcArcStructFromPCAndPTAndRP(
    Eps_Point _PntOfArc,
    Eps_Point _RadiusPoint,
    Eps_Point _PntOfTangency,
    int _nDirection,
    ref Eps_Arc _ArcStruct)
  {
    _ArcStruct = new Eps_Arc();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_PntOfArc));
    Marshal.StructureToPtr<Eps_Point>(_PntOfArc, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_RadiusPoint));
    Marshal.StructureToPtr<Eps_Point>(_RadiusPoint, num2, true);
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_PntOfTangency));
    Marshal.StructureToPtr<Eps_Point>(_PntOfTangency, num3, true);
    IntPtr num4 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _ArcStruct));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcArcStructFromPCAndPTAndRP(num1, num2, num3, _nDirection, num4);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcArcStructFromPCAndPTAndRP(num1, num2, num3, _nDirection, num4);
    BaseArc baseArc = new BaseArc();
    Marshal.PtrToStructure<BaseArc>(num4, baseArc);
    _ArcStruct = new Eps_Arc(baseArc);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    Marshal.FreeHGlobal(num3);
    Marshal.FreeHGlobal(num4);
  }

  public static void eplGeoE_FindMinMaxOfArc(
    Eps_Arc _Arc,
    ref Eps_Point _MinPnt,
    ref Eps_Point _MaxPnt)
  {
    _MinPnt = new Eps_Point();
    _MaxPnt = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_MinPnt));
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_MaxPnt));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_FindMinMaxOfArc(num1, num2, num3);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_FindMinMaxOfArc(num1, num2, num3);
    Marshal.PtrToStructure<Eps_Point>(num2, _MinPnt);
    Marshal.PtrToStructure<Eps_Point>(num3, _MaxPnt);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num3);
    Marshal.FreeHGlobal(num2);
  }

  public static bool eplGeoE_IsPointOnArc2D(
    Eps_Point _Point,
    Eps_Arc _Arc,
    double _dPointTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Point));
    Marshal.StructureToPtr<Eps_Point>(_Point, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num2, true);
    bool flag = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_IsPointOnArc2D(num1, num2, _dPointTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_IsPointOnArc2D(num1, num2, _dPointTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return flag;
  }

  public static bool eplGeoE_IsPointOnLine2D(
    Eps_Point _Point,
    Eps_Line _Line,
    double _dPointTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Point));
    Marshal.StructureToPtr<Eps_Point>(_Point, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _Line));
    Marshal.StructureToPtr<Eps_Line>(_Line, num2, true);
    bool flag = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_IsPointOnLine2D(num1, num2, _dPointTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_IsPointOnLine2D(num1, num2, _dPointTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return flag;
  }

  public static bool eplGeoE_DoBoundingBoxesOverlap(
    Eps_Line _LineOne,
    Eps_Line _LineTwo,
    double _dPointTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _LineOne));
    Marshal.StructureToPtr<Eps_Line>(_LineOne, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _LineTwo));
    Marshal.StructureToPtr<Eps_Line>(_LineTwo, num2, true);
    bool flag = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_DoBoundingBoxesOverlap(num1, num2, _dPointTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_DoBoundingBoxesOverlap(num1, num2, _dPointTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return flag;
  }

  public static double eplGeoE_CalcPlaneDistBtwnTwoPnts(
    double _dFirstPntRightLeft,
    double _dFirstPntUpDown,
    double _dSecondPntRightLeft,
    double _dSecondPntUpDown)
  {
    double dReturnValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcPlaneDistBtwnTwoPnts(_dFirstPntRightLeft, _dFirstPntUpDown, _dSecondPntRightLeft, _dSecondPntUpDown, ref dReturnValue);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcPlaneDistBtwnTwoPnts(_dFirstPntRightLeft, _dFirstPntUpDown, _dSecondPntRightLeft, _dSecondPntUpDown, ref dReturnValue);
    return dReturnValue;
  }

  public static void eplGeoE_MakeVector(
    Eps_Point _InitialPnt,
    Eps_Point _FinalPnt,
    ref Eps_Point _Vector)
  {
    _Vector = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_InitialPnt));
    Marshal.StructureToPtr<Eps_Point>(_InitialPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FinalPnt));
    Marshal.StructureToPtr<Eps_Point>(_FinalPnt, num2, true);
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Vector));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_MakeVector(num1, num2, num3);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_MakeVector(num1, num2, num3);
    Marshal.PtrToStructure<Eps_Point>(num3, _Vector);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    Marshal.FreeHGlobal(num3);
  }

  public static int eplGeoE_CheckIfLineInsideLine(
    Eps_Line _LineOne,
    Eps_Line _LineTwo,
    double _dPointTolerance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _LineOne));
    Marshal.StructureToPtr<Eps_Line>(_LineOne, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<BaseLine>((BaseLine) _LineTwo));
    Marshal.StructureToPtr<Eps_Line>(_LineTwo, num2, true);
    int num3 = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_CheckIfLineInsideLine(num1, num2, _dPointTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_CheckIfLineInsideLine(num1, num2, _dPointTolerance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return num3;
  }

  public static int eplGeoE_SolveDeltaByChordLenAndRadius(
    double _dChordLength,
    double _dRadius,
    ref double _dDeltaAngle)
  {
    return !ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx86.eplDLLGeoE_SolveDeltaByChordLenAndRadius(_dChordLength, _dRadius, ref _dDeltaAngle) : EPSharedExternal.Externalx64.eplDLLGeoE_SolveDeltaByChordLenAndRadius(_dChordLength, _dRadius, ref _dDeltaAngle);
  }

  public static double eplGeoE_SolveTanLenByRadiusAndDelta(double _dRadius, double _dDeltaAngle)
  {
    double dReturnValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_SolveTanLenByRadiusAndDelta(_dRadius, _dDeltaAngle, ref dReturnValue);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_SolveTanLenByRadiusAndDelta(_dRadius, _dDeltaAngle, ref dReturnValue);
    return dReturnValue;
  }

  public static void eplGeoE_CalcRadiusPointFromPCAndPIAndPT(
    Eps_Point _PntOfCurve,
    Eps_Point _PntOfInter,
    Eps_Point _PntOfTangency,
    ref Eps_Point _RadiusPoint)
  {
    _RadiusPoint = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_PntOfCurve));
    Marshal.StructureToPtr<Eps_Point>(_PntOfCurve, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_PntOfInter));
    Marshal.StructureToPtr<Eps_Point>(_PntOfInter, num2, true);
    IntPtr num3 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_PntOfTangency));
    Marshal.StructureToPtr<Eps_Point>(_PntOfTangency, num3, true);
    IntPtr num4 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_RadiusPoint));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcRadiusPointFromPCAndPIAndPT(num1, num2, num3, num4);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcRadiusPointFromPCAndPIAndPT(num1, num2, num3, num4);
    Marshal.PtrToStructure<Eps_Point>(num4, _RadiusPoint);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    Marshal.FreeHGlobal(num3);
    Marshal.FreeHGlobal(num4);
  }

  public static void eplGeoE_RotatePoint(
    ref Eps_Point _Point,
    Eps_Point _ReferencePoint,
    double _dRotation)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_ReferencePoint));
    Marshal.StructureToPtr<Eps_Point>(_ReferencePoint, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_Point));
    Marshal.StructureToPtr<Eps_Point>(_Point, num2, false);
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_RotatePoint(num2, num1, _dRotation);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_RotatePoint(num2, num1, _dRotation);
    Marshal.PtrToStructure<Eps_Point>(num2, _Point);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static void eplGeoE_CalcPolarToXYZ(
    Eps_Point _StartPnt,
    double _dHorzPolarDirection,
    double _dVertPolarDirection,
    double _dPolarSlopeDistance,
    ref Eps_Point _NewPnt)
  {
    _NewPnt = new Eps_Point();
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_StartPnt));
    Marshal.StructureToPtr<Eps_Point>(_StartPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_NewPnt));
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcPolarToXYZ(num1, _dHorzPolarDirection, _dVertPolarDirection, _dPolarSlopeDistance, num2);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcPolarToXYZ(num1, _dHorzPolarDirection, _dVertPolarDirection, _dPolarSlopeDistance, num2);
    Marshal.PtrToStructure<Eps_Point>(num2, _NewPnt);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static void eplGeoE_CalcXYZToPolar(
    Eps_Point _StartPnt,
    Eps_Point _EndPnt,
    ref double _dHorzPolarDirection,
    ref double _dVertPolarDirection,
    ref double _dPolarSlopeDistance)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_StartPnt));
    Marshal.StructureToPtr<Eps_Point>(_StartPnt, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_EndPnt));
    Marshal.StructureToPtr<Eps_Point>(_EndPnt, num2, true);
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcXYZToPolar(num1, num2, ref _dHorzPolarDirection, ref _dVertPolarDirection, ref _dPolarSlopeDistance);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcXYZToPolar(num1, num2, ref _dHorzPolarDirection, ref _dVertPolarDirection, ref _dPolarSlopeDistance);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
  }

  public static void eplFilP_SetRegAppProgramKey(string _strKey)
  {
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLFilP_SetRegAppProgramKey(_strKey);
    else
      EPSharedExternal.Externalx64.eplDLLFilP_SetRegAppProgramKey(_strKey);
  }

  public static int eplFilP_GetSupportPath(string _strFileName, ref string _strSupportPath)
  {
    StringBuilder _SupportPath = new StringBuilder((int) short.MaxValue);
    int supportPath = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLFilP_GetSupportPath(_strFileName, _SupportPath) : EPSharedExternal.Externalx86.eplDLLFilP_GetSupportPath(_strFileName, _SupportPath);
    _strSupportPath = _SupportPath.ToString();
    return supportPath;
  }

  public static void eplGeoE_CalcTangentInDirOfArc(Eps_Arc _Arc, ref double _dTangentInDir)
  {
    IntPtr num = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num, true);
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcTangentInDirOfArc(num, ref _dTangentInDir);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcTangentInDirOfArc(num, ref _dTangentInDir);
    Marshal.FreeHGlobal(num);
  }

  public static void eplGeoE_CalcTangentOutDirOfArc(Eps_Arc _Arc, ref double _dTangentOutDir)
  {
    IntPtr num = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num, true);
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcTangentOutDirOfArc(num, ref _dTangentOutDir);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcTangentOutDirOfArc(num, ref _dTangentOutDir);
    Marshal.FreeHGlobal(num);
  }

  public static void eplGeoE_CalcArcChordArea(Eps_Arc _Arc, ref double _dChordArea)
  {
    IntPtr num = Marshal.AllocHGlobal(Marshal.SizeOf<BaseArc>((BaseArc) _Arc));
    Marshal.StructureToPtr<Eps_Arc>(_Arc, num, true);
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLGeoE_CalcArcChordArea(num, ref _dChordArea);
    else
      EPSharedExternal.Externalx64.eplDLLGeoE_CalcArcChordArea(num, ref _dChordArea);
    Marshal.FreeHGlobal(num);
  }

  public static bool eplGeoE_IsLegListInsideLegList(
    Eps_Line[] _aTestLines,
    int _nTestLineCount,
    Eps_Arc[] _aTestArcs,
    int _nTestArcCount,
    int[] _aTestLegOrder,
    Eps_Line[] _aLines,
    int _nLineCount,
    Eps_Arc[] _aArcs,
    int _nArcCount,
    int[] _aLegOrder,
    double _dTolerance)
  {
    IntPtr num1 = IntPtr.Zero;
    IntPtr zero1 = IntPtr.Zero;
    IntPtr ptr1;
    if (_aTestLines != null)
    {
      num1 = Marshal.AllocHGlobal(_nTestLineCount * 2 * Marshal.SizeOf(typeof (BaseLine)));
      ptr1 = num1;
      for (int index = 0; index < _nTestLineCount; ++index)
      {
        Marshal.StructureToPtr<BaseLine>((BaseLine) _aTestLines[index], ptr1, true);
        ptr1 = new IntPtr(ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
      }
    }
    IntPtr num2 = IntPtr.Zero;
    IntPtr zero2 = IntPtr.Zero;
    IntPtr ptr2;
    if (_aTestArcs != null)
    {
      num2 = Marshal.AllocHGlobal(_nTestArcCount * 2 * Marshal.SizeOf(typeof (BaseArc)));
      ptr2 = num2;
      for (int index = 0; index < _nTestArcCount; ++index)
      {
        Marshal.StructureToPtr<BaseArc>((BaseArc) _aTestArcs[index], ptr2, true);
        ptr2 = new IntPtr(ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
      }
    }
    IntPtr num3 = IntPtr.Zero;
    IntPtr zero3 = IntPtr.Zero;
    IntPtr ptr3;
    if (_aTestLegOrder != null)
    {
      num3 = Marshal.AllocHGlobal((_nTestLineCount + _nTestArcCount) * 2 * Marshal.SizeOf(typeof (int)));
      ptr3 = num3;
      for (int index = 0; index < _nTestLineCount + _nTestArcCount; ++index)
      {
        Marshal.StructureToPtr<int>(_aTestLegOrder[index], ptr3, true);
        ptr3 = new IntPtr(ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
      }
    }
    IntPtr num4 = IntPtr.Zero;
    IntPtr zero4 = IntPtr.Zero;
    IntPtr ptr4;
    if (_aLines != null)
    {
      num4 = Marshal.AllocHGlobal(_nLineCount * 2 * Marshal.SizeOf(typeof (BaseLine)));
      ptr4 = num4;
      for (int index = 0; index < _nLineCount; ++index)
      {
        Marshal.StructureToPtr<BaseLine>((BaseLine) _aLines[index], ptr4, true);
        ptr4 = new IntPtr(ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
      }
    }
    IntPtr num5 = IntPtr.Zero;
    IntPtr zero5 = IntPtr.Zero;
    IntPtr ptr5;
    if (_aArcs != null)
    {
      num5 = Marshal.AllocHGlobal(_nArcCount * 2 * Marshal.SizeOf(typeof (BaseArc)));
      ptr5 = num5;
      for (int index = 0; index < _nArcCount; ++index)
      {
        Marshal.StructureToPtr<BaseArc>((BaseArc) _aArcs[index], ptr5, true);
        ptr5 = new IntPtr(ptr5.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
      }
    }
    IntPtr num6 = IntPtr.Zero;
    IntPtr zero6 = IntPtr.Zero;
    IntPtr ptr6;
    if (_aLegOrder != null)
    {
      num6 = Marshal.AllocHGlobal((_nLineCount + _nArcCount) * 2 * Marshal.SizeOf(typeof (int)));
      ptr6 = num6;
      for (int index = 0; index < _nLineCount + _nArcCount; ++index)
      {
        Marshal.StructureToPtr<int>(_aLegOrder[index], ptr6, true);
        ptr6 = new IntPtr(ptr6.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
      }
    }
    bool flag = ApplicationUtility.Is64BitInstall ? EPSharedExternal.Externalx64.eplDLLGeoE_IsLegListInsideLegList(num1, _nTestLineCount, num2, _nTestArcCount, num3, num4, _nLineCount, num5, _nArcCount, num6, _dTolerance) : EPSharedExternal.Externalx86.eplDLLGeoE_IsLegListInsideLegList(num1, _nTestLineCount, num2, _nTestArcCount, num3, num4, _nLineCount, num5, _nArcCount, num6, _dTolerance);
    ptr1 = num1;
    for (int index = 0; index < _nTestLineCount; ++index)
    {
      Marshal.DestroyStructure(ptr1, typeof (BaseLine));
      ptr1 = (IntPtr) (ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (num1 != IntPtr.Zero)
      Marshal.FreeHGlobal(num1);
    ptr2 = num2;
    for (int index = 0; index < _nTestArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr2, typeof (BaseArc));
      ptr2 = (IntPtr) (ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
    }
    if (num2 != IntPtr.Zero)
      Marshal.FreeHGlobal(num2);
    ptr3 = num3;
    for (int index = 0; index < _nTestLineCount + _nTestArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr3, typeof (int));
      ptr3 = (IntPtr) (ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
    }
    if (num3 != IntPtr.Zero)
      Marshal.FreeHGlobal(num3);
    ptr4 = num4;
    for (int index = 0; index < _nLineCount; ++index)
    {
      Marshal.DestroyStructure(ptr4, typeof (BaseLine));
      ptr4 = (IntPtr) (ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (num4 != IntPtr.Zero)
      Marshal.FreeHGlobal(num4);
    ptr5 = num5;
    for (int index = 0; index < _nArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr5, typeof (BaseArc));
      ptr5 = (IntPtr) (ptr5.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
    }
    if (num5 != IntPtr.Zero)
      Marshal.FreeHGlobal(num5);
    ptr6 = num6;
    for (int index = 0; index < _nLineCount + _nArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr6, typeof (int));
      ptr6 = (IntPtr) (ptr6.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
    }
    if (num6 != IntPtr.Zero)
      Marshal.FreeHGlobal(num6);
    return flag;
  }

  public static double eplCalE_fmod(double _dFirstOperand, double _dSecondOperand)
  {
    return EPSharedExternal.eplCalE_fmod(_dFirstOperand, _dSecondOperand, 1E-05);
  }

  public static double eplCalE_fmod(
    double _dFirstOperand,
    double _dSecondOperand,
    double _dTolerance)
  {
    double _dReturnValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLCalE_fmod(_dFirstOperand, _dSecondOperand, _dTolerance, ref _dReturnValue);
    else
      EPSharedExternal.Externalx64.eplDLLCalE_fmod(_dFirstOperand, _dSecondOperand, _dTolerance, ref _dReturnValue);
    return _dReturnValue;
  }

  public static double eplCalE_RoundValue(double _dValue, int _nPrecision)
  {
    double _dRoundedValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLCalE_RoundValue(_dValue, _nPrecision, ref _dRoundedValue);
    else
      EPSharedExternal.Externalx64.eplDLLCalE_RoundValue(_dValue, _nPrecision, ref _dRoundedValue);
    return _dRoundedValue;
  }

  public static double eplCalE_CalcComponentKOfCrossProduct(
    Eps_Point _FirstPoint,
    Eps_Point _SecondPoint)
  {
    IntPtr num1 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_FirstPoint));
    Marshal.StructureToPtr<Eps_Point>(_FirstPoint, num1, true);
    IntPtr num2 = Marshal.AllocHGlobal(Marshal.SizeOf<Eps_Point>(_SecondPoint));
    Marshal.StructureToPtr<Eps_Point>(_SecondPoint, num2, true);
    double _dReturnValue = 0.0;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLLCalE_CalcComponentKOfCrossProduct(num1, num2, ref _dReturnValue);
    else
      EPSharedExternal.Externalx64.eplDLLCalE_CalcComponentKOfCrossProduct(num1, num2, ref _dReturnValue);
    Marshal.FreeHGlobal(num1);
    Marshal.FreeHGlobal(num2);
    return _dReturnValue;
  }

  public static void epl_SetRevitVersion(RevitVersion _RevitVersion)
  {
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.eplDLL_SetRevitVersion(_RevitVersion.GetHashCode());
    else
      EPSharedExternal.Externalx64.eplDLL_SetRevitVersion(_RevitVersion.GetHashCode());
  }

  public static void epl_UnloadHelper(bool _bIs64BitInstall)
  {
    int num = _bIs64BitInstall ? 1 : 0;
  }

  public static void CreateCatchLinesAndFeatureLinesFromTopo(
    string _strFileName,
    Eps_Line[] _aLines,
    int _nLineCount,
    Eps_Arc[] _aArcs,
    int _nArcCount,
    int[] _aLegOrder,
    Eps_Point[] _aPnts,
    int _nPointCount,
    double _dLinearInterval,
    double _dRadialInterval,
    double _dArcPointInterval,
    double _dCutSlope,
    double _dFillSlope,
    bool _bProjectLeft,
    ref Eps_Line[] _aCatchLines,
    ref int _nNumCatchLines,
    ref Eps_Line[] _aFeatureLines,
    ref int _nNumFeatureLines)
  {
    IntPtr num1 = IntPtr.Zero;
    IntPtr zero1 = IntPtr.Zero;
    IntPtr ptr1;
    if (_aLines != null)
    {
      num1 = Marshal.AllocHGlobal(_nLineCount * 2 * Marshal.SizeOf(typeof (BaseLine)));
      ptr1 = num1;
      for (int index = 0; index < _nLineCount; ++index)
      {
        Marshal.StructureToPtr<BaseLine>((BaseLine) _aLines[index], ptr1, true);
        ptr1 = new IntPtr(ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
      }
    }
    IntPtr num2 = IntPtr.Zero;
    IntPtr zero2 = IntPtr.Zero;
    IntPtr ptr2;
    if (_aArcs != null)
    {
      num2 = Marshal.AllocHGlobal(_nArcCount * 2 * Marshal.SizeOf(typeof (BaseArc)));
      ptr2 = num2;
      for (int index = 0; index < _nArcCount; ++index)
      {
        Marshal.StructureToPtr<BaseArc>((BaseArc) _aArcs[index], ptr2, true);
        ptr2 = new IntPtr(ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
      }
    }
    IntPtr num3 = IntPtr.Zero;
    IntPtr zero3 = IntPtr.Zero;
    IntPtr ptr3;
    if (_aLegOrder != null)
    {
      num3 = Marshal.AllocHGlobal((_nLineCount + _nArcCount) * 2 * Marshal.SizeOf(typeof (int)));
      ptr3 = num3;
      for (int index = 0; index < _nLineCount + _nArcCount; ++index)
      {
        Marshal.StructureToPtr<int>(_aLegOrder[index], ptr3, true);
        ptr3 = new IntPtr(ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
      }
    }
    IntPtr num4 = IntPtr.Zero;
    IntPtr zero4 = IntPtr.Zero;
    IntPtr ptr4;
    if (_aPnts != null)
    {
      num4 = Marshal.AllocHGlobal(_nPointCount * 2 * Marshal.SizeOf(typeof (Eps_Point)));
      ptr4 = num4;
      for (int index = 0; index < _nPointCount; ++index)
      {
        Marshal.StructureToPtr<Eps_Point>(_aPnts[index], ptr4, true);
        ptr4 = new IntPtr(ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
      }
    }
    IntPtr zero5 = IntPtr.Zero;
    IntPtr zero6 = IntPtr.Zero;
    IntPtr zero7 = IntPtr.Zero;
    IntPtr zero8 = IntPtr.Zero;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.epl_CreateCatchLinesAndFeatureLinesFromTopo(_strFileName, num1, _nLineCount, num2, _nArcCount, num3, num4, _nPointCount, _dLinearInterval, _dRadialInterval, _dArcPointInterval, _dCutSlope, _dFillSlope, _bProjectLeft, ref zero5, ref _nNumCatchLines, ref zero7, ref _nNumFeatureLines);
    else
      EPSharedExternal.Externalx64.epl_CreateCatchLinesAndFeatureLinesFromTopo(_strFileName, num1, _nLineCount, num2, _nArcCount, num3, num4, _nPointCount, _dLinearInterval, _dRadialInterval, _dArcPointInterval, _dCutSlope, _dFillSlope, _bProjectLeft, ref zero5, ref _nNumCatchLines, ref zero7, ref _nNumFeatureLines);
    _aCatchLines = new Eps_Line[_nNumCatchLines];
    IntPtr ptr5 = zero5;
    for (int index = 0; index < _nNumCatchLines; ++index)
    {
      _aCatchLines[index] = new Eps_Line((BaseLine) Marshal.PtrToStructure(ptr5, typeof (BaseLine)));
      Marshal.DestroyStructure(ptr5, typeof (BaseLine));
      ptr5 = (IntPtr) (ptr5.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (zero5 != IntPtr.Zero)
      Marshal.DestroyStructure(zero5, typeof (BaseLine));
    _aFeatureLines = new Eps_Line[_nNumFeatureLines];
    IntPtr ptr6 = zero7;
    for (int index = 0; index < _nNumFeatureLines; ++index)
    {
      _aFeatureLines[index] = new Eps_Line((BaseLine) Marshal.PtrToStructure(ptr6, typeof (BaseLine)));
      Marshal.DestroyStructure(ptr6, typeof (BaseLine));
      ptr6 = (IntPtr) (ptr6.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (zero7 != IntPtr.Zero)
      Marshal.DestroyStructure(zero7, typeof (BaseLine));
    ptr1 = num1;
    for (int index = 0; index < _nLineCount; ++index)
    {
      Marshal.DestroyStructure(ptr1, typeof (BaseLine));
      ptr1 = (IntPtr) (ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (num1 != IntPtr.Zero)
      Marshal.FreeHGlobal(num1);
    ptr2 = num2;
    for (int index = 0; index < _nArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr2, typeof (BaseArc));
      ptr2 = (IntPtr) (ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
    }
    if (num2 != IntPtr.Zero)
      Marshal.FreeHGlobal(num2);
    ptr3 = num3;
    for (int index = 0; index < _nLineCount + _nArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr3, typeof (int));
      ptr3 = (IntPtr) (ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
    }
    if (num3 != IntPtr.Zero)
      Marshal.FreeHGlobal(num3);
    ptr4 = num4;
    for (int index = 0; index < _nPointCount; ++index)
    {
      Marshal.DestroyStructure(ptr4, typeof (Eps_Point));
      ptr4 = (IntPtr) (ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (!(num4 != IntPtr.Zero))
      return;
    Marshal.FreeHGlobal(num4);
  }

  public static void CreateCutAndFillFromTopo(
    string _strFileName,
    Eps_Line[] _aLines,
    int _nLineCount,
    Eps_Arc[] _aArcs,
    int _nArcCount,
    int[] _aLegOrder,
    Eps_Point[] _aPnts,
    int _nPointCount,
    double _dLinearInterval,
    double _dRadialInterval,
    double _dArcPointInterval,
    double _dLeftOffsetWidth,
    double _dRightOffsetWidth,
    double _dBoulevardWidth,
    double _dCutSlope,
    double _dFillSlope,
    int _nProjectInnerSlopes,
    double _dSubgradeAdjustElev,
    bool _bIsCrownPresent,
    bool _bIsProjectLegToTopo,
    double _dLeftEdgeAdjustElev,
    double _dRightEdgeAdjustElev,
    double _dLeftSubgradeAdjustElev,
    double _dRightSubgradeAdjustElev,
    ref Eps_Point[] _aCutFillPoints,
    ref int _nNumCutFillPoints,
    ref Eps_Line[] _aLeftCatchLines,
    ref int _nNumLeftCatchLines,
    ref Eps_Line[] _aRightCatchLines,
    ref int _nNumRightCatchLines,
    ref Eps_Line[] _aLeftCutFillLines,
    ref int _nNumLeftCutFillLines,
    ref Eps_Line[] _aRightCutFillLines,
    ref int _nNumRightCutFillLines)
  {
    IntPtr num1 = IntPtr.Zero;
    IntPtr zero1 = IntPtr.Zero;
    IntPtr ptr1;
    if (_aLines != null)
    {
      num1 = Marshal.AllocHGlobal(_nLineCount * 2 * Marshal.SizeOf(typeof (BaseLine)));
      ptr1 = num1;
      for (int index = 0; index < _nLineCount; ++index)
      {
        Marshal.StructureToPtr<BaseLine>((BaseLine) _aLines[index], ptr1, true);
        ptr1 = new IntPtr(ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
      }
    }
    IntPtr num2 = IntPtr.Zero;
    IntPtr zero2 = IntPtr.Zero;
    IntPtr ptr2;
    if (_aArcs != null)
    {
      num2 = Marshal.AllocHGlobal(_nArcCount * 2 * Marshal.SizeOf(typeof (BaseArc)));
      ptr2 = num2;
      for (int index = 0; index < _nArcCount; ++index)
      {
        Marshal.StructureToPtr<BaseArc>((BaseArc) _aArcs[index], ptr2, true);
        ptr2 = new IntPtr(ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
      }
    }
    IntPtr num3 = IntPtr.Zero;
    IntPtr zero3 = IntPtr.Zero;
    IntPtr ptr3;
    if (_aLegOrder != null)
    {
      num3 = Marshal.AllocHGlobal((_nLineCount + _nArcCount) * 2 * Marshal.SizeOf(typeof (int)));
      ptr3 = num3;
      for (int index = 0; index < _nLineCount + _nArcCount; ++index)
      {
        Marshal.StructureToPtr<int>(_aLegOrder[index], ptr3, true);
        ptr3 = new IntPtr(ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
      }
    }
    IntPtr num4 = IntPtr.Zero;
    IntPtr zero4 = IntPtr.Zero;
    IntPtr ptr4;
    if (_aPnts != null)
    {
      num4 = Marshal.AllocHGlobal(_nPointCount * 2 * Marshal.SizeOf(typeof (Eps_Point)));
      ptr4 = num4;
      for (int index = 0; index < _nPointCount; ++index)
      {
        Marshal.StructureToPtr<Eps_Point>(_aPnts[index], ptr4, true);
        ptr4 = new IntPtr(ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
      }
    }
    IntPtr zero5 = IntPtr.Zero;
    IntPtr zero6 = IntPtr.Zero;
    IntPtr zero7 = IntPtr.Zero;
    IntPtr zero8 = IntPtr.Zero;
    IntPtr zero9 = IntPtr.Zero;
    IntPtr zero10 = IntPtr.Zero;
    IntPtr zero11 = IntPtr.Zero;
    IntPtr zero12 = IntPtr.Zero;
    IntPtr zero13 = IntPtr.Zero;
    IntPtr zero14 = IntPtr.Zero;
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.epl_CreateCutAndFillFromTopo(_strFileName, num1, _nLineCount, num2, _nArcCount, num3, num4, _nPointCount, _dLinearInterval, _dRadialInterval, _dArcPointInterval, _dLeftOffsetWidth, _dRightOffsetWidth, _dBoulevardWidth, _dCutSlope, _dFillSlope, _nProjectInnerSlopes, _dSubgradeAdjustElev, _bIsCrownPresent, _bIsProjectLegToTopo, _dLeftEdgeAdjustElev, _dRightEdgeAdjustElev, _dLeftSubgradeAdjustElev, _dRightSubgradeAdjustElev, ref zero5, ref _nNumCutFillPoints, ref zero7, ref _nNumLeftCatchLines, ref zero9, ref _nNumRightCatchLines, ref zero11, ref _nNumLeftCutFillLines, ref zero13, ref _nNumRightCutFillLines);
    else
      EPSharedExternal.Externalx64.epl_CreateCutAndFillFromTopo(_strFileName, num1, _nLineCount, num2, _nArcCount, num3, num4, _nPointCount, _dLinearInterval, _dRadialInterval, _dArcPointInterval, _dLeftOffsetWidth, _dRightOffsetWidth, _dBoulevardWidth, _dCutSlope, _dFillSlope, _nProjectInnerSlopes, _dSubgradeAdjustElev, _bIsCrownPresent, _bIsProjectLegToTopo, _dLeftEdgeAdjustElev, _dRightEdgeAdjustElev, _dLeftSubgradeAdjustElev, _dRightSubgradeAdjustElev, ref zero5, ref _nNumCutFillPoints, ref zero7, ref _nNumLeftCatchLines, ref zero9, ref _nNumRightCatchLines, ref zero11, ref _nNumLeftCutFillLines, ref zero13, ref _nNumRightCutFillLines);
    _aCutFillPoints = new Eps_Point[_nNumCutFillPoints];
    IntPtr ptr5 = zero5;
    for (int index = 0; index < _nNumCutFillPoints; ++index)
    {
      _aCutFillPoints[index] = (Eps_Point) Marshal.PtrToStructure(ptr5, typeof (Eps_Point));
      Marshal.DestroyStructure(ptr5, typeof (Eps_Point));
      ptr5 = (IntPtr) (ptr5.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (zero5 != IntPtr.Zero)
      Marshal.DestroyStructure(zero5, typeof (Eps_Point));
    _aLeftCatchLines = new Eps_Line[_nNumLeftCatchLines];
    IntPtr ptr6 = zero7;
    for (int index = 0; index < _nNumLeftCatchLines; ++index)
    {
      _aLeftCatchLines[index] = new Eps_Line((BaseLine) Marshal.PtrToStructure(ptr6, typeof (BaseLine)));
      Marshal.DestroyStructure(ptr6, typeof (BaseLine));
      ptr6 = (IntPtr) (ptr6.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (zero7 != IntPtr.Zero)
      Marshal.DestroyStructure(zero7, typeof (BaseLine));
    _aRightCatchLines = new Eps_Line[_nNumRightCatchLines];
    IntPtr ptr7 = zero9;
    for (int index = 0; index < _nNumRightCatchLines; ++index)
    {
      _aRightCatchLines[index] = new Eps_Line((BaseLine) Marshal.PtrToStructure(ptr7, typeof (BaseLine)));
      Marshal.DestroyStructure(ptr7, typeof (BaseLine));
      ptr7 = (IntPtr) (ptr7.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (zero9 != IntPtr.Zero)
      Marshal.DestroyStructure(zero9, typeof (BaseLine));
    _aLeftCutFillLines = new Eps_Line[_nNumLeftCutFillLines];
    IntPtr ptr8 = zero11;
    for (int index = 0; index < _nNumLeftCutFillLines; ++index)
    {
      _aLeftCutFillLines[index] = new Eps_Line((BaseLine) Marshal.PtrToStructure(ptr8, typeof (BaseLine)));
      Marshal.DestroyStructure(ptr8, typeof (BaseLine));
      ptr8 = (IntPtr) (ptr8.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (zero11 != IntPtr.Zero)
      Marshal.DestroyStructure(zero11, typeof (BaseLine));
    _aRightCutFillLines = new Eps_Line[_nNumRightCutFillLines];
    IntPtr ptr9 = zero13;
    for (int index = 0; index < _nNumRightCutFillLines; ++index)
    {
      _aRightCutFillLines[index] = new Eps_Line((BaseLine) Marshal.PtrToStructure(ptr9, typeof (BaseLine)));
      Marshal.DestroyStructure(ptr9, typeof (BaseLine));
      ptr9 = (IntPtr) (ptr9.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (zero13 != IntPtr.Zero)
      Marshal.DestroyStructure(zero13, typeof (BaseLine));
    ptr1 = num1;
    for (int index = 0; index < _nLineCount; ++index)
    {
      Marshal.DestroyStructure(ptr1, typeof (BaseLine));
      ptr1 = (IntPtr) (ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (BaseLine)));
    }
    if (num1 != IntPtr.Zero)
      Marshal.FreeHGlobal(num1);
    ptr2 = num2;
    for (int index = 0; index < _nArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr2, typeof (BaseArc));
      ptr2 = (IntPtr) (ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (BaseArc)));
    }
    if (num2 != IntPtr.Zero)
      Marshal.FreeHGlobal(num2);
    ptr3 = num3;
    for (int index = 0; index < _nLineCount + _nArcCount; ++index)
    {
      Marshal.DestroyStructure(ptr3, typeof (int));
      ptr3 = (IntPtr) (ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (int)));
    }
    if (num3 != IntPtr.Zero)
      Marshal.FreeHGlobal(num3);
    ptr4 = num4;
    for (int index = 0; index < _nPointCount; ++index)
    {
      Marshal.DestroyStructure(ptr4, typeof (Eps_Point));
      ptr4 = (IntPtr) (ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (!(num4 != IntPtr.Zero))
      return;
    Marshal.FreeHGlobal(num4);
  }

  public static void GenerateTrianglesFromTopo(
    string _strFileName,
    Eps_Point[] _aPnts,
    int _nPointCount,
    ref Eps_Point[] _aFirstTrianglePoints,
    ref Eps_Point[] _aSecondTrianglePoints,
    ref Eps_Point[] _aThirdTrianglePoints,
    ref int _nNumTriangles)
  {
    IntPtr num = IntPtr.Zero;
    IntPtr zero1 = IntPtr.Zero;
    IntPtr ptr1;
    if (_aPnts != null)
    {
      num = Marshal.AllocHGlobal(_nPointCount * 2 * Marshal.SizeOf(typeof (Eps_Point)));
      ptr1 = num;
      for (int index = 0; index < _nPointCount; ++index)
      {
        Marshal.StructureToPtr<Eps_Point>(_aPnts[index], ptr1, true);
        ptr1 = new IntPtr(ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
      }
    }
    IntPtr _aFirstTrianglePnts = IntPtr.Zero;
    IntPtr zero2 = IntPtr.Zero;
    IntPtr ptr2;
    if (_aFirstTrianglePoints != null)
    {
      _aFirstTrianglePnts = Marshal.AllocHGlobal(_nNumTriangles * 2 * Marshal.SizeOf(typeof (Eps_Point)));
      ptr2 = _aFirstTrianglePnts;
      for (int index = 0; index < _nNumTriangles; ++index)
      {
        Marshal.StructureToPtr<Eps_Point>(_aFirstTrianglePoints[index], ptr2, true);
        ptr2 = new IntPtr(ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
      }
    }
    IntPtr _aSecondTrianglePnts = IntPtr.Zero;
    IntPtr zero3 = IntPtr.Zero;
    IntPtr ptr3;
    if (_aSecondTrianglePoints != null)
    {
      _aSecondTrianglePnts = Marshal.AllocHGlobal(_nNumTriangles * 2 * Marshal.SizeOf(typeof (Eps_Point)));
      ptr3 = _aSecondTrianglePnts;
      for (int index = 0; index < _nNumTriangles; ++index)
      {
        Marshal.StructureToPtr<Eps_Point>(_aSecondTrianglePoints[index], ptr3, true);
        ptr3 = new IntPtr(ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
      }
    }
    IntPtr _aThirdTrianglePnts = IntPtr.Zero;
    IntPtr zero4 = IntPtr.Zero;
    IntPtr ptr4;
    if (_aThirdTrianglePoints != null)
    {
      _aThirdTrianglePnts = Marshal.AllocHGlobal(_nNumTriangles * 2 * Marshal.SizeOf(typeof (Eps_Point)));
      ptr4 = _aThirdTrianglePnts;
      for (int index = 0; index < _nNumTriangles; ++index)
      {
        Marshal.StructureToPtr<Eps_Point>(_aThirdTrianglePoints[index], ptr4, true);
        ptr4 = new IntPtr(ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
      }
    }
    if (!ApplicationUtility.Is64BitInstall)
      EPSharedExternal.Externalx86.epl_GenerateTrianglesFromTopo(_strFileName, num, _nPointCount, ref _aFirstTrianglePnts, ref _aSecondTrianglePnts, ref _aThirdTrianglePnts, ref _nNumTriangles);
    else
      EPSharedExternal.Externalx64.epl_GenerateTrianglesFromTopo(_strFileName, num, _nPointCount, ref _aFirstTrianglePnts, ref _aSecondTrianglePnts, ref _aThirdTrianglePnts, ref _nNumTriangles);
    _aFirstTrianglePoints = new Eps_Point[_nNumTriangles];
    ptr2 = _aFirstTrianglePnts;
    for (int index = 0; index < _nNumTriangles; ++index)
    {
      _aFirstTrianglePoints[index] = (Eps_Point) Marshal.PtrToStructure(ptr2, typeof (Eps_Point));
      Marshal.DestroyStructure(ptr2, typeof (Eps_Point));
      ptr2 = (IntPtr) (ptr2.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (_aFirstTrianglePnts != IntPtr.Zero)
      Marshal.DestroyStructure(_aFirstTrianglePnts, typeof (Eps_Point));
    _aSecondTrianglePoints = new Eps_Point[_nNumTriangles];
    ptr3 = _aSecondTrianglePnts;
    for (int index = 0; index < _nNumTriangles; ++index)
    {
      _aSecondTrianglePoints[index] = (Eps_Point) Marshal.PtrToStructure(ptr3, typeof (Eps_Point));
      Marshal.DestroyStructure(ptr3, typeof (Eps_Point));
      ptr3 = (IntPtr) (ptr3.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (_aSecondTrianglePnts != IntPtr.Zero)
      Marshal.DestroyStructure(_aSecondTrianglePnts, typeof (Eps_Point));
    _aThirdTrianglePoints = new Eps_Point[_nNumTriangles];
    ptr4 = _aThirdTrianglePnts;
    for (int index = 0; index < _nNumTriangles; ++index)
    {
      _aThirdTrianglePoints[index] = (Eps_Point) Marshal.PtrToStructure(ptr4, typeof (Eps_Point));
      Marshal.DestroyStructure(ptr4, typeof (Eps_Point));
      ptr4 = (IntPtr) (ptr4.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (_aThirdTrianglePnts != IntPtr.Zero)
      Marshal.DestroyStructure(_aThirdTrianglePnts, typeof (Eps_Point));
    ptr1 = num;
    for (int index = 0; index < _nPointCount; ++index)
    {
      Marshal.DestroyStructure(ptr1, typeof (Eps_Point));
      ptr1 = (IntPtr) (ptr1.ToInt64() + (long) Marshal.SizeOf(typeof (Eps_Point)));
    }
    if (!(num != IntPtr.Zero))
      return;
    Marshal.FreeHGlobal(num);
  }

  private class Externalx86
  {
    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_GetLicense();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_IsNodeLicense();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_LicenseManagement();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_IsBorrowedNetworkLicense();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_BorrowNetworkLicense();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_ReturnBorrowedLicense();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplLM_ReturnLicense();

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplDLLGeoE_ArePntsDuplicates2D(
      IntPtr _pFirstCheckPnt,
      IntPtr _pSecondCheckPnt,
      double _dTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcHorzAngByThreePnts(
      IntPtr _pStartPnt,
      IntPtr _pVertex,
      IntPtr _pEndPnt,
      int _nAngleType,
      ref double _dAngle,
      double _dPointTol);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_NormalizeRadians(double _dAngle, ref double _dReturnValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcHorzDirBtwnTwoPnts(
      IntPtr _pFirstPnt,
      IntPtr _pSecondPnt,
      ref double _dDirection,
      double _dMinDist);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcHorzDistBtwnTwoPnts(
      IntPtr _pFirstPnt,
      IntPtr _pSecondPnt,
      ref double _dDistance,
      double _dMinDist);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcPolarToXY(
      IntPtr _pStartPnt,
      double _dPolarDirection,
      double _dPolarDistance,
      IntPtr _NewPnt);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_FindStaOffPointAlongArc(
      IntPtr _pArc,
      double _dStation,
      double _dOffset,
      IntPtr _pStaOffPnt);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_FindStaOffPointAlongLine(
      IntPtr _pLine,
      double _dStation,
      double _dOffset,
      IntPtr _pStaOffPnt);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcTangentDirOfArc(
      IntPtr _pArcPnt,
      IntPtr _pRadiusPnt,
      int _nArcDirection,
      ref double _dTangentDir);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcStationOffsetAlongLine(
      IntPtr _pPoint,
      IntPtr _pLine,
      ref double _pStation,
      ref double _pOffset,
      double _dStaTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcStationOffsetAlongArc(
      IntPtr _pPoint,
      IntPtr _pArc,
      ref double _pStation,
      ref double _pOffset,
      double _dStaTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_SolveArcLenByRadiusAndDelta(
      double _dRadius,
      double _dDeltaAngle,
      ref double dReturnValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_ConstructOffsetArc(
      IntPtr _pOrigArc,
      double _dOffsetDist,
      int _nOffsetDir,
      IntPtr _OffsetArc);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_ConstructOffsetLine(
      IntPtr _pOrigLine,
      double _dOffsetDist,
      int _nOffsetDir,
      IntPtr _OffsetLine);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcMidPointBetweenTwoPoints(
      IntPtr _pFirstPoint,
      IntPtr _pSecondPoint,
      IntPtr _pMidPoint);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_IntersectTwoDirs2D(
      IntPtr _pFirstPnt,
      double _dFirstDir,
      IntPtr _pSecondPnt,
      double _dSecondDir,
      IntPtr _pInterPnt,
      double _dTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplDLLGeoE_ArePntsDuplicates3D(
      IntPtr _pFirstCheckPnt,
      IntPtr _pSecondCheckPnt,
      double _dTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcArcStructFromPCAndPTAndRP(
      IntPtr _pFirstPnt,
      IntPtr _pRadiusPoint,
      IntPtr _pPntOfTangency,
      int _nDirection,
      IntPtr _pArcStruct);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_FindMinMaxOfArc(
      IntPtr _pArc,
      IntPtr _pMinPnt,
      IntPtr _pMaxPnt);

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplDLLGeoE_IsPointOnArc2D(
      IntPtr _pPoint,
      IntPtr pArc,
      double _dPointTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplDLLGeoE_IsPointOnLine2D(
      IntPtr _pPoint,
      IntPtr pLine,
      double _dPointTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplDLLGeoE_DoBoundingBoxesOverlap(
      IntPtr _pLineOne,
      IntPtr _pLineTwo,
      double _dPointTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern double eplDLLGeoE_CalcPlaneDistBtwnTwoPnts(
      double _dFirstPntRightLeft,
      double _dFirstPntUpDown,
      double _dSecondPntRightLeft,
      double _dSecondPntUpDown,
      ref double dReturnValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_MakeVector(
      IntPtr _pInitialPnt,
      IntPtr _pFinalPnt,
      IntPtr _pVector);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CheckIfLineInsideLine(
      IntPtr _pLineOne,
      IntPtr _pLineTwo,
      double _dPointTolerance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_SolveDeltaByChordLenAndRadius(
      double _dChordLength,
      double _dRadius,
      ref double _dDeltaAngle);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_SolveTanLenByRadiusAndDelta(
      double _dRadius,
      double _dDeltaAngle,
      ref double dReturnValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcRadiusPointFromPCAndPIAndPT(
      IntPtr _pPntOfCurve,
      IntPtr _pPntOfInter,
      IntPtr _pPntOfTangency,
      IntPtr _pRadiusPoint);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_RotatePoint(
      IntPtr _pPoint,
      IntPtr _pReferencePoint,
      double _dDirection);

    [DllImport("SITESWrapperx86.dll")]
    public static extern int eplDLLGeoE_CalcVertDirBtwnTwoPnts(
      IntPtr _pFirstPnt,
      IntPtr _pSecondPnt,
      ref double _dDirection,
      double _dMinDist);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcPolarToXYZ(
      IntPtr pStartPnt,
      double _dHorzPolarDirection,
      double _dVertPolarDirection,
      double _dPolarSlopeDistance,
      IntPtr _NewPnt);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcXYZToPolar(
      IntPtr pStartPnt,
      IntPtr pEndPnt,
      ref double _dHorzPolarDirection,
      ref double _dVertPolarDirection,
      ref double _dPolarSlopeDistance);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcTangentInDirOfArc(
      IntPtr pArc,
      ref double _dTangentInDir);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcTangentOutDirOfArc(
      IntPtr pArc,
      ref double _dTangentOutDir);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLGeoE_CalcArcChordArea(IntPtr pArc, ref double _dChordArea);

    [DllImport("SITESWrapperx86.dll")]
    public static extern bool eplDLLGeoE_IsLegListInsideLegList(
      IntPtr _pTestLines,
      int _nTestLineCount,
      IntPtr _pTestArcs,
      int _nTestArcCount,
      IntPtr _pTestLegOrder,
      IntPtr _pLines,
      int _nLineCount,
      IntPtr _pArcs,
      int _nArcCount,
      IntPtr _pLegOrder,
      double _dTolerance);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern void eplDLLFilP_SetRegAppProgramKey(string _strKey);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetSupportPath(
      string _strFilename,
      StringBuilder _SupportPath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetProgramPath(
      string _strFilename,
      StringBuilder _ProgramPath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetHelpPath(string _strFilename, StringBuilder _HelpPath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetImagePath(string _strFilename, StringBuilder _ImagePath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetSymbolsPath(
      string _strFilename,
      StringBuilder _SymbolsPath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetTutorialPath(
      string _strFilename,
      StringBuilder _TutorialPath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetLibraryPath(
      string _strFilename,
      StringBuilder _LibraryPath);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetSamplePath(
      string _strFilename,
      StringBuilder _SamplePath);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLCalE_fmod(
      double _dFirstOperand,
      double _dSecondOperand,
      double _dTolerance,
      ref double _dReturnValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLCalE_RoundValue(
      double _dValue,
      int _nPrecision,
      ref double _dRoundedValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLLCalE_CalcComponentKOfCrossProduct(
      IntPtr _pFirstPoint,
      IntPtr _pSecondPoint,
      ref double _dReturnValue);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLL_SetRevitVersion(int _nRevitVersion);

    [DllImport("SITESWrapperx86.dll")]
    public static extern void eplDLL_UnloadHelper();

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Unicode)]
    public static extern void epl_CreateCatchLinesAndFeatureLinesFromTopo(
      string _strFileName,
      IntPtr _pLines,
      int _nLineCount,
      IntPtr _pArcs,
      int _nArcCount,
      IntPtr _pLegOrder,
      IntPtr _pPnts,
      int _nPointCount,
      double _dLinearInterval,
      double _dRadialInterval,
      double _dArcPointInterval,
      double _dCutSlope,
      double _dFillSlope,
      bool _bProjectLeft,
      ref IntPtr _aLeftCatchLines,
      ref int _nNumLeftCatchLines,
      ref IntPtr _aFeatureLines,
      ref int _nFeatureLines);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Unicode)]
    public static extern void epl_CreateCutAndFillFromTopo(
      string _strFileName,
      IntPtr _pLines,
      int _nLineCount,
      IntPtr _pArcs,
      int _nArcCount,
      IntPtr _pLegOrder,
      IntPtr _pPnts,
      int _nPointCount,
      double _dLinearInterval,
      double _dRadialInterval,
      double _dArcPointInterval,
      double _dLeftOffsetWidth,
      double _dRightOffsetWidth,
      double _dBoulevardWidth,
      double _dCutSlope,
      double _dFillSlope,
      int _nProjectInnerSlopes,
      double _dSubgradeAdjustElev,
      bool _bIsCrownPresent,
      bool _bIsProjectLegToTopo,
      double _dLeftEdgeAdjustElev,
      double _dRightEdgeAdjustElev,
      double _dLeftSubgradeAdjustElev,
      double _dRightSubgradeAdjustElev,
      ref IntPtr _aCutFillPoints,
      ref int _nNumCutFillPoints,
      ref IntPtr _aLeftCatchLines,
      ref int _nNumLeftCatchLines,
      ref IntPtr _aRightCatchLines,
      ref int _nNumRightCatchLines,
      ref IntPtr _aLeftCutFillLines,
      ref int _nNumLeftCutFillLines,
      ref IntPtr _aRightCutFillLines,
      ref int _nNumRightCutFillLines);

    [DllImport("SITESWrapperx86.dll", CharSet = CharSet.Unicode)]
    public static extern void epl_GenerateTrianglesFromTopo(
      string _strFileName,
      IntPtr _pPnts,
      int _nPointCount,
      ref IntPtr _aFirstTrianglePnts,
      ref IntPtr _aSecondTrianglePnts,
      ref IntPtr _aThirdTrianglePnts,
      ref int _nNumTriangles);
  }

  private class Externalx64
  {
    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_GetLicense();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_IsNodeLicense();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_LicenseManagement();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_IsBorrowedNetworkLicense();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_BorrowNetworkLicense();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_ReturnBorrowedLicense();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplLM_ReturnLicense();

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplDLLGeoE_ArePntsDuplicates2D(
      IntPtr _pFirstCheckPnt,
      IntPtr _pSecondCheckPnt,
      double _dTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcHorzAngByThreePnts(
      IntPtr _pStartPnt,
      IntPtr _pVertex,
      IntPtr _pEndPnt,
      int _nAngleType,
      ref double _dAngle,
      double _dPointTol);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_NormalizeRadians(double _dAngle, ref double _dReturnValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcHorzDirBtwnTwoPnts(
      IntPtr _pFirstPnt,
      IntPtr _pSecondPnt,
      ref double _dDirection,
      double _dMinDist);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcHorzDistBtwnTwoPnts(
      IntPtr _pFirstPnt,
      IntPtr _pSecondPnt,
      ref double _dDistance,
      double _dMinDist);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcPolarToXY(
      IntPtr _pStartPnt,
      double _dPolarDirection,
      double _dPolarDistance,
      IntPtr _NewPnt);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_FindStaOffPointAlongArc(
      IntPtr _pArc,
      double _dStation,
      double _dOffset,
      IntPtr _pStaOffPnt);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_FindStaOffPointAlongLine(
      IntPtr _pLine,
      double _dStation,
      double _dOffset,
      IntPtr _pStaOffPnt);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcTangentDirOfArc(
      IntPtr _pArcPnt,
      IntPtr _pRadiusPnt,
      int _nArcDirection,
      ref double _dTangentDir);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcStationOffsetAlongLine(
      IntPtr _pPoint,
      IntPtr _pLine,
      ref double _pStation,
      ref double _pOffset,
      double _dStaTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcStationOffsetAlongArc(
      IntPtr _pPoint,
      IntPtr _pArc,
      ref double _pStation,
      ref double _pOffset,
      double _dStaTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_SolveArcLenByRadiusAndDelta(
      double _dRadius,
      double _dDeltaAngle,
      ref double dReturnValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_ConstructOffsetArc(
      IntPtr _pOrigArc,
      double _dOffsetDist,
      int _nOffsetDir,
      IntPtr _OffsetArc);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_ConstructOffsetLine(
      IntPtr _pOrigLine,
      double _dOffsetDist,
      int _nOffsetDir,
      IntPtr _OffsetLine);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcMidPointBetweenTwoPoints(
      IntPtr _pFirstPoint,
      IntPtr _pSecondPoint,
      IntPtr _pMidPoint);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_IntersectTwoDirs2D(
      IntPtr _pFirstPnt,
      double _dFirstDir,
      IntPtr _pSecondPnt,
      double _dSecondDir,
      IntPtr _pInterPnt,
      double _dTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplDLLGeoE_ArePntsDuplicates3D(
      IntPtr _pFirstCheckPnt,
      IntPtr _pSecondCheckPnt,
      double _dTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcArcStructFromPCAndPTAndRP(
      IntPtr _pFirstPnt,
      IntPtr _pRadiusPoint,
      IntPtr _pPntOfTangency,
      int _nDirection,
      IntPtr _pArcStruct);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_FindMinMaxOfArc(
      IntPtr _pArc,
      IntPtr _pMinPnt,
      IntPtr _pMaxPnt);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplDLLGeoE_IsPointOnArc2D(
      IntPtr _pPoint,
      IntPtr pArc,
      double _dPointTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplDLLGeoE_IsPointOnLine2D(
      IntPtr _pPoint,
      IntPtr pLine,
      double _dPointTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplDLLGeoE_DoBoundingBoxesOverlap(
      IntPtr _pLineOne,
      IntPtr _pLineTwo,
      double _dPointTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern double eplDLLGeoE_CalcPlaneDistBtwnTwoPnts(
      double _dFirstPntRightLeft,
      double _dFirstPntUpDown,
      double _dSecondPntRightLeft,
      double _dSecondPntUpDown,
      ref double dReturnValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_MakeVector(
      IntPtr _pInitialPnt,
      IntPtr _pFinalPnt,
      IntPtr _pVector);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CheckIfLineInsideLine(
      IntPtr _pLineOne,
      IntPtr _pLineTwo,
      double _dPointTolerance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_SolveDeltaByChordLenAndRadius(
      double _dChordLength,
      double _dRadius,
      ref double _dDeltaAngle);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_SolveTanLenByRadiusAndDelta(
      double _dRadius,
      double _dDeltaAngle,
      ref double dReturnValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcRadiusPointFromPCAndPIAndPT(
      IntPtr _pPntOfCurve,
      IntPtr _pPntOfInter,
      IntPtr _pPntOfTangency,
      IntPtr _pRadiusPoint);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_RotatePoint(
      IntPtr _pPoint,
      IntPtr _pReferencePoint,
      double _dDirection);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern int eplDLLGeoE_CalcVertDirBtwnTwoPnts(
      IntPtr _pFirstPnt,
      IntPtr _pSecondPnt,
      ref double _dDirection,
      double _dMinDist);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcPolarToXYZ(
      IntPtr pStartPnt,
      double _dHorzPolarDirection,
      double _dVertPolarDirection,
      double _dPolarSlopeDistance,
      IntPtr _NewPnt);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcXYZToPolar(
      IntPtr pStartPnt,
      IntPtr pEndPnt,
      ref double _dHorzPolarDirection,
      ref double _dVertPolarDirection,
      ref double _dPolarSlopeDistance);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcTangentInDirOfArc(
      IntPtr pArc,
      ref double _dTangentInDir);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcTangentOutDirOfArc(
      IntPtr pArc,
      ref double _dTangentOutDir);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLGeoE_CalcArcChordArea(IntPtr pArc, ref double _dChordArea);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern bool eplDLLGeoE_IsLegListInsideLegList(
      IntPtr _pTestLines,
      int _nTestLineCount,
      IntPtr _pTestArcs,
      int _nTestArcCount,
      IntPtr _pTestLegOrder,
      IntPtr _pLines,
      int _nLineCount,
      IntPtr _pArcs,
      int _nArcCount,
      IntPtr _pLegOrder,
      double _dTolerance);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern void eplDLLFilP_SetRegAppProgramKey(string _strKey);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetSupportPath(
      string _strFilename,
      StringBuilder _SupportPath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetProgramPath(
      string _strFilename,
      StringBuilder _ProgramPath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetHelpPath(string _strFilename, StringBuilder _HelpPath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetImagePath(string _strFilename, StringBuilder _ImagePath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetSymbolsPath(
      string _strFilename,
      StringBuilder _SymbolsPath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetTutorialPath(
      string _strFilename,
      StringBuilder _TutorialPath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetLibraryPath(
      string _strFilename,
      StringBuilder _LibraryPath);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Auto)]
    public static extern int eplDLLFilP_GetSamplePath(
      string _strFilename,
      StringBuilder _SamplePath);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLCalE_fmod(
      double _dFirstOperand,
      double _dSecondOperand,
      double _dTolerance,
      ref double _dReturnValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLCalE_RoundValue(
      double _dValue,
      int _nPrecision,
      ref double _dRoundedValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLLCalE_CalcComponentKOfCrossProduct(
      IntPtr _pFirstPoint,
      IntPtr _pSecondPoint,
      ref double _dReturnValue);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLL_SetRevitVersion(int _nRevitVersion);

    [DllImport("SitesDLLWrapper.dll")]
    public static extern void eplDLL_UnloadHelper();

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Unicode)]
    public static extern void epl_CreateCatchLinesAndFeatureLinesFromTopo(
      string _strFileName,
      IntPtr _pLines,
      int _nLineCount,
      IntPtr _pArcs,
      int _nArcCount,
      IntPtr _pLegOrder,
      IntPtr _pPnts,
      int _nPointCount,
      double _dLinearInterval,
      double _dRadialInterval,
      double _dArcPointInterval,
      double _dCutSlope,
      double _dFillSlope,
      bool _bProjectLeft,
      ref IntPtr _aLeftCatchLines,
      ref int _nNumLeftCatchLines,
      ref IntPtr _aFeatureLines,
      ref int _nFeatureLines);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Unicode)]
    public static extern void epl_CreateCutAndFillFromTopo(
      string _strFileName,
      IntPtr _pLines,
      int _nLineCount,
      IntPtr _pArcs,
      int _nArcCount,
      IntPtr _pLegOrder,
      IntPtr _pPnts,
      int _nPointCount,
      double _dLinearInterval,
      double _dRadialInterval,
      double _dArcPointInterval,
      double _dLeftOffsetWidth,
      double _dRightOffsetWidth,
      double _dBoulevardWidth,
      double _dCutSlope,
      double _dFillSlope,
      int _nProjectInnerSlopes,
      double _dSubgradeAdjustElev,
      bool _bIsCrownPresent,
      bool _bIsProjectLegToTopo,
      double _dLeftEdgeAdjustElev,
      double _dRightEdgeAdjustElev,
      double _dLeftSubgradeAdjustElev,
      double _dRightSubgradeAdjustElev,
      ref IntPtr _aCutFillPoints,
      ref int _nNumCutFillPoints,
      ref IntPtr _aLeftCatchLines,
      ref int _nNumLeftCatchLines,
      ref IntPtr _aRightCatchLines,
      ref int _nNumRightCatchLines,
      ref IntPtr _aLeftCutFillLines,
      ref int _nNumLeftCutFillLines,
      ref IntPtr _aRightCutFillLines,
      ref int _nNumRightCutFillLines);

    [DllImport("SitesDLLWrapper.dll", CharSet = CharSet.Unicode)]
    public static extern void epl_GenerateTrianglesFromTopo(
      string _strFileName,
      IntPtr _pPnts,
      int _nPointCount,
      ref IntPtr _aFirstTrianglePnts,
      ref IntPtr _aSecondTrianglePnts,
      ref IntPtr _aThirdTrianglePnts,
      ref int _nNumTriangles);
  }
}
