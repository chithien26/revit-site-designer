﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ParkingLotPlacementForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ParkingLotPlacementForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private ParkingLotPlacement m_ParkingLotPlacement;
  private FamilySymbol m_ParkingStallSymbol;
  private FamilySymbol m_ADAParkingStallSymbol;
  private FamilySymbol m_BumperSymbol;
  private FamilySymbol m_IslandSymbol;
  private FormatOptions m_LengthFormatOptions;
  private FormatOptions m_AngularOptions;
  private View m_CurView;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_LengthUnitSymbolType;
  private UnitSymbolType m_AngularSymbolType;
  private bool m_bAreaBiDirectionalAisles;
  private int m_nAreaRowSpacingOptions;
  private int m_nAreaParkingNumberOfRows;
  private string m_strAreaAisleWidth = string.Empty;
  private string m_strAreaDistanceBetweenCenterlines = string.Empty;
  private FamilyContainer m_CurFamilyContainer;
  private DecimalSymbol m_DecimalSymbolType;
  private double m_dAngularRounding;
  private IContainer components;
  private TabPage m_ParkingSpaceTabPage;
  private ComboBox m_LevelComboBox;
  private Label m_LevelLabel;
  private TabControl m_ParkingLotTabControl;
  private TabPage m_ADASpaceTabPage;
  private ComboBox m_ParkingNameComboBox;
  private Label m_ParkingNameLabel;
  private ComboBox m_ParkingFamilyComboBox;
  private Label m_ParkingFamilyLabel;
  private Label m_ParkingAngleLabel;
  private TextBox m_ParkingAngleTextBox;
  private TextBox m_ParkingWidthTextBox;
  private Label m_ParkingWidthLabel;
  private TextBox m_ParkingLengthTextBox;
  private Label m_ParkingLengthLabel;
  private GroupBox m_ParkingPlacementGroupBox;
  private Button m_ParkingAreaSettingsButton;
  private RadioButton m_ParkingAreaRadioButton;
  private RadioButton m_ParkingDoubleRowRadioButton;
  private RadioButton m_ParkingSingleRowRadioButton;
  private CheckBox m_ADAPlaceParkingSpacesCheckBox;
  private TextBox m_ADANumberOfSpacesTextBox;
  private Label m_ADANumberOfSpacesLabel;
  private TextBox m_ADAWidthTextBox;
  private Label m_ADAWidthLabel;
  private ComboBox m_ADAFamilyNameComboBox;
  private Label m_ADAFamilyNameLabel;
  private ComboBox m_ADAFamilyComboBox;
  private Label m_ADAFamilyLabel;
  private TabPage m_BumperTabPage;
  private CheckBox m_BumperPlaceCheckBox;
  private TextBox m_BumperWidthTextBox;
  private Label m_BumperWidthLabel;
  private ComboBox m_BumperFamilyNameComboBox;
  private Label m_BumperFamilyNameLabel;
  private ComboBox m_BumperFamilyComboBox;
  private Label m_BumperFamilyLabel;
  private TextBox m_BumperSetbackTextBox;
  private Label m_BumperSetbackLabel;
  private TextBox m_BumperHeightTextBox;
  private Label m_BumperHeightLabel;
  private TextBox m_BumperOffsetTextBox;
  private Label m_BumperOffsetLabel;
  private TabPage m_IslandTabPage;
  private CheckBox m_IslandPlaceCheckBox;
  private TextBox m_IslandHeightTextBox;
  private Label m_IslandHeightLabel;
  private TextBox m_IslandWidthTextBox;
  private Label m_IslandWidthLabel;
  private ComboBox m_IslandFamilyNameComboBox;
  private Label m_IslandFamilyNameLabel;
  private ComboBox m_IslandFamilyComboBox;
  private Label m_IslandFamilyLabel;
  private Button m_LoadParkingFamilyButton;
  private Button m_LoadADAFamilyButton;
  private Button m_LoadBumperFamilyButton;
  private Button m_LoadIslandFamilyButton;
  private TextBox m_ParkingNumberOfSpacesTextBox;
  private Label m_ParkingNumberOfSpacesLabel;
  private RadioButton m_ParkingByNumberRadioButton;
  private Panel m_OptimizePanel;
  private RadioButton m_ParkingChainRadioButton;
  private RadioButton m_ParkingSegmentRadioButton;
  private RadioButton m_ParkingOptimizeRadioButton;
  private CheckBox m_ExistingElementCheckBox;
  private Panel m_MoveablePanel;
  private CheckBox m_DeleteExistingCheckBox;
  private Button m_InsertButton;
  private Button m_CancelButton;
  private CheckBox m_ADASharedAccessibleAisleCheckBox;
  private Label m_StartingDistanceLabel;
  private TextBox m_StartingDistanceTextBox;
  private Panel m_ToposurfacePickerPanel;
  private Label m_SelectedSurfaceLabel;
  private CheckBox m_ToposurfaceCheckBox;
  private ComboBox m_SurfaceList;

  public ParkingLotPlacementForm(ParkingLotPlacement _ParkingLotPlacement)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ParkingLotDialog");
    this.m_ParkingSpaceTabPage.Text = EPShared.LocalRM.GetString("ParkingStyleDialog");
    this.m_ADASpaceTabPage.Text = EPShared.LocalRM.GetString("ADASpacingDialog");
    this.m_BumperTabPage.Text = EPShared.LocalRM.GetString("BumperDialog");
    this.m_IslandTabPage.Text = EPShared.LocalRM.GetString("IslandDialog");
    this.m_ParkingPlacementGroupBox.Text = EPShared.LocalRM.GetString("ParkingPlacementDialog");
    this.m_ParkingSingleRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleRowDialog");
    this.m_ParkingDoubleRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_DoubleRowDialog");
    this.m_ParkingAreaRadioButton.Text = EPShared.LocalRM.GetString("AMP_AreaDialog");
    this.m_ParkingAreaSettingsButton.Text = EPShared.LocalRM.GetString("Se_AMP_ttingsDialog");
    this.m_ParkingFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
    this.m_ParkingNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
    this.m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
    this.m_ParkingLengthLabel.Text = EPShared.LocalRM.GetString("AMP_LengthDialog");
    this.m_ParkingAngleLabel.Text = EPShared.LocalRM.GetString("AMP_AngleDialog");
    this.m_ParkingWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
    this.m_ParkingOptimizeRadioButton.Text = EPShared.LocalRM.GetString("AMP_OptimizeDialog");
    this.m_ParkingSegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ParkingChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_ParkingByNumberRadioButton.Text = EPShared.LocalRM.GetString("ByN_AMP_umberDialog");
    this.m_ParkingWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
    this.m_ParkingNumberOfSpacesLabel.Text = EPShared.LocalRM.GetString("Nu_AMP_mberOfSpacesDialog");
    this.m_ExistingElementCheckBox.Text = EPShared.LocalRM.GetString("ExistingEle_AMP_mentDialog");
    this.m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
    this.m_ADAPlaceParkingSpacesCheckBox.Text = EPShared.LocalRM.GetString("Place_AMP_ADAParkingSpacesDialog");
    this.m_ADAFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
    this.m_ADAFamilyNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
    this.m_ADAWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
    this.m_ADANumberOfSpacesLabel.Text = EPShared.LocalRM.GetString("Nu_AMP_mberOfSpacesDialog");
    this.m_ADASharedAccessibleAisleCheckBox.Text = EPShared.LocalRM.GetString("S_AMP_haredAccessibleAisleDialog");
    this.m_BumperPlaceCheckBox.Text = EPShared.LocalRM.GetString("Place_AMP_BumpersDialog");
    this.m_BumperFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
    this.m_BumperFamilyNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
    this.m_BumperSetbackLabel.Text = EPShared.LocalRM.GetString("AMP_SetbackDialog");
    this.m_BumperOffsetLabel.Text = EPShared.LocalRM.GetString("AMP_OffsetDialog");
    this.m_BumperWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
    this.m_BumperHeightLabel.Text = EPShared.LocalRM.GetString("AMP_HeightDialog");
    this.m_IslandPlaceCheckBox.Text = EPShared.LocalRM.GetString("Place_AMP_IslandsDialog");
    this.m_IslandFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
    this.m_IslandFamilyNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
    this.m_IslandWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
    this.m_IslandHeightLabel.Text = EPShared.LocalRM.GetString("AMP_HeightDialog");
    this.m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
    this.m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
    this.EPToolTip.SetToolTip((Control) this.m_LoadParkingFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_LoadADAFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_LoadBumperFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.EPToolTip.SetToolTip((Control) this.m_LoadIslandFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.m_ParkingLotPlacement = _ParkingLotPlacement;
    this.m_DisplayUnitSystem = this.m_ParkingLotPlacement.Document.DisplayUnitSystem;
    this.m_LengthFormatOptions = this.m_ParkingLotPlacement.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_AngularOptions = this.m_ParkingLotPlacement.Document.GetUnits().GetFormatOptions((UnitType) 3);
    this.m_Units = this.m_ParkingLotPlacement.Document.GetUnits();
    try
    {
      this.m_LengthUnitSymbolType = this.m_LengthFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_LengthUnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_AngularSymbolType = this.m_AngularOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_AngularSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_dAngularRounding = this.m_AngularOptions.Accuracy;
    }
    catch (InvalidOperationException ex)
    {
      this.m_dAngularRounding = 1.0;
    }
    this.m_DecimalSymbolType = this.m_ParkingLotPlacement.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty1 = string.Empty;
    this.GetDialogPosition();
    this.m_ParkingFamilyComboBox.DataSource = (object) this.m_ParkingLotPlacement.ParkingStallFamilyList;
    this.m_ParkingFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_ParkingFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_ParkingFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty1, true) == 0)
        {
          this.m_ParkingFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotSymbolName", ref empty1))
    {
      for (int index = 0; index < this.m_ParkingNameComboBox.Items.Count; ++index)
      {
        if (this.m_ParkingNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty1, true) == 0)
        {
          this.m_ParkingNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_LevelComboBox.DataSource = (object) this.m_ParkingLotPlacement.Views;
    this.m_LevelComboBox.DisplayMember = "ViewName";
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotViewName", ref empty1))
    {
      for (int index = 0; index < this.m_LevelComboBox.Items.Count; ++index)
      {
        if (this.m_LevelComboBox.Items[index] is View view && string.Compare(((Element) view).Name, empty1, true) == 0)
        {
          this.m_LevelComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotParkingAngle", ref _dReturnValue))
      _dReturnValue = Math.PI / 2.0;
    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dReturnValue, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref empty1);
    this.m_ParkingAngleTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotParkingWidth", ref _dReturnValue))
      _dReturnValue = 9.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_ParkingWidthTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotParkingLength", ref _dReturnValue))
      _dReturnValue = 18.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_ParkingLengthTextBox.Text = empty1;
    this.m_ParkingSingleRowRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotPlacementOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_ParkingSingleRowRadioButton.Checked = true;
          break;
        case 1:
          this.m_ParkingDoubleRowRadioButton.Checked = true;
          break;
        default:
          this.m_ParkingAreaRadioButton.Checked = true;
          break;
      }
    }
    this.m_ParkingOptimizeRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotOptimizeByNumberOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_ParkingOptimizeRadioButton.Checked = true;
      else
        this.m_ParkingByNumberRadioButton.Checked = true;
    }
    this.m_ParkingSegmentRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotOptimizeSegmentChainOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_ParkingSegmentRadioButton.Checked = true;
      else
        this.m_ParkingChainRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotNumberOfSpaces", ref _nReturnValue))
      _nReturnValue = 0;
    this.m_ParkingNumberOfSpacesTextBox.Text = Convert.ToString(_nReturnValue);
    this.m_ExistingElementCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotExistingElement", ref _nReturnValue))
      this.m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_DeleteExistingCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotDeleteExisting", ref _nReturnValue))
      this.m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotStartingDistance", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_StartingDistanceTextBox.Text = empty1;
    this.m_ADAFamilyComboBox.DataSource = (object) this.m_ParkingLotPlacement.ADAParkingStallFamilyList;
    this.m_ADAFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotADAFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_ADAFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_ADAFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty1, true) == 0)
        {
          this.m_ADAFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotADASymbolName", ref empty1))
    {
      for (int index = 0; index < this.m_ADAFamilyNameComboBox.Items.Count; ++index)
      {
        if (this.m_ADAFamilyNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty1, true) == 0)
        {
          this.m_ADAFamilyNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_ADAPlaceParkingSpacesCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADAPlaceParkingSpaces", ref _nReturnValue))
      this.m_ADAPlaceParkingSpacesCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADAParkingWidth", ref _dReturnValue))
      _dReturnValue = 9.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_ADAWidthTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADANumberOfSpaces", ref _nReturnValue))
      _nReturnValue = 1;
    this.m_ADANumberOfSpacesTextBox.Text = Convert.ToString(_nReturnValue);
    this.m_ADASharedAccessibleAisleCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADASharedAccessibleAisle", ref _nReturnValue))
      this.m_ADASharedAccessibleAisleCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_BumperFamilyComboBox.DataSource = (object) this.m_ParkingLotPlacement.ParkingBumperFamilyList;
    this.m_BumperFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_BumperFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_BumperFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty1, true) == 0)
        {
          this.m_BumperFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperSymbolName", ref empty1))
    {
      for (int index = 0; index < this.m_BumperFamilyNameComboBox.Items.Count; ++index)
      {
        if (this.m_BumperFamilyNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty1, true) == 0)
        {
          this.m_BumperFamilyNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_BumperPlaceCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperPlace", ref _nReturnValue))
      this.m_BumperPlaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingSetback", ref _dReturnValue))
      _dReturnValue = 1.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_BumperSetbackTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingOffset", ref _dReturnValue))
      _dReturnValue = 1.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_BumperOffsetTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingWidth", ref _dReturnValue))
      _dReturnValue = 0.5;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_BumperWidthTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingHeight", ref _dReturnValue))
      _dReturnValue = 0.58333;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_BumperHeightTextBox.Text = empty1;
    this.m_IslandFamilyComboBox.Items.Add((object) "<Empty Space>");
    for (int index = 0; index < this.m_ParkingLotPlacement.ParkingIslandFamilyList.Count; ++index)
      this.m_IslandFamilyComboBox.Items.Add((object) this.m_ParkingLotPlacement.ParkingIslandFamilyList[index].FamilyName);
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_IslandFamilyComboBox.Items.Count; ++index)
      {
        if (string.Compare((string) this.m_IslandFamilyComboBox.Items[index], empty1, true) == 0)
        {
          this.m_IslandFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandSymbolName", ref empty1))
    {
      for (int index = 0; index < this.m_IslandFamilyNameComboBox.Items.Count; ++index)
      {
        if (string.Compare((string) this.m_IslandFamilyNameComboBox.Items[index], empty1, true) == 0)
        {
          this.m_IslandFamilyNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (this.m_IslandFamilyComboBox.SelectedIndex == -1)
      this.m_IslandFamilyComboBox.SelectedIndex = 0;
    this.m_IslandPlaceCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotIslandPlace", ref _nReturnValue))
      this.m_IslandPlaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotIslandParkingWidth", ref _dReturnValue))
      _dReturnValue = 4.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_IslandWidthTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotIslandParkingHeight", ref _dReturnValue))
      _dReturnValue = 0.58333;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_IslandHeightTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsDistanceBetweenCenterlines", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_strAreaDistanceBetweenCenterlines = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsAisleWidth", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty1);
    this.m_strAreaAisleWidth = empty1;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsBiDirectionalAisles", ref _nReturnValue))
      this.m_bAreaBiDirectionalAisles = Convert.ToBoolean(_nReturnValue);
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsRowSpacingOption", ref _nReturnValue))
      this.m_nAreaRowSpacingOptions = _nReturnValue;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsNumberOfRows", ref _nReturnValue))
      this.m_nAreaParkingNumberOfRows = _nReturnValue;
    this.m_ToposurfaceCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotPickToposurface", ref _nReturnValue))
      this.m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    Parameter parameter1 = (Parameter) null;
    string name = string.Empty;
    if (this.m_ParkingLotPlacement.SurfaceList.Count > 0)
    {
      int num = 1;
      foreach (TopographySurfaceContainer surface in this.m_ParkingLotPlacement.SurfaceList)
      {
        Parameter parameter2 = ((Element) surface.TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter2 != null)
          name = parameter2.AsString();
        if (name == null || name == string.Empty)
        {
          name = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
          ++num;
        }
        this.m_SurfaceList.Items.Add((object) new ToposurfaceItem(name, surface));
      }
    }
    else
    {
      this.m_ToposurfaceCheckBox.Checked = false;
      this.m_ToposurfaceCheckBox.Enabled = false;
      this.m_SurfaceList.Enabled = false;
    }
    parameter1 = (Parameter) null;
    string empty2 = string.Empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotSurfaceName", ref empty1))
    {
      for (int index = 0; index < this.m_SurfaceList.Items.Count; ++index)
      {
        if (this.m_SurfaceList.Items[index] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, empty1, true) == 0)
        {
          this.m_SurfaceList.SelectedIndex = index;
          break;
        }
      }
    }
    if (this.m_SurfaceList.Items.Count <= 0 || this.m_SurfaceList.SelectedIndex != -1)
      return;
    this.m_SurfaceList.SelectedIndex = 0;
  }

  private void SaveSettings()
  {
    double _dReturnedDouble = 0.0;
    this.m_CurView = this.m_LevelComboBox.SelectedItem as View;
    if (this.m_CurView == null)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.m_ParkingStallSymbol = this.m_ParkingNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_ParkingStallSymbol == null)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        if (this.m_ParkingFamilyComboBox.SelectedItem is FamilyContainer selectedItem1)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotFamilyName", selectedItem1.FamilyName);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotSymbolName", ((Element) this.m_ParkingStallSymbol).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotViewName", ((Element) this.m_CurView).Name);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_ParkingWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotParkingWidth", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_ParkingLengthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotParkingLength", _dReturnedDouble);
        _dReturnedDouble = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_ParkingAngleTextBox.Text);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotParkingAngle", _dReturnedDouble);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotPlacementOption", !this.m_ParkingSingleRowRadioButton.Checked ? (!this.m_ParkingDoubleRowRadioButton.Checked ? 2 : 1) : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotOptimizeByNumberOption", !this.m_ParkingOptimizeRadioButton.Checked ? 1 : 0);
        int _nReturnedInt = !this.m_ParkingSegmentRadioButton.Checked ? 1 : 0;
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotOptimizeSegmentChainOption", _nReturnedInt);
        if (RevitGeometry.StrE_GetValidWholeNumber(this.m_ParkingNumberOfSpacesTextBox.Text, ref _nReturnedInt))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotNumberOfSpaces", _nReturnedInt);
        if (this.m_ADAFamilyComboBox.SelectedItem is FamilyContainer selectedItem2)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotADAFamilyName", selectedItem2.FamilyName);
        this.m_ADAParkingStallSymbol = this.m_ADAFamilyNameComboBox.SelectedItem as FamilySymbol;
        if (this.m_ADAParkingStallSymbol != null)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotADASymbolName", ((Element) this.m_ADAParkingStallSymbol).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADAPlaceParkingSpaces", Convert.ToInt32(this.m_ADAPlaceParkingSpacesCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_ADAWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADAParkingWidth", _dReturnedDouble);
        if (RevitGeometry.StrE_GetValidWholeNumber(this.m_ADANumberOfSpacesTextBox.Text, ref _nReturnedInt))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADANumberOfSpaces", _nReturnedInt);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADASharedAccessibleAisle", Convert.ToInt32(this.m_ADASharedAccessibleAisleCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotExistingElement", Convert.ToInt32(this.m_ExistingElementCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotDeleteExisting", Convert.ToInt32(this.m_DeleteExistingCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotStartingDistance", _dReturnedDouble);
        if (this.m_BumperFamilyComboBox.SelectedItem is FamilyContainer selectedItem3)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperFamilyName", selectedItem3.FamilyName);
        this.m_BumperSymbol = this.m_BumperFamilyNameComboBox.SelectedItem as FamilySymbol;
        if (this.m_BumperSymbol != null)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperSymbolName", ((Element) this.m_BumperSymbol).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperPlace", Convert.ToInt32(this.m_BumperPlaceCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperSetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingSetback", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperOffsetTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingOffset", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingWidth", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingHeight", _dReturnedDouble);
        if (this.m_IslandFamilyComboBox.SelectedItem != null)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandFamilyName", (string) this.m_IslandFamilyComboBox.SelectedItem);
        if (this.m_CurFamilyContainer != null && this.m_IslandFamilyNameComboBox.SelectedItem != null)
        {
          for (int index = 0; index < this.m_CurFamilyContainer.FamilySymbolList.Count; ++index)
          {
            if (string.Compare((string) this.m_IslandFamilyNameComboBox.SelectedItem, ((Element) this.m_CurFamilyContainer.FamilySymbolList[index]).Name, true) == 0)
            {
              this.m_IslandSymbol = this.m_CurFamilyContainer.FamilySymbolList[index];
              break;
            }
          }
        }
        else if (this.m_IslandSymbol != null)
          this.m_IslandSymbol = (FamilySymbol) null;
        if (this.m_IslandSymbol != null)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandSymbolName", ((Element) this.m_IslandSymbol).Name);
        else
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandSymbolName", string.Empty);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotIslandPlace", Convert.ToInt32(this.m_IslandPlaceCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_IslandWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotIslandParkingWidth", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_IslandHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotIslandParkingHeight", _dReturnedDouble);
        ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotPickToposurface", Convert.ToInt32(this.m_ToposurfaceCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_ParkingLotPlacement.Document.PathName, "ParkingLotSurfaceName", Convert.ToString(this.m_SurfaceList.SelectedItem));
      }
    }
  }

  private void OnParkingOptimizeByNumberOptionChecked(object sender, EventArgs e)
  {
    if (!this.m_IslandPlaceCheckBox.Checked || this.m_CurFamilyContainer == null)
    {
      this.m_ParkingChainRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
      this.m_ParkingSegmentRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
    }
    else
    {
      this.m_ParkingChainRadioButton.Enabled = false;
      this.m_ParkingSegmentRadioButton.Enabled = false;
    }
    this.m_ParkingNumberOfSpacesLabel.Enabled = !this.m_ParkingOptimizeRadioButton.Checked;
    this.m_ParkingNumberOfSpacesTextBox.Enabled = !this.m_ParkingOptimizeRadioButton.Checked;
  }

  private void OnParkingPlacementOptionsChecked(object sender, EventArgs e)
  {
    this.m_ParkingAreaSettingsButton.Enabled = this.m_ParkingAreaRadioButton.Checked;
    if (!this.m_IslandPlaceCheckBox.Checked || this.m_CurFamilyContainer == null)
    {
      this.m_ParkingChainRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
      this.m_ParkingSegmentRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
    }
    else
    {
      this.m_ParkingChainRadioButton.Enabled = false;
      this.m_ParkingSegmentRadioButton.Enabled = false;
    }
  }

  private void OnParkingFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_ParkingFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_ParkingNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_ParkingNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnADAFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_ADAFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_ADAFamilyNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_ADAFamilyNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnBumperFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_BumperFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_BumperFamilyNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_BumperFamilyNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnIslandFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    this.m_CurFamilyContainer = (FamilyContainer) null;
    for (int index = 0; index < this.m_ParkingLotPlacement.ParkingIslandFamilyList.Count; ++index)
    {
      if (string.Compare((string) this.m_IslandFamilyComboBox.SelectedItem, this.m_ParkingLotPlacement.ParkingIslandFamilyList[index].FamilyName, true) == 0)
      {
        this.m_CurFamilyContainer = this.m_ParkingLotPlacement.ParkingIslandFamilyList[index];
        break;
      }
    }
    this.m_IslandFamilyNameComboBox.Items.Clear();
    if (this.m_CurFamilyContainer != null)
    {
      if (this.m_CurFamilyContainer.FamilySymbolList.Count > 0)
      {
        for (int index = 0; index < this.m_CurFamilyContainer.FamilySymbolList.Count; ++index)
          this.m_IslandFamilyNameComboBox.Items.Add((object) ((Element) this.m_CurFamilyContainer.FamilySymbolList[index]).Name);
        this.m_IslandFamilyNameComboBox.SelectedIndex = 0;
      }
      this.m_IslandFamilyNameLabel.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_IslandFamilyNameComboBox.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_IslandHeightLabel.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_IslandHeightTextBox.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_ParkingChainRadioButton.Enabled = false;
      this.m_ParkingSegmentRadioButton.Enabled = false;
    }
    else
    {
      this.m_IslandFamilyNameLabel.Enabled = false;
      this.m_IslandFamilyNameComboBox.Enabled = false;
      this.m_IslandHeightLabel.Enabled = false;
      this.m_IslandHeightTextBox.Enabled = false;
      this.m_ParkingChainRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
      this.m_ParkingSegmentRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
    }
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void FormatParkingAngleValue()
  {
    string empty = string.Empty;
    if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_ParkingAngleTextBox.Text), this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref empty) != 0)
      return;
    this.m_ParkingAngleTextBox.Text = empty;
  }

  private void OnParkingAngleTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatParkingAngleValue();
  }

  private void FormatParkingWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_ParkingWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_ParkingWidthTextBox.Text = empty;
    }
    else
      this.m_ParkingWidthTextBox.Focus();
  }

  private void OnParkingWidthTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatParkingWidthValue();
  }

  private void FormatParkingLengthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_ParkingLengthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_ParkingLengthTextBox.Text = empty;
    }
    else
      this.m_ParkingLengthTextBox.Focus();
  }

  private void OnParkingLengthTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatParkingLengthValue();
  }

  private void FormatADAParkingWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_ADAWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_ADAWidthTextBox.Text = empty;
    }
    else
      this.m_ADAWidthTextBox.Focus();
  }

  private void OnADAParkingWidthTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatADAParkingWidthValue();
  }

  private void FormatBumperSetbackValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperSetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_BumperSetbackTextBox.Text = empty;
    }
    else
      this.m_BumperSetbackTextBox.Focus();
  }

  private void OnBumperSetbackTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatBumperSetbackValue();
  }

  private void FormatBumperOffsetValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperOffsetTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_BumperOffsetTextBox.Text = empty;
    }
    else
      this.m_BumperOffsetTextBox.Focus();
  }

  private void OnBumperOffsetTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatBumperOffsetValue();
  }

  private void FormatBumperWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_BumperWidthTextBox.Text = empty;
    }
    else
      this.m_BumperWidthTextBox.Focus();
  }

  private void OnBumperWidthTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatBumperWidthValue();
  }

  private void FormatBumperHeightValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BumperHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_BumperHeightTextBox.Text = empty;
    }
    else
      this.m_BumperHeightTextBox.Focus();
  }

  private void OnBumperHeightTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatBumperHeightValue();
  }

  private void FormatIslandWidthValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_IslandWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_IslandWidthTextBox.Text = empty;
    }
    else
      this.m_IslandWidthTextBox.Focus();
  }

  private void OnIslandWidthTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatIslandWidthValue();
  }

  private void FormatIslandHeightValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_IslandHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_IslandHeightTextBox.Text = empty;
    }
    else
      this.m_IslandHeightTextBox.Focus();
  }

  private void OnIslandHeightTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatIslandHeightValue();
  }

  private void OnIslandHeightTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatIslandHeightValue();
  }

  private void OnParkingLengthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatParkingLengthValue();
  }

  private void OnParkingWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatParkingWidthValue();
  }

  private void OnParkingAngleTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatParkingAngleValue();
  }

  private void OnADAParkingWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatADAParkingWidthValue();
  }

  private void OnBumperSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatBumperSetbackValue();
  }

  private void OnBumperOffsetTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatBumperOffsetValue();
  }

  private void OnBumperWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatBumperWidthValue();
  }

  private void OnBumperHeightTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatBumperHeightValue();
  }

  private void OnIslandWidthTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatIslandWidthValue();
  }

  private void OnIslandPlaceCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_IslandFamilyLabel.Enabled = this.m_IslandPlaceCheckBox.Checked;
    this.m_IslandFamilyComboBox.Enabled = this.m_IslandPlaceCheckBox.Checked;
    this.m_IslandWidthLabel.Enabled = this.m_IslandPlaceCheckBox.Checked;
    this.m_IslandWidthTextBox.Enabled = this.m_IslandPlaceCheckBox.Checked;
    if (this.m_IslandPlaceCheckBox.Checked && this.m_CurFamilyContainer != null)
    {
      this.m_IslandFamilyNameLabel.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_IslandFamilyNameComboBox.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_IslandHeightLabel.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_IslandHeightTextBox.Enabled = this.m_IslandPlaceCheckBox.Checked;
      this.m_ParkingChainRadioButton.Enabled = false;
      this.m_ParkingSegmentRadioButton.Enabled = false;
    }
    else
    {
      this.m_IslandFamilyNameLabel.Enabled = false;
      this.m_IslandFamilyNameComboBox.Enabled = false;
      this.m_IslandHeightLabel.Enabled = false;
      this.m_IslandHeightTextBox.Enabled = false;
      this.m_ParkingChainRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
      this.m_ParkingSegmentRadioButton.Enabled = !this.m_ParkingAreaRadioButton.Checked && this.m_ParkingOptimizeRadioButton.Checked;
    }
  }

  private void OnBumperPlaceCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_BumperFamilyLabel.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperFamilyComboBox.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperFamilyNameLabel.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperFamilyNameComboBox.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperSetbackLabel.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperSetbackTextBox.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperOffsetLabel.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperOffsetTextBox.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperWidthLabel.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperWidthTextBox.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperHeightLabel.Enabled = this.m_BumperPlaceCheckBox.Checked;
    this.m_BumperHeightTextBox.Enabled = this.m_BumperPlaceCheckBox.Checked;
  }

  private void OnADAPlaceParkingSpacesCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_ADAFamilyLabel.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADAFamilyComboBox.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADAFamilyNameLabel.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADAFamilyNameComboBox.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADAWidthLabel.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADAWidthTextBox.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADANumberOfSpacesLabel.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADANumberOfSpacesTextBox.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
    this.m_ADASharedAccessibleAisleCheckBox.Enabled = this.m_ADAPlaceParkingSpacesCheckBox.Checked;
  }

  private void OnInsertButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnParkingAreaSettingsButtonClick(object sender, EventArgs e)
  {
    using (ParkingLotAreaSettingsForm areaSettingsForm = new ParkingLotAreaSettingsForm(this.m_ParkingLotPlacement.Document))
    {
      areaSettingsForm.DistanceBetweenCenterlines = this.m_strAreaDistanceBetweenCenterlines;
      areaSettingsForm.AisleWidth = this.m_strAreaAisleWidth;
      areaSettingsForm.BiDirectionalAisles = this.m_bAreaBiDirectionalAisles;
      areaSettingsForm.RowSpacingOptions = this.m_nAreaRowSpacingOptions;
      areaSettingsForm.ParkingNumberOfRows = this.m_nAreaParkingNumberOfRows;
      if (areaSettingsForm.ShowDialog() == DialogResult.Cancel)
        return;
      this.m_strAreaDistanceBetweenCenterlines = areaSettingsForm.DistanceBetweenCenterlines;
      this.m_strAreaAisleWidth = areaSettingsForm.AisleWidth;
      this.m_bAreaBiDirectionalAisles = areaSettingsForm.BiDirectionalAisles;
      this.m_nAreaRowSpacingOptions = areaSettingsForm.RowSpacingOptions;
      this.m_nAreaParkingNumberOfRows = areaSettingsForm.ParkingNumberOfRows;
    }
  }

  private void OnParkingLotPlacementFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void LoadFamilyFilePicker(LandcaddID _ParkingType)
  {
    string empty1 = string.Empty;
    int num1 = 0;
    int num2 = 0;
    switch (_ParkingType)
    {
      case LandcaddID.ParkingStall:
        num2 = this.m_ParkingFamilyComboBox.Items.Count;
        empty1 = EPShared.LocalRM.GetString("LoadParkingFamilyTransaction");
        break;
      case LandcaddID.ADAParkingStall:
        num2 = this.m_ADAFamilyComboBox.Items.Count;
        empty1 = EPShared.LocalRM.GetString("LoadADAParkingFamilyTransaction");
        break;
      case LandcaddID.ParkingBumper:
        num2 = this.m_BumperFamilyComboBox.Items.Count;
        empty1 = EPShared.LocalRM.GetString("LoadParkingBumperFamilyTransaction");
        break;
      case LandcaddID.ParkingIsland:
        num2 = this.m_IslandFamilyComboBox.Items.Count;
        empty1 = EPShared.LocalRM.GetString("LoadParkingIslandFamilyTransaction");
        break;
    }
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty2 = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = "Please select Parking Family File.";
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty2) == 0)
        openFileDialog.InitialDirectory = empty2;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      int int32;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_ParkingLotPlacement.TransactionContainer.Start(empty1 + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_ParkingLotPlacement.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_ParkingLotPlacement.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_ParkingLotPlacement.TransactionContainer = transactionContainer;
            this.m_ParkingLotPlacement.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_ParkingLotPlacement.TransactionContainer.Rollback();
            flag = false;
            string str1 = EPShared.LocalRM.GetString("ParkingFamilyCantBeLoadedMessage");
            int32 = Convert.ToInt32((object) _ParkingType);
            string str2 = int32.ToString("000");
            string str3 = EPShared.LocalRM.GetString("TypeParameterFamilyFileMessage");
            int num3 = (int) RevitMessageBox.Show(str1 + str2 + str3, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (num2 != 0)
          return;
        string str4 = EPShared.LocalRM.GetString("ParkingFamilyNotLoadedMessage");
        int32 = Convert.ToInt32((object) _ParkingType);
        string str5 = int32.ToString("000");
        string str6 = EPShared.LocalRM.GetString("TypeParameterFamilyNotLoadedMessage");
        int num4 = (int) RevitMessageBox.Show(str4 + str5 + str6, EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_ParkingLotPlacement.PopulateFamilyAndSymbolLists(_ParkingType);
        switch (_ParkingType)
        {
          case LandcaddID.ParkingStall:
            this.m_ParkingFamilyComboBox.DataSource = (object) this.m_ParkingLotPlacement.ParkingStallFamilyList;
            this.m_ParkingFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
            if (_Family != null)
            {
              for (int index = 0; index < this.m_ParkingFamilyComboBox.Items.Count; ++index)
              {
                if (this.m_ParkingFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
                {
                  this.m_ParkingFamilyComboBox.SelectedIndex = index;
                  break;
                }
              }
            }
            num1 = this.m_ParkingFamilyComboBox.Items.Count;
            break;
          case LandcaddID.ADAParkingStall:
            this.m_ADAFamilyComboBox.DataSource = (object) this.m_ParkingLotPlacement.ADAParkingStallFamilyList;
            this.m_ADAFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
            if (_Family != null)
            {
              for (int index = 0; index < this.m_ADAFamilyComboBox.Items.Count; ++index)
              {
                if (this.m_ADAFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
                {
                  this.m_ADAFamilyComboBox.SelectedIndex = index;
                  break;
                }
              }
            }
            num1 = this.m_ADAFamilyComboBox.Items.Count;
            break;
          case LandcaddID.ParkingBumper:
            this.m_BumperFamilyComboBox.DataSource = (object) this.m_ParkingLotPlacement.ParkingBumperFamilyList;
            this.m_BumperFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
            if (_Family != null)
            {
              for (int index = 0; index < this.m_BumperFamilyComboBox.Items.Count; ++index)
              {
                if (this.m_BumperFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
                {
                  this.m_BumperFamilyComboBox.SelectedIndex = index;
                  break;
                }
              }
            }
            num1 = this.m_BumperFamilyComboBox.Items.Count;
            break;
          case LandcaddID.ParkingIsland:
            this.m_IslandFamilyComboBox.Items.Clear();
            this.m_IslandFamilyComboBox.Items.Add((object) "<Empty Space>");
            for (int index = 0; index < this.m_ParkingLotPlacement.ParkingIslandFamilyList.Count; ++index)
            {
              this.m_IslandFamilyComboBox.Items.Add((object) this.m_ParkingLotPlacement.ParkingIslandFamilyList[index].FamilyName);
              if (_Family != null && string.Compare(this.m_ParkingLotPlacement.ParkingIslandFamilyList[index].FamilyName, ((Element) _Family).Name, true) == 0)
                this.m_IslandFamilyComboBox.SelectedIndex = index;
            }
            num1 = this.m_IslandFamilyComboBox.Items.Count;
            break;
        }
        if (num1 != num2)
          return;
        string str7 = EPShared.LocalRM.GetString("FamilyNotParkingMessage");
        int32 = Convert.ToInt32((object) _ParkingType);
        string str8 = int32.ToString("000");
        string str9 = EPShared.LocalRM.GetString("TypeParameterFamilyMessage");
        int num5 = (int) RevitMessageBox.Show(str7 + str8 + str9, EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnLoadIslandFamilyButtonClick(object sender, EventArgs e)
  {
    this.LoadFamilyFilePicker(LandcaddID.ParkingIsland);
  }

  private void OnLoadBumperFamilyButtonClick(object sender, EventArgs e)
  {
    this.LoadFamilyFilePicker(LandcaddID.ParkingBumper);
  }

  private void OnLoadADAFamilyButtonClick(object sender, EventArgs e)
  {
    this.LoadFamilyFilePicker(LandcaddID.ADAParkingStall);
  }

  private void OnLoadParkingFamilyButtonClick(object sender, EventArgs e)
  {
    this.LoadFamilyFilePicker(LandcaddID.ParkingStall);
  }

  private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_DeleteExistingCheckBox.Enabled = this.m_ExistingElementCheckBox.Checked;
    this.m_StartingDistanceLabel.Enabled = this.m_ExistingElementCheckBox.Checked;
    this.m_StartingDistanceTextBox.Enabled = this.m_ExistingElementCheckBox.Checked;
  }

  private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatStartingDistanceValue();
  }

  private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatStartingDistanceValue();
  }

  private void FormatStartingDistanceValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_StartingDistanceTextBox.Text = empty;
    }
    else
      this.m_StartingDistanceTextBox.Focus();
  }

  private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
  {
    this.m_SurfaceList.Enabled = this.m_ToposurfaceCheckBox.Checked;
    this.m_SelectedSurfaceLabel.Enabled = this.m_ToposurfaceCheckBox.Checked;
  }

  public PlacementType PlacementType
  {
    get
    {
      if (this.m_ParkingSingleRowRadioButton.Checked)
        return PlacementType.ParkingSingleRow;
      return this.m_ParkingDoubleRowRadioButton.Checked ? PlacementType.ParkingDoubleRow : PlacementType.ParkingArea;
    }
  }

  public Level Level => this.m_CurView.GenLevel;

  public View View => this.m_CurView;

  public FamilySymbol ParkingStallSymbol => this.m_ParkingStallSymbol;

  public FamilySymbol ADAParkingStallSymbol => this.m_ADAParkingStallSymbol;

  public FamilySymbol BumperSymbol => this.m_BumperSymbol;

  public FamilySymbol IslandSymbol => this.m_IslandSymbol;

  public bool ParkingSingleRowChecked => this.m_ParkingSingleRowRadioButton.Checked;

  public bool ParkingDoubleRowChecked => this.m_ParkingDoubleRowRadioButton.Checked;

  public bool ParkingAreaChecked => this.m_ParkingAreaRadioButton.Checked;

  public bool ParkingOptimizeChecked => this.m_ParkingOptimizeRadioButton.Checked;

  public bool ParkingByNumberChecked => this.m_ParkingByNumberRadioButton.Checked;

  public bool ParkingSegmentChecked => this.m_ParkingSegmentRadioButton.Checked;

  public bool ParkingChainChecked => this.m_ParkingChainRadioButton.Checked;

  public int ParkingNumberOfSpaces
  {
    get
    {
      int _nReturnedInt = 0;
      RevitGeometry.StrE_GetValidWholeNumber(this.m_ParkingNumberOfSpacesTextBox.Text, ref _nReturnedInt);
      return _nReturnedInt;
    }
  }

  public double ParkingAngle
  {
    get
    {
      double parkingAngle = 0.0;
      if (this.m_ParkingAngleTextBox.Text != string.Empty)
        parkingAngle = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_ParkingAngleTextBox.Text);
      return parkingAngle;
    }
  }

  public double ParkingWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_ParkingWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_ParkingWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double ParkingLength
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_ParkingLengthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_ParkingLengthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool ADAPlaceParkingSpacesChecked => this.m_ADAPlaceParkingSpacesCheckBox.Checked;

  public double ADAParkingWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_ADAWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_ADAWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public int ADAParkingNumberOfSpaces
  {
    get
    {
      int _nReturnedInt = 0;
      RevitGeometry.StrE_GetValidWholeNumber(this.m_ADANumberOfSpacesTextBox.Text, ref _nReturnedInt);
      return _nReturnedInt;
    }
  }

  public bool ADASharedAccessibleAisleChecked => this.m_ADASharedAccessibleAisleCheckBox.Checked;

  public bool BumperPlaceChecked => this.m_BumperPlaceCheckBox.Checked;

  public double BumperSetback
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_BumperSetbackTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_BumperSetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double BumperOffset
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_BumperOffsetTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_BumperOffsetTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double BumperWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_BumperWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_BumperWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double BumperHeight
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_BumperHeightTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_BumperHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool IslandPlaceChecked => this.m_IslandPlaceCheckBox.Checked;

  public double IslandWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_IslandWidthTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_IslandWidthTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double IslandHeight
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_IslandHeightTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_IslandHeightTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool AreaBiDirectionalAisles => this.m_bAreaBiDirectionalAisles;

  public int AreaRowSpacingOptions => this.m_nAreaRowSpacingOptions;

  public double AreaAisleWidth
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_strAreaAisleWidth != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_strAreaAisleWidth, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double AreaDistanceBetweenCenterlines
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_strAreaDistanceBetweenCenterlines != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_strAreaDistanceBetweenCenterlines, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public int AreaParkingNumberOfRows => this.m_nAreaParkingNumberOfRows;

  public bool ExistingElementChecked => this.m_ExistingElementCheckBox.Checked;

  public bool DeleteExistingChecked
  {
    get => this.m_ExistingElementCheckBox.Checked && this.m_DeleteExistingCheckBox.Checked;
  }

  public double StartingDistance
  {
    get
    {
      if (!this.m_ExistingElementCheckBox.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_StartingDistanceTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public TopographySurfaceContainer Surface
  {
    get
    {
      TopographySurfaceContainer surface = (TopographySurfaceContainer) null;
      if (this.m_SurfaceList.SelectedItem is ToposurfaceItem selectedItem)
        surface = selectedItem.Value;
      return surface;
    }
  }

  public bool PickToposurface => this.m_ToposurfaceCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ParkingSpaceTabPage = new TabPage();
    this.m_LoadParkingFamilyButton = new Button();
    this.m_ParkingPlacementGroupBox = new GroupBox();
    this.m_ParkingAreaSettingsButton = new Button();
    this.m_ParkingAreaRadioButton = new RadioButton();
    this.m_ParkingDoubleRowRadioButton = new RadioButton();
    this.m_ParkingSingleRowRadioButton = new RadioButton();
    this.m_ParkingLengthTextBox = new TextBox();
    this.m_ParkingLengthLabel = new Label();
    this.m_ParkingAngleLabel = new Label();
    this.m_ParkingAngleTextBox = new TextBox();
    this.m_ParkingWidthTextBox = new TextBox();
    this.m_ParkingWidthLabel = new Label();
    this.m_ParkingNameComboBox = new ComboBox();
    this.m_ParkingNameLabel = new Label();
    this.m_ParkingFamilyComboBox = new ComboBox();
    this.m_ParkingFamilyLabel = new Label();
    this.m_LevelComboBox = new ComboBox();
    this.m_LevelLabel = new Label();
    this.m_ParkingLotTabControl = new TabControl();
    this.m_ADASpaceTabPage = new TabPage();
    this.m_ADASharedAccessibleAisleCheckBox = new CheckBox();
    this.m_LoadADAFamilyButton = new Button();
    this.m_ADAPlaceParkingSpacesCheckBox = new CheckBox();
    this.m_ADANumberOfSpacesTextBox = new TextBox();
    this.m_ADANumberOfSpacesLabel = new Label();
    this.m_ADAWidthTextBox = new TextBox();
    this.m_ADAWidthLabel = new Label();
    this.m_ADAFamilyNameComboBox = new ComboBox();
    this.m_ADAFamilyNameLabel = new Label();
    this.m_ADAFamilyComboBox = new ComboBox();
    this.m_ADAFamilyLabel = new Label();
    this.m_BumperTabPage = new TabPage();
    this.m_LoadBumperFamilyButton = new Button();
    this.m_BumperHeightTextBox = new TextBox();
    this.m_BumperHeightLabel = new Label();
    this.m_BumperOffsetTextBox = new TextBox();
    this.m_BumperOffsetLabel = new Label();
    this.m_BumperSetbackTextBox = new TextBox();
    this.m_BumperSetbackLabel = new Label();
    this.m_BumperPlaceCheckBox = new CheckBox();
    this.m_BumperWidthTextBox = new TextBox();
    this.m_BumperWidthLabel = new Label();
    this.m_BumperFamilyNameComboBox = new ComboBox();
    this.m_BumperFamilyNameLabel = new Label();
    this.m_BumperFamilyComboBox = new ComboBox();
    this.m_BumperFamilyLabel = new Label();
    this.m_IslandTabPage = new TabPage();
    this.m_LoadIslandFamilyButton = new Button();
    this.m_IslandHeightTextBox = new TextBox();
    this.m_IslandHeightLabel = new Label();
    this.m_IslandPlaceCheckBox = new CheckBox();
    this.m_IslandWidthTextBox = new TextBox();
    this.m_IslandWidthLabel = new Label();
    this.m_IslandFamilyNameComboBox = new ComboBox();
    this.m_IslandFamilyNameLabel = new Label();
    this.m_IslandFamilyComboBox = new ComboBox();
    this.m_IslandFamilyLabel = new Label();
    this.m_ParkingNumberOfSpacesTextBox = new TextBox();
    this.m_ParkingNumberOfSpacesLabel = new Label();
    this.m_ParkingByNumberRadioButton = new RadioButton();
    this.m_OptimizePanel = new Panel();
    this.m_ParkingChainRadioButton = new RadioButton();
    this.m_ParkingSegmentRadioButton = new RadioButton();
    this.m_ParkingOptimizeRadioButton = new RadioButton();
    this.m_ExistingElementCheckBox = new CheckBox();
    this.m_MoveablePanel = new Panel();
    this.m_StartingDistanceLabel = new Label();
    this.m_StartingDistanceTextBox = new TextBox();
    this.m_DeleteExistingCheckBox = new CheckBox();
    this.m_InsertButton = new Button();
    this.m_CancelButton = new Button();
    this.m_ToposurfacePickerPanel = new Panel();
    this.m_SurfaceList = new ComboBox();
    this.m_SelectedSurfaceLabel = new Label();
    this.m_ToposurfaceCheckBox = new CheckBox();
    this.m_ParkingSpaceTabPage.SuspendLayout();
    this.m_ParkingPlacementGroupBox.SuspendLayout();
    this.m_ParkingLotTabControl.SuspendLayout();
    this.m_ADASpaceTabPage.SuspendLayout();
    this.m_BumperTabPage.SuspendLayout();
    this.m_IslandTabPage.SuspendLayout();
    this.m_OptimizePanel.SuspendLayout();
    this.m_MoveablePanel.SuspendLayout();
    this.m_ToposurfacePickerPanel.SuspendLayout();
    this.SuspendLayout();
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_LoadParkingFamilyButton);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingPlacementGroupBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingLengthTextBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingLengthLabel);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingAngleLabel);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingAngleTextBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingWidthTextBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingWidthLabel);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingNameComboBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingNameLabel);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingFamilyComboBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_ParkingFamilyLabel);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_LevelComboBox);
    this.m_ParkingSpaceTabPage.Controls.Add((Control) this.m_LevelLabel);
    this.m_ParkingSpaceTabPage.Location = new Point(4, 22);
    this.m_ParkingSpaceTabPage.Name = "m_ParkingSpaceTabPage";
    this.m_ParkingSpaceTabPage.Padding = new Padding(3);
    this.m_ParkingSpaceTabPage.Size = new Size(412, 193);
    this.m_ParkingSpaceTabPage.TabIndex = 0;
    this.m_ParkingSpaceTabPage.Text = "Parking Style";
    this.m_ParkingSpaceTabPage.UseVisualStyleBackColor = true;
    this.m_LoadParkingFamilyButton.Location = new Point(324, 61);
    this.m_LoadParkingFamilyButton.Name = "m_LoadParkingFamilyButton";
    this.m_LoadParkingFamilyButton.Size = new Size(24, 20);
    this.m_LoadParkingFamilyButton.TabIndex = 4;
    this.m_LoadParkingFamilyButton.TabStop = false;
    this.m_LoadParkingFamilyButton.Text = "...";
    this.m_LoadParkingFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadParkingFamilyButton.Click += new EventHandler(this.OnLoadParkingFamilyButtonClick);
    this.m_ParkingPlacementGroupBox.Controls.Add((Control) this.m_ParkingAreaSettingsButton);
    this.m_ParkingPlacementGroupBox.Controls.Add((Control) this.m_ParkingAreaRadioButton);
    this.m_ParkingPlacementGroupBox.Controls.Add((Control) this.m_ParkingDoubleRowRadioButton);
    this.m_ParkingPlacementGroupBox.Controls.Add((Control) this.m_ParkingSingleRowRadioButton);
    this.m_ParkingPlacementGroupBox.Location = new Point(6, 6);
    this.m_ParkingPlacementGroupBox.Name = "m_ParkingPlacementGroupBox";
    this.m_ParkingPlacementGroupBox.Size = new Size(400, 48 /*0x30*/);
    this.m_ParkingPlacementGroupBox.TabIndex = 1;
    this.m_ParkingPlacementGroupBox.TabStop = false;
    this.m_ParkingPlacementGroupBox.Text = "Parking Placement";
    this.m_ParkingAreaSettingsButton.Enabled = false;
    this.m_ParkingAreaSettingsButton.Location = new Point(318, 16 /*0x10*/);
    this.m_ParkingAreaSettingsButton.Name = "m_ParkingAreaSettingsButton";
    this.m_ParkingAreaSettingsButton.Size = new Size(75, 23);
    this.m_ParkingAreaSettingsButton.TabIndex = 3;
    this.m_ParkingAreaSettingsButton.Text = "Se&ttings";
    this.m_ParkingAreaSettingsButton.UseVisualStyleBackColor = true;
    this.m_ParkingAreaSettingsButton.Click += new EventHandler(this.OnParkingAreaSettingsButtonClick);
    this.m_ParkingAreaRadioButton.AutoSize = true;
    this.m_ParkingAreaRadioButton.Location = new Point(239, 19);
    this.m_ParkingAreaRadioButton.Name = "m_ParkingAreaRadioButton";
    this.m_ParkingAreaRadioButton.Size = new Size(47, 17);
    this.m_ParkingAreaRadioButton.TabIndex = 2;
    this.m_ParkingAreaRadioButton.TabStop = true;
    this.m_ParkingAreaRadioButton.Text = "&Area";
    this.m_ParkingAreaRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingAreaRadioButton.CheckedChanged += new EventHandler(this.OnParkingPlacementOptionsChecked);
    this.m_ParkingDoubleRowRadioButton.AutoSize = true;
    this.m_ParkingDoubleRowRadioButton.Location = new Point(113, 19);
    this.m_ParkingDoubleRowRadioButton.Name = "m_ParkingDoubleRowRadioButton";
    this.m_ParkingDoubleRowRadioButton.Size = new Size(84, 17);
    this.m_ParkingDoubleRowRadioButton.TabIndex = 1;
    this.m_ParkingDoubleRowRadioButton.TabStop = true;
    this.m_ParkingDoubleRowRadioButton.Text = "&Double Row";
    this.m_ParkingDoubleRowRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingDoubleRowRadioButton.CheckedChanged += new EventHandler(this.OnParkingPlacementOptionsChecked);
    this.m_ParkingSingleRowRadioButton.AutoSize = true;
    this.m_ParkingSingleRowRadioButton.Location = new Point(6, 19);
    this.m_ParkingSingleRowRadioButton.Name = "m_ParkingSingleRowRadioButton";
    this.m_ParkingSingleRowRadioButton.Size = new Size(79, 17);
    this.m_ParkingSingleRowRadioButton.TabIndex = 0;
    this.m_ParkingSingleRowRadioButton.TabStop = true;
    this.m_ParkingSingleRowRadioButton.Text = "&Single Row";
    this.m_ParkingSingleRowRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingSingleRowRadioButton.CheckedChanged += new EventHandler(this.OnParkingPlacementOptionsChecked);
    this.m_ParkingLengthTextBox.Location = new Point(99, 141);
    this.m_ParkingLengthTextBox.Name = "m_ParkingLengthTextBox";
    this.m_ParkingLengthTextBox.Size = new Size(100, 20);
    this.m_ParkingLengthTextBox.TabIndex = 10;
    this.m_ParkingLengthTextBox.KeyDown += new KeyEventHandler(this.OnParkingLengthTextBoxKeyDown);
    this.m_ParkingLengthTextBox.Leave += new EventHandler(this.OnParkingLengthTextBoxLeave);
    this.m_ParkingLengthLabel.AutoSize = true;
    this.m_ParkingLengthLabel.Location = new Point(6, 144 /*0x90*/);
    this.m_ParkingLengthLabel.Name = "m_ParkingLengthLabel";
    this.m_ParkingLengthLabel.Size = new Size(43, 13);
    this.m_ParkingLengthLabel.TabIndex = 9;
    this.m_ParkingLengthLabel.Text = "&Length:";
    this.m_ParkingAngleLabel.AutoSize = true;
    this.m_ParkingAngleLabel.Location = new Point(216, 144 /*0x90*/);
    this.m_ParkingAngleLabel.Name = "m_ParkingAngleLabel";
    this.m_ParkingAngleLabel.Size = new Size(37, 13);
    this.m_ParkingAngleLabel.TabIndex = 11;
    this.m_ParkingAngleLabel.Text = "Angle:";
    this.m_ParkingAngleTextBox.Location = new Point(299, 141);
    this.m_ParkingAngleTextBox.Name = "m_ParkingAngleTextBox";
    this.m_ParkingAngleTextBox.Size = new Size(100, 20);
    this.m_ParkingAngleTextBox.TabIndex = 12;
    this.m_ParkingAngleTextBox.KeyDown += new KeyEventHandler(this.OnParkingAngleTextBoxKeyDown);
    this.m_ParkingAngleTextBox.Leave += new EventHandler(this.OnParkingAngleTextBoxLeave);
    this.m_ParkingWidthTextBox.Location = new Point(99, 167);
    this.m_ParkingWidthTextBox.Name = "m_ParkingWidthTextBox";
    this.m_ParkingWidthTextBox.Size = new Size(100, 20);
    this.m_ParkingWidthTextBox.TabIndex = 0;
    this.m_ParkingWidthTextBox.KeyDown += new KeyEventHandler(this.OnParkingWidthTextBoxKeyDown);
    this.m_ParkingWidthTextBox.Leave += new EventHandler(this.OnParkingWidthTextBoxLeave);
    this.m_ParkingWidthLabel.AutoSize = true;
    this.m_ParkingWidthLabel.Location = new Point(6, 170);
    this.m_ParkingWidthLabel.Name = "m_ParkingWidthLabel";
    this.m_ParkingWidthLabel.Size = new Size(38, 13);
    this.m_ParkingWidthLabel.TabIndex = 13;
    this.m_ParkingWidthLabel.Text = "&Width:";
    this.m_ParkingNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ParkingNameComboBox.FormattingEnabled = true;
    this.m_ParkingNameComboBox.Location = new Point(99, 87);
    this.m_ParkingNameComboBox.Name = "m_ParkingNameComboBox";
    this.m_ParkingNameComboBox.Size = new Size(219, 21);
    this.m_ParkingNameComboBox.TabIndex = 6;
    this.m_ParkingNameLabel.AutoSize = true;
    this.m_ParkingNameLabel.Location = new Point(6, 90);
    this.m_ParkingNameLabel.Name = "m_ParkingNameLabel";
    this.m_ParkingNameLabel.Size = new Size(38, 13);
    this.m_ParkingNameLabel.TabIndex = 5;
    this.m_ParkingNameLabel.Text = "&Name:";
    this.m_ParkingFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ParkingFamilyComboBox.FormattingEnabled = true;
    this.m_ParkingFamilyComboBox.Location = new Point(99, 60);
    this.m_ParkingFamilyComboBox.Name = "m_ParkingFamilyComboBox";
    this.m_ParkingFamilyComboBox.Size = new Size(219, 21);
    this.m_ParkingFamilyComboBox.TabIndex = 3;
    this.m_ParkingFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnParkingFamilyComboBoxSelectedIndexChanged);
    this.m_ParkingFamilyLabel.AutoSize = true;
    this.m_ParkingFamilyLabel.Location = new Point(6, 63 /*0x3F*/);
    this.m_ParkingFamilyLabel.Name = "m_ParkingFamilyLabel";
    this.m_ParkingFamilyLabel.Size = new Size(39, 13);
    this.m_ParkingFamilyLabel.TabIndex = 2;
    this.m_ParkingFamilyLabel.Text = "&Family:";
    this.m_LevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LevelComboBox.FormattingEnabled = true;
    this.m_LevelComboBox.Location = new Point(99, 114);
    this.m_LevelComboBox.Name = "m_LevelComboBox";
    this.m_LevelComboBox.Size = new Size(219, 21);
    this.m_LevelComboBox.TabIndex = 8;
    this.m_LevelLabel.AutoSize = true;
    this.m_LevelLabel.Location = new Point(6, 117);
    this.m_LevelLabel.Name = "m_LevelLabel";
    this.m_LevelLabel.Size = new Size(36, 13);
    this.m_LevelLabel.TabIndex = 7;
    this.m_LevelLabel.Text = "&Level:";
    this.m_ParkingLotTabControl.Controls.Add((Control) this.m_ParkingSpaceTabPage);
    this.m_ParkingLotTabControl.Controls.Add((Control) this.m_ADASpaceTabPage);
    this.m_ParkingLotTabControl.Controls.Add((Control) this.m_BumperTabPage);
    this.m_ParkingLotTabControl.Controls.Add((Control) this.m_IslandTabPage);
    this.m_ParkingLotTabControl.ItemSize = new Size(58, 18);
    this.m_ParkingLotTabControl.Location = new Point(12, 12);
    this.m_ParkingLotTabControl.Name = "m_ParkingLotTabControl";
    this.m_ParkingLotTabControl.SelectedIndex = 0;
    this.m_ParkingLotTabControl.Size = new Size(420, 219);
    this.m_ParkingLotTabControl.TabIndex = 0;
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADASharedAccessibleAisleCheckBox);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_LoadADAFamilyButton);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAPlaceParkingSpacesCheckBox);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADANumberOfSpacesTextBox);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADANumberOfSpacesLabel);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAWidthTextBox);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAWidthLabel);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAFamilyNameComboBox);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAFamilyNameLabel);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAFamilyComboBox);
    this.m_ADASpaceTabPage.Controls.Add((Control) this.m_ADAFamilyLabel);
    this.m_ADASpaceTabPage.Location = new Point(4, 22);
    this.m_ADASpaceTabPage.Name = "m_ADASpaceTabPage";
    this.m_ADASpaceTabPage.Padding = new Padding(3);
    this.m_ADASpaceTabPage.Size = new Size(412, 193);
    this.m_ADASpaceTabPage.TabIndex = 1;
    this.m_ADASpaceTabPage.Text = "ADA Spacing";
    this.m_ADASpaceTabPage.UseVisualStyleBackColor = true;
    this.m_ADASharedAccessibleAisleCheckBox.AutoSize = true;
    this.m_ADASharedAccessibleAisleCheckBox.Enabled = false;
    this.m_ADASharedAccessibleAisleCheckBox.Location = new Point(6, 136);
    this.m_ADASharedAccessibleAisleCheckBox.Name = "m_ADASharedAccessibleAisleCheckBox";
    this.m_ADASharedAccessibleAisleCheckBox.Size = new Size(139, 17);
    this.m_ADASharedAccessibleAisleCheckBox.TabIndex = 10;
    this.m_ADASharedAccessibleAisleCheckBox.Text = "S&hared Accessible Aisle";
    this.m_ADASharedAccessibleAisleCheckBox.UseVisualStyleBackColor = true;
    this.m_LoadADAFamilyButton.Location = new Point(368, 31 /*0x1F*/);
    this.m_LoadADAFamilyButton.Name = "m_LoadADAFamilyButton";
    this.m_LoadADAFamilyButton.Size = new Size(24, 20);
    this.m_LoadADAFamilyButton.TabIndex = 3;
    this.m_LoadADAFamilyButton.TabStop = false;
    this.m_LoadADAFamilyButton.Text = "...";
    this.m_LoadADAFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadADAFamilyButton.Click += new EventHandler(this.OnLoadADAFamilyButtonClick);
    this.m_ADAPlaceParkingSpacesCheckBox.AutoSize = true;
    this.m_ADAPlaceParkingSpacesCheckBox.Location = new Point(7, 7);
    this.m_ADAPlaceParkingSpacesCheckBox.Name = "m_ADAPlaceParkingSpacesCheckBox";
    this.m_ADAPlaceParkingSpacesCheckBox.Size = new Size(156, 17);
    this.m_ADAPlaceParkingSpacesCheckBox.TabIndex = 0;
    this.m_ADAPlaceParkingSpacesCheckBox.Text = "Place &ADA Parking Spaces";
    this.m_ADAPlaceParkingSpacesCheckBox.UseVisualStyleBackColor = true;
    this.m_ADAPlaceParkingSpacesCheckBox.CheckStateChanged += new EventHandler(this.OnADAPlaceParkingSpacesCheckBoxChecked);
    this.m_ADANumberOfSpacesTextBox.Enabled = false;
    this.m_ADANumberOfSpacesTextBox.Location = new Point(143, 110);
    this.m_ADANumberOfSpacesTextBox.Name = "m_ADANumberOfSpacesTextBox";
    this.m_ADANumberOfSpacesTextBox.Size = new Size(100, 20);
    this.m_ADANumberOfSpacesTextBox.TabIndex = 9;
    this.m_ADANumberOfSpacesLabel.AutoSize = true;
    this.m_ADANumberOfSpacesLabel.Enabled = false;
    this.m_ADANumberOfSpacesLabel.Location = new Point(4, 113);
    this.m_ADANumberOfSpacesLabel.Name = "m_ADANumberOfSpacesLabel";
    this.m_ADANumberOfSpacesLabel.Size = new Size(98, 13);
    this.m_ADANumberOfSpacesLabel.TabIndex = 8;
    this.m_ADANumberOfSpacesLabel.Text = "N&umber of Spaces:";
    this.m_ADAWidthTextBox.Enabled = false;
    this.m_ADAWidthTextBox.Location = new Point(143, 84);
    this.m_ADAWidthTextBox.Name = "m_ADAWidthTextBox";
    this.m_ADAWidthTextBox.Size = new Size(100, 20);
    this.m_ADAWidthTextBox.TabIndex = 7;
    this.m_ADAWidthTextBox.KeyDown += new KeyEventHandler(this.OnADAParkingWidthTextBoxKeyDown);
    this.m_ADAWidthTextBox.Leave += new EventHandler(this.OnADAParkingWidthTextBoxLeave);
    this.m_ADAWidthLabel.AutoSize = true;
    this.m_ADAWidthLabel.Enabled = false;
    this.m_ADAWidthLabel.Location = new Point(6, 87);
    this.m_ADAWidthLabel.Name = "m_ADAWidthLabel";
    this.m_ADAWidthLabel.Size = new Size(38, 13);
    this.m_ADAWidthLabel.TabIndex = 6;
    this.m_ADAWidthLabel.Text = "&Width:";
    this.m_ADAFamilyNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ADAFamilyNameComboBox.Enabled = false;
    this.m_ADAFamilyNameComboBox.FormattingEnabled = true;
    this.m_ADAFamilyNameComboBox.Location = new Point(143, 57);
    this.m_ADAFamilyNameComboBox.Name = "m_ADAFamilyNameComboBox";
    this.m_ADAFamilyNameComboBox.Size = new Size(219, 21);
    this.m_ADAFamilyNameComboBox.TabIndex = 5;
    this.m_ADAFamilyNameLabel.AutoSize = true;
    this.m_ADAFamilyNameLabel.Enabled = false;
    this.m_ADAFamilyNameLabel.Location = new Point(6, 60);
    this.m_ADAFamilyNameLabel.Name = "m_ADAFamilyNameLabel";
    this.m_ADAFamilyNameLabel.Size = new Size(38, 13);
    this.m_ADAFamilyNameLabel.TabIndex = 4;
    this.m_ADAFamilyNameLabel.Text = "&Name:";
    this.m_ADAFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ADAFamilyComboBox.Enabled = false;
    this.m_ADAFamilyComboBox.FormattingEnabled = true;
    this.m_ADAFamilyComboBox.Location = new Point(143, 30);
    this.m_ADAFamilyComboBox.Name = "m_ADAFamilyComboBox";
    this.m_ADAFamilyComboBox.Size = new Size(219, 21);
    this.m_ADAFamilyComboBox.TabIndex = 2;
    this.m_ADAFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnADAFamilyComboBoxSelectedIndexChanged);
    this.m_ADAFamilyLabel.AutoSize = true;
    this.m_ADAFamilyLabel.Enabled = false;
    this.m_ADAFamilyLabel.Location = new Point(6, 33);
    this.m_ADAFamilyLabel.Name = "m_ADAFamilyLabel";
    this.m_ADAFamilyLabel.Size = new Size(39, 13);
    this.m_ADAFamilyLabel.TabIndex = 1;
    this.m_ADAFamilyLabel.Text = "&Family:";
    this.m_BumperTabPage.Controls.Add((Control) this.m_LoadBumperFamilyButton);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperHeightTextBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperHeightLabel);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperOffsetTextBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperOffsetLabel);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperSetbackTextBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperSetbackLabel);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperPlaceCheckBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperWidthTextBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperWidthLabel);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperFamilyNameComboBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperFamilyNameLabel);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperFamilyComboBox);
    this.m_BumperTabPage.Controls.Add((Control) this.m_BumperFamilyLabel);
    this.m_BumperTabPage.Location = new Point(4, 22);
    this.m_BumperTabPage.Name = "m_BumperTabPage";
    this.m_BumperTabPage.Size = new Size(412, 193);
    this.m_BumperTabPage.TabIndex = 2;
    this.m_BumperTabPage.Text = "Bumper";
    this.m_BumperTabPage.UseVisualStyleBackColor = true;
    this.m_LoadBumperFamilyButton.Location = new Point(368, 31 /*0x1F*/);
    this.m_LoadBumperFamilyButton.Name = "m_LoadBumperFamilyButton";
    this.m_LoadBumperFamilyButton.Size = new Size(24, 20);
    this.m_LoadBumperFamilyButton.TabIndex = 3;
    this.m_LoadBumperFamilyButton.TabStop = false;
    this.m_LoadBumperFamilyButton.Text = "...";
    this.m_LoadBumperFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadBumperFamilyButton.Click += new EventHandler(this.OnLoadBumperFamilyButtonClick);
    this.m_BumperHeightTextBox.Enabled = false;
    this.m_BumperHeightTextBox.Location = new Point(143, 162);
    this.m_BumperHeightTextBox.Name = "m_BumperHeightTextBox";
    this.m_BumperHeightTextBox.Size = new Size(100, 20);
    this.m_BumperHeightTextBox.TabIndex = 13;
    this.m_BumperHeightTextBox.KeyDown += new KeyEventHandler(this.OnBumperHeightTextBoxKeyDown);
    this.m_BumperHeightTextBox.Leave += new EventHandler(this.OnBumperHeightTextBoxLeave);
    this.m_BumperHeightLabel.AutoSize = true;
    this.m_BumperHeightLabel.Enabled = false;
    this.m_BumperHeightLabel.Location = new Point(6, 165);
    this.m_BumperHeightLabel.Name = "m_BumperHeightLabel";
    this.m_BumperHeightLabel.Size = new Size(41, 13);
    this.m_BumperHeightLabel.TabIndex = 12;
    this.m_BumperHeightLabel.Text = "&Height:";
    this.m_BumperOffsetTextBox.Enabled = false;
    this.m_BumperOffsetTextBox.Location = new Point(143, 110);
    this.m_BumperOffsetTextBox.Name = "m_BumperOffsetTextBox";
    this.m_BumperOffsetTextBox.Size = new Size(100, 20);
    this.m_BumperOffsetTextBox.TabIndex = 9;
    this.m_BumperOffsetTextBox.KeyDown += new KeyEventHandler(this.OnBumperOffsetTextBoxKeyDown);
    this.m_BumperOffsetTextBox.Leave += new EventHandler(this.OnBumperOffsetTextBoxLeave);
    this.m_BumperOffsetLabel.AutoSize = true;
    this.m_BumperOffsetLabel.Enabled = false;
    this.m_BumperOffsetLabel.Location = new Point(6, 113);
    this.m_BumperOffsetLabel.Name = "m_BumperOffsetLabel";
    this.m_BumperOffsetLabel.Size = new Size(38, 13);
    this.m_BumperOffsetLabel.TabIndex = 8;
    this.m_BumperOffsetLabel.Text = "&Offset:";
    this.m_BumperSetbackTextBox.Enabled = false;
    this.m_BumperSetbackTextBox.Location = new Point(143, 84);
    this.m_BumperSetbackTextBox.Name = "m_BumperSetbackTextBox";
    this.m_BumperSetbackTextBox.Size = new Size(100, 20);
    this.m_BumperSetbackTextBox.TabIndex = 7;
    this.m_BumperSetbackTextBox.KeyDown += new KeyEventHandler(this.OnBumperSetbackTextBoxKeyDown);
    this.m_BumperSetbackTextBox.Leave += new EventHandler(this.OnBumperSetbackTextBoxLeave);
    this.m_BumperSetbackLabel.AutoSize = true;
    this.m_BumperSetbackLabel.Enabled = false;
    this.m_BumperSetbackLabel.Location = new Point(6, 87);
    this.m_BumperSetbackLabel.Name = "m_BumperSetbackLabel";
    this.m_BumperSetbackLabel.Size = new Size(50, 13);
    this.m_BumperSetbackLabel.TabIndex = 6;
    this.m_BumperSetbackLabel.Text = "&Setback:";
    this.m_BumperPlaceCheckBox.AutoSize = true;
    this.m_BumperPlaceCheckBox.Location = new Point(7, 7);
    this.m_BumperPlaceCheckBox.Name = "m_BumperPlaceCheckBox";
    this.m_BumperPlaceCheckBox.Size = new Size(97, 17);
    this.m_BumperPlaceCheckBox.TabIndex = 0;
    this.m_BumperPlaceCheckBox.Text = "Place &Bumpers";
    this.m_BumperPlaceCheckBox.UseVisualStyleBackColor = true;
    this.m_BumperPlaceCheckBox.CheckStateChanged += new EventHandler(this.OnBumperPlaceCheckBoxChecked);
    this.m_BumperWidthTextBox.Enabled = false;
    this.m_BumperWidthTextBox.Location = new Point(143, 136);
    this.m_BumperWidthTextBox.Name = "m_BumperWidthTextBox";
    this.m_BumperWidthTextBox.Size = new Size(100, 20);
    this.m_BumperWidthTextBox.TabIndex = 11;
    this.m_BumperWidthTextBox.KeyDown += new KeyEventHandler(this.OnBumperWidthTextBoxKeyDown);
    this.m_BumperWidthTextBox.Leave += new EventHandler(this.OnBumperWidthTextBoxLeave);
    this.m_BumperWidthLabel.AutoSize = true;
    this.m_BumperWidthLabel.Enabled = false;
    this.m_BumperWidthLabel.Location = new Point(6, 139);
    this.m_BumperWidthLabel.Name = "m_BumperWidthLabel";
    this.m_BumperWidthLabel.Size = new Size(38, 13);
    this.m_BumperWidthLabel.TabIndex = 10;
    this.m_BumperWidthLabel.Text = "&Width:";
    this.m_BumperFamilyNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_BumperFamilyNameComboBox.Enabled = false;
    this.m_BumperFamilyNameComboBox.FormattingEnabled = true;
    this.m_BumperFamilyNameComboBox.Location = new Point(143, 57);
    this.m_BumperFamilyNameComboBox.Name = "m_BumperFamilyNameComboBox";
    this.m_BumperFamilyNameComboBox.Size = new Size(219, 21);
    this.m_BumperFamilyNameComboBox.TabIndex = 5;
    this.m_BumperFamilyNameLabel.AutoSize = true;
    this.m_BumperFamilyNameLabel.Enabled = false;
    this.m_BumperFamilyNameLabel.Location = new Point(6, 60);
    this.m_BumperFamilyNameLabel.Name = "m_BumperFamilyNameLabel";
    this.m_BumperFamilyNameLabel.Size = new Size(38, 13);
    this.m_BumperFamilyNameLabel.TabIndex = 4;
    this.m_BumperFamilyNameLabel.Text = "&Name:";
    this.m_BumperFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_BumperFamilyComboBox.Enabled = false;
    this.m_BumperFamilyComboBox.FormattingEnabled = true;
    this.m_BumperFamilyComboBox.Location = new Point(143, 30);
    this.m_BumperFamilyComboBox.Name = "m_BumperFamilyComboBox";
    this.m_BumperFamilyComboBox.Size = new Size(219, 21);
    this.m_BumperFamilyComboBox.TabIndex = 2;
    this.m_BumperFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnBumperFamilyComboBoxSelectedIndexChanged);
    this.m_BumperFamilyLabel.AutoSize = true;
    this.m_BumperFamilyLabel.Enabled = false;
    this.m_BumperFamilyLabel.Location = new Point(6, 33);
    this.m_BumperFamilyLabel.Name = "m_BumperFamilyLabel";
    this.m_BumperFamilyLabel.Size = new Size(39, 13);
    this.m_BumperFamilyLabel.TabIndex = 1;
    this.m_BumperFamilyLabel.Text = "&Family:";
    this.m_IslandTabPage.Controls.Add((Control) this.m_LoadIslandFamilyButton);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandHeightTextBox);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandHeightLabel);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandPlaceCheckBox);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandWidthTextBox);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandWidthLabel);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandFamilyNameComboBox);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandFamilyNameLabel);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandFamilyComboBox);
    this.m_IslandTabPage.Controls.Add((Control) this.m_IslandFamilyLabel);
    this.m_IslandTabPage.Location = new Point(4, 22);
    this.m_IslandTabPage.Name = "m_IslandTabPage";
    this.m_IslandTabPage.Size = new Size(412, 193);
    this.m_IslandTabPage.TabIndex = 3;
    this.m_IslandTabPage.Text = "Island";
    this.m_IslandTabPage.UseVisualStyleBackColor = true;
    this.m_LoadIslandFamilyButton.Location = new Point(368, 31 /*0x1F*/);
    this.m_LoadIslandFamilyButton.Name = "m_LoadIslandFamilyButton";
    this.m_LoadIslandFamilyButton.Size = new Size(24, 20);
    this.m_LoadIslandFamilyButton.TabIndex = 3;
    this.m_LoadIslandFamilyButton.TabStop = false;
    this.m_LoadIslandFamilyButton.Text = "...";
    this.m_LoadIslandFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadIslandFamilyButton.Click += new EventHandler(this.OnLoadIslandFamilyButtonClick);
    this.m_IslandHeightTextBox.Enabled = false;
    this.m_IslandHeightTextBox.Location = new Point(143, 110);
    this.m_IslandHeightTextBox.Name = "m_IslandHeightTextBox";
    this.m_IslandHeightTextBox.Size = new Size(100, 20);
    this.m_IslandHeightTextBox.TabIndex = 9;
    this.m_IslandHeightTextBox.KeyDown += new KeyEventHandler(this.OnIslandHeightTextBoxKeyDown);
    this.m_IslandHeightTextBox.Leave += new EventHandler(this.OnIslandHeightTextBoxLeave);
    this.m_IslandHeightLabel.AutoSize = true;
    this.m_IslandHeightLabel.Enabled = false;
    this.m_IslandHeightLabel.Location = new Point(6, 113);
    this.m_IslandHeightLabel.Name = "m_IslandHeightLabel";
    this.m_IslandHeightLabel.Size = new Size(41, 13);
    this.m_IslandHeightLabel.TabIndex = 8;
    this.m_IslandHeightLabel.Text = "&Height:";
    this.m_IslandPlaceCheckBox.AutoSize = true;
    this.m_IslandPlaceCheckBox.Location = new Point(7, 7);
    this.m_IslandPlaceCheckBox.Name = "m_IslandPlaceCheckBox";
    this.m_IslandPlaceCheckBox.Size = new Size(89, 17);
    this.m_IslandPlaceCheckBox.TabIndex = 0;
    this.m_IslandPlaceCheckBox.Text = "Place &Islands";
    this.m_IslandPlaceCheckBox.UseVisualStyleBackColor = true;
    this.m_IslandPlaceCheckBox.CheckStateChanged += new EventHandler(this.OnIslandPlaceCheckBoxChecked);
    this.m_IslandWidthTextBox.Enabled = false;
    this.m_IslandWidthTextBox.Location = new Point(143, 84);
    this.m_IslandWidthTextBox.Name = "m_IslandWidthTextBox";
    this.m_IslandWidthTextBox.Size = new Size(100, 20);
    this.m_IslandWidthTextBox.TabIndex = 7;
    this.m_IslandWidthTextBox.KeyDown += new KeyEventHandler(this.OnIslandWidthTextBoxKeyDown);
    this.m_IslandWidthTextBox.Leave += new EventHandler(this.OnIslandWidthTextBoxLeave);
    this.m_IslandWidthLabel.AutoSize = true;
    this.m_IslandWidthLabel.Enabled = false;
    this.m_IslandWidthLabel.Location = new Point(6, 87);
    this.m_IslandWidthLabel.Name = "m_IslandWidthLabel";
    this.m_IslandWidthLabel.Size = new Size(38, 13);
    this.m_IslandWidthLabel.TabIndex = 6;
    this.m_IslandWidthLabel.Text = "&Width:";
    this.m_IslandFamilyNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_IslandFamilyNameComboBox.Enabled = false;
    this.m_IslandFamilyNameComboBox.FormattingEnabled = true;
    this.m_IslandFamilyNameComboBox.Location = new Point(143, 57);
    this.m_IslandFamilyNameComboBox.Name = "m_IslandFamilyNameComboBox";
    this.m_IslandFamilyNameComboBox.Size = new Size(219, 21);
    this.m_IslandFamilyNameComboBox.TabIndex = 5;
    this.m_IslandFamilyNameLabel.AutoSize = true;
    this.m_IslandFamilyNameLabel.Enabled = false;
    this.m_IslandFamilyNameLabel.Location = new Point(6, 60);
    this.m_IslandFamilyNameLabel.Name = "m_IslandFamilyNameLabel";
    this.m_IslandFamilyNameLabel.Size = new Size(38, 13);
    this.m_IslandFamilyNameLabel.TabIndex = 4;
    this.m_IslandFamilyNameLabel.Text = "&Name:";
    this.m_IslandFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_IslandFamilyComboBox.Enabled = false;
    this.m_IslandFamilyComboBox.FormattingEnabled = true;
    this.m_IslandFamilyComboBox.Location = new Point(143, 30);
    this.m_IslandFamilyComboBox.Name = "m_IslandFamilyComboBox";
    this.m_IslandFamilyComboBox.Size = new Size(219, 21);
    this.m_IslandFamilyComboBox.TabIndex = 2;
    this.m_IslandFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnIslandFamilyComboBoxSelectedIndexChanged);
    this.m_IslandFamilyLabel.AutoSize = true;
    this.m_IslandFamilyLabel.Enabled = false;
    this.m_IslandFamilyLabel.Location = new Point(6, 33);
    this.m_IslandFamilyLabel.Name = "m_IslandFamilyLabel";
    this.m_IslandFamilyLabel.Size = new Size(39, 13);
    this.m_IslandFamilyLabel.TabIndex = 1;
    this.m_IslandFamilyLabel.Text = "&Family:";
    this.m_ParkingNumberOfSpacesTextBox.Enabled = false;
    this.m_ParkingNumberOfSpacesTextBox.Location = new Point(171, 361);
    this.m_ParkingNumberOfSpacesTextBox.Name = "m_ParkingNumberOfSpacesTextBox";
    this.m_ParkingNumberOfSpacesTextBox.Size = new Size(100, 20);
    this.m_ParkingNumberOfSpacesTextBox.TabIndex = 6;
    this.m_ParkingNumberOfSpacesLabel.AutoSize = true;
    this.m_ParkingNumberOfSpacesLabel.Enabled = false;
    this.m_ParkingNumberOfSpacesLabel.Location = new Point(32 /*0x20*/, 364);
    this.m_ParkingNumberOfSpacesLabel.Name = "m_ParkingNumberOfSpacesLabel";
    this.m_ParkingNumberOfSpacesLabel.Size = new Size(98, 13);
    this.m_ParkingNumberOfSpacesLabel.TabIndex = 5;
    this.m_ParkingNumberOfSpacesLabel.Text = "Nu&mber of Spaces:";
    this.m_ParkingByNumberRadioButton.AutoSize = true;
    this.m_ParkingByNumberRadioButton.Location = new Point(12, 340);
    this.m_ParkingByNumberRadioButton.Name = "m_ParkingByNumberRadioButton";
    this.m_ParkingByNumberRadioButton.Size = new Size(77, 17);
    this.m_ParkingByNumberRadioButton.TabIndex = 4;
    this.m_ParkingByNumberRadioButton.Text = "By N&umber";
    this.m_ParkingByNumberRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingByNumberRadioButton.CheckedChanged += new EventHandler(this.OnParkingOptimizeByNumberOptionChecked);
    this.m_OptimizePanel.Controls.Add((Control) this.m_ParkingChainRadioButton);
    this.m_OptimizePanel.Controls.Add((Control) this.m_ParkingSegmentRadioButton);
    this.m_OptimizePanel.Location = new Point(32 /*0x20*/, 310);
    this.m_OptimizePanel.Name = "m_OptimizePanel";
    this.m_OptimizePanel.Size = new Size(283, 24);
    this.m_OptimizePanel.TabIndex = 3;
    this.m_ParkingChainRadioButton.AutoSize = true;
    this.m_ParkingChainRadioButton.Enabled = false;
    this.m_ParkingChainRadioButton.Location = new Point(139, 3);
    this.m_ParkingChainRadioButton.Name = "m_ParkingChainRadioButton";
    this.m_ParkingChainRadioButton.Size = new Size(52, 17);
    this.m_ParkingChainRadioButton.TabIndex = 1;
    this.m_ParkingChainRadioButton.Text = "&Chain";
    this.m_ParkingChainRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingSegmentRadioButton.AutoSize = true;
    this.m_ParkingSegmentRadioButton.Checked = true;
    this.m_ParkingSegmentRadioButton.Enabled = false;
    this.m_ParkingSegmentRadioButton.Location = new Point(0, 3);
    this.m_ParkingSegmentRadioButton.Name = "m_ParkingSegmentRadioButton";
    this.m_ParkingSegmentRadioButton.Size = new Size(67, 17);
    this.m_ParkingSegmentRadioButton.TabIndex = 0;
    this.m_ParkingSegmentRadioButton.TabStop = true;
    this.m_ParkingSegmentRadioButton.Text = "&Segment";
    this.m_ParkingSegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingOptimizeRadioButton.AutoSize = true;
    this.m_ParkingOptimizeRadioButton.Checked = true;
    this.m_ParkingOptimizeRadioButton.Location = new Point(12, 287);
    this.m_ParkingOptimizeRadioButton.Name = "m_ParkingOptimizeRadioButton";
    this.m_ParkingOptimizeRadioButton.Size = new Size(65, 17);
    this.m_ParkingOptimizeRadioButton.TabIndex = 2;
    this.m_ParkingOptimizeRadioButton.TabStop = true;
    this.m_ParkingOptimizeRadioButton.Text = "&Optimize";
    this.m_ParkingOptimizeRadioButton.UseVisualStyleBackColor = true;
    this.m_ParkingOptimizeRadioButton.CheckedChanged += new EventHandler(this.OnParkingOptimizeByNumberOptionChecked);
    this.m_ExistingElementCheckBox.AutoSize = true;
    this.m_ExistingElementCheckBox.Location = new Point(12, 387);
    this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
    this.m_ExistingElementCheckBox.Size = new Size(103, 17);
    this.m_ExistingElementCheckBox.TabIndex = 7;
    this.m_ExistingElementCheckBox.Text = "&Existing Element";
    this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
    this.m_ExistingElementCheckBox.CheckedChanged += new EventHandler(this.OnExistingElementCheckBoxChecked);
    this.m_MoveablePanel.Controls.Add((Control) this.m_StartingDistanceLabel);
    this.m_MoveablePanel.Controls.Add((Control) this.m_StartingDistanceTextBox);
    this.m_MoveablePanel.Controls.Add((Control) this.m_DeleteExistingCheckBox);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_CancelButton);
    this.m_MoveablePanel.Location = new Point(12, 410);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(420, 72);
    this.m_MoveablePanel.TabIndex = 8;
    this.m_StartingDistanceLabel.AutoSize = true;
    this.m_StartingDistanceLabel.Enabled = false;
    this.m_StartingDistanceLabel.Location = new Point(20, 26);
    this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
    this.m_StartingDistanceLabel.Size = new Size(91, 13);
    this.m_StartingDistanceLabel.TabIndex = 1;
    this.m_StartingDistanceLabel.Text = "Starting Distance:";
    this.m_StartingDistanceTextBox.Enabled = false;
    this.m_StartingDistanceTextBox.Location = new Point(159, 23);
    this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
    this.m_StartingDistanceTextBox.Size = new Size(100, 20);
    this.m_StartingDistanceTextBox.TabIndex = 2;
    this.m_StartingDistanceTextBox.KeyDown += new KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
    this.m_StartingDistanceTextBox.Leave += new EventHandler(this.OnStartingDistanceTextBoxLeave);
    this.m_DeleteExistingCheckBox.AutoSize = true;
    this.m_DeleteExistingCheckBox.Enabled = false;
    this.m_DeleteExistingCheckBox.Location = new Point(20, 0);
    this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
    this.m_DeleteExistingCheckBox.Size = new Size(137, 17);
    this.m_DeleteExistingCheckBox.TabIndex = 0;
    this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
    this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
    this.m_InsertButton.Location = new Point(264, 49);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 3;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnInsertButtonClick);
    this.m_CancelButton.Location = new Point(345, 49);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_ToposurfacePickerPanel.Controls.Add((Control) this.m_SurfaceList);
    this.m_ToposurfacePickerPanel.Controls.Add((Control) this.m_SelectedSurfaceLabel);
    this.m_ToposurfacePickerPanel.Controls.Add((Control) this.m_ToposurfaceCheckBox);
    this.m_ToposurfacePickerPanel.Location = new Point(12, 237);
    this.m_ToposurfacePickerPanel.Name = "m_ToposurfacePickerPanel";
    this.m_ToposurfacePickerPanel.Size = new Size(420, 44);
    this.m_ToposurfacePickerPanel.TabIndex = 1;
    this.m_SurfaceList.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_SurfaceList.Enabled = false;
    this.m_SurfaceList.FormattingEnabled = true;
    this.m_SurfaceList.Location = new Point(107, 23);
    this.m_SurfaceList.Name = "m_SurfaceList";
    this.m_SurfaceList.Size = new Size(219, 21);
    this.m_SurfaceList.TabIndex = 2;
    this.m_SelectedSurfaceLabel.AutoSize = true;
    this.m_SelectedSurfaceLabel.Enabled = false;
    this.m_SelectedSurfaceLabel.Location = new Point(0, 26);
    this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
    this.m_SelectedSurfaceLabel.Size = new Size(44, 13);
    this.m_SelectedSurfaceLabel.TabIndex = 1;
    this.m_SelectedSurfaceLabel.Text = "Surface";
    this.m_ToposurfaceCheckBox.AutoSize = true;
    this.m_ToposurfaceCheckBox.Location = new Point(0, 0);
    this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
    this.m_ToposurfaceCheckBox.Size = new Size(110, 17);
    this.m_ToposurfaceCheckBox.TabIndex = 0;
    this.m_ToposurfaceCheckBox.Text = "Pick Toposurface";
    this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
    this.m_ToposurfaceCheckBox.CheckedChanged += new EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(444, 494);
    this.Controls.Add((Control) this.m_ToposurfacePickerPanel);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.Controls.Add((Control) this.m_ExistingElementCheckBox);
    this.Controls.Add((Control) this.m_ParkingNumberOfSpacesTextBox);
    this.Controls.Add((Control) this.m_ParkingNumberOfSpacesLabel);
    this.Controls.Add((Control) this.m_ParkingByNumberRadioButton);
    this.Controls.Add((Control) this.m_OptimizePanel);
    this.Controls.Add((Control) this.m_ParkingOptimizeRadioButton);
    this.Controls.Add((Control) this.m_ParkingLotTabControl);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ParkingLotPlacementForm);
    this.Text = "Parking Lot";
    this.FormClosing += new FormClosingEventHandler(this.OnParkingLotPlacementFormClosing);
    this.m_ParkingSpaceTabPage.ResumeLayout(false);
    this.m_ParkingSpaceTabPage.PerformLayout();
    this.m_ParkingPlacementGroupBox.ResumeLayout(false);
    this.m_ParkingPlacementGroupBox.PerformLayout();
    this.m_ParkingLotTabControl.ResumeLayout(false);
    this.m_ADASpaceTabPage.ResumeLayout(false);
    this.m_ADASpaceTabPage.PerformLayout();
    this.m_BumperTabPage.ResumeLayout(false);
    this.m_BumperTabPage.PerformLayout();
    this.m_IslandTabPage.ResumeLayout(false);
    this.m_IslandTabPage.PerformLayout();
    this.m_OptimizePanel.ResumeLayout(false);
    this.m_OptimizePanel.PerformLayout();
    this.m_MoveablePanel.ResumeLayout(false);
    this.m_MoveablePanel.PerformLayout();
    this.m_ToposurfacePickerPanel.ResumeLayout(false);
    this.m_ToposurfacePickerPanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
