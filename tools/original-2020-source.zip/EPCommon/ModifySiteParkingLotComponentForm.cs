﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ModifySiteParkingLotComponentForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ModifySiteParkingLotComponentForm : EPForm
{
  private SiteAlignmentAction m_PerformAction;
  private IContainer components;
  private Button m_MoveButton;
  private Button m_RotateButton;
  private Button m_CancelButton;
  private Button m_ApplyButton;
  private Button m_ChangeElevationButton;
  private Button m_AddVertexButton;
  private Button m_DeleteVertexButton;
  private Button m_DeleteButton;
  private Button m_ChangeTypeButton;
  private TextBox m_MessageTextBox;
  private Button m_DeleteBreaklineButton;
  private Button m_AddBreaklineButton;
  private Button m_ChangeViewScaleButton;

  public ModifySiteParkingLotComponentForm()
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ModifyParkingLotDialog");
    this.m_MessageTextBox.Text = EPShared.LocalRM.GetString("ModifySiteComponentInformationDialog");
    this.m_MoveButton.Text = EPShared.LocalRM.GetString("AMP_MoveDialog");
    this.m_RotateButton.Text = EPShared.LocalRM.GetString("AMP_RotateDialog");
    this.m_AddVertexButton.Text = EPShared.LocalRM.GetString("Add_AMP_VertexDialog");
    this.m_DeleteVertexButton.Text = EPShared.LocalRM.GetString("D_AMP_eleteVertexDialog");
    this.m_ChangeElevationButton.Text = EPShared.LocalRM.GetString("AMP_ChangeElevationDialog");
    this.m_ChangeTypeButton.Text = EPShared.LocalRM.GetString("C_AMP_hangeTypeDialog");
    this.m_AddBreaklineButton.Text = EPShared.LocalRM.GetString("Add_AMP_BreaklineDialog");
    this.m_DeleteBreaklineButton.Text = EPShared.LocalRM.GetString("De_AMP_leteBreaklineDialog");
    this.m_DeleteButton.Text = EPShared.LocalRM.GetString("AMP_DeleteDialog");
    this.m_ChangeViewScaleButton.Text = EPShared.LocalRM.GetString("ChangeView_AMP_ScaleDialog");
    this.m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.ContextualHelpID = "HID_SDparkinglotModify";
    this.InitializeControls();
  }

  private void InitializeControls() => this.GetDialogPosition();

  private void OnMoveButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.Move;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnRotateButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.Rotate;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnChangeElevationButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.ChangeElevationGrade;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnAddVertexButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.AddVertex;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnDeleteVertexButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.DeleteVertex;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnDeleteButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.Delete;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnChangeTypeButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.ChangeType;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnAddBreaklineButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.AddBreakline;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnDeleteBreaklineButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.DeleteBreakline;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnApplyButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnModifySiteComponentClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnChangeViewScaleButtonClick(object sender, EventArgs e)
  {
    this.m_PerformAction = SiteAlignmentAction.ChangeViewScale;
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  public SiteAlignmentAction PerformAction => this.m_PerformAction;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_MoveButton = new Button();
    this.m_RotateButton = new Button();
    this.m_CancelButton = new Button();
    this.m_ApplyButton = new Button();
    this.m_ChangeElevationButton = new Button();
    this.m_AddVertexButton = new Button();
    this.m_DeleteVertexButton = new Button();
    this.m_DeleteButton = new Button();
    this.m_ChangeTypeButton = new Button();
    this.m_MessageTextBox = new TextBox();
    this.m_DeleteBreaklineButton = new Button();
    this.m_AddBreaklineButton = new Button();
    this.m_ChangeViewScaleButton = new Button();
    this.SuspendLayout();
    this.m_MoveButton.Location = new Point(12, 59);
    this.m_MoveButton.Name = "m_MoveButton";
    this.m_MoveButton.Size = new Size(132, 23);
    this.m_MoveButton.TabIndex = 1;
    this.m_MoveButton.Text = "&Move";
    this.m_MoveButton.UseVisualStyleBackColor = true;
    this.m_MoveButton.Click += new EventHandler(this.OnMoveButtonClick);
    this.m_RotateButton.Location = new Point(150, 59);
    this.m_RotateButton.Name = "m_RotateButton";
    this.m_RotateButton.Size = new Size(132, 23);
    this.m_RotateButton.TabIndex = 2;
    this.m_RotateButton.Text = "&Rotate";
    this.m_RotateButton.UseVisualStyleBackColor = true;
    this.m_RotateButton.Click += new EventHandler(this.OnRotateButtonClick);
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(206, 204);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(76, 23);
    this.m_CancelButton.TabIndex = 12;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_ApplyButton.Location = new Point(125, 204);
    this.m_ApplyButton.Name = "m_ApplyButton";
    this.m_ApplyButton.Size = new Size(75, 23);
    this.m_ApplyButton.TabIndex = 11;
    this.m_ApplyButton.Text = "&Apply";
    this.m_ApplyButton.UseVisualStyleBackColor = true;
    this.m_ApplyButton.Click += new EventHandler(this.OnApplyButtonClick);
    this.m_ChangeElevationButton.Location = new Point(12, 117);
    this.m_ChangeElevationButton.Name = "m_ChangeElevationButton";
    this.m_ChangeElevationButton.Size = new Size(132, 23);
    this.m_ChangeElevationButton.TabIndex = 5;
    this.m_ChangeElevationButton.Text = "Change Elevation";
    this.m_ChangeElevationButton.UseVisualStyleBackColor = true;
    this.m_ChangeElevationButton.Click += new EventHandler(this.OnChangeElevationButtonClick);
    this.m_AddVertexButton.Location = new Point(13, 88);
    this.m_AddVertexButton.Name = "m_AddVertexButton";
    this.m_AddVertexButton.Size = new Size(131, 23);
    this.m_AddVertexButton.TabIndex = 3;
    this.m_AddVertexButton.Text = "Add Vertex";
    this.m_AddVertexButton.UseVisualStyleBackColor = true;
    this.m_AddVertexButton.Click += new EventHandler(this.OnAddVertexButtonClick);
    this.m_DeleteVertexButton.Location = new Point(150, 88);
    this.m_DeleteVertexButton.Name = "m_DeleteVertexButton";
    this.m_DeleteVertexButton.Size = new Size(132, 23);
    this.m_DeleteVertexButton.TabIndex = 4;
    this.m_DeleteVertexButton.Text = "Delete Vertex";
    this.m_DeleteVertexButton.UseVisualStyleBackColor = true;
    this.m_DeleteVertexButton.Click += new EventHandler(this.OnDeleteVertexButtonClick);
    this.m_DeleteButton.Location = new Point(13, 175);
    this.m_DeleteButton.Name = "m_DeleteButton";
    this.m_DeleteButton.Size = new Size(131, 23);
    this.m_DeleteButton.TabIndex = 9;
    this.m_DeleteButton.Text = "Delete";
    this.m_DeleteButton.UseVisualStyleBackColor = true;
    this.m_DeleteButton.Click += new EventHandler(this.OnDeleteButtonClick);
    this.m_ChangeTypeButton.Location = new Point(150, 117);
    this.m_ChangeTypeButton.Name = "m_ChangeTypeButton";
    this.m_ChangeTypeButton.Size = new Size(132, 23);
    this.m_ChangeTypeButton.TabIndex = 6;
    this.m_ChangeTypeButton.Text = "Change Type";
    this.m_ChangeTypeButton.UseVisualStyleBackColor = true;
    this.m_ChangeTypeButton.Click += new EventHandler(this.OnChangeTypeButtonClick);
    this.m_MessageTextBox.BackColor = SystemColors.Control;
    this.m_MessageTextBox.BorderStyle = BorderStyle.None;
    this.m_MessageTextBox.Location = new Point(13, 11);
    this.m_MessageTextBox.Multiline = true;
    this.m_MessageTextBox.Name = "m_MessageTextBox";
    this.m_MessageTextBox.Size = new Size(269, 42);
    this.m_MessageTextBox.TabIndex = 0;
    this.m_MessageTextBox.TabStop = false;
    this.m_MessageTextBox.Text = "Please select the edit type you want to do. Press ESC or right-click and Cancel to complete the action.";
    this.m_DeleteBreaklineButton.Location = new Point(150, 146);
    this.m_DeleteBreaklineButton.Name = "m_DeleteBreaklineButton";
    this.m_DeleteBreaklineButton.Size = new Size(132, 23);
    this.m_DeleteBreaklineButton.TabIndex = 8;
    this.m_DeleteBreaklineButton.Text = "Delete Breakline";
    this.m_DeleteBreaklineButton.UseVisualStyleBackColor = true;
    this.m_DeleteBreaklineButton.Click += new EventHandler(this.OnDeleteBreaklineButtonClick);
    this.m_AddBreaklineButton.Location = new Point(12, 146);
    this.m_AddBreaklineButton.Name = "m_AddBreaklineButton";
    this.m_AddBreaklineButton.Size = new Size(132, 23);
    this.m_AddBreaklineButton.TabIndex = 7;
    this.m_AddBreaklineButton.Text = "Add Breakline";
    this.m_AddBreaklineButton.UseVisualStyleBackColor = true;
    this.m_AddBreaklineButton.Click += new EventHandler(this.OnAddBreaklineButtonClick);
    this.m_ChangeViewScaleButton.Location = new Point(150, 175);
    this.m_ChangeViewScaleButton.Name = "m_ChangeViewScaleButton";
    this.m_ChangeViewScaleButton.Size = new Size(132, 23);
    this.m_ChangeViewScaleButton.TabIndex = 10;
    this.m_ChangeViewScaleButton.Text = "Change View Scale";
    this.m_ChangeViewScaleButton.UseVisualStyleBackColor = true;
    this.m_ChangeViewScaleButton.Click += new EventHandler(this.OnChangeViewScaleButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(294, 239);
    this.Controls.Add((Control) this.m_ChangeViewScaleButton);
    this.Controls.Add((Control) this.m_DeleteBreaklineButton);
    this.Controls.Add((Control) this.m_AddBreaklineButton);
    this.Controls.Add((Control) this.m_MessageTextBox);
    this.Controls.Add((Control) this.m_ChangeTypeButton);
    this.Controls.Add((Control) this.m_DeleteButton);
    this.Controls.Add((Control) this.m_DeleteVertexButton);
    this.Controls.Add((Control) this.m_AddVertexButton);
    this.Controls.Add((Control) this.m_ChangeElevationButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_ApplyButton);
    this.Controls.Add((Control) this.m_RotateButton);
    this.Controls.Add((Control) this.m_MoveButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (ModifySiteParkingLotComponentForm);
    this.Text = "Modify Site Component";
    this.FormClosing += new FormClosingEventHandler(this.OnModifySiteComponentClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ApplyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
