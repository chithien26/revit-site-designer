﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlacementType
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public enum PlacementType
{
  HedgeRowCenter = 1,
  HedgeRowAlternate = 2,
  HedgeRowSide = 3,
  GroveTrianglular = 4,
  GroveSquare = 5,
  Single = 6,
  ParkingSingleRow = 7,
  ParkingDoubleRow = 8,
  ParkingArea = 9,
}
