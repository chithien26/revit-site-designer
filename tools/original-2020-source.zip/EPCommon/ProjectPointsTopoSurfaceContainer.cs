﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ProjectPointsTopoSurfaceContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class ProjectPointsTopoSurfaceContainer
{
  private TopographySurfaceContainer m_TopographySurfaceContainer;
  private List<Eps_Point> m_ProjectPoints;

  public ProjectPointsTopoSurfaceContainer(
    TopographySurfaceContainer _TopographySurfaceContainer)
  {
    this.m_TopographySurfaceContainer = _TopographySurfaceContainer;
    this.m_ProjectPoints = new List<Eps_Point>();
  }

  public ProjectPointsTopoSurfaceContainer(
    TopographySurfaceContainer _TopographySurfaceContainer,
    Eps_Point _CurPoint)
  {
    this.m_TopographySurfaceContainer = _TopographySurfaceContainer;
    this.m_ProjectPoints = new List<Eps_Point>();
    this.m_ProjectPoints.Add(_CurPoint);
  }

  public TopographySurfaceContainer TopographySurfaceContainer => this.m_TopographySurfaceContainer;

  public List<Eps_Point> ProjectPoints
  {
    get => this.m_ProjectPoints;
    set => this.m_ProjectPoints = value;
  }
}
