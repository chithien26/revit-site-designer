﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyInstanceAssignmentContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;

#nullable disable
namespace EPCommon;

public class FamilyInstanceAssignmentContainer
{
  private ElementId m_ElementId;
  private ElementId m_FamilyInstanceElementId;
  private FamilyInstance m_FamilyInstance;

  public FamilyInstanceAssignmentContainer(ElementId _ElementId, FamilyInstance _FamilyInstance)
  {
    this.m_ElementId = _ElementId;
    this.m_FamilyInstance = _FamilyInstance;
    if (this.m_FamilyInstance == null)
      return;
    this.m_FamilyInstanceElementId = ((Element) this.m_FamilyInstance).Id;
  }

  public FamilyInstance GetFamilyInstance(Document _CurrentDocument)
  {
    string str = string.Empty;
    try
    {
      str = ((Element) this.m_FamilyInstance).UniqueId;
    }
    catch (Exception ex1)
    {
      switch (ex1)
      {
        case AccessViolationException _:
        case InvalidOperationException _:
          if (!(_CurrentDocument.GetElement(this.m_FamilyInstanceElementId) is FamilyInstance element))
            return (FamilyInstance) null;
          try
          {
            str = ((Element) element).UniqueId;
          }
          catch (Exception ex2)
          {
            switch (ex2)
            {
              case AccessViolationException _:
              case InvalidOperationException _:
                return (FamilyInstance) null;
            }
          }
          this.m_FamilyInstance = element;
          break;
      }
    }
    return this.m_FamilyInstance;
  }

  public ElementId ID => this.m_ElementId;

  public ElementId FamilyInstanceID => this.m_FamilyInstanceElementId;

  public FamilyInstance FamilyInstance
  {
    set => this.m_FamilyInstance = value;
  }
}
