﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.AnnotateForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class AnnotateForm : EPForm
{
  private Annotation m_dataBuffer;
  private IContainer components;
  private Button m_CancelButton;
  private Button m_OKButton;
  private CheckBox m_AnnotateElevCheckBox;
  private CheckBox m_AnnotateGradeCheckBox;
  private ComboBox m_TextTypeComboBox;
  private Label m_TextTypeLabel;
  private CheckBox m_BySharedCoordinatesCheckBox;

  public AnnotateForm(Annotation _dataBuffer)
  {
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDannotate";
    this.m_dataBuffer = _dataBuffer;
    this.SetupString();
    this.InitializeControls();
  }

  private void SetupString()
  {
    this.Text = EPShared.LocalRM.GetString("AnnotateTitleDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_AnnotateElevCheckBox.Text = EPShared.LocalRM.GetString("AMP_ElevationsDialog");
    this.m_AnnotateGradeCheckBox.Text = EPShared.LocalRM.GetString("AMP_GradesDialog");
    this.m_TextTypeLabel.Text = EPShared.LocalRM.GetString("AMP_TextTypeDialog");
    this.m_BySharedCoordinatesCheckBox.Text = EPShared.LocalRM.GetString("B_AMP_ySurveyPointsDialog");
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_TextTypeComboBox.DataSource = (object) this.m_dataBuffer.TextTypeList;
    this.m_TextTypeComboBox.DisplayMember = "Name";
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "AnnotationTextTypeName", ref empty))
    {
      for (int index = 0; index < this.m_TextTypeComboBox.Items.Count; ++index)
      {
        if (this.m_TextTypeComboBox.Items[index] is TextNoteType textNoteType && string.Compare(((Element) textNoteType).Name, empty, true) == 0)
        {
          this.m_TextTypeComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_AnnotateElevCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("AnnotateElevations", ref _nReturnValue))
      this.m_AnnotateElevCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_AnnotateGradeCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("AnnotateGrades", ref _nReturnValue))
      this.m_AnnotateGradeCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_BySharedCoordinatesCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "AnnotateUsingSharedCoordinates", ref _nReturnValue))
    {
      this.m_BySharedCoordinatesCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    }
    else
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "UseSharedElevation", ref _nReturnValue))
        return;
      this.m_BySharedCoordinatesCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "AnnotateUsingSharedCoordinates", Convert.ToInt32(this.m_BySharedCoordinatesCheckBox.Checked));
    }
  }

  private void SaveSettings()
  {
    if (this.m_TextTypeComboBox.SelectedItem is TextNoteType selectedItem)
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "AnnotationTextTypeName", ((Element) selectedItem).Name);
    ApplicationUtility.Settings.eplSetE_SetSetting("AnnotateElevations", Convert.ToInt32(this.m_AnnotateElevCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting("AnnotateGrades", Convert.ToInt32(this.m_AnnotateGradeCheckBox.Checked));
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "AnnotateUsingSharedCoordinates", Convert.ToInt32(this.m_BySharedCoordinatesCheckBox.Checked));
  }

  private void OnFormClosing(object sender, FormClosingEventArgs e) => this.SetDialogPosition();

  private bool CheckBoxStatus()
  {
    return this.m_AnnotateElevCheckBox.Checked || this.m_AnnotateGradeCheckBox.Checked;
  }

  private void OnOkButtonClicked(object sender, EventArgs e)
  {
    if (!this.CheckBoxStatus())
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoOptionsSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.SaveSettings();
      this.DialogResult = DialogResult.OK;
    }
  }

  private void OnCancelButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  public bool AnnotateElevations => this.m_AnnotateElevCheckBox.Checked;

  public bool AnnotateGrades => this.m_AnnotateGradeCheckBox.Checked;

  public TextNoteType TextNoteType => this.m_TextTypeComboBox.SelectedItem as TextNoteType;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_CancelButton = new Button();
    this.m_OKButton = new Button();
    this.m_AnnotateElevCheckBox = new CheckBox();
    this.m_AnnotateGradeCheckBox = new CheckBox();
    this.m_TextTypeComboBox = new ComboBox();
    this.m_TextTypeLabel = new Label();
    this.m_BySharedCoordinatesCheckBox = new CheckBox();
    this.SuspendLayout();
    this.m_CancelButton.Location = new Point(207, 108);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 6;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClicked);
    this.m_OKButton.Location = new Point(126, 108);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 5;
    this.m_OKButton.Text = "Ok";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOkButtonClicked);
    this.m_AnnotateElevCheckBox.AutoSize = true;
    this.m_AnnotateElevCheckBox.Location = new Point(12, 62);
    this.m_AnnotateElevCheckBox.Name = "m_AnnotateElevCheckBox";
    this.m_AnnotateElevCheckBox.Size = new Size(121, 17);
    this.m_AnnotateElevCheckBox.TabIndex = 3;
    this.m_AnnotateElevCheckBox.Text = "Annotate Elevations";
    this.m_AnnotateElevCheckBox.UseVisualStyleBackColor = true;
    this.m_AnnotateGradeCheckBox.AutoSize = true;
    this.m_AnnotateGradeCheckBox.Location = new Point(12, 39);
    this.m_AnnotateGradeCheckBox.Name = "m_AnnotateGradeCheckBox";
    this.m_AnnotateGradeCheckBox.Size = new Size(101, 17);
    this.m_AnnotateGradeCheckBox.TabIndex = 2;
    this.m_AnnotateGradeCheckBox.Text = "Annotate Grade";
    this.m_AnnotateGradeCheckBox.UseVisualStyleBackColor = true;
    this.m_TextTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_TextTypeComboBox.FormattingEnabled = true;
    this.m_TextTypeComboBox.Location = new Point(130, 12);
    this.m_TextTypeComboBox.Name = "m_TextTypeComboBox";
    this.m_TextTypeComboBox.Size = new Size(152, 21);
    this.m_TextTypeComboBox.TabIndex = 1;
    this.m_TextTypeLabel.AutoSize = true;
    this.m_TextTypeLabel.Location = new Point(12, 16 /*0x10*/);
    this.m_TextTypeLabel.Name = "m_TextTypeLabel";
    this.m_TextTypeLabel.Size = new Size(58, 13);
    this.m_TextTypeLabel.TabIndex = 0;
    this.m_TextTypeLabel.Text = "&Text Type:";
    this.m_BySharedCoordinatesCheckBox.AutoSize = true;
    this.m_BySharedCoordinatesCheckBox.Location = new Point(12, 85);
    this.m_BySharedCoordinatesCheckBox.Name = "m_UseSharedCoordinatesCheckBox";
    this.m_BySharedCoordinatesCheckBox.Size = new Size(141, 17);
    this.m_BySharedCoordinatesCheckBox.TabIndex = 4;
    this.m_BySharedCoordinatesCheckBox.Text = "Use Shared Coordinates";
    this.m_BySharedCoordinatesCheckBox.UseVisualStyleBackColor = true;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(294, 143);
    this.Controls.Add((Control) this.m_BySharedCoordinatesCheckBox);
    this.Controls.Add((Control) this.m_TextTypeComboBox);
    this.Controls.Add((Control) this.m_TextTypeLabel);
    this.Controls.Add((Control) this.m_AnnotateElevCheckBox);
    this.Controls.Add((Control) this.m_AnnotateGradeCheckBox);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (AnnotateForm);
    this.Text = "Annotate Site Components";
    this.FormClosing += new FormClosingEventHandler(this.OnFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
