﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ProjectSettingComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

internal class ProjectSettingComparer : IComparer<ProjectSettingContainer>
{
  private bool m_bSortByDateTime = true;
  private bool m_bOrderByDescending;

  public ProjectSettingComparer(bool _bOrderByDescending)
  {
    this.m_bOrderByDescending = _bOrderByDescending;
  }

  int IComparer<ProjectSettingContainer>.Compare(
    ProjectSettingContainer FirstProjectSetting,
    ProjectSettingContainer SecondProjectSetting)
  {
    int num = 0;
    if (this.m_bSortByDateTime)
    {
      if (FirstProjectSetting != null)
        num = SecondProjectSetting == null ? -1 : FirstProjectSetting.CurrentDateTime.CompareTo(SecondProjectSetting.CurrentDateTime);
      else if (SecondProjectSetting != null)
        num = 1;
    }
    if (this.m_bOrderByDescending)
      num = -num;
    return num;
  }
}
