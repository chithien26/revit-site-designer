﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantSearchForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantSearchForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private int m_nInitialSettingsCount;
  private string m_strSettingsPrefix;
  private FormatOptions m_FormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private Button m_CancelButton;
  private Button m_FindButton;
  private ComboBox m_ParameterComboBox;
  private ComboBox m_FilterComboBox;
  private Label m_ParameterLabel;
  private ListView m_SearchPlantListView;
  private Button m_ModifyButton;
  private Button m_AddButton;
  private TextBox m_FilterTextBox;
  private Label m_FilterLabel;
  private Button m_DeleteButton;

  public PlantSearchForm(string _strFormName, Document _Document)
  {
    this.InitializeComponent();
    this.m_nInitialSettingsCount = 0;
    this.Text = _strFormName;
    this.m_ParameterLabel.Text = EPShared.LocalRM.GetString("AMP_ParameterDialog");
    this.m_FilterLabel.Text = EPShared.LocalRM.GetString("Fi_AMP_lterDialog");
    this.m_AddButton.Text = EPShared.LocalRM.GetString("AMP_AddDialog");
    this.m_ModifyButton.Text = EPShared.LocalRM.GetString("AMP_ModifyDialog");
    this.m_DeleteButton.Text = EPShared.LocalRM.GetString("AMP_DeleteDialog");
    this.m_FindButton.Text = EPShared.LocalRM.GetString("AMP_FindDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_strSettingsPrefix = _strFormName.Replace(" ", "");
    this.m_FormatOptions = _Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_DisplayUnitSystem = _Document.DisplayUnitSystem;
    this.m_Units = _Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = _Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int num = 0;
    string empty1 = string.Empty;
    this.GetDialogPosition();
    foreach (string plantAllParamenter in ManagePlants.PlantAllParamenterList())
    {
      if (string.Compare(plantAllParamenter, EPShared.LocalRM.GetString("PlantingSymbolPlantFamilyParameter"), true) != 0 && string.Compare(plantAllParamenter, EPShared.LocalRM.GetString("GenericModelSymbolPlantFamilyParameter"), true) != 0 && string.Compare(plantAllParamenter, EPShared.LocalRM.GetString("PlantCountPlantFamilyParameter"), true) != 0 && string.Compare(plantAllParamenter, EPShared.LocalRM.GetString("PlacementIDFamilyParameter"), true) != 0)
        this.m_ParameterComboBox.Items.Add((object) plantAllParamenter);
    }
    if (this.m_ParameterComboBox.Items.Count > 0)
      this.m_ParameterComboBox.SelectedIndex = 0;
    foreach (object comparison in ManagePlants.ComparisonList())
      this.m_FilterComboBox.Items.Add(comparison);
    if (this.m_FilterComboBox.Items.Count > 0)
      this.m_FilterComboBox.SelectedIndex = 0;
    this.m_SearchPlantListView.View = View.Details;
    this.m_SearchPlantListView.Columns.Add(EPShared.LocalRM.GetString("ParameterString"), 140, HorizontalAlignment.Left);
    this.m_SearchPlantListView.Columns.Add(EPShared.LocalRM.GetString("ComparisonTypeString"), 140, HorizontalAlignment.Left);
    this.m_SearchPlantListView.Columns.Add(EPShared.LocalRM.GetString("FilterString"), 140, HorizontalAlignment.Left);
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    string empty4 = string.Empty;
    while (true)
    {
      ++num;
      if (ApplicationUtility.Settings.eplSetE_GetSetting($"{this.m_strSettingsPrefix}ParameterName{Convert.ToString(num)}", ref empty2) && ApplicationUtility.Settings.eplSetE_GetSetting($"{this.m_strSettingsPrefix}ComparisionType{Convert.ToString(num)}", ref empty3) && ApplicationUtility.Settings.eplSetE_GetSetting($"{this.m_strSettingsPrefix}Filter{Convert.ToString(num)}", ref empty4))
      {
        ListViewItem listViewItem = new ListViewItem(empty2);
        listViewItem.SubItems.Add(empty3);
        if (string.Compare(empty2, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) != 0 && string.Compare(empty2, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), true) != 0 && string.Compare(empty2, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) != 0 && string.Compare(empty2, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) != 0 && string.Compare(empty2, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), true) != 0)
        {
          listViewItem.SubItems.Add(empty4);
        }
        else
        {
          RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(empty4), this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
          listViewItem.SubItems.Add(empty1);
        }
        this.m_SearchPlantListView.Items.Add(listViewItem);
      }
      else
        break;
    }
    this.m_nInitialSettingsCount = num - 1;
    if (this.m_SearchPlantListView.Items.Count <= 0)
      return;
    this.m_SearchPlantListView.Items[0].Selected = true;
  }

  private void SaveSettings()
  {
    int index;
    for (index = 0; index < this.m_SearchPlantListView.Items.Count; ++index)
    {
      ApplicationUtility.Settings.eplSetE_SetSetting($"{this.m_strSettingsPrefix}ParameterName{Convert.ToString(index + 1)}", this.m_SearchPlantListView.Items[index].Text);
      ApplicationUtility.Settings.eplSetE_SetSetting($"{this.m_strSettingsPrefix}ComparisionType{Convert.ToString(index + 1)}", this.m_SearchPlantListView.Items[index].SubItems[1].Text);
      if (string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), true) != 0)
      {
        ApplicationUtility.Settings.eplSetE_SetSetting($"{this.m_strSettingsPrefix}Filter{Convert.ToString(index + 1)}", this.m_SearchPlantListView.Items[index].SubItems[2].Text);
      }
      else
      {
        double _dReturnedDouble = 0.0;
        RevitGeometry.Units_ConvertStringToDouble(this.m_SearchPlantListView.Items[index].SubItems[2].Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false);
        ApplicationUtility.Settings.eplSetE_SetSetting($"{this.m_strSettingsPrefix}Filter{Convert.ToString(index + 1)}", ValueConversion.ToString(_dReturnedDouble));
      }
    }
    for (; index < this.m_nInitialSettingsCount; ++index)
    {
      ApplicationUtility.Settings.eplSetE_DeleteStringSetting($"{this.m_strSettingsPrefix}ParameterName{Convert.ToString(index + 1)}");
      ApplicationUtility.Settings.eplSetE_DeleteStringSetting("PlantSearchComparisionType" + Convert.ToString(index + 1));
      ApplicationUtility.Settings.eplSetE_DeleteStringSetting("PlantSearchFilter" + Convert.ToString(index + 1));
    }
  }

  private void OnFindButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnAddButtonClick(object sender, EventArgs e)
  {
    this.m_SearchPlantListView.Items.Add(new ListViewItem((string) this.m_ParameterComboBox.SelectedItem)
    {
      SubItems = {
        (string) this.m_FilterComboBox.SelectedItem,
        this.m_FilterTextBox.Text
      }
    });
  }

  private void OnDeleteButtonClick(object sender, EventArgs e)
  {
    for (int index = 0; index < this.m_SearchPlantListView.SelectedIndices.Count; ++index)
      this.m_SearchPlantListView.Items.RemoveAt(this.m_SearchPlantListView.SelectedIndices[index]);
  }

  private void OnModifyButtonClick(object sender, EventArgs e)
  {
    if (this.m_SearchPlantListView.SelectedItems.Count > 0)
    {
      ListViewItem selectedItem = this.m_SearchPlantListView.SelectedItems[0];
      selectedItem.Text = (string) this.m_ParameterComboBox.SelectedItem;
      selectedItem.SubItems[1].Text = (string) this.m_FilterComboBox.SelectedItem;
      selectedItem.SubItems[2].Text = this.m_FilterTextBox.Text;
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ParameterNotSelectedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
  }

  private void SearchPlantListViewIndexChanged(object sender, EventArgs e)
  {
    if (this.m_SearchPlantListView.SelectedItems.Count <= 0)
      return;
    ListViewItem selectedItem = this.m_SearchPlantListView.SelectedItems[0];
    int num1 = this.m_ParameterComboBox.FindString(selectedItem.Text);
    if (num1 >= 0)
      this.m_ParameterComboBox.SelectedIndex = num1;
    int num2 = this.m_FilterComboBox.FindString(selectedItem.SubItems[1].Text);
    if (num2 >= 0)
      this.m_FilterComboBox.SelectedIndex = num2;
    this.m_FilterTextBox.Text = selectedItem.SubItems[2].Text;
  }

  private void OnPlantSearchFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnFilterTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatFilterValue();
  }

  private void OnFilterTextBoxLeave(object sender, EventArgs e) => this.FormatFilterValue();

  private void FormatFilterValue()
  {
    string selectedItem = (string) this.m_ParameterComboBox.SelectedItem;
    if (string.Compare(selectedItem, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) != 0 && string.Compare(selectedItem, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), true) != 0 && string.Compare(selectedItem, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) != 0 && string.Compare(selectedItem, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) != 0 && string.Compare(selectedItem, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), true) != 0)
      return;
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_FilterTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_FilterTextBox.Text = empty;
    }
    else
      this.m_FilterTextBox.Focus();
  }

  public List<KeyValuePair<string, SearchPlantParameter>> SearchParameterResults
  {
    get
    {
      ProgressBarForm progressBarForm = new ProgressBarForm();
      progressBarForm.MinValue = 0;
      progressBarForm.MaxValue = this.m_SearchPlantListView.Items.Count;
      progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSearchingMessage");
      progressBarForm.ShowForm();
      progressBarForm.Refresh();
      List<KeyValuePair<string, SearchPlantParameter>> parameterResults = new List<KeyValuePair<string, SearchPlantParameter>>();
      for (int index = 0; index < this.m_SearchPlantListView.Items.Count; ++index)
      {
        SearchPlantParameter searchPlantParameter;
        if (string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("HeightPlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("CharacteristicsFoliageSizePlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), true) != 0 && string.Compare(this.m_SearchPlantListView.Items[index].Text, EPShared.LocalRM.GetString("PlantSpacingPlantFamilyParameter"), true) != 0)
        {
          searchPlantParameter = new SearchPlantParameter(ManagePlants.FindPlantComparisonType(this.m_SearchPlantListView.Items[index].SubItems[1].Text), this.m_SearchPlantListView.Items[index].SubItems[2].Text);
        }
        else
        {
          double _dReturnedDouble = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(this.m_SearchPlantListView.Items[index].SubItems[2].Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false);
          searchPlantParameter = new SearchPlantParameter(ManagePlants.FindPlantComparisonType(this.m_SearchPlantListView.Items[index].SubItems[1].Text), ValueConversion.ToString(_dReturnedDouble));
        }
        parameterResults.Add(new KeyValuePair<string, SearchPlantParameter>(this.m_SearchPlantListView.Items[index].Text, searchPlantParameter));
        progressBarForm.UpdateProgressBar(1);
      }
      progressBarForm.SetMaxValue();
      Thread.Sleep(300);
      progressBarForm.Close();
      return parameterResults;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_CancelButton = new Button();
    this.m_FindButton = new Button();
    this.m_ParameterComboBox = new ComboBox();
    this.m_FilterComboBox = new ComboBox();
    this.m_ParameterLabel = new Label();
    this.m_SearchPlantListView = new ListView();
    this.m_ModifyButton = new Button();
    this.m_AddButton = new Button();
    this.m_FilterTextBox = new TextBox();
    this.m_FilterLabel = new Label();
    this.m_DeleteButton = new Button();
    this.SuspendLayout();
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(459, 231);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(77, 23);
    this.m_CancelButton.TabIndex = 10;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_FindButton.Location = new Point(376, 231);
    this.m_FindButton.Name = "m_FindButton";
    this.m_FindButton.Size = new Size(79, 23);
    this.m_FindButton.TabIndex = 9;
    this.m_FindButton.Text = "&Find";
    this.m_FindButton.UseVisualStyleBackColor = true;
    this.m_FindButton.Click += new EventHandler(this.OnFindButtonClick);
    this.m_ParameterComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ParameterComboBox.FormattingEnabled = true;
    this.m_ParameterComboBox.Location = new Point(95, 12);
    this.m_ParameterComboBox.Name = "m_ParameterComboBox";
    this.m_ParameterComboBox.Size = new Size(242, 21);
    this.m_ParameterComboBox.Sorted = true;
    this.m_ParameterComboBox.TabIndex = 1;
    this.m_FilterComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_FilterComboBox.FormattingEnabled = true;
    this.m_FilterComboBox.Location = new Point(346, 12);
    this.m_FilterComboBox.Name = "m_FilterComboBox";
    this.m_FilterComboBox.Size = new Size(190, 21);
    this.m_FilterComboBox.TabIndex = 2;
    this.m_ParameterLabel.AutoSize = true;
    this.m_ParameterLabel.Location = new Point(9, 15);
    this.m_ParameterLabel.Name = "m_ParameterLabel";
    this.m_ParameterLabel.Size = new Size(58, 13);
    this.m_ParameterLabel.TabIndex = 0;
    this.m_ParameterLabel.Text = "&Parameter:";
    this.m_SearchPlantListView.FullRowSelect = true;
    this.m_SearchPlantListView.HideSelection = false;
    this.m_SearchPlantListView.Location = new Point(12, 73);
    this.m_SearchPlantListView.Name = "m_SearchPlantListView";
    this.m_SearchPlantListView.Size = new Size(443, 152);
    this.m_SearchPlantListView.TabIndex = 5;
    this.m_SearchPlantListView.UseCompatibleStateImageBehavior = false;
    this.m_SearchPlantListView.SelectedIndexChanged += new EventHandler(this.SearchPlantListViewIndexChanged);
    this.m_ModifyButton.Location = new Point(461, 102);
    this.m_ModifyButton.Name = "m_ModifyButton";
    this.m_ModifyButton.Size = new Size(75, 23);
    this.m_ModifyButton.TabIndex = 7;
    this.m_ModifyButton.Text = "&Modify";
    this.m_ModifyButton.UseVisualStyleBackColor = true;
    this.m_ModifyButton.Click += new EventHandler(this.OnModifyButtonClick);
    this.m_AddButton.Location = new Point(461, 73);
    this.m_AddButton.Name = "m_AddButton";
    this.m_AddButton.Size = new Size(75, 23);
    this.m_AddButton.TabIndex = 6;
    this.m_AddButton.Text = "&Add";
    this.m_AddButton.UseVisualStyleBackColor = true;
    this.m_AddButton.Click += new EventHandler(this.OnAddButtonClick);
    this.m_FilterTextBox.Location = new Point(95, 40);
    this.m_FilterTextBox.Name = "m_FilterTextBox";
    this.m_FilterTextBox.Size = new Size(242, 20);
    this.m_FilterTextBox.TabIndex = 4;
    this.m_FilterTextBox.KeyDown += new KeyEventHandler(this.OnFilterTextBoxKeyDown);
    this.m_FilterTextBox.Leave += new EventHandler(this.OnFilterTextBoxLeave);
    this.m_FilterLabel.AutoSize = true;
    this.m_FilterLabel.Location = new Point(12, 43);
    this.m_FilterLabel.Name = "m_FilterLabel";
    this.m_FilterLabel.Size = new Size(32 /*0x20*/, 13);
    this.m_FilterLabel.TabIndex = 3;
    this.m_FilterLabel.Text = "Fil&ter:";
    this.m_DeleteButton.Location = new Point(461, 131);
    this.m_DeleteButton.Name = "m_DeleteButton";
    this.m_DeleteButton.Size = new Size(75, 23);
    this.m_DeleteButton.TabIndex = 8;
    this.m_DeleteButton.Text = "&Delete";
    this.m_DeleteButton.UseVisualStyleBackColor = true;
    this.m_DeleteButton.Click += new EventHandler(this.OnDeleteButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(547, 266);
    this.Controls.Add((Control) this.m_DeleteButton);
    this.Controls.Add((Control) this.m_FilterLabel);
    this.Controls.Add((Control) this.m_FilterTextBox);
    this.Controls.Add((Control) this.m_AddButton);
    this.Controls.Add((Control) this.m_ModifyButton);
    this.Controls.Add((Control) this.m_SearchPlantListView);
    this.Controls.Add((Control) this.m_ParameterLabel);
    this.Controls.Add((Control) this.m_FilterComboBox);
    this.Controls.Add((Control) this.m_ParameterComboBox);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_FindButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (PlantSearchForm);
    this.Text = "Plant Search";
    this.FormClosing += new FormClosingEventHandler(this.OnPlantSearchFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_FindButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
