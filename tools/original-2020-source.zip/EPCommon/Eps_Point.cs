﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_Point
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class Eps_Point
{
  private double m_dX;
  private double m_dY;
  private double m_dZ;

  public Eps_Point()
  {
    this.m_dX = 0.0;
    this.m_dY = 0.0;
    this.m_dZ = 0.0;
  }

  public Eps_Point(XYZ _XYZPoint)
  {
    this.m_dX = _XYZPoint.X;
    this.m_dY = _XYZPoint.Y;
    this.m_dZ = _XYZPoint.Z;
  }

  public Eps_Point(double _dX, double _dY, double _dZ)
  {
    this.m_dX = _dX;
    this.m_dY = _dY;
    this.m_dZ = _dZ;
  }

  public Eps_Point(Eps_Point _Point)
  {
    this.m_dX = _Point.x;
    this.m_dY = _Point.y;
    this.m_dZ = _Point.z;
  }

  public bool IsEqual(Eps_Point _ComparePoint)
  {
    return EPShared.eplGeoE_ArePntsDuplicates2D(this, _ComparePoint);
  }

  public double x
  {
    get => this.m_dX;
    set => this.m_dX = value;
  }

  public double y
  {
    get => this.m_dY;
    set => this.m_dY = value;
  }

  public double z
  {
    get => this.m_dZ;
    set => this.m_dZ = value;
  }

  public XYZ XYZ => new XYZ(this.m_dX, this.m_dY, this.m_dZ);

  public XYZ XY => new XYZ(this.m_dX, this.m_dY, 0.0);
}
