﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.GenericModelFamilyInstanceWrapper
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class GenericModelFamilyInstanceWrapper
{
  private string m_strChainID;
  private List<GenericModelFamilyInstanceContainer> m_FamilyContainerList;
  private List<GenericModelFamilyInstanceContainer> m_IslandFamilyInstanceList;
  private List<FamilyInstanceAssignmentContainer> m_FamilyAssignmentList;

  public GenericModelFamilyInstanceWrapper(
    string _strChainID,
    List<GenericModelFamilyInstanceContainer> _PlantContainerList)
  {
    this.m_strChainID = _strChainID;
    this.m_FamilyContainerList = _PlantContainerList;
    this.m_IslandFamilyInstanceList = (List<GenericModelFamilyInstanceContainer>) null;
    this.m_FamilyAssignmentList = (List<FamilyInstanceAssignmentContainer>) null;
  }

  public int IndexOfFamilyInstanceUniqueID(Document _CurrentDocument, string _strUniqueID)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        FamilyInstance familyInstance = this.m_FamilyContainerList[index].GetFamilyInstance(_CurrentDocument);
        if (familyInstance != null && string.Compare(((Element) familyInstance).UniqueId, _strUniqueID, true) == 0)
          return index;
      }
    }
    return -1;
  }

  public int IndexOfContainerID(Document _CurrentDocument, ElementId _ContainerID)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (this.m_FamilyContainerList[index].GetFamilyInstance(_CurrentDocument) != null && ElementId.op_Equality(this.m_FamilyContainerList[index].ID, _ContainerID))
          return index;
      }
    }
    return -1;
  }

  public int IndexOfIslandContainerID(Document _CurrentDocument, ElementId _ContainerID)
  {
    if (this.m_IslandFamilyInstanceList != null && this.m_IslandFamilyInstanceList.Count > 0)
    {
      for (int index = 0; index < this.m_IslandFamilyInstanceList.Count; ++index)
      {
        if (this.m_IslandFamilyInstanceList[index].GetFamilyInstance(_CurrentDocument) != null && ElementId.op_Equality(this.m_IslandFamilyInstanceList[index].ID, _ContainerID))
          return index;
      }
    }
    return -1;
  }

  public int IndexOfFamilyInstanceID(Document _CurrentDocument, ElementId _ElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (this.m_FamilyContainerList[index].FamilyInstanceID.IntegerValue == _ElementId.IntegerValue)
          return index;
      }
    }
    return -1;
  }

  public FamilyInstance GetFirstExistingFamilyInstance(Document _CurrentDocument)
  {
    ElementId _FindElementId = new ElementId(-1);
    return this.GetFirstExistingFamilyInstance(_CurrentDocument, _FindElementId);
  }

  public FamilyInstance GetFirstExistingFamilyInstance(
    Document _CurrentDocument,
    ElementId _FindElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (_FindElementId.IntegerValue == -1 || _FindElementId.IntegerValue == this.m_FamilyContainerList[index].ID.IntegerValue)
        {
          FamilyInstance familyInstance = this.m_FamilyContainerList[index].GetFamilyInstance(_CurrentDocument);
          if (familyInstance != null)
            return familyInstance;
        }
      }
    }
    return (FamilyInstance) null;
  }

  public Element GetFirstExistingElement(Document _CurrentDocument)
  {
    ElementId _FindElementId = new ElementId(-1);
    return this.GetFirstExistingElement(_CurrentDocument, _FindElementId);
  }

  public Element GetFirstExistingElement(Document _CurrentDocument, ElementId _FindElementId)
  {
    if (this.m_FamilyContainerList != null && this.m_FamilyContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyContainerList.Count; ++index)
      {
        if (_FindElementId.IntegerValue == -1 || _FindElementId.IntegerValue == this.m_FamilyContainerList[index].ID.IntegerValue)
        {
          Element element = _CurrentDocument.GetElement(this.m_FamilyContainerList[index].ID);
          if (element != null)
            return element;
        }
      }
    }
    return (Element) null;
  }

  public int IndexOfFamilyAssignmentInstanceID(Document _CurrentDocument, ElementId _ElementId)
  {
    if (this.m_FamilyAssignmentList != null && this.m_FamilyAssignmentList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyAssignmentList.Count; ++index)
      {
        if (this.m_FamilyAssignmentList[index].FamilyInstanceID.IntegerValue == _ElementId.IntegerValue)
          return index;
      }
    }
    return -1;
  }

  public List<KeyValuePair<string, FamilyInstance>> GetFamilyAssignmentInstanceList(
    Document _CurrentDocument)
  {
    return this.GetFamilyAssignmentInstanceList(_CurrentDocument, (FamilyInstance) null);
  }

  public List<KeyValuePair<string, FamilyInstance>> GetFamilyAssignmentInstanceList(
    Document _CurrentDocument,
    FamilyInstance _PlacementFamilyInstance)
  {
    List<KeyValuePair<string, FamilyInstance>> assignmentInstanceList = (List<KeyValuePair<string, FamilyInstance>>) null;
    if (this.m_FamilyAssignmentList != null && this.m_FamilyAssignmentList.Count > 0)
    {
      for (int index = 0; index < this.m_FamilyAssignmentList.Count; ++index)
      {
        FamilyInstance familyInstance = this.m_FamilyAssignmentList[index].GetFamilyInstance(_CurrentDocument);
        if (familyInstance != null)
        {
          Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlacementIDFamilyParameter);
          if (parameter != null && (_PlacementFamilyInstance == null || string.Compare(parameter.AsString(), ((Element) _PlacementFamilyInstance).UniqueId, true) == 0))
          {
            if (assignmentInstanceList == null)
              assignmentInstanceList = new List<KeyValuePair<string, FamilyInstance>>();
            assignmentInstanceList.Add(new KeyValuePair<string, FamilyInstance>(parameter.AsString(), familyInstance));
          }
        }
      }
    }
    return assignmentInstanceList;
  }

  public bool GetFamilyAssignmentDeletedList(
    Document _CurrentDocument,
    ref List<ElementId> _DeletedElementsList,
    ref int _nFamilyDeletedCount)
  {
    bool flag = false;
    bool assignmentDeletedList = true;
    _nFamilyDeletedCount = 0;
    if (this.m_FamilyAssignmentList != null && this.m_FamilyAssignmentList.Count > 0)
    {
      for (int index1 = 0; index1 < this.m_FamilyAssignmentList.Count; ++index1)
      {
        for (int index2 = 0; index2 < _DeletedElementsList.Count; ++index2)
        {
          if (ElementId.op_Equality(_DeletedElementsList[index2], this.m_FamilyAssignmentList[index1].ID))
          {
            ++_nFamilyDeletedCount;
            _DeletedElementsList.RemoveAt(index2);
            flag = true;
            break;
          }
        }
        if (!flag && assignmentDeletedList)
        {
          if (this.m_FamilyAssignmentList[index1].GetFamilyInstance(_CurrentDocument) != null)
            assignmentDeletedList = false;
        }
        else
          flag = false;
      }
    }
    return assignmentDeletedList;
  }

  public string ChainID => this.m_strChainID;

  public List<GenericModelFamilyInstanceContainer> FamilyContainerList
  {
    get => this.m_FamilyContainerList;
  }

  public List<GenericModelFamilyInstanceContainer> IslandFamilyInstanceList
  {
    get => this.m_IslandFamilyInstanceList;
    set => this.m_IslandFamilyInstanceList = value;
  }

  public List<FamilyInstanceAssignmentContainer> FamilyAssignmentList
  {
    get => this.m_FamilyAssignmentList;
    set => this.m_FamilyAssignmentList = value;
  }
}
