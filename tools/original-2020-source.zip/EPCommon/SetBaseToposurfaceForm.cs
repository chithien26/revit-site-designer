﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SetBaseToposurfaceForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class SetBaseToposurfaceForm : EPForm
{
  private SetBaseToposurface m_dataBuffer;
  private List<TopographySurfaceContainer> m_SelectedSurfaceList;
  private IContainer components;
  private Button m_CancelButton;
  private Button m_OKButton;
  private GroupBox m_ToposurfaceGroupBox;
  private ListView m_ToposurfaceListView;
  private TextBox m_MessageTextBox;
  private Button m_PickButton;

  public SetBaseToposurfaceForm(SetBaseToposurface _dataBuffer)
  {
    this.InitializeComponent();
    if (!_dataBuffer.PickIndividualSurface)
    {
      this.Text = EPShared.LocalRM.GetString("SetBaseToposurfaceDialog");
      this.m_MessageTextBox.Text = EPShared.LocalRM.GetString("SetBaseToposurfaceInformationDialog");
    }
    else
    {
      this.Text = EPShared.LocalRM.GetString("ToposurfaceAssociationDialog");
      this.m_MessageTextBox.Text = EPShared.LocalRM.GetString("PickToposurfaceInformationDialog");
    }
    this.m_ToposurfaceListView.MultiSelect = !_dataBuffer.PickIndividualSurface;
    this.m_ToposurfaceGroupBox.Text = EPShared.LocalRM.GetString("ToposurfaceDialog");
    this.m_PickButton.Text = EPShared.LocalRM.GetString("AMP_PickDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.ContextualHelpID = "HID_SDsetBaseTopo";
    this.m_dataBuffer = _dataBuffer;
    this.m_SelectedSurfaceList = (List<TopographySurfaceContainer>) null;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    this.GetDialogPosition();
    this.SetupListView();
  }

  private void SetupListView()
  {
    this.m_ToposurfaceListView.View = View.Details;
    this.m_ToposurfaceListView.Columns.Add(EPShared.LocalRM.GetString("SurfaceNameDialog"));
    this.m_ToposurfaceListView.Columns.Add(EPShared.LocalRM.GetString("PhaseCreatedDialog"));
    int num = (this.m_ToposurfaceListView.Width - 5) / this.m_ToposurfaceListView.Columns.Count;
    for (int index = 0; index < this.m_ToposurfaceListView.Columns.Count; ++index)
      this.m_ToposurfaceListView.Columns[index].Width = num;
    this.PopulateListView();
    this.SelectListItems();
    if (this.m_ToposurfaceListView.Items.Count != 1)
      return;
    this.m_ToposurfaceListView.SelectedIndices.Add(0);
  }

  public void SelectListItems()
  {
    this.m_ToposurfaceListView.SelectedIndices.Clear();
    foreach (Element instance in this.m_dataBuffer.InstanceSet)
    {
      if (instance is TopographySurface topographySurface && ((Element) topographySurface).Category != null && ((Element) topographySurface).Category.Id.IntegerValue == ((BuiltInCategory) -2001340).GetHashCode())
      {
        int itemIndex = this.m_ToposurfaceListView.Items.IndexOfKey(((Element) topographySurface).UniqueId);
        if (itemIndex >= 0)
          this.m_ToposurfaceListView.SelectedIndices.Add(itemIndex);
      }
    }
  }

  private void PopulateListView()
  {
    ListViewItem listViewItem1 = new ListViewItem();
    string text = string.Empty;
    int num = 1;
    this.m_ToposurfaceListView.Items.Clear();
    for (int index = 0; index < this.m_dataBuffer.SurfaceList.Count; ++index)
    {
      Parameter parameter1 = ((Element) this.m_dataBuffer.SurfaceList[index].TopographySurface)[(BuiltInParameter) -1006900];
      if (parameter1 != null)
        text = parameter1.AsString();
      if (text == null || text == string.Empty)
      {
        text = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
        ++num;
      }
      ListViewItem listViewItem2 = this.m_ToposurfaceListView.Items.Insert(index, ((Element) this.m_dataBuffer.SurfaceList[index].TopographySurface).UniqueId, text, string.Empty);
      listViewItem2.Tag = (object) ((Element) this.m_dataBuffer.SurfaceList[index].TopographySurface).UniqueId;
      Parameter parameter2 = ((Element) this.m_dataBuffer.SurfaceList[index].TopographySurface)[(BuiltInParameter) -1012100];
      if (parameter2 != null)
      {
        foreach (Phase phase in this.m_dataBuffer.Document.Phases)
        {
          if (ElementId.op_Equality(((Element) phase).Id, parameter2.AsElementId()))
          {
            text = ((Element) phase).Name;
            break;
          }
        }
      }
      if (text == null || text == string.Empty)
        text = EPShared.LocalRM.GetString("NotAvailableString");
      listViewItem2.SubItems.Add(text);
    }
  }

  private void OnPickButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.SetSelectedTopoList())
      return;
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnFormLoad(object sender, EventArgs e) => this.OverrideKeyUp();

  private bool SetSelectedTopoList()
  {
    this.m_SelectedSurfaceList = new List<TopographySurfaceContainer>();
    int count;
    if ((count = this.m_ToposurfaceListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = 0; index1 < count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_dataBuffer.SurfaceList.Count; ++index2)
        {
          if (string.Compare((string) this.m_ToposurfaceListView.SelectedItems[index1].Tag, ((Element) this.m_dataBuffer.SurfaceList[index2].TopographySurface).UniqueId, true) == 0)
          {
            this.m_dataBuffer.SurfaceList[index2].FindMinMaxPointsOfTopographySurface();
            this.m_SelectedSurfaceList.Add(this.m_dataBuffer.SurfaceList[index2]);
            break;
          }
        }
      }
      return true;
    }
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSurfacesSelectedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private void OnSetBaseToposurfaceClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public List<TopographySurfaceContainer> SelectedSurfaceList => this.m_SelectedSurfaceList;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (SetBaseToposurfaceForm));
    this.m_CancelButton = new Button();
    this.m_OKButton = new Button();
    this.m_ToposurfaceGroupBox = new GroupBox();
    this.m_ToposurfaceListView = new ListView();
    this.m_MessageTextBox = new TextBox();
    this.m_PickButton = new Button();
    this.m_ToposurfaceGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_CancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(313, 312);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_OKButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_OKButton.Location = new Point(230, 312);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(77, 23);
    this.m_OKButton.TabIndex = 3;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_ToposurfaceGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ToposurfaceGroupBox.Controls.Add((Control) this.m_ToposurfaceListView);
    this.m_ToposurfaceGroupBox.Location = new Point(12, 78);
    this.m_ToposurfaceGroupBox.Name = "m_ToposurfaceGroupBox";
    this.m_ToposurfaceGroupBox.Size = new Size(376, 228);
    this.m_ToposurfaceGroupBox.TabIndex = 1;
    this.m_ToposurfaceGroupBox.TabStop = false;
    this.m_ToposurfaceGroupBox.Text = "Toposurface";
    this.m_ToposurfaceListView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_ToposurfaceListView.FullRowSelect = true;
    this.m_ToposurfaceListView.HideSelection = false;
    this.m_ToposurfaceListView.Location = new Point(6, 19);
    this.m_ToposurfaceListView.Name = "m_ToposurfaceListView";
    this.m_ToposurfaceListView.Size = new Size(364, 203);
    this.m_ToposurfaceListView.TabIndex = 0;
    this.m_ToposurfaceListView.UseCompatibleStateImageBehavior = false;
    this.m_ToposurfaceListView.DoubleClick += new EventHandler(this.OnOKButtonClick);
    this.m_MessageTextBox.BackColor = SystemColors.Control;
    this.m_MessageTextBox.BorderStyle = BorderStyle.None;
    this.m_MessageTextBox.Location = new Point(12, 12);
    this.m_MessageTextBox.Multiline = true;
    this.m_MessageTextBox.Name = "m_MessageTextBox";
    this.m_MessageTextBox.Size = new Size(376, 60);
    this.m_MessageTextBox.TabIndex = 0;
    this.m_MessageTextBox.TabStop = false;
    this.m_MessageTextBox.Text = componentResourceManager.GetString("m_MessageTextBox.Text");
    this.m_PickButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_PickButton.Location = new Point(149, 312);
    this.m_PickButton.Name = "m_PickButton";
    this.m_PickButton.Size = new Size(75, 23);
    this.m_PickButton.TabIndex = 2;
    this.m_PickButton.Text = "&Pick";
    this.m_PickButton.UseVisualStyleBackColor = true;
    this.m_PickButton.Click += new EventHandler(this.OnPickButtonClicked);
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
    this.ClientSize = new Size(400, 347);
    this.Controls.Add((Control) this.m_PickButton);
    this.Controls.Add((Control) this.m_MessageTextBox);
    this.Controls.Add((Control) this.m_ToposurfaceGroupBox);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_OKButton);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.Name = nameof (SetBaseToposurfaceForm);
    this.Text = "Set Base Toposurface";
    this.FormClosing += new FormClosingEventHandler(this.OnSetBaseToposurfaceClosing);
    this.Load += new EventHandler(this.OnFormLoad);
    this.m_ToposurfaceGroupBox.ResumeLayout(false);
    this.ResumeLayout(false);
    this.PerformLayout();
  }
}
