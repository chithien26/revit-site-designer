using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class ParkingLotAreaSettingsForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private Document m_Document;

	private FormatOptions m_LengthFormatOptions;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_LengthUnitSymbolType;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private TextBox m_AisleWidthTextBox;

	private GroupBox m_RowSpacingGroupBox;

	private ComboBox m_RowSpacingOptionsComboBox;

	private Label m_ParkingFamilyLabel;

	private CheckBox m_BiDirectionalAislesCheckBox;

	private TextBox m_DistanceBetweenCenterlinesTextBox;

	private Button m_OKButton;

	private Button m_CancelButton;

	private TextBox m_ParkingNumberOfRowsTextBox;

	private Label m_ParkingNumberOfRowsLabel;

	public string DistanceBetweenCenterlines
	{
		get
		{
			return m_DistanceBetweenCenterlinesTextBox.Text;
		}
		set
		{
			m_DistanceBetweenCenterlinesTextBox.Text = value;
		}
	}

	public string AisleWidth
	{
		get
		{
			return m_AisleWidthTextBox.Text;
		}
		set
		{
			m_AisleWidthTextBox.Text = value;
		}
	}

	public bool BiDirectionalAisles
	{
		get
		{
			return m_BiDirectionalAislesCheckBox.Checked;
		}
		set
		{
			m_BiDirectionalAislesCheckBox.Checked = value;
		}
	}

	public int RowSpacingOptions
	{
		get
		{
			return m_RowSpacingOptionsComboBox.SelectedIndex;
		}
		set
		{
			if (value >= 0 && value < m_RowSpacingOptionsComboBox.Items.Count)
			{
				m_RowSpacingOptionsComboBox.SelectedIndex = value;
			}
		}
	}

	public int ParkingNumberOfRows
	{
		get
		{
			int _nReturnedInt = 0;
			RevitGeometry.StrE_GetValidWholeNumber(m_ParkingNumberOfRowsTextBox.Text, ref _nReturnedInt);
			return _nReturnedInt;
		}
		set
		{
			m_ParkingNumberOfRowsTextBox.Text = Convert.ToString(value);
		}
	}

	public ParkingLotAreaSettingsForm(Document _Document)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("ParkingLotAreaSettingsDialog");
		m_RowSpacingGroupBox.Text = EPShared.LocalRM.GetString("RowSpacingDialog");
		m_ParkingNumberOfRowsLabel.Text = EPShared.LocalRM.GetString("AMP_NumberOfRowsDialog");
		m_BiDirectionalAislesCheckBox.Text = EPShared.LocalRM.GetString("AMP_UseBiDirectionalAislesDialog");
		m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_Document = _Document;
		m_DisplayUnitSystem = m_Document.DisplayUnitSystem;
		m_LengthFormatOptions = m_Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_Units = m_Document.GetUnits();
		try
		{
			m_LengthUnitSymbolType = m_LengthFormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_LengthUnitSymbolType = UnitSymbolType.UST_NONE;
		}
		m_DecimalSymbolType = m_Document.GetUnits().DecimalSymbol;
		m_RowSpacingOptionsComboBox.Items.Add(EPShared.LocalRM.GetString("DistBetweenLinesString"));
		m_RowSpacingOptionsComboBox.Items.Add(EPShared.LocalRM.GetString("AisleWidthString"));
		InitializeControls();
	}

	private void InitializeControls()
	{
		GetDialogPosition();
	}

	private void SaveSettings()
	{
		int _nReturnedInt = 0;
		double _dReturnedDouble = 0.0;
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsRowSpacingOption", m_RowSpacingOptionsComboBox.SelectedIndex);
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsBiDirectionalAisles", Convert.ToInt32(m_BiDirectionalAislesCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_DistanceBetweenCenterlinesTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsDistanceBetweenCenterlines", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_AisleWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsAisleWidth", _dReturnedDouble);
		}
		if (RevitGeometry.StrE_GetValidWholeNumber(m_ParkingNumberOfRowsTextBox.Text, ref _nReturnedInt))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotAreaSettingsNumberOfRows", _nReturnedInt);
		}
	}

	private void FormatDistanceBetweenCenterlinesValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_DistanceBetweenCenterlinesTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_DistanceBetweenCenterlinesTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_DistanceBetweenCenterlinesTextBox);
		}
	}

	private void FormatAisleWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_AisleWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_AisleWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_AisleWidthTextBox);
		}
	}

	private void OnOKButtonClick(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void OnRowSpacingOptionsComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_RowSpacingOptionsComboBox.SelectedIndex == 0)
		{
			m_DistanceBetweenCenterlinesTextBox.Visible = true;
			m_AisleWidthTextBox.Visible = false;
		}
		else
		{
			m_DistanceBetweenCenterlinesTextBox.Visible = false;
			m_AisleWidthTextBox.Visible = true;
		}
	}

	private void OnDistanceBetweenCenterlinesTextBoxLeave(object sender, EventArgs e)
	{
		FormatDistanceBetweenCenterlinesValue();
	}

	private void OnDistanceBetweenCenterlinesTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatDistanceBetweenCenterlinesValue();
		}
	}

	private void OnAisleWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatAisleWidthValue();
	}

	private void OnAisleWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatAisleWidthValue();
		}
	}

	private void ParkingLotAreaSettingsFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_AisleWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_RowSpacingGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ParkingNumberOfRowsTextBox = new System.Windows.Forms.TextBox();
		this.m_ParkingNumberOfRowsLabel = new System.Windows.Forms.Label();
		this.m_DistanceBetweenCenterlinesTextBox = new System.Windows.Forms.TextBox();
		this.m_BiDirectionalAislesCheckBox = new System.Windows.Forms.CheckBox();
		this.m_RowSpacingOptionsComboBox = new System.Windows.Forms.ComboBox();
		this.m_ParkingFamilyLabel = new System.Windows.Forms.Label();
		this.m_OKButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_RowSpacingGroupBox.SuspendLayout();
		base.SuspendLayout();
		this.m_AisleWidthTextBox.Location = new System.Drawing.Point(231, 20);
		this.m_AisleWidthTextBox.Name = "m_AisleWidthTextBox";
		this.m_AisleWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_AisleWidthTextBox.TabIndex = 2;
		this.m_AisleWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnAisleWidthTextBoxKeyDown);
		this.m_AisleWidthTextBox.Leave += new System.EventHandler(this.OnAisleWidthTextBoxLeave);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_ParkingNumberOfRowsTextBox);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_ParkingNumberOfRowsLabel);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_DistanceBetweenCenterlinesTextBox);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_BiDirectionalAislesCheckBox);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_RowSpacingOptionsComboBox);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_AisleWidthTextBox);
		this.m_RowSpacingGroupBox.Controls.Add(this.m_ParkingFamilyLabel);
		this.m_RowSpacingGroupBox.Location = new System.Drawing.Point(12, 12);
		this.m_RowSpacingGroupBox.Name = "m_RowSpacingGroupBox";
		this.m_RowSpacingGroupBox.Size = new System.Drawing.Size(340, 99);
		this.m_RowSpacingGroupBox.TabIndex = 0;
		this.m_RowSpacingGroupBox.TabStop = false;
		this.m_RowSpacingGroupBox.Text = "Row Spacing";
		this.m_ParkingNumberOfRowsTextBox.Location = new System.Drawing.Point(125, 46);
		this.m_ParkingNumberOfRowsTextBox.Name = "m_ParkingNumberOfRowsTextBox";
		this.m_ParkingNumberOfRowsTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ParkingNumberOfRowsTextBox.TabIndex = 3;
		this.m_ParkingNumberOfRowsLabel.AutoSize = true;
		this.m_ParkingNumberOfRowsLabel.Location = new System.Drawing.Point(6, 49);
		this.m_ParkingNumberOfRowsLabel.Name = "m_ParkingNumberOfRowsLabel";
		this.m_ParkingNumberOfRowsLabel.Size = new System.Drawing.Size(89, 13);
		this.m_ParkingNumberOfRowsLabel.TabIndex = 2;
		this.m_ParkingNumberOfRowsLabel.Text = "&Number of Rows:";
		this.m_DistanceBetweenCenterlinesTextBox.Location = new System.Drawing.Point(231, 20);
		this.m_DistanceBetweenCenterlinesTextBox.Name = "m_DistanceBetweenCenterlinesTextBox";
		this.m_DistanceBetweenCenterlinesTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_DistanceBetweenCenterlinesTextBox.TabIndex = 1;
		this.m_DistanceBetweenCenterlinesTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnDistanceBetweenCenterlinesTextBoxKeyDown);
		this.m_DistanceBetweenCenterlinesTextBox.Leave += new System.EventHandler(this.OnDistanceBetweenCenterlinesTextBoxLeave);
		this.m_BiDirectionalAislesCheckBox.AutoSize = true;
		this.m_BiDirectionalAislesCheckBox.Location = new System.Drawing.Point(6, 72);
		this.m_BiDirectionalAislesCheckBox.Name = "m_BiDirectionalAislesCheckBox";
		this.m_BiDirectionalAislesCheckBox.Size = new System.Drawing.Size(140, 17);
		this.m_BiDirectionalAislesCheckBox.TabIndex = 4;
		this.m_BiDirectionalAislesCheckBox.Text = "&Use Bi-Directional Aisles";
		this.m_BiDirectionalAislesCheckBox.UseVisualStyleBackColor = true;
		this.m_RowSpacingOptionsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_RowSpacingOptionsComboBox.FormattingEnabled = true;
		this.m_RowSpacingOptionsComboBox.Location = new System.Drawing.Point(6, 19);
		this.m_RowSpacingOptionsComboBox.Name = "m_RowSpacingOptionsComboBox";
		this.m_RowSpacingOptionsComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_RowSpacingOptionsComboBox.TabIndex = 0;
		this.m_RowSpacingOptionsComboBox.SelectedIndexChanged += new System.EventHandler(this.OnRowSpacingOptionsComboBoxSelectedIndexChanged);
		this.m_ParkingFamilyLabel.AutoSize = true;
		this.m_ParkingFamilyLabel.Location = new System.Drawing.Point(-93, 38);
		this.m_ParkingFamilyLabel.Name = "m_ParkingFamilyLabel";
		this.m_ParkingFamilyLabel.Size = new System.Drawing.Size(39, 13);
		this.m_ParkingFamilyLabel.TabIndex = 3;
		this.m_ParkingFamilyLabel.Text = "&Family:";
		this.m_OKButton.Location = new System.Drawing.Point(196, 117);
		this.m_OKButton.Name = "m_OKButton";
		this.m_OKButton.Size = new System.Drawing.Size(75, 23);
		this.m_OKButton.TabIndex = 1;
		this.m_OKButton.Text = "&OK";
		this.m_OKButton.UseVisualStyleBackColor = true;
		this.m_OKButton.Click += new System.EventHandler(this.OnOKButtonClick);
		this.m_CancelButton.Location = new System.Drawing.Point(277, 117);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 2;
		this.m_CancelButton.Text = "&Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(364, 151);
		base.Controls.Add(this.m_OKButton);
		base.Controls.Add(this.m_CancelButton);
		base.Controls.Add(this.m_RowSpacingGroupBox);
		base.Name = "ParkingLotAreaSettingsForm";
		this.Text = "Parking Lot Area Settings";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ParkingLotAreaSettingsFormClosing);
		this.m_RowSpacingGroupBox.ResumeLayout(false);
		this.m_RowSpacingGroupBox.PerformLayout();
		base.ResumeLayout(false);
		base.AcceptButton = this.m_OKButton;
		base.CancelButton = this.m_CancelButton;
	}
}
