﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LocateComponentsForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LocateComponentsForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private ComponentCreation m_dataBuffer;
  private View m_CurView;
  private FamilySymbol m_CurType;
  private FormatOptions m_FormatOptions;
  private FormatOptions m_AngularOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_UnitSymbolType;
  private UnitSymbolType m_AngularSymbolType;
  private DecimalSymbol m_DecimalSymbolType;
  private double m_dAngularRounding;
  private IContainer components;
  private Label m_ComponentFamilyLabel;
  private ComboBox m_ComponentFamilyComboBox;
  private ComboBox m_LevelComboBox;
  private Label m_LevelLabel;
  private RadioButton m_HedgeRowRadioButton;
  private Label m_ComponentNameLabel;
  private ComboBox m_ComponentNameComboBox;
  private Label m_ComponentSpacingLabel;
  private TextBox m_PlantSpacingTextBox;
  private Label m_SetbackLabel;
  private TextBox m_SetbackTextBox;
  private RadioButton m_GroveRadioButton;
  private Panel m_HedgeRowPanel;
  private RadioButton m_SideHedgeRadioButton;
  private RadioButton m_AlternateHedgeRadioButton;
  private RadioButton m_CenterHedgeRadioButton;
  private Panel m_GrovePanel;
  private RadioButton m_SquareRadioButton;
  private RadioButton m_TriangularRadioButton;
  private Label m_RotationLabel;
  private TextBox m_RotationTextBox;
  private CheckBox m_AlignToCheckBox;
  private Button m_LoadFamilyButton;
  private CheckBox m_ExistingElementCheckBox;
  private Panel m_MoveablePanel;
  private CheckBox m_DeleteExistingCheckBox;
  private Button m_CancelButton;
  private Button m_InsertButton;
  private RadioButton m_ChainRadioButton;
  private RadioButton m_SegmentRadioButton;
  private Label m_StartingDistanceLabel;
  private TextBox m_StartingDistanceTextBox;
  private Panel m_ToposurfacePickerPanel;
  private Label m_SelectedSurfaceLabel;
  private CheckBox m_ToposurfaceCheckBox;
  private ComboBox m_SurfaceList;
  private Panel m_SegmentChainPanel;

  public LocateComponentsForm(ComponentCreation dataBuffer)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("LocateComponentsDialog");
    this.m_ComponentFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_ComponentFamilyDialog");
    this.m_ComponentNameLabel.Text = EPShared.LocalRM.GetString("C_AMP_omponentNameDialog");
    this.m_ComponentSpacingLabel.Text = EPShared.LocalRM.GetString("Component_AMP_SpacingDialog");
    this.m_HedgeRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_PlaceAlongDialog");
    this.m_CenterHedgeRadioButton.Text = EPShared.LocalRM.GetString("C_AMP_enterDialog");
    this.m_AlternateHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_AlternateDialog");
    this.m_SideHedgeRadioButton.Text = EPShared.LocalRM.GetString("AMP_SideDialog");
    this.m_AlignToCheckBox.Text = EPShared.LocalRM.GetString("Ali_AMP_gnToDialog");
    this.m_GroveRadioButton.Text = EPShared.LocalRM.GetString("PlaceIn_AMP_AreaDialog");
    this.m_TriangularRadioButton.Text = EPShared.LocalRM.GetString("Triang_AMP_ularDialog");
    this.m_SquareRadioButton.Text = EPShared.LocalRM.GetString("S_AMP_quareDialog");
    this.m_RotationLabel.Text = EPShared.LocalRM.GetString("R_AMP_otationDialog");
    this.m_SetbackLabel.Text = EPShared.LocalRM.GetString("Set_AMP_backDialog");
    this.m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
    this.m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_ExistingElementCheckBox.Text = EPShared.LocalRM.GetString("ExistingEle_AMP_mentDialog");
    this.m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
    this.m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
    this.m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
    this.m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
    this.m_ToposurfaceCheckBox.Checked = false;
    this.m_SurfaceList.Enabled = false;
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.ContextualHelpID = "HID_SDaaa";
    this.m_dataBuffer = dataBuffer;
    this.m_FormatOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_AngularOptions = this.m_dataBuffer.Document.GetUnits().GetFormatOptions((UnitType) 3);
    this.m_DisplayUnitSystem = this.m_dataBuffer.Document.DisplayUnitSystem;
    this.m_Units = this.m_dataBuffer.Document.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_AngularSymbolType = this.m_AngularOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_AngularSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_dAngularRounding = this.m_AngularOptions.Accuracy;
    }
    catch (InvalidOperationException ex)
    {
      this.m_dAngularRounding = 1.0;
    }
    this.m_DecimalSymbolType = this.m_dataBuffer.Document.GetUnits().DecimalSymbol;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty1 = string.Empty;
    this.GetDialogPosition();
    this.m_HedgeRowRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsPlacementOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_HedgeRowRadioButton.Checked = true;
      else
        this.m_GroveRadioButton.Checked = true;
    }
    this.m_CenterHedgeRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsHedgeRowOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_CenterHedgeRadioButton.Checked = true;
          break;
        case 1:
          this.m_AlternateHedgeRadioButton.Checked = true;
          break;
        default:
          this.m_SideHedgeRadioButton.Checked = true;
          break;
      }
    }
    this.m_TriangularRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsGroveRowOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_TriangularRadioButton.Checked = true;
      else
        this.m_SquareRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsGroveRotation", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, _dReturnValue, this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref empty1);
    this.m_RotationTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsSpacing", ref _dReturnValue))
      _dReturnValue = 5.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_PlantSpacingTextBox.Text = empty1;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsSetback", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_SetbackTextBox.Text = empty1;
    this.m_ExistingElementCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsExistingElement", ref _nReturnValue))
      this.m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_DeleteExistingCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsDeleteExisting", ref _nReturnValue))
      this.m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsStartingDistance", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
    this.m_StartingDistanceTextBox.Text = empty1;
    this.m_AlignToCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsAllignTo", ref _nReturnValue))
      this.m_AlignToCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    this.m_ComponentFamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
    this.m_ComponentFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsFamilyName", ref empty1))
    {
      for (int index = 0; index < this.m_ComponentFamilyComboBox.Items.Count; ++index)
      {
        if (this.m_ComponentFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, empty1, true) == 0)
        {
          this.m_ComponentFamilyComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsPlantName", ref empty1))
    {
      for (int index = 0; index < this.m_ComponentNameComboBox.Items.Count; ++index)
      {
        if (this.m_ComponentNameComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, empty1, true) == 0)
        {
          this.m_ComponentNameComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    for (int index = 0; index < this.m_dataBuffer.Views.Count; ++index)
      this.m_LevelComboBox.Items.Add((object) $"{this.m_dataBuffer.Views[index].ViewType.ToString()}-{((Element) this.m_dataBuffer.Views[index]).Name}");
    if (this.m_LevelComboBox.Items.Count > 0)
      this.m_LevelComboBox.SelectedIndex = 0;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsViewName", ref empty1))
    {
      View view = (View) null;
      for (int index = 0; index < this.m_LevelComboBox.Items.Count; ++index)
      {
        if (view != null && string.Compare(Convert.ToString(this.m_LevelComboBox.Items[index]), empty1, true) == 0)
        {
          this.m_LevelComboBox.SelectedIndex = index;
          break;
        }
      }
    }
    this.m_SegmentRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsSegmentChainOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_SegmentRadioButton.Checked = true;
      else
        this.m_ChainRadioButton.Checked = true;
    }
    this.m_ToposurfaceCheckBox.Checked = false;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("LocateComponentsPickToposurface", ref _nReturnValue))
      this.m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
    Parameter parameter1 = (Parameter) null;
    string name = string.Empty;
    if (this.m_dataBuffer.SurfaceList.Count > 0)
    {
      int num = 1;
      foreach (TopographySurfaceContainer surface in this.m_dataBuffer.SurfaceList)
      {
        Parameter parameter2 = ((Element) surface.TopographySurface)[(BuiltInParameter) -1006900];
        if (parameter2 != null)
          name = parameter2.AsString();
        if (name == null || name == string.Empty)
        {
          name = $"<{EPShared.LocalRM.GetString("UnnamedSurfaceDialog")} {Convert.ToString(num)}>";
          ++num;
        }
        this.m_SurfaceList.Items.Add((object) new ToposurfaceItem(name, surface));
      }
    }
    else
    {
      this.m_ToposurfaceCheckBox.Checked = false;
      this.m_ToposurfaceCheckBox.Enabled = false;
      this.m_SurfaceList.Enabled = false;
    }
    parameter1 = (Parameter) null;
    string empty2 = string.Empty;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsSurfaceName", ref empty1))
    {
      for (int index = 0; index < this.m_SurfaceList.Items.Count; ++index)
      {
        if (this.m_SurfaceList.Items[index] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, empty1, true) == 0)
        {
          this.m_SurfaceList.SelectedIndex = index;
          break;
        }
      }
    }
    if (this.m_SurfaceList.Items.Count <= 0 || this.m_SurfaceList.SelectedIndex != -1)
      return;
    this.m_SurfaceList.SelectedIndex = 0;
  }

  private View GetCurrentView()
  {
    View currentView = (View) null;
    bool flag = false;
    for (int index = 0; index < this.m_dataBuffer.Views.Count; ++index)
    {
      currentView = this.m_dataBuffer.Views[index];
      string strB = $"{currentView.ViewType.ToString()}-{((Element) currentView).Name}";
      if (currentView != null && string.Compare(Convert.ToString(this.m_LevelComboBox.Items[this.m_LevelComboBox.SelectedIndex]), strB, true) == 0)
        break;
      if (flag)
        break;
    }
    return currentView;
  }

  private void SaveSettings()
  {
    this.m_CurView = this.GetCurrentView();
    if (this.m_CurView == null)
    {
      int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    }
    else
    {
      this.m_CurType = this.m_ComponentNameComboBox.SelectedItem as FamilySymbol;
      if (this.m_CurType == null)
      {
        int num2 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
      else
      {
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsPlacementOption", !this.m_HedgeRowRadioButton.Checked ? 1 : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsHedgeRowOption", !this.m_CenterHedgeRadioButton.Checked ? (!this.m_AlternateHedgeRadioButton.Checked ? 2 : 1) : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsGroveRowOption", !this.m_TriangularRadioButton.Checked ? 1 : 0);
        double _dReturnedDouble = 0.0;
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsSpacing", _dReturnedDouble);
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsSetback", _dReturnedDouble);
        _dReturnedDouble = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_RotationTextBox.Text);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsGroveRotation", _dReturnedDouble);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsExistingElement", Convert.ToInt32(this.m_ExistingElementCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsDeleteExisting", Convert.ToInt32(this.m_DeleteExistingCheckBox.Checked));
        if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble, false))
          ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsStartingDistance", _dReturnedDouble);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsAllignTo", Convert.ToInt32(this.m_AlignToCheckBox.Checked));
        if (this.m_ComponentFamilyComboBox.SelectedItem is FamilyContainer selectedItem)
          ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsFamilyName", selectedItem.FamilyName);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsPlantName", ((Element) this.m_CurType).Name);
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsViewName", Convert.ToString(this.m_LevelComboBox.SelectedItem));
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsSegmentChainOption", !this.m_SegmentRadioButton.Checked ? 1 : 0);
        ApplicationUtility.Settings.eplSetE_SetSetting("LocateComponentsPickToposurface", Convert.ToInt32(this.m_ToposurfaceCheckBox.Checked));
        ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, "LocateComponentsSurfaceName", Convert.ToString(this.m_SurfaceList.SelectedItem));
      }
    }
  }

  private bool ValidateFields()
  {
    double _dReturnedDouble = 0.0;
    if (string.IsNullOrEmpty(this.m_PlantSpacingTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoComponentSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_PlantSpacingTextBox.Focus();
      return false;
    }
    if (!RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble) || _dReturnedDouble <= 1E-05)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidComponentSpacingMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_PlantSpacingTextBox.Focus();
      return false;
    }
    if (!this.m_HedgeRowRadioButton.Checked || this.m_CenterHedgeRadioButton.Checked || RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble) && _dReturnedDouble > 1E-05)
      return true;
    int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ValidSetbackMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    this.m_SetbackTextBox.Focus();
    return false;
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnHedgeRowGroveOptionChecked(object sender, EventArgs e)
  {
    this.m_CenterHedgeRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_AlternateHedgeRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_SideHedgeRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_AlignToCheckBox.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_TriangularRadioButton.Enabled = !this.m_HedgeRowRadioButton.Checked;
    this.m_SquareRadioButton.Enabled = !this.m_HedgeRowRadioButton.Checked;
    this.m_RotationLabel.Enabled = !this.m_HedgeRowRadioButton.Checked;
    this.m_RotationTextBox.Enabled = !this.m_HedgeRowRadioButton.Checked;
    this.m_SegmentRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_ChainRadioButton.Enabled = this.m_HedgeRowRadioButton.Checked;
    this.m_StartingDistanceLabel.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
    this.m_StartingDistanceTextBox.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
    this.OnHedgeRowOptionChecked(sender, e);
  }

  private void OnHedgeRowOptionChecked(object sender, EventArgs e)
  {
    if (this.m_HedgeRowRadioButton.Checked)
    {
      this.m_SetbackLabel.Enabled = !this.m_CenterHedgeRadioButton.Checked;
      this.m_SetbackTextBox.Enabled = !this.m_CenterHedgeRadioButton.Checked;
    }
    else
    {
      this.m_SetbackLabel.Enabled = true;
      this.m_SetbackTextBox.Enabled = true;
    }
  }

  private void FormatPlantSpacingValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_PlantSpacingTextBox.Text = empty;
    }
    else
      this.m_PlantSpacingTextBox.Focus();
  }

  private void OnPlantSpacingTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatPlantSpacingValue();
  }

  private void FormatSetbackValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_SetbackTextBox.Text = empty;
    }
    else
      this.m_SetbackTextBox.Focus();
  }

  private void OnSetbackTextBoxLeave(object sender, EventArgs e) => this.FormatSetbackValue();

  private void FormatRotationValue()
  {
    string empty = string.Empty;
    if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(this.m_AngularOptions.DisplayUnits, RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_RotationTextBox.Text), this.m_dAngularRounding, this.m_AngularSymbolType, this.m_DecimalSymbolType, ref empty) == 0)
      this.m_RotationTextBox.Text = empty;
    else
      this.m_RotationTextBox.Focus();
  }

  private void OnRotationTextBoxLeave(object sender, EventArgs e) => this.FormatRotationValue();

  private void OnPlantSpacingTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatPlantSpacingValue();
  }

  private void OnRotationTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatRotationValue();
  }

  private void OnSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyCode != Keys.Return)
      return;
    e.Handled = true;
    this.FormatSetbackValue();
  }

  private void OnComponentNameComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
  }

  private void OnLocateComponentsClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnComponentFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_ComponentFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_ComponentNameComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_ComponentNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_ComponentFamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectComponentFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadComponentFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            this.m_dataBuffer.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_dataBuffer.TransactionContainer.Rollback();
            flag = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ComponentFamilyCantBeLoadedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ComponentFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilyAndSymbolLists();
        this.m_ComponentFamilyComboBox.DataSource = (object) this.m_dataBuffer.FamilyList;
        this.m_ComponentFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_ComponentFamilyComboBox.Items.Count; ++index)
          {
            if (this.m_ComponentFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_ComponentFamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_ComponentFamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotComponentMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
  {
    this.m_DeleteExistingCheckBox.Enabled = this.m_ExistingElementCheckBox.Checked;
    this.m_StartingDistanceLabel.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
    this.m_StartingDistanceTextBox.Enabled = this.m_ExistingElementCheckBox.Checked && this.m_HedgeRowRadioButton.Checked;
  }

  private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatStartingDistanceValue();
  }

  private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatStartingDistanceValue();
  }

  private void FormatStartingDistanceValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
      this.m_StartingDistanceTextBox.Text = empty;
    }
    else
      this.m_StartingDistanceTextBox.Focus();
  }

  private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
  {
    this.m_SurfaceList.Enabled = this.m_ToposurfaceCheckBox.Checked;
    this.m_SelectedSurfaceLabel.Enabled = this.m_ToposurfaceCheckBox.Checked;
  }

  public bool HedgeRowChecked => this.m_HedgeRowRadioButton.Checked;

  public bool GroveChecked => this.m_GroveRadioButton.Checked;

  public bool TriangularGroveChecked => this.m_TriangularRadioButton.Checked;

  public bool SquareGroveChecked => this.m_SquareRadioButton.Checked;

  public bool CenteredHedgeRowChecked => this.m_CenterHedgeRadioButton.Checked;

  public bool AlternateHedgeRowChecked => this.m_AlternateHedgeRadioButton.Checked;

  public bool SideHedgeRadioButton => this.m_SideHedgeRadioButton.Checked;

  public bool ExistingElementChecked => this.m_ExistingElementCheckBox.Checked;

  public bool DeleteExistingChecked
  {
    get => this.m_ExistingElementCheckBox.Checked && this.m_DeleteExistingCheckBox.Checked;
  }

  public double StartingDistance
  {
    get
    {
      if (!this.m_HedgeRowRadioButton.Checked || !this.m_ExistingElementCheckBox.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_StartingDistanceTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_StartingDistanceTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool AlignTo => this.m_AlignToCheckBox.Checked;

  public Level Level => this.m_CurView.GenLevel;

  public View View => this.m_CurView;

  public FamilySymbol Type => this.m_CurType;

  public double RotationAngle
  {
    get
    {
      double rotationAngle = 0.0;
      if (this.m_RotationTextBox.Text != string.Empty)
        rotationAngle = RevitGeometry.eplGeoE_ConvertAngleToRadians(this.m_RotationTextBox.Text);
      return rotationAngle;
    }
  }

  public double ComponentSpacing
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_PlantSpacingTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_PlantSpacingTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double SetbackSpacing
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_SetbackTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_SetbackTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool SegmentChecked => this.m_SegmentRadioButton.Checked;

  public bool ChainChecked => this.m_ChainRadioButton.Checked;

  public PlacementType PlacementType
  {
    get
    {
      if (this.m_HedgeRowRadioButton.Checked)
      {
        if (this.m_CenterHedgeRadioButton.Checked)
          return PlacementType.HedgeRowCenter;
        return this.m_AlternateHedgeRadioButton.Checked ? PlacementType.HedgeRowAlternate : PlacementType.HedgeRowSide;
      }
      return this.m_TriangularRadioButton.Checked ? PlacementType.GroveTrianglular : PlacementType.GroveSquare;
    }
  }

  public TopographySurfaceContainer Surface
  {
    get
    {
      TopographySurfaceContainer surface = (TopographySurfaceContainer) null;
      if (this.m_SurfaceList.SelectedItem is ToposurfaceItem selectedItem)
        surface = selectedItem.Value;
      return surface;
    }
  }

  public bool PickToposurface => this.m_ToposurfaceCheckBox.Checked;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ComponentFamilyLabel = new Label();
    this.m_ComponentFamilyComboBox = new ComboBox();
    this.m_LevelComboBox = new ComboBox();
    this.m_LevelLabel = new Label();
    this.m_HedgeRowRadioButton = new RadioButton();
    this.m_ComponentNameLabel = new Label();
    this.m_ComponentNameComboBox = new ComboBox();
    this.m_ComponentSpacingLabel = new Label();
    this.m_PlantSpacingTextBox = new TextBox();
    this.m_SetbackLabel = new Label();
    this.m_SetbackTextBox = new TextBox();
    this.m_GroveRadioButton = new RadioButton();
    this.m_HedgeRowPanel = new Panel();
    this.m_SideHedgeRadioButton = new RadioButton();
    this.m_AlternateHedgeRadioButton = new RadioButton();
    this.m_CenterHedgeRadioButton = new RadioButton();
    this.m_GrovePanel = new Panel();
    this.m_SquareRadioButton = new RadioButton();
    this.m_TriangularRadioButton = new RadioButton();
    this.m_RotationLabel = new Label();
    this.m_RotationTextBox = new TextBox();
    this.m_AlignToCheckBox = new CheckBox();
    this.m_LoadFamilyButton = new Button();
    this.m_ExistingElementCheckBox = new CheckBox();
    this.m_MoveablePanel = new Panel();
    this.m_StartingDistanceLabel = new Label();
    this.m_StartingDistanceTextBox = new TextBox();
    this.m_DeleteExistingCheckBox = new CheckBox();
    this.m_CancelButton = new Button();
    this.m_InsertButton = new Button();
    this.m_ChainRadioButton = new RadioButton();
    this.m_SegmentRadioButton = new RadioButton();
    this.m_ToposurfacePickerPanel = new Panel();
    this.m_SurfaceList = new ComboBox();
    this.m_SelectedSurfaceLabel = new Label();
    this.m_ToposurfaceCheckBox = new CheckBox();
    this.m_SegmentChainPanel = new Panel();
    this.m_HedgeRowPanel.SuspendLayout();
    this.m_GrovePanel.SuspendLayout();
    this.m_MoveablePanel.SuspendLayout();
    this.m_ToposurfacePickerPanel.SuspendLayout();
    this.m_SegmentChainPanel.SuspendLayout();
    this.SuspendLayout();
    this.m_ComponentFamilyLabel.AutoSize = true;
    this.m_ComponentFamilyLabel.Location = new Point(12, 15);
    this.m_ComponentFamilyLabel.Name = "m_ComponentFamilyLabel";
    this.m_ComponentFamilyLabel.Size = new Size(96 /*0x60*/, 13);
    this.m_ComponentFamilyLabel.TabIndex = 0;
    this.m_ComponentFamilyLabel.Text = "&Component Family:";
    this.m_ComponentFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ComponentFamilyComboBox.FormattingEnabled = true;
    this.m_ComponentFamilyComboBox.Location = new Point(130, 12);
    this.m_ComponentFamilyComboBox.Name = "m_ComponentFamilyComboBox";
    this.m_ComponentFamilyComboBox.Size = new Size(215, 21);
    this.m_ComponentFamilyComboBox.TabIndex = 1;
    this.m_ComponentFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnComponentFamilyComboBoxSelectedIndexChanged);
    this.m_LevelComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_LevelComboBox.FormattingEnabled = true;
    this.m_LevelComboBox.Location = new Point(130, 276);
    this.m_LevelComboBox.Name = "m_LevelComboBox";
    this.m_LevelComboBox.Size = new Size(215, 21);
    this.m_LevelComboBox.TabIndex = 17;
    this.m_LevelLabel.AutoSize = true;
    this.m_LevelLabel.Location = new Point(12, 279);
    this.m_LevelLabel.Name = "m_LevelLabel";
    this.m_LevelLabel.Size = new Size(36, 13);
    this.m_LevelLabel.TabIndex = 16 /*0x10*/;
    this.m_LevelLabel.Text = "&Level:";
    this.m_HedgeRowRadioButton.AutoSize = true;
    this.m_HedgeRowRadioButton.Location = new Point(12, 97);
    this.m_HedgeRowRadioButton.Name = "m_HedgeRowRadioButton";
    this.m_HedgeRowRadioButton.Size = new Size(82, 17);
    this.m_HedgeRowRadioButton.TabIndex = 7;
    this.m_HedgeRowRadioButton.TabStop = true;
    this.m_HedgeRowRadioButton.Text = "&Place Along";
    this.m_HedgeRowRadioButton.UseVisualStyleBackColor = true;
    this.m_HedgeRowRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowGroveOptionChecked);
    this.m_ComponentNameLabel.AutoSize = true;
    this.m_ComponentNameLabel.Location = new Point(12, 43);
    this.m_ComponentNameLabel.Name = "m_ComponentNameLabel";
    this.m_ComponentNameLabel.Size = new Size(95, 13);
    this.m_ComponentNameLabel.TabIndex = 3;
    this.m_ComponentNameLabel.Text = "C&omponent Name:";
    this.m_ComponentNameComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ComponentNameComboBox.FormattingEnabled = true;
    this.m_ComponentNameComboBox.Location = new Point(130, 39);
    this.m_ComponentNameComboBox.Name = "m_ComponentNameComboBox";
    this.m_ComponentNameComboBox.Size = new Size(215, 21);
    this.m_ComponentNameComboBox.TabIndex = 4;
    this.m_ComponentNameComboBox.SelectedIndexChanged += new EventHandler(this.OnComponentNameComboBoxSelectedIndexChanged);
    this.m_ComponentSpacingLabel.AutoSize = true;
    this.m_ComponentSpacingLabel.Location = new Point(12, 69);
    this.m_ComponentSpacingLabel.Name = "m_ComponentSpacingLabel";
    this.m_ComponentSpacingLabel.Size = new Size(106, 13);
    this.m_ComponentSpacingLabel.TabIndex = 5;
    this.m_ComponentSpacingLabel.Text = "Component &Spacing:";
    this.m_PlantSpacingTextBox.Location = new Point(130, 66);
    this.m_PlantSpacingTextBox.Name = "m_PlantSpacingTextBox";
    this.m_PlantSpacingTextBox.Size = new Size(100, 20);
    this.m_PlantSpacingTextBox.TabIndex = 6;
    this.m_PlantSpacingTextBox.KeyDown += new KeyEventHandler(this.OnPlantSpacingTextBoxKeyDown);
    this.m_PlantSpacingTextBox.Leave += new EventHandler(this.OnPlantSpacingTextBoxLeave);
    this.m_SetbackLabel.AutoSize = true;
    this.m_SetbackLabel.Location = new Point(12, 253);
    this.m_SetbackLabel.Name = "m_SetbackLabel";
    this.m_SetbackLabel.Size = new Size(50, 13);
    this.m_SetbackLabel.TabIndex = 14;
    this.m_SetbackLabel.Text = "Set&back:";
    this.m_SetbackTextBox.Location = new Point(130, 250);
    this.m_SetbackTextBox.Name = "m_SetbackTextBox";
    this.m_SetbackTextBox.Size = new Size(100, 20);
    this.m_SetbackTextBox.TabIndex = 15;
    this.m_SetbackTextBox.KeyDown += new KeyEventHandler(this.OnSetbackTextBoxKeyDown);
    this.m_SetbackTextBox.Leave += new EventHandler(this.OnSetbackTextBoxLeave);
    this.m_GroveRadioButton.AutoSize = true;
    this.m_GroveRadioButton.Location = new Point(12, 171);
    this.m_GroveRadioButton.Name = "m_GroveRadioButton";
    this.m_GroveRadioButton.Size = new Size(88, 17);
    this.m_GroveRadioButton.TabIndex = 10;
    this.m_GroveRadioButton.TabStop = true;
    this.m_GroveRadioButton.Text = "Place in &Area";
    this.m_GroveRadioButton.UseVisualStyleBackColor = true;
    this.m_GroveRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowGroveOptionChecked);
    this.m_HedgeRowPanel.Controls.Add((Control) this.m_SideHedgeRadioButton);
    this.m_HedgeRowPanel.Controls.Add((Control) this.m_AlternateHedgeRadioButton);
    this.m_HedgeRowPanel.Controls.Add((Control) this.m_CenterHedgeRadioButton);
    this.m_HedgeRowPanel.Location = new Point(29, 120);
    this.m_HedgeRowPanel.Name = "m_HedgeRowPanel";
    this.m_HedgeRowPanel.Size = new Size(316, 24);
    this.m_HedgeRowPanel.TabIndex = 8;
    this.m_SideHedgeRadioButton.AutoSize = true;
    this.m_SideHedgeRadioButton.Location = new Point(253, 4);
    this.m_SideHedgeRadioButton.Name = "m_SideHedgeRadioButton";
    this.m_SideHedgeRadioButton.Size = new Size(46, 17);
    this.m_SideHedgeRadioButton.TabIndex = 2;
    this.m_SideHedgeRadioButton.TabStop = true;
    this.m_SideHedgeRadioButton.Text = "&Side";
    this.m_SideHedgeRadioButton.UseVisualStyleBackColor = true;
    this.m_SideHedgeRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowOptionChecked);
    this.m_AlternateHedgeRadioButton.AutoSize = true;
    this.m_AlternateHedgeRadioButton.Location = new Point(119, 3);
    this.m_AlternateHedgeRadioButton.Name = "m_AlternateHedgeRadioButton";
    this.m_AlternateHedgeRadioButton.Size = new Size(67, 17);
    this.m_AlternateHedgeRadioButton.TabIndex = 1;
    this.m_AlternateHedgeRadioButton.TabStop = true;
    this.m_AlternateHedgeRadioButton.Text = "&Alternate";
    this.m_AlternateHedgeRadioButton.UseVisualStyleBackColor = true;
    this.m_AlternateHedgeRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowOptionChecked);
    this.m_CenterHedgeRadioButton.AutoSize = true;
    this.m_CenterHedgeRadioButton.Location = new Point(3, 4);
    this.m_CenterHedgeRadioButton.Name = "m_CenterHedgeRadioButton";
    this.m_CenterHedgeRadioButton.Size = new Size(56, 17);
    this.m_CenterHedgeRadioButton.TabIndex = 0;
    this.m_CenterHedgeRadioButton.TabStop = true;
    this.m_CenterHedgeRadioButton.Text = "C&enter";
    this.m_CenterHedgeRadioButton.UseVisualStyleBackColor = true;
    this.m_CenterHedgeRadioButton.CheckedChanged += new EventHandler(this.OnHedgeRowOptionChecked);
    this.m_GrovePanel.Controls.Add((Control) this.m_SquareRadioButton);
    this.m_GrovePanel.Controls.Add((Control) this.m_TriangularRadioButton);
    this.m_GrovePanel.Location = new Point(29, 194);
    this.m_GrovePanel.Name = "m_GrovePanel";
    this.m_GrovePanel.Size = new Size(316, 24);
    this.m_GrovePanel.TabIndex = 11;
    this.m_SquareRadioButton.AutoSize = true;
    this.m_SquareRadioButton.Location = new Point(119, 4);
    this.m_SquareRadioButton.Name = "m_SquareRadioButton";
    this.m_SquareRadioButton.Size = new Size(59, 17);
    this.m_SquareRadioButton.TabIndex = 1;
    this.m_SquareRadioButton.TabStop = true;
    this.m_SquareRadioButton.Text = "S&quare";
    this.m_SquareRadioButton.UseVisualStyleBackColor = true;
    this.m_TriangularRadioButton.AutoSize = true;
    this.m_TriangularRadioButton.Location = new Point(3, 3);
    this.m_TriangularRadioButton.Name = "m_TriangularRadioButton";
    this.m_TriangularRadioButton.Size = new Size(72, 17);
    this.m_TriangularRadioButton.TabIndex = 0;
    this.m_TriangularRadioButton.TabStop = true;
    this.m_TriangularRadioButton.Text = "Triang&ular";
    this.m_TriangularRadioButton.UseVisualStyleBackColor = true;
    this.m_RotationLabel.AutoSize = true;
    this.m_RotationLabel.Enabled = false;
    this.m_RotationLabel.Location = new Point(31 /*0x1F*/, 227);
    this.m_RotationLabel.Name = "m_RotationLabel";
    this.m_RotationLabel.Size = new Size(50, 13);
    this.m_RotationLabel.TabIndex = 12;
    this.m_RotationLabel.Text = "R&otation:";
    this.m_RotationTextBox.Enabled = false;
    this.m_RotationTextBox.Location = new Point(130, 224 /*0xE0*/);
    this.m_RotationTextBox.Name = "m_RotationTextBox";
    this.m_RotationTextBox.Size = new Size(100, 20);
    this.m_RotationTextBox.TabIndex = 13;
    this.m_RotationTextBox.KeyDown += new KeyEventHandler(this.OnRotationTextBoxKeyDown);
    this.m_RotationTextBox.Leave += new EventHandler(this.OnRotationTextBoxLeave);
    this.m_AlignToCheckBox.AutoSize = true;
    this.m_AlignToCheckBox.Location = new Point(32 /*0x20*/, 150);
    this.m_AlignToCheckBox.Name = "m_AlignToCheckBox";
    this.m_AlignToCheckBox.Size = new Size(65, 17);
    this.m_AlignToCheckBox.TabIndex = 9;
    this.m_AlignToCheckBox.Text = "Ali&gn To";
    this.m_AlignToCheckBox.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Location = new Point(351, 13);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_ExistingElementCheckBox.AutoSize = true;
    this.m_ExistingElementCheckBox.Location = new Point(12, 376);
    this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
    this.m_ExistingElementCheckBox.Size = new Size(103, 17);
    this.m_ExistingElementCheckBox.TabIndex = 20;
    this.m_ExistingElementCheckBox.Text = "Existing Ele&ment";
    this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
    this.m_ExistingElementCheckBox.CheckedChanged += new EventHandler(this.OnExistingElementCheckBoxChecked);
    this.m_MoveablePanel.Controls.Add((Control) this.m_StartingDistanceLabel);
    this.m_MoveablePanel.Controls.Add((Control) this.m_StartingDistanceTextBox);
    this.m_MoveablePanel.Controls.Add((Control) this.m_DeleteExistingCheckBox);
    this.m_MoveablePanel.Controls.Add((Control) this.m_CancelButton);
    this.m_MoveablePanel.Controls.Add((Control) this.m_InsertButton);
    this.m_MoveablePanel.Location = new Point(12, 399);
    this.m_MoveablePanel.Name = "m_MoveablePanel";
    this.m_MoveablePanel.Size = new Size(363, 72);
    this.m_MoveablePanel.TabIndex = 21;
    this.m_StartingDistanceLabel.AutoSize = true;
    this.m_StartingDistanceLabel.Enabled = false;
    this.m_StartingDistanceLabel.Location = new Point(20, 26);
    this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
    this.m_StartingDistanceLabel.Size = new Size(91, 13);
    this.m_StartingDistanceLabel.TabIndex = 1;
    this.m_StartingDistanceLabel.Text = "Starting Distance:";
    this.m_StartingDistanceTextBox.Enabled = false;
    this.m_StartingDistanceTextBox.Location = new Point(118, 23);
    this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
    this.m_StartingDistanceTextBox.Size = new Size(100, 20);
    this.m_StartingDistanceTextBox.TabIndex = 2;
    this.m_StartingDistanceTextBox.KeyDown += new KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
    this.m_StartingDistanceTextBox.Leave += new EventHandler(this.OnStartingDistanceTextBoxLeave);
    this.m_DeleteExistingCheckBox.AutoSize = true;
    this.m_DeleteExistingCheckBox.Enabled = false;
    this.m_DeleteExistingCheckBox.Location = new Point(20, 0);
    this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
    this.m_DeleteExistingCheckBox.Size = new Size(137, 17);
    this.m_DeleteExistingCheckBox.TabIndex = 0;
    this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
    this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
    this.m_CancelButton.DialogResult = DialogResult.Cancel;
    this.m_CancelButton.Location = new Point(287, 49);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(76, 23);
    this.m_CancelButton.TabIndex = 4;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_InsertButton.Location = new Point(206, 49);
    this.m_InsertButton.Name = "m_InsertButton";
    this.m_InsertButton.Size = new Size(75, 23);
    this.m_InsertButton.TabIndex = 3;
    this.m_InsertButton.Text = "&Insert";
    this.m_InsertButton.UseVisualStyleBackColor = true;
    this.m_InsertButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_ChainRadioButton.AutoSize = true;
    this.m_ChainRadioButton.Location = new Point(118, 0);
    this.m_ChainRadioButton.Name = "m_ChainRadioButton";
    this.m_ChainRadioButton.Size = new Size(52, 17);
    this.m_ChainRadioButton.TabIndex = 1;
    this.m_ChainRadioButton.Text = "&Chain";
    this.m_ChainRadioButton.UseVisualStyleBackColor = true;
    this.m_SegmentRadioButton.AutoSize = true;
    this.m_SegmentRadioButton.Checked = true;
    this.m_SegmentRadioButton.Location = new Point(0, 0);
    this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
    this.m_SegmentRadioButton.Size = new Size(67, 17);
    this.m_SegmentRadioButton.TabIndex = 0;
    this.m_SegmentRadioButton.TabStop = true;
    this.m_SegmentRadioButton.Text = "&Segment";
    this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_ToposurfacePickerPanel.Controls.Add((Control) this.m_SurfaceList);
    this.m_ToposurfacePickerPanel.Controls.Add((Control) this.m_SelectedSurfaceLabel);
    this.m_ToposurfacePickerPanel.Controls.Add((Control) this.m_ToposurfaceCheckBox);
    this.m_ToposurfacePickerPanel.Location = new Point(12, 303);
    this.m_ToposurfacePickerPanel.Name = "m_ToposurfacePickerPanel";
    this.m_ToposurfacePickerPanel.Size = new Size(363, 44);
    this.m_ToposurfacePickerPanel.TabIndex = 18;
    this.m_SurfaceList.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_SurfaceList.Enabled = false;
    this.m_SurfaceList.FormattingEnabled = true;
    this.m_SurfaceList.Location = new Point(118, 23);
    this.m_SurfaceList.Name = "m_SurfaceList";
    this.m_SurfaceList.Size = new Size(215, 21);
    this.m_SurfaceList.TabIndex = 2;
    this.m_SelectedSurfaceLabel.AutoSize = true;
    this.m_SelectedSurfaceLabel.Enabled = false;
    this.m_SelectedSurfaceLabel.Location = new Point(0, 26);
    this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
    this.m_SelectedSurfaceLabel.Size = new Size(44, 13);
    this.m_SelectedSurfaceLabel.TabIndex = 1;
    this.m_SelectedSurfaceLabel.Text = "Surface";
    this.m_ToposurfaceCheckBox.AutoSize = true;
    this.m_ToposurfaceCheckBox.Location = new Point(0, 0);
    this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
    this.m_ToposurfaceCheckBox.Size = new Size(119, 17);
    this.m_ToposurfaceCheckBox.TabIndex = 0;
    this.m_ToposurfaceCheckBox.Text = "Toposurface Picker";
    this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
    this.m_ToposurfaceCheckBox.CheckStateChanged += new EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
    this.m_SegmentChainPanel.Controls.Add((Control) this.m_SegmentRadioButton);
    this.m_SegmentChainPanel.Controls.Add((Control) this.m_ChainRadioButton);
    this.m_SegmentChainPanel.Location = new Point(12, 353);
    this.m_SegmentChainPanel.Name = "m_SegmentChainPanel";
    this.m_SegmentChainPanel.Size = new Size(363, 17);
    this.m_SegmentChainPanel.TabIndex = 19;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(387, 483);
    this.Controls.Add((Control) this.m_SegmentChainPanel);
    this.Controls.Add((Control) this.m_ToposurfacePickerPanel);
    this.Controls.Add((Control) this.m_MoveablePanel);
    this.Controls.Add((Control) this.m_ExistingElementCheckBox);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_AlignToCheckBox);
    this.Controls.Add((Control) this.m_RotationLabel);
    this.Controls.Add((Control) this.m_RotationTextBox);
    this.Controls.Add((Control) this.m_GrovePanel);
    this.Controls.Add((Control) this.m_HedgeRowPanel);
    this.Controls.Add((Control) this.m_GroveRadioButton);
    this.Controls.Add((Control) this.m_SetbackLabel);
    this.Controls.Add((Control) this.m_SetbackTextBox);
    this.Controls.Add((Control) this.m_ComponentSpacingLabel);
    this.Controls.Add((Control) this.m_PlantSpacingTextBox);
    this.Controls.Add((Control) this.m_ComponentNameComboBox);
    this.Controls.Add((Control) this.m_ComponentNameLabel);
    this.Controls.Add((Control) this.m_HedgeRowRadioButton);
    this.Controls.Add((Control) this.m_LevelComboBox);
    this.Controls.Add((Control) this.m_LevelLabel);
    this.Controls.Add((Control) this.m_ComponentFamilyComboBox);
    this.Controls.Add((Control) this.m_ComponentFamilyLabel);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (LocateComponentsForm);
    this.Text = "Locate Components";
    this.FormClosing += new FormClosingEventHandler(this.OnLocateComponentsClosing);
    this.m_HedgeRowPanel.ResumeLayout(false);
    this.m_HedgeRowPanel.PerformLayout();
    this.m_GrovePanel.ResumeLayout(false);
    this.m_GrovePanel.PerformLayout();
    this.m_MoveablePanel.ResumeLayout(false);
    this.m_MoveablePanel.PerformLayout();
    this.m_ToposurfacePickerPanel.ResumeLayout(false);
    this.m_ToposurfacePickerPanel.PerformLayout();
    this.m_SegmentChainPanel.ResumeLayout(false);
    this.m_SegmentChainPanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_InsertButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
