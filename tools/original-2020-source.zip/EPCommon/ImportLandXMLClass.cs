﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ImportLandXMLClass
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ImportLandXMLClass
{
  private Document m_Document;

  public ImportLandXMLClass(Document _CurDocument) => this.m_Document = _CurDocument;

  public void Run()
  {
    ImportLandXMLManager importLandXmlManager = new ImportLandXMLManager(this.m_Document);
    DialogResult dialogResult = importLandXmlManager.ShowDialog();
    Eps_Point _Point = new Eps_Point();
    for (; dialogResult == DialogResult.Retry; dialogResult = importLandXmlManager.ImportSurfaceAlignments())
    {
      RevitUtility.GetPointFromProject(this.m_Document, EPShared.LocalRM.GetString("PickCenterPointPrompt"), ref _Point, false);
      importLandXmlManager.ManualCenterBasePoint = _Point;
    }
  }

  public static FamilyInstance GetSiteComponentPlacementFamilyInstance(
    Document _Document,
    string _strTopoSurfaceId,
    bool _bCheckForSurface)
  {
    FindFamilyInstance = (FamilyInstance) null;
    Parameter SiteworksIDParameter = (Parameter) null;
    FilteredElementCollector source = new FilteredElementCollector(_Document);
    source.OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001260);
    foreach (Element element in ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => CurrentElement is FamilyInstance FindFamilyInstance && (SiteworksIDParameter = ((Element) FindFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.LandXMLSurfacePlacement).ToString("000"), true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null)).ToList<Element>())
    {
      if (element is FamilyInstance placementFamilyInstance && ((Element) placementFamilyInstance).Category != null && ((Element) placementFamilyInstance).Category.Id.IntegerValue == ((BuiltInCategory) -2001260).GetHashCode())
      {
        SiteworksIDParameter = ((Element) placementFamilyInstance.Symbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (SiteworksIDParameter != null)
        {
          if (string.Compare(SiteworksIDParameter.AsString(), Convert.ToInt32((object) LandcaddID.LandXMLSurfacePlacement).ToString("000"), true) != 0)
            return (FamilyInstance) null;
          if (!_bCheckForSurface)
            return placementFamilyInstance;
          Parameter parameter = ((Element) placementFamilyInstance).LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
          if (parameter != null && string.Compare(parameter.AsString(), _strTopoSurfaceId, true) == 0)
            return placementFamilyInstance;
        }
      }
    }
    return (FamilyInstance) null;
  }

  public static bool FindPositioningParameters(
    FamilyInstance _CurrentInstance,
    ref double _dDistance,
    ref double _dHzDirection,
    ref double _dVzDirection)
  {
    int num = 1;
    Parameter parameter1 = ((Element) _CurrentInstance).LookupParameter(RevitParameters.PositioningMethodLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter1 != null)
      num = parameter1.AsInteger();
    Parameter parameter2 = ((Element) _CurrentInstance).LookupParameter(RevitParameters.PositionDistanceLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter2 != null)
      _dDistance = parameter2.AsDouble();
    Parameter parameter3 = ((Element) _CurrentInstance).LookupParameter(RevitParameters.PositionHzDirectionLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter3 != null)
      _dHzDirection = parameter3.AsDouble();
    Parameter parameter4 = ((Element) _CurrentInstance).LookupParameter(RevitParameters.PositionVzDirectionLandXMLSurfacePlacementFamilyInstanceParameter);
    if (parameter4 != null)
      _dVzDirection = parameter4.AsDouble();
    return num != 1;
  }
}
