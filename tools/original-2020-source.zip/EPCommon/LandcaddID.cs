﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandcaddID
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public enum LandcaddID
{
  PlantMix = 1,
  PatioWalk = 2,
  ParkingStall = 3,
  ADAParkingStall = 4,
  ParkingBumper = 5,
  ParkingIsland = 6,
  Fence = 7,
  Planting = 8,
  FamilyInstancePlacement = 9,
  SoftTerrain = 101, // 0x00000065
  Street = 102, // 0x00000066
  Curb = 103, // 0x00000067
  Sidewalk = 104, // 0x00000068
  RetainingWall = 105, // 0x00000069
  Steps = 106, // 0x0000006A
  ParkingLot = 107, // 0x0000006B
  SiteComponentPlacement = 108, // 0x0000006C
  TopoSurfacePlacement = 109, // 0x0000006D
  LandXMLSurfacePlacement = 110, // 0x0000006E
  FeatureLine = 111, // 0x0000006F
  BuildingPadPlacement = 112, // 0x00000070
  PointWipeout = 113, // 0x00000071
  IntersectionPlacement = 114, // 0x00000072
  Pipe = 115, // 0x00000073
  Structure = 116, // 0x00000074
}
