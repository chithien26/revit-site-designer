﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.EPTransactionContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class EPTransactionContainer
{
  private Document m_Document;
  private Transaction m_Transaction;
  private SubTransaction m_SubTransaction;
  private FailurePreprocessor m_FailurePreprocessor;
  private TopographyEditScope m_TopographyEditScope;
  private TransactionGroup m_TransactionGroup;

  public EPTransactionContainer(Document _Document)
  {
    this.m_Document = _Document;
    this.m_Transaction = new Transaction(_Document);
    this.m_SubTransaction = new SubTransaction(_Document);
  }

  public bool Start() => this.Start(string.Empty);

  public bool Start(string _strTransactionName)
  {
    return this.m_Transaction != null && !this.m_Transaction.HasStarted() && (!(_strTransactionName != string.Empty) ? this.m_Transaction.Start() : this.m_Transaction.Start(_strTransactionName)) == 1;
  }

  public bool Commit()
  {
    if (this.m_Transaction != null && !this.m_Transaction.HasEnded() && this.m_Transaction.HasStarted())
    {
      this.FailureHandlingOptions(BuiltInFailures.OverlapFailures.DuplicateInstances);
      if (this.m_Transaction.Commit() == 3)
        return true;
    }
    return false;
  }

  public bool Rollback()
  {
    return this.m_Transaction != null && !this.m_Transaction.HasEnded() && this.m_Transaction.HasStarted() && this.m_Transaction.RollBack() == 2;
  }

  public bool StartTopographyEditScope(string transName, ElementId topoID)
  {
    try
    {
      if (this.m_TopographyEditScope == null)
        this.m_TopographyEditScope = new TopographyEditScope(this.m_Document, transName);
      if (!((EditScope) this.m_TopographyEditScope).IsActive && this.m_TopographyEditScope.IsPermitted)
        this.m_TopographyEditScope.Start(topoID);
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool CommitTopographyEditScope(
    ref TopographyEditFailuresPreprocessor failuresPreprocessor)
  {
    try
    {
      if (this.m_TopographyEditScope != null && ((EditScope) this.m_TopographyEditScope).IsActive)
        ((EditScope) this.m_TopographyEditScope).Commit((IFailuresPreprocessor) failuresPreprocessor);
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool DisposeTopographyEditScope()
  {
    try
    {
      if (this.m_TopographyEditScope != null && !((EditScope) this.m_TopographyEditScope).IsActive)
        ((EditScope) this.m_TopographyEditScope).Dispose();
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool StartTransactionGroup(string transName)
  {
    try
    {
      if (this.m_TransactionGroup == null)
        this.m_TransactionGroup = new TransactionGroup(this.m_Document, transName);
      if (!this.m_TransactionGroup.HasStarted())
        this.m_TransactionGroup.Start().ToString();
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool CommitTransactionGroup()
  {
    try
    {
      if (this.m_TransactionGroup != null && this.m_TransactionGroup.HasStarted())
        this.m_TransactionGroup.Commit();
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool AssimilateTransactionGroup()
  {
    try
    {
      if (this.m_TransactionGroup != null && this.m_TransactionGroup.HasStarted())
        this.m_TransactionGroup.Assimilate();
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool RollbackTransactionGroup()
  {
    try
    {
      if (this.m_TransactionGroup != null && this.m_TransactionGroup.HasStarted())
        this.m_TransactionGroup.RollBack();
      return true;
    }
    catch
    {
      return false;
    }
  }

  public bool BeginTransaction()
  {
    return this.m_Transaction != null && !this.m_Transaction.HasEnded() && this.m_Transaction.HasStarted() && this.m_SubTransaction != null && !this.m_SubTransaction.HasStarted() && this.m_SubTransaction.Start() == 1;
  }

  public bool EndTransaction()
  {
    return this.m_Transaction != null && !this.m_Transaction.HasEnded() && this.m_Transaction.HasStarted() && this.m_SubTransaction != null && !this.m_SubTransaction.HasEnded() && this.m_SubTransaction.Commit() == 3;
  }

  public void AbortTransaction()
  {
    if (this.m_Transaction == null || this.m_Transaction.HasEnded() || !this.m_Transaction.HasStarted() || this.m_SubTransaction == null || this.m_SubTransaction.HasEnded())
      return;
    this.m_SubTransaction.RollBack();
  }

  public string GetName()
  {
    return this.m_Transaction != null ? this.m_Transaction.GetName() : string.Empty;
  }

  public void SetName(string _strTransactionName)
  {
    if (this.m_Transaction == null || !(_strTransactionName != string.Empty) || string.Compare(_strTransactionName, this.m_Transaction.GetName(), true) == 0)
      return;
    this.m_Transaction.SetName(_strTransactionName);
  }

  public bool HasStarted()
  {
    return this.m_Transaction != null && !this.m_Transaction.HasEnded() && this.m_Transaction.HasStarted();
  }

  public void FailureHandlingOptions(List<FailureDefinitionId> FailureDefinitionIdList)
  {
    if (this.m_Transaction == null || this.m_Transaction.HasEnded() || !this.m_Transaction.HasStarted())
      return;
    if (this.m_FailurePreprocessor == null)
    {
      this.m_FailurePreprocessor = new FailurePreprocessor(FailureDefinitionIdList);
    }
    else
    {
      if (this.m_FailurePreprocessor.FailureDefinitionIdList == null)
        this.m_FailurePreprocessor.FailureDefinitionIdList = new List<FailureDefinitionId>();
      foreach (FailureDefinitionId failureDefinitionId in FailureDefinitionIdList)
      {
        if (!this.CheckDuplicateId(failureDefinitionId))
          this.m_FailurePreprocessor.FailureDefinitionIdList.Add(failureDefinitionId);
      }
    }
    Autodesk.Revit.DB.FailureHandlingOptions failureHandlingOptions = this.m_Transaction.GetFailureHandlingOptions();
    failureHandlingOptions.SetFailuresPreprocessor((IFailuresPreprocessor) this.m_FailurePreprocessor);
    this.m_Transaction.SetFailureHandlingOptions(failureHandlingOptions);
  }

  public void FailureHandlingOptions(FailureDefinitionId FailureDefinitionId)
  {
    if (this.m_Transaction == null || this.m_Transaction.HasEnded() || !this.m_Transaction.HasStarted())
      return;
    if (this.m_FailurePreprocessor == null)
    {
      this.m_FailurePreprocessor = new FailurePreprocessor(FailureDefinitionId);
    }
    else
    {
      if (this.m_FailurePreprocessor.FailureDefinitionIdList == null)
        this.m_FailurePreprocessor.FailureDefinitionIdList = new List<FailureDefinitionId>();
      if (!this.CheckDuplicateId(FailureDefinitionId))
        this.m_FailurePreprocessor.FailureDefinitionIdList.Add(FailureDefinitionId);
    }
    Autodesk.Revit.DB.FailureHandlingOptions failureHandlingOptions = this.m_Transaction.GetFailureHandlingOptions();
    failureHandlingOptions.SetFailuresPreprocessor((IFailuresPreprocessor) this.m_FailurePreprocessor);
    this.m_Transaction.SetFailureHandlingOptions(failureHandlingOptions);
  }

  private bool CheckDuplicateId(FailureDefinitionId _Id)
  {
    foreach (FailureDefinitionId failureDefinitionId in this.m_FailurePreprocessor.FailureDefinitionIdList)
    {
      if (FailureDefinitionId.op_Equality(_Id, failureDefinitionId))
        return true;
    }
    return false;
  }
}
