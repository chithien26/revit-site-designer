﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SiteComponentReport
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class SiteComponentReport : EPForm
{
  private Units m_Units;
  private Application m_CurApplication;
  private Document m_CurrentDocument;
  private List<FamilyRegionContainer> m_FamilyRegionList;
  private FormatOptions m_LengthFormatOptions;
  private FormatOptions m_AreaFormatOptions;
  private FormatOptions m_VolumeFormatOptions;
  private UnitSymbolType m_LengthUnitSymbolType;
  private UnitSymbolType m_AreaUnitSymbolType;
  private UnitSymbolType m_VolumeUnitSymbolType;
  private bool m_bExportToFile;
  private List<ExportReportLine> m_ReportLineList;
  private string m_strSettingsPrefix;
  private List<FamilyInstanceComponentWrapper> m_AllSiteComponentList;
  private List<FamilyInstanceComponentWrapper> m_SideWalkComponentList;
  private List<FamilyInstanceComponentWrapper> m_StreetComponentList;
  private List<FamilyInstanceComponentWrapper> m_CurbComponentList;
  private List<FamilyInstanceComponentWrapper> m_RetainingWallComponentList;
  private List<FamilyInstanceComponentWrapper> m_ParkingLotComponentList;
  private TopographySurfaceContainer m_ProposedSurface;
  private DecimalSymbol m_DecimalSymbolType;
  private IContainer components;
  private GroupBox m_SiteReportGroupBox;
  private Button m_CloseButton;
  private Button m_ExportButton;
  private TreeView m_ReportTreeView;
  private ListView m_ReportListView;
  private GroupBox m_ExportOptionsGroupBox;
  private RadioButton m_TabExportRadioButton;
  private RadioButton m_CommaExportRadioButton;
  private TextBox m_ExportFileTextBox;
  private Button m_ExportFileButton;
  private Label m_ExportFileLabel;

  public SiteComponentReport(Document _CurDocument, ref bool _bDlgStatus)
  {
    _bDlgStatus = true;
    this.InitializeComponent();
    this.EPToolTip.SetToolTip((Control) this.m_ExportFileButton, EPShared.LocalRM.GetString("LoadFileToolTip"));
    this.ContextualHelpID = "HID_SDreports";
    this.m_CurApplication = _CurDocument.Application;
    this.m_CurrentDocument = _CurDocument;
    this.m_LengthFormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_AreaFormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 1);
    this.m_VolumeFormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 2);
    this.m_Units = this.m_CurrentDocument.GetUnits();
    try
    {
      this.m_LengthUnitSymbolType = this.m_LengthFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_LengthUnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_AreaUnitSymbolType = this.m_AreaFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_AreaUnitSymbolType = (UnitSymbolType) 0;
    }
    try
    {
      this.m_VolumeUnitSymbolType = this.m_VolumeFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_VolumeUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_CurrentDocument.GetUnits().DecimalSymbol;
    this.m_FamilyRegionList = new List<FamilyRegionContainer>();
    this.m_AllSiteComponentList = new List<FamilyInstanceComponentWrapper>();
    this.Text = EPShared.LocalRM.GetString("SitesReportDialog");
    this.m_SiteReportGroupBox.Text = this.Text;
    this.m_ExportOptionsGroupBox.Text = EPShared.LocalRM.GetString("ExportOptionsDialog");
    this.m_CommaExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
    this.m_TabExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
    this.m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_ExportButton.Text = EPShared.LocalRM.GetString("AMP_ExportDialog");
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
    this.m_strSettingsPrefix = this.Text.Replace(" ", "");
    this.InitializeControls();
    this.m_ReportListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"), this.m_ReportListView.Size.Width / 2 - 2, HorizontalAlignment.Left);
    this.m_ReportListView.Columns.Add(EPShared.LocalRM.GetString("Value"), this.m_ReportListView.Size.Width / 2 - 2, HorizontalAlignment.Left);
    this.m_ProposedSurface = (TopographySurfaceContainer) null;
    FamilyInstance _TopoPlacementFamilyInstance = (FamilyInstance) null;
    TopographySurfaceManagement.FindBaseLandcaddTopographySurface(this.m_CurrentDocument, true, ref this.m_ProposedSurface, ref _TopoPlacementFamilyInstance);
    this.PopulateReportTree();
    if (this.m_AllSiteComponentList.Count > 0)
      return;
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoSiteComponentsInProjectMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    _bDlgStatus = false;
  }

  private void PopulateReportTree()
  {
    this.m_AllSiteComponentList = RevitUtility.FindAllSiteComponents(this.m_CurrentDocument);
    IList<Element> elements1 = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260).ToElements();
    IList<Element> elements2 = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2003400).ToElements();
    IList<Element> elements3 = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (DirectShape)).ToElements();
    IList<Element> elements4 = new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements();
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    string empty3 = string.Empty;
    string empty4 = string.Empty;
    string empty5 = string.Empty;
    string empty6 = string.Empty;
    string empty7 = string.Empty;
    bool flag = false;
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      FamilyInstance existingFamilyInstance = this.m_AllSiteComponentList[index].GetFirstExistingFamilyInstance();
      if (existingFamilyInstance != null)
      {
        string strA1 = string.Empty;
        string strA2 = string.Empty;
        string strA3 = string.Empty;
        string strB = string.Empty;
        string strA4 = string.Empty;
        string strA5 = string.Empty;
        string strA6 = string.Empty;
        Parameter parameter1 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
        if (parameter1 != null)
          strA1 = parameter1.AsString();
        Parameter parameter2 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.FamilySymbolNameFamilyParameter);
        if (parameter2 != null)
          strA2 = parameter2.AsString();
        Parameter parameter3 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.FamilyNameFamilyParameter);
        if (parameter3 != null)
          strA3 = parameter3.AsString();
        Parameter parameter4 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.LocateTypeGenericFamilyParameter);
        if (parameter4 != null)
          strB = parameter4.AsString();
        if (strB != string.Empty)
        {
          foreach (Element element in (IEnumerable<Element>) elements1)
          {
            if (element is FamilySymbol familySymbol && familySymbol.Family != null)
            {
              Parameter parameter5 = ((Element) familySymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
              if (parameter5 != null && string.Compare(parameter5.AsString(), strB, true) == 0)
              {
                if (string.Compare(strA1, ((Element) familySymbol).UniqueId, true) == 0)
                {
                  flag = true;
                  this.m_AllSiteComponentList[index].ProposedFamilySymbol = familySymbol;
                  break;
                }
                if (string.Compare(strA2, ((Element) familySymbol).Name, true) == 0 && string.Compare(strA3, ((Element) familySymbol.Family).Name, true) == 0)
                  this.m_AllSiteComponentList[index].ProposedFamilySymbol = familySymbol;
              }
            }
          }
        }
        if (parameter1 != null && !flag && this.m_AllSiteComponentList[index].ProposedFamilySymbol != null)
          parameter1.Set(((Element) this.m_AllSiteComponentList[index].ProposedFamilySymbol).UniqueId);
        Parameter parameter6 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.PrimaryFormIDFamilyParameter);
        if (parameter6 != null)
          strA4 = parameter6.AsString();
        if (strA4 != string.Empty)
        {
          foreach (Element element in (IEnumerable<Element>) elements2)
          {
            if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && string.Compare(strA4, ((Element) familyInstance).UniqueId, true) == 0)
            {
              this.m_AllSiteComponentList[index].PrimarySiteComponentMass = familyInstance;
              break;
            }
          }
          foreach (Element element in (IEnumerable<Element>) elements3)
          {
            if (element is DirectShape directShape && string.Compare(strA4, ((Element) directShape).UniqueId, true) == 0)
            {
              this.m_AllSiteComponentList[index].PrimarySiteComponentDirectShape = directShape;
              break;
            }
          }
        }
        Parameter parameter7 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.AdditionalFormIDFamilyParameter);
        if (parameter7 != null)
          strA5 = parameter7.AsString();
        if (strA5 != string.Empty)
        {
          foreach (Element element in (IEnumerable<Element>) elements2)
          {
            if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && string.Compare(strA5, ((Element) familyInstance).UniqueId, true) == 0)
            {
              this.m_AllSiteComponentList[index].AdditionalSiteComponentMass = familyInstance;
              break;
            }
          }
          foreach (Element element in (IEnumerable<Element>) elements3)
          {
            if (element is DirectShape directShape && string.Compare(strA5, ((Element) directShape).UniqueId, true) == 0)
            {
              this.m_AllSiteComponentList[index].AdditionalSiteComponentDirectShape = directShape;
              break;
            }
          }
        }
        Parameter parameter8 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.ParkingLotSurfaceIDFamilyParameter);
        if (parameter8 != null)
          strA6 = parameter8.AsString();
        if (strA6 != string.Empty)
        {
          foreach (Element element in (IEnumerable<Element>) elements4)
          {
            if (element is TopographySurface _TopographySurface && string.Compare(strA6, ((Element) _TopographySurface).UniqueId, true) == 0)
            {
              this.m_AllSiteComponentList[index].ParkingLotTopographySurface = new TopographySurfaceContainer(this.m_CurApplication, _TopographySurface, true);
              break;
            }
          }
        }
      }
    }
    this.m_RetainingWallComponentList = new List<FamilyInstanceComponentWrapper>();
    int int32;
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      if (this.m_AllSiteComponentList[index].ProposedFamilySymbol != null)
      {
        Parameter parameter = ((Element) this.m_AllSiteComponentList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (parameter != null)
        {
          string strA = parameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.RetainingWall);
          string strB = int32.ToString("000");
          if (string.Compare(strA, strB, true) == 0)
            this.m_RetainingWallComponentList.Add(this.m_AllSiteComponentList[index]);
        }
      }
    }
    if (this.m_RetainingWallComponentList.Count > 0)
    {
      TreeNode node1 = new TreeNode();
      node1.Text = EPShared.LocalRM.GetString("RetainingWallString");
      for (int index = 0; index < this.m_RetainingWallComponentList.Count; ++index)
      {
        TreeNode node2 = new TreeNode();
        if (this.m_RetainingWallComponentList[index].ProposedFamilySymbol != null)
        {
          FamilyInstance existingFamilyInstance = this.m_RetainingWallComponentList[index].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance != null)
          {
            Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
            if (parameter != null)
            {
              node2.Text = parameter.AsString();
              node1.Nodes.Add(node2);
            }
          }
        }
      }
      this.m_ReportTreeView.Nodes.Add(node1);
    }
    this.m_StreetComponentList = new List<FamilyInstanceComponentWrapper>();
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      if (this.m_AllSiteComponentList[index].ProposedFamilySymbol != null)
      {
        Parameter parameter = ((Element) this.m_AllSiteComponentList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (parameter != null)
        {
          string strA = parameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.Street);
          string strB = int32.ToString("000");
          if (string.Compare(strA, strB, true) == 0)
            this.m_StreetComponentList.Add(this.m_AllSiteComponentList[index]);
        }
      }
    }
    if (this.m_StreetComponentList.Count > 0)
    {
      TreeNode node3 = new TreeNode();
      node3.Text = EPShared.LocalRM.GetString("StreetString");
      this.m_ReportTreeView.Nodes.Add(node3);
      for (int index = 0; index < this.m_StreetComponentList.Count; ++index)
      {
        TreeNode node4 = new TreeNode();
        if (this.m_StreetComponentList[index].ProposedFamilySymbol != null)
        {
          FamilyInstance existingFamilyInstance = this.m_StreetComponentList[index].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance != null)
          {
            Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
            if (parameter != null)
            {
              node4.Text = parameter.AsString();
              node3.Nodes.Add(node4);
            }
          }
        }
      }
    }
    this.m_CurbComponentList = new List<FamilyInstanceComponentWrapper>();
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      if (this.m_AllSiteComponentList[index].ProposedFamilySymbol != null)
      {
        Parameter parameter = ((Element) this.m_AllSiteComponentList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (parameter != null)
        {
          string strA = parameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.Curb);
          string strB = int32.ToString("000");
          if (string.Compare(strA, strB, true) == 0)
            this.m_CurbComponentList.Add(this.m_AllSiteComponentList[index]);
        }
      }
    }
    if (this.m_CurbComponentList.Count > 0)
    {
      TreeNode node5 = new TreeNode();
      node5.Text = EPShared.LocalRM.GetString("CurbString");
      this.m_ReportTreeView.Nodes.Add(node5);
      for (int index = 0; index < this.m_CurbComponentList.Count; ++index)
      {
        TreeNode node6 = new TreeNode();
        if (this.m_CurbComponentList[index].ProposedFamilySymbol != null)
        {
          FamilyInstance existingFamilyInstance = this.m_CurbComponentList[index].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance != null)
          {
            Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
            if (parameter != null)
            {
              node6.Text = parameter.AsString();
              node5.Nodes.Add(node6);
            }
          }
        }
      }
    }
    this.m_SideWalkComponentList = new List<FamilyInstanceComponentWrapper>();
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      if (this.m_AllSiteComponentList[index].ProposedFamilySymbol != null)
      {
        Parameter parameter = ((Element) this.m_AllSiteComponentList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (parameter != null)
        {
          string strA = parameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.Sidewalk);
          string strB = int32.ToString("000");
          if (string.Compare(strA, strB, true) == 0)
            this.m_SideWalkComponentList.Add(this.m_AllSiteComponentList[index]);
        }
      }
    }
    if (this.m_SideWalkComponentList.Count > 0)
    {
      TreeNode node7 = new TreeNode();
      node7.Text = EPShared.LocalRM.GetString("SidewalkString");
      this.m_ReportTreeView.Nodes.Add(node7);
      for (int index = 0; index < this.m_SideWalkComponentList.Count; ++index)
      {
        TreeNode node8 = new TreeNode();
        if (this.m_SideWalkComponentList[index].ProposedFamilySymbol != null)
        {
          FamilyInstance existingFamilyInstance = this.m_SideWalkComponentList[index].GetFirstExistingFamilyInstance();
          if (existingFamilyInstance != null)
          {
            Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
            if (parameter != null)
            {
              node8.Text = parameter.AsString();
              node7.Nodes.Add(node8);
            }
          }
        }
      }
    }
    this.m_ParkingLotComponentList = new List<FamilyInstanceComponentWrapper>();
    for (int index = 0; index < this.m_AllSiteComponentList.Count; ++index)
    {
      if (this.m_AllSiteComponentList[index].ProposedFamilySymbol != null)
      {
        Parameter parameter = ((Element) this.m_AllSiteComponentList[index].ProposedFamilySymbol).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (parameter != null)
        {
          string strA = parameter.AsString();
          int32 = Convert.ToInt32((object) LandcaddID.ParkingLot);
          string strB = int32.ToString("000");
          if (string.Compare(strA, strB, true) == 0)
            this.m_ParkingLotComponentList.Add(this.m_AllSiteComponentList[index]);
        }
      }
    }
    if (this.m_ParkingLotComponentList.Count <= 0)
      return;
    TreeNode node9 = new TreeNode();
    node9.Text = EPShared.LocalRM.GetString("ParkingLotString");
    this.m_ReportTreeView.Nodes.Add(node9);
    for (int index = 0; index < this.m_ParkingLotComponentList.Count; ++index)
    {
      TreeNode node10 = new TreeNode();
      if (this.m_ParkingLotComponentList[index].ProposedFamilySymbol != null)
      {
        FamilyInstance existingFamilyInstance = this.m_ParkingLotComponentList[index].GetFirstExistingFamilyInstance();
        if (existingFamilyInstance != null)
        {
          Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
          if (parameter != null)
          {
            node10.Text = parameter.AsString();
            node9.Nodes.Add(node10);
          }
        }
      }
    }
  }

  private void OnExportButtonClicked(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    string empty1 = string.Empty;
    if (this.m_ReportLineList == null)
      this.m_ReportLineList = new List<ExportReportLine>();
    this.m_bExportToFile = true;
    string empty2 = string.Empty;
    string _strSeperator = !this.m_CommaExportRadioButton.Checked ? "\t" : ",";
    this.PopulateReportLineList();
    if (this.m_ReportLineList.Count > 0)
      ImportExport.ExportToFile(_strSeperator, this.m_ExportFileTextBox.Text, this.m_ReportLineList);
    this.m_ReportLineList.Clear();
    this.m_bExportToFile = false;
  }

  private void PopulateReportLineList()
  {
    string str = string.Empty;
    int num = 0;
    if (this.m_CurbComponentList.Count > 0)
    {
      this.PopulateTotalAreaInList(this.m_CurbComponentList, (string) null, LandcaddID.Curb);
      this.AddBlankLine();
      num = -1;
      foreach (FamilyInstanceComponentWrapper curbComponent in this.m_CurbComponentList)
      {
        FamilyInstance existingFamilyInstance = curbComponent.GetFirstExistingFamilyInstance();
        if (existingFamilyInstance != null)
        {
          Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
          if (parameter != null)
            str = parameter.AsString();
        }
        int rootIndex = this.FindRootIndex(this.m_CurbComponentList, str);
        if (rootIndex != -1)
        {
          this.PopulateTotalAreaInList(this.m_CurbComponentList[rootIndex], str, LandcaddID.Curb);
          this.AddBlankLine();
        }
      }
      this.AddBlankLine();
    }
    if (this.m_ParkingLotComponentList.Count > 0)
    {
      this.PopulateTotalAreaInList(this.m_ParkingLotComponentList, (string) null, LandcaddID.ParkingLot);
      this.AddBlankLine();
      num = -1;
      foreach (FamilyInstanceComponentWrapper parkingLotComponent in this.m_ParkingLotComponentList)
      {
        FamilyInstance existingFamilyInstance = parkingLotComponent.GetFirstExistingFamilyInstance();
        if (existingFamilyInstance != null)
        {
          Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
          if (parameter != null)
            str = parameter.AsString();
        }
        int rootIndex = this.FindRootIndex(this.m_ParkingLotComponentList, str);
        if (rootIndex != -1)
        {
          this.PopulateTotalAreaInList(this.m_ParkingLotComponentList[rootIndex], str, LandcaddID.ParkingLot);
          this.AddBlankLine();
        }
      }
      this.AddBlankLine();
    }
    if (this.m_RetainingWallComponentList.Count > 0)
    {
      this.PopulateTotalAreaInList(this.m_RetainingWallComponentList, (string) null, LandcaddID.RetainingWall);
      this.AddBlankLine();
      num = -1;
      foreach (FamilyInstanceComponentWrapper retainingWallComponent in this.m_RetainingWallComponentList)
      {
        FamilyInstance existingFamilyInstance = retainingWallComponent.GetFirstExistingFamilyInstance();
        if (existingFamilyInstance != null)
        {
          Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
          if (parameter != null)
            str = parameter.AsString();
        }
        int rootIndex = this.FindRootIndex(this.m_RetainingWallComponentList, str);
        if (rootIndex != -1)
        {
          this.PopulateTotalAreaInList(this.m_RetainingWallComponentList[rootIndex], str, LandcaddID.RetainingWall);
          this.AddBlankLine();
        }
      }
      this.AddBlankLine();
    }
    if (this.m_SideWalkComponentList.Count > 0)
    {
      this.PopulateTotalAreaInList(this.m_SideWalkComponentList, (string) null, LandcaddID.Sidewalk);
      this.AddBlankLine();
      num = -1;
      foreach (FamilyInstanceComponentWrapper sideWalkComponent in this.m_SideWalkComponentList)
      {
        FamilyInstance existingFamilyInstance = sideWalkComponent.GetFirstExistingFamilyInstance();
        if (existingFamilyInstance != null)
        {
          Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
          if (parameter != null)
            str = parameter.AsString();
        }
        int rootIndex = this.FindRootIndex(this.m_SideWalkComponentList, str);
        if (rootIndex != -1)
        {
          this.PopulateTotalAreaInList(this.m_SideWalkComponentList[rootIndex], str, LandcaddID.Sidewalk);
          this.AddBlankLine();
        }
      }
      this.AddBlankLine();
    }
    if (this.m_StreetComponentList.Count <= 0)
      return;
    this.PopulateTotalAreaInList(this.m_StreetComponentList, (string) null, LandcaddID.Street);
    this.AddBlankLine();
    num = -1;
    foreach (FamilyInstanceComponentWrapper streetComponent in this.m_StreetComponentList)
    {
      FamilyInstance existingFamilyInstance = streetComponent.GetFirstExistingFamilyInstance();
      if (existingFamilyInstance != null)
      {
        Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
        if (parameter != null)
          str = parameter.AsString();
      }
      int rootIndex = this.FindRootIndex(this.m_StreetComponentList, str);
      if (rootIndex != -1)
      {
        this.PopulateTotalAreaInList(this.m_StreetComponentList[rootIndex], str, LandcaddID.Street);
        this.AddBlankLine();
      }
    }
    this.AddBlankLine();
  }

  private void OnCloseButtonClicked(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
  }

  private int FindRootIndex(
    List<FamilyInstanceComponentWrapper> _ComponentList,
    string _strFamilyName)
  {
    string empty = string.Empty;
    for (int index = 0; index < _ComponentList.Count; ++index)
    {
      FamilyInstance existingFamilyInstance = _ComponentList[index].GetFirstExistingFamilyInstance();
      if (existingFamilyInstance != null)
      {
        Parameter parameter = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
        if (parameter != null && string.Compare(parameter.AsString(), _strFamilyName, true) == 0)
          return index;
      }
    }
    return -1;
  }

  private void ReportTreeViewAfterSelect(object sender, TreeViewEventArgs e)
  {
    this.m_ReportListView.Items.Clear();
    LandcaddID _Id = LandcaddID.Steps;
    List<FamilyInstanceComponentWrapper> componentWrapperList = (List<FamilyInstanceComponentWrapper>) null;
    string strB = string.Empty;
    string str = string.Empty;
    if (this.m_ReportTreeView.SelectedNode.Parent == null)
    {
      strB = this.m_ReportTreeView.SelectedNode.Text;
      str = (string) null;
    }
    else if (this.m_ReportTreeView.SelectedNode.Parent.Parent == null)
    {
      strB = this.m_ReportTreeView.SelectedNode.Parent.Text;
      str = this.m_ReportTreeView.SelectedNode.Text;
    }
    if (string.Compare(EPShared.LocalRM.GetString("StreetString"), strB, true) == 0)
    {
      _Id = LandcaddID.Street;
      componentWrapperList = this.m_StreetComponentList;
    }
    else if (string.Compare(EPShared.LocalRM.GetString("CurbString"), strB, true) == 0)
    {
      _Id = LandcaddID.Curb;
      componentWrapperList = this.m_CurbComponentList;
    }
    else if (string.Compare(EPShared.LocalRM.GetString("SidewalkString"), strB, true) == 0)
    {
      _Id = LandcaddID.Sidewalk;
      componentWrapperList = this.m_SideWalkComponentList;
    }
    else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallString"), strB, true) == 0)
    {
      _Id = LandcaddID.RetainingWall;
      componentWrapperList = this.m_RetainingWallComponentList;
    }
    else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotString"), strB, true) == 0)
    {
      _Id = LandcaddID.ParkingLot;
      componentWrapperList = this.m_ParkingLotComponentList;
    }
    if (this.m_ReportTreeView.SelectedNode.Parent == null)
    {
      this.PopulateTotalAreaInList(componentWrapperList, str, _Id);
    }
    else
    {
      if (this.m_ReportTreeView.SelectedNode.Parent.Parent != null)
        return;
      int rootIndex = this.FindRootIndex(componentWrapperList, str);
      if (rootIndex == -1)
        return;
      this.PopulateTotalAreaInList(componentWrapperList[rootIndex], str, _Id);
    }
  }

  private void PopulateTotalAreaInList(
    FamilyInstanceComponentWrapper _FamilyInstanceWrapperList,
    LandcaddID _Id)
  {
    this.PopulateTotalAreaInList(new List<FamilyInstanceComponentWrapper>()
    {
      _FamilyInstanceWrapperList
    }, string.Empty, _Id);
  }

  private void PopulateTotalAreaInList(
    List<FamilyInstanceComponentWrapper> _FamilyInstanceWrapperList,
    LandcaddID _Id)
  {
    this.PopulateTotalAreaInList(_FamilyInstanceWrapperList, string.Empty, _Id);
  }

  private void PopulateTotalAreaInList(
    FamilyInstanceComponentWrapper _FamilyInstanceWrapperList,
    string _strTitle,
    LandcaddID _Id)
  {
    this.PopulateTotalAreaInList(new List<FamilyInstanceComponentWrapper>()
    {
      _FamilyInstanceWrapperList
    }, _strTitle, _Id);
  }

  private void PopulateTotalAreaInList(
    List<FamilyInstanceComponentWrapper> _FamilyInstanceWrapperList,
    string _strTitle,
    LandcaddID _Id)
  {
    double num1 = 0.0;
    double num2 = 0.0;
    double num3 = 0.0;
    double num4 = 0.0;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    double _dBase = 0.0;
    double _dSubBase = 0.0;
    double num5 = 0.0;
    double num6 = 0.0;
    double num7 = 0.0;
    double num8 = 0.0;
    double _dParkinglotDepth = 0.0;
    double _dRightOffsetWidth = 0.0;
    double _dLeftOffsetWidth = 0.0;
    double _dAdditionalCurbWidth = 0.0;
    double LegListArea1 = 0.0;
    double LegListArea2 = 0.0;
    double LegListArea3 = 0.0;
    bool flag = false;
    string strA = string.Empty;
    if (_strTitle != null)
    {
      for (int index = 0; index < _FamilyInstanceWrapperList.Count; ++index)
      {
        FamilyInstance existingFamilyInstance = _FamilyInstanceWrapperList[index].GetFirstExistingFamilyInstance();
        if (_FamilyInstanceWrapperList[index].ProposedFamilySymbol != null && existingFamilyInstance != null)
        {
          this.GetBaseSubBaseParameter(_FamilyInstanceWrapperList[index].ProposedFamilySymbol, _Id, ref _dBase, ref _dSubBase, ref _dParkinglotDepth);
          Parameter parameter1 = ((Element) existingFamilyInstance).LookupParameter(RevitParameters.SiteComponentNameFamilyParameter);
          if (parameter1 != null)
            strA = parameter1.AsString();
          if (string.Compare(strA, _strTitle, true) == 0)
          {
            Eps_Leg BoundaryLegList1 = (Eps_Leg) null;
            Eps_Leg BoundaryLegList2 = (Eps_Leg) null;
            Eps_Leg BoundaryLegList3 = (Eps_Leg) null;
            _FamilyInstanceWrapperList[index].CreateOriginalLeg(this.m_ProposedSurface);
            if (_FamilyInstanceWrapperList[index].OriginalLeg != null && _FamilyInstanceWrapperList[index].OriginalLeg.LegCount > 0)
            {
              this.GetWidthParameters(_FamilyInstanceWrapperList[index].ProposedFamilySymbol, _Id, ref _dLeftOffsetWidth, ref _dRightOffsetWidth, ref _dAdditionalCurbWidth);
              if (!RevitDefines.EQ(_dRightOffsetWidth + _dLeftOffsetWidth, 0.0))
              {
                Eps_Leg ppOffsetLegList1 = new Eps_Leg();
                RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dRightOffsetWidth, 1, ref ppOffsetLegList1, true);
                Eps_Leg ppOffsetLegList2 = new Eps_Leg();
                RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dLeftOffsetWidth, 2, ref ppOffsetLegList2, true);
                BoundaryLegList1 = Eps_Leg.CopyLeg(ppOffsetLegList1.Reverse());
                Eps_Leg _CompleteLeg1 = new Eps_Leg();
                _CompleteLeg1.Line = new Eps_Line();
                _CompleteLeg1.Line.StartPnt = ppOffsetLegList1.LegStartPnt;
                _CompleteLeg1.Line.EndPnt = ppOffsetLegList2.LegStartPnt;
                BoundaryLegList1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg1);
                BoundaryLegList1.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList2);
                Eps_Leg _CompleteLeg2 = new Eps_Leg();
                _CompleteLeg2.Line = new Eps_Line();
                _CompleteLeg2.Line.StartPnt = ppOffsetLegList2.LegEndPnt;
                _CompleteLeg2.Line.EndPnt = ppOffsetLegList1.LegEndPnt;
                BoundaryLegList1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg2);
              }
              if (_FamilyInstanceWrapperList[index].PrimarySiteComponentMass != null && BoundaryLegList1 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList1, ref LegListArea1) == 0)
              {
                num1 += LegListArea1;
                num2 += LegListArea1 * _dBase;
                num3 += LegListArea1 * _dSubBase;
                Parameter parameter2 = ((Element) _FamilyInstanceWrapperList[index].PrimarySiteComponentMass)[(BuiltInParameter) -1012007];
                if (parameter2 != null)
                  num4 += parameter2.AsDouble();
              }
              if (_FamilyInstanceWrapperList[index].PrimarySiteComponentDirectShape != null && BoundaryLegList1 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList1, ref LegListArea1) == 0)
              {
                num1 += LegListArea1;
                num2 += LegListArea1 * _dBase;
                num3 += LegListArea1 * _dSubBase;
                num4 += RevitGeometry.GetDirectShapeVolume(_FamilyInstanceWrapperList[index].PrimarySiteComponentDirectShape);
              }
              if (!RevitDefines.EQ(_dRightOffsetWidth + _dLeftOffsetWidth, 0.0) && RevitDefines.GT(_dAdditionalCurbWidth, 0.0))
              {
                Eps_Leg ppOffsetLegList3 = new Eps_Leg();
                RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dRightOffsetWidth, 1, ref ppOffsetLegList3, true);
                Eps_Leg ppOffsetLegList4 = new Eps_Leg();
                RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dRightOffsetWidth + _dAdditionalCurbWidth, 1, ref ppOffsetLegList4, true);
                Eps_Leg ppOffsetLegList5 = new Eps_Leg();
                RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dLeftOffsetWidth, 2, ref ppOffsetLegList5, true);
                Eps_Leg ppOffsetLegList6 = new Eps_Leg();
                RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dLeftOffsetWidth + _dAdditionalCurbWidth, 2, ref ppOffsetLegList6, true);
                BoundaryLegList2 = Eps_Leg.CopyLeg(ppOffsetLegList3.Reverse());
                Eps_Leg _CompleteLeg3 = new Eps_Leg();
                _CompleteLeg3.Line = new Eps_Line();
                _CompleteLeg3.Line.StartPnt = ppOffsetLegList3.LegStartPnt;
                _CompleteLeg3.Line.EndPnt = ppOffsetLegList4.LegStartPnt;
                BoundaryLegList2.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg3);
                BoundaryLegList2.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList4);
                Eps_Leg _CompleteLeg4 = new Eps_Leg();
                _CompleteLeg4.Line = new Eps_Line();
                _CompleteLeg4.Line.StartPnt = ppOffsetLegList4.LegEndPnt;
                _CompleteLeg4.Line.EndPnt = ppOffsetLegList3.LegEndPnt;
                BoundaryLegList1.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg4);
                BoundaryLegList3 = Eps_Leg.CopyLeg(ppOffsetLegList5.Reverse());
                Eps_Leg _CompleteLeg5 = new Eps_Leg();
                _CompleteLeg5.Line = new Eps_Line();
                _CompleteLeg5.Line.StartPnt = ppOffsetLegList5.LegStartPnt;
                _CompleteLeg5.Line.EndPnt = ppOffsetLegList6.LegStartPnt;
                BoundaryLegList3.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg5);
                BoundaryLegList3.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList6);
                Eps_Leg _CompleteLeg6 = new Eps_Leg();
                _CompleteLeg6.Line = new Eps_Line();
                _CompleteLeg6.Line.StartPnt = ppOffsetLegList6.LegEndPnt;
                _CompleteLeg6.Line.EndPnt = ppOffsetLegList5.LegEndPnt;
                BoundaryLegList3.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg6);
              }
              if (_FamilyInstanceWrapperList[index].AdditionalSiteComponentMass != null && BoundaryLegList2 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList2, ref LegListArea3) == 0 && BoundaryLegList3 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList3, ref LegListArea2) == 0)
              {
                flag = true;
                if (_Id != LandcaddID.Street)
                {
                  num1 += LegListArea3 + LegListArea2;
                  num2 += (LegListArea3 + LegListArea2) * _dBase;
                  num3 += (LegListArea3 + LegListArea2) * _dSubBase;
                  Parameter parameter3 = ((Element) _FamilyInstanceWrapperList[index].AdditionalSiteComponentMass)[(BuiltInParameter) -1012007];
                  if (parameter3 != null)
                    num4 += parameter3.AsDouble();
                }
                else
                {
                  num5 += LegListArea3 + LegListArea2;
                  num7 += (LegListArea3 + LegListArea2) * _dBase;
                  num8 += (LegListArea3 + LegListArea2) * _dSubBase;
                  Parameter parameter4 = ((Element) _FamilyInstanceWrapperList[index].AdditionalSiteComponentMass)[(BuiltInParameter) -1012007];
                  if (parameter4 != null)
                    num6 += parameter4.AsDouble();
                }
              }
              if (_FamilyInstanceWrapperList[index].AdditionalSiteComponentDirectShape != null && BoundaryLegList2 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList2, ref LegListArea3) == 0 && BoundaryLegList3 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList3, ref LegListArea2) == 0)
              {
                flag = true;
                if (_Id != LandcaddID.Street)
                {
                  num1 += LegListArea3 + LegListArea2;
                  num2 += (LegListArea3 + LegListArea2) * _dBase;
                  num3 += (LegListArea3 + LegListArea2) * _dSubBase;
                  num4 += RevitGeometry.GetDirectShapeVolume(_FamilyInstanceWrapperList[index].AdditionalSiteComponentDirectShape);
                }
                else
                {
                  num5 += LegListArea3 + LegListArea2;
                  num7 += (LegListArea3 + LegListArea2) * _dBase;
                  num8 += (LegListArea3 + LegListArea2) * _dSubBase;
                  num6 += RevitGeometry.GetDirectShapeVolume(_FamilyInstanceWrapperList[index].AdditionalSiteComponentDirectShape);
                }
              }
            }
            if (_FamilyInstanceWrapperList[index].ParkingLotTopographySurface != null)
            {
              Parameter parameter5 = ((Element) _FamilyInstanceWrapperList[index].ParkingLotTopographySurface.TopographySurface)[(BuiltInParameter) -1012601];
              if (parameter5 != null)
              {
                num1 += parameter5.AsDouble();
                num2 += parameter5.AsDouble() * _dBase;
                num3 += parameter5.AsDouble() * _dSubBase;
                num4 += parameter5.AsDouble() * _dParkinglotDepth;
                break;
              }
              break;
            }
            break;
          }
        }
      }
    }
    else
    {
      for (int index = 0; index < _FamilyInstanceWrapperList.Count; ++index)
      {
        if (_FamilyInstanceWrapperList[index].ProposedFamilySymbol != null)
        {
          this.GetBaseSubBaseParameter(_FamilyInstanceWrapperList[index].ProposedFamilySymbol, _Id, ref _dBase, ref _dSubBase, ref _dParkinglotDepth);
          Eps_Leg BoundaryLegList4 = (Eps_Leg) null;
          Eps_Leg BoundaryLegList5 = (Eps_Leg) null;
          Eps_Leg BoundaryLegList6 = (Eps_Leg) null;
          _FamilyInstanceWrapperList[index].CreateOriginalLeg(this.m_ProposedSurface);
          if (_FamilyInstanceWrapperList[index].OriginalLeg != null && _FamilyInstanceWrapperList[index].OriginalLeg.LegCount > 0)
          {
            this.GetWidthParameters(_FamilyInstanceWrapperList[index].ProposedFamilySymbol, _Id, ref _dLeftOffsetWidth, ref _dRightOffsetWidth, ref _dAdditionalCurbWidth);
            if (!RevitDefines.EQ(_dRightOffsetWidth + _dLeftOffsetWidth, 0.0))
            {
              Eps_Leg ppOffsetLegList7 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dRightOffsetWidth, 1, ref ppOffsetLegList7, true);
              Eps_Leg ppOffsetLegList8 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dLeftOffsetWidth, 2, ref ppOffsetLegList8, true);
              BoundaryLegList4 = Eps_Leg.CopyLeg(ppOffsetLegList7.Reverse());
              Eps_Leg _CompleteLeg7 = new Eps_Leg();
              _CompleteLeg7.Line = new Eps_Line();
              _CompleteLeg7.Line.StartPnt = ppOffsetLegList7.LegStartPnt;
              _CompleteLeg7.Line.EndPnt = ppOffsetLegList8.LegStartPnt;
              BoundaryLegList4.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg7);
              BoundaryLegList4.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList8);
              Eps_Leg _CompleteLeg8 = new Eps_Leg();
              _CompleteLeg8.Line = new Eps_Line();
              _CompleteLeg8.Line.StartPnt = ppOffsetLegList8.LegEndPnt;
              _CompleteLeg8.Line.EndPnt = ppOffsetLegList7.LegEndPnt;
              BoundaryLegList4.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg8);
            }
            if (_FamilyInstanceWrapperList[index].PrimarySiteComponentMass != null && BoundaryLegList4 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList4, ref LegListArea1) == 0)
            {
              num1 += LegListArea1;
              num2 += LegListArea1 * _dBase;
              num3 += LegListArea1 * _dSubBase;
              Parameter parameter = ((Element) _FamilyInstanceWrapperList[index].PrimarySiteComponentMass)[(BuiltInParameter) -1012007];
              if (parameter != null)
                num4 += parameter.AsDouble();
            }
            if (_FamilyInstanceWrapperList[index].PrimarySiteComponentDirectShape != null && BoundaryLegList4 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList4, ref LegListArea1) == 0)
            {
              num1 += LegListArea1;
              num2 += LegListArea1 * _dBase;
              num3 += LegListArea1 * _dSubBase;
              num4 += RevitGeometry.GetDirectShapeVolume(_FamilyInstanceWrapperList[index].PrimarySiteComponentDirectShape);
            }
            if (!RevitDefines.EQ(_dRightOffsetWidth + _dLeftOffsetWidth, 0.0) && RevitDefines.GT(_dAdditionalCurbWidth, 0.0))
            {
              Eps_Leg ppOffsetLegList9 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dRightOffsetWidth, 1, ref ppOffsetLegList9, true);
              Eps_Leg ppOffsetLegList10 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dRightOffsetWidth + _dAdditionalCurbWidth, 1, ref ppOffsetLegList10, true);
              Eps_Leg ppOffsetLegList11 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dLeftOffsetWidth, 2, ref ppOffsetLegList11, true);
              Eps_Leg ppOffsetLegList12 = new Eps_Leg();
              RevitGeometry.OffsetLegList(_FamilyInstanceWrapperList[index].OriginalLeg, _dLeftOffsetWidth + _dAdditionalCurbWidth, 2, ref ppOffsetLegList12, true);
              BoundaryLegList5 = Eps_Leg.CopyLeg(ppOffsetLegList9.Reverse());
              Eps_Leg _CompleteLeg9 = new Eps_Leg();
              _CompleteLeg9.Line = new Eps_Line();
              _CompleteLeg9.Line.StartPnt = ppOffsetLegList9.LegStartPnt;
              _CompleteLeg9.Line.EndPnt = ppOffsetLegList10.LegStartPnt;
              BoundaryLegList5.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg9);
              BoundaryLegList5.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList10);
              Eps_Leg _CompleteLeg10 = new Eps_Leg();
              _CompleteLeg10.Line = new Eps_Line();
              _CompleteLeg10.Line.StartPnt = ppOffsetLegList10.LegEndPnt;
              _CompleteLeg10.Line.EndPnt = ppOffsetLegList9.LegEndPnt;
              BoundaryLegList4.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg10);
              BoundaryLegList6 = Eps_Leg.CopyLeg(ppOffsetLegList11.Reverse());
              Eps_Leg _CompleteLeg11 = new Eps_Leg();
              _CompleteLeg11.Line = new Eps_Line();
              _CompleteLeg11.Line.StartPnt = ppOffsetLegList11.LegStartPnt;
              _CompleteLeg11.Line.EndPnt = ppOffsetLegList12.LegStartPnt;
              BoundaryLegList6.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg11);
              BoundaryLegList6.Last.Next = Eps_Leg.CopyLeg(ppOffsetLegList12);
              Eps_Leg _CompleteLeg12 = new Eps_Leg();
              _CompleteLeg12.Line = new Eps_Line();
              _CompleteLeg12.Line.StartPnt = ppOffsetLegList12.LegEndPnt;
              _CompleteLeg12.Line.EndPnt = ppOffsetLegList11.LegEndPnt;
              BoundaryLegList6.Last.Next = Eps_Leg.SingleLeg(_CompleteLeg12);
            }
            if (_FamilyInstanceWrapperList[index].AdditionalSiteComponentMass != null && BoundaryLegList5 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList5, ref LegListArea3) == 0 && BoundaryLegList6 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList6, ref LegListArea2) == 0)
            {
              flag = true;
              if (_Id != LandcaddID.Street)
              {
                num1 += LegListArea3 + LegListArea2;
                num2 += (LegListArea3 + LegListArea2) * _dBase;
                num3 += (LegListArea3 + LegListArea2) * _dSubBase;
                Parameter parameter = ((Element) _FamilyInstanceWrapperList[index].AdditionalSiteComponentMass)[(BuiltInParameter) -1012007];
                if (parameter != null)
                  num4 += parameter.AsDouble();
              }
              else
              {
                num5 += LegListArea3 + LegListArea2;
                num7 += (LegListArea3 + LegListArea2) * _dBase;
                num8 += (LegListArea3 + LegListArea2) * _dSubBase;
                Parameter parameter = ((Element) _FamilyInstanceWrapperList[index].AdditionalSiteComponentMass)[(BuiltInParameter) -1012007];
                if (parameter != null)
                  num6 += parameter.AsDouble();
              }
            }
            if (_FamilyInstanceWrapperList[index].AdditionalSiteComponentDirectShape != null && BoundaryLegList5 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList5, ref LegListArea3) == 0 && BoundaryLegList6 != null && RevitGeometry.eplGeoE_CalcAreaOfLegList(BoundaryLegList6, ref LegListArea2) == 0)
            {
              flag = true;
              if (_Id != LandcaddID.Street)
              {
                num1 += LegListArea3 + LegListArea2;
                num2 += (LegListArea3 + LegListArea2) * _dBase;
                num3 += (LegListArea3 + LegListArea2) * _dSubBase;
                num4 += RevitGeometry.GetDirectShapeVolume(_FamilyInstanceWrapperList[index].AdditionalSiteComponentDirectShape);
              }
              else
              {
                num5 += LegListArea3 + LegListArea2;
                num7 += (LegListArea3 + LegListArea2) * _dBase;
                num8 += (LegListArea3 + LegListArea2) * _dSubBase;
                num6 += RevitGeometry.GetDirectShapeVolume(_FamilyInstanceWrapperList[index].AdditionalSiteComponentDirectShape);
              }
            }
          }
          if (_FamilyInstanceWrapperList[index].ParkingLotTopographySurface != null)
          {
            Parameter parameter = ((Element) _FamilyInstanceWrapperList[index].ParkingLotTopographySurface.TopographySurface)[(BuiltInParameter) -1012601];
            if (parameter != null)
            {
              num1 += parameter.AsDouble();
              num2 += parameter.AsDouble() * _dBase;
              num3 += parameter.AsDouble() * _dSubBase;
              num4 += parameter.AsDouble() * _dParkinglotDepth;
            }
          }
        }
      }
    }
    string empty3 = string.Empty;
    string _strLevel = _strTitle != null ? _strTitle : this.GetCurrentTypeString(_Id);
    string _strParameter1 = EPShared.LocalRM.GetString("MassGrossSurfaceAreaParameter");
    if (RevitDefines.GT(num1, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num1, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strLevel, _strParameter1, empty1);
    string _strParameter2 = EPShared.LocalRM.GetString("MassGrossVolumeParameter");
    if (RevitDefines.GT(num4, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num4, this.m_VolumeFormatOptions.DisplayUnits, this.m_VolumeFormatOptions.Accuracy, this.m_VolumeUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter2, empty1);
    string _strParameter3 = EPShared.LocalRM.GetString("MassBaseVolume");
    if (RevitDefines.GT(num2, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num2, this.m_VolumeFormatOptions.DisplayUnits, this.m_VolumeFormatOptions.Accuracy, this.m_VolumeUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter3, empty1);
    string _strParameter4 = EPShared.LocalRM.GetString("MassSubBaseVolume");
    if (RevitDefines.GT(num3, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num3, this.m_VolumeFormatOptions.DisplayUnits, this.m_VolumeFormatOptions.Accuracy, this.m_VolumeUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter4, empty1);
    if (_Id != LandcaddID.Street || !flag)
      return;
    this.PopulateList("", "", "");
    string _strParameter5 = $"{this.GetCurrentTypeString(LandcaddID.Curb)} {EPShared.LocalRM.GetString("MassGrossSurfaceAreaParameter")}";
    if (RevitDefines.GT(num5, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num5, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter5, empty1);
    string _strParameter6 = $"{this.GetCurrentTypeString(LandcaddID.Curb)} {EPShared.LocalRM.GetString("MassGrossVolumeParameter")}";
    if (RevitDefines.GT(num6, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num6, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter6, empty1);
    string _strParameter7 = $"{this.GetCurrentTypeString(LandcaddID.Curb)} {EPShared.LocalRM.GetString("MassBaseVolume")}";
    if (RevitDefines.GT(num7, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num7, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter7, empty1);
    string _strParameter8 = $"{this.GetCurrentTypeString(LandcaddID.Curb)} {EPShared.LocalRM.GetString("MassSubBaseVolume")}";
    if (RevitDefines.GT(num8, 0.0))
      RevitGeometry.Units_ConvertDoubleToString(num8, this.m_AreaFormatOptions.DisplayUnits, this.m_AreaFormatOptions.Accuracy, this.m_AreaUnitSymbolType, this.m_Units, ref empty1);
    else
      empty1 = EPShared.LocalRM.GetString("NotAvailableString");
    this.PopulateList(_strParameter8, empty1);
  }

  private string GetCurrentTypeString(LandcaddID _Id)
  {
    string empty = string.Empty;
    switch (_Id)
    {
      case LandcaddID.Street:
        empty = EPShared.LocalRM.GetString("StreetString");
        break;
      case LandcaddID.Curb:
        empty = EPShared.LocalRM.GetString("CurbString");
        break;
      case LandcaddID.Sidewalk:
        empty = EPShared.LocalRM.GetString("SidewalkString");
        break;
      case LandcaddID.RetainingWall:
        empty = EPShared.LocalRM.GetString("RetainingWallString");
        break;
      case LandcaddID.ParkingLot:
        empty = EPShared.LocalRM.GetString("ParkingLotString");
        break;
    }
    return empty;
  }

  private bool GetBaseSubBaseParameter(
    FamilyInstance _CurrentInstance,
    LandcaddID _CurrentID,
    ref double _dBase,
    ref double _dSubBase,
    ref double _dParkinglotDepth)
  {
    _dBase = 0.0;
    _dSubBase = 0.0;
    _dParkinglotDepth = 0.0;
    if (_CurrentInstance == null)
      return false;
    string str1 = string.Empty;
    string str2 = string.Empty;
    switch (_CurrentID)
    {
      case LandcaddID.Street:
        str1 = RevitParameters.StreetBaseSurfaceParameter;
        str2 = RevitParameters.StreetSubbaseSurfaceParameter;
        break;
      case LandcaddID.Curb:
        str1 = RevitParameters.CurbBaseSurfaceParameter;
        str2 = RevitParameters.CurbSubbaseSurfaceParameter;
        break;
      case LandcaddID.Sidewalk:
        str1 = RevitParameters.SideWalkBaseSurfaceParameter;
        str2 = RevitParameters.SideWalkSubbaseSurfaceParameter;
        break;
      case LandcaddID.RetainingWall:
        str1 = RevitParameters.RetainingWallBaseSurfaceParameter;
        str2 = RevitParameters.RetainingWallSubbaseSurfaceParameter;
        break;
      case LandcaddID.ParkingLot:
        str1 = RevitParameters.ParkingLotParkingBaseDepthParameter;
        str2 = RevitParameters.ParkingLotParkingSubBaseDepthParameter;
        Parameter parameter1 = ((Element) _CurrentInstance).LookupParameter(RevitParameters.ParkingLotPavementDepthParameter);
        if (parameter1 != null)
        {
          _dParkinglotDepth = parameter1.AsDouble();
          break;
        }
        break;
    }
    Parameter parameter2 = ((Element) _CurrentInstance).LookupParameter(str1);
    if (parameter2 != null)
      _dBase = parameter2.AsDouble();
    Parameter parameter3 = ((Element) _CurrentInstance).LookupParameter(str2);
    if (parameter3 != null)
      _dSubBase = parameter3.AsDouble();
    return true;
  }

  private bool GetBaseSubBaseParameter(
    FamilySymbol _CurrentSymbol,
    LandcaddID _CurrentID,
    ref double _dBase,
    ref double _dSubBase,
    ref double _dParkinglotDepth)
  {
    _dBase = 0.0;
    _dSubBase = 0.0;
    _dParkinglotDepth = 0.0;
    if (_CurrentSymbol == null)
      return false;
    string str1 = string.Empty;
    string str2 = string.Empty;
    switch (_CurrentID)
    {
      case LandcaddID.Street:
        str1 = RevitParameters.StreetBaseSurfaceParameter;
        str2 = RevitParameters.StreetSubbaseSurfaceParameter;
        break;
      case LandcaddID.Curb:
        str1 = RevitParameters.CurbBaseSurfaceParameter;
        str2 = RevitParameters.CurbSubbaseSurfaceParameter;
        break;
      case LandcaddID.Sidewalk:
        str1 = RevitParameters.SideWalkBaseSurfaceParameter;
        str2 = RevitParameters.SideWalkSubbaseSurfaceParameter;
        break;
      case LandcaddID.RetainingWall:
        str1 = RevitParameters.RetainingWallBaseSurfaceParameter;
        str2 = RevitParameters.RetainingWallSubbaseSurfaceParameter;
        break;
      case LandcaddID.ParkingLot:
        str1 = RevitParameters.ParkingLotParkingBaseDepthParameter;
        str2 = RevitParameters.ParkingLotParkingSubBaseDepthParameter;
        Parameter parameter1 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.ParkingLotPavementDepthParameter);
        if (parameter1 != null)
        {
          _dParkinglotDepth = parameter1.AsDouble();
          break;
        }
        break;
    }
    Parameter parameter2 = ((Element) _CurrentSymbol).LookupParameter(str1);
    if (parameter2 != null)
      _dBase = parameter2.AsDouble();
    Parameter parameter3 = ((Element) _CurrentSymbol).LookupParameter(str2);
    if (parameter3 != null)
      _dSubBase = parameter3.AsDouble();
    return true;
  }

  private bool GetWidthParameters(
    FamilySymbol _CurrentSymbol,
    LandcaddID _CurrentID,
    ref double _dLeftOffsetWidth,
    ref double _dRightOffsetWidth,
    ref double _dAdditionalCurbWidth)
  {
    _dLeftOffsetWidth = 0.0;
    _dRightOffsetWidth = 0.0;
    _dAdditionalCurbWidth = 0.0;
    if (_CurrentSymbol == null)
      return false;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    switch (_CurrentID)
    {
      case LandcaddID.SoftTerrain:
        Parameter parameter1 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.SoftTerrainLeftOffsetWidthParameter);
        if (parameter1 != null)
          _dLeftOffsetWidth = parameter1.AsDouble();
        Parameter parameter2 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.SoftTerrainRightOffsetWidthParameter);
        if (parameter2 != null)
        {
          _dRightOffsetWidth = parameter2.AsDouble();
          break;
        }
        break;
      case LandcaddID.Street:
        double num1 = 0.0;
        Parameter parameter3 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetLaneWidthParameter);
        if (parameter3 != null)
          num1 = parameter3.AsDouble();
        Parameter parameter4 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetNumberOfLanesParameter);
        if (parameter4 != null)
        {
          _dLeftOffsetWidth = num1 * (double) parameter4.AsInteger() / 2.0;
          _dRightOffsetWidth = num1 * (double) parameter4.AsInteger() / 2.0;
        }
        Parameter parameter5 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetCurbDisplayParameter);
        if (parameter5 != null && parameter5.AsInteger() != 0)
        {
          Parameter parameter6 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
          if (parameter6 != null)
          {
            double num2 = parameter6.AsDouble();
            _dAdditionalCurbWidth = num2;
            _dAdditionalCurbWidth = num2;
          }
          Parameter parameter7 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
          if (parameter7 != null)
          {
            _dAdditionalCurbWidth += parameter7.AsDouble();
            _dAdditionalCurbWidth += parameter7.AsDouble();
            break;
          }
          break;
        }
        break;
      case LandcaddID.Curb:
        double num3 = 0.0;
        double num4 = 0.0;
        Parameter parameter8 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
        if (parameter8 != null)
          num4 = parameter8.AsDouble();
        Parameter parameter9 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
        if (parameter9 != null)
          num3 = parameter9.AsDouble();
        Parameter parameter10 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.UseRightSideGenericFamilyParameter);
        if (parameter10 != null && parameter10.AsInteger() == 1)
        {
          _dRightOffsetWidth = num4 + num3;
          _dLeftOffsetWidth = 0.0;
          break;
        }
        _dLeftOffsetWidth = num4 + num3;
        _dRightOffsetWidth = 0.0;
        break;
      case LandcaddID.Sidewalk:
        Parameter parameter11 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.SideWalkWidthParameter);
        if (parameter11 != null)
        {
          double num5 = parameter11.AsDouble();
          _dLeftOffsetWidth = num5 / 2.0;
          _dRightOffsetWidth = num5 / 2.0;
          break;
        }
        break;
      case LandcaddID.RetainingWall:
        Parameter parameter12 = ((Element) _CurrentSymbol).LookupParameter(RevitParameters.RetainingWallWidthParameter);
        if (parameter12 != null)
        {
          double num6 = parameter12.AsDouble();
          _dLeftOffsetWidth = num6 / 2.0;
          _dRightOffsetWidth = num6 / 2.0;
          break;
        }
        break;
    }
    return true;
  }

  private void OnExportFileButtonClick(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    if (this.m_CommaExportRadioButton.Checked)
      saveFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
    else
      saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_ExportFileTextBox.Text = saveFileDialog.FileName;
    this.m_ExportFileTextBox.Focus();
  }

  private void AddBlankLine()
  {
    if (!this.m_bExportToFile)
      return;
    this.m_ReportLineList.Add(new ExportReportLine());
  }

  private void PopulateList(string _strParameter, string _strValue)
  {
    this.PopulateList(string.Empty, _strParameter, _strValue);
  }

  private void PopulateList(string _strLevel, string _strParameter, string _strValue)
  {
    if (!this.m_bExportToFile)
    {
      ListViewItem listViewItem = this.m_ReportListView.Items.Add(_strParameter, _strParameter, string.Empty);
      listViewItem.Tag = (object) _strParameter;
      listViewItem.SubItems.Add(_strValue);
    }
    else
      this.m_ReportLineList.Add(new ExportReportLine(_strLevel, _strParameter, _strValue));
  }

  private bool ValidateFields()
  {
    if (string.IsNullOrEmpty(this.m_ExportFileTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFolderFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ExportFileTextBox.Focus();
      return false;
    }
    string empty = string.Empty;
    string str = !this.m_CommaExportRadioButton.Checked ? ".txt" : ".csv";
    if (this.m_ExportFileTextBox.Text.IndexOf(str) < 0)
    {
      if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
      {
        int length = -1;
        if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
        else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
        if (Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
        {
          this.m_ExportFileTextBox.Text += str;
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
    {
      int length = -1;
      if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
        length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
      else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
        length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
      if (!Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    return true;
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_CommaExportRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_CommaExportRadioButton.Checked = true;
      else
        this.m_TabExportRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSettingsPrefix + "ExportFileName", ref empty))
      return;
    this.m_ExportFileTextBox.Text = empty;
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportOption", !this.m_CommaExportRadioButton.Checked ? 1 : 0);
    if (!(this.m_ExportFileTextBox.Text != string.Empty))
      return;
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSettingsPrefix + "ExportFileName", this.m_ExportFileTextBox.Text);
  }

  private void OnSiteComponentReportClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_SiteReportGroupBox = new GroupBox();
    this.m_ReportListView = new ListView();
    this.m_ReportTreeView = new TreeView();
    this.m_CloseButton = new Button();
    this.m_ExportButton = new Button();
    this.m_ExportOptionsGroupBox = new GroupBox();
    this.m_TabExportRadioButton = new RadioButton();
    this.m_CommaExportRadioButton = new RadioButton();
    this.m_ExportFileTextBox = new TextBox();
    this.m_ExportFileButton = new Button();
    this.m_ExportFileLabel = new Label();
    this.m_SiteReportGroupBox.SuspendLayout();
    this.m_ExportOptionsGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_SiteReportGroupBox.Controls.Add((Control) this.m_ReportListView);
    this.m_SiteReportGroupBox.Controls.Add((Control) this.m_ReportTreeView);
    this.m_SiteReportGroupBox.Location = new Point(12, 5);
    this.m_SiteReportGroupBox.Name = "m_SiteReportGroupBox";
    this.m_SiteReportGroupBox.Size = new Size(532, 308);
    this.m_SiteReportGroupBox.TabIndex = 0;
    this.m_SiteReportGroupBox.TabStop = false;
    this.m_SiteReportGroupBox.Text = "Site Component Report";
    this.m_ReportListView.Location = new Point(214, 16 /*0x10*/);
    this.m_ReportListView.MultiSelect = false;
    this.m_ReportListView.Name = "m_ReportListView";
    this.m_ReportListView.Size = new Size(312, 285);
    this.m_ReportListView.TabIndex = 1;
    this.m_ReportListView.UseCompatibleStateImageBehavior = false;
    this.m_ReportListView.View = View.Details;
    this.m_ReportTreeView.Location = new Point(6, 16 /*0x10*/);
    this.m_ReportTreeView.Name = "m_ReportTreeView";
    this.m_ReportTreeView.Size = new Size(202, 285);
    this.m_ReportTreeView.TabIndex = 0;
    this.m_ReportTreeView.AfterSelect += new TreeViewEventHandler(this.ReportTreeViewAfterSelect);
    this.m_CloseButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CloseButton.Location = new Point(470, 405);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(76, 23);
    this.m_CloseButton.TabIndex = 3;
    this.m_CloseButton.Text = "&Close";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClicked);
    this.m_ExportButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ExportButton.Location = new Point(388, 405);
    this.m_ExportButton.Name = "m_ExportButton";
    this.m_ExportButton.Size = new Size(76, 23);
    this.m_ExportButton.TabIndex = 2;
    this.m_ExportButton.Text = "&Export";
    this.m_ExportButton.UseVisualStyleBackColor = true;
    this.m_ExportButton.Click += new EventHandler(this.OnExportButtonClicked);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_TabExportRadioButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_CommaExportRadioButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileTextBox);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileButton);
    this.m_ExportOptionsGroupBox.Controls.Add((Control) this.m_ExportFileLabel);
    this.m_ExportOptionsGroupBox.Location = new Point(12, 320);
    this.m_ExportOptionsGroupBox.Name = "m_ExportOptionsGroupBox";
    this.m_ExportOptionsGroupBox.Size = new Size(532, 77);
    this.m_ExportOptionsGroupBox.TabIndex = 1;
    this.m_ExportOptionsGroupBox.TabStop = false;
    this.m_ExportOptionsGroupBox.Text = "Export Options";
    this.m_TabExportRadioButton.AutoSize = true;
    this.m_TabExportRadioButton.Location = new Point(181, 20);
    this.m_TabExportRadioButton.Name = "m_TabExportRadioButton";
    this.m_TabExportRadioButton.Size = new Size(139, 17);
    this.m_TabExportRadioButton.TabIndex = 4;
    this.m_TabExportRadioButton.TabStop = true;
    this.m_TabExportRadioButton.Text = "&Tab Delimited (Text File)";
    this.m_TabExportRadioButton.UseVisualStyleBackColor = true;
    this.m_CommaExportRadioButton.AutoSize = true;
    this.m_CommaExportRadioButton.Location = new Point(6, 20);
    this.m_CommaExportRadioButton.Name = "m_CommaExportRadioButton";
    this.m_CommaExportRadioButton.Size = new Size(155, 17);
    this.m_CommaExportRadioButton.TabIndex = 3;
    this.m_CommaExportRadioButton.TabStop = true;
    this.m_CommaExportRadioButton.Text = "&Comma Delimited (Text File)";
    this.m_CommaExportRadioButton.UseVisualStyleBackColor = true;
    this.m_ExportFileTextBox.Location = new Point(58, 43);
    this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
    this.m_ExportFileTextBox.Size = new Size(438, 20);
    this.m_ExportFileTextBox.TabIndex = 6;
    this.m_ExportFileButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
    this.m_ExportFileButton.Location = new Point(502, 43);
    this.m_ExportFileButton.Name = "m_ExportFileButton";
    this.m_ExportFileButton.Size = new Size(24, 20);
    this.m_ExportFileButton.TabIndex = 7;
    this.m_ExportFileButton.TabStop = false;
    this.m_ExportFileButton.Text = "...";
    this.m_ExportFileButton.UseVisualStyleBackColor = true;
    this.m_ExportFileButton.Click += new EventHandler(this.OnExportFileButtonClick);
    this.m_ExportFileLabel.AutoSize = true;
    this.m_ExportFileLabel.Location = new Point(6, 46);
    this.m_ExportFileLabel.Name = "m_ExportFileLabel";
    this.m_ExportFileLabel.Size = new Size(26, 13);
    this.m_ExportFileLabel.TabIndex = 5;
    this.m_ExportFileLabel.Text = "Fi&le:";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(558, 435);
    this.Controls.Add((Control) this.m_ExportOptionsGroupBox);
    this.Controls.Add((Control) this.m_ExportButton);
    this.Controls.Add((Control) this.m_CloseButton);
    this.Controls.Add((Control) this.m_SiteReportGroupBox);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(564, 467);
    this.Name = nameof (SiteComponentReport);
    this.Text = "Site Component Report";
    this.FormClosing += new FormClosingEventHandler(this.OnSiteComponentReportClosing);
    this.m_SiteReportGroupBox.ResumeLayout(false);
    this.m_ExportOptionsGroupBox.ResumeLayout(false);
    this.m_ExportOptionsGroupBox.PerformLayout();
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ExportButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }

  public enum RegionEdgingWarning
  {
    RegionEdgingNotFound,
    IssueWarning,
    WarningDisplayed,
  }
}
