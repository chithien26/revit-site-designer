﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.AddBreaklineForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class AddBreaklineForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private FormatOptions m_SlopeFormatOptions;
  private FormatOptions m_LengthFormatOptions;
  private DisplayUnit m_DisplayUnitSystem;
  private UnitSymbolType m_LengthUnitSymbolType;
  private UnitSymbolType m_SlopeUnitSymbolType;
  private Document m_Document;
  private DecimalSymbol m_DecimalSymbolType;
  private CurrentElevationFocus m_CurrentElevationFocus;
  private double m_dAdjustConstElevation;
  private IContainer components;
  private Label m_BeginningValueLabel;
  private TextBox m_BeginningElevationTextBox;
  private Button m_OKButton;
  private Button m_CancelButton;
  private Label m_EndingValueLabel;
  private TextBox m_EndingElevationTextBox;
  private RadioButton m_RelativeElevationRadioButton;
  private RadioButton m_ConstantElevationsRadioButton;
  private RadioButton m_GradeRadioButton;
  private TextBox m_GradeTextBox;
  private RadioButton m_ChainRadioButton;
  private RadioButton m_DisplayAndUseExistingHostLineRadioButton;
  private Panel m_HostLineSelectionPanel;
  private RadioButton m_DrawHostLineRadioButton;
  private Panel m_UsePanel;
  private RadioButton m_SegmentRadioButton;
  private Label m_RadiusLabel;
  private TextBox m_RadiusTextBox;
  private Button m_PickInRevitButton;
  private Label m_LinearIntervalLabel;
  private TextBox m_LinearIntervalTextBox;

  public AddBreaklineForm(Document _Document)
  {
    this.InitializeComponent();
    this.m_Document = _Document;
    this.Text = EPShared.LocalRM.GetString("AddBreaklineDialog");
    this.m_LinearIntervalLabel.Text = EPShared.LocalRM.GetString("Linear_AMP_PointIntervalDialog");
    this.m_RelativeElevationRadioButton.Text = EPShared.LocalRM.GetString("Re_AMP_lativeElevationsDialog");
    this.m_ConstantElevationsRadioButton.Text = EPShared.LocalRM.GetString("Constant_AMP_ElevationsDialog");
    this.m_GradeRadioButton.Text = EPShared.LocalRM.GetString("AMP_GradeDialog");
    this.m_BeginningValueLabel.Text = EPShared.LocalRM.GetString("AMP_BeginningElevationDialog");
    this.m_SegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
    this.m_ChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
    this.m_DisplayAndUseExistingHostLineRadioButton.Text = EPShared.LocalRM.GetString("DisplayAnd_AMP_UseExistingHostLineDialog");
    this.m_DrawHostLineRadioButton.Text = EPShared.LocalRM.GetString("AMP_DrawHostLineDialog");
    this.m_RadiusLabel.Text = EPShared.LocalRM.GetString("AMP_RadiusDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.EPToolTip.SetToolTip((Control) this.m_PickInRevitButton, EPShared.LocalRM.GetString("PickPointElevationToolTip"));
    this.m_DisplayUnitSystem = this.m_Document.DisplayUnitSystem;
    this.m_LengthFormatOptions = this.m_Document.GetUnits().GetFormatOptions((UnitType) 0);
    this.m_Units = this.m_Document.GetUnits();
    try
    {
      this.m_LengthUnitSymbolType = this.m_LengthFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_LengthUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_SlopeFormatOptions = this.m_Document.GetUnits().GetFormatOptions((UnitType) 59);
    try
    {
      this.m_SlopeUnitSymbolType = this.m_SlopeFormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_SlopeUnitSymbolType = (UnitSymbolType) 0;
    }
    this.m_DecimalSymbolType = this.m_Document.GetUnits().DecimalSymbol;
    this.m_dAdjustConstElevation = 0.0;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    double _dReturnValue = 0.0;
    string empty = string.Empty;
    this.GetDialogPosition();
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineLinearInterval", ref _dReturnValue))
      _dReturnValue = 5.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
    this.m_LinearIntervalTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineBeginningElevation", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
    this.m_BeginningElevationTextBox.Text = empty;
    this.m_RelativeElevationRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineElevationOption", ref _nReturnValue))
    {
      switch (_nReturnValue)
      {
        case 0:
          this.m_RelativeElevationRadioButton.Checked = true;
          break;
        case 1:
          this.m_ConstantElevationsRadioButton.Checked = true;
          break;
        default:
          this.m_GradeRadioButton.Checked = true;
          break;
      }
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineEndingElevation", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
    this.m_EndingElevationTextBox.Text = empty;
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineGrade", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_SlopeFormatOptions.DisplayUnits, this.m_SlopeFormatOptions.Accuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref empty);
    this.m_GradeTextBox.Text = empty;
    this.m_DisplayAndUseExistingHostLineRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineHostLineSelectionOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_DisplayAndUseExistingHostLineRadioButton.Checked = true;
      else
        this.m_DrawHostLineRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineRadius", ref _dReturnValue))
      _dReturnValue = 0.0;
    RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
    this.m_RadiusTextBox.Text = empty;
    this.m_ChainRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("AddBreaklineSegmentChainOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_SegmentRadioButton.Checked = true;
      else
        this.m_ChainRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_Document.PathName, "UseSharedElevation", ref _nReturnValue) || _nReturnValue != 1)
      return;
    this.m_dAdjustConstElevation = this.m_Document.ActiveProjectLocation.GetProjectPosition(new XYZ()).Elevation;
  }

  private void SaveSettings()
  {
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_LinearIntervalTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineLinearInterval", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BeginningElevationTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineBeginningElevation", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Document.GetUnits(), (UnitType) 59, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineGrade", _dReturnedDouble);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineEndingElevation", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineElevationOption", !this.m_RelativeElevationRadioButton.Checked ? (!this.m_ConstantElevationsRadioButton.Checked ? 2 : 1) : 0);
    ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineHostLineSelectionOption", !this.m_DisplayAndUseExistingHostLineRadioButton.Checked ? 1 : 0);
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble, false))
      ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineRadius", _dReturnedDouble);
    ApplicationUtility.Settings.eplSetE_SetSetting("AddBreaklineSegmentChainOption", !this.m_SegmentRadioButton.Checked ? 1 : 0);
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnElevationGradeOptionChecked(object sender, EventArgs e)
  {
    this.m_EndingValueLabel.Enabled = !this.m_RelativeElevationRadioButton.Checked;
    this.m_EndingElevationTextBox.Enabled = this.m_ConstantElevationsRadioButton.Checked;
    this.m_EndingElevationTextBox.Visible = !this.m_GradeRadioButton.Checked;
    this.m_GradeTextBox.Visible = this.m_GradeRadioButton.Checked;
    this.m_GradeTextBox.Enabled = this.m_GradeRadioButton.Checked;
    if (this.m_GradeRadioButton.Checked)
      this.m_EndingValueLabel.Text = EPShared.LocalRM.GetString("AMP_GradeDialog") + ":";
    else
      this.m_EndingValueLabel.Text = EPShared.LocalRM.GetString("EndingEle_AMP_vationDialog");
  }

  private void OnAddBreaklineFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void FormatLinearIntervalValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_LinearIntervalTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_LinearIntervalTextBox.Text = empty;
    }
    else
      this.m_LinearIntervalTextBox.Focus();
  }

  private void OnLinearIntervalKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatLinearIntervalValue();
  }

  private void OnLinearIntervalTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatLinearIntervalValue();
  }

  private void FormatBeginningElevationValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_BeginningElevationTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_BeginningElevationTextBox.Text = empty;
    }
    else
      this.m_BeginningElevationTextBox.Focus();
  }

  private void FormatEndingElevationValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationTextBox.Text, this.m_Document.GetUnits(), (UnitType) 0, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
      this.m_EndingElevationTextBox.Text = empty;
    }
    else
      this.m_EndingElevationTextBox.Focus();
  }

  private void FormatGradeValue()
  {
    string empty = string.Empty;
    double _dReturnedDouble = 0.0;
    if (RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Document.GetUnits(), (UnitType) 59, ref _dReturnedDouble))
    {
      RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_SlopeFormatOptions.DisplayUnits, this.m_SlopeFormatOptions.Accuracy, this.m_SlopeUnitSymbolType, this.m_Units, ref empty);
      this.m_GradeTextBox.Text = empty;
    }
    else
      this.m_GradeTextBox.Focus();
  }

  private void OnBeginningElevationTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatBeginningElevationValue();
    this.m_CurrentElevationFocus = CurrentElevationFocus.BeginningElevationRange;
  }

  private void OnBeginningElevationTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatBeginningElevationValue();
  }

  private void OnEndingElevationTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatEndingElevationValue();
  }

  private void OnEndingElevationTextBoxLeave(object sender, EventArgs e)
  {
    this.FormatEndingElevationValue();
    this.m_CurrentElevationFocus = CurrentElevationFocus.EndingElevationRange;
  }

  private void OnGradeTextBoxKeyDown(object sender, KeyEventArgs e)
  {
    if (e.KeyData != Keys.Return)
      return;
    this.FormatGradeValue();
  }

  private void OnGradeTextBoxLeave(object sender, EventArgs e) => this.FormatGradeValue();

  private void OnHostLineSelectionOptionChecked(object sender, EventArgs e)
  {
    this.m_RadiusLabel.Enabled = this.m_DrawHostLineRadioButton.Checked;
    this.m_RadiusTextBox.Enabled = this.m_DrawHostLineRadioButton.Checked;
  }

  private void OnPickInRevitButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Retry;
    this.Close();
  }

  public void SetFocusedElevation(double _dElevation)
  {
    string empty = string.Empty;
    _dElevation += this.m_dAdjustConstElevation;
    RevitGeometry.Units_ConvertDoubleToString(_dElevation, this.m_LengthFormatOptions.DisplayUnits, this.m_LengthFormatOptions.Accuracy, this.m_LengthUnitSymbolType, this.m_Units, ref empty);
    switch (this.m_CurrentElevationFocus)
    {
      case CurrentElevationFocus.BeginningElevationRange:
        this.m_BeginningElevationTextBox.Text = empty;
        this.m_PickInRevitButton.Enabled = true;
        break;
      case CurrentElevationFocus.EndingElevationRange:
        this.m_EndingElevationTextBox.Text = empty;
        this.m_PickInRevitButton.Enabled = true;
        break;
    }
  }

  private void OnAddBreaklineFormShown(object sender, EventArgs e)
  {
    switch (this.m_CurrentElevationFocus)
    {
      case CurrentElevationFocus.None:
        this.m_PickInRevitButton.Enabled = false;
        break;
      case CurrentElevationFocus.BeginningElevationRange:
        this.m_BeginningElevationTextBox.Focus();
        this.m_PickInRevitButton.Enabled = true;
        break;
      case CurrentElevationFocus.EndingElevationRange:
        this.m_EndingElevationTextBox.Focus();
        this.m_PickInRevitButton.Enabled = true;
        break;
    }
  }

  private void OnElevationTextBoxEnter(object sender, EventArgs e)
  {
    this.m_PickInRevitButton.Enabled = !this.m_RelativeElevationRadioButton.Checked;
  }

  private void OnElevationTextBoxLostFocus(object sender, EventArgs e)
  {
    if (this.m_PickInRevitButton.Focused || this.m_BeginningElevationTextBox.Focused || this.m_EndingElevationTextBox.Focused)
      return;
    this.m_PickInRevitButton.Enabled = false;
  }

  public double LinearInterval
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_LinearIntervalTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_LinearIntervalTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public double BeginningElevation
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_BeginningElevationTextBox.Text != string.Empty)
      {
        RevitGeometry.Units_ConvertStringToDouble(this.m_BeginningElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        if (!this.m_RelativeElevationRadioButton.Checked)
          _dReturnedDouble -= this.m_dAdjustConstElevation;
      }
      return _dReturnedDouble;
    }
  }

  public double EndingElevation
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_EndingElevationTextBox.Text != string.Empty)
      {
        RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        _dReturnedDouble -= this.m_dAdjustConstElevation;
      }
      return _dReturnedDouble;
    }
  }

  public double Grade
  {
    get
    {
      double _dReturnedDouble = 0.0;
      if (this.m_GradeTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Units, (UnitType) 59, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool RelativeElevationChecked => this.m_RelativeElevationRadioButton.Checked;

  public bool ConstantElevationsChecked => this.m_ConstantElevationsRadioButton.Checked;

  public bool GradeChecked => this.m_GradeRadioButton.Checked;

  public bool ExistingHostLineChecked => this.m_DisplayAndUseExistingHostLineRadioButton.Checked;

  public double Radius
  {
    get
    {
      if (this.m_DisplayAndUseExistingHostLineRadioButton.Checked)
        return 0.0;
      double _dReturnedDouble = 0.0;
      if (this.m_RadiusTextBox.Text != string.Empty)
        RevitGeometry.Units_ConvertStringToDouble(this.m_RadiusTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
      return _dReturnedDouble;
    }
  }

  public bool SegmentChecked => this.m_SegmentRadioButton.Checked;

  public bool ChainChecked => this.m_ChainRadioButton.Checked;

  public double GetGrade(double _dLegListLength)
  {
    double _dReturnedDouble = 0.0;
    if (this.m_ConstantElevationsRadioButton.Checked)
    {
      if (this.m_EndingElevationTextBox.Text != string.Empty)
      {
        RevitGeometry.Units_ConvertStringToDouble(this.m_EndingElevationTextBox.Text, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
        _dReturnedDouble = (_dReturnedDouble - this.m_dAdjustConstElevation - this.BeginningElevation) / _dLegListLength;
      }
    }
    else if (this.m_GradeRadioButton.Checked && this.m_GradeTextBox.Text != string.Empty)
      RevitGeometry.Units_ConvertStringToDouble(this.m_GradeTextBox.Text, this.m_Units, (UnitType) 59, ref _dReturnedDouble);
    return _dReturnedDouble;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (AddBreaklineForm));
    this.m_BeginningValueLabel = new Label();
    this.m_BeginningElevationTextBox = new TextBox();
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_EndingValueLabel = new Label();
    this.m_EndingElevationTextBox = new TextBox();
    this.m_RelativeElevationRadioButton = new RadioButton();
    this.m_ConstantElevationsRadioButton = new RadioButton();
    this.m_GradeRadioButton = new RadioButton();
    this.m_GradeTextBox = new TextBox();
    this.m_ChainRadioButton = new RadioButton();
    this.m_DisplayAndUseExistingHostLineRadioButton = new RadioButton();
    this.m_HostLineSelectionPanel = new Panel();
    this.m_DrawHostLineRadioButton = new RadioButton();
    this.m_UsePanel = new Panel();
    this.m_SegmentRadioButton = new RadioButton();
    this.m_RadiusLabel = new Label();
    this.m_RadiusTextBox = new TextBox();
    this.m_PickInRevitButton = new Button();
    this.m_LinearIntervalLabel = new Label();
    this.m_LinearIntervalTextBox = new TextBox();
    this.m_HostLineSelectionPanel.SuspendLayout();
    this.m_UsePanel.SuspendLayout();
    this.SuspendLayout();
    this.m_BeginningValueLabel.AutoSize = true;
    this.m_BeginningValueLabel.Location = new Point(10, 110);
    this.m_BeginningValueLabel.Name = "m_BeginningValueLabel";
    this.m_BeginningValueLabel.Size = new Size(104, 13);
    this.m_BeginningValueLabel.TabIndex = 6;
    this.m_BeginningValueLabel.Text = "Beginning Elevation:";
    this.m_BeginningElevationTextBox.Location = new Point(171, 107);
    this.m_BeginningElevationTextBox.Name = "m_BeginningElevationTextBox";
    this.m_BeginningElevationTextBox.Size = new Size(176 /*0xB0*/, 20);
    this.m_BeginningElevationTextBox.TabIndex = 7;
    this.m_BeginningElevationTextBox.KeyDown += new KeyEventHandler(this.OnBeginningElevationTextBoxKeyDown);
    this.m_BeginningElevationTextBox.Leave += new EventHandler(this.OnBeginningElevationTextBoxLeave);
    this.m_BeginningElevationTextBox.Enter += new EventHandler(this.OnElevationTextBoxEnter);
    this.m_BeginningElevationTextBox.LostFocus += new EventHandler(this.OnElevationTextBoxLostFocus);
    this.m_OKButton.Location = new Point(191, (int) byte.MaxValue);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 15;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(272, (int) byte.MaxValue);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 16 /*0x10*/;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelClick);
    this.m_EndingValueLabel.AutoSize = true;
    this.m_EndingValueLabel.Enabled = false;
    this.m_EndingValueLabel.Location = new Point(10, 136);
    this.m_EndingValueLabel.Name = "m_EndingValueLabel";
    this.m_EndingValueLabel.Size = new Size(90, 13);
    this.m_EndingValueLabel.TabIndex = 8;
    this.m_EndingValueLabel.Text = "Ending Elevation:";
    this.m_EndingElevationTextBox.Location = new Point(171, 133);
    this.m_EndingElevationTextBox.Name = "m_EndingElevationTextBox";
    this.m_EndingElevationTextBox.Size = new Size(176 /*0xB0*/, 20);
    this.m_EndingElevationTextBox.TabIndex = 7;
    this.m_EndingElevationTextBox.KeyDown += new KeyEventHandler(this.OnEndingElevationTextBoxKeyDown);
    this.m_EndingElevationTextBox.Leave += new EventHandler(this.OnEndingElevationTextBoxLeave);
    this.m_EndingElevationTextBox.Enter += new EventHandler(this.OnElevationTextBoxEnter);
    this.m_EndingElevationTextBox.LostFocus += new EventHandler(this.OnElevationTextBoxLostFocus);
    this.m_RelativeElevationRadioButton.AutoSize = true;
    this.m_RelativeElevationRadioButton.Checked = true;
    this.m_RelativeElevationRadioButton.Location = new Point(13, 38);
    this.m_RelativeElevationRadioButton.Name = "m_RelativeElevationRadioButton";
    this.m_RelativeElevationRadioButton.Size = new Size(111, 17);
    this.m_RelativeElevationRadioButton.TabIndex = 3;
    this.m_RelativeElevationRadioButton.TabStop = true;
    this.m_RelativeElevationRadioButton.Text = "Relative Elevation";
    this.m_RelativeElevationRadioButton.UseVisualStyleBackColor = true;
    this.m_RelativeElevationRadioButton.CheckedChanged += new EventHandler(this.OnElevationGradeOptionChecked);
    this.m_ConstantElevationsRadioButton.AutoSize = true;
    this.m_ConstantElevationsRadioButton.Location = new Point(13, 61);
    this.m_ConstantElevationsRadioButton.Name = "m_ConstantElevationsRadioButton";
    this.m_ConstantElevationsRadioButton.Size = new Size(119, 17);
    this.m_ConstantElevationsRadioButton.TabIndex = 4;
    this.m_ConstantElevationsRadioButton.Text = "Constant Elevations";
    this.m_ConstantElevationsRadioButton.UseVisualStyleBackColor = true;
    this.m_ConstantElevationsRadioButton.CheckedChanged += new EventHandler(this.OnElevationGradeOptionChecked);
    this.m_GradeRadioButton.AutoSize = true;
    this.m_GradeRadioButton.Location = new Point(13, 84);
    this.m_GradeRadioButton.Name = "m_GradeRadioButton";
    this.m_GradeRadioButton.Size = new Size(54, 17);
    this.m_GradeRadioButton.TabIndex = 5;
    this.m_GradeRadioButton.Text = "Grade";
    this.m_GradeRadioButton.UseVisualStyleBackColor = true;
    this.m_GradeRadioButton.CheckedChanged += new EventHandler(this.OnElevationGradeOptionChecked);
    this.m_GradeTextBox.Enabled = false;
    this.m_GradeTextBox.Location = new Point(171, 133);
    this.m_GradeTextBox.Name = "m_GradeTextBox";
    this.m_GradeTextBox.Size = new Size(176 /*0xB0*/, 20);
    this.m_GradeTextBox.TabIndex = 10;
    this.m_GradeTextBox.KeyDown += new KeyEventHandler(this.OnGradeTextBoxKeyDown);
    this.m_GradeTextBox.Leave += new EventHandler(this.OnGradeTextBoxLeave);
    this.m_ChainRadioButton.AutoSize = true;
    this.m_ChainRadioButton.Checked = true;
    this.m_ChainRadioButton.Location = new Point(158, 0);
    this.m_ChainRadioButton.Name = "m_ChainRadioButton";
    this.m_ChainRadioButton.Size = new Size(52, 17);
    this.m_ChainRadioButton.TabIndex = 1;
    this.m_ChainRadioButton.TabStop = true;
    this.m_ChainRadioButton.Text = "&Chain";
    this.m_ChainRadioButton.UseVisualStyleBackColor = true;
    this.m_DisplayAndUseExistingHostLineRadioButton.AutoSize = true;
    this.m_DisplayAndUseExistingHostLineRadioButton.Location = new Point(0, 0);
    this.m_DisplayAndUseExistingHostLineRadioButton.Name = "m_DisplayAndUseExistingHostLineRadioButton";
    this.m_DisplayAndUseExistingHostLineRadioButton.Size = new Size(204, 17);
    this.m_DisplayAndUseExistingHostLineRadioButton.TabIndex = 0;
    this.m_DisplayAndUseExistingHostLineRadioButton.Text = "Display and &Use an Existing Host Line";
    this.m_DisplayAndUseExistingHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_DisplayAndUseExistingHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_DisplayAndUseExistingHostLineRadioButton);
    this.m_HostLineSelectionPanel.Controls.Add((Control) this.m_DrawHostLineRadioButton);
    this.m_HostLineSelectionPanel.Location = new Point(12, 182);
    this.m_HostLineSelectionPanel.Name = "m_HostLineSelectionPanel";
    this.m_HostLineSelectionPanel.Size = new Size(334, 41);
    this.m_HostLineSelectionPanel.TabIndex = 12;
    this.m_DrawHostLineRadioButton.AutoSize = true;
    this.m_DrawHostLineRadioButton.Location = new Point(0, 23);
    this.m_DrawHostLineRadioButton.Name = "m_DrawHostLineRadioButton";
    this.m_DrawHostLineRadioButton.Size = new Size(228, 17);
    this.m_DrawHostLineRadioButton.TabIndex = 1;
    this.m_DrawHostLineRadioButton.Text = "&Draw Host Line (Click Escape to Complete)";
    this.m_DrawHostLineRadioButton.UseVisualStyleBackColor = true;
    this.m_DrawHostLineRadioButton.CheckedChanged += new EventHandler(this.OnHostLineSelectionOptionChecked);
    this.m_UsePanel.Controls.Add((Control) this.m_SegmentRadioButton);
    this.m_UsePanel.Controls.Add((Control) this.m_ChainRadioButton);
    this.m_UsePanel.Location = new Point(13, 159);
    this.m_UsePanel.Name = "m_UsePanel";
    this.m_UsePanel.Size = new Size(333, 18);
    this.m_UsePanel.TabIndex = 11;
    this.m_SegmentRadioButton.AutoSize = true;
    this.m_SegmentRadioButton.Location = new Point(-1, 0);
    this.m_SegmentRadioButton.Name = "m_SegmentRadioButton";
    this.m_SegmentRadioButton.Size = new Size(67, 17);
    this.m_SegmentRadioButton.TabIndex = 0;
    this.m_SegmentRadioButton.Text = "&Segment";
    this.m_SegmentRadioButton.UseVisualStyleBackColor = true;
    this.m_RadiusLabel.AutoSize = true;
    this.m_RadiusLabel.Enabled = false;
    this.m_RadiusLabel.Location = new Point(12, 232);
    this.m_RadiusLabel.Name = "m_RadiusLabel";
    this.m_RadiusLabel.Size = new Size(43, 13);
    this.m_RadiusLabel.TabIndex = 13;
    this.m_RadiusLabel.Text = "Radius:";
    this.m_RadiusTextBox.Enabled = false;
    this.m_RadiusTextBox.Location = new Point(171, 229);
    this.m_RadiusTextBox.Name = "m_RadiusTextBox";
    this.m_RadiusTextBox.Size = new Size(100, 20);
    this.m_RadiusTextBox.TabIndex = 14;
    this.m_PickInRevitButton.Enabled = false;
    this.m_PickInRevitButton.Image = (Image) componentResourceManager.GetObject("m_PickInRevitButton.Image");
    this.m_PickInRevitButton.Location = new Point(323, 12);
    this.m_PickInRevitButton.Name = "m_PickInRevitButton";
    this.m_PickInRevitButton.Size = new Size(24, 20);
    this.m_PickInRevitButton.TabIndex = 2;
    this.m_PickInRevitButton.TabStop = false;
    this.m_PickInRevitButton.UseVisualStyleBackColor = true;
    this.m_PickInRevitButton.Click += new EventHandler(this.OnPickInRevitButtonClick);
    this.m_LinearIntervalLabel.AutoSize = true;
    this.m_LinearIntervalLabel.Location = new Point(12, 15);
    this.m_LinearIntervalLabel.Name = "m_LinearIntervalLabel";
    this.m_LinearIntervalLabel.Size = new Size(104, 13);
    this.m_LinearIntervalLabel.TabIndex = 0;
    this.m_LinearIntervalLabel.Text = "Linear Point Interval:";
    this.m_LinearIntervalTextBox.Location = new Point(171, 12);
    this.m_LinearIntervalTextBox.Name = "m_LinearIntervalTextBox";
    this.m_LinearIntervalTextBox.Size = new Size(100, 20);
    this.m_LinearIntervalTextBox.TabIndex = 1;
    this.m_LinearIntervalTextBox.KeyDown += new KeyEventHandler(this.OnLinearIntervalKeyDown);
    this.m_LinearIntervalTextBox.Leave += new EventHandler(this.OnLinearIntervalTextBoxLeave);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(359, 290);
    this.Controls.Add((Control) this.m_LinearIntervalLabel);
    this.Controls.Add((Control) this.m_LinearIntervalTextBox);
    this.Controls.Add((Control) this.m_PickInRevitButton);
    this.Controls.Add((Control) this.m_HostLineSelectionPanel);
    this.Controls.Add((Control) this.m_UsePanel);
    this.Controls.Add((Control) this.m_RadiusLabel);
    this.Controls.Add((Control) this.m_RadiusTextBox);
    this.Controls.Add((Control) this.m_GradeTextBox);
    this.Controls.Add((Control) this.m_GradeRadioButton);
    this.Controls.Add((Control) this.m_ConstantElevationsRadioButton);
    this.Controls.Add((Control) this.m_RelativeElevationRadioButton);
    this.Controls.Add((Control) this.m_EndingValueLabel);
    this.Controls.Add((Control) this.m_EndingElevationTextBox);
    this.Controls.Add((Control) this.m_BeginningValueLabel);
    this.Controls.Add((Control) this.m_BeginningElevationTextBox);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (AddBreaklineForm);
    this.Text = nameof (AddBreaklineForm);
    this.Shown += new EventHandler(this.OnAddBreaklineFormShown);
    this.FormClosing += new FormClosingEventHandler(this.OnAddBreaklineFormClosing);
    this.m_HostLineSelectionPanel.ResumeLayout(false);
    this.m_HostLineSelectionPanel.PerformLayout();
    this.m_UsePanel.ResumeLayout(false);
    this.m_UsePanel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
