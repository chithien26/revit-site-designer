﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.BaseLine
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Runtime.InteropServices;

#nullable disable
namespace EPCommon;

[StructLayout(LayoutKind.Sequential)]
public class BaseLine
{
  private Eps_Point m_StartPnt;
  private Eps_Point m_EndPnt;

  public BaseLine()
  {
    this.m_StartPnt = new Eps_Point();
    this.m_EndPnt = new Eps_Point();
  }

  public BaseLine(Line _Line)
  {
    this.m_StartPnt = new Eps_Point(((Curve) _Line).GetEndPoint(0));
    this.m_EndPnt = new Eps_Point(((Curve) _Line).GetEndPoint(1));
  }

  public BaseLine(BaseLine _Line)
  {
    this.m_EndPnt = new Eps_Point(_Line.EndPnt);
    this.m_StartPnt = new Eps_Point(_Line.StartPnt);
  }

  public bool IsEqual(BaseLine _CompareLine)
  {
    bool flag = false;
    if (EPShared.eplGeoE_ArePntsDuplicates2D(this.m_StartPnt, _CompareLine.StartPnt) && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_EndPnt, _CompareLine.EndPnt) || EPShared.eplGeoE_ArePntsDuplicates2D(this.m_EndPnt, _CompareLine.StartPnt) && EPShared.eplGeoE_ArePntsDuplicates2D(this.m_StartPnt, _CompareLine.EndPnt))
      flag = true;
    return flag;
  }

  public Eps_Point StartPnt
  {
    get => this.m_StartPnt;
    set => this.m_StartPnt = value;
  }

  public Eps_Point EndPnt
  {
    get => this.m_EndPnt;
    set => this.m_EndPnt = value;
  }
}
