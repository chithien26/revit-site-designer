﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyInstanceComponentWrapperComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class FamilyInstanceComponentWrapperComparer : IComparer<FamilyInstanceComponentWrapper>
{
  int IComparer<FamilyInstanceComponentWrapper>.Compare(
    FamilyInstanceComponentWrapper first,
    FamilyInstanceComponentWrapper second)
  {
    int num = 0;
    if (first != null)
      num = second == null ? -1 : first.DrawOrder.CompareTo(second.DrawOrder);
    else if (second != null)
      num = 1;
    return num;
  }
}
