﻿// Decompiled with JetBrains decompiler
// Type: SITES.DocumentViewContainerList
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System.Collections.Generic;

#nullable disable
namespace SITES;

public class DocumentViewContainerList
{
  private List<DocumentViewContainer> m_DocumentViewContainerList;

  public DocumentViewContainerList()
  {
    this.m_DocumentViewContainerList = new List<DocumentViewContainer>();
  }

  public int FindIndexDocument(Document _FindDocument)
  {
    if (this.m_DocumentViewContainerList != null && this.m_DocumentViewContainerList.Count > 0)
    {
      for (int index = 0; index < this.m_DocumentViewContainerList.Count; ++index)
      {
        if (this.m_DocumentViewContainerList[index].Document.Equals((object) _FindDocument))
          return index;
      }
    }
    return -1;
  }

  public bool ContainsView(int _ContainerIndex, View _FindView)
  {
    if (this.m_DocumentViewContainerList != null && _ContainerIndex >= 0 && _ContainerIndex < this.m_DocumentViewContainerList.Count)
    {
      for (int index = this.m_DocumentViewContainerList[_ContainerIndex].ViewList.Count - 1; index >= 0; --index)
      {
        try
        {
          if (string.Compare(((Element) this.m_DocumentViewContainerList[_ContainerIndex].ViewList[index]).Name, ((Element) _FindView).Name, true) == 0)
            return true;
        }
        catch (InvalidObjectException ex)
        {
          this.m_DocumentViewContainerList[_ContainerIndex].ViewList.RemoveAt(index);
        }
      }
    }
    return false;
  }

  public List<DocumentViewContainer> DocumentViewList => this.m_DocumentViewContainerList;
}
