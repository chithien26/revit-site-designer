using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using SITES.Utilities;

namespace EPCommon;

public class ModifyPlant
{
	private Autodesk.Revit.ApplicationServices.Application m_CurApplication;

	private Document m_Document;

	private ModifyPlantForm m_DisplayForm;

	private List<FamilyContainer> m_PlantFamilyList;

	private List<FamilyContainer> m_ExistingPlantFamilyList;

	private EPTransactionContainer m_TransactionContainer;

	public ReadOnlyCollection<FamilyContainer> PlantFamilyList => new ReadOnlyCollection<FamilyContainer>(m_PlantFamilyList);

	public ReadOnlyCollection<FamilyContainer> ExistingPlantFamilyList => new ReadOnlyCollection<FamilyContainer>(m_ExistingPlantFamilyList);

	public Document Document => m_Document;

	public EPTransactionContainer TransactionContainer
	{
		get
		{
			return m_TransactionContainer;
		}
		set
		{
			m_TransactionContainer = value;
		}
	}

	public ModifyPlant(Document _CurDocument)
	{
		m_CurApplication = _CurDocument.Application;
		m_Document = _CurDocument;
		m_TransactionContainer = new EPTransactionContainer(m_Document);
		m_PlantFamilyList = new List<FamilyContainer>();
		m_ExistingPlantFamilyList = new List<FamilyContainer>();
		InitializeListData();
	}

	public void PopulateFamilyAndSymbolLists()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: false);
	}

	private void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
	{
		int num = 0;
		m_PlantFamilyList.Clear();
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		FilteredElementIterator elementIterator = filteredElementCollector.OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_Planting).GetElementIterator();
		filteredElementCollector = new FilteredElementCollector(m_Document);
		List<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements()
			.ToList();
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
		Eps_Point eps_Point = new Eps_Point();
		FamilySymbol familySymbol = null;
		FamilyInstance familyInstance = null;
		List<Eps_Point> list2 = null;
		LocationPoint locationPoint = null;
		Eps_Point eps_Point2 = null;
		elementIterator.Reset();
		while (elementIterator.MoveNext())
		{
			if (!(elementIterator.Current is FamilySymbol { Category: not null } familySymbol2) || familySymbol2.Category.Id.Value64() != BuiltInCategory.OST_Planting.GetHashCode())
			{
				continue;
			}
			list2 = null;
			foreach (Element item in list)
			{
				if (item is FamilyInstance { Symbol: not null } familyInstance2 && familyInstance2.Symbol.Category != null && familyInstance2.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && string.Compare(familySymbol2.UniqueId, familyInstance2.Symbol.UniqueId, ignoreCase: true) == 0)
				{
					if (list2 == null)
					{
						list2 = new List<Eps_Point>();
					}
					locationPoint = familyInstance2.Location as LocationPoint;
					eps_Point2 = new Eps_Point(locationPoint.Point);
					if (!RevitUtility.IsPointInPointList(eps_Point2, list2))
					{
						list2.Add(eps_Point2);
					}
				}
			}
			if (list2 != null && list2.Count > 0)
			{
				bool flag = true;
				while (flag)
				{
					flag = false;
					for (int i = 0; i < list2.Count; i++)
					{
						if (EPShared.eplGeoE_ArePntsDuplicates3D(list2[i], eps_Point))
						{
							eps_Point.z++;
							flag = true;
							break;
						}
					}
				}
			}
			bool flag2 = false;
			for (num = 0; num < m_PlantFamilyList.Count; num++)
			{
				if (string.Compare(m_PlantFamilyList[num].FamilyName, familySymbol2.Family.Name, ignoreCase: true) == 0)
				{
					m_PlantFamilyList[num].FamilySymbolList.Add(familySymbol2);
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				FamilyContainer familyContainer = new FamilyContainer(familySymbol2.Family.Name);
				familyContainer.FamilySymbolList.Add(familySymbol2);
				m_PlantFamilyList.Add(familyContainer);
			}
		}
		m_TransactionContainer.Rollback();
		string _strFullFamilyFilename = string.Empty;
		if (_bCheckForFamily && m_PlantFamilyList.Count == 0)
		{
			List<string> list3 = new List<string>();
			list3.Add(EPShared.LocalRM.GetString("LoadDefaultFamilyOption"));
			list3.Add(EPShared.LocalRM.GetString("ContinueWOLoadFamilyOption"));
			WarningOptionsForm warningOptionsForm = new WarningOptionsForm(m_Document.PathName, "ModifyPlants", EPShared.LocalRM.GetString("PlantingFamilyNotLoadedMessage"), list3);
			warningOptionsForm.ShowDialog();
			if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamilyOption"), ignoreCase: true) == 0)
			{
				Family _Family = null;
				if (RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Conifer", "LC Conifers.rfa", ref _strFullFamilyFilename))
				{
					m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + Path.GetFileName(_strFullFamilyFilename));
					RevitUtility.LoadFamily(m_Document, _strFullFamilyFilename, out _Family, _bUseFailureHandling: true, ref m_TransactionContainer);
					m_TransactionContainer.Commit();
					if (_Family != null && _Family.GetFamilySymbolIds() != null)
					{
						foreach (ElementId familySymbolId in _Family.GetFamilySymbolIds())
						{
							if (!(m_Document.GetElement(familySymbolId) is FamilySymbol familySymbol3))
							{
								continue;
							}
							bool flag3 = false;
							for (num = 0; num < m_PlantFamilyList.Count; num++)
							{
								if (string.Compare(m_PlantFamilyList[num].FamilyName, familySymbol3.Family.Name, ignoreCase: true) == 0)
								{
									m_PlantFamilyList[num].FamilySymbolList.Add(familySymbol3);
									flag3 = true;
									break;
								}
							}
							if (!flag3)
							{
								FamilyContainer familyContainer2 = new FamilyContainer(familySymbol3.Family.Name);
								familyContainer2.FamilySymbolList.Add(familySymbol3);
								m_PlantFamilyList.Add(familyContainer2);
							}
						}
					}
				}
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		for (num = 0; num < m_PlantFamilyList.Count; num++)
		{
			m_PlantFamilyList[num].FamilySymbolList.Sort(comparer);
		}
	}

	private void InitializeListData()
	{
		PopulateFamilyAndSymbolLists(_bCheckForFamily: true);
		PopulateExistingPlantList();
	}

	private void PopulateExistingPlantList()
	{
		int num = 0;
		bool flag = false;
		bool flag2 = false;
		m_ExistingPlantFamilyList.Clear();
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		foreach (Element item in list)
		{
			if (!(item is FamilyInstance { Symbol: not null } familyInstance) || familyInstance.Symbol.Category == null || familyInstance.Symbol.Category.Id.Value64() != BuiltInCategory.OST_Planting.GetHashCode())
			{
				continue;
			}
			for (num = 0; num < m_ExistingPlantFamilyList.Count; num++)
			{
				if (string.Compare(m_ExistingPlantFamilyList[num].FamilyName, familyInstance.Symbol.Family.Name, ignoreCase: true) != 0)
				{
					continue;
				}
				for (int i = 0; i < m_ExistingPlantFamilyList[num].FamilySymbolList.Count; i++)
				{
					if (string.Compare(m_ExistingPlantFamilyList[num].FamilySymbolList[i].Name, familyInstance.Symbol.Name, ignoreCase: true) == 0)
					{
						flag2 = true;
						break;
					}
				}
				if (!flag2)
				{
					m_ExistingPlantFamilyList[num].FamilySymbolList.Add(familyInstance.Symbol);
				}
				else
				{
					flag2 = false;
				}
				flag = true;
				break;
			}
			if (!flag)
			{
				FamilyContainer familyContainer = new FamilyContainer(familyInstance.Symbol.Family.Name);
				familyContainer.FamilySymbolList.Add(familyInstance.Symbol);
				m_ExistingPlantFamilyList.Add(familyContainer);
			}
			else
			{
				flag = false;
			}
		}
		FamilySymbolComparer comparer = new FamilySymbolComparer();
		for (num = 0; num < m_ExistingPlantFamilyList.Count; num++)
		{
			m_ExistingPlantFamilyList[num].FamilySymbolList.Sort(comparer);
		}
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		bool flag = false;
		if (m_ExistingPlantFamilyList.Count <= 0)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("ModifyPlantNoFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
		DialogResult _DialogResult = DialogResult.OK;
		using (m_DisplayForm = new ModifyPlantForm(this))
		{
			while (_DialogResult != DialogResult.Cancel)
			{
				flag = ShowDialog(ref _DialogResult);
				if (flag)
				{
					m_TransactionContainer.Commit();
				}
				else
				{
					m_TransactionContainer.Rollback();
				}
			}
			return flag;
		}
	}

	private bool GetFindSymbol()
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantMessage"), ref _Elements, _bDisplayError: true) || _Elements == null)
		{
			return false;
		}
		foreach (Element item in _Elements)
		{
			if (item is FamilyInstance { Symbol: not null } familyInstance && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode())
			{
				m_DisplayForm.SetExistingPlantFamilyComboBox(familyInstance.Symbol.Family.Name);
				m_DisplayForm.SetExistingPlantNameComboBox(familyInstance.Symbol.Name);
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		return true;
	}

	private bool GetSinglePoint(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, _bDisplayError: true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		m_Document.Regenerate();
		foreach (Element item in _Elements)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
				else
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("PlantAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				}
			}
			else
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportforModifyingPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			}
		}
		return true;
	}

	private bool GetWindowPoints(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		ElementSet _Elements = null;
		if (!RevitUtility.GetElementsFromProject(m_Document, EPShared.LocalRM.GetString("PickPlantsMessage"), ref _Elements, _bDisplayError: true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
		{
			return false;
		}
		m_Document.Regenerate();
		foreach (Element item in _Elements)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
			}
		}
		return true;
	}

	private bool GetAllPointsWithType(ref ElementSet _InstanceSet, ref List<Eps_Point> _PointList)
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		IList<Element> list = filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_Planting).ToElements();
		if (list == null || list.Count == 0)
		{
			return false;
		}
		foreach (Element item in list)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			LocationPoint locationPoint = item.Location as LocationPoint;
			if (familyInstance != null && familyInstance.Symbol != null && m_DisplayForm.ExistingType != null && string.Compare(familyInstance.Symbol.Name, m_DisplayForm.ExistingType.Name, ignoreCase: true) == 0 && familyInstance.Symbol.Category != null && familyInstance.Symbol.Category.Id.Value64() == BuiltInCategory.OST_Planting.GetHashCode() && locationPoint != null)
			{
				Eps_Point eps_Point = new Eps_Point(locationPoint.Point);
				if (!RevitUtility.IsPointInPointList(eps_Point, _PointList))
				{
					_PointList.Add(eps_Point);
					_InstanceSet.Insert(item);
				}
			}
		}
		return true;
	}

	private bool ShowDialog(ref DialogResult _DialogResult)
	{
		m_DisplayForm.ShowDialog();
		_DialogResult = m_DisplayForm.DialogResult;
		if (_DialogResult == DialogResult.Cancel)
		{
			return false;
		}
		if (_DialogResult == DialogResult.Retry)
		{
			return GetFindSymbol();
		}
		m_TransactionContainer.Start(EPShared.LocalRM.GetString("ModifyPlantsTransaction"));
		ElementSet _InstanceSet = new ElementSet();
		List<Eps_Point> _PointList = new List<Eps_Point>();
		if (m_DisplayForm.SelectionSetChecked)
		{
			if (!GetSinglePoint(ref _InstanceSet, ref _PointList))
			{
				return false;
			}
		}
		else if (m_DisplayForm.WindowSelectChecked)
		{
			if (!GetWindowPoints(ref _InstanceSet, ref _PointList))
			{
				return false;
			}
		}
		else if (m_DisplayForm.AllInstancesChecked && !GetAllPointsWithType(ref _InstanceSet, ref _PointList))
		{
			return false;
		}
		bool flag = true;
		bool flag2 = true;
		List<string> list = new List<string>();
		Parameter parameter = null;
		string text = string.Empty;
		ProgressBarForm progressBarForm = new ProgressBarForm();
		progressBarForm.MinValue = 0;
		progressBarForm.MaxValue = _InstanceSet.Size;
		if (_InstanceSet.Size <= 0)
		{
			progressBarForm.MaxValue = 1000;
		}
		progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarSavingModifiedPlantsMessage");
		progressBarForm.ShowForm();
		progressBarForm.Refresh();
		m_TransactionContainer.BeginTransaction();
		foreach (Element item in _InstanceSet)
		{
			FamilyInstance familyInstance = item as FamilyInstance;
			if (m_DisplayForm.ModifyPlantTypeChecked)
			{
				parameter = familyInstance.LookupParameter(RevitParameters.PlacementIDFamilyParameter);
				if (parameter != null && parameter.AsString() != string.Empty)
				{
					text = parameter.AsString();
					if (!list.Contains(text))
					{
						list.Add(text);
					}
				}
				familyInstance.Symbol = m_DisplayForm.Type;
				parameter = familyInstance.LookupParameter(RevitParameters.PlacementIDFamilyParameter);
				if (parameter != null && text != string.Empty)
				{
					parameter.Set(text);
				}
				text = string.Empty;
			}
			if (m_DisplayForm.ModifyPlantHeightChecked && Math.Abs(m_DisplayForm.PlantHeight) > 0.0 && flag)
			{
				parameter = familyInstance.LookupParameter(RevitParameters.PlantHeightPlantFamilyParameter);
				if (parameter != null)
				{
					parameter.Set(m_DisplayForm.PlantHeight);
				}
				else
				{
					flag = false;
				}
			}
			if (m_DisplayForm.ModifyPlantWidthChecked && Math.Abs(m_DisplayForm.PlantWidth) > 0.0 && flag2)
			{
				parameter = familyInstance.LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
				if (parameter != null)
				{
					parameter.Set(m_DisplayForm.PlantWidth);
				}
				else
				{
					flag2 = false;
				}
			}
			progressBarForm.UpdateProgressBar(1);
		}
		if (list != null && list.Count > 0)
		{
			UpdatePlacementFamilyInstances(list, m_DisplayForm.Type.UniqueId);
		}
		m_TransactionContainer.EndTransaction();
		progressBarForm.SetMaxValue();
		Thread.Sleep(300);
		progressBarForm.Close();
		PopulateExistingPlantList();
		return true;
	}

	private void UpdatePlacementFamilyInstances(List<string> _PlacementIDList, string _strSymbolID)
	{
		FilteredElementCollector filteredElementCollector = new FilteredElementCollector(m_Document);
		filteredElementCollector.OfClass(typeof(FamilyInstance)).OfCategory(BuiltInCategory.OST_GenericModel);
		Parameter LandcaddIDParameter = null;
		FamilyInstance FindFamilyInstance = null;
		List<Element> list = null;
		try
		{
			IEnumerable<Element> source = filteredElementCollector.Where((Element CurrentElement) => (FindFamilyInstance = CurrentElement as FamilyInstance) != null && (LandcaddIDParameter = FindFamilyInstance.Symbol.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter)) != null && string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) == 0 && CurrentElement.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter) != null);
			list = source.ToList();
		}
		catch (ApplicationException)
		{
			return;
		}
		LandcaddIDParameter = null;
		Parameter parameter = null;
		Parameter parameter2 = null;
		foreach (Element item in list)
		{
			if (!(item is FamilyInstance { Category: not null } familyInstance) || familyInstance.Category.Id.Value64() != BuiltInCategory.OST_GenericModel.GetHashCode())
			{
				continue;
			}
			LandcaddIDParameter = familyInstance.Symbol.LookupParameter(RevitParameters.LandcaddIDGenericModelFamilyParameter);
			if (LandcaddIDParameter == null || string.Compare(LandcaddIDParameter.AsString(), Convert.ToInt32(LandcaddID.FamilyInstancePlacement).ToString("000"), ignoreCase: true) != 0)
			{
				continue;
			}
			parameter2 = familyInstance.LookupParameter(RevitParameters.UniqueIDGenericModelFamilyParameter);
			if (parameter2 == null)
			{
				continue;
			}
			for (int num = 0; num < _PlacementIDList.Count; num++)
			{
				if (string.Compare(familyInstance.UniqueId, _PlacementIDList[num], ignoreCase: true) == 0)
				{
					parameter = familyInstance.LookupParameter(RevitParameters.SymbolIDGenericFamilyParameter);
					if (parameter != null && !parameter.IsReadOnly)
					{
						parameter.Set(_strSymbolID);
					}
					_PlacementIDList.RemoveAt(num);
					break;
				}
			}
			if (_PlacementIDList.Count == 0)
			{
				break;
			}
		}
	}
}
