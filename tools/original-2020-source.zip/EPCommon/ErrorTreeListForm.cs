﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ErrorTreeListForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using SITES.Sites_Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ErrorTreeListForm : Form
{
  private Document m_CurDocument;
  private IContainer components;
  private GroupBox m_MessagesGroupBox;
  private TreeView m_MessagesTreeView;
  private Button m_CloseButton;
  private Button m_ShowButton;

  public ErrorTreeListForm(Document _CurDocument, string _strFormTitle, TreeNode _CurrentNode)
  {
    this.InitializeComponent();
    this.Text = _strFormTitle;
    this.m_CloseButton.Text = EPShared.LocalRM.GetString("AMP_CloseDialog");
    this.m_ShowButton.Text = EPShared.LocalRM.GetString("AMP_ShowDialog");
    this.m_MessagesGroupBox.Text = EPShared.LocalRM.GetString("MessagesDialog");
    this.m_CurDocument = _CurDocument;
    this.m_MessagesTreeView.Nodes.Add(_CurrentNode);
    this.m_MessagesTreeView.ExpandAll();
  }

  private void OnCloseButtonClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.OK;
  }

  private void OnMessagesTreeViewAfterCheck(object sender, TreeViewEventArgs e)
  {
    if (e.Node == null)
      return;
    this.m_MessagesTreeView.AfterCheck -= new TreeViewEventHandler(this.OnMessagesTreeViewAfterCheck);
    this.SetChildTreeNodeSelectionState(e.Node);
    this.UnselectParentTreeNode(e.Node);
    if (this.m_MessagesTreeView.Nodes.Count > 0)
      this.m_ShowButton.Enabled = this.AreAnyTreeNodesChecked(this.m_MessagesTreeView.Nodes[0]);
    this.m_MessagesTreeView.AfterCheck += new TreeViewEventHandler(this.OnMessagesTreeViewAfterCheck);
  }

  private void SetChildTreeNodeSelectionState(TreeNode _ParentTreeNode)
  {
    if (_ParentTreeNode.Nodes == null || _ParentTreeNode.Nodes.Count <= 0)
      return;
    foreach (TreeNode node in _ParentTreeNode.Nodes)
    {
      node.Checked = _ParentTreeNode.Checked;
      this.SetChildTreeNodeSelectionState(node);
    }
  }

  private void UnselectParentTreeNode(TreeNode _ChildTreeNode)
  {
    if (_ChildTreeNode.Checked || _ChildTreeNode.Parent == null)
      return;
    _ChildTreeNode.Parent.Checked = false;
    this.UnselectParentTreeNode(_ChildTreeNode.Parent);
  }

  private List<Element> FindAllChildTreeNodeElements(TreeNode _ParentTreeNode)
  {
    List<Element> treeNodeElements = new List<Element>();
    if (_ParentTreeNode.Nodes != null && _ParentTreeNode.Nodes.Count > 0)
    {
      foreach (TreeNode node in _ParentTreeNode.Nodes)
      {
        if (node.Checked && node.Tag != null && node.Tag is Element tag)
          treeNodeElements.Add(tag);
        treeNodeElements.AddRange((IEnumerable<Element>) this.FindAllChildTreeNodeElements(node));
      }
    }
    return treeNodeElements;
  }

  private bool AreAnyTreeNodesChecked(TreeNode _TreeNode)
  {
    if (_TreeNode.Nodes != null && _TreeNode.Nodes.Count > 0)
    {
      foreach (TreeNode node in _TreeNode.Nodes)
      {
        if (node.Checked || this.AreAnyTreeNodesChecked(node))
          return true;
      }
    }
    return false;
  }

  private void OnShowButtonClick(object sender, EventArgs e)
  {
    List<Element> elementList = (List<Element>) null;
    if (this.m_MessagesTreeView.Nodes.Count > 0)
      elementList = this.FindAllChildTreeNodeElements(this.m_MessagesTreeView.Nodes[0]);
    if (elementList == null || elementList.Count <= 0)
      return;
    UIDocument uiDocument = new UIDocument(this.m_CurDocument);
    ElementSet elementSet = new ElementSet();
    foreach (Element element in elementList)
      elementSet.Insert(element);
    if (elementSet.Size <= 0)
      return;
    uiDocument.ShowElements(elementSet);
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_MessagesGroupBox = new GroupBox();
    this.m_MessagesTreeView = new TreeView();
    this.m_CloseButton = new Button();
    this.m_ShowButton = new Button();
    this.m_MessagesGroupBox.SuspendLayout();
    this.SuspendLayout();
    this.m_MessagesGroupBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_MessagesGroupBox.Controls.Add((Control) this.m_MessagesTreeView);
    this.m_MessagesGroupBox.Location = new Point(12, 12);
    this.m_MessagesGroupBox.Name = "m_MessagesGroupBox";
    this.m_MessagesGroupBox.Size = new Size(628, 316);
    this.m_MessagesGroupBox.TabIndex = 0;
    this.m_MessagesGroupBox.TabStop = false;
    this.m_MessagesGroupBox.Text = "Messages";
    this.m_MessagesTreeView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_MessagesTreeView.CheckBoxes = true;
    this.m_MessagesTreeView.Location = new Point(6, 19);
    this.m_MessagesTreeView.Name = "m_MessagesTreeView";
    this.m_MessagesTreeView.Size = new Size(616, 291);
    this.m_MessagesTreeView.TabIndex = 0;
    this.m_MessagesTreeView.AfterCheck += new TreeViewEventHandler(this.OnMessagesTreeViewAfterCheck);
    this.m_CloseButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_CloseButton.Location = new Point(565, 334);
    this.m_CloseButton.Name = "m_CloseButton";
    this.m_CloseButton.Size = new Size(75, 23);
    this.m_CloseButton.TabIndex = 2;
    this.m_CloseButton.Text = "&Close";
    this.m_CloseButton.UseVisualStyleBackColor = true;
    this.m_CloseButton.Click += new EventHandler(this.OnCloseButtonClicked);
    this.m_ShowButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ShowButton.Enabled = false;
    this.m_ShowButton.Location = new Point(484, 334);
    this.m_ShowButton.Name = "m_ShowButton";
    this.m_ShowButton.Size = new Size(75, 23);
    this.m_ShowButton.TabIndex = 1;
    this.m_ShowButton.Text = "&Show";
    this.m_ShowButton.UseVisualStyleBackColor = true;
    this.m_ShowButton.Click += new EventHandler(this.OnShowButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(652, 369);
    this.Controls.Add((Control) this.m_ShowButton);
    this.Controls.Add((Control) this.m_CloseButton);
    this.Controls.Add((Control) this.m_MessagesGroupBox);
    this.Icon = Resources.Siteworks;
    this.MaximizeBox = false;
    this.MinimizeBox = false;
    this.MinimumSize = new Size(260, 200);
    this.Name = nameof (ErrorTreeListForm);
    this.ShowInTaskbar = false;
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = nameof (ErrorTreeListForm);
    this.m_MessagesGroupBox.ResumeLayout(false);
    this.ResumeLayout(false);
    this.AcceptButton = (IButtonControl) this.m_ShowButton;
    this.CancelButton = (IButtonControl) this.m_CloseButton;
  }
}
