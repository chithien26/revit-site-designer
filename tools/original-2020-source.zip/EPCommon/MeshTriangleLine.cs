﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.MeshTriangleLine
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

#nullable disable
namespace EPCommon;

public class MeshTriangleLine
{
  private int m_nTriangleNumber;
  private uint m_nLineStartNumber;
  private uint m_nLineEndNumber;

  public MeshTriangleLine(int _nTriangleNumber, uint _nLineStartNumber, uint _nLineEndNumber)
  {
    this.m_nTriangleNumber = _nTriangleNumber;
    this.m_nLineStartNumber = _nLineStartNumber;
    this.m_nLineEndNumber = _nLineEndNumber;
  }

  public bool IsEqual(MeshTriangleLine _CompareLine)
  {
    bool flag = false;
    if ((int) this.m_nLineStartNumber == (int) _CompareLine.LineStartNumber && (int) this.m_nLineEndNumber == (int) _CompareLine.LineEndNumber || (int) this.m_nLineEndNumber == (int) _CompareLine.LineStartNumber && (int) this.m_nLineStartNumber == (int) _CompareLine.LineEndNumber)
      flag = true;
    return flag;
  }

  public int TriangleNumber => this.m_nTriangleNumber;

  public uint LineStartNumber => this.m_nLineStartNumber;

  public uint LineEndNumber => this.m_nLineEndNumber;
}
