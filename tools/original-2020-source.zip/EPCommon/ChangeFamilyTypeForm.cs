﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ChangeFamilyTypeForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ChangeFamilyTypeForm : EPForm
{
  private Document m_Document;
  private List<FamilyContainer> m_FamilyList;
  private LandcaddID m_CurrentLandcaddId = LandcaddID.SoftTerrain;
  private EPTransactionContainer m_TransactionContainer;
  private IContainer components;
  private Button m_OKButton;
  private Button m_CancelButton;
  private Label m_CurrentTypeLabel;
  private Label m_CurrentFamilyLabel;
  private Label m_CurrentFamilyValueLabel;
  private Button m_LoadFamilyButton;
  private ComboBox m_NewTypeComboBox;
  private Label m_NewTypeLabel;
  private ComboBox m_NewFamilyComboBox;
  private Label m_NewFamilyLabel;
  private Label m_CurrentTypeValueLabel;

  public ChangeFamilyTypeForm(
    Document _Document,
    EPTransactionContainer _TransactionContainer,
    string _strCurrentFamilyValue,
    string _strCurrentTypeValue,
    LandcaddID _CurrentLandcaddID)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("ChangeFamilyTypeDialog");
    this.m_CurrentFamilyLabel.Text = EPShared.LocalRM.GetString("CurrentFamilyDialog");
    this.m_CurrentTypeLabel.Text = EPShared.LocalRM.GetString("CurrentTypeDialog");
    this.m_NewFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_NewFamilyDialog");
    this.m_NewTypeLabel.Text = EPShared.LocalRM.GetString("New_AMP_TypeDialog");
    this.m_CurrentFamilyValueLabel.Text = _strCurrentFamilyValue;
    this.m_CurrentTypeValueLabel.Text = _strCurrentTypeValue;
    if (_strCurrentFamilyValue == string.Empty)
      this.m_CurrentFamilyLabel.Enabled = false;
    if (_strCurrentTypeValue == string.Empty)
      this.m_CurrentTypeLabel.Enabled = false;
    this.ContextualHelpID = "HID_SDchangeFamilyType";
    this.m_FamilyList = new List<FamilyContainer>();
    this.m_Document = _Document;
    this.m_TransactionContainer = _TransactionContainer;
    this.m_CurrentLandcaddId = _CurrentLandcaddID;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    this.GetDialogPosition();
    this.PopulateFamilyList();
    this.m_NewFamilyComboBox.DataSource = (object) this.m_FamilyList;
    this.m_NewFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
    for (int index = 0; index < this.m_NewFamilyComboBox.Items.Count; ++index)
    {
      if (this.m_NewFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, this.m_CurrentFamilyValueLabel.Text, true) == 0)
      {
        this.m_NewFamilyComboBox.SelectedIndex = index;
        break;
      }
    }
    for (int index = 0; index < this.m_NewTypeComboBox.Items.Count; ++index)
    {
      if (this.m_NewTypeComboBox.Items[index] is FamilySymbol familySymbol && string.Compare(((Element) familySymbol).Name, this.m_CurrentTypeValueLabel.Text, true) == 0)
      {
        this.m_NewTypeComboBox.SelectedIndex = index;
        break;
      }
    }
  }

  private void PopulateFamilyList()
  {
    this.m_FamilyList.Clear();
    Parameter CurSiteworksID = (Parameter) null;
    FamilySymbol familySymbol1 = (FamilySymbol) null;
    FilteredElementCollector source = new FilteredElementCollector(this.m_Document);
    source.OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001260);
    List<Element> list = ((IEnumerable<Element>) source).Where<Element>((Func<Element, bool>) (CurrentElement => (CurSiteworksID = CurrentElement.LookupParameter(RevitParameters.SiteworksIDFamilyParameter)) != null && string.Compare(CurSiteworksID.AsString(), Convert.ToInt32((object) this.m_CurrentLandcaddId).ToString("000"), true) == 0)).ToList<Element>();
    familySymbol1 = (FamilySymbol) null;
    foreach (Element element in list)
    {
      if (element is FamilySymbol familySymbol2 && ((Element) familySymbol2).Category != null)
      {
        CurSiteworksID = ((Element) familySymbol2).LookupParameter(RevitParameters.SiteworksIDFamilyParameter);
        if (CurSiteworksID != null && string.Compare(CurSiteworksID.AsString(), Convert.ToInt32((object) this.m_CurrentLandcaddId).ToString("000"), true) == 0)
        {
          bool flag = false;
          for (int index = 0; index < this.m_FamilyList.Count; ++index)
          {
            if (string.Compare(this.m_FamilyList[index].FamilyName, ((Element) familySymbol2.Family).Name, true) == 0)
            {
              this.m_FamilyList[index].FamilySymbolList.Add(familySymbol2);
              flag = true;
              break;
            }
          }
          if (!flag)
            this.m_FamilyList.Add(new FamilyContainer(((Element) familySymbol2.Family).Name)
            {
              FamilySymbolList = {
                familySymbol2
              }
            });
        }
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index = 0; index < this.m_FamilyList.Count; ++index)
      this.m_FamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnChangeValueClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_NewFamilyComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("PleaseSelectSoftTerrainFamilyFileMessage");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadSoftTerrainFamilyTransaction") + openFileDialog.SafeFileName);
            flag = RevitUtility.LoadFamily(this.m_Document, openFileDialog.FileName, out _Family, true, ref this.m_TransactionContainer);
            this.m_TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            this.m_TransactionContainer.Rollback();
            flag = false;
            int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SoftTerrainFamilyCantBeLoadedMessage") + Convert.ToInt32((object) this.m_CurrentLandcaddId).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SoftTerrainFamilyNotLoadedWithIDMessage") + Convert.ToInt32((object) this.m_CurrentLandcaddId).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.PopulateFamilyList();
        this.m_NewFamilyComboBox.DataSource = (object) this.m_FamilyList;
        this.m_NewFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
        if (_Family != null)
        {
          for (int index = 0; index < this.m_NewFamilyComboBox.Items.Count; ++index)
          {
            if (this.m_NewFamilyComboBox.Items[index] is FamilyContainer familyContainer && string.Compare(familyContainer.FamilyName, ((Element) _Family).Name, true) == 0)
            {
              this.m_NewFamilyComboBox.SelectedIndex = index;
              break;
            }
          }
        }
        if (this.m_NewFamilyComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotSoftTerrainMessage") + Convert.ToInt32((object) this.m_CurrentLandcaddId).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
  {
    if (!(this.m_NewFamilyComboBox.SelectedItem is FamilyContainer selectedItem))
      return;
    this.m_NewTypeComboBox.DataSource = (object) selectedItem.FamilySymbolList;
    this.m_NewTypeComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
  }

  public FamilySymbol NewTypeValue
  {
    get
    {
      return this.m_NewTypeComboBox.SelectedItem != null ? this.m_NewTypeComboBox.SelectedItem as FamilySymbol : (FamilySymbol) null;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (ChangeFamilyTypeForm));
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_CurrentTypeLabel = new Label();
    this.m_CurrentFamilyLabel = new Label();
    this.m_CurrentFamilyValueLabel = new Label();
    this.m_LoadFamilyButton = new Button();
    this.m_NewTypeComboBox = new ComboBox();
    this.m_NewTypeLabel = new Label();
    this.m_NewFamilyComboBox = new ComboBox();
    this.m_NewFamilyLabel = new Label();
    this.m_CurrentTypeValueLabel = new Label();
    this.SuspendLayout();
    this.m_OKButton.Location = new Point(222, 118);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 9;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(303, 118);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 10;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_CurrentTypeLabel.AutoSize = true;
    this.m_CurrentTypeLabel.Location = new Point(12, 41);
    this.m_CurrentTypeLabel.Name = "m_CurrentTypeLabel";
    this.m_CurrentTypeLabel.Size = new Size(71, 13);
    this.m_CurrentTypeLabel.TabIndex = 2;
    this.m_CurrentTypeLabel.Text = "Current Type:";
    this.m_CurrentFamilyLabel.AutoSize = true;
    this.m_CurrentFamilyLabel.Location = new Point(12, 15);
    this.m_CurrentFamilyLabel.Name = "m_CurrentFamilyLabel";
    this.m_CurrentFamilyLabel.Size = new Size(76, 13);
    this.m_CurrentFamilyLabel.TabIndex = 0;
    this.m_CurrentFamilyLabel.Text = "Current Family:";
    this.m_CurrentFamilyValueLabel.AutoSize = true;
    this.m_CurrentFamilyValueLabel.Location = new Point(130, 15);
    this.m_CurrentFamilyValueLabel.Name = "m_CurrentFamilyValueLabel";
    this.m_CurrentFamilyValueLabel.Size = new Size(34, 13);
    this.m_CurrentFamilyValueLabel.TabIndex = 1;
    this.m_CurrentFamilyValueLabel.Text = "Value";
    this.m_LoadFamilyButton.Location = new Point(354, 64 /*0x40*/);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 20);
    this.m_LoadFamilyButton.TabIndex = 6;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_NewTypeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_NewTypeComboBox.FormattingEnabled = true;
    this.m_NewTypeComboBox.Location = new Point(133, 91);
    this.m_NewTypeComboBox.Name = "m_NewTypeComboBox";
    this.m_NewTypeComboBox.Size = new Size(215, 21);
    this.m_NewTypeComboBox.TabIndex = 8;
    this.m_NewTypeLabel.AutoSize = true;
    this.m_NewTypeLabel.Location = new Point(12, 94);
    this.m_NewTypeLabel.Name = "m_NewTypeLabel";
    this.m_NewTypeLabel.Size = new Size(59, 13);
    this.m_NewTypeLabel.TabIndex = 7;
    this.m_NewTypeLabel.Text = "New Type:";
    this.m_NewFamilyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_NewFamilyComboBox.FormattingEnabled = true;
    this.m_NewFamilyComboBox.Location = new Point(133, 64 /*0x40*/);
    this.m_NewFamilyComboBox.Name = "m_NewFamilyComboBox";
    this.m_NewFamilyComboBox.Size = new Size(215, 21);
    this.m_NewFamilyComboBox.TabIndex = 5;
    this.m_NewFamilyComboBox.SelectedIndexChanged += new EventHandler(this.OnFamilyComboBoxSelectedIndexChanged);
    this.m_NewFamilyLabel.AutoSize = true;
    this.m_NewFamilyLabel.Location = new Point(12, 67);
    this.m_NewFamilyLabel.Name = "m_NewFamilyLabel";
    this.m_NewFamilyLabel.Size = new Size(64 /*0x40*/, 13);
    this.m_NewFamilyLabel.TabIndex = 4;
    this.m_NewFamilyLabel.Text = "&New Family:";
    this.m_CurrentTypeValueLabel.AutoSize = true;
    this.m_CurrentTypeValueLabel.Location = new Point(130, 41);
    this.m_CurrentTypeValueLabel.Name = "m_CurrentTypeValueLabel";
    this.m_CurrentTypeValueLabel.Size = new Size(34, 13);
    this.m_CurrentTypeValueLabel.TabIndex = 3;
    this.m_CurrentTypeValueLabel.Text = "Value";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(390, 153);
    this.Controls.Add((Control) this.m_CurrentTypeValueLabel);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_NewTypeComboBox);
    this.Controls.Add((Control) this.m_NewTypeLabel);
    this.Controls.Add((Control) this.m_NewFamilyComboBox);
    this.Controls.Add((Control) this.m_NewFamilyLabel);
    this.Controls.Add((Control) this.m_CurrentFamilyValueLabel);
    this.Controls.Add((Control) this.m_CurrentFamilyLabel);
    this.Controls.Add((Control) this.m_CurrentTypeLabel);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
    this.Name = nameof (ChangeFamilyTypeForm);
    this.StartPosition = FormStartPosition.CenterScreen;
    this.Text = "Change Family Type";
    this.FormClosing += new FormClosingEventHandler(this.OnChangeValueClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
