﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.Eps_PointComparer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class Eps_PointComparer : IComparer<Eps_Point>
{
  private bool m_bSortByElevation = true;
  private bool m_bDecendingValues = true;

  int IComparer<Eps_Point>.Compare(Eps_Point first, Eps_Point second)
  {
    int num = 0;
    if (this.m_bSortByElevation)
    {
      if (first != null)
        num = second == null ? -1 : first.z.CompareTo(second.z);
      else if (second != null)
        num = 1;
    }
    if (this.m_bDecendingValues)
      num = -num;
    return num;
  }
}
