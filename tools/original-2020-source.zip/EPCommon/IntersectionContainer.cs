﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.IntersectionContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class IntersectionContainer
{
  private List<ProfileContainer> m_ProfileList;
  private bool m_bStartingIntersection;
  private ProfileUsage m_ProfileUsage;
  private Eps_Leg m_RightOffsetLeg;
  private Eps_Leg m_LeftOffsetLeg;

  public IntersectionContainer()
  {
    this.m_ProfileUsage = ProfileUsage.EntireProfile;
    this.m_bStartingIntersection = true;
    this.m_ProfileList = new List<ProfileContainer>();
    this.m_RightOffsetLeg = (Eps_Leg) null;
    this.m_LeftOffsetLeg = (Eps_Leg) null;
  }

  public ProfileUsage ProfileUsage
  {
    get => this.m_ProfileUsage;
    set => this.m_ProfileUsage = value;
  }

  public bool StartingIntersection
  {
    get => this.m_bStartingIntersection;
    set => this.m_bStartingIntersection = value;
  }

  public List<ProfileContainer> Profiles
  {
    get => this.m_ProfileList;
    set => this.m_ProfileList = value;
  }

  public Eps_Leg RightOffsetLeg
  {
    get => this.m_RightOffsetLeg;
    set => this.m_RightOffsetLeg = value;
  }

  public Eps_Leg LeftOffsetLeg
  {
    get => this.m_LeftOffsetLeg;
    set => this.m_LeftOffsetLeg = value;
  }

  public bool IsEqual(IntersectionContainer another)
  {
    return this.ProfileUsage == another.ProfileUsage && this.StartingIntersection == another.StartingIntersection && this.IsProfileEqual(this.Profiles, another.Profiles) && this.LeftOffsetLeg.IsEqual(another.LeftOffsetLeg) && this.RightOffsetLeg.IsEqual(another.RightOffsetLeg);
  }

  private bool IsProfileEqual(List<ProfileContainer> first, List<ProfileContainer> second)
  {
    if (first.Count != second.Count)
      return false;
    for (int index = 0; index < first.Count; ++index)
    {
      if (!first[index].IsEqual(second[index]))
        return false;
    }
    return true;
  }
}
