﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ExternalDefinitionContainer
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class ExternalDefinitionContainer
{
  private string m_strName;
  private ExternalDefinition m_ExternalDefinition;

  public ExternalDefinitionContainer(string _strName) => this.m_strName = _strName;

  public ExternalDefinitionContainer(ExternalDefinition _ExternalDefinition)
  {
    this.m_ExternalDefinition = _ExternalDefinition;
    if (this.m_ExternalDefinition == null)
      return;
    this.m_strName = ((Definition) this.m_ExternalDefinition).Name;
  }

  public string Name
  {
    get => this.m_strName;
    set => this.m_strName = value;
  }

  public ExternalDefinition ExternalDefinition
  {
    get => this.m_ExternalDefinition;
    set
    {
      this.m_ExternalDefinition = value;
      if (this.m_ExternalDefinition == null)
        return;
      this.m_strName = ((Definition) this.m_ExternalDefinition).Name;
    }
  }
}
