﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SitePlacementSettings
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System.Collections.Generic;

#nullable disable
namespace EPCommon;

public class SitePlacementSettings
{
  private LandcaddID m_LocateType;
  private Level m_Level;
  private FamilySymbol m_Type;
  private double m_dElevation;
  private double m_dGrade;
  private List<double> m_BeginningElevationList;
  private List<double> m_EndingElevationList;
  private double m_dLinearPointInterval;
  private FamilySymbol m_PlacementSymbol;
  private bool m_bUseRightSide;
  private bool m_bIsReverse;
  private bool m_bIsRelativeElevation;
  private string m_strName;
  private int m_nTopoDrawOrder;
  private string m_strLoftFormID;
  private string m_strAdditionalLoftFormID;
  private string m_strIslandSurfaceId;
  private string m_strParkingLotSurfaceID;
  private string m_strParentTopoSurfaceID;
  private FamilySymbol m_IntersectionPlacementSymbol;
  private List<IntersectionStationContainer> m_IntersectionStations;
  private int m_nProjectInnerSlopes;
  private EPTransactionContainer m_TransactionContainer;

  public SitePlacementSettings()
  {
    this.m_LocateType = LandcaddID.Street;
    this.m_Level = (Level) null;
    this.m_Type = (FamilySymbol) null;
    this.m_dElevation = 0.0;
    this.m_dGrade = 0.0;
    this.m_BeginningElevationList = new List<double>();
    this.m_EndingElevationList = new List<double>();
    this.m_dLinearPointInterval = 0.0;
    this.m_PlacementSymbol = (FamilySymbol) null;
    this.m_bUseRightSide = false;
    this.m_bIsReverse = false;
    this.m_bIsRelativeElevation = false;
    this.m_nProjectInnerSlopes = 0;
    this.m_TransactionContainer = (EPTransactionContainer) null;
    this.m_nTopoDrawOrder = -1;
    this.m_strLoftFormID = string.Empty;
    this.AdditionalLoftFormID = string.Empty;
    this.m_strIslandSurfaceId = string.Empty;
    this.m_strParkingLotSurfaceID = string.Empty;
    this.m_strParentTopoSurfaceID = string.Empty;
    this.m_IntersectionPlacementSymbol = (FamilySymbol) null;
    this.m_IntersectionStations = (List<IntersectionStationContainer>) null;
  }

  public SitePlacementSettings(
    LandcaddID _LocateType,
    Level _Level,
    FamilySymbol _Type,
    FamilySymbol _PlacementSymbol,
    string _strName,
    int _nTopoDrawOrder,
    EPTransactionContainer _TransactionContainer)
  {
    this.m_LocateType = _LocateType;
    this.m_Level = _Level;
    this.m_Type = _Type;
    this.m_dElevation = 0.0;
    this.m_dGrade = 0.0;
    this.m_BeginningElevationList = new List<double>();
    this.m_EndingElevationList = new List<double>();
    this.m_dLinearPointInterval = 0.0;
    this.m_PlacementSymbol = _PlacementSymbol;
    this.m_bUseRightSide = false;
    this.m_bIsReverse = false;
    this.m_bIsRelativeElevation = false;
    this.m_strName = _strName;
    this.m_nTopoDrawOrder = _nTopoDrawOrder;
    this.m_TransactionContainer = _TransactionContainer;
    this.m_strLoftFormID = string.Empty;
    this.AdditionalLoftFormID = string.Empty;
    this.m_strIslandSurfaceId = string.Empty;
    this.m_strParkingLotSurfaceID = string.Empty;
    this.m_strParentTopoSurfaceID = string.Empty;
    this.m_IntersectionPlacementSymbol = (FamilySymbol) null;
    this.m_IntersectionStations = (List<IntersectionStationContainer>) null;
    if (this.m_Type != null && !this.m_Type.IsActive)
      this.m_Type.Activate();
    if (this.m_PlacementSymbol == null || this.m_PlacementSymbol.IsActive)
      return;
    this.m_PlacementSymbol.Activate();
  }

  public LandcaddID LocateType
  {
    get => this.m_LocateType;
    set => this.m_LocateType = value;
  }

  public Level Level
  {
    get => this.m_Level;
    set => this.m_Level = value;
  }

  public FamilySymbol Type
  {
    get => this.m_Type;
    set => this.m_Type = value;
  }

  public double Elevation
  {
    get => this.m_dElevation;
    set => this.m_dElevation = value;
  }

  public double Grade
  {
    get => this.m_dGrade;
    set => this.m_dGrade = value;
  }

  public List<double> BeginningElevationList
  {
    get => this.m_BeginningElevationList;
    set => this.m_BeginningElevationList = value;
  }

  public List<double> EndingElevationList
  {
    get => this.m_EndingElevationList;
    set => this.m_EndingElevationList = value;
  }

  public double LinearPointInterval
  {
    get => this.m_dLinearPointInterval;
    set => this.m_dLinearPointInterval = value;
  }

  public bool IsRelativeElevation
  {
    get => this.m_bIsRelativeElevation;
    set => this.m_bIsRelativeElevation = value;
  }

  public FamilySymbol PlacementSymbol
  {
    get => this.m_PlacementSymbol;
    set => this.m_PlacementSymbol = value;
  }

  public FamilySymbol IntersectionPlacementSymbol
  {
    get => this.m_IntersectionPlacementSymbol;
    set => this.m_IntersectionPlacementSymbol = value;
  }

  public bool UseRightSide
  {
    get => this.m_bUseRightSide;
    set => this.m_bUseRightSide = value;
  }

  public bool IsReverse
  {
    get => this.m_bIsReverse;
    set => this.m_bIsReverse = value;
  }

  public string Name
  {
    get => this.m_strName;
    set => this.m_strName = value;
  }

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }

  public int ProjectInnerSlopes
  {
    get => this.m_nProjectInnerSlopes;
    set => this.m_nProjectInnerSlopes = value;
  }

  public int TopoDrawOrder
  {
    get => this.m_nTopoDrawOrder;
    set => this.m_nTopoDrawOrder = value;
  }

  public string LoftFormID
  {
    get => this.m_strLoftFormID;
    set => this.m_strLoftFormID = value;
  }

  public string AdditionalLoftFormID
  {
    get => this.m_strAdditionalLoftFormID;
    set => this.m_strAdditionalLoftFormID = value;
  }

  public string IslandSurfaceID
  {
    get => this.m_strIslandSurfaceId;
    set => this.m_strIslandSurfaceId = value;
  }

  public string ParkingLotSurfaceID
  {
    get => this.m_strParkingLotSurfaceID;
    set => this.m_strParkingLotSurfaceID = value;
  }

  public string ParentTopoSurfaceID
  {
    get => this.m_strParentTopoSurfaceID;
    set => this.m_strParentTopoSurfaceID = value;
  }

  public List<IntersectionStationContainer> IntersectionStations
  {
    get => this.m_IntersectionStations;
    set => this.m_IntersectionStations = value;
  }
}
