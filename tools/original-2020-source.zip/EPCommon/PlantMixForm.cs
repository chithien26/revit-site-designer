﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantMixForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using SITES.Sites_Core;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantMixForm : EPForm
{
  private bool m_bApply;
  private string m_strCurrentInstance = string.Empty;
  private ReadOnlyCollection<FamilySymbol> m_ListOfPlantMixInstances;
  private string m_strSetttingName = string.Empty;
  private CreatePlantMix m_dataBuffer;
  private IContainer components;
  private Button m_OKButton;
  private Button m_CancelButton;
  private Button m_ApplyButton;
  private ComboBox m_PlantMixComboBox;
  private Label m_FamilyLabel;
  private TextBox m_RegionName;
  private Label m_RegionNameLabel;
  private RadioButton m_UnassignRadioButton;
  private RadioButton m_AssignRadioButton;
  private Button m_LoadFamilyButton;
  private Button m_FamilyManagerButton;

  public PlantMixForm(CreatePlantMix _dataBuffer)
  {
    this.InitializeComponent();
    this.EPToolTip.SetToolTip((Control) this.m_LoadFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
    this.m_dataBuffer = _dataBuffer;
    if (this.m_dataBuffer.CreateDialogType == CreateDialogType.PlantMix)
    {
      this.m_FamilyManagerButton.Image = (Image) Resources.PlantMixManager;
      this.EPToolTip.SetToolTip((Control) this.m_FamilyManagerButton, EPShared.LocalRM.GetString("PlantMixFamilyManagerRibbonButton"));
    }
    else
    {
      this.m_FamilyManagerButton.Image = (Image) Resources.PatioWalkManager;
      this.EPToolTip.SetToolTip((Control) this.m_FamilyManagerButton, EPShared.LocalRM.GetString("PatioWalkFamilyManagerRibbonButton"));
    }
    this.Text = this.m_dataBuffer.FormText;
    this.m_FamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
    this.m_RegionNameLabel.Text = EPShared.LocalRM.GetString("AMP_RegionNameDialog");
    this.m_AssignRadioButton.Text = EPShared.LocalRM.GetString("AssignDialog");
    this.m_UnassignRadioButton.Text = EPShared.LocalRM.GetString("UnassignDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ApplyButton.Text = EPShared.LocalRM.GetString("AMP_ApplyDialog");
    this.m_strSetttingName = Enum.GetName(typeof (CreateDialogType), (object) this.m_dataBuffer.CreateDialogType.GetHashCode()).ToUpper();
    this.GetSettings();
    this.m_ListOfPlantMixInstances = this.m_dataBuffer.PlantMixFamilyList;
    if (this.m_ListOfPlantMixInstances.Count > 0)
    {
      for (int index = 0; index < this.m_ListOfPlantMixInstances.Count; ++index)
      {
        if (!this.m_PlantMixComboBox.Items.Contains((object) ((Element) this.m_ListOfPlantMixInstances[index].Family).Name))
          this.m_PlantMixComboBox.Items.Add((object) ((Element) this.m_ListOfPlantMixInstances[index].Family).Name);
      }
    }
    int num = this.m_PlantMixComboBox.FindString(this.m_strCurrentInstance);
    if (num < 0)
      return;
    this.m_PlantMixComboBox.SelectedIndex = num;
  }

  private void GetSettings()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    ApplicationUtility.Settings.eplSetE_GetSetting(this.m_dataBuffer.Document.PathName, this.m_strSetttingName + "PickCurrentInstance", ref this.m_strCurrentInstance);
    this.m_AssignRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSetttingName + "AssignOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_AssignRadioButton.Checked = true;
      else
        this.m_UnassignRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting(this.m_strSetttingName + "PickCurrentType", ref empty))
      return;
    this.m_RegionName.Text = empty;
  }

  private void SaveSettings()
  {
    if (this.m_PlantMixComboBox.SelectedIndex < this.m_ListOfPlantMixInstances.Count)
      ApplicationUtility.Settings.eplSetE_SetSetting(this.m_dataBuffer.Document.PathName, this.m_strSetttingName + "PickCurrentInstance", ((Element) this.m_ListOfPlantMixInstances[this.m_PlantMixComboBox.SelectedIndex].Family).Name);
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSetttingName + "AssignOption", !this.m_AssignRadioButton.Checked ? 1 : 0);
    if (!(this.m_RegionName.Text != string.Empty))
      return;
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_strSetttingName + "PickCurrentType", this.m_RegionName.Text);
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    this.m_bApply = false;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.m_bApply = false;
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnApplyButtonClick(object sender, EventArgs e)
  {
    this.m_bApply = true;
    this.SaveSettings();
    this.DialogResult = DialogResult.OK;
  }

  private void OnAssignPlantMixFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnLoadFamilyButtonClick(object sender, EventArgs e)
  {
    int count = this.m_PlantMixComboBox.Items.Count;
    using (OpenFileDialog openFileDialog = new OpenFileDialog())
    {
      string empty = string.Empty;
      Family _Family = (Family) null;
      openFileDialog.Title = EPShared.LocalRM.GetString("Select__String") + this.m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("__GenericModelFamilyString");
      openFileDialog.RestoreDirectory = true;
      openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
      if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref empty) == 0)
        openFileDialog.InitialDirectory = empty;
      bool flag = false;
      DialogResult dialogResult = DialogResult.OK;
      while (dialogResult != DialogResult.Cancel)
      {
        dialogResult = openFileDialog.ShowDialog();
        if (dialogResult != DialogResult.Cancel)
        {
          try
          {
            if (this.m_dataBuffer.CreateDialogType == CreateDialogType.PlantMix)
              this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantMixFamilyTransaction") + openFileDialog.SafeFileName);
            else
              this.m_dataBuffer.TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPatioWalkFamilyTransaction") + openFileDialog.SafeFileName);
            EPTransactionContainer transactionContainer = this.m_dataBuffer.TransactionContainer;
            flag = RevitUtility.LoadFamily(this.m_dataBuffer.Document, openFileDialog.FileName, out _Family, true, ref transactionContainer);
            this.m_dataBuffer.TransactionContainer = transactionContainer;
            this.m_dataBuffer.TransactionContainer.Commit();
            break;
          }
          catch (SEHException ex)
          {
            flag = false;
            if (string.Compare(ex.Message, EPShared.LocalRM.GetString("ExternalComponentExceptionMessage"), true) == 0)
            {
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyCannotbeLoadedPickanother_Message") + this.m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("GenericModelLandcaddID_String") + this.m_dataBuffer.LandcaddIDValue + EPShared.LocalRM.GetString("_TypeParameterString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            }
          }
        }
      }
      if (!flag)
      {
        if (count != 0)
          return;
        int num = (int) RevitMessageBox.Show(this.m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("GenericModelLandcaddID_String") + this.m_dataBuffer.LandcaddIDValue + EPShared.LocalRM.GetString("_TypeParameterPFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
      else
      {
        this.m_dataBuffer.PopulateFamilySymbolList();
        this.m_PlantMixComboBox.Items.Clear();
        this.m_ListOfPlantMixInstances = this.m_dataBuffer.PlantMixFamilyList;
        if (this.m_ListOfPlantMixInstances.Count > 0)
        {
          for (int index = 0; index < this.m_ListOfPlantMixInstances.Count; ++index)
          {
            if (!this.m_PlantMixComboBox.Items.Contains((object) ((Element) this.m_ListOfPlantMixInstances[index].Family).Name))
            {
              this.m_PlantMixComboBox.Items.Add((object) ((Element) this.m_ListOfPlantMixInstances[index].Family).Name);
              if (_Family != null && string.Compare(((Element) this.m_ListOfPlantMixInstances[index].Family).Name, ((Element) _Family).Name, true) == 0)
                this.m_PlantMixComboBox.SelectedIndex = index;
            }
          }
          this.m_PlantMixComboBox.SelectedIndex = 0;
        }
        if (this.m_PlantMixComboBox.Items.Count != count)
          return;
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyLoadedNotA_Message") + this.m_dataBuffer.PlantOrPatioWalkText + EPShared.LocalRM.GetString("GenericModelLandcaddID_String") + this.m_dataBuffer.LandcaddIDValue + EPShared.LocalRM.GetString("_TypeParameterString"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
      }
    }
  }

  private void OnFamilyManagerButtonClick(object sender, EventArgs e)
  {
    DialogType _Type = DialogType.PlantMix;
    if (this.m_dataBuffer.CreateDialogType == CreateDialogType.PatioWalk)
      _Type = DialogType.Patio;
    using (PlantMixFamilyManager mixFamilyManager = new PlantMixFamilyManager(_Type, this.m_dataBuffer.Document))
    {
      int num = (int) mixFamilyManager.ShowDialog();
      this.m_dataBuffer.PopulateFamilySymbolList();
      this.m_ListOfPlantMixInstances = this.m_dataBuffer.PlantMixFamilyList;
      if (this.m_ListOfPlantMixInstances.Count <= 0)
        return;
      for (int index = 0; index < this.m_ListOfPlantMixInstances.Count; ++index)
      {
        if (!this.m_PlantMixComboBox.Items.Contains((object) ((Element) this.m_ListOfPlantMixInstances[index].Family).Name))
        {
          this.m_PlantMixComboBox.Items.Add((object) ((Element) this.m_ListOfPlantMixInstances[index].Family).Name);
          this.m_PlantMixComboBox.SelectedIndex = index;
        }
      }
    }
  }

  public bool AssignRegion => this.m_AssignRadioButton.Checked;

  public string RegionName => this.m_RegionName.Text;

  public bool ApplyStatus => this.m_bApply;

  public FamilySymbol SelectedFamilySymbol
  {
    get
    {
      return this.m_PlantMixComboBox.SelectedIndex < this.m_ListOfPlantMixInstances.Count ? this.m_ListOfPlantMixInstances[this.m_PlantMixComboBox.SelectedIndex] : (FamilySymbol) null;
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_OKButton = new Button();
    this.m_CancelButton = new Button();
    this.m_ApplyButton = new Button();
    this.m_PlantMixComboBox = new ComboBox();
    this.m_FamilyLabel = new Label();
    this.m_RegionName = new TextBox();
    this.m_RegionNameLabel = new Label();
    this.m_UnassignRadioButton = new RadioButton();
    this.m_AssignRadioButton = new RadioButton();
    this.m_LoadFamilyButton = new Button();
    this.m_FamilyManagerButton = new Button();
    this.SuspendLayout();
    this.m_OKButton.Location = new Point(147, 91);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 8;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.m_CancelButton.Location = new Point(228, 91);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 9;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_ApplyButton.Location = new Point(310, 91);
    this.m_ApplyButton.Name = "m_ApplyButton";
    this.m_ApplyButton.Size = new Size(75, 23);
    this.m_ApplyButton.TabIndex = 10;
    this.m_ApplyButton.Text = "&Apply";
    this.m_ApplyButton.UseVisualStyleBackColor = true;
    this.m_ApplyButton.Click += new EventHandler(this.OnApplyButtonClick);
    this.m_PlantMixComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_PlantMixComboBox.FormattingEnabled = true;
    this.m_PlantMixComboBox.Location = new Point(110, 12);
    this.m_PlantMixComboBox.Name = "m_PlantMixComboBox";
    this.m_PlantMixComboBox.Size = new Size(215, 21);
    this.m_PlantMixComboBox.TabIndex = 1;
    this.m_FamilyLabel.AutoSize = true;
    this.m_FamilyLabel.Location = new Point(12, 15);
    this.m_FamilyLabel.Name = "m_FamilyLabel";
    this.m_FamilyLabel.Size = new Size(39, 13);
    this.m_FamilyLabel.TabIndex = 0;
    this.m_FamilyLabel.Text = "&Family:";
    this.m_RegionName.Location = new Point(110, 39);
    this.m_RegionName.Name = "m_RegionName";
    this.m_RegionName.Size = new Size(215, 20);
    this.m_RegionName.TabIndex = 5;
    this.m_RegionNameLabel.AutoSize = true;
    this.m_RegionNameLabel.Location = new Point(12, 42);
    this.m_RegionNameLabel.Name = "m_RegionNameLabel";
    this.m_RegionNameLabel.Size = new Size(78, 13);
    this.m_RegionNameLabel.TabIndex = 4;
    this.m_RegionNameLabel.Text = "&Region Name :";
    this.m_UnassignRadioButton.AutoSize = true;
    this.m_UnassignRadioButton.Location = new Point(110, 65);
    this.m_UnassignRadioButton.Name = "m_UnassignRadioButton";
    this.m_UnassignRadioButton.Size = new Size(69, 17);
    this.m_UnassignRadioButton.TabIndex = 7;
    this.m_UnassignRadioButton.TabStop = true;
    this.m_UnassignRadioButton.Text = "&Unassign";
    this.m_UnassignRadioButton.UseVisualStyleBackColor = true;
    this.m_AssignRadioButton.AutoSize = true;
    this.m_AssignRadioButton.Location = new Point(15, 65);
    this.m_AssignRadioButton.Name = "m_AssignRadioButton";
    this.m_AssignRadioButton.Size = new Size(56, 17);
    this.m_AssignRadioButton.TabIndex = 6;
    this.m_AssignRadioButton.TabStop = true;
    this.m_AssignRadioButton.Text = "A&ssign";
    this.m_AssignRadioButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Location = new Point(331, 12);
    this.m_LoadFamilyButton.Name = "m_LoadFamilyButton";
    this.m_LoadFamilyButton.Size = new Size(24, 21);
    this.m_LoadFamilyButton.TabIndex = 2;
    this.m_LoadFamilyButton.TabStop = false;
    this.m_LoadFamilyButton.Text = "...";
    this.m_LoadFamilyButton.UseVisualStyleBackColor = true;
    this.m_LoadFamilyButton.Click += new EventHandler(this.OnLoadFamilyButtonClick);
    this.m_FamilyManagerButton.Location = new Point(361, 12);
    this.m_FamilyManagerButton.Name = "m_FamilyManagerButton";
    this.m_FamilyManagerButton.Size = new Size(23, 21);
    this.m_FamilyManagerButton.TabIndex = 3;
    this.m_FamilyManagerButton.TabStop = false;
    this.m_FamilyManagerButton.UseVisualStyleBackColor = true;
    this.m_FamilyManagerButton.Click += new EventHandler(this.OnFamilyManagerButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(397, 126);
    this.Controls.Add((Control) this.m_FamilyManagerButton);
    this.Controls.Add((Control) this.m_LoadFamilyButton);
    this.Controls.Add((Control) this.m_AssignRadioButton);
    this.Controls.Add((Control) this.m_UnassignRadioButton);
    this.Controls.Add((Control) this.m_PlantMixComboBox);
    this.Controls.Add((Control) this.m_FamilyLabel);
    this.Controls.Add((Control) this.m_RegionName);
    this.Controls.Add((Control) this.m_RegionNameLabel);
    this.Controls.Add((Control) this.m_ApplyButton);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_OKButton);
    this.FormBorderStyle = FormBorderStyle.FixedDialog;
    this.Name = nameof (PlantMixForm);
    this.Text = "Assign Plant Mix";
    this.FormClosing += new FormClosingEventHandler(this.OnAssignPlantMixFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ApplyButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
