﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.CurbForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.Creation;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using SITES.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class CurbForm : BaseForm
{
  private bool m_bIsLeftCurb;
  private const double m_bInscribedRadius = 0.0625;
  private double m_dGutterSlope;
  private double m_dSubgradeSlope;
  private double m_dSubgradeDepth;
  private double m_dGutterWidth;
  private double m_dCurbWidth;
  private double m_dCurbOffset;
  private double m_dCurbHeight;
  private FamilySymbol m_CurbFamilySymbol;
  private bool m_bUseInternalPoint = true;

  public CurbForm(
    FamilySymbol _FamilySymbol,
    Eps_Leg _CurrentLeg,
    bool _bAttachedToStreet,
    bool _bIsLeftCurb)
    : base(_CurrentLeg)
  {
    this.m_dSubgradeSlope = 0.0;
    this.m_dGutterSlope = 0.0;
    this.m_dSubgradeDepth = 0.0;
    this.m_dGutterWidth = 2.0;
    this.m_dCurbWidth = 1.0;
    this.m_dCurbOffset = 0.2;
    this.m_dCurbHeight = 0.5;
    this.m_bIsLeftCurb = _bIsLeftCurb;
    this.m_CurbFamilySymbol = _FamilySymbol;
    if (_FamilySymbol == null)
      return;
    Parameter parameter1 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetGutterWidthParameter);
    if (parameter1 != null)
      this.m_dGutterWidth = parameter1.AsDouble();
    Parameter parameter2 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetGutterSlopeParameter);
    if (parameter2 != null)
      this.m_dGutterSlope = parameter2.AsDouble();
    if (_bAttachedToStreet)
    {
      Parameter parameter3 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetPavementDepthParameter);
      if (parameter3 != null)
        this.m_dSubgradeDepth = parameter3.AsDouble();
      Parameter parameter4 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetCrossSlopeParameter);
      if (parameter4 != null)
        this.m_dSubgradeSlope = parameter4.AsDouble();
    }
    else
    {
      Parameter parameter5 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.CurbGutterHeightParameter);
      if (parameter5 != null)
        this.m_dSubgradeDepth = parameter5.AsDouble();
    }
    Parameter parameter6 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetCurbHeightParameter);
    if (parameter6 != null)
      this.m_dCurbHeight = parameter6.AsDouble();
    Parameter parameter7 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetCurbOffsetParameter);
    if (parameter7 != null)
      this.m_dCurbOffset = parameter7.AsDouble();
    Parameter parameter8 = ((Element) _FamilySymbol).LookupParameter(RevitParameters.StreetCurbWidthParameter);
    if (parameter8 == null)
      return;
    this.m_dCurbWidth = parameter8.AsDouble();
  }

  private List<Form> CreateLoftForm(double _dStartingOffset, double _dStartingElevation)
  {
    List<Form> loftForm = new List<Form>();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingCurbMassMessage");
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 0;
    List<ReferenceArrayArray> referenceArrayArray = this.GetReferenceArrayArray(_dStartingOffset, _dStartingElevation);
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = referenceArrayArray.Count;
    for (int index = 0; index < referenceArrayArray.Count; ++index)
    {
      if (referenceArrayArray[index] != null && referenceArrayArray[index].Size > 0)
      {
        string empty = string.Empty;
        Form form = this.NewLoftForm(referenceArrayArray[index], _dStartingOffset, _dStartingElevation, index, ref empty);
        if (form == null)
        {
          this.m_TransactionContainer.AbortTransaction();
          this.m_TransactionContainer.BeginTransaction();
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          loftForm.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return loftForm;
        }
        loftForm.Add(form);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return loftForm;
  }

  private List<Solid> CreateBlends(double _dStartingOffset, double _dStartingElevation)
  {
    List<Solid> blends = new List<Solid>();
    this.m_ProgressBarForm = new ProgressBarForm();
    this.m_ProgressBarForm.ShowForm();
    this.m_ProgressBarForm.Refresh();
    this.m_ProgressBarForm.Message = EPShared.LocalRM.GetString("ProgressBarCreatingCurbMassMessage");
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = 0;
    List<List<CurveLoop>> curveLoopArray = this.GetCurveLoopArray(_dStartingOffset, _dStartingElevation);
    this.m_ProgressBarForm.MinValue = 0;
    this.m_ProgressBarForm.MaxValue = curveLoopArray.Count;
    for (int index = 0; index < curveLoopArray.Count; ++index)
    {
      if (curveLoopArray[index] != null && curveLoopArray[index].Count > 0)
      {
        string empty = string.Empty;
        Solid solid = this.NewBlend(curveLoopArray[index], _dStartingOffset, _dStartingElevation, index, ref empty);
        if (GeometryObject.op_Equality((GeometryObject) solid, (GeometryObject) null))
        {
          this.m_ProgressBarForm.SetMaxValue();
          Thread.Sleep(300);
          this.m_ProgressBarForm.Close();
          blends.Clear();
          int num = (int) RevitMessageBox.Show(empty, EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return blends;
        }
        blends.Add(solid);
      }
      this.m_ProgressBarForm.UpdateProgressBar(1);
    }
    this.m_ProgressBarForm.SetMaxValue();
    Thread.Sleep(300);
    this.m_ProgressBarForm.Close();
    return blends;
  }

  private Form NewLoftForm(
    ReferenceArrayArray _CurbReferenceArrayArray,
    double _dStartingOffset,
    double _dStartingElevation,
    int _nProcessLegSegment,
    ref string _strErrorMessage)
  {
    Form form = (Form) null;
    try
    {
      form = this.m_MassDocument.FamilyCreate.NewLoftForm(true, _CurbReferenceArrayArray);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (InvalidOperationException ex)
    {
      if (string.Compare(((Exception) ex).Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("CurbTemplateNotMassTypeMessage");
        return (Form) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<ReferenceArrayArray> referenceArrayArray = this.GetReferenceArrayArray(_dStartingOffset, _dStartingElevation, _nProcessLegSegment);
        if (referenceArrayArray.Count > 0)
          form = this.NewLoftForm(referenceArrayArray[0], _dStartingOffset, _dStartingElevation, _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCreateMassMessage");
    }
    return form;
  }

  private Solid NewBlend(
    List<CurveLoop> _CurbReferenceArrayArray,
    double _dStartingOffset,
    double _dStartingElevation,
    int _nProcessLegSegment,
    ref string _strErrorMessage)
  {
    Solid solid = (Solid) null;
    try
    {
      SolidOptions solidOptions = (SolidOptions) null;
      Parameter parameter = ((Element) this.CurbFamilySymbol).LookupParameter(RevitParameters.StreetCurbMaterialParameter);
      if (parameter != null)
        solidOptions = new SolidOptions(new ElementId(parameter.AsInteger()), ElementId.InvalidElementId);
      solid = GeometryCreationUtilities.CreateLoftGeometry((IList<CurveLoop>) _CurbReferenceArrayArray, solidOptions);
      this.m_dOffsetAdjust = 0.01;
    }
    catch (InvalidOperationException ex)
    {
      if (string.Compare(((Exception) ex).Message, "The attempted operation is not permitted in this type of family.", true) == 0)
      {
        _strErrorMessage = EPShared.LocalRM.GetString("CurbTemplateNotMassTypeMessage");
        return (Solid) null;
      }
      if (RevitDefines.LT(this.m_dOffsetAdjust, 0.03))
      {
        this.m_dOffsetAdjust += 0.005;
        List<List<CurveLoop>> curveLoopArray = this.GetCurveLoopArray(_dStartingOffset, _dStartingElevation, _nProcessLegSegment);
        if (curveLoopArray.Count > 0)
          solid = this.NewBlend(curveLoopArray[0], _dStartingOffset, _dStartingElevation, _nProcessLegSegment, ref _strErrorMessage);
      }
      else
        _strErrorMessage = EPShared.LocalRM.GetString("UnableToCreateBlendGeometry");
    }
    return solid;
  }

  public override string CreateElement(
    Document doc,
    ref string _strAdditionalLoftID,
    string _strSiteComponentName,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseInternalPoint)
  {
    this.m_bUseInternalPoint = _bUseInternalPoint;
    List<Solid> blends = this.CreateBlends(_dStartingOffset, _dStartingElevation);
    if (blends == null || blends.Count == 0)
      return string.Empty;
    List<GeometryObject> geometryObjectList = new List<GeometryObject>();
    foreach (Solid solid in blends)
      geometryObjectList.Add((GeometryObject) solid);
    if (geometryObjectList.Count == 0)
      return string.Empty;
    Guid guid = doc.Application.ActiveAddInId.GetGUID();
    DirectShape element = DirectShape.CreateElement(doc, new ElementId((BuiltInCategory) -2001220));
    element.ApplicationId = guid.ToString();
    element.SetShape((IList<GeometryObject>) geometryObjectList);
    string uniqueId = ((Element) element).UniqueId;
    ElementTransformUtils.MoveElement(doc, ((Element) element).Id, this.m_LegInsertPoint.XYZ);
    ((Element) element).Name = _strSiteComponentName;
    return uniqueId;
  }

  public List<Form> CreateLoftFormWithParameters(
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseInternalPoint)
  {
    this.m_bUseInternalPoint = _bUseInternalPoint;
    List<Form> loftForm = this.CreateLoftForm(_dStartingOffset, _dStartingElevation);
    string empty = string.Empty;
    Category category = (Category) null;
    Category familyCategory = this.m_MassDocument.OwnerFamily.FamilyCategory;
    if (familyCategory != null && familyCategory.SubCategories != null && familyCategory.SubCategories.Size > 0)
    {
      if (!ApplicationUtility.Settings.eplSetE_GetSetting("CurbMassSubCategoryName", ref empty) && !ApplicationUtility.Settings.eplSetE_GetSetting("CurbMassSubCatergoryName", ref empty))
      {
        empty = EPShared.LocalRM.GetString("SWCurbLineNameString");
        ApplicationUtility.Settings.eplSetE_SetSetting("CurbMassSubCategoryName", empty);
      }
      if (familyCategory.SubCategories.Contains(empty))
        category = familyCategory.SubCategories[empty];
    }
    if (loftForm != null && loftForm.Count > 0)
    {
      if (category == null)
        category = this.m_MassDocument.Settings.Categories.NewSubcategory(familyCategory, empty);
      FamilyParameter familyParameter = (FamilyParameter) null;
      for (int index = 0; index < loftForm.Count; ++index)
      {
        if (index == 0)
          familyParameter = this.m_MassDocument.FamilyManager.AddParameter(RevitParameters.StreetCurbMaterialParameter, (BuiltInParameterGroup) -5000105, (ParameterType) 9, true);
        try
        {
          Parameter parameter = ((Element) loftForm[index])[(BuiltInParameter) -1002107];
          if (parameter != null)
            this.m_MassDocument.FamilyManager.AssociateElementParameterToFamilyParameter(parameter, familyParameter);
          if (category != null)
            ((GenericForm) loftForm[index]).Subcategory = category;
        }
        catch (InvalidOperationException ex)
        {
        }
      }
    }
    return loftForm;
  }

  public List<ReferenceArrayArray> GetReferenceArrayArray(
    double _dStartingOffset,
    double _dStartingElevation)
  {
    return this.GetReferenceArrayArray(_dStartingOffset, _dStartingElevation, -1);
  }

  public List<List<CurveLoop>> GetCurveLoopArray(
    double _dStartingOffset,
    double _dStartingElevation)
  {
    return this.GetCurveLoopArray(_dStartingOffset, _dStartingElevation, -1);
  }

  private List<ReferenceArrayArray> GetReferenceArrayArray(
    double _dStartingOffset,
    double _dStartingElevation,
    int _nProcessLegSegment)
  {
    List<ReferenceArrayArray> referenceArrayArray1 = new List<ReferenceArrayArray>();
    ReferenceArray referenceArray1 = (ReferenceArray) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    double _dStation1 = 0.0;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    double _dX = 0.0;
    double num1 = 0.0;
    double num2 = 0.0;
    double _dAdjustDistance1 = 0.0;
    bool flag1 = false;
    double _dDirection = 0.0;
    bool flag2 = false;
    double _dAdjustDistance2 = 0.0;
    int _nDocIndex = 0;
    if (this.m_MassLeg != null)
    {
      for (Eps_Leg _Leg = this.m_MassLeg; _Leg != null; _Leg = _Leg.Next)
      {
        if (_nProcessLegSegment > -1)
        {
          if (_nDocIndex <= _nProcessLegSegment)
          {
            if (_nDocIndex < _nProcessLegSegment)
            {
              ++_nDocIndex;
              continue;
            }
          }
          else
            break;
        }
        ReferenceArrayArray referenceArrayArray2 = new ReferenceArrayArray();
        double num3 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
        if (_Leg.Arc != null)
        {
          Arc arc = _Leg.Arc.RevitArc(this.m_MassDocument);
          double _dStation2 = 0.0;
          double _dOffset = 0.0;
          int num4 = 0;
          List<XYZ> list = ((Curve) arc).Tessellate().ToList<XYZ>();
          int count = list.Count;
          foreach (XYZ _XYZPoint in list)
          {
            Eps_Point _Point = new Eps_Point(_XYZPoint);
            if (num4 % 5 != 0 && num4 != 1 && num4 != count - 1)
            {
              ++num4;
            }
            else
            {
              EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation2, ref _dOffset);
              if (_nDocIndex > 0 && num4 == 0)
                _dStation2 += dOffsetAdjust;
              if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null && num4 == count - 1)
                _dStation2 -= dOffsetAdjust;
              ReferenceArray referenceArray2;
              if (_nDocIndex == 0 && num4 == 0)
              {
                if (this.m_MassLeg.IsLegClosed())
                {
                  int ArcDir = 0;
                  EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Arc, ref _dX);
                  if (_Leg.Last.Line != null)
                  {
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Last.Line.StartPnt, _Leg.Last.Line.EndPnt, ref num2);
                    ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Last.Line.EndPnt);
                  }
                  else if (_Leg.Last.Arc != null)
                  {
                    EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Last.Arc, ref num2);
                    ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Last.Arc.EndPnt);
                  }
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    flag2 = true;
                    double num5 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                    double SweepAngle = 0.0;
                    RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                    _dDirection = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                    _dAdjustDistance2 = Math.Abs(Math.Cos(num5 / 2.0));
                  }
                }
                referenceArray2 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2, _dStartingElevation) : this.FindReferenceArrayProfileAtStation(_nDocIndex, dOffsetAdjust, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
              }
              else if (num4 == count - 1)
              {
                if (_Leg.Next != null && _Leg.Next.Line != null)
                {
                  EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Arc, ref _dX);
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                  int ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Next.Line.EndPnt);
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    double num6 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                    double SweepAngle = 0.0;
                    RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                    num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                    if (!RevitDefines.EQ(_dX, num1))
                    {
                      flag1 = true;
                      _dAdjustDistance1 = Math.Abs(Math.Cos(num6 / 2.0));
                      referenceArray2 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2, true, num1, _dAdjustDistance1, _dStartingElevation);
                    }
                    else
                      referenceArray2 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                  }
                  else
                    referenceArray2 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                }
                else
                  referenceArray2 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2) : this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
              }
              else if (flag1)
              {
                referenceArray2 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance1, _dStartingElevation);
                flag1 = false;
              }
              else
                referenceArray2 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
              if (referenceArray2 != null && referenceArray2.Size > 0)
              {
                referenceArrayArray2.Append(referenceArray2);
                referenceArray1 = (ReferenceArray) null;
              }
              ++num4;
            }
          }
          _dStation1 += num3;
        }
        else
        {
          ReferenceArray referenceArray3;
          if (_nDocIndex == 0)
          {
            if (this.m_MassLeg.IsLegClosed())
            {
              int ArcDir = 0;
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
              if (_Leg.Last.Line != null)
              {
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Last.Line.StartPnt, _Leg.Last.Line.EndPnt, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Last.Line.EndPnt);
              }
              else if (_Leg.Last.Arc != null)
              {
                EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Last.Arc, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Last.Arc.EndPnt);
              }
              if (!RevitDefines.EQ(_dX, num2))
              {
                flag2 = true;
                double num7 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                double SweepAngle = 0.0;
                RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                _dDirection = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                _dAdjustDistance2 = Math.Abs(Math.Cos(num7 / 2.0));
              }
            }
            referenceArray3 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, _dStartingElevation) : this.FindReferenceArrayProfileAtStation(_nDocIndex, dOffsetAdjust, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
          }
          else if (flag1)
          {
            referenceArray3 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance1, _dStartingElevation);
            flag1 = false;
          }
          else
            referenceArray3 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust);
          if (referenceArray3 != null && referenceArray3.Size > 0)
          {
            referenceArrayArray2.Append(referenceArray3);
            referenceArray1 = (ReferenceArray) null;
          }
          _dStation1 += num3;
          if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null)
            _dStation1 -= dOffsetAdjust;
          ReferenceArray referenceArray4;
          if (_Leg.Next != null)
          {
            int ArcDir = 0;
            EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
            if (_Leg.Next.Line != null)
            {
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
              ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Line.EndPnt);
            }
            else if (_Leg.Next.Arc != null)
            {
              EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Next.Arc, ref num2);
              ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Arc.EndPnt);
            }
            if (!RevitDefines.EQ(_dX, num2))
            {
              double num8 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
              double SweepAngle = 0.0;
              RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
              num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
              if (!RevitDefines.EQ(_dX, num1))
              {
                flag1 = true;
                _dAdjustDistance1 = Math.Abs(Math.Cos(num8 / 2.0));
                referenceArray4 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, true, num1, _dAdjustDistance1, _dStartingElevation);
              }
              else
                referenceArray4 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1);
            }
            else
              referenceArray4 = this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1);
          }
          else
            referenceArray4 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1) : this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation1, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
          if (referenceArray4 != null && referenceArray4.Size > 0)
          {
            referenceArrayArray2.Append(referenceArray4);
            referenceArray1 = (ReferenceArray) null;
          }
        }
        referenceArrayArray1.Add(referenceArrayArray2);
        ++_nDocIndex;
      }
    }
    return referenceArrayArray1;
  }

  private List<List<CurveLoop>> GetCurveLoopArray(
    double _dStartingOffset,
    double _dStartingElevation,
    int _nProcessLegSegment)
  {
    List<List<CurveLoop>> curveLoopArray = new List<List<CurveLoop>>();
    CurveLoop curveLoop1 = (CurveLoop) null;
    Eps_Point epsPoint1 = new Eps_Point();
    Eps_Point epsPoint2 = new Eps_Point();
    double _dStation1 = 0.0;
    double dOffsetAdjust = this.m_dOffsetAdjust;
    double _dX = 0.0;
    double num1 = 0.0;
    double num2 = 0.0;
    double _dAdjustDistance1 = 0.0;
    bool flag1 = false;
    double _dDirection = 0.0;
    bool flag2 = false;
    double _dAdjustDistance2 = 0.0;
    int _nDocIndex = 0;
    if (this.m_MassLeg != null)
    {
      for (Eps_Leg _Leg = this.m_MassLeg; _Leg != null; _Leg = _Leg.Next)
      {
        if (_nProcessLegSegment > -1)
        {
          if (_nDocIndex <= _nProcessLegSegment)
          {
            if (_nDocIndex < _nProcessLegSegment)
            {
              ++_nDocIndex;
              continue;
            }
          }
          else
            break;
        }
        List<CurveLoop> curveLoopList = new List<CurveLoop>();
        double num3 = RevitGeometry.eplGeoE_CalcLegLength(_Leg);
        if (_Leg.Arc != null)
        {
          Arc arc = _Leg.Arc.RevitArc(this.m_MassDocument);
          double _dStation2 = 0.0;
          double _dOffset = 0.0;
          int num4 = 0;
          List<XYZ> list = ((Curve) arc).Tessellate().ToList<XYZ>();
          int count = list.Count;
          foreach (XYZ _XYZPoint in list)
          {
            Eps_Point _Point = new Eps_Point(_XYZPoint);
            if (num4 % 5 != 0 && num4 != 1 && num4 != count - 1)
            {
              ++num4;
            }
            else
            {
              EPShared.eplGeoE_CalcStationOffsetAlongArc(_Point, _Leg.Arc, ref _dStation2, ref _dOffset);
              if (_nDocIndex > 0 && num4 == 0)
                _dStation2 += dOffsetAdjust;
              if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null && num4 == count - 1)
                _dStation2 -= dOffsetAdjust;
              CurveLoop curveLoop2;
              if (_nDocIndex == 0 && num4 == 0)
              {
                if (this.m_MassLeg.IsLegClosed())
                {
                  int ArcDir = 0;
                  EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Arc, ref _dX);
                  if (_Leg.Last.Line != null)
                  {
                    EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Last.Line.StartPnt, _Leg.Last.Line.EndPnt, ref num2);
                    ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Last.Line.EndPnt);
                  }
                  else if (_Leg.Last.Arc != null)
                  {
                    EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Last.Arc, ref num2);
                    ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Last.Arc.EndPnt);
                  }
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    flag2 = true;
                    double num5 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                    double SweepAngle = 0.0;
                    RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                    _dDirection = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                    _dAdjustDistance2 = Math.Abs(Math.Cos(num5 / 2.0));
                  }
                }
                curveLoop2 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2, _dStartingElevation) : this.FindCurveLoopProfileAtStation(_nDocIndex, dOffsetAdjust, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
              }
              else if (num4 == count - 1)
              {
                if (_Leg.Next != null && _Leg.Next.Line != null)
                {
                  EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Arc, ref _dX);
                  EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
                  int ArcDir = RevitGeometry.CalcSignedArea(_Leg.Arc.StartPnt, _Leg.Arc.EndPnt, _Leg.Next.Line.EndPnt);
                  if (!RevitDefines.EQ(_dX, num2))
                  {
                    double num6 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                    double SweepAngle = 0.0;
                    RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                    num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                    if (!RevitDefines.EQ(_dX, num1))
                    {
                      flag1 = true;
                      _dAdjustDistance1 = Math.Abs(Math.Cos(num6 / 2.0));
                      curveLoop2 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2, true, num1, _dAdjustDistance1, _dStartingElevation);
                    }
                    else
                      curveLoop2 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                  }
                  else
                    curveLoop2 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
                }
                else
                  curveLoop2 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2) : this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
              }
              else if (flag1)
              {
                curveLoop2 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance1, _dStartingElevation);
                flag1 = false;
              }
              else
                curveLoop2 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + _dStation2);
              if (curveLoop2 != null)
              {
                curveLoopList.Add(curveLoop2);
                curveLoop1 = (CurveLoop) null;
              }
              ++num4;
            }
          }
          _dStation1 += num3;
        }
        else
        {
          CurveLoop curveLoop3;
          if (_nDocIndex == 0)
          {
            if (this.m_MassLeg.IsLegClosed())
            {
              int ArcDir = 0;
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
              if (_Leg.Last.Line != null)
              {
                EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Last.Line.StartPnt, _Leg.Last.Line.EndPnt, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Last.Line.EndPnt);
              }
              else if (_Leg.Last.Arc != null)
              {
                EPShared.eplGeoE_CalcTangentOutDirOfArc(_Leg.Last.Arc, ref num2);
                ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Last.Arc.EndPnt);
              }
              if (!RevitDefines.EQ(_dX, num2))
              {
                flag2 = true;
                double num7 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
                double SweepAngle = 0.0;
                RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
                _dDirection = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
                _dAdjustDistance2 = Math.Abs(Math.Cos(num7 / 2.0));
              }
            }
            curveLoop3 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, _dStartingElevation) : this.FindCurveLoopProfileAtStation(_nDocIndex, dOffsetAdjust, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
          }
          else if (flag1)
          {
            curveLoop3 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust, true, num1, _dAdjustDistance1, _dStartingElevation);
            flag1 = false;
          }
          else
            curveLoop3 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1 + dOffsetAdjust);
          if (curveLoop3 != null)
          {
            curveLoopList.Add(curveLoop3);
            curveLoop1 = (CurveLoop) null;
          }
          _dStation1 += num3;
          if (this.m_MassLeg.IsLegClosed() && _Leg.Next == null)
            _dStation1 -= dOffsetAdjust;
          CurveLoop curveLoop4;
          if (_Leg.Next != null)
          {
            int ArcDir = 0;
            EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Line.StartPnt, _Leg.Line.EndPnt, ref _dX);
            if (_Leg.Next.Line != null)
            {
              EPShared.eplGeoE_CalcHorzDirBtwnTwoPnts(_Leg.Next.Line.StartPnt, _Leg.Next.Line.EndPnt, ref num2);
              ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Line.EndPnt);
            }
            else if (_Leg.Next.Arc != null)
            {
              EPShared.eplGeoE_CalcTangentInDirOfArc(_Leg.Next.Arc, ref num2);
              ArcDir = RevitGeometry.CalcSignedArea(_Leg.Line.StartPnt, _Leg.Line.EndPnt, _Leg.Next.Arc.EndPnt);
            }
            if (!RevitDefines.EQ(_dX, num2))
            {
              double num8 = EPShared.eplGeoE_NormalizeRadians(num2 - _dX);
              double SweepAngle = 0.0;
              RevitGeometry.eplGeoE_CalcSweepAngle(ArcDir, num2, EPShared.eplGeoE_NormalizeRadians(_dX + Math.PI), ref SweepAngle);
              num1 = ArcDir != 1 ? EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0) + Math.PI) : EPShared.eplGeoE_NormalizeRadians(_dX - (double) ArcDir * (SweepAngle / 2.0));
              if (!RevitDefines.EQ(_dX, num1))
              {
                flag1 = true;
                _dAdjustDistance1 = Math.Abs(Math.Cos(num8 / 2.0));
                curveLoop4 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, true, num1, _dAdjustDistance1, _dStartingElevation);
              }
              else
                curveLoop4 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1);
            }
            else
              curveLoop4 = this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1);
          }
          else
            curveLoop4 = _nDocIndex != 0 && _Leg.Next != null || !flag2 ? this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1) : this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation1, true, _dDirection, _dAdjustDistance2, _dStartingElevation);
          if (curveLoop4 != null)
          {
            curveLoopList.Add(curveLoop4);
            curveLoop1 = (CurveLoop) null;
          }
        }
        curveLoopArray.Add(curveLoopList);
        ++_nDocIndex;
      }
    }
    return curveLoopArray;
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(int _nDocIndex, double _dStation)
  {
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, 0.0, 0.0, false, 0.0, 1.0);
  }

  private CurveLoop FindCurveLoopProfileAtStation(int _nDocIndex, double _dStation)
  {
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, 0.0, 0.0, false, 0.0, 1.0);
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    double _dStartElevation)
  {
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, 0.0, _dStartElevation, false, 0.0, 1.0);
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    double _dStartElevation)
  {
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, 0.0, _dStartElevation, false, 0.0, 1.0);
  }

  private ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance,
    double _dStartElevation)
  {
    return this.FindReferenceArrayProfileAtStation(_nDocIndex, _dStation, 0.0, _dStartElevation, _bUseDirection, _dDirection, _dAdjustDistance);
  }

  private CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance,
    double _dStartElevation)
  {
    return this.FindCurveLoopProfileAtStation(_nDocIndex, _dStation, 0.0, _dStartElevation, _bUseDirection, _dDirection, _dAdjustDistance);
  }

  public ReferenceArray FindReferenceArrayProfileAtStation(
    int _nDocIndex,
    double _dStation,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    ReferenceArray profileAtStation = new ReferenceArray();
    CurveArray curveArray = new CurveArray();
    try
    {
      Eps_Point epsPoint1 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.InnerSubgradeEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint2 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.OuterSubgradeEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint3 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.BackOfCurbEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint4 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.TopOfCurbEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint5 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.FlowlineEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint6 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.GutterEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint6, epsPoint5, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint6.XYZ, epsPoint5.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint5, epsPoint4, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint5.XYZ, epsPoint4.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint4, epsPoint3, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint4.XYZ, epsPoint3.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint3, epsPoint2, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint3.XYZ, epsPoint2.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint2, epsPoint1, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint2.XYZ, epsPoint1.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, epsPoint6, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint1.XYZ, epsPoint6.XYZ, true);
        curveArray.Append((Curve) line);
      }
      CurveLoop curveLoop = new CurveLoop();
      foreach (Curve curve in curveArray)
        curveLoop.Append(curve);
      SketchPlane sketchPlane = SketchPlane.Create(this.m_MassDocument, curveLoop.GetPlane());
      foreach (Curve curve in curveArray)
      {
        ModelCurve modelCurve = ((ItemFactoryBase) this.m_MassDocument.FamilyCreate).NewModelCurve(curve, sketchPlane);
        profileAtStation.Append(((CurveElement) modelCurve).GeometryCurve.Reference);
      }
    }
    catch (Exception ex)
    {
    }
    return profileAtStation;
  }

  public CurveLoop FindCurveLoopProfileAtStation(
    int _nDocIndex,
    double _dStation,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    CurveLoop profileAtStation = new CurveLoop();
    CurveArray curveArray = new CurveArray();
    try
    {
      Eps_Point epsPoint1 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.InnerSubgradeEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint2 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.OuterSubgradeEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint3 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.BackOfCurbEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint4 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.TopOfCurbEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint5 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.FlowlineEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      Eps_Point epsPoint6 = this.CalcTemplateOffsets(CurbForm.CurbOffsetPoint.GutterEdge, _dStation, _dStartingOffset, _dStartingElevation, _bUseDirection, _dDirection, _dAdjustDistance);
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint6, epsPoint5, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint6.XYZ, epsPoint5.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint5, epsPoint4, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint5.XYZ, epsPoint4.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint4, epsPoint3, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint4.XYZ, epsPoint3.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint3, epsPoint2, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint3.XYZ, epsPoint2.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint2, epsPoint1, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint2.XYZ, epsPoint1.XYZ, true);
        curveArray.Append((Curve) line);
      }
      if (!EPShared.eplGeoE_ArePntsDuplicates3D(epsPoint1, epsPoint6, 1.0 / 400.0))
      {
        Line line = RevitUtility.CreateLine(epsPoint1.XYZ, epsPoint6.XYZ, true);
        curveArray.Append((Curve) line);
      }
      foreach (Curve curve in curveArray)
        profileAtStation.Append(curve);
    }
    catch (Exception ex)
    {
    }
    return profileAtStation;
  }

  private Eps_Point CalcTemplateOffsets(
    CurbForm.CurbOffsetPoint _CurbOffsetPoint,
    double _dStation,
    double _dStartingOffset,
    double _dStartingElevation,
    bool _bUseDirection,
    double _dDirection,
    double _dAdjustDistance)
  {
    Eps_Point epsPoint = new Eps_Point();
    double num1 = this.m_dGutterWidth / _dAdjustDistance;
    double num2 = this.m_dCurbWidth / _dAdjustDistance;
    double num3 = this.m_dCurbOffset / _dAdjustDistance;
    double num4 = 1.0;
    double num5 = _dStartingOffset / _dAdjustDistance;
    double num6 = _dStartingElevation;
    if (this.m_bIsLeftCurb)
      num4 *= -1.0;
    switch (_CurbOffsetPoint)
    {
      case CurbForm.CurbOffsetPoint.InnerSubgradeEdge:
        if (this.m_bUseInternalPoint)
        {
          num6 -= this.m_dSubgradeDepth;
          break;
        }
        num5 -= num4 * (num1 + num2);
        num6 -= this.m_dSubgradeDepth + this.m_dCurbHeight - (num1 + num2) * this.m_dGutterSlope;
        break;
      case CurbForm.CurbOffsetPoint.GutterEdge:
        if (!this.m_bUseInternalPoint)
        {
          num5 -= num4 * (num1 + num2);
          num6 -= this.m_dCurbHeight - num1 * this.m_dGutterSlope;
          break;
        }
        break;
      case CurbForm.CurbOffsetPoint.FlowlineEdge:
        if (this.m_bUseInternalPoint)
        {
          num5 += num4 * num1;
          num6 -= num1 * this.m_dGutterSlope;
          break;
        }
        num5 -= num4 * num2;
        num6 -= this.m_dCurbHeight;
        break;
      case CurbForm.CurbOffsetPoint.TopOfCurbEdge:
        if (this.m_bUseInternalPoint)
        {
          num5 += num4 * (num1 + num3);
          num6 += this.m_dCurbHeight - num1 * this.m_dGutterSlope;
          break;
        }
        num5 -= num4 * (num2 - num3);
        break;
      case CurbForm.CurbOffsetPoint.BackOfCurbEdge:
        if (this.m_bUseInternalPoint)
        {
          num5 += num4 * (num1 + num2);
          num6 += this.m_dCurbHeight - num1 * this.m_dGutterSlope;
          break;
        }
        break;
      case CurbForm.CurbOffsetPoint.OuterSubgradeEdge:
        if (this.m_bUseInternalPoint)
        {
          num5 += num4 * (num1 + num2);
          num6 -= this.m_dSubgradeDepth + (num1 + num2) * this.m_dSubgradeSlope;
          break;
        }
        num6 -= this.m_dCurbHeight + this.m_dSubgradeDepth;
        break;
    }
    if (!_bUseDirection)
    {
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation, num5, ref epsPoint);
    }
    else
    {
      Eps_Point Pnt = new Eps_Point();
      RevitGeometry.eplGeoE_FindPntOnLegByStationOffset(this.m_MassLeg, _dStation, 0.0, ref Pnt);
      if (num5 < 0.0)
      {
        num5 = Math.Abs(num5);
        _dDirection = EPShared.eplGeoE_NormalizeRadians(_dDirection + Math.PI);
      }
      EPShared.eplGeoE_CalcPolarToXY(Pnt, _dDirection, num5, ref epsPoint);
    }
    epsPoint.z += num6;
    return epsPoint;
  }

  public FamilySymbol CurbFamilySymbol => this.m_CurbFamilySymbol;

  private enum CurbOffsetPoint
  {
    InnerSubgradeEdge,
    GutterEdge,
    FlowlineEdge,
    TopOfCurbEdge,
    BackOfCurbEdge,
    OuterSubgradeEdge,
  }
}
