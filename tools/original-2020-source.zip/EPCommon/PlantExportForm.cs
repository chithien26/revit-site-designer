﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.PlantExportForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class PlantExportForm : EPForm
{
  private List<FamilyTypeContainer> m_PlantListFamilyTypeList;
  private List<ParameterColumn> m_ParameterList;
  private Document m_Document;
  private IContainer components;
  private TextBox m_ExportFileTextBox;
  private Button m_ExportFileButton;
  private Label m_ExportFileLabel;
  private RadioButton m_TabExportRadioButton;
  private RadioButton m_CommaExportRadioButton;
  private Button m_CancelButton;
  private Button m_OKButton;

  public PlantExportForm(
    Document _Document,
    List<FamilyTypeContainer> _PlantListFamilyTypeList,
    List<ParameterColumn> _ParameterList)
  {
    this.InitializeComponent();
    this.Text = EPShared.LocalRM.GetString("PlantExportDialog");
    this.m_CommaExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_CSVFileDialog");
    this.m_TabExportRadioButton.Text = EPShared.LocalRM.GetString("AMP_TabFileDialog");
    this.m_ExportFileLabel.Text = EPShared.LocalRM.GetString("AMP_FileDialog");
    this.m_OKButton.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_PlantListFamilyTypeList = _PlantListFamilyTypeList;
    this.m_ParameterList = _ParameterList;
    this.m_Document = _Document;
    this.InitializeControls();
  }

  private void InitializeControls()
  {
    int _nReturnValue = 0;
    string empty = string.Empty;
    this.GetDialogPosition();
    this.m_CommaExportRadioButton.Checked = true;
    if (ApplicationUtility.Settings.eplSetE_GetSetting("PlantExportOption", ref _nReturnValue))
    {
      if (_nReturnValue == 0)
        this.m_CommaExportRadioButton.Checked = true;
      else
        this.m_TabExportRadioButton.Checked = true;
    }
    if (!ApplicationUtility.Settings.eplSetE_GetSetting("PlantExportFileName", ref empty))
      return;
    this.m_ExportFileTextBox.Text = empty;
  }

  private void SaveSettings()
  {
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantExportOption", !this.m_CommaExportRadioButton.Checked ? 1 : 0);
    if (!(this.m_ExportFileTextBox.Text != string.Empty))
      return;
    ApplicationUtility.Settings.eplSetE_SetSetting("PlantExportFileName", this.m_ExportFileTextBox.Text);
  }

  private void OnExportFileButtonClick(object sender, EventArgs e)
  {
    SaveFileDialog saveFileDialog = new SaveFileDialog();
    if (this.m_CommaExportRadioButton.Checked)
      saveFileDialog.Filter = ApplicationUtility.GetString("CSVAndTxtFilePickerFilter");
    else
      saveFileDialog.Filter = ApplicationUtility.GetString("TxtFilePickerFilter");
    saveFileDialog.FilterIndex = 1;
    saveFileDialog.RestoreDirectory = true;
    if (saveFileDialog.ShowDialog() != DialogResult.OK)
      return;
    this.m_ExportFileTextBox.Text = saveFileDialog.FileName;
    this.m_ExportFileTextBox.Focus();
  }

  private bool ValidateFields()
  {
    if (string.IsNullOrEmpty(this.m_ExportFileTextBox.Text))
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SpecifyFolderFileNameMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      this.m_ExportFileTextBox.Focus();
      return false;
    }
    string empty = string.Empty;
    string str = !this.m_CommaExportRadioButton.Checked ? ".txt" : ".csv";
    if (this.m_ExportFileTextBox.Text.IndexOf(str) < 0)
    {
      if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
      {
        int length = -1;
        if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
        else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
          length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
        if (Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
        {
          this.m_ExportFileTextBox.Text += str;
        }
        else
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          return false;
        }
      }
      else
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0 || this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
    {
      int length = -1;
      if (this.m_ExportFileTextBox.Text.IndexOf("\\") > 0)
        length = this.m_ExportFileTextBox.Text.LastIndexOf("\\");
      else if (this.m_ExportFileTextBox.Text.IndexOf("/") > 0)
        length = this.m_ExportFileTextBox.Text.LastIndexOf("/");
      if (!Directory.Exists(this.m_ExportFileTextBox.Text.Substring(0, length)))
      {
        int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
        return false;
      }
    }
    else
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("InvalidDirectoryMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      return false;
    }
    return true;
  }

  private void OnOKButtonClick(object sender, EventArgs e)
  {
    if (!this.ValidateFields())
      return;
    this.SaveSettings();
    string empty = string.Empty;
    ImportExport.ExportToFile(this.m_Document, !this.m_CommaExportRadioButton.Checked ? "\t" : ",", this.m_ExportFileTextBox.Text, this.m_PlantListFamilyTypeList, this.m_ParameterList);
    this.DialogResult = DialogResult.OK;
    this.Close();
  }

  private void OnCancelButtonClick(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
    this.Close();
  }

  private void OnPlantExportFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ExportFileTextBox = new TextBox();
    this.m_ExportFileButton = new Button();
    this.m_ExportFileLabel = new Label();
    this.m_TabExportRadioButton = new RadioButton();
    this.m_CommaExportRadioButton = new RadioButton();
    this.m_CancelButton = new Button();
    this.m_OKButton = new Button();
    this.SuspendLayout();
    this.m_ExportFileTextBox.Location = new Point(60, 35);
    this.m_ExportFileTextBox.Name = "m_ExportFileTextBox";
    this.m_ExportFileTextBox.Size = new Size(361, 20);
    this.m_ExportFileTextBox.TabIndex = 3;
    this.m_ExportFileButton.Location = new Point(427, 35);
    this.m_ExportFileButton.Name = "m_ExportFileButton";
    this.m_ExportFileButton.Size = new Size(24, 20);
    this.m_ExportFileButton.TabIndex = 4;
    this.m_ExportFileButton.TabStop = false;
    this.m_ExportFileButton.Text = "...";
    this.m_ExportFileButton.UseVisualStyleBackColor = true;
    this.m_ExportFileButton.Click += new EventHandler(this.OnExportFileButtonClick);
    this.m_ExportFileLabel.AutoSize = true;
    this.m_ExportFileLabel.Location = new Point(12, 38);
    this.m_ExportFileLabel.Name = "m_ExportFileLabel";
    this.m_ExportFileLabel.Size = new Size(26, 13);
    this.m_ExportFileLabel.TabIndex = 2;
    this.m_ExportFileLabel.Text = "Fi&le:";
    this.m_TabExportRadioButton.AutoSize = true;
    this.m_TabExportRadioButton.Location = new Point(243, 12);
    this.m_TabExportRadioButton.Name = "m_TabExportRadioButton";
    this.m_TabExportRadioButton.Size = new Size(139, 17);
    this.m_TabExportRadioButton.TabIndex = 1;
    this.m_TabExportRadioButton.TabStop = true;
    this.m_TabExportRadioButton.Text = "&Tab Delimited (Text File)";
    this.m_TabExportRadioButton.UseVisualStyleBackColor = true;
    this.m_CommaExportRadioButton.AutoSize = true;
    this.m_CommaExportRadioButton.Location = new Point(12, 12);
    this.m_CommaExportRadioButton.Name = "m_CommaExportRadioButton";
    this.m_CommaExportRadioButton.Size = new Size(155, 17);
    this.m_CommaExportRadioButton.TabIndex = 0;
    this.m_CommaExportRadioButton.TabStop = true;
    this.m_CommaExportRadioButton.Text = "&Comma Delimited (Text File)";
    this.m_CommaExportRadioButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Location = new Point(376, 61);
    this.m_CancelButton.Name = "m_CancelButton";
    this.m_CancelButton.Size = new Size(75, 23);
    this.m_CancelButton.TabIndex = 6;
    this.m_CancelButton.Text = "&Cancel";
    this.m_CancelButton.UseVisualStyleBackColor = true;
    this.m_CancelButton.Click += new EventHandler(this.OnCancelButtonClick);
    this.m_OKButton.Location = new Point(295, 61);
    this.m_OKButton.Name = "m_OKButton";
    this.m_OKButton.Size = new Size(75, 23);
    this.m_OKButton.TabIndex = 5;
    this.m_OKButton.Text = "&OK";
    this.m_OKButton.UseVisualStyleBackColor = true;
    this.m_OKButton.Click += new EventHandler(this.OnOKButtonClick);
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(463, 96 /*0x60*/);
    this.Controls.Add((Control) this.m_CancelButton);
    this.Controls.Add((Control) this.m_OKButton);
    this.Controls.Add((Control) this.m_TabExportRadioButton);
    this.Controls.Add((Control) this.m_CommaExportRadioButton);
    this.Controls.Add((Control) this.m_ExportFileTextBox);
    this.Controls.Add((Control) this.m_ExportFileButton);
    this.Controls.Add((Control) this.m_ExportFileLabel);
    this.Name = nameof (PlantExportForm);
    this.Text = "Plant Export";
    this.FormClosing += new FormClosingEventHandler(this.OnPlantExportFormClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_OKButton;
    this.CancelButton = (IButtonControl) this.m_CancelButton;
  }
}
