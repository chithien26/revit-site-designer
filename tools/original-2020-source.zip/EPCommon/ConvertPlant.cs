﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.ConvertPlant
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using SITES.Utilities;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class ConvertPlant
{
  private Document m_Document;
  private List<View> m_ViewList;
  private ConvertPlantForm m_DisplayForm;
  private List<TopographySurfaceContainer> m_SurfaceList;
  private List<FamilyContainer> m_PlantFamilyList;
  private EPTransactionContainer m_TransactionContainer;

  public ConvertPlant(Document _CurDocument)
  {
    this.m_Document = _CurDocument;
    this.m_TransactionContainer = new EPTransactionContainer(this.m_Document);
    this.m_ViewList = new List<View>();
    this.m_SurfaceList = new List<TopographySurfaceContainer>();
    this.m_PlantFamilyList = new List<FamilyContainer>();
    this.InitializeListData();
  }

  public void PopulateFamilyAndSymbolLists() => this.PopulateFamilyAndSymbolLists(false);

  public void PopulateFamilyAndSymbolLists(bool _bCheckForFamily)
  {
    this.m_PlantFamilyList.Clear();
    FilteredElementIterator elementIterator1 = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2001360).GetElementIterator();
    List<Element> list = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilyInstance)).OfCategory((BuiltInCategory) -2001360).ToElements().ToList<Element>();
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("GetFamilyInformationTransaction"));
    Eps_Point _SecondCheckPnt = new Eps_Point();
    elementIterator1.Reset();
    while (elementIterator1.MoveNext())
    {
      if (elementIterator1.Current is FamilySymbol current1 && ((Element) current1).Category != null && ((Element) current1).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode())
      {
        List<Eps_Point> _PointList = (List<Eps_Point>) null;
        foreach (Element element in list)
        {
          if (element is FamilyInstance familyInstance && familyInstance.Symbol != null && ((Element) familyInstance.Symbol).Category != null && ((Element) familyInstance.Symbol).Category.Id.IntegerValue == ((BuiltInCategory) -2001360).GetHashCode() && string.Compare(((Element) current1).UniqueId, ((Element) familyInstance.Symbol).UniqueId, true) == 0)
          {
            if (_PointList == null)
              _PointList = new List<Eps_Point>();
            Eps_Point _FindPoint = new Eps_Point((((Element) familyInstance).Location as LocationPoint).Point);
            if (!RevitUtility.IsPointInPointList(_FindPoint, _PointList))
              _PointList.Add(_FindPoint);
          }
        }
        if (_PointList != null && _PointList.Count > 0)
        {
          bool flag = true;
          while (flag)
          {
            flag = false;
            for (int index = 0; index < _PointList.Count; ++index)
            {
              if (EPShared.eplGeoE_ArePntsDuplicates3D(_PointList[index], _SecondCheckPnt))
              {
                ++_SecondCheckPnt.z;
                flag = true;
                break;
              }
            }
          }
        }
        bool flag1 = false;
        for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
        {
          if (string.Compare(this.m_PlantFamilyList[index].FamilyName, ((Element) current1.Family).Name, true) == 0)
          {
            this.m_PlantFamilyList[index].FamilySymbolList.Add(current1);
            flag1 = true;
            break;
          }
        }
        if (!flag1)
          this.m_PlantFamilyList.Add(new FamilyContainer(((Element) current1.Family).Name)
          {
            FamilySymbolList = {
              current1
            }
          });
      }
    }
    this.m_TransactionContainer.Rollback();
    FilteredElementIterator elementIterator2 = new FilteredElementCollector(this.m_Document).OfClass(typeof (FamilySymbol)).OfCategory((BuiltInCategory) -2005021).GetElementIterator();
    bool flag2 = false;
    elementIterator2.Reset();
    while (elementIterator2.MoveNext())
    {
      if (elementIterator2.Current is FamilySymbol current2 && ((Element) current2).Category != null && ((Element) current2).Category.Id.IntegerValue == ((BuiltInCategory) -2005021).GetHashCode())
      {
        flag2 = true;
        break;
      }
    }
    string empty = string.Empty;
    if (_bCheckForFamily && (this.m_PlantFamilyList.Count == 0 || !flag2))
    {
      WarningOptionsForm warningOptionsForm = new WarningOptionsForm(this.m_Document.PathName, "ConvertPlants", EPShared.LocalRM.GetString("PlantingTagFamiliesNotLoadedMessage"), new List<string>()
      {
        EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"),
        EPShared.LocalRM.GetString("ContinueWOLoadFamiliesOption")
      });
      int num = (int) warningOptionsForm.ShowDialog();
      if (warningOptionsForm.DialogResult == DialogResult.OK && string.Compare(warningOptionsForm.WarningOption, EPShared.LocalRM.GetString("LoadDefaultFamiliesOption"), true) == 0)
      {
        if (this.m_PlantFamilyList.Count == 0)
        {
          Family _Family = (Family) null;
          if (RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Conifer", "LC Conifers.rfa", ref empty))
          {
            this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantFamilyTransaction") + Path.GetFileName(empty));
            RevitUtility.LoadFamily(this.m_Document, empty, out _Family, true, ref this.m_TransactionContainer);
            this.m_TransactionContainer.Commit();
            if (_Family != null && _Family.GetFamilySymbolIds() != null)
            {
              foreach (ElementId familySymbolId in (IEnumerable<ElementId>) _Family.GetFamilySymbolIds())
              {
                if (this.m_Document.GetElement(familySymbolId) is FamilySymbol element)
                {
                  bool flag3 = false;
                  for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
                  {
                    if (string.Compare(this.m_PlantFamilyList[index].FamilyName, ((Element) element.Family).Name, true) == 0)
                    {
                      this.m_PlantFamilyList[index].FamilySymbolList.Add(element);
                      flag3 = true;
                      break;
                    }
                  }
                  if (!flag3)
                    this.m_PlantFamilyList.Add(new FamilyContainer(((Element) element.Family).Name)
                    {
                      FamilySymbolList = {
                        element
                      }
                    });
                }
              }
            }
          }
        }
        if (!flag2 && RevitUtility.GetFullFamilyFilenameIfExist("Planting\\Tags", "LC Plant Tags - Single Line.rfa", ref empty))
        {
          this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("LoadPlantingTagFamilyTransaction") + Path.GetFileName(empty));
          RevitUtility.LoadFamily(this.m_Document, empty, true, ref this.m_TransactionContainer);
          this.m_TransactionContainer.Commit();
        }
      }
    }
    FamilySymbolComparer familySymbolComparer = new FamilySymbolComparer();
    for (int index = 0; index < this.m_PlantFamilyList.Count; ++index)
      this.m_PlantFamilyList[index].FamilySymbolList.Sort((IComparer<FamilySymbol>) familySymbolComparer);
  }

  private void InitializeListData()
  {
    this.PopulateFamilyAndSymbolLists(true);
    foreach (View element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (View)).ToElements())
    {
      if (element.GenLevel != null && !this.m_ViewList.Contains(element) && (element.ViewType == 1 || element.ViewType == 115 || element.ViewType == 116) && string.Compare(((Element) element).Name, EPShared.LocalRM.GetString("SiteString"), true) != 0)
      {
        bool flag = false;
        for (int index = 0; index < this.m_ViewList.Count; ++index)
        {
          if (string.Compare(((Element) this.m_ViewList[index].GenLevel).UniqueId, ((Element) element.GenLevel).UniqueId, true) == 0)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          this.m_ViewList.Add(element);
      }
    }
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_Document).OfClass(typeof (TopographySurface)).OfCategory((BuiltInCategory) -2001340).ToElements())
      this.m_SurfaceList.Add(new TopographySurfaceContainer(this.m_Document.Application, element as TopographySurface));
  }

  public void Run() => this.DisplayUI();

  private bool DisplayUI()
  {
    bool flag = false;
    if (this.m_PlantFamilyList.Count <= 0)
    {
      int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NoFamiliesGenericMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
    }
    DialogResult _DialogResult = DialogResult.OK;
    using (this.m_DisplayForm = new ConvertPlantForm(this))
    {
      while (_DialogResult == DialogResult.OK)
      {
        flag = this.ShowDialog(ref _DialogResult);
        if (flag)
          this.m_TransactionContainer.Commit();
        else
          this.m_TransactionContainer.Rollback();
      }
    }
    return flag;
  }

  private bool GetSinglePoint(ref ElementSet _ArcSet, ref List<Eps_Arc> _ArcList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickCircleMessage"), ref _Elements, true, PickMethod.PickObjects) || _Elements == null || _Elements.Size == 0)
      return false;
    this.m_Document.Regenerate();
    foreach (Element element in _Elements)
    {
      if (element.Location is LocationCurve location)
      {
        Curve curve = location.Curve;
        switch (curve)
        {
          case Arc _:
          case Ellipse _:
            if (!curve.IsBound)
            {
              Eps_Arc _FindArc = (Eps_Arc) null;
              if (curve is Arc)
                _FindArc = new Eps_Arc((Arc) curve);
              else if (curve is Ellipse)
              {
                Ellipse ellipse = (Ellipse) curve;
                _FindArc = new Eps_Arc();
                IList<XYZ> xyzList = ((Curve) ellipse).Tessellate();
                if (xyzList.Count > 0)
                {
                  _FindArc.StartPnt = new Eps_Point(xyzList[0]);
                  _FindArc.EndPnt = new Eps_Point(xyzList[xyzList.Count - 1]);
                }
                _FindArc.RadiusPnt = new Eps_Point(ellipse.Center);
                if (ellipse.Normal.Z > 0.0)
                  _FindArc.Direction = 1;
                else
                  _FindArc.Direction = -1;
                if (ellipse.RadiusX < ellipse.RadiusY)
                  _FindArc.Radius = ellipse.RadiusX;
                else
                  _FindArc.Radius = ellipse.RadiusY;
                _FindArc.Delta = ((Curve) ellipse).Length / _FindArc.Radius;
              }
              if (!RevitUtility.IsArcInArcList(_FindArc, _ArcList))
              {
                _ArcList.Add(_FindArc);
                _ArcSet.Insert(element);
                continue;
              }
              int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("CircleAlreadyPickedMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
              continue;
            }
            break;
        }
        int num1 = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("ObjectNotSupportConvertPlantMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
      }
    }
    return _ArcList != null && _ArcList.Count != 0;
  }

  private bool GetWindowPoints(ref ElementSet _ArcSet, ref List<Eps_Arc> _ArcList)
  {
    ElementSet _Elements = (ElementSet) null;
    if (!RevitUtility.GetElementsFromProject(this.m_Document, EPShared.LocalRM.GetString("PickCircleMessage"), ref _Elements, true, PickMethod.WindowSelect) || _Elements == null || _Elements.Size == 0)
      return false;
    this.m_Document.Regenerate();
    foreach (Element element in _Elements)
    {
      if (element.Location is LocationCurve location)
      {
        Curve curve = location.Curve;
        if ((curve is Arc || curve is Ellipse) && !curve.IsBound)
        {
          Eps_Arc _FindArc = (Eps_Arc) null;
          if (curve is Arc)
            _FindArc = new Eps_Arc((Arc) curve);
          else if (curve is Ellipse)
          {
            Ellipse ellipse = (Ellipse) curve;
            _FindArc = new Eps_Arc();
            IList<XYZ> xyzList = ((Curve) ellipse).Tessellate();
            if (xyzList.Count > 0)
            {
              _FindArc.StartPnt = new Eps_Point(xyzList[0]);
              _FindArc.EndPnt = new Eps_Point(xyzList[xyzList.Count - 1]);
            }
            _FindArc.RadiusPnt = new Eps_Point(ellipse.Center);
            if (ellipse.Normal.Z > 0.0)
              _FindArc.Direction = 1;
            else
              _FindArc.Direction = -1;
            if (ellipse.RadiusX < ellipse.RadiusY)
              _FindArc.Radius = ellipse.RadiusX;
            else
              _FindArc.Radius = ellipse.RadiusY;
            _FindArc.Delta = ((Curve) ellipse).Length / _FindArc.Radius;
          }
          if (!RevitUtility.IsArcInArcList(_FindArc, _ArcList))
          {
            _ArcList.Add(_FindArc);
            _ArcSet.Insert(element);
          }
        }
      }
    }
    return _ArcList != null && _ArcList.Count != 0;
  }

  private bool GetAllPoints(ref ElementSet _ArcSet, ref List<Eps_Arc> _ArcList)
  {
    IList<Element> elements = new FilteredElementCollector(this.m_Document).OfClass(typeof (CurveElement)).OfCategory((BuiltInCategory) -2000051).ToElements();
    if (elements == null || elements.Count == 0)
      return false;
    this.m_Document.Regenerate();
    foreach (Element element in (IEnumerable<Element>) elements)
    {
      if (element.Location is LocationCurve location)
      {
        Curve curve = location.Curve;
        if ((curve is Arc || curve is Ellipse) && !curve.IsBound)
        {
          Eps_Arc _FindArc = (Eps_Arc) null;
          if (curve is Arc)
            _FindArc = new Eps_Arc((Arc) curve);
          else if (curve is Ellipse)
          {
            Ellipse ellipse = (Ellipse) curve;
            _FindArc = new Eps_Arc();
            IList<XYZ> xyzList = ((Curve) ellipse).Tessellate();
            if (xyzList.Count > 0)
            {
              _FindArc.StartPnt = new Eps_Point(xyzList[0]);
              _FindArc.EndPnt = new Eps_Point(xyzList[xyzList.Count - 1]);
            }
            _FindArc.RadiusPnt = new Eps_Point(ellipse.Center);
            if (ellipse.Normal.Z > 0.0)
              _FindArc.Direction = 1;
            else
              _FindArc.Direction = -1;
            if (ellipse.RadiusX < ellipse.RadiusY)
              _FindArc.Radius = ellipse.RadiusX;
            else
              _FindArc.Radius = ellipse.RadiusY;
            _FindArc.Delta = ((Curve) ellipse).Length / _FindArc.Radius;
          }
          if (!RevitUtility.IsArcInArcList(_FindArc, _ArcList))
          {
            _ArcList.Add(_FindArc);
            _ArcSet.Insert(element);
          }
        }
      }
    }
    return _ArcList != null && _ArcList.Count != 0;
  }

  private bool ShowDialog(ref DialogResult _DialogResult)
  {
    int num = (int) this.m_DisplayForm.ShowDialog();
    _DialogResult = this.m_DisplayForm.DialogResult;
    if (_DialogResult != DialogResult.OK)
      return false;
    this.m_TransactionContainer.Start(EPShared.LocalRM.GetString("ConvertPlantsTransaction"));
    ElementSet _ArcSet = new ElementSet();
    List<Eps_Arc> _ArcList = new List<Eps_Arc>();
    if (this.m_DisplayForm.SelectionSetChecked)
    {
      if (!this.GetSinglePoint(ref _ArcSet, ref _ArcList))
        return false;
    }
    else if (this.m_DisplayForm.WindowSelectChecked)
    {
      if (!this.GetWindowPoints(ref _ArcSet, ref _ArcList))
        return false;
    }
    else if (this.m_DisplayForm.AllCirclesChecked && !this.GetAllPoints(ref _ArcSet, ref _ArcList))
      return false;
    bool flag = true;
    ElementSet _FamilyList = new ElementSet();
    ProgressBarForm progressBarForm = new ProgressBarForm();
    progressBarForm.MinValue = 0;
    progressBarForm.MaxValue = _ArcList.Count;
    if (_ArcList.Count <= 0)
      progressBarForm.MaxValue = 10000;
    progressBarForm.Message = EPShared.LocalRM.GetString("ProgressbarConvertingPlantsMessage");
    progressBarForm.ShowForm();
    progressBarForm.Refresh();
    double _dTagSpacing = 0.0;
    this.m_TransactionContainer.BeginTransaction();
    for (int index = 0; index < _ArcList.Count; ++index)
    {
      FamilyInstance familyInstance = RevitUtility.NewFamilyInstance(this.m_Document, _ArcList[index].RadiusPnt.XY, this.m_DisplayForm.Type, RevitUtility.GetSurfaceContainingPoint(_ArcList[index].RadiusPnt, this.m_SurfaceList), this.m_DisplayForm.Level, (StructuralType) 0, ref this.m_TransactionContainer);
      if (2.0 * _ArcList[index].Radius > 0.0 && flag)
      {
        Parameter parameter = ((Element) familyInstance).LookupParameter(RevitParameters.PlantWidthPlantFamilyParameter);
        if (parameter != null)
          parameter.Set(2.0 * _ArcList[index].Radius);
        else
          flag = false;
      }
      if (_dTagSpacing < 4.0 * _ArcList[index].Radius)
        _dTagSpacing = 4.0 * _ArcList[index].Radius;
      _FamilyList.Insert((Element) familyInstance);
      progressBarForm.UpdateProgressBar(1);
    }
    this.m_TransactionContainer.EndTransaction();
    if (this.m_DisplayForm.DeleteExistingChecked)
    {
      this.m_TransactionContainer.BeginTransaction();
      this.m_Document.Delete((ICollection<ElementId>) ElementSetConverter.ToIDList(_ArcSet));
      this.m_TransactionContainer.EndTransaction();
    }
    if (!_FamilyList.IsEmpty)
      PlantCommon.CreateTag(this.m_Document, this.m_TransactionContainer, this.m_DisplayForm.View, _FamilyList, _dTagSpacing, this.m_DisplayForm.PlaceGroupTagChecked, this.m_DisplayForm.LeaderedTagChecked, true);
    progressBarForm.SetMaxValue();
    Thread.Sleep(300);
    progressBarForm.Close();
    return true;
  }

  public ReadOnlyCollection<View> Views
  {
    get => new ReadOnlyCollection<View>((IList<View>) this.m_ViewList);
  }

  public Document Document => this.m_Document;

  public ReadOnlyCollection<FamilyContainer> PlantFamilyList
  {
    get => new ReadOnlyCollection<FamilyContainer>((IList<FamilyContainer>) this.m_PlantFamilyList);
  }

  public EPTransactionContainer TransactionContainer
  {
    get => this.m_TransactionContainer;
    set => this.m_TransactionContainer = value;
  }
}
