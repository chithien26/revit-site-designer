using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace EPCommon;

public class PlantFamilyCreation
{
	private Document m_CurDocument;

	public PlantFamilyCreation(Document _CurDocument)
	{
		m_CurDocument = _CurDocument;
	}

	public void Run()
	{
		DisplayUI();
	}

	private bool DisplayUI()
	{
		using PlantViewForm plantViewForm = new PlantViewForm(m_CurDocument);
		plantViewForm.ShowDialog();
		if (DialogResult.OK != plantViewForm.DialogResult)
		{
			return false;
		}
		return true;
	}
}
