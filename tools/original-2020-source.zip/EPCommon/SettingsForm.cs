﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.SettingsForm
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class SettingsForm : EPForm
{
  private Units m_Units;
  private const UnitType m_LengthUnitType = (UnitType) 0;
  private const UnitType m_SlopeUnitType = (UnitType) 59;
  private const UnitType m_AngularUnitType = (UnitType) 3;
  private Document m_CurrentDocument;
  private RevitProduct m_CurrentProduct = RevitProduct.SITES;
  private QuantumListView m_GlobalListView;
  private List<string> m_ParameterList = new List<string>();
  private List<string> m_ParametersStringList = new List<string>();
  private List<string> m_ParametersValueList = new List<string>();
  private List<string> m_TabList = new List<string>();
  private QuantumListView m_ParameterListView;
  private DecimalSymbol m_DecimalSymbolType;
  private FormatOptions m_FormatOptions;
  private UnitSymbolType m_UnitSymbolType;
  private DisplayUnit m_DisplayUnitSystem;
  private List<string> m_Fields = new List<string>();
  private List<string> m_Values = new List<string>();
  private List<Material> m_AllMaterialList = new List<Material>();
  private IContainer components;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;
  private TabControl m_SettingsTabControl;
  private Panel m_Panel;

  public SettingsForm(Document _CurrentDocument, RevitProduct _nProductType)
  {
    this.m_CurrentDocument = _CurrentDocument;
    this.m_CurrentProduct = _nProductType;
    this.m_DecimalSymbolType = this.m_CurrentDocument.GetUnits().DecimalSymbol;
    this.m_DisplayUnitSystem = this.m_CurrentDocument.DisplayUnitSystem;
    this.m_FormatOptions = this.m_CurrentDocument.GetUnits().GetFormatOptions((UnitType) 0);
    this.ContextualHelpID = "HID_SDsettings";
    this.m_Units = _CurrentDocument.GetUnits();
    try
    {
      this.m_UnitSymbolType = this.m_FormatOptions.UnitSymbol;
    }
    catch (InvalidOperationException ex)
    {
      this.m_UnitSymbolType = (UnitSymbolType) 0;
    }
    this.InitializeComponent();
    this.InitializeData();
    this.FormClosing += new FormClosingEventHandler(this.OnSettingsFormClosing);
    this.ResizeBegin += new EventHandler(this.FormResizeBegin);
  }

  private void InitializeData()
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    if (this.m_CurrentProduct == RevitProduct.SITES)
    {
      this.m_ParametersStringList.Add("MassTemplateFileName");
      string str1 = this.GetStringSetting("MassTemplateFileName");
      if (str1 == string.Empty)
      {
        RevitUtility.FindMassTemplateFileName(this.m_CurrentDocument, LandcaddID.SoftTerrain, ref empty2, false);
        str1 = empty2;
      }
      this.m_ParametersValueList.Add(str1);
      empty1 = string.Empty;
      empty2 = string.Empty;
      this.m_ParametersStringList.Add("CurbMassTemplateFileName");
      string str2 = this.GetStringSetting("CurbMassTemplateFileName");
      if (str2 == string.Empty)
      {
        RevitUtility.FindMassTemplateFileName(this.m_CurrentDocument, LandcaddID.Curb, ref empty2, false);
        str2 = empty2;
      }
      this.m_ParametersValueList.Add(str2);
      empty1 = string.Empty;
      empty2 = string.Empty;
      this.m_ParametersStringList.Add("RetainingWallMassTemplateFileName");
      string str3 = this.GetStringSetting("RetainingWallMassTemplateFileName");
      if (str3 == string.Empty)
      {
        RevitUtility.FindMassTemplateFileName(this.m_CurrentDocument, LandcaddID.RetainingWall, ref empty2, false);
        str3 = empty2;
      }
      this.m_ParametersValueList.Add(str3);
      empty1 = string.Empty;
      empty2 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkMassTemplateFileName");
      string str4 = this.GetStringSetting("SidewalkMassTemplateFileName");
      if (str4 == string.Empty)
      {
        RevitUtility.FindMassTemplateFileName(this.m_CurrentDocument, LandcaddID.Sidewalk, ref empty2, false);
        str4 = empty2;
      }
      this.m_ParametersValueList.Add(str4);
      empty1 = string.Empty;
      empty2 = string.Empty;
      this.m_ParametersStringList.Add("StreetMassTemplateFileName");
      string str5 = this.GetStringSetting("StreetMassTemplateFileName");
      if (str5 == string.Empty)
      {
        RevitUtility.FindMassTemplateFileName(this.m_CurrentDocument, LandcaddID.Street, ref empty2, false);
        str5 = empty2;
      }
      this.m_ParametersValueList.Add(str5);
      empty1 = string.Empty;
      empty2 = string.Empty;
      this.m_ParametersStringList.Add("MassCreationOnlyMode");
      string str6 = this.GetIntSetting("MassCreationOnlyMode");
      if (str6 == string.Empty)
        str6 = "0";
      this.m_ParametersValueList.Add(str6);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("CurbMassSubCategoryName");
      string stringSetting1 = this.GetStringSetting("CurbMassSubCategoryName");
      if (stringSetting1 == string.Empty)
        stringSetting1 = EPShared.LocalRM.GetString("SWCurbLineNameString");
      this.m_ParametersValueList.Add(stringSetting1);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("RetainingWallMassSubCategoryName");
      string stringSetting2 = this.GetStringSetting("RetainingWallMassSubCategoryName");
      if (stringSetting2 == string.Empty)
        stringSetting2 = EPShared.LocalRM.GetString("SWRetainingWallLineNameString");
      this.m_ParametersValueList.Add(stringSetting2);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkMassSubCategoryName");
      string stringSetting3 = this.GetStringSetting("SidewalkMassSubCategoryName");
      if (stringSetting3 == string.Empty)
        stringSetting3 = EPShared.LocalRM.GetString("SWSidewalkLineNameString");
      this.m_ParametersValueList.Add(stringSetting3);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("StreetMassSubCategoryName");
      string stringSetting4 = this.GetStringSetting("StreetMassSubCategoryName");
      if (stringSetting4 == string.Empty)
        stringSetting4 = EPShared.LocalRM.GetString("SWStreetLineNameString");
      this.m_ParametersValueList.Add(stringSetting4);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("CurbLineSubCategoryName");
      string stringSetting5 = this.GetStringSetting("CurbLineSubCategoryName");
      if (stringSetting5 == string.Empty)
        stringSetting5 = EPShared.LocalRM.GetString("SWCurbLineNameString");
      this.m_ParametersValueList.Add(stringSetting5);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("CurbLineSubCategoryColor");
      string str7 = this.GetStringSetting("CurbLineSubCategoryColor");
      if (str7 == string.Empty)
        str7 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str7);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("CurbLineSubCategoryLineWeight");
      string str8 = this.GetIntSetting("CurbLineSubCategoryLineWeight");
      if (str8 == string.Empty)
        str8 = "1";
      this.m_ParametersValueList.Add(str8);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("FeatureLineLineSubCategoryName");
      string stringSetting6 = this.GetStringSetting("FeatureLineLineSubCategoryName");
      if (stringSetting6 == string.Empty)
        stringSetting6 = EPShared.LocalRM.GetString("SWFeatureLineLineNameString");
      this.m_ParametersValueList.Add(stringSetting6);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("FeatureLineLineSubCategoryColor");
      string str9 = this.GetStringSetting("FeatureLineLineSubCategoryColor");
      if (str9 == string.Empty)
        str9 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str9);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("FeatureLineLineSubCategoryLineWeight");
      string str10 = this.GetIntSetting("FeatureLineLineSubCategoryLineWeight");
      if (str10 == string.Empty)
        str10 = "1";
      this.m_ParametersValueList.Add(str10);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("ParkingLotLineSubCategoryName");
      string stringSetting7 = this.GetStringSetting("ParkingLotLineSubCategoryName");
      if (stringSetting7 == string.Empty)
        stringSetting7 = EPShared.LocalRM.GetString("SWParkingLotLineNameString");
      this.m_ParametersValueList.Add(stringSetting7);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("ParkingLotLineSubCategoryColor");
      string str11 = this.GetStringSetting("ParkingLotLineSubCategoryColor");
      if (str11 == string.Empty)
        str11 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str11);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("ParkingLotLineSubCategoryLineWeight");
      string str12 = this.GetIntSetting("ParkingLotLineSubCategoryLineWeight");
      if (str12 == string.Empty)
        str12 = "1";
      this.m_ParametersValueList.Add(str12);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("PointWipeoutLineSubCategoryName");
      string stringSetting8 = this.GetStringSetting("PointWipeoutLineSubCategoryName");
      if (stringSetting8 == string.Empty)
        stringSetting8 = EPShared.LocalRM.GetString("SWPointWipeoutLineNameString");
      this.m_ParametersValueList.Add(stringSetting8);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("PointWipeoutLineSubCategoryColor");
      string str13 = this.GetStringSetting("PointWipeoutLineSubCategoryColor");
      if (str13 == string.Empty)
        str13 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str13);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("PointWipeoutLineSubCategoryLineWeight");
      string str14 = this.GetIntSetting("PointWipeoutLineSubCategoryLineWeight");
      if (str14 == string.Empty)
        str14 = "1";
      this.m_ParametersValueList.Add(str14);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("RetainingWallLineSubCategoryName");
      string stringSetting9 = this.GetStringSetting("RetainingWallLineSubCategoryName");
      if (stringSetting9 == string.Empty)
        stringSetting9 = EPShared.LocalRM.GetString("SWRetainingWallLineNameString");
      this.m_ParametersValueList.Add(stringSetting9);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("RetainingWallLineSubCategoryColor");
      string str15 = this.GetStringSetting("RetainingWallLineSubCategoryColor");
      if (str15 == string.Empty)
        str15 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str15);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("RetainingWallLineSubCategoryLineWeight");
      string str16 = this.GetIntSetting("RetainingWallLineSubCategoryLineWeight");
      if (str16 == string.Empty)
        str16 = "1";
      this.m_ParametersValueList.Add(str16);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkLineSubCategoryName");
      string stringSetting10 = this.GetStringSetting("SidewalkLineSubCategoryName");
      if (stringSetting10 == string.Empty)
        stringSetting10 = EPShared.LocalRM.GetString("SWSidewalkLineNameString");
      this.m_ParametersValueList.Add(stringSetting10);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkLineSubCategoryColor");
      string str17 = this.GetStringSetting("SidewalkLineSubCategoryColor");
      if (str17 == string.Empty)
        str17 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str17);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkLineSubCategoryLineWeight");
      string str18 = this.GetIntSetting("SidewalkLineSubCategoryLineWeight");
      if (str18 == string.Empty)
        str18 = "1";
      this.m_ParametersValueList.Add(str18);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SoftTerrainLineSubCategoryName");
      string stringSetting11 = this.GetStringSetting("SoftTerrainLineSubCategoryName");
      if (stringSetting11 == string.Empty)
        stringSetting11 = EPShared.LocalRM.GetString("SWSoftTerrainLineNameString");
      this.m_ParametersValueList.Add(stringSetting11);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SoftTerrainLineSubCategoryColor");
      string str19 = this.GetStringSetting("SoftTerrainLineSubCategoryColor");
      if (str19 == string.Empty)
        str19 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str19);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SoftTerrainLineSubCategoryLineWeight");
      string str20 = this.GetIntSetting("SoftTerrainLineSubCategoryLineWeight");
      if (str20 == string.Empty)
        str20 = "1";
      this.m_ParametersValueList.Add(str20);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("StreetLineSubCategoryName");
      string stringSetting12 = this.GetStringSetting("StreetLineSubCategoryName");
      if (stringSetting12 == string.Empty)
        stringSetting12 = EPShared.LocalRM.GetString("SWStreetLineNameString");
      this.m_ParametersValueList.Add(stringSetting12);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("StreetLineSubCategoryColor");
      string str21 = this.GetStringSetting("StreetLineSubCategoryColor");
      if (str21 == string.Empty)
        str21 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("DefaultLineColor")}";
      this.m_ParametersValueList.Add(str21);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("StreetLineSubCategoryLineWeight");
      string str22 = this.GetIntSetting("StreetLineSubCategoryLineWeight");
      if (str22 == string.Empty)
        str22 = "1";
      this.m_ParametersValueList.Add(str22);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("IntersectionLineSubCategoryName");
      string stringSetting13 = this.GetStringSetting("IntersectionLineSubCategoryName");
      if (stringSetting13 == string.Empty)
        stringSetting13 = EPShared.LocalRM.GetString("SWIntersectionLineNameString");
      this.m_ParametersValueList.Add(stringSetting13);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("IntersectionLineSubCategoryColor");
      string str23 = this.GetStringSetting("IntersectionLineSubCategoryColor");
      if (str23 == string.Empty)
        str23 = $"{EPShared.LocalRM.GetString("RGBString")} {ApplicationUtility.GetString("RedLineColor")}";
      this.m_ParametersValueList.Add(str23);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("IntersectionLineSubCategoryLineWeight");
      string str24 = this.GetIntSetting("IntersectionLineSubCategoryLineWeight");
      if (str24 == string.Empty)
        str24 = "3";
      this.m_ParametersValueList.Add(str24);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("TopographySurfaceArcPointInterval");
      string str25 = this.GetDoubleSetting("TopographySurfaceArcPointInterval");
      if (str25 == string.Empty)
        str25 = "1.0";
      this.m_ParametersValueList.Add(str25);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("ProposedToposurfaceMaterialParameter");
      string str26 = this.GetProjectIntSetting("ProposedToposurfaceMaterialParameter");
      if (str26 == string.Empty)
        str26 = "0";
      this.m_ParametersValueList.Add(str26);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("ParkingLotIslandToposurfaceMaterialParameter");
      string str27 = this.GetProjectIntSetting("ParkingLotIslandToposurfaceMaterialParameter");
      if (str27 == string.Empty)
        str27 = "0";
      this.m_ParametersValueList.Add(str27);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SiteComponentPromptForStartingSide");
      string str28 = this.GetIntSetting("SiteComponentPromptForStartingSide");
      if (str28 == string.Empty)
        str28 = "0";
      this.m_ParametersValueList.Add(str28);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("UseSharedElevation");
      string str29 = this.GetProjectIntSetting("UseSharedElevation");
      if (str29 == string.Empty)
        str29 = "0";
      this.m_ParametersValueList.Add(str29);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("StreetIntersectionDefaultRadius");
      string str30 = this.GetDoubleSetting("StreetIntersectionDefaultRadius");
      if (str30 == string.Empty)
        str30 = "5.0";
      this.m_ParametersValueList.Add(str30);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkIntersectionDefaultRadius");
      string str31 = this.GetDoubleSetting("SidewalkIntersectionDefaultRadius");
      if (str31 == string.Empty)
        str31 = "5.0";
      this.m_ParametersValueList.Add(str31);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("StreetIntersectionDefaultTransitioningDistance");
      string str32 = this.GetDoubleSetting("StreetIntersectionDefaultTransitioningDistance");
      if (str32 == string.Empty)
        str32 = "10.0";
      this.m_ParametersValueList.Add(str32);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("SidewalkIntersectionDefaultTransitioningDistance");
      string str33 = this.GetDoubleSetting("SidewalkIntersectionDefaultTransitioningDistance");
      if (str33 == string.Empty)
        str33 = "10.0";
      this.m_ParametersValueList.Add(str33);
      empty1 = string.Empty;
    }
    else if (this.m_CurrentProduct == RevitProduct.LANDCADD)
    {
      this.m_ParametersStringList.Add("PlantingTemplateFileName");
      string str34 = this.GetStringSetting("PlantingTemplateFileName");
      if (str34 == string.Empty)
      {
        ManagePlants.FindTemplateFileName(this.m_CurrentDocument, ref empty2, false);
        str34 = empty2;
      }
      this.m_ParametersValueList.Add(str34);
      empty1 = string.Empty;
      string empty3 = string.Empty;
      this.m_ParametersStringList.Add("GenericTemplateFileName");
      string str35 = this.GetStringSetting("GenericTemplateFileName");
      if (str35 == string.Empty)
      {
        ManagePlants.FindMixTemplateFileName(this.m_CurrentDocument, ref empty3, false);
        str35 = empty3;
      }
      this.m_ParametersValueList.Add(str35);
      empty1 = string.Empty;
      string empty4 = string.Empty;
      this.m_ParametersStringList.Add("LANDCADDUpdaterCall");
      string str36 = this.GetIntSetting("LANDCADDUpdaterCall");
      if (str36 == string.Empty)
        str36 = "1";
      this.m_ParametersValueList.Add(str36);
      empty1 = string.Empty;
      this.m_ParametersStringList.Add("DisplaySharedParamaterWarningString");
      string intSetting = this.GetIntSetting("MissingSharedParametersDoNotShowAgainOption");
      this.m_ParametersValueList.Add(!(intSetting == string.Empty) ? (Convert.ToInt32(intSetting) != 1 ? "1" : "0") : "1");
      empty1 = string.Empty;
    }
    this.m_ParametersStringList.Add("CheckForUpdateNotification");
    string intSetting1 = this.GetIntSetting("CheckForUpdateNotificationDoNotShowAgainOption");
    this.m_ParametersValueList.Add(!(intSetting1 == string.Empty) ? (Convert.ToInt32(intSetting1) != 1 ? "1" : "0") : "1");
    empty1 = string.Empty;
    this.m_ParametersStringList.Add("LibraryPath");
    string stringSetting14 = this.GetStringSetting("LibraryPath");
    if (stringSetting14 == string.Empty)
      ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref stringSetting14);
    this.m_ParametersValueList.Add(stringSetting14);
    empty1 = string.Empty;
    this.m_ParametersStringList.Add("SamplePath");
    string stringSetting15 = this.GetStringSetting("SamplePath");
    if (stringSetting15 == string.Empty)
      ApplicationUtility.RegistryPaths.GetSamplePath(string.Empty, ref stringSetting15);
    this.m_ParametersValueList.Add(stringSetting15);
    empty1 = string.Empty;
    string str = string.Empty;
    switch (this.m_CurrentProduct)
    {
      case RevitProduct.LANDCADD:
        str = $"{EPShared.LocalRM.GetString("LandcaddRibbonTab")} {EPShared.LocalRM.GetString("SettingRibbonButton")}";
        break;
      case RevitProduct.SITES:
        str = $"{EPShared.LocalRM.GetString("LandcaddSitesRibbonTab")} {EPShared.LocalRM.GetString("SettingRibbonButton")}";
        break;
    }
    this.Text = str;
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.GetDialogPosition();
    this.SetupTabControl();
  }

  private string GetStringSetting(string _strSettingName)
  {
    string empty = string.Empty;
    ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingName, ref empty);
    return empty;
  }

  private string GetIntSetting(string _strSettingName)
  {
    int _nReturnValue = 0;
    return ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingName, ref _nReturnValue) ? Convert.ToString(_nReturnValue) : string.Empty;
  }

  private string GetProjectIntSetting(string _strSettingName)
  {
    int _nReturnValue = 0;
    return ApplicationUtility.Settings.eplSetE_GetSetting(this.m_CurrentDocument.PathName, _strSettingName, ref _nReturnValue) ? Convert.ToString(_nReturnValue) : string.Empty;
  }

  private string GetDoubleSetting(string _strSettingName)
  {
    double _dReturnValue = 0.0;
    return ApplicationUtility.Settings.eplSetE_GetSetting(_strSettingName, ref _dReturnValue) ? Convert.ToString(_dReturnValue) : string.Empty;
  }

  private void SetupTabControl()
  {
    this.SetupParameterListTabList();
    this.m_GlobalListView = new QuantumListView();
    this.m_SettingsTabControl.SelectedIndex = 0;
    this.m_SettingsTabControl.TabIndex = 0;
    this.SetupSettingsDlg();
    this.SetupGlobalListViewInfoForAdd();
    this.m_SettingsTabControl.TabPages.Clear();
    int num = 0;
    foreach (string tab in this.m_TabList)
    {
      this.m_SettingsTabControl.TabPages.Add(tab);
      this.m_SettingsTabControl.TabPages[num++].AutoScroll = true;
    }
    this.SetupSettingsViewInfo(this.m_SettingsTabControl.TabPages[0].Text);
  }

  private void SetupSettingsDlg()
  {
    int width = this.Width;
    int height = this.Height;
    if (Environment.OSVersion.Version.Major == 5)
    {
      height -= 95;
      width -= 30;
    }
    else if (Environment.OSVersion.Version.Major == 6)
    {
      if (Environment.OSVersion.Version.Minor == 0)
      {
        height -= 95;
        width -= 35;
      }
      else
      {
        height -= 110;
        width -= 35;
      }
    }
    this.m_ParameterListView = new QuantumListView(width, height);
    this.m_ParameterListView.View = View.Details;
    this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
    this.m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
    this.m_ParameterListView.Columns[0].Width = width / 2;
    this.m_ParameterListView.Columns[1].Width = width / 2;
    this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("NoString"));
    this.m_ParameterListView.CmbBox.Items.Add((object) EPShared.LocalRM.GetString("YesString"));
    foreach (Element element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (Material)).OfCategory((BuiltInCategory) -2000700).ToElements())
    {
      if (element != null && element is Material material)
      {
        this.m_ParameterListView.MaterialCmbBox.Items.Add((object) ((Element) material).Name);
        this.m_AllMaterialList.Add(material);
      }
    }
    this.m_SettingsTabControl.Location = new Point(3, 3);
  }

  private void SetupGlobalListViewInfoForAdd()
  {
    string empty = string.Empty;
    ListViewItem listViewItem1 = new ListViewItem();
    List<string> stringList = new List<string>();
    if (this.m_CurrentProduct == RevitProduct.LANDCADD)
    {
      stringList.Add(EPShared.LocalRM.GetString("PlantingTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("GenericTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("DisplaySharedParamaterWarningString"));
      stringList.Add(EPShared.LocalRM.GetString("LANDCADDUpdaterCall"));
    }
    else if (this.m_CurrentProduct == RevitProduct.SITES)
    {
      stringList.Add(EPShared.LocalRM.GetString("MassTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("CurbMassTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("RetainingWallMassTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkMassTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("StreetMassTemplateFileNameString"));
      stringList.Add(EPShared.LocalRM.GetString("MassCreationOnlyMode"));
      stringList.Add(EPShared.LocalRM.GetString("CurbMassSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("RetainingWallMassSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkMassSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("StreetMassSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("CurbLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("CurbLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("CurbLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("StreetLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("StreetLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("StreetLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("IntersectionLineSubCategoryName"));
      stringList.Add(EPShared.LocalRM.GetString("IntersectionLineSubCategoryColor"));
      stringList.Add(EPShared.LocalRM.GetString("IntersectionLineSubCategoryLineWeight"));
      stringList.Add(EPShared.LocalRM.GetString("TopographySurfaceArcPointInterval"));
      stringList.Add(EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"));
      stringList.Add(EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"));
      stringList.Add(EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"));
      stringList.Add(EPShared.LocalRM.GetString("UseSharedElevation"));
      stringList.Add(EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"));
      stringList.Add(EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"));
      stringList.Add(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"));
    }
    stringList.Add(EPShared.LocalRM.GetString("CheckForUpdateNotification"));
    stringList.Add(EPShared.LocalRM.GetString("LibraryPath"));
    stringList.Add(EPShared.LocalRM.GetString("SamplePath"));
    for (int index = 0; index < stringList.Count; ++index)
    {
      string str = stringList[index];
      string _strToDisplay = this.m_ParametersValueList[index];
      if (this.m_CurrentProduct == RevitProduct.SITES)
      {
        if (string.Compare(stringList[index], EPShared.LocalRM.GetString("TopographySurfaceArcPointInterval"), true) == 0)
        {
          double _dConvertedDouble = 12.0;
          if (_strToDisplay != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
        }
        else if (string.Compare(stringList[index], EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"), true) == 0 || string.Compare(stringList[index], EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"), true) == 0 || string.Compare(stringList[index], EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"), true) == 0 || string.Compare(stringList[index], EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"), true) == 0)
        {
          double _dConvertedDouble = 0.0;
          if (_strToDisplay != string.Empty)
            _dConvertedDouble = ValueConversion.ToDouble(_strToDisplay);
          RevitGeometry.Units_ConvertDoubleToString(_dConvertedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
        }
        else if (string.Compare(stringList[index], EPShared.LocalRM.GetString("MassCreationOnlyMode"), true) == 0 || string.Compare(stringList[index], EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"), true) == 0 || string.Compare(stringList[index], EPShared.LocalRM.GetString("UseSharedElevation"), true) == 0)
          _strToDisplay = string.Compare(_strToDisplay, "1", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("YesString");
        else if (string.Compare(stringList[index], EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"), true) == 0 || string.Compare(stringList[index], EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"), true) == 0)
        {
          int nMaterialToFind = Convert.ToInt32(_strToDisplay);
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => ((Element) SelectedMaterial).Id.IntegerValue == nMaterialToFind)).ToList<Material>();
          _strToDisplay = list.Count < 1 ? "Default" : ((Element) list.ElementAt<Material>(0)).Name;
        }
      }
      else if (this.m_CurrentProduct == RevitProduct.LANDCADD)
      {
        if (string.Compare(stringList[index], EPShared.LocalRM.GetString("LANDCADDUpdaterCall"), true) == 0)
          _strToDisplay = string.Compare(_strToDisplay, "1", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("YesString");
        else if (string.Compare(stringList[index], EPShared.LocalRM.GetString("DisplaySharedParamaterWarningString"), true) == 0)
          _strToDisplay = string.Compare(_strToDisplay, "1", true) != 0 ? EPShared.LocalRM.GetString("YesString") : EPShared.LocalRM.GetString("NoString");
      }
      if (string.Compare(stringList[index], EPShared.LocalRM.GetString("CheckForUpdateNotification"), true) == 0)
        _strToDisplay = string.Compare(_strToDisplay, "1", true) != 0 ? EPShared.LocalRM.GetString("NoString") : EPShared.LocalRM.GetString("YesString");
      ListViewItem listViewItem2 = this.m_GlobalListView.Items.Add(str, str, string.Empty);
      listViewItem2.SubItems.Add(_strToDisplay);
      listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = _strToDisplay;
    }
  }

  private void SetupParameterListTabList()
  {
    this.m_TabList.Clear();
    if (this.m_CurrentProduct == RevitProduct.LANDCADD)
    {
      this.m_TabList.Add(EPShared.LocalRM.GetString("TemplatesString"));
      this.m_TabList.Add(EPShared.LocalRM.GetString("GeneralString"));
    }
    else
    {
      if (this.m_CurrentProduct != RevitProduct.SITES)
        return;
      this.m_TabList.Add(EPShared.LocalRM.GetString("GeneralString"));
      if (ApplicationUtility.UseMass)
      {
        this.m_TabList.Add(EPShared.LocalRM.GetString("MassTemplatesString"));
        this.m_TabList.Add(EPShared.LocalRM.GetString("MassCreationString"));
      }
      this.m_TabList.Add(EPShared.LocalRM.GetString("SiteComponentLineCreationString"));
    }
  }

  private void SetupSettingsViewInfo(string _strCurrentTabText)
  {
    this.UpdateGlobalListView();
    if (this.m_SettingsTabControl.SelectedTab.Controls.Count > 0)
      this.m_SettingsTabControl.SelectedTab.Controls.RemoveAt(0);
    this.m_ParameterList.Clear();
    if (this.m_CurrentProduct == RevitProduct.LANDCADD)
    {
      if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("TemplatesString"), true) == 0)
      {
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("PlantingTemplateFileNameString"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("GenericTemplateFileNameString"));
      }
      else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("GeneralString"), true) == 0)
      {
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("DisplaySharedParamaterWarningString"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("LANDCADDUpdaterCall"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CheckForUpdateNotification"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("LibraryPath"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SamplePath"));
      }
    }
    else if (this.m_CurrentProduct == RevitProduct.SITES)
    {
      if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("MassTemplatesString"), true) == 0)
      {
        this.ContextualHelpID = "HID_SDsettingsMassTemplates";
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("MassTemplateFileNameString"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CurbMassTemplateFileNameString"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("RetainingWallMassTemplateFileNameString"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkMassTemplateFileNameString"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetMassTemplateFileNameString"));
      }
      else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("MassCreationString"), true) == 0)
      {
        this.ContextualHelpID = "HID_SDsettingsMassCreation";
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("MassCreationOnlyMode"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CurbMassSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("RetainingWallMassSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkMassSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetMassSubCategoryName"));
      }
      else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("SiteComponentLineCreationString"), true) == 0)
      {
        this.ContextualHelpID = "HID_SDsettingsLineCreation";
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CurbLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CurbLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CurbLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetLineSubCategoryLineWeight"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("IntersectionLineSubCategoryName"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("IntersectionLineSubCategoryColor"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("IntersectionLineSubCategoryLineWeight"));
      }
      else if (string.Compare(_strCurrentTabText, EPShared.LocalRM.GetString("GeneralString"), true) == 0)
      {
        this.ContextualHelpID = "HID_SDsettingsGeneral";
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("TopographySurfaceArcPointInterval"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("UseSharedElevation"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("CheckForUpdateNotification"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("LibraryPath"));
        this.m_ParameterList.Add(EPShared.LocalRM.GetString("SamplePath"));
      }
    }
    this.m_ParameterListView.Items.Clear();
    this.m_ParameterListView.RefreshListView();
    this.m_ParameterListView.OnListViewItemChanged += new ListViewItemChanged(this.ParameterListViewOnListViewItemChanged);
    string empty = string.Empty;
    ListViewItem listViewItem1 = new ListViewItem();
    for (int index = 0; index < this.m_ParameterList.Count; ++index)
    {
      string parameter = this.m_ParameterList[index];
      string _strToDisplay = this.GetListViewValue(parameter);
      if (this.m_CurrentProduct == RevitProduct.SITES)
      {
        if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("TopographySurfaceArcPointInterval"), true) == 0)
        {
          double _dReturnedDouble = 1.0;
          if (_strToDisplay != string.Empty)
            RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
        }
        else if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"), true) == 0 || string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"), true) == 0 || string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"), true) == 0 || string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"), true) == 0)
        {
          double _dReturnedDouble = 0.0;
          if (_strToDisplay != string.Empty)
            RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref _strToDisplay);
        }
        else if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("MassCreationOnlyMode"), true) == 0 || string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"), true) == 0 || string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("UseSharedElevation"), true) == 0)
        {
          if (string.Compare(_strToDisplay, "1", true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("YesString");
          else if (string.Compare(_strToDisplay, "0", true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("NoString");
          else if (_strToDisplay == string.Empty)
            _strToDisplay = EPShared.LocalRM.GetString("NoString");
        }
        else if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"), true) == 0 || string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"), true) == 0)
        {
          if (_strToDisplay == string.Empty)
            _strToDisplay = "Default";
          string strStringToFind = _strToDisplay;
          List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, true) == 0)).ToList<Material>();
          _strToDisplay = list.Count < 1 ? string.Empty : ((Element) list.ElementAt<Material>(0)).Name;
        }
      }
      else if (this.m_CurrentProduct == RevitProduct.LANDCADD)
      {
        if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("DisplaySharedParamaterWarningString"), true) == 0)
        {
          if (string.Compare(_strToDisplay, "1", true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("YesString");
          else if (string.Compare(_strToDisplay, "0", true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("NoString");
          else if (_strToDisplay == string.Empty)
            _strToDisplay = EPShared.LocalRM.GetString("YesString");
        }
        if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("LANDCADDUpdaterCall"), true) == 0)
        {
          if (string.Compare(_strToDisplay, "1", true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("YesString");
          else if (string.Compare(_strToDisplay, "0", true) == 0)
            _strToDisplay = EPShared.LocalRM.GetString("NoString");
          else if (_strToDisplay == string.Empty)
            _strToDisplay = EPShared.LocalRM.GetString("YesString");
        }
      }
      if (string.Compare(this.m_ParameterList[index], EPShared.LocalRM.GetString("CheckForUpdateNotification"), true) == 0)
      {
        if (string.Compare(_strToDisplay, "1", true) == 0 || _strToDisplay == string.Empty)
          _strToDisplay = EPShared.LocalRM.GetString("YesString");
        else if (string.Compare(_strToDisplay, "0", true) == 0)
          _strToDisplay = EPShared.LocalRM.GetString("NoString");
      }
      ListViewItem listViewItem2 = this.m_ParameterListView.Items.Add(parameter, parameter, string.Empty);
      listViewItem2.SubItems.Add(_strToDisplay);
      listViewItem2.SubItems[listViewItem2.SubItems.Count - 1].Text = _strToDisplay;
    }
    this.m_SettingsTabControl.SelectedTab.Controls.AddRange(new Control[1]
    {
      (Control) this.m_ParameterListView
    });
  }

  private string GetListViewValue(string _strParameterName)
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index = 0; index < this.m_GlobalListView.Items.Count; ++index)
    {
      string text1 = this.m_GlobalListView.Items[index].SubItems[0].Text;
      string text2 = this.m_GlobalListView.Items[index].SubItems[1].Text;
      if (string.Compare(text1, _strParameterName, true) == 0)
        return text2;
    }
    return string.Empty;
  }

  private void UpdateGlobalListView()
  {
    if (this.m_ParameterListView == null)
      return;
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index1 = 0; index1 < this.m_ParameterListView.Items.Count; ++index1)
    {
      string text1 = this.m_ParameterListView.Items[index1].SubItems[0].Text;
      string text2 = this.m_ParameterListView.Items[index1].SubItems[1].Text;
      for (int index2 = 0; index2 < this.m_GlobalListView.Items.Count; ++index2)
      {
        if (string.Compare(this.m_GlobalListView.Items[index2].SubItems[0].Text, text1, false) == 0)
        {
          this.m_GlobalListView.Items[index2].SubItems[1].Text = text2;
          break;
        }
      }
    }
  }

  private void UpdateCurrentTabListView()
  {
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index1 = 0; index1 < this.m_GlobalListView.Items.Count; ++index1)
    {
      string text1 = this.m_GlobalListView.Items[index1].SubItems[0].Text;
      string text2 = this.m_GlobalListView.Items[index1].SubItems[1].Text;
      for (int index2 = 0; index2 < this.m_ParameterListView.Items.Count; ++index2)
      {
        if (string.Compare(this.m_ParameterListView.Items[index2].SubItems[0].Text, text1, false) == 0)
        {
          this.m_ParameterListView.Items[index2].SubItems[1].Text = text2;
          break;
        }
      }
    }
  }

  private void StreetTabControlTabIndexChanged(object sender, EventArgs e)
  {
    this.SetupSettingsViewInfo(this.m_SettingsTabControl.SelectedTab.Text);
    this.UpdateCurrentTabListView();
  }

  private void OnSettingsFormClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  private void OnButtonCancelClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnButtonOkClicked(object sender, EventArgs e)
  {
    this.UpdateGlobalListView();
    string empty1 = string.Empty;
    string empty2 = string.Empty;
    for (int index = 0; index < this.m_GlobalListView.Items.Count; ++index)
    {
      string text = this.m_GlobalListView.Items[index].SubItems[0].Text;
      string str1 = this.m_GlobalListView.Items[index].SubItems[1].Text;
      if (this.m_CurrentProduct == RevitProduct.SITES)
      {
        if (string.Compare(EPShared.LocalRM.GetString("CurbMassSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("CurbMassSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("MassTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("MassTemplateFileName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("CurbMassTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("CurbMassTemplateFileName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallMassTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("RetainingWallMassTemplateFileName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SidewalkMassTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("SidewalkMassTemplateFileName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("StreetMassTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("StreetMassTemplateFileName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallMassSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("RetainingWallMassSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SidewalkMassSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("SidewalkMassSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("StreetMassSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("StreetMassSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("CurbLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("CurbLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("CurbLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("CurbLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("CurbLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("CurbLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("FeatureLineLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("FeatureLineLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("FeatureLineLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("ParkingLotLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("ParkingLotLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("ParkingLotLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("PointWipeoutLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("PointWipeoutLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("PointWipeoutLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("RetainingWallLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("RetainingWallLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("RetainingWallLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SidewalkLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("SidewalkLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SidewalkLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("SidewalkLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SidewalkLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("SidewalkLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("SoftTerrainLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("SoftTerrainLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("SoftTerrainLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("StreetLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("StreetLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("StreetLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("StreetLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("StreetLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("StreetLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("IntersectionLineSubCategoryName"), text, true) == 0)
        {
          this.m_Fields.Add("IntersectionLineSubCategoryName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("IntersectionLineSubCategoryColor"), text, true) == 0)
        {
          this.m_Fields.Add("IntersectionLineSubCategoryColor");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("IntersectionLineSubCategoryLineWeight"), text, true) == 0)
        {
          this.m_Fields.Add("IntersectionLineSubCategoryLineWeight");
          this.m_Values.Add(str1);
        }
        if (this.m_CurrentProduct == RevitProduct.SITES)
        {
          if (string.Compare(text, EPShared.LocalRM.GetString("TopographySurfaceArcPointInterval"), true) == 0)
          {
            double _dReturnedDouble = 0.0;
            if (str1 != null && str1 != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), str1, true) == 0)
              _dReturnedDouble = 0.0;
            else if (str1 != null && str1 != string.Empty)
              RevitGeometry.Units_ConvertStringToDouble(str1, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
            str1 = ValueConversion.ToString(_dReturnedDouble);
            this.m_Fields.Add("TopographySurfaceArcPointInterval");
            this.m_Values.Add(str1);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"), true) == 0)
          {
            double _dReturnedDouble = 0.0;
            if (str1 != null && str1 != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), str1, true) == 0)
              _dReturnedDouble = 0.0;
            else if (str1 != null && str1 != string.Empty)
              RevitGeometry.Units_ConvertStringToDouble(str1, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
            str1 = ValueConversion.ToString(_dReturnedDouble);
            if (string.Compare(text, EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"), true) == 0)
              this.m_Fields.Add("StreetIntersectionDefaultRadius");
            else if (string.Compare(text, EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"), true) == 0)
              this.m_Fields.Add("SidewalkIntersectionDefaultRadius");
            this.m_Values.Add(str1);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"), true) == 0)
          {
            double _dReturnedDouble = 0.0;
            if (str1 != null && str1 != string.Empty && string.Compare(EPShared.LocalRM.GetString("NotAvailableString"), str1, true) == 0)
              _dReturnedDouble = 0.0;
            else if (str1 != null && str1 != string.Empty)
              RevitGeometry.Units_ConvertStringToDouble(str1, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
            str1 = ValueConversion.ToString(_dReturnedDouble);
            if (string.Compare(text, EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"), true) == 0)
              this.m_Fields.Add("StreetIntersectionDefaultTransitioningDistance");
            else if (string.Compare(text, EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"), true) == 0)
              this.m_Fields.Add("SidewalkIntersectionDefaultTransitioningDistance");
            this.m_Values.Add(str1);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("MassCreationOnlyMode"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("UseSharedElevation"), true) == 0)
          {
            str1 = string.Compare(str1, EPShared.LocalRM.GetString("YesString"), true) != 0 ? (string.Compare(str1, EPShared.LocalRM.GetString("NoString"), true) != 0 ? "0" : "0") : "1";
            if (string.Compare(text, EPShared.LocalRM.GetString("MassCreationOnlyMode"), true) == 0)
              this.m_Fields.Add("MassCreationOnlyMode");
            else if (string.Compare(text, EPShared.LocalRM.GetString("SiteComponentPromptForStartingSide"), true) == 0)
              this.m_Fields.Add("SiteComponentPromptForStartingSide");
            else if (string.Compare(text, EPShared.LocalRM.GetString("UseSharedElevation"), true) == 0)
              this.m_Fields.Add("UseSharedElevation");
            this.m_Values.Add(str1);
          }
          else if (string.Compare(text, EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"), true) == 0 || string.Compare(text, EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"), true) == 0)
          {
            string strStringToFind = str1;
            if (strStringToFind == string.Empty)
            {
              str1 = "00000";
            }
            else
            {
              List<Material> list = this.m_AllMaterialList.Where<Material>((Func<Material, bool>) (SelectedMaterial => string.Compare(((Element) SelectedMaterial).Name, strStringToFind, false) == 0)).ToList<Material>();
              str1 = list.Count < 1 ? "00000" : ((Element) list.ElementAt<Material>(0)).Id.IntegerValue.ToString();
            }
            if (string.Compare(text, EPShared.LocalRM.GetString("ProposedToposurfaceMaterialParameter"), true) == 0)
              this.m_Fields.Add("ProposedToposurfaceMaterialParameter");
            else if (string.Compare(text, EPShared.LocalRM.GetString("ParkingLotIslandToposurfaceMaterialParameter"), true) == 0)
              this.m_Fields.Add("ParkingLotIslandToposurfaceMaterialParameter");
            this.m_Values.Add(str1);
          }
        }
      }
      else if (this.m_CurrentProduct == RevitProduct.LANDCADD)
      {
        if (string.Compare(EPShared.LocalRM.GetString("PlantingTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("PlantingTemplateFileName");
          this.m_Values.Add(str1);
        }
        else if (string.Compare(EPShared.LocalRM.GetString("GenericTemplateFileNameString"), text, true) == 0)
        {
          this.m_Fields.Add("GenericTemplateFileName");
          this.m_Values.Add(str1);
        }
        if (string.Compare(EPShared.LocalRM.GetString("DisplaySharedParamaterWarningString"), text, true) == 0)
        {
          str1 = string.Compare(str1, EPShared.LocalRM.GetString("YesString"), true) != 0 ? (string.Compare(str1, EPShared.LocalRM.GetString("NoString"), true) != 0 ? "0" : "1") : "0";
          this.m_Fields.Add("MissingSharedParametersDoNotShowAgainOption");
          this.m_Values.Add(str1);
        }
        if (string.Compare(EPShared.LocalRM.GetString("LANDCADDUpdaterCall"), text, true) == 0)
        {
          str1 = string.Compare(str1, EPShared.LocalRM.GetString("YesString"), true) != 0 ? (string.Compare(str1, EPShared.LocalRM.GetString("NoString"), true) != 0 ? "1" : "0") : "1";
          this.m_Fields.Add("LANDCADDUpdaterCall");
          this.m_Values.Add(str1);
        }
      }
      if (string.Compare(EPShared.LocalRM.GetString("CheckForUpdateNotification"), text, true) == 0)
      {
        string str2 = string.Compare(str1, EPShared.LocalRM.GetString("YesString"), true) != 0 ? (string.Compare(str1, EPShared.LocalRM.GetString("NoString"), true) != 0 ? "1" : "0") : "1";
        this.m_Fields.Add("CheckForUpdateNotificationDoNotShowAgainOption");
        this.m_Values.Add(str2);
      }
      else if (string.Compare(EPShared.LocalRM.GetString("LibraryPath"), text, true) == 0)
      {
        this.m_Fields.Add("LibraryPath");
        this.m_Values.Add(str1);
      }
      else if (string.Compare(EPShared.LocalRM.GetString("SamplePath"), text, true) == 0)
      {
        this.m_Fields.Add("SamplePath");
        this.m_Values.Add(str1);
      }
    }
    for (int index = 0; index < this.m_Fields.Count; ++index)
    {
      if (this.m_CurrentProduct == RevitProduct.SITES)
      {
        if (string.Compare(this.m_Fields[index], "TopographySurfaceArcPointInterval", true) == 0)
        {
          if (this.m_Values[index] != string.Empty)
          {
            this.SetDoubleSetting(this.m_Fields[index], Convert.ToDouble(this.m_Values[index]));
            continue;
          }
        }
        else if (string.Compare(this.m_Fields[index], "StreetIntersectionDefaultRadius", true) == 0 || string.Compare(this.m_Fields[index], "SidewalkIntersectionDefaultRadius", true) == 0)
        {
          if (this.m_Values[index] != string.Empty)
          {
            this.SetDoubleSetting(this.m_Fields[index], Convert.ToDouble(this.m_Values[index]));
            continue;
          }
        }
        else if (string.Compare(this.m_Fields[index], "StreetIntersectionDefaultTransitioningDistance", true) == 0 || string.Compare(this.m_Fields[index], "SidewalkIntersectionDefaultTransitioningDistance", true) == 0)
        {
          if (this.m_Values[index] != string.Empty)
          {
            this.SetDoubleSetting(this.m_Fields[index], Convert.ToDouble(this.m_Values[index]));
            continue;
          }
        }
        else if ((string.Compare(this.m_Fields[index], "MassCreationOnlyMode", true) == 0 || string.Compare(this.m_Fields[index], "SoftTerrainLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "SidewalkLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "RetainingWallLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "StreetLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "IntersectionLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "CurbLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "ParkingLotLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "FeatureLineLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "PointWipeoutLineSubCategoryLineWeight", true) == 0 || string.Compare(this.m_Fields[index], "ProposedToposurfaceMaterialParameter", true) == 0 || string.Compare(this.m_Fields[index], "ParkingLotIslandToposurfaceMaterialParameter", true) == 0 || string.Compare(this.m_Fields[index], "SiteComponentPromptForStartingSide", true) == 0 || string.Compare(this.m_Fields[index], "UseSharedElevation", true) == 0) && this.m_Values[index] != string.Empty)
        {
          if (string.Compare(this.m_Fields[index], "ProposedToposurfaceMaterialParameter", true) == 0 || string.Compare(this.m_Fields[index], "ParkingLotIslandToposurfaceMaterialParameter", true) == 0 || string.Compare(this.m_Fields[index], "UseSharedElevation", true) == 0)
          {
            this.SetProjectIntSetting(this.m_Fields[index], Convert.ToInt32(this.m_Values[index]));
            continue;
          }
          this.SetIntSetting(this.m_Fields[index], Convert.ToInt32(this.m_Values[index]));
          continue;
        }
      }
      else if (this.m_CurrentProduct == RevitProduct.LANDCADD && (string.Compare(this.m_Fields[index], "LANDCADDUpdaterCall", true) == 0 || string.Compare(this.m_Fields[index], "MissingSharedParametersDoNotShowAgainOption", true) == 0 || string.Compare(this.m_Fields[index], "CheckSharedParametersFile2010", true) == 0 || string.Compare(this.m_Fields[index], "CheckSharedParametersFile2011", true) == 0 || string.Compare(this.m_Fields[index], "CheckSharedParametersFile2012", true) == 0 || string.Compare(this.m_Fields[index], "CheckSharedParametersFile2013", true) == 0) && this.m_Values[index] != string.Empty)
      {
        this.SetIntSetting(this.m_Fields[index], Convert.ToInt32(this.m_Values[index]));
        continue;
      }
      if (string.Compare(this.m_Fields[index], "CheckForUpdateNotificationDoNotShowAgainOption", true) == 0)
      {
        if (this.m_Values[index] != string.Empty)
        {
          if (Convert.ToInt32(this.m_Values[index]) == 1)
            this.SetIntSetting(this.m_Fields[index], 0);
          else
            this.SetIntSetting(this.m_Fields[index], 1);
        }
      }
      else if (this.m_Values[index] != string.Empty)
        this.SetStringSetting(this.m_Fields[index], this.m_Values[index]);
    }
    this.DialogResult = DialogResult.OK;
  }

  private void SetStringSetting(string _strSettingName, string _strSettingValue)
  {
    ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingName, _strSettingValue);
  }

  private void SetIntSetting(string _strSettingName, int _nSettingValue)
  {
    ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingName, _nSettingValue);
  }

  private void SetProjectIntSetting(string _strSettingName, int _nSettingValue)
  {
    ApplicationUtility.Settings.eplSetE_SetSetting(this.m_CurrentDocument.PathName, _strSettingName, _nSettingValue);
  }

  private void SetDoubleSetting(string _strSettingName, double _dValue)
  {
    ApplicationUtility.Settings.eplSetE_SetSetting(_strSettingName, _dValue);
  }

  private void FormResizeBegin(object sender, EventArgs e) => this.AnchorListView();

  private void AnchorListView()
  {
    if (this.m_ParameterListView == null)
      return;
    this.m_ParameterListView.SetAnchor();
  }

  private void ParameterListViewOnListViewItemChanged(int _nChangedIndex)
  {
    string text1 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
    string text2 = this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
    if (this.m_CurrentProduct == RevitProduct.SITES)
    {
      if (string.Compare(EPShared.LocalRM.GetString("TopographySurfaceArcPointInterval"), text1, true) == 0)
      {
        try
        {
          double _dReturnedDouble = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
          if (_dReturnedDouble < 1.0)
          {
            string empty = string.Empty;
            RevitGeometry.Units_ConvertDoubleToString(1.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty);
            int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("StreetLaneWidthParameter")}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
            return;
          }
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"), text1, true) == 0)
      {
        try
        {
          double _dReturnedDouble = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
          if (_dReturnedDouble < 0.0)
          {
            string empty1 = string.Empty;
            RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty1);
            string empty2 = string.Empty;
            if (string.Compare(EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius"), text1, true) == 0)
              empty2 = EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius");
            else if (string.Compare(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultRadius"), text1, true) == 0)
              empty2 = EPShared.LocalRM.GetString("StreetIntersectionDefaultRadius");
            int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{empty2}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty1}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty1;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
            return;
          }
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"), text1, true) == 0)
      {
        try
        {
          double _dReturnedDouble = 0.0;
          RevitGeometry.Units_ConvertStringToDouble(text2, this.m_Units, (UnitType) 0, ref _dReturnedDouble);
          if (_dReturnedDouble < 0.0)
          {
            string empty3 = string.Empty;
            RevitGeometry.Units_ConvertDoubleToString(0.0, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref empty3);
            string empty4 = string.Empty;
            if (string.Compare(EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance"), text1, true) == 0)
              empty4 = EPShared.LocalRM.GetString("StreetIntersectionDefaultTransitioningDistance");
            else if (string.Compare(EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance"), text1, true) == 0)
              empty4 = EPShared.LocalRM.GetString("SidewalkIntersectionDefaultTransitioningDistance");
            int num = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{empty4}. {EPShared.LocalRM.GetString("MinimumValueIsMessage_")}{empty3}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
            this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = empty3;
            this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
            this.m_ParameterListView.SetFocus(_nChangedIndex);
            return;
          }
          RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, this.m_FormatOptions.DisplayUnits, this.m_FormatOptions.Accuracy, this.m_UnitSymbolType, this.m_Units, ref text2);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = text2;
        }
        catch (Exception ex)
        {
          int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("MassTemplateFileNameString"), text1, true) == 0)
      {
        if (!File.Exists(text2))
        {
          int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
          this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("CurbMassTemplateFileNameString"), text1, true) == 0)
      {
        if (!File.Exists(text2))
        {
          int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
          this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("RetainingWallMassTemplateFileNameString"), text1, true) == 0)
      {
        if (!File.Exists(text2))
        {
          int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
          this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("SidewalkMassTemplateFileNameString"), text1, true) == 0)
      {
        if (!File.Exists(text2))
        {
          int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
          this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("StreetMassTemplateFileNameString"), text1, true) == 0)
      {
        if (!File.Exists(text2))
        {
          int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
          this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("SoftTerrainLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("SidewalkLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("RetainingWallLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("StreetLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("IntersectionLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("CurbLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("ParkingLotLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("FeatureLineLineSubCategoryLineWeight"), text1, true) == 0 || string.Compare(EPShared.LocalRM.GetString("PointWipeoutLineSubCategoryLineWeight"), text1, true) == 0)
      {
        int num1 = 0;
        bool flag = true;
        for (int index = 0; index < text2.Length; ++index)
        {
          if (!char.IsDigit(text2[index]))
          {
            flag = false;
            break;
          }
        }
        if (flag)
          num1 = Convert.ToInt32(text2);
        if (num1 <= 0 || num1 > 16 /*0x10*/)
        {
          int num2 = (int) RevitMessageBox.Show($"{EPShared.LocalRM.GetString("NeedValidInputFor_")}{EPShared.LocalRM.GetString("LineSubCategoryLineWeight")}. {EPShared.LocalRM.GetString("ValidLineWeightValuesMessage")}", EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
          this.m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = "1";
          this.m_ParameterListView.CurrListItem = this.m_ParameterListView.Items[_nChangedIndex];
          this.m_ParameterListView.SetFocus(_nChangedIndex);
        }
      }
    }
    else if (this.m_CurrentProduct == RevitProduct.LANDCADD)
    {
      if (string.Compare(EPShared.LocalRM.GetString("PlantingTemplateFileNameString"), text1, true) == 0)
      {
        if (!File.Exists(text2))
        {
          int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
          this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
        }
      }
      else if (string.Compare(EPShared.LocalRM.GetString("GenericTemplateFileNameString"), text1, true) == 0 && !File.Exists(text2))
      {
        int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
        this.m_ParameterListView.SetFilePickerFocus(_nChangedIndex);
      }
    }
    if (string.Compare(EPShared.LocalRM.GetString("LibraryPath"), text1, true) == 0)
    {
      if (Directory.Exists(text2))
        return;
      int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
      this.m_ParameterListView.SetDirectoryPickerFocus(_nChangedIndex);
    }
    else
    {
      if (string.Compare(EPShared.LocalRM.GetString("SamplePath"), text1, true) != 0 || Directory.Exists(text2))
        return;
      int num = (int) MessageBox.Show(EPShared.LocalRM.GetString("InvalidInputString"));
      this.m_ParameterListView.SetDirectoryPickerFocus(_nChangedIndex);
    }
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.m_SettingsTabControl = new TabControl();
    this.m_Panel = new Panel();
    this.m_Panel.SuspendLayout();
    this.SuspendLayout();
    this.m_ButtonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ButtonOk.Location = new Point(304, 549);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 0;
    this.m_ButtonOk.Text = "Ok";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnButtonOkClicked);
    this.m_ButtonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
    this.m_ButtonCancel.Location = new Point(385, 549);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 1;
    this.m_ButtonCancel.Text = "Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnButtonCancelClicked);
    this.m_SettingsTabControl.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    this.m_SettingsTabControl.Location = new Point(12, 12);
    this.m_SettingsTabControl.Name = "m_SettingsTabControl";
    this.m_SettingsTabControl.SelectedIndex = 0;
    this.m_SettingsTabControl.Size = new Size(455, 531);
    this.m_SettingsTabControl.TabIndex = 2;
    this.m_SettingsTabControl.SelectedIndexChanged += new EventHandler(this.StreetTabControlTabIndexChanged);
    this.m_Panel.AutoSize = true;
    this.m_Panel.AutoSizeMode = AutoSizeMode.GrowAndShrink;
    this.m_Panel.Controls.Add((Control) this.m_SettingsTabControl);
    this.m_Panel.Controls.Add((Control) this.m_ButtonCancel);
    this.m_Panel.Controls.Add((Control) this.m_ButtonOk);
    this.m_Panel.Dock = DockStyle.Fill;
    this.m_Panel.Location = new Point(0, 0);
    this.m_Panel.Name = "m_Panel";
    this.m_Panel.Size = new Size(467, 591);
    this.m_Panel.TabIndex = 3;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(467, 591);
    this.Controls.Add((Control) this.m_Panel);
    this.MinimumSize = new Size(475, 629);
    this.Name = nameof (SettingsForm);
    this.Text = nameof (SettingsForm);
    this.m_Panel.ResumeLayout(false);
    this.m_Panel.PerformLayout();
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
