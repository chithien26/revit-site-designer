﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.LandXMLTypeList
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace EPCommon;

public class LandXMLTypeList : EPForm
{
  private LandXMLElementType m_CurrentType;
  private List<LandXMLSurface> m_SurfaceList = new List<LandXMLSurface>();
  private List<LandXMLSurface> m_SelectedSurfaceList = new List<LandXMLSurface>();
  private List<LandXMLAlignment> m_AlignmentList = new List<LandXMLAlignment>();
  private List<LandXMLAlignment> m_SelectedAlignmentList = new List<LandXMLAlignment>();
  private string m_strCurrentType = string.Empty;
  private Document m_CurrentDocument;
  private int m_nElementCount;
  private List<View> m_ViewList = new List<View>();
  private EPTransactionContainer m_TransactionContainer;
  private bool m_bInvalidXMLFile;
  private bool m_bHasSpiral;
  private Eps_Point m_ManualCenterBasePoint = new Eps_Point();
  private LandXMLImportOptions m_CurrentLandXMLOption;
  private LandXMLParser m_XMLParser;
  private IContainer components;
  private ListView m_LandXMLTypeListView;
  private Button m_ButtonOk;
  private Button m_ButtonCancel;
  private ComboBox m_ViewCombo;
  private Label m_LevelLbl;
  private Label m_SelectSurfaceLabel;

  public LandXMLTypeList(
    LandXMLElementType _CurrentType,
    Document _CurrentDocument,
    EPTransactionContainer _TransactionContainer,
    LandXMLImportOptions _CurrentLandXMLOptions,
    Eps_Point _ManualCenterBasePoint,
    LandXMLParser _XMLParser)
  {
    this.m_CurrentLandXMLOption = _CurrentLandXMLOptions;
    this.m_ManualCenterBasePoint = _ManualCenterBasePoint;
    this.m_CurrentType = _CurrentType;
    this.m_CurrentDocument = _CurrentDocument;
    this.m_TransactionContainer = _TransactionContainer;
    this.InitializeComponent();
    this.ContextualHelpID = "HID_SDimportLandXMLinfo";
    this.SetupStrings();
    this.m_XMLParser = _XMLParser;
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      try
      {
        this.m_bInvalidXMLFile = false;
        this.m_XMLParser.ParseLandXMLSurfaces();
        this.m_SurfaceList = this.m_XMLParser.Surfaces;
        this.m_nElementCount = this.m_SurfaceList.Count;
      }
      catch (Exception ex)
      {
        this.m_bInvalidXMLFile = true;
      }
    }
    else
    {
      try
      {
        this.m_bInvalidXMLFile = false;
        this.m_XMLParser.ParseLandXMLAlignments();
        this.m_AlignmentList = this.m_XMLParser.Allignments;
        this.m_nElementCount = this.m_AlignmentList.Count;
        this.m_bHasSpiral = this.m_XMLParser.HasSpiral;
      }
      catch (Exception ex)
      {
        this.m_bInvalidXMLFile = true;
      }
    }
    this.GetDialogPosition();
    this.UpdateListView();
  }

  private void SetupStrings()
  {
    this.m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
    this.m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
    switch (this.m_CurrentType)
    {
      case LandXMLElementType.Surface:
        this.Text = EPShared.LocalRM.GetString("ToposurfaceSelectionDialog");
        this.m_strCurrentType = EPShared.LocalRM.GetString("ToposurfacesString");
        this.m_SelectSurfaceLabel.Text = EPShared.LocalRM.GetString("SelectTopoSurfaceLabelString");
        break;
      case LandXMLElementType.Allignment:
        this.Text = EPShared.LocalRM.GetString("AlignmentSelectionDialog");
        this.m_strCurrentType = EPShared.LocalRM.GetString("AllignmentString");
        this.m_SelectSurfaceLabel.Text = EPShared.LocalRM.GetString("SelectTopoAlignmentLabelString");
        break;
    }
    this.m_LandXMLTypeListView.View = View.Details;
    this.m_LandXMLTypeListView.MultiSelect = true;
    List<string> stringList = new List<string>();
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      stringList.Add(EPShared.LocalRM.GetString("NameSubRegionParameter"));
      stringList.Add(EPShared.LocalRM.GetString("DescriptionPlantFamilyParameter"));
      for (int index = 0; index < stringList.Count; ++index)
        this.m_LandXMLTypeListView.Columns.Add(stringList[index], (this.m_LandXMLTypeListView.Width - 6) / 2, HorizontalAlignment.Center);
      this.m_LandXMLTypeListView.Columns[1].TextAlign = HorizontalAlignment.Left;
      this.m_LevelLbl.Hide();
      this.m_ViewCombo.Hide();
    }
    else
    {
      this.m_LandXMLTypeListView.Columns.Add(EPShared.LocalRM.GetString("NameSubRegionParameter"));
      this.m_LandXMLTypeListView.Columns[0].Width = this.m_LandXMLTypeListView.Width - 4;
      this.m_LevelLbl.Text = EPShared.LocalRM.GetString("RevitLevelString");
      this.m_LevelLbl.Show();
      this.m_ViewCombo.Show();
      foreach (View element in (IEnumerable<Element>) new FilteredElementCollector(this.m_CurrentDocument).OfClass(typeof (View)).ToElements())
      {
        if (element.GenLevel != null && !this.m_ViewList.Contains(element) && (element.ViewType == 1 || element.ViewType == 115 || element.ViewType == 116) && string.Compare(((Element) element).Name, EPShared.LocalRM.GetString("SiteString"), true) != 0)
        {
          bool flag = false;
          for (int index = 0; index < this.m_ViewList.Count; ++index)
          {
            if (string.Compare(((Element) this.m_ViewList[index].GenLevel).UniqueId, ((Element) element.GenLevel).UniqueId, true) == 0)
            {
              flag = true;
              break;
            }
          }
          if (!flag)
            this.m_ViewList.Add(element);
        }
      }
      this.m_ViewCombo.DataSource = (object) this.m_ViewList;
      this.m_ViewCombo.DisplayMember = EPShared.LocalRM.GetString("NameString");
      if (this.m_ViewList.Count <= 0)
        return;
      this.m_ViewCombo.SelectedIndex = 0;
    }
  }

  private void UpdateListView()
  {
    this.m_LandXMLTypeListView.Items.Clear();
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      foreach (LandXMLSurface surface in this.m_SurfaceList)
      {
        ListViewItem listViewItem1 = new ListViewItem();
        ListViewItem listViewItem2 = this.m_LandXMLTypeListView.Items.Add(surface.SurfaceName);
        listViewItem2.Tag = (object) surface.SurfaceName;
        if (surface.SurfaceDescription == string.Empty)
          listViewItem2.SubItems.Add(EPShared.LocalRM.GetString("NotAvailableString"));
        else
          listViewItem2.SubItems.Add(surface.SurfaceDescription);
      }
      if (this.m_LandXMLTypeListView.Items.Count <= 0)
        return;
      this.m_LandXMLTypeListView.Items[0].Selected = true;
    }
    else
    {
      foreach (LandXMLAlignment alignment in this.m_AlignmentList)
      {
        ListViewItem listViewItem = new ListViewItem();
        this.m_LandXMLTypeListView.Items.Add(alignment.Name).Tag = (object) alignment.Name;
      }
      if (this.m_LandXMLTypeListView.Items.Count <= 0)
        return;
      this.m_LandXMLTypeListView.Items[0].Selected = true;
    }
  }

  private bool FindSelectedIndices(ref List<LandXMLSurface> _SelectedSurfaces)
  {
    int count;
    if ((count = this.m_LandXMLTypeListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = 0; index1 < count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_SurfaceList.Count; ++index2)
        {
          if (string.Compare((string) this.m_LandXMLTypeListView.SelectedItems[index1].Tag, this.m_SurfaceList[index2].SurfaceName, true) == 0)
          {
            _SelectedSurfaces.Add(this.m_SurfaceList[index2]);
            break;
          }
        }
      }
      return true;
    }
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("SurfaceNotSelectedString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private bool FindSelectedIndices(ref List<LandXMLAlignment> _SelectedAlignment)
  {
    int count;
    if ((count = this.m_LandXMLTypeListView.SelectedItems.Count) >= 1)
    {
      for (int index1 = 0; index1 < count; ++index1)
      {
        for (int index2 = 0; index2 < this.m_AlignmentList.Count; ++index2)
        {
          if (string.Compare((string) this.m_LandXMLTypeListView.SelectedItems[index1].Tag, this.m_AlignmentList[index2].Name, true) == 0)
          {
            _SelectedAlignment.Add(this.m_AlignmentList[index2]);
            break;
          }
        }
      }
      return true;
    }
    int num = (int) RevitMessageBox.Show(EPShared.LocalRM.GetString("AlignmentNotSelectedString"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
    return false;
  }

  private void OnButtonOkClicked(object sender, EventArgs e)
  {
    DialogResult dialogResult = DialogResult.Cancel;
    if (this.m_CurrentType == LandXMLElementType.Surface)
    {
      if (!this.FindSelectedIndices(ref this.m_SelectedSurfaceList))
        return;
      using (SurfaceInformation surfaceInformation = new SurfaceInformation(this.m_CurrentDocument, this.m_TransactionContainer))
      {
        for (int index = 0; index < this.m_SelectedSurfaceList.Count; ++index)
        {
          surfaceInformation.SetCurrentSurface(this.m_SelectedSurfaceList[index]);
          if (surfaceInformation.ShowDialog() == DialogResult.OK)
          {
            this.m_SelectedSurfaceList[index].SurfaceName = surfaceInformation.SurfaceName;
            this.m_SelectedSurfaceList[index].Phase = surfaceInformation.Phase;
            this.m_SelectedSurfaceList[index].OverwriteSurfaceID = surfaceInformation.OverwriteSurfaceID;
            dialogResult = DialogResult.OK;
          }
          else
          {
            this.m_SelectedSurfaceList.RemoveAt(index);
            --index;
          }
        }
      }
    }
    else
    {
      if (!this.FindSelectedIndices(ref this.m_SelectedAlignmentList))
        return;
      dialogResult = DialogResult.OK;
    }
    this.DialogResult = dialogResult;
  }

  private void OnButtonCancelClicked(object sender, EventArgs e)
  {
    this.DialogResult = DialogResult.Cancel;
  }

  private void OnLandXMLTypeListClosing(object sender, FormClosingEventArgs e)
  {
    this.SetDialogPosition();
  }

  public int ElementCount
  {
    get => this.m_nElementCount;
    set => this.m_nElementCount = value;
  }

  public bool InvalidXMLFile => this.m_bInvalidXMLFile;

  public bool HasSpiral => this.m_bHasSpiral;

  public List<LandXMLSurface> SelectedSurfaceList => this.m_SelectedSurfaceList;

  public List<LandXMLAlignment> SelectedAlignmentList => this.m_SelectedAlignmentList;

  public View CurrentView => this.m_ViewCombo.SelectedItem as View;

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.components != null)
      this.components.Dispose();
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.m_LandXMLTypeListView = new ListView();
    this.m_ButtonOk = new Button();
    this.m_ButtonCancel = new Button();
    this.m_ViewCombo = new ComboBox();
    this.m_LevelLbl = new Label();
    this.m_SelectSurfaceLabel = new Label();
    this.SuspendLayout();
    this.m_LandXMLTypeListView.FullRowSelect = true;
    this.m_LandXMLTypeListView.Location = new Point(14, 35);
    this.m_LandXMLTypeListView.Name = "m_LandXMLTypeListView";
    this.m_LandXMLTypeListView.Size = new Size(332, 186);
    this.m_LandXMLTypeListView.TabIndex = 1;
    this.m_LandXMLTypeListView.UseCompatibleStateImageBehavior = false;
    this.m_ButtonOk.Location = new Point(190, 254);
    this.m_ButtonOk.Name = "m_ButtonOk";
    this.m_ButtonOk.Size = new Size(75, 23);
    this.m_ButtonOk.TabIndex = 4;
    this.m_ButtonOk.Text = "Ok";
    this.m_ButtonOk.UseVisualStyleBackColor = true;
    this.m_ButtonOk.Click += new EventHandler(this.OnButtonOkClicked);
    this.m_ButtonCancel.Location = new Point(271, 254);
    this.m_ButtonCancel.Name = "m_ButtonCancel";
    this.m_ButtonCancel.Size = new Size(75, 23);
    this.m_ButtonCancel.TabIndex = 5;
    this.m_ButtonCancel.Text = "Cancel";
    this.m_ButtonCancel.UseVisualStyleBackColor = true;
    this.m_ButtonCancel.Click += new EventHandler(this.OnButtonCancelClicked);
    this.m_ViewCombo.DropDownStyle = ComboBoxStyle.DropDownList;
    this.m_ViewCombo.FormattingEnabled = true;
    this.m_ViewCombo.Location = new Point(101, 230);
    this.m_ViewCombo.Name = "m_ViewCombo";
    this.m_ViewCombo.Size = new Size(245, 21);
    this.m_ViewCombo.TabIndex = 3;
    this.m_LevelLbl.AutoSize = true;
    this.m_LevelLbl.Location = new Point(12, 233);
    this.m_LevelLbl.Name = "m_LevelLbl";
    this.m_LevelLbl.Size = new Size(33, 13);
    this.m_LevelLbl.TabIndex = 2;
    this.m_LevelLbl.Text = "Level";
    this.m_SelectSurfaceLabel.AutoSize = true;
    this.m_SelectSurfaceLabel.Location = new Point(12, 9);
    this.m_SelectSurfaceLabel.Name = "m_SelectSurfaceLabel";
    this.m_SelectSurfaceLabel.Size = new Size(315, 13);
    this.m_SelectSurfaceLabel.TabIndex = 0;
    this.m_SelectSurfaceLabel.Text = "Click on the toposurface(s) that you wish to import into your model";
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.ClientSize = new Size(358, 289);
    this.Controls.Add((Control) this.m_SelectSurfaceLabel);
    this.Controls.Add((Control) this.m_LevelLbl);
    this.Controls.Add((Control) this.m_ViewCombo);
    this.Controls.Add((Control) this.m_ButtonCancel);
    this.Controls.Add((Control) this.m_ButtonOk);
    this.Controls.Add((Control) this.m_LandXMLTypeListView);
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.MinimumSize = new Size(364, 310);
    this.Name = nameof (LandXMLTypeList);
    this.Text = nameof (LandXMLTypeList);
    this.FormClosing += new FormClosingEventHandler(this.OnLandXMLTypeListClosing);
    this.ResumeLayout(false);
    this.PerformLayout();
    this.AcceptButton = (IButtonControl) this.m_ButtonOk;
    this.CancelButton = (IButtonControl) this.m_ButtonCancel;
  }
}
