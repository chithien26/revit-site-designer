﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.UCS
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using System;

#nullable disable
namespace EPCommon;

public class UCS
{
  private Vector m_origin = new Vector(0.0, 0.0, 0.0);
  private Vector m_xAxis = new Vector(1.0, 0.0, 0.0);
  private Vector m_yAxis = new Vector(0.0, 1.0, 0.0);
  private Vector m_zAxis = new Vector(0.0, 0.0, 1.0);

  public UCS()
  {
  }

  public Vector Origin
  {
    get => this.m_origin;
    set => this.m_origin = value;
  }

  public Vector this[int index]
  {
    get
    {
      switch (index)
      {
        case 0:
          return this.m_xAxis;
        case 1:
          return this.m_yAxis;
        case 2:
          return this.m_zAxis;
        default:
          throw new ArgumentOutOfRangeException();
      }
    }
  }

  public Vector XAxis => this.m_xAxis;

  public Vector YAxis => this.m_yAxis;

  public Vector ZAxis => this.m_zAxis;

  public UCS(Vector origin, Vector xAxis, Vector yAxis)
    : this(origin, xAxis, yAxis, true)
  {
  }

  public UCS(Vector origin, Vector xAxis, Vector yAxis, bool flag)
  {
    Vector vector1 = xAxis / ~xAxis;
    Vector vector2 = yAxis / ~yAxis;
    Vector vector3 = vector1 & vector2;
    if (~vector3 < double.Epsilon)
      throw new InvalidOperationException();
    if (!flag)
      vector3 = -vector3;
    this.m_origin = origin;
    this.m_xAxis = vector1;
    this.m_yAxis = vector2;
    this.m_zAxis = vector3;
  }

  public Vector LC2GC(Vector arg)
  {
    return new Vector()
    {
      X = arg.X * this.m_xAxis.X + arg.Y * this.m_yAxis.X + arg.Z * this.m_zAxis.X + this.m_origin.X,
      Y = arg.X * this.m_xAxis.Y + arg.Y * this.m_yAxis.Y + arg.Z * this.m_zAxis.Y + this.m_origin.Y,
      Z = arg.X * this.m_xAxis.Z + arg.Y * this.m_yAxis.Z + arg.Z * this.m_zAxis.Z + this.m_origin.Z
    };
  }

  public Vector GC2LC(Vector arg)
  {
    Vector vector = new Vector();
    arg -= this.m_origin;
    vector.X = this.m_xAxis * arg;
    vector.Y = this.m_yAxis * arg;
    vector.Z = this.m_zAxis * arg;
    return vector;
  }

  public static UCS operator +(UCS lhs, UCS rhs)
  {
    Vector origin = lhs.Origin + rhs.Origin;
    Vector[] m1 = new Vector[3];
    Vector[] m2 = new Vector[3];
    for (int index = 0; index < 3; ++index)
    {
      m1[index] = lhs[index];
      m2[index] = rhs[index];
    }
    Vector[] vectorArray = Vector.MultiCross3X3Matrix(m1, m2);
    return new UCS(origin, vectorArray[0], vectorArray[1]);
  }
}
