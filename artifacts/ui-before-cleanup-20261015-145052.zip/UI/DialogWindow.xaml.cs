using System.Windows;

namespace SiteDesigner.UI;

public partial class DialogWindow : Window
{
    public DialogWindow() => InitializeComponent();
    public void SetContent(FrameworkElement content) => DialogContent.Content = content;
}
