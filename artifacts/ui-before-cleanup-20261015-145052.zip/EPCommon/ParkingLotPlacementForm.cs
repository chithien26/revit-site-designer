using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Revit.DB;
using Autodesk.Revit.Exceptions;

namespace EPCommon;

public class ParkingLotPlacementForm : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private ParkingLotPlacement m_ParkingLotPlacement;

	private FamilySymbol m_ParkingStallSymbol;

	private FamilySymbol m_ADAParkingStallSymbol;

	private FamilySymbol m_BumperSymbol;

	private FamilySymbol m_IslandSymbol;

	private FormatOptions m_LengthFormatOptions;

	private FormatOptions m_AngularOptions;

	private Autodesk.Revit.DB.View m_CurView;

	private DisplayUnit m_DisplayUnitSystem;

	private UnitSymbolType m_LengthUnitSymbolType;

	private UnitSymbolType m_AngularSymbolType;

	private bool m_bAreaBiDirectionalAisles;

	private int m_nAreaRowSpacingOptions;

	private int m_nAreaParkingNumberOfRows;

	private string m_strAreaAisleWidth = string.Empty;

	private string m_strAreaDistanceBetweenCenterlines = string.Empty;

	private FamilyContainer m_CurFamilyContainer;

	private DecimalSymbol m_DecimalSymbolType;

	private double m_dAngularRounding;

	private IContainer components;

	private TabPage m_ParkingSpaceTabPage;

	private ComboBox m_LevelComboBox;

	private Label m_LevelLabel;

	private TabControl m_ParkingLotTabControl;

	private TabPage m_ADASpaceTabPage;

	private ComboBox m_ParkingNameComboBox;

	private Label m_ParkingNameLabel;

	private ComboBox m_ParkingFamilyComboBox;

	private Label m_ParkingFamilyLabel;

	private Label m_ParkingAngleLabel;

	private TextBox m_ParkingAngleTextBox;

	private TextBox m_ParkingWidthTextBox;

	private Label m_ParkingWidthLabel;

	private TextBox m_ParkingLengthTextBox;

	private Label m_ParkingLengthLabel;

	private GroupBox m_ParkingPlacementGroupBox;

	private Button m_ParkingAreaSettingsButton;

	private RadioButton m_ParkingAreaRadioButton;

	private RadioButton m_ParkingDoubleRowRadioButton;

	private RadioButton m_ParkingSingleRowRadioButton;

	private CheckBox m_ADAPlaceParkingSpacesCheckBox;

	private TextBox m_ADANumberOfSpacesTextBox;

	private Label m_ADANumberOfSpacesLabel;

	private TextBox m_ADAWidthTextBox;

	private Label m_ADAWidthLabel;

	private ComboBox m_ADAFamilyNameComboBox;

	private Label m_ADAFamilyNameLabel;

	private ComboBox m_ADAFamilyComboBox;

	private Label m_ADAFamilyLabel;

	private TabPage m_BumperTabPage;

	private CheckBox m_BumperPlaceCheckBox;

	private TextBox m_BumperWidthTextBox;

	private Label m_BumperWidthLabel;

	private ComboBox m_BumperFamilyNameComboBox;

	private Label m_BumperFamilyNameLabel;

	private ComboBox m_BumperFamilyComboBox;

	private Label m_BumperFamilyLabel;

	private TextBox m_BumperSetbackTextBox;

	private Label m_BumperSetbackLabel;

	private TextBox m_BumperHeightTextBox;

	private Label m_BumperHeightLabel;

	private TextBox m_BumperOffsetTextBox;

	private Label m_BumperOffsetLabel;

	private TabPage m_IslandTabPage;

	private CheckBox m_IslandPlaceCheckBox;

	private TextBox m_IslandHeightTextBox;

	private Label m_IslandHeightLabel;

	private TextBox m_IslandWidthTextBox;

	private Label m_IslandWidthLabel;

	private ComboBox m_IslandFamilyNameComboBox;

	private Label m_IslandFamilyNameLabel;

	private ComboBox m_IslandFamilyComboBox;

	private Label m_IslandFamilyLabel;

	private Button m_LoadParkingFamilyButton;

	private Button m_LoadADAFamilyButton;

	private Button m_LoadBumperFamilyButton;

	private Button m_LoadIslandFamilyButton;

	private TextBox m_ParkingNumberOfSpacesTextBox;

	private Label m_ParkingNumberOfSpacesLabel;

	private RadioButton m_ParkingByNumberRadioButton;

	private System.Windows.Forms.Panel m_OptimizePanel;

	private RadioButton m_ParkingChainRadioButton;

	private RadioButton m_ParkingSegmentRadioButton;

	private RadioButton m_ParkingOptimizeRadioButton;

	private CheckBox m_ExistingElementCheckBox;

	private System.Windows.Forms.Panel m_MoveablePanel;

	private CheckBox m_DeleteExistingCheckBox;

	private Button m_InsertButton;

	private Button m_CancelButton;

	private CheckBox m_ADASharedAccessibleAisleCheckBox;

	private Label m_StartingDistanceLabel;

	private TextBox m_StartingDistanceTextBox;

	private System.Windows.Forms.Panel m_ToposurfacePickerPanel;

	private Label m_SelectedSurfaceLabel;

	private CheckBox m_ToposurfaceCheckBox;

	private ComboBox m_SurfaceList;

	public PlacementType PlacementType
	{
		get
		{
			if (m_ParkingSingleRowRadioButton.Checked)
			{
				return PlacementType.ParkingSingleRow;
			}
			if (m_ParkingDoubleRowRadioButton.Checked)
			{
				return PlacementType.ParkingDoubleRow;
			}
			return PlacementType.ParkingArea;
		}
	}

	public Level Level => m_CurView.GenLevel;

	public Autodesk.Revit.DB.View View => m_CurView;

	public FamilySymbol ParkingStallSymbol => m_ParkingStallSymbol;

	public FamilySymbol ADAParkingStallSymbol => m_ADAParkingStallSymbol;

	public FamilySymbol BumperSymbol => m_BumperSymbol;

	public FamilySymbol IslandSymbol => m_IslandSymbol;

	public bool ParkingSingleRowChecked => m_ParkingSingleRowRadioButton.Checked;

	public bool ParkingDoubleRowChecked => m_ParkingDoubleRowRadioButton.Checked;

	public bool ParkingAreaChecked => m_ParkingAreaRadioButton.Checked;

	public bool ParkingOptimizeChecked => m_ParkingOptimizeRadioButton.Checked;

	public bool ParkingByNumberChecked => m_ParkingByNumberRadioButton.Checked;

	public bool ParkingSegmentChecked => m_ParkingSegmentRadioButton.Checked;

	public bool ParkingChainChecked => m_ParkingChainRadioButton.Checked;

	public int ParkingNumberOfSpaces
	{
		get
		{
			int _nReturnedInt = 0;
			RevitGeometry.StrE_GetValidWholeNumber(m_ParkingNumberOfSpacesTextBox.Text, ref _nReturnedInt);
			return _nReturnedInt;
		}
	}

	public double ParkingAngle
	{
		get
		{
			double result = 0.0;
			if (m_ParkingAngleTextBox.Text != string.Empty)
			{
				result = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_ParkingAngleTextBox.Text);
			}
			return result;
		}
	}

	public double ParkingWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_ParkingWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_ParkingWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double ParkingLength
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_ParkingLengthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_ParkingLengthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool ADAPlaceParkingSpacesChecked => m_ADAPlaceParkingSpacesCheckBox.Checked;

	public double ADAParkingWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_ADAWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_ADAWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public int ADAParkingNumberOfSpaces
	{
		get
		{
			int _nReturnedInt = 0;
			RevitGeometry.StrE_GetValidWholeNumber(m_ADANumberOfSpacesTextBox.Text, ref _nReturnedInt);
			return _nReturnedInt;
		}
	}

	public bool ADASharedAccessibleAisleChecked => m_ADASharedAccessibleAisleCheckBox.Checked;

	public bool BumperPlaceChecked => m_BumperPlaceCheckBox.Checked;

	public double BumperSetback
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_BumperSetbackTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_BumperSetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double BumperOffset
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_BumperOffsetTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_BumperOffsetTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double BumperWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_BumperWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_BumperWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double BumperHeight
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_BumperHeightTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_BumperHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool IslandPlaceChecked => m_IslandPlaceCheckBox.Checked;

	public double IslandWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_IslandWidthTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_IslandWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double IslandHeight
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_IslandHeightTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_IslandHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public bool AreaBiDirectionalAisles => m_bAreaBiDirectionalAisles;

	public int AreaRowSpacingOptions => m_nAreaRowSpacingOptions;

	public double AreaAisleWidth
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_strAreaAisleWidth != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_strAreaAisleWidth, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public double AreaDistanceBetweenCenterlines
	{
		get
		{
			double _dReturnedDouble = 0.0;
			if (m_strAreaDistanceBetweenCenterlines != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_strAreaDistanceBetweenCenterlines, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public int AreaParkingNumberOfRows => m_nAreaParkingNumberOfRows;

	public bool ExistingElementChecked => m_ExistingElementCheckBox.Checked;

	public bool DeleteExistingChecked
	{
		get
		{
			if (!m_ExistingElementCheckBox.Checked)
			{
				return false;
			}
			return m_DeleteExistingCheckBox.Checked;
		}
	}

	public double StartingDistance
	{
		get
		{
			if (!m_ExistingElementCheckBox.Checked)
			{
				return 0.0;
			}
			double _dReturnedDouble = 0.0;
			if (m_StartingDistanceTextBox.Text != string.Empty)
			{
				RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble);
			}
			return _dReturnedDouble;
		}
	}

	public TopographySurfaceContainer Surface
	{
		get
		{
			TopographySurfaceContainer result = null;
			if (m_SurfaceList.SelectedItem is ToposurfaceItem toposurfaceItem)
			{
				result = toposurfaceItem.Value;
			}
			return result;
		}
	}

	public bool PickToposurface => m_ToposurfaceCheckBox.Checked;

	public ParkingLotPlacementForm(ParkingLotPlacement _ParkingLotPlacement)
	{
		InitializeComponent();
		Text = EPShared.LocalRM.GetString("ParkingLotDialog");
		m_ParkingSpaceTabPage.Text = EPShared.LocalRM.GetString("ParkingStyleDialog");
		m_ADASpaceTabPage.Text = EPShared.LocalRM.GetString("ADASpacingDialog");
		m_BumperTabPage.Text = EPShared.LocalRM.GetString("BumperDialog");
		m_IslandTabPage.Text = EPShared.LocalRM.GetString("IslandDialog");
		m_ParkingPlacementGroupBox.Text = EPShared.LocalRM.GetString("ParkingPlacementDialog");
		m_ParkingSingleRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_SingleRowDialog");
		m_ParkingDoubleRowRadioButton.Text = EPShared.LocalRM.GetString("AMP_DoubleRowDialog");
		m_ParkingAreaRadioButton.Text = EPShared.LocalRM.GetString("AMP_AreaDialog");
		m_ParkingAreaSettingsButton.Text = EPShared.LocalRM.GetString("Se_AMP_ttingsDialog");
		m_ParkingFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
		m_ParkingNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
		m_LevelLabel.Text = EPShared.LocalRM.GetString("AMP_LevelDialog");
		m_ParkingLengthLabel.Text = EPShared.LocalRM.GetString("AMP_LengthDialog");
		m_ParkingAngleLabel.Text = EPShared.LocalRM.GetString("AMP_AngleDialog");
		m_ParkingWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
		m_ParkingOptimizeRadioButton.Text = EPShared.LocalRM.GetString("AMP_OptimizeDialog");
		m_ParkingSegmentRadioButton.Text = EPShared.LocalRM.GetString("AMP_SegmentDialog");
		m_ParkingChainRadioButton.Text = EPShared.LocalRM.GetString("AMP_ChainDialog");
		m_ParkingByNumberRadioButton.Text = EPShared.LocalRM.GetString("ByN_AMP_umberDialog");
		m_ParkingWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
		m_ParkingNumberOfSpacesLabel.Text = EPShared.LocalRM.GetString("Nu_AMP_mberOfSpacesDialog");
		m_ExistingElementCheckBox.Text = EPShared.LocalRM.GetString("ExistingEle_AMP_mentDialog");
		m_DeleteExistingCheckBox.Text = EPShared.LocalRM.GetString("DeleteE_AMP_xistingElementDialog");
		m_ADAPlaceParkingSpacesCheckBox.Text = EPShared.LocalRM.GetString("Place_AMP_ADAParkingSpacesDialog");
		m_ADAFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
		m_ADAFamilyNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
		m_ADAWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
		m_ADANumberOfSpacesLabel.Text = EPShared.LocalRM.GetString("Nu_AMP_mberOfSpacesDialog");
		m_ADASharedAccessibleAisleCheckBox.Text = EPShared.LocalRM.GetString("S_AMP_haredAccessibleAisleDialog");
		m_BumperPlaceCheckBox.Text = EPShared.LocalRM.GetString("Place_AMP_BumpersDialog");
		m_BumperFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
		m_BumperFamilyNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
		m_BumperSetbackLabel.Text = EPShared.LocalRM.GetString("AMP_SetbackDialog");
		m_BumperOffsetLabel.Text = EPShared.LocalRM.GetString("AMP_OffsetDialog");
		m_BumperWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
		m_BumperHeightLabel.Text = EPShared.LocalRM.GetString("AMP_HeightDialog");
		m_IslandPlaceCheckBox.Text = EPShared.LocalRM.GetString("Place_AMP_IslandsDialog");
		m_IslandFamilyLabel.Text = EPShared.LocalRM.GetString("AMP_FamilyDialog");
		m_IslandFamilyNameLabel.Text = EPShared.LocalRM.GetString("AMP_NameDialog");
		m_IslandWidthLabel.Text = EPShared.LocalRM.GetString("AMP_WidthDialog");
		m_IslandHeightLabel.Text = EPShared.LocalRM.GetString("AMP_HeightDialog");
		m_StartingDistanceLabel.Text = EPShared.LocalRM.GetString("S_AMP_tartingDistanceDialog");
		m_InsertButton.Text = EPShared.LocalRM.GetString("AMP_InsertDialog");
		m_CancelButton.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ToposurfaceCheckBox.Text = EPShared.LocalRM.GetString("Pick_AMP_Toposurface");
		m_SelectedSurfaceLabel.Text = EPShared.LocalRM.GetString("S_AMP_urfaceDialog");
		EPToolTip.SetToolTip(m_LoadParkingFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		EPToolTip.SetToolTip(m_LoadADAFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		EPToolTip.SetToolTip(m_LoadBumperFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		EPToolTip.SetToolTip(m_LoadIslandFamilyButton, EPShared.LocalRM.GetString("LoadFamilyToolTip"));
		m_ParkingLotPlacement = _ParkingLotPlacement;
		m_DisplayUnitSystem = m_ParkingLotPlacement.Document.DisplayUnitSystem;
		m_LengthFormatOptions = m_ParkingLotPlacement.Document.GetUnits().GetFormatOptions(UnitType.UT_Length);
		m_AngularOptions = m_ParkingLotPlacement.Document.GetUnits().GetFormatOptions(UnitType.UT_Angle);
		m_Units = m_ParkingLotPlacement.Document.GetUnits();
		try
		{
			m_LengthUnitSymbolType = m_LengthFormatOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_LengthUnitSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_AngularSymbolType = m_AngularOptions.LegacyUnitSymbol();
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_AngularSymbolType = UnitSymbolType.UST_NONE;
		}
		try
		{
			m_dAngularRounding = m_AngularOptions.Accuracy;
		}
		catch (Autodesk.Revit.Exceptions.InvalidOperationException)
		{
			m_dAngularRounding = 1.0;
		}
		m_DecimalSymbolType = m_ParkingLotPlacement.Document.GetUnits().DecimalSymbol;
		InitializeControls();
	}

	private void InitializeControls()
	{
		int _nReturnValue = 0;
		double _dReturnValue = 0.0;
		string _strReturnValue = string.Empty;
		GetDialogPosition();
		FamilyContainer familyContainer = null;
		FamilySymbol familySymbol = null;
		m_ParkingFamilyComboBox.DataSource = m_ParkingLotPlacement.ParkingStallFamilyList;
		m_ParkingFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotFamilyName", ref _strReturnValue))
		{
			for (int i = 0; i < m_ParkingFamilyComboBox.Items.Count; i++)
			{
				if (m_ParkingFamilyComboBox.Items[i] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _strReturnValue, ignoreCase: true) == 0)
				{
					m_ParkingFamilyComboBox.SelectedIndex = i;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotSymbolName", ref _strReturnValue))
		{
			for (int j = 0; j < m_ParkingNameComboBox.Items.Count; j++)
			{
				if (m_ParkingNameComboBox.Items[j] is FamilySymbol familySymbol2 && string.Compare(familySymbol2.Name, _strReturnValue, ignoreCase: true) == 0)
				{
					m_ParkingNameComboBox.SelectedIndex = j;
					break;
				}
			}
		}
		m_LevelComboBox.DataSource = m_ParkingLotPlacement.Views;
		m_LevelComboBox.DisplayMember = "ViewName";
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotViewName", ref _strReturnValue))
		{
			Autodesk.Revit.DB.View view = null;
			for (int k = 0; k < m_LevelComboBox.Items.Count; k++)
			{
				if (m_LevelComboBox.Items[k] is Autodesk.Revit.DB.View view2 && string.Compare(view2.Name, _strReturnValue, ignoreCase: true) == 0)
				{
					m_LevelComboBox.SelectedIndex = k;
					break;
				}
			}
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotParkingAngle", ref _dReturnValue))
		{
			_dReturnValue = Math.PI / 2.0;
		}
		RevitGeometry.eplStrE_ConvertRadiansToAngleStr(m_AngularOptions.LegacyDisplayUnits(), _dReturnValue, m_dAngularRounding, m_AngularSymbolType, m_DecimalSymbolType, ref _strReturnValue);
		m_ParkingAngleTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotParkingWidth", ref _dReturnValue))
		{
			_dReturnValue = 9.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_ParkingWidthTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotParkingLength", ref _dReturnValue))
		{
			_dReturnValue = 18.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_ParkingLengthTextBox.Text = _strReturnValue;
		m_ParkingSingleRowRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotPlacementOption", ref _nReturnValue))
		{
			switch (_nReturnValue)
			{
			case 0:
				m_ParkingSingleRowRadioButton.Checked = true;
				break;
			case 1:
				m_ParkingDoubleRowRadioButton.Checked = true;
				break;
			default:
				m_ParkingAreaRadioButton.Checked = true;
				break;
			}
		}
		m_ParkingOptimizeRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotOptimizeByNumberOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_ParkingOptimizeRadioButton.Checked = true;
			}
			else
			{
				m_ParkingByNumberRadioButton.Checked = true;
			}
		}
		m_ParkingSegmentRadioButton.Checked = true;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotOptimizeSegmentChainOption", ref _nReturnValue))
		{
			if (_nReturnValue == 0)
			{
				m_ParkingSegmentRadioButton.Checked = true;
			}
			else
			{
				m_ParkingChainRadioButton.Checked = true;
			}
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotNumberOfSpaces", ref _nReturnValue))
		{
			_nReturnValue = 0;
		}
		m_ParkingNumberOfSpacesTextBox.Text = Convert.ToString(_nReturnValue);
		m_ExistingElementCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotExistingElement", ref _nReturnValue))
		{
			m_ExistingElementCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_DeleteExistingCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotDeleteExisting", ref _nReturnValue))
		{
			m_DeleteExistingCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotStartingDistance", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_StartingDistanceTextBox.Text = _strReturnValue;
		m_ADAFamilyComboBox.DataSource = m_ParkingLotPlacement.ADAParkingStallFamilyList;
		m_ADAFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotADAFamilyName", ref _strReturnValue))
		{
			for (int l = 0; l < m_ADAFamilyComboBox.Items.Count; l++)
			{
				if (m_ADAFamilyComboBox.Items[l] is FamilyContainer familyContainer3 && string.Compare(familyContainer3.FamilyName, _strReturnValue, ignoreCase: true) == 0)
				{
					m_ADAFamilyComboBox.SelectedIndex = l;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotADASymbolName", ref _strReturnValue))
		{
			for (int m = 0; m < m_ADAFamilyNameComboBox.Items.Count; m++)
			{
				if (m_ADAFamilyNameComboBox.Items[m] is FamilySymbol familySymbol3 && string.Compare(familySymbol3.Name, _strReturnValue, ignoreCase: true) == 0)
				{
					m_ADAFamilyNameComboBox.SelectedIndex = m;
					break;
				}
			}
		}
		m_ADAPlaceParkingSpacesCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADAPlaceParkingSpaces", ref _nReturnValue))
		{
			m_ADAPlaceParkingSpacesCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADAParkingWidth", ref _dReturnValue))
		{
			_dReturnValue = 9.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_ADAWidthTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADANumberOfSpaces", ref _nReturnValue))
		{
			_nReturnValue = 1;
		}
		m_ADANumberOfSpacesTextBox.Text = Convert.ToString(_nReturnValue);
		m_ADASharedAccessibleAisleCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotADASharedAccessibleAisle", ref _nReturnValue))
		{
			m_ADASharedAccessibleAisleCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		m_BumperFamilyComboBox.DataSource = m_ParkingLotPlacement.ParkingBumperFamilyList;
		m_BumperFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperFamilyName", ref _strReturnValue))
		{
			for (int n = 0; n < m_BumperFamilyComboBox.Items.Count; n++)
			{
				if (m_BumperFamilyComboBox.Items[n] is FamilyContainer familyContainer4 && string.Compare(familyContainer4.FamilyName, _strReturnValue, ignoreCase: true) == 0)
				{
					m_BumperFamilyComboBox.SelectedIndex = n;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperSymbolName", ref _strReturnValue))
		{
			for (int num = 0; num < m_BumperFamilyNameComboBox.Items.Count; num++)
			{
				if (m_BumperFamilyNameComboBox.Items[num] is FamilySymbol familySymbol4 && string.Compare(familySymbol4.Name, _strReturnValue, ignoreCase: true) == 0)
				{
					m_BumperFamilyNameComboBox.SelectedIndex = num;
					break;
				}
			}
		}
		m_BumperPlaceCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperPlace", ref _nReturnValue))
		{
			m_BumperPlaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingSetback", ref _dReturnValue))
		{
			_dReturnValue = 1.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_BumperSetbackTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingOffset", ref _dReturnValue))
		{
			_dReturnValue = 1.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_BumperOffsetTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingWidth", ref _dReturnValue))
		{
			_dReturnValue = 0.5;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_BumperWidthTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotBumperParkingHeight", ref _dReturnValue))
		{
			_dReturnValue = 0.58333;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_BumperHeightTextBox.Text = _strReturnValue;
		m_IslandFamilyComboBox.Items.Add("<Empty Space>");
		for (int num2 = 0; num2 < m_ParkingLotPlacement.ParkingIslandFamilyList.Count; num2++)
		{
			m_IslandFamilyComboBox.Items.Add(m_ParkingLotPlacement.ParkingIslandFamilyList[num2].FamilyName);
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandFamilyName", ref _strReturnValue))
		{
			for (int num3 = 0; num3 < m_IslandFamilyComboBox.Items.Count; num3++)
			{
				if (string.Compare((string)m_IslandFamilyComboBox.Items[num3], _strReturnValue, ignoreCase: true) == 0)
				{
					m_IslandFamilyComboBox.SelectedIndex = num3;
					break;
				}
			}
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandSymbolName", ref _strReturnValue))
		{
			for (int num4 = 0; num4 < m_IslandFamilyNameComboBox.Items.Count; num4++)
			{
				if (string.Compare((string)m_IslandFamilyNameComboBox.Items[num4], _strReturnValue, ignoreCase: true) == 0)
				{
					m_IslandFamilyNameComboBox.SelectedIndex = num4;
					break;
				}
			}
		}
		if (m_IslandFamilyComboBox.SelectedIndex == -1)
		{
			m_IslandFamilyComboBox.SelectedIndex = 0;
		}
		m_IslandPlaceCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotIslandPlace", ref _nReturnValue))
		{
			m_IslandPlaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotIslandParkingWidth", ref _dReturnValue))
		{
			_dReturnValue = 4.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_IslandWidthTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotIslandParkingHeight", ref _dReturnValue))
		{
			_dReturnValue = 0.58333;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_IslandHeightTextBox.Text = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsDistanceBetweenCenterlines", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_strAreaDistanceBetweenCenterlines = _strReturnValue;
		if (!ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsAisleWidth", ref _dReturnValue))
		{
			_dReturnValue = 0.0;
		}
		RevitGeometry.Units_ConvertDoubleToString(_dReturnValue, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strReturnValue);
		m_strAreaAisleWidth = _strReturnValue;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsBiDirectionalAisles", ref _nReturnValue))
		{
			m_bAreaBiDirectionalAisles = Convert.ToBoolean(_nReturnValue);
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsRowSpacingOption", ref _nReturnValue))
		{
			m_nAreaRowSpacingOptions = _nReturnValue;
		}
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotAreaSettingsNumberOfRows", ref _nReturnValue))
		{
			m_nAreaParkingNumberOfRows = _nReturnValue;
		}
		m_ToposurfaceCheckBox.Checked = false;
		if (ApplicationUtility.Settings.eplSetE_GetSetting("ParkingLotPickToposurface", ref _nReturnValue))
		{
			m_ToposurfaceCheckBox.Checked = Convert.ToBoolean(_nReturnValue);
		}
		Parameter parameter = null;
		string text = string.Empty;
		if (m_ParkingLotPlacement.SurfaceList.Count > 0)
		{
			int num5 = 1;
			foreach (TopographySurfaceContainer surface in m_ParkingLotPlacement.SurfaceList)
			{
				parameter = ((Element)surface.TopographySurface).get_Parameter(BuiltInParameter.ROOM_NAME);
				if (parameter != null)
				{
					text = parameter.AsString();
				}
				if (text == null || text == string.Empty)
				{
					text = "<" + EPShared.LocalRM.GetString("UnnamedSurfaceDialog") + " " + Convert.ToString(num5) + ">";
					num5++;
				}
				m_SurfaceList.Items.Add(new ToposurfaceItem(text, surface));
			}
		}
		else
		{
			m_ToposurfaceCheckBox.Checked = false;
			m_ToposurfaceCheckBox.Enabled = false;
			m_SurfaceList.Enabled = false;
		}
		parameter = null;
		text = string.Empty;
		if (ApplicationUtility.Settings.eplSetE_GetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotSurfaceName", ref _strReturnValue))
		{
			for (int num6 = 0; num6 < m_SurfaceList.Items.Count; num6++)
			{
				if (m_SurfaceList.Items[num6] is ToposurfaceItem toposurfaceItem && string.Compare(toposurfaceItem.Name, _strReturnValue, ignoreCase: true) == 0)
				{
					m_SurfaceList.SelectedIndex = num6;
					break;
				}
			}
		}
		if (m_SurfaceList.Items.Count > 0 && m_SurfaceList.SelectedIndex == -1)
		{
			m_SurfaceList.SelectedIndex = 0;
		}
	}

	private void SaveSettings()
	{
		int num = 0;
		double _dReturnedDouble = 0.0;
		m_CurView = m_LevelComboBox.SelectedItem as Autodesk.Revit.DB.View;
		if (m_CurView == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectLevelMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		m_ParkingStallSymbol = m_ParkingNameComboBox.SelectedItem as FamilySymbol;
		if (m_ParkingStallSymbol == null)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("IncorrectFamilySymbolMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
			return;
		}
		if (m_ParkingFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotFamilyName", familyContainer.FamilyName);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotSymbolName", m_ParkingStallSymbol.Name);
		ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotViewName", m_CurView.Name);
		if (RevitGeometry.Units_ConvertStringToDouble(m_ParkingWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotParkingWidth", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_ParkingLengthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotParkingLength", _dReturnedDouble);
		}
		_dReturnedDouble = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_ParkingAngleTextBox.Text);
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotParkingAngle", _dReturnedDouble);
		num = ((!m_ParkingSingleRowRadioButton.Checked) ? (m_ParkingDoubleRowRadioButton.Checked ? 1 : 2) : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotPlacementOption", num);
		num = ((!m_ParkingOptimizeRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotOptimizeByNumberOption", num);
		num = ((!m_ParkingSegmentRadioButton.Checked) ? 1 : 0);
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotOptimizeSegmentChainOption", num);
		if (RevitGeometry.StrE_GetValidWholeNumber(m_ParkingNumberOfSpacesTextBox.Text, ref num))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotNumberOfSpaces", num);
		}
		if (m_ADAFamilyComboBox.SelectedItem is FamilyContainer familyContainer2)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotADAFamilyName", familyContainer2.FamilyName);
		}
		m_ADAParkingStallSymbol = m_ADAFamilyNameComboBox.SelectedItem as FamilySymbol;
		if (m_ADAParkingStallSymbol != null)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotADASymbolName", m_ADAParkingStallSymbol.Name);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADAPlaceParkingSpaces", Convert.ToInt32(m_ADAPlaceParkingSpacesCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_ADAWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADAParkingWidth", _dReturnedDouble);
		}
		if (RevitGeometry.StrE_GetValidWholeNumber(m_ADANumberOfSpacesTextBox.Text, ref num))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADANumberOfSpaces", num);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotADASharedAccessibleAisle", Convert.ToInt32(m_ADASharedAccessibleAisleCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotExistingElement", Convert.ToInt32(m_ExistingElementCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotDeleteExisting", Convert.ToInt32(m_DeleteExistingCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotStartingDistance", _dReturnedDouble);
		}
		if (m_BumperFamilyComboBox.SelectedItem is FamilyContainer familyContainer3)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperFamilyName", familyContainer3.FamilyName);
		}
		m_BumperSymbol = m_BumperFamilyNameComboBox.SelectedItem as FamilySymbol;
		if (m_BumperSymbol != null)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotBumperSymbolName", m_BumperSymbol.Name);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperPlace", Convert.ToInt32(m_BumperPlaceCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperSetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingSetback", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperOffsetTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingOffset", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingWidth", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotBumperParkingHeight", _dReturnedDouble);
		}
		if (m_IslandFamilyComboBox.SelectedItem != null)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandFamilyName", (string)m_IslandFamilyComboBox.SelectedItem);
		}
		if (m_CurFamilyContainer != null && m_IslandFamilyNameComboBox.SelectedItem != null)
		{
			for (int i = 0; i < m_CurFamilyContainer.FamilySymbolList.Count; i++)
			{
				if (string.Compare((string)m_IslandFamilyNameComboBox.SelectedItem, m_CurFamilyContainer.FamilySymbolList[i].Name, ignoreCase: true) == 0)
				{
					m_IslandSymbol = m_CurFamilyContainer.FamilySymbolList[i];
					break;
				}
			}
		}
		else if (m_IslandSymbol != null)
		{
			m_IslandSymbol = null;
		}
		if (m_IslandSymbol != null)
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandSymbolName", m_IslandSymbol.Name);
		}
		else
		{
			ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotIslandSymbolName", string.Empty);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotIslandPlace", Convert.ToInt32(m_IslandPlaceCheckBox.Checked));
		if (RevitGeometry.Units_ConvertStringToDouble(m_IslandWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotIslandParkingWidth", _dReturnedDouble);
		}
		if (RevitGeometry.Units_ConvertStringToDouble(m_IslandHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble, _bDisplayInvalidInputMessage: false))
		{
			ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotIslandParkingHeight", _dReturnedDouble);
		}
		ApplicationUtility.Settings.eplSetE_SetSetting("ParkingLotPickToposurface", Convert.ToInt32(m_ToposurfaceCheckBox.Checked));
		ApplicationUtility.Settings.eplSetE_SetSetting(m_ParkingLotPlacement.Document.PathName, "ParkingLotSurfaceName", Convert.ToString(m_SurfaceList.SelectedItem));
	}

	private void OnParkingOptimizeByNumberOptionChecked(object sender, EventArgs e)
	{
		if (!m_IslandPlaceCheckBox.Checked || m_CurFamilyContainer == null)
		{
			m_ParkingChainRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
			m_ParkingSegmentRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
		}
		else
		{
			m_ParkingChainRadioButton.Enabled = false;
			m_ParkingSegmentRadioButton.Enabled = false;
		}
		m_ParkingNumberOfSpacesLabel.Enabled = !m_ParkingOptimizeRadioButton.Checked;
		m_ParkingNumberOfSpacesTextBox.Enabled = !m_ParkingOptimizeRadioButton.Checked;
	}

	private void OnParkingPlacementOptionsChecked(object sender, EventArgs e)
	{
		m_ParkingAreaSettingsButton.Enabled = m_ParkingAreaRadioButton.Checked;
		if (!m_IslandPlaceCheckBox.Checked || m_CurFamilyContainer == null)
		{
			m_ParkingChainRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
			m_ParkingSegmentRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
		}
		else
		{
			m_ParkingChainRadioButton.Enabled = false;
			m_ParkingSegmentRadioButton.Enabled = false;
		}
	}

	private void OnParkingFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_ParkingFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_ParkingNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_ParkingNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnADAFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_ADAFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_ADAFamilyNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_ADAFamilyNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnBumperFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		if (m_BumperFamilyComboBox.SelectedItem is FamilyContainer familyContainer)
		{
			m_BumperFamilyNameComboBox.DataSource = familyContainer.FamilySymbolList;
			m_BumperFamilyNameComboBox.DisplayMember = EPShared.LocalRM.GetString("NameString");
		}
	}

	private void OnIslandFamilyComboBoxSelectedIndexChanged(object sender, EventArgs e)
	{
		m_CurFamilyContainer = null;
		for (int i = 0; i < m_ParkingLotPlacement.ParkingIslandFamilyList.Count; i++)
		{
			if (string.Compare((string)m_IslandFamilyComboBox.SelectedItem, m_ParkingLotPlacement.ParkingIslandFamilyList[i].FamilyName, ignoreCase: true) == 0)
			{
				m_CurFamilyContainer = m_ParkingLotPlacement.ParkingIslandFamilyList[i];
				break;
			}
		}
		m_IslandFamilyNameComboBox.Items.Clear();
		if (m_CurFamilyContainer != null)
		{
			if (m_CurFamilyContainer.FamilySymbolList.Count > 0)
			{
				for (int j = 0; j < m_CurFamilyContainer.FamilySymbolList.Count; j++)
				{
					m_IslandFamilyNameComboBox.Items.Add(m_CurFamilyContainer.FamilySymbolList[j].Name);
				}
				m_IslandFamilyNameComboBox.SelectedIndex = 0;
			}
			m_IslandFamilyNameLabel.Enabled = m_IslandPlaceCheckBox.Checked;
			m_IslandFamilyNameComboBox.Enabled = m_IslandPlaceCheckBox.Checked;
			m_IslandHeightLabel.Enabled = m_IslandPlaceCheckBox.Checked;
			m_IslandHeightTextBox.Enabled = m_IslandPlaceCheckBox.Checked;
			m_ParkingChainRadioButton.Enabled = false;
			m_ParkingSegmentRadioButton.Enabled = false;
		}
		else
		{
			m_IslandFamilyNameLabel.Enabled = false;
			m_IslandFamilyNameComboBox.Enabled = false;
			m_IslandHeightLabel.Enabled = false;
			m_IslandHeightTextBox.Enabled = false;
			m_ParkingChainRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
			m_ParkingSegmentRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
		}
	}

	private void OnCancelButtonClick(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
		Close();
	}

	private void FormatParkingAngleValue()
	{
		string _strAngleStr = string.Empty;
		double num = 0.0;
		num = RevitGeometry.eplGeoE_ConvertAngleToRadians(m_ParkingAngleTextBox.Text);
		if (RevitGeometry.eplStrE_ConvertRadiansToAngleStr(m_AngularOptions.LegacyDisplayUnits(), num, m_dAngularRounding, m_AngularSymbolType, m_DecimalSymbolType, ref _strAngleStr) == 0)
		{
			m_ParkingAngleTextBox.Text = _strAngleStr;
		}
	}

	private void OnParkingAngleTextBoxLeave(object sender, EventArgs e)
	{
		FormatParkingAngleValue();
	}

	private void FormatParkingWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_ParkingWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_ParkingWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_ParkingWidthTextBox);
		}
	}

	private void OnParkingWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatParkingWidthValue();
	}

	private void FormatParkingLengthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_ParkingLengthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_ParkingLengthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_ParkingLengthTextBox);
		}
	}

	private void OnParkingLengthTextBoxLeave(object sender, EventArgs e)
	{
		FormatParkingLengthValue();
	}

	private void FormatADAParkingWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_ADAWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_ADAWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_ADAWidthTextBox);
		}
	}

	private void OnADAParkingWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatADAParkingWidthValue();
	}

	private void FormatBumperSetbackValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperSetbackTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_BumperSetbackTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_BumperSetbackTextBox);
		}
	}

	private void OnBumperSetbackTextBoxLeave(object sender, EventArgs e)
	{
		FormatBumperSetbackValue();
	}

	private void FormatBumperOffsetValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperOffsetTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_BumperOffsetTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_BumperOffsetTextBox);
		}
	}

	private void OnBumperOffsetTextBoxLeave(object sender, EventArgs e)
	{
		FormatBumperOffsetValue();
	}

	private void FormatBumperWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_BumperWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_BumperWidthTextBox);
		}
	}

	private void OnBumperWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatBumperWidthValue();
	}

	private void FormatBumperHeightValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_BumperHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_BumperHeightTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_BumperHeightTextBox);
		}
	}

	private void OnBumperHeightTextBoxLeave(object sender, EventArgs e)
	{
		FormatBumperHeightValue();
	}

	private void FormatIslandWidthValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_IslandWidthTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_IslandWidthTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_IslandWidthTextBox);
		}
	}

	private void OnIslandWidthTextBoxLeave(object sender, EventArgs e)
	{
		FormatIslandWidthValue();
	}

	private void FormatIslandHeightValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_IslandHeightTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_IslandHeightTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_IslandHeightTextBox);
		}
	}

	private void OnIslandHeightTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatIslandHeightValue();
		}
	}

	private void OnIslandHeightTextBoxLeave(object sender, EventArgs e)
	{
		FormatIslandHeightValue();
	}

	private void OnParkingLengthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatParkingLengthValue();
		}
	}

	private void OnParkingWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatParkingWidthValue();
		}
	}

	private void OnParkingAngleTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatParkingAngleValue();
		}
	}

	private void OnADAParkingWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatADAParkingWidthValue();
		}
	}

	private void OnBumperSetbackTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatBumperSetbackValue();
		}
	}

	private void OnBumperOffsetTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatBumperOffsetValue();
		}
	}

	private void OnBumperWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatBumperWidthValue();
		}
	}

	private void OnBumperHeightTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatBumperHeightValue();
		}
	}

	private void OnIslandWidthTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Return)
		{
			e.Handled = true;
			FormatIslandWidthValue();
		}
	}

	private void OnIslandPlaceCheckBoxChecked(object sender, EventArgs e)
	{
		m_IslandFamilyLabel.Enabled = m_IslandPlaceCheckBox.Checked;
		m_IslandFamilyComboBox.Enabled = m_IslandPlaceCheckBox.Checked;
		m_IslandWidthLabel.Enabled = m_IslandPlaceCheckBox.Checked;
		m_IslandWidthTextBox.Enabled = m_IslandPlaceCheckBox.Checked;
		if (m_IslandPlaceCheckBox.Checked && m_CurFamilyContainer != null)
		{
			m_IslandFamilyNameLabel.Enabled = m_IslandPlaceCheckBox.Checked;
			m_IslandFamilyNameComboBox.Enabled = m_IslandPlaceCheckBox.Checked;
			m_IslandHeightLabel.Enabled = m_IslandPlaceCheckBox.Checked;
			m_IslandHeightTextBox.Enabled = m_IslandPlaceCheckBox.Checked;
			m_ParkingChainRadioButton.Enabled = false;
			m_ParkingSegmentRadioButton.Enabled = false;
		}
		else
		{
			m_IslandFamilyNameLabel.Enabled = false;
			m_IslandFamilyNameComboBox.Enabled = false;
			m_IslandHeightLabel.Enabled = false;
			m_IslandHeightTextBox.Enabled = false;
			m_ParkingChainRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
			m_ParkingSegmentRadioButton.Enabled = !m_ParkingAreaRadioButton.Checked && m_ParkingOptimizeRadioButton.Checked;
		}
	}

	private void OnBumperPlaceCheckBoxChecked(object sender, EventArgs e)
	{
		m_BumperFamilyLabel.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperFamilyComboBox.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperFamilyNameLabel.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperFamilyNameComboBox.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperSetbackLabel.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperSetbackTextBox.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperOffsetLabel.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperOffsetTextBox.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperWidthLabel.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperWidthTextBox.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperHeightLabel.Enabled = m_BumperPlaceCheckBox.Checked;
		m_BumperHeightTextBox.Enabled = m_BumperPlaceCheckBox.Checked;
	}

	private void OnADAPlaceParkingSpacesCheckBoxChecked(object sender, EventArgs e)
	{
		m_ADAFamilyLabel.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADAFamilyComboBox.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADAFamilyNameLabel.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADAFamilyNameComboBox.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADAWidthLabel.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADAWidthTextBox.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADANumberOfSpacesLabel.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADANumberOfSpacesTextBox.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
		m_ADASharedAccessibleAisleCheckBox.Enabled = m_ADAPlaceParkingSpacesCheckBox.Checked;
	}

	private void OnInsertButtonClick(object sender, EventArgs e)
	{
		SaveSettings();
		DialogResult = DialogResult.OK;
		Close();
	}

	private void OnParkingAreaSettingsButtonClick(object sender, EventArgs e)
	{
		using ParkingLotAreaSettingsForm parkingLotAreaSettingsForm = new ParkingLotAreaSettingsForm(m_ParkingLotPlacement.Document);
		parkingLotAreaSettingsForm.DistanceBetweenCenterlines = m_strAreaDistanceBetweenCenterlines;
		parkingLotAreaSettingsForm.AisleWidth = m_strAreaAisleWidth;
		parkingLotAreaSettingsForm.BiDirectionalAisles = m_bAreaBiDirectionalAisles;
		parkingLotAreaSettingsForm.RowSpacingOptions = m_nAreaRowSpacingOptions;
		parkingLotAreaSettingsForm.ParkingNumberOfRows = m_nAreaParkingNumberOfRows;
		if (parkingLotAreaSettingsForm.ShowDialog() != DialogResult.Cancel)
		{
			m_strAreaDistanceBetweenCenterlines = parkingLotAreaSettingsForm.DistanceBetweenCenterlines;
			m_strAreaAisleWidth = parkingLotAreaSettingsForm.AisleWidth;
			m_bAreaBiDirectionalAisles = parkingLotAreaSettingsForm.BiDirectionalAisles;
			m_nAreaRowSpacingOptions = parkingLotAreaSettingsForm.RowSpacingOptions;
			m_nAreaParkingNumberOfRows = parkingLotAreaSettingsForm.ParkingNumberOfRows;
		}
	}

	private void OnParkingLotPlacementFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void LoadFamilyFilePicker(LandcaddID _ParkingType)
	{
		string text = string.Empty;
		int num = 0;
		int num2 = 0;
		switch (_ParkingType)
		{
		case LandcaddID.ParkingStall:
			num2 = m_ParkingFamilyComboBox.Items.Count;
			text = EPShared.LocalRM.GetString("LoadParkingFamilyTransaction");
			break;
		case LandcaddID.ADAParkingStall:
			num2 = m_ADAFamilyComboBox.Items.Count;
			text = EPShared.LocalRM.GetString("LoadADAParkingFamilyTransaction");
			break;
		case LandcaddID.ParkingBumper:
			num2 = m_BumperFamilyComboBox.Items.Count;
			text = EPShared.LocalRM.GetString("LoadParkingBumperFamilyTransaction");
			break;
		case LandcaddID.ParkingIsland:
			num2 = m_IslandFamilyComboBox.Items.Count;
			text = EPShared.LocalRM.GetString("LoadParkingIslandFamilyTransaction");
			break;
		}
		using OpenFileDialog openFileDialog = new OpenFileDialog();
		string _strLibraryPath = string.Empty;
		FamilyContainer familyContainer = null;
		Family _Family = null;
		openFileDialog.Title = "Please select Parking Family File.";
		openFileDialog.RestoreDirectory = true;
		openFileDialog.Filter = ApplicationUtility.GetString("FamilyFilePickerFilter");
		if (ApplicationUtility.RegistryPaths.GetLibraryPath(string.Empty, ref _strLibraryPath) == 0)
		{
			openFileDialog.InitialDirectory = _strLibraryPath;
		}
		bool flag = false;
		DialogResult dialogResult = DialogResult.OK;
		while (dialogResult != DialogResult.Cancel)
		{
			dialogResult = openFileDialog.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				try
				{
					m_ParkingLotPlacement.TransactionContainer.Start(text + openFileDialog.SafeFileName);
					EPTransactionContainer _TransactionContainer = m_ParkingLotPlacement.TransactionContainer;
					flag = RevitUtility.LoadFamily(m_ParkingLotPlacement.Document, openFileDialog.FileName, out _Family, _bUseFailureHandling: true, ref _TransactionContainer);
					m_ParkingLotPlacement.TransactionContainer = _TransactionContainer;
					m_ParkingLotPlacement.TransactionContainer.Commit();
				}
				catch (SEHException)
				{
					m_ParkingLotPlacement.TransactionContainer.Rollback();
					flag = false;
					RevitMessageBox.Show(EPShared.LocalRM.GetString("ParkingFamilyCantBeLoadedMessage") + Convert.ToInt32(_ParkingType).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyFileMessage"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					continue;
				}
				break;
			}
		}
		if (!flag)
		{
			if (num2 == 0)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("ParkingFamilyNotLoadedMessage") + Convert.ToInt32(_ParkingType).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyNotLoadedMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
			}
			return;
		}
		m_ParkingLotPlacement.PopulateFamilyAndSymbolLists(_ParkingType);
		switch (_ParkingType)
		{
		case LandcaddID.ParkingStall:
			m_ParkingFamilyComboBox.DataSource = m_ParkingLotPlacement.ParkingStallFamilyList;
			m_ParkingFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
			if (_Family != null)
			{
				for (int k = 0; k < m_ParkingFamilyComboBox.Items.Count; k++)
				{
					if (m_ParkingFamilyComboBox.Items[k] is FamilyContainer familyContainer3 && string.Compare(familyContainer3.FamilyName, _Family.Name, ignoreCase: true) == 0)
					{
						m_ParkingFamilyComboBox.SelectedIndex = k;
						break;
					}
				}
			}
			num = m_ParkingFamilyComboBox.Items.Count;
			break;
		case LandcaddID.ADAParkingStall:
			m_ADAFamilyComboBox.DataSource = m_ParkingLotPlacement.ADAParkingStallFamilyList;
			m_ADAFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
			if (_Family != null)
			{
				for (int j = 0; j < m_ADAFamilyComboBox.Items.Count; j++)
				{
					if (m_ADAFamilyComboBox.Items[j] is FamilyContainer familyContainer2 && string.Compare(familyContainer2.FamilyName, _Family.Name, ignoreCase: true) == 0)
					{
						m_ADAFamilyComboBox.SelectedIndex = j;
						break;
					}
				}
			}
			num = m_ADAFamilyComboBox.Items.Count;
			break;
		case LandcaddID.ParkingBumper:
			m_BumperFamilyComboBox.DataSource = m_ParkingLotPlacement.ParkingBumperFamilyList;
			m_BumperFamilyComboBox.DisplayMember = EPShared.LocalRM.GetString("FamilyNameString");
			if (_Family != null)
			{
				for (int l = 0; l < m_BumperFamilyComboBox.Items.Count; l++)
				{
					if (m_BumperFamilyComboBox.Items[l] is FamilyContainer familyContainer4 && string.Compare(familyContainer4.FamilyName, _Family.Name, ignoreCase: true) == 0)
					{
						m_BumperFamilyComboBox.SelectedIndex = l;
						break;
					}
				}
			}
			num = m_BumperFamilyComboBox.Items.Count;
			break;
		case LandcaddID.ParkingIsland:
		{
			m_IslandFamilyComboBox.Items.Clear();
			m_IslandFamilyComboBox.Items.Add("<Empty Space>");
			for (int i = 0; i < m_ParkingLotPlacement.ParkingIslandFamilyList.Count; i++)
			{
				m_IslandFamilyComboBox.Items.Add(m_ParkingLotPlacement.ParkingIslandFamilyList[i].FamilyName);
				if (_Family != null && string.Compare(m_ParkingLotPlacement.ParkingIslandFamilyList[i].FamilyName, _Family.Name, ignoreCase: true) == 0)
				{
					m_IslandFamilyComboBox.SelectedIndex = i;
				}
			}
			num = m_IslandFamilyComboBox.Items.Count;
			break;
		}
		}
		if (num == num2)
		{
			RevitMessageBox.Show(EPShared.LocalRM.GetString("FamilyNotParkingMessage") + Convert.ToInt32(_ParkingType).ToString("000") + EPShared.LocalRM.GetString("TypeParameterFamilyMessage"), EPShared.LocalRM.GetString("Warning"), MessageBoxIcon.Exclamation);
		}
	}

	private void OnLoadIslandFamilyButtonClick(object sender, EventArgs e)
	{
		LoadFamilyFilePicker(LandcaddID.ParkingIsland);
	}

	private void OnLoadBumperFamilyButtonClick(object sender, EventArgs e)
	{
		LoadFamilyFilePicker(LandcaddID.ParkingBumper);
	}

	private void OnLoadADAFamilyButtonClick(object sender, EventArgs e)
	{
		LoadFamilyFilePicker(LandcaddID.ADAParkingStall);
	}

	private void OnLoadParkingFamilyButtonClick(object sender, EventArgs e)
	{
		LoadFamilyFilePicker(LandcaddID.ParkingStall);
	}

	private void OnExistingElementCheckBoxChecked(object sender, EventArgs e)
	{
		m_DeleteExistingCheckBox.Enabled = m_ExistingElementCheckBox.Checked;
		m_StartingDistanceLabel.Enabled = m_ExistingElementCheckBox.Checked;
		m_StartingDistanceTextBox.Enabled = m_ExistingElementCheckBox.Checked;
	}

	private void OnStartingDistanceTextBoxKeyDown(object sender, KeyEventArgs e)
	{
		if (e.KeyData == Keys.Return)
		{
			FormatStartingDistanceValue();
		}
	}

	private void OnStartingDistanceTextBoxLeave(object sender, EventArgs e)
	{
		FormatStartingDistanceValue();
	}

	private void FormatStartingDistanceValue()
	{
		string _strToDisplay = string.Empty;
		double _dReturnedDouble = 0.0;
		if (RevitGeometry.Units_ConvertStringToDouble(m_StartingDistanceTextBox.Text, m_Units, UnitType.UT_Length, ref _dReturnedDouble))
		{
			RevitGeometry.Units_ConvertDoubleToString(_dReturnedDouble, m_LengthFormatOptions.LegacyDisplayUnits(), m_LengthFormatOptions.Accuracy, m_LengthUnitSymbolType, m_Units, ref _strToDisplay);
			m_StartingDistanceTextBox.Text = _strToDisplay;
		}
		else
		{
			SiteDesigner.UI.WpfFocus.Focus(m_StartingDistanceTextBox);
		}
	}

	private void OnToposurfaceCheckBoxCheckedChanged(object sender, EventArgs e)
	{
		m_SurfaceList.Enabled = m_ToposurfaceCheckBox.Checked;
		m_SelectedSurfaceLabel.Enabled = m_ToposurfaceCheckBox.Checked;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ParkingSpaceTabPage = new System.Windows.Forms.TabPage();
		this.m_LoadParkingFamilyButton = new System.Windows.Forms.Button();
		this.m_ParkingPlacementGroupBox = new System.Windows.Forms.GroupBox();
		this.m_ParkingAreaSettingsButton = new System.Windows.Forms.Button();
		this.m_ParkingAreaRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ParkingDoubleRowRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ParkingSingleRowRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ParkingLengthTextBox = new System.Windows.Forms.TextBox();
		this.m_ParkingLengthLabel = new System.Windows.Forms.Label();
		this.m_ParkingAngleLabel = new System.Windows.Forms.Label();
		this.m_ParkingAngleTextBox = new System.Windows.Forms.TextBox();
		this.m_ParkingWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_ParkingWidthLabel = new System.Windows.Forms.Label();
		this.m_ParkingNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_ParkingNameLabel = new System.Windows.Forms.Label();
		this.m_ParkingFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_ParkingFamilyLabel = new System.Windows.Forms.Label();
		this.m_LevelComboBox = new System.Windows.Forms.ComboBox();
		this.m_LevelLabel = new System.Windows.Forms.Label();
		this.m_ParkingLotTabControl = new System.Windows.Forms.TabControl();
		this.m_ADASpaceTabPage = new System.Windows.Forms.TabPage();
		this.m_ADASharedAccessibleAisleCheckBox = new System.Windows.Forms.CheckBox();
		this.m_LoadADAFamilyButton = new System.Windows.Forms.Button();
		this.m_ADAPlaceParkingSpacesCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ADANumberOfSpacesTextBox = new System.Windows.Forms.TextBox();
		this.m_ADANumberOfSpacesLabel = new System.Windows.Forms.Label();
		this.m_ADAWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_ADAWidthLabel = new System.Windows.Forms.Label();
		this.m_ADAFamilyNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_ADAFamilyNameLabel = new System.Windows.Forms.Label();
		this.m_ADAFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_ADAFamilyLabel = new System.Windows.Forms.Label();
		this.m_BumperTabPage = new System.Windows.Forms.TabPage();
		this.m_LoadBumperFamilyButton = new System.Windows.Forms.Button();
		this.m_BumperHeightTextBox = new System.Windows.Forms.TextBox();
		this.m_BumperHeightLabel = new System.Windows.Forms.Label();
		this.m_BumperOffsetTextBox = new System.Windows.Forms.TextBox();
		this.m_BumperOffsetLabel = new System.Windows.Forms.Label();
		this.m_BumperSetbackTextBox = new System.Windows.Forms.TextBox();
		this.m_BumperSetbackLabel = new System.Windows.Forms.Label();
		this.m_BumperPlaceCheckBox = new System.Windows.Forms.CheckBox();
		this.m_BumperWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_BumperWidthLabel = new System.Windows.Forms.Label();
		this.m_BumperFamilyNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_BumperFamilyNameLabel = new System.Windows.Forms.Label();
		this.m_BumperFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_BumperFamilyLabel = new System.Windows.Forms.Label();
		this.m_IslandTabPage = new System.Windows.Forms.TabPage();
		this.m_LoadIslandFamilyButton = new System.Windows.Forms.Button();
		this.m_IslandHeightTextBox = new System.Windows.Forms.TextBox();
		this.m_IslandHeightLabel = new System.Windows.Forms.Label();
		this.m_IslandPlaceCheckBox = new System.Windows.Forms.CheckBox();
		this.m_IslandWidthTextBox = new System.Windows.Forms.TextBox();
		this.m_IslandWidthLabel = new System.Windows.Forms.Label();
		this.m_IslandFamilyNameComboBox = new System.Windows.Forms.ComboBox();
		this.m_IslandFamilyNameLabel = new System.Windows.Forms.Label();
		this.m_IslandFamilyComboBox = new System.Windows.Forms.ComboBox();
		this.m_IslandFamilyLabel = new System.Windows.Forms.Label();
		this.m_ParkingNumberOfSpacesTextBox = new System.Windows.Forms.TextBox();
		this.m_ParkingNumberOfSpacesLabel = new System.Windows.Forms.Label();
		this.m_ParkingByNumberRadioButton = new System.Windows.Forms.RadioButton();
		this.m_OptimizePanel = new System.Windows.Forms.Panel();
		this.m_ParkingChainRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ParkingSegmentRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ParkingOptimizeRadioButton = new System.Windows.Forms.RadioButton();
		this.m_ExistingElementCheckBox = new System.Windows.Forms.CheckBox();
		this.m_MoveablePanel = new System.Windows.Forms.Panel();
		this.m_StartingDistanceLabel = new System.Windows.Forms.Label();
		this.m_StartingDistanceTextBox = new System.Windows.Forms.TextBox();
		this.m_DeleteExistingCheckBox = new System.Windows.Forms.CheckBox();
		this.m_InsertButton = new System.Windows.Forms.Button();
		this.m_CancelButton = new System.Windows.Forms.Button();
		this.m_ToposurfacePickerPanel = new System.Windows.Forms.Panel();
		this.m_SurfaceList = new System.Windows.Forms.ComboBox();
		this.m_SelectedSurfaceLabel = new System.Windows.Forms.Label();
		this.m_ToposurfaceCheckBox = new System.Windows.Forms.CheckBox();
		this.m_ParkingSpaceTabPage.SuspendLayout();
		this.m_ParkingPlacementGroupBox.SuspendLayout();
		this.m_ParkingLotTabControl.SuspendLayout();
		this.m_ADASpaceTabPage.SuspendLayout();
		this.m_BumperTabPage.SuspendLayout();
		this.m_IslandTabPage.SuspendLayout();
		this.m_OptimizePanel.SuspendLayout();
		this.m_MoveablePanel.SuspendLayout();
		this.m_ToposurfacePickerPanel.SuspendLayout();
		base.SuspendLayout();
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_LoadParkingFamilyButton);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingPlacementGroupBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingLengthTextBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingLengthLabel);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingAngleLabel);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingAngleTextBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingWidthTextBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingWidthLabel);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingNameComboBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingNameLabel);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingFamilyComboBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_ParkingFamilyLabel);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_LevelComboBox);
		this.m_ParkingSpaceTabPage.Controls.Add(this.m_LevelLabel);
		this.m_ParkingSpaceTabPage.Location = new System.Drawing.Point(4, 22);
		this.m_ParkingSpaceTabPage.Name = "m_ParkingSpaceTabPage";
		this.m_ParkingSpaceTabPage.Padding = new System.Windows.Forms.Padding(3);
		this.m_ParkingSpaceTabPage.Size = new System.Drawing.Size(412, 193);
		this.m_ParkingSpaceTabPage.TabIndex = 0;
		this.m_ParkingSpaceTabPage.Text = "Parking Style";
		this.m_ParkingSpaceTabPage.UseVisualStyleBackColor = true;
		this.m_LoadParkingFamilyButton.Location = new System.Drawing.Point(324, 61);
		this.m_LoadParkingFamilyButton.Name = "m_LoadParkingFamilyButton";
		this.m_LoadParkingFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadParkingFamilyButton.TabIndex = 4;
		this.m_LoadParkingFamilyButton.TabStop = false;
		this.m_LoadParkingFamilyButton.Text = "...";
		this.m_LoadParkingFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadParkingFamilyButton.Click += new System.EventHandler(this.OnLoadParkingFamilyButtonClick);
		this.m_ParkingPlacementGroupBox.Controls.Add(this.m_ParkingAreaSettingsButton);
		this.m_ParkingPlacementGroupBox.Controls.Add(this.m_ParkingAreaRadioButton);
		this.m_ParkingPlacementGroupBox.Controls.Add(this.m_ParkingDoubleRowRadioButton);
		this.m_ParkingPlacementGroupBox.Controls.Add(this.m_ParkingSingleRowRadioButton);
		this.m_ParkingPlacementGroupBox.Location = new System.Drawing.Point(6, 6);
		this.m_ParkingPlacementGroupBox.Name = "m_ParkingPlacementGroupBox";
		this.m_ParkingPlacementGroupBox.Size = new System.Drawing.Size(400, 48);
		this.m_ParkingPlacementGroupBox.TabIndex = 1;
		this.m_ParkingPlacementGroupBox.TabStop = false;
		this.m_ParkingPlacementGroupBox.Text = "Parking Placement";
		this.m_ParkingAreaSettingsButton.Enabled = false;
		this.m_ParkingAreaSettingsButton.Location = new System.Drawing.Point(318, 16);
		this.m_ParkingAreaSettingsButton.Name = "m_ParkingAreaSettingsButton";
		this.m_ParkingAreaSettingsButton.Size = new System.Drawing.Size(75, 23);
		this.m_ParkingAreaSettingsButton.TabIndex = 3;
		this.m_ParkingAreaSettingsButton.Text = "Se&ttings";
		this.m_ParkingAreaSettingsButton.UseVisualStyleBackColor = true;
		this.m_ParkingAreaSettingsButton.Click += new System.EventHandler(this.OnParkingAreaSettingsButtonClick);
		this.m_ParkingAreaRadioButton.AutoSize = true;
		this.m_ParkingAreaRadioButton.Location = new System.Drawing.Point(239, 19);
		this.m_ParkingAreaRadioButton.Name = "m_ParkingAreaRadioButton";
		this.m_ParkingAreaRadioButton.Size = new System.Drawing.Size(47, 17);
		this.m_ParkingAreaRadioButton.TabIndex = 2;
		this.m_ParkingAreaRadioButton.TabStop = true;
		this.m_ParkingAreaRadioButton.Text = "&Area";
		this.m_ParkingAreaRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingAreaRadioButton.CheckedChanged += new System.EventHandler(this.OnParkingPlacementOptionsChecked);
		this.m_ParkingDoubleRowRadioButton.AutoSize = true;
		this.m_ParkingDoubleRowRadioButton.Location = new System.Drawing.Point(113, 19);
		this.m_ParkingDoubleRowRadioButton.Name = "m_ParkingDoubleRowRadioButton";
		this.m_ParkingDoubleRowRadioButton.Size = new System.Drawing.Size(84, 17);
		this.m_ParkingDoubleRowRadioButton.TabIndex = 1;
		this.m_ParkingDoubleRowRadioButton.TabStop = true;
		this.m_ParkingDoubleRowRadioButton.Text = "&Double Row";
		this.m_ParkingDoubleRowRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingDoubleRowRadioButton.CheckedChanged += new System.EventHandler(this.OnParkingPlacementOptionsChecked);
		this.m_ParkingSingleRowRadioButton.AutoSize = true;
		this.m_ParkingSingleRowRadioButton.Location = new System.Drawing.Point(6, 19);
		this.m_ParkingSingleRowRadioButton.Name = "m_ParkingSingleRowRadioButton";
		this.m_ParkingSingleRowRadioButton.Size = new System.Drawing.Size(79, 17);
		this.m_ParkingSingleRowRadioButton.TabIndex = 0;
		this.m_ParkingSingleRowRadioButton.TabStop = true;
		this.m_ParkingSingleRowRadioButton.Text = "&Single Row";
		this.m_ParkingSingleRowRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingSingleRowRadioButton.CheckedChanged += new System.EventHandler(this.OnParkingPlacementOptionsChecked);
		this.m_ParkingLengthTextBox.Location = new System.Drawing.Point(99, 141);
		this.m_ParkingLengthTextBox.Name = "m_ParkingLengthTextBox";
		this.m_ParkingLengthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ParkingLengthTextBox.TabIndex = 10;
		this.m_ParkingLengthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnParkingLengthTextBoxKeyDown);
		this.m_ParkingLengthTextBox.Leave += new System.EventHandler(this.OnParkingLengthTextBoxLeave);
		this.m_ParkingLengthLabel.AutoSize = true;
		this.m_ParkingLengthLabel.Location = new System.Drawing.Point(6, 144);
		this.m_ParkingLengthLabel.Name = "m_ParkingLengthLabel";
		this.m_ParkingLengthLabel.Size = new System.Drawing.Size(43, 13);
		this.m_ParkingLengthLabel.TabIndex = 9;
		this.m_ParkingLengthLabel.Text = "&Length:";
		this.m_ParkingAngleLabel.AutoSize = true;
		this.m_ParkingAngleLabel.Location = new System.Drawing.Point(216, 144);
		this.m_ParkingAngleLabel.Name = "m_ParkingAngleLabel";
		this.m_ParkingAngleLabel.Size = new System.Drawing.Size(37, 13);
		this.m_ParkingAngleLabel.TabIndex = 11;
		this.m_ParkingAngleLabel.Text = "Angle:";
		this.m_ParkingAngleTextBox.Location = new System.Drawing.Point(299, 141);
		this.m_ParkingAngleTextBox.Name = "m_ParkingAngleTextBox";
		this.m_ParkingAngleTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ParkingAngleTextBox.TabIndex = 12;
		this.m_ParkingAngleTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnParkingAngleTextBoxKeyDown);
		this.m_ParkingAngleTextBox.Leave += new System.EventHandler(this.OnParkingAngleTextBoxLeave);
		this.m_ParkingWidthTextBox.Location = new System.Drawing.Point(99, 167);
		this.m_ParkingWidthTextBox.Name = "m_ParkingWidthTextBox";
		this.m_ParkingWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ParkingWidthTextBox.TabIndex = 0;
		this.m_ParkingWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnParkingWidthTextBoxKeyDown);
		this.m_ParkingWidthTextBox.Leave += new System.EventHandler(this.OnParkingWidthTextBoxLeave);
		this.m_ParkingWidthLabel.AutoSize = true;
		this.m_ParkingWidthLabel.Location = new System.Drawing.Point(6, 170);
		this.m_ParkingWidthLabel.Name = "m_ParkingWidthLabel";
		this.m_ParkingWidthLabel.Size = new System.Drawing.Size(38, 13);
		this.m_ParkingWidthLabel.TabIndex = 13;
		this.m_ParkingWidthLabel.Text = "&Width:";
		this.m_ParkingNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ParkingNameComboBox.FormattingEnabled = true;
		this.m_ParkingNameComboBox.Location = new System.Drawing.Point(99, 87);
		this.m_ParkingNameComboBox.Name = "m_ParkingNameComboBox";
		this.m_ParkingNameComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_ParkingNameComboBox.TabIndex = 6;
		this.m_ParkingNameLabel.AutoSize = true;
		this.m_ParkingNameLabel.Location = new System.Drawing.Point(6, 90);
		this.m_ParkingNameLabel.Name = "m_ParkingNameLabel";
		this.m_ParkingNameLabel.Size = new System.Drawing.Size(38, 13);
		this.m_ParkingNameLabel.TabIndex = 5;
		this.m_ParkingNameLabel.Text = "&Name:";
		this.m_ParkingFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ParkingFamilyComboBox.FormattingEnabled = true;
		this.m_ParkingFamilyComboBox.Location = new System.Drawing.Point(99, 60);
		this.m_ParkingFamilyComboBox.Name = "m_ParkingFamilyComboBox";
		this.m_ParkingFamilyComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_ParkingFamilyComboBox.TabIndex = 3;
		this.m_ParkingFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnParkingFamilyComboBoxSelectedIndexChanged);
		this.m_ParkingFamilyLabel.AutoSize = true;
		this.m_ParkingFamilyLabel.Location = new System.Drawing.Point(6, 63);
		this.m_ParkingFamilyLabel.Name = "m_ParkingFamilyLabel";
		this.m_ParkingFamilyLabel.Size = new System.Drawing.Size(39, 13);
		this.m_ParkingFamilyLabel.TabIndex = 2;
		this.m_ParkingFamilyLabel.Text = "&Family:";
		this.m_LevelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_LevelComboBox.FormattingEnabled = true;
		this.m_LevelComboBox.Location = new System.Drawing.Point(99, 114);
		this.m_LevelComboBox.Name = "m_LevelComboBox";
		this.m_LevelComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_LevelComboBox.TabIndex = 8;
		this.m_LevelLabel.AutoSize = true;
		this.m_LevelLabel.Location = new System.Drawing.Point(6, 117);
		this.m_LevelLabel.Name = "m_LevelLabel";
		this.m_LevelLabel.Size = new System.Drawing.Size(36, 13);
		this.m_LevelLabel.TabIndex = 7;
		this.m_LevelLabel.Text = "&Level:";
		this.m_ParkingLotTabControl.Controls.Add(this.m_ParkingSpaceTabPage);
		this.m_ParkingLotTabControl.Controls.Add(this.m_ADASpaceTabPage);
		this.m_ParkingLotTabControl.Controls.Add(this.m_BumperTabPage);
		this.m_ParkingLotTabControl.Controls.Add(this.m_IslandTabPage);
		this.m_ParkingLotTabControl.ItemSize = new System.Drawing.Size(58, 18);
		this.m_ParkingLotTabControl.Location = new System.Drawing.Point(12, 12);
		this.m_ParkingLotTabControl.Name = "m_ParkingLotTabControl";
		this.m_ParkingLotTabControl.SelectedIndex = 0;
		this.m_ParkingLotTabControl.Size = new System.Drawing.Size(420, 219);
		this.m_ParkingLotTabControl.TabIndex = 0;
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADASharedAccessibleAisleCheckBox);
		this.m_ADASpaceTabPage.Controls.Add(this.m_LoadADAFamilyButton);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAPlaceParkingSpacesCheckBox);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADANumberOfSpacesTextBox);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADANumberOfSpacesLabel);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAWidthTextBox);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAWidthLabel);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAFamilyNameComboBox);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAFamilyNameLabel);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAFamilyComboBox);
		this.m_ADASpaceTabPage.Controls.Add(this.m_ADAFamilyLabel);
		this.m_ADASpaceTabPage.Location = new System.Drawing.Point(4, 22);
		this.m_ADASpaceTabPage.Name = "m_ADASpaceTabPage";
		this.m_ADASpaceTabPage.Padding = new System.Windows.Forms.Padding(3);
		this.m_ADASpaceTabPage.Size = new System.Drawing.Size(412, 193);
		this.m_ADASpaceTabPage.TabIndex = 1;
		this.m_ADASpaceTabPage.Text = "ADA Spacing";
		this.m_ADASpaceTabPage.UseVisualStyleBackColor = true;
		this.m_ADASharedAccessibleAisleCheckBox.AutoSize = true;
		this.m_ADASharedAccessibleAisleCheckBox.Enabled = false;
		this.m_ADASharedAccessibleAisleCheckBox.Location = new System.Drawing.Point(6, 136);
		this.m_ADASharedAccessibleAisleCheckBox.Name = "m_ADASharedAccessibleAisleCheckBox";
		this.m_ADASharedAccessibleAisleCheckBox.Size = new System.Drawing.Size(139, 17);
		this.m_ADASharedAccessibleAisleCheckBox.TabIndex = 10;
		this.m_ADASharedAccessibleAisleCheckBox.Text = "S&hared Accessible Aisle";
		this.m_ADASharedAccessibleAisleCheckBox.UseVisualStyleBackColor = true;
		this.m_LoadADAFamilyButton.Location = new System.Drawing.Point(368, 31);
		this.m_LoadADAFamilyButton.Name = "m_LoadADAFamilyButton";
		this.m_LoadADAFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadADAFamilyButton.TabIndex = 3;
		this.m_LoadADAFamilyButton.TabStop = false;
		this.m_LoadADAFamilyButton.Text = "...";
		this.m_LoadADAFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadADAFamilyButton.Click += new System.EventHandler(this.OnLoadADAFamilyButtonClick);
		this.m_ADAPlaceParkingSpacesCheckBox.AutoSize = true;
		this.m_ADAPlaceParkingSpacesCheckBox.Location = new System.Drawing.Point(7, 7);
		this.m_ADAPlaceParkingSpacesCheckBox.Name = "m_ADAPlaceParkingSpacesCheckBox";
		this.m_ADAPlaceParkingSpacesCheckBox.Size = new System.Drawing.Size(156, 17);
		this.m_ADAPlaceParkingSpacesCheckBox.TabIndex = 0;
		this.m_ADAPlaceParkingSpacesCheckBox.Text = "Place &ADA Parking Spaces";
		this.m_ADAPlaceParkingSpacesCheckBox.UseVisualStyleBackColor = true;
		this.m_ADAPlaceParkingSpacesCheckBox.CheckStateChanged += new System.EventHandler(this.OnADAPlaceParkingSpacesCheckBoxChecked);
		this.m_ADANumberOfSpacesTextBox.Enabled = false;
		this.m_ADANumberOfSpacesTextBox.Location = new System.Drawing.Point(143, 110);
		this.m_ADANumberOfSpacesTextBox.Name = "m_ADANumberOfSpacesTextBox";
		this.m_ADANumberOfSpacesTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ADANumberOfSpacesTextBox.TabIndex = 9;
		this.m_ADANumberOfSpacesLabel.AutoSize = true;
		this.m_ADANumberOfSpacesLabel.Enabled = false;
		this.m_ADANumberOfSpacesLabel.Location = new System.Drawing.Point(4, 113);
		this.m_ADANumberOfSpacesLabel.Name = "m_ADANumberOfSpacesLabel";
		this.m_ADANumberOfSpacesLabel.Size = new System.Drawing.Size(98, 13);
		this.m_ADANumberOfSpacesLabel.TabIndex = 8;
		this.m_ADANumberOfSpacesLabel.Text = "N&umber of Spaces:";
		this.m_ADAWidthTextBox.Enabled = false;
		this.m_ADAWidthTextBox.Location = new System.Drawing.Point(143, 84);
		this.m_ADAWidthTextBox.Name = "m_ADAWidthTextBox";
		this.m_ADAWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ADAWidthTextBox.TabIndex = 7;
		this.m_ADAWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnADAParkingWidthTextBoxKeyDown);
		this.m_ADAWidthTextBox.Leave += new System.EventHandler(this.OnADAParkingWidthTextBoxLeave);
		this.m_ADAWidthLabel.AutoSize = true;
		this.m_ADAWidthLabel.Enabled = false;
		this.m_ADAWidthLabel.Location = new System.Drawing.Point(6, 87);
		this.m_ADAWidthLabel.Name = "m_ADAWidthLabel";
		this.m_ADAWidthLabel.Size = new System.Drawing.Size(38, 13);
		this.m_ADAWidthLabel.TabIndex = 6;
		this.m_ADAWidthLabel.Text = "&Width:";
		this.m_ADAFamilyNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ADAFamilyNameComboBox.Enabled = false;
		this.m_ADAFamilyNameComboBox.FormattingEnabled = true;
		this.m_ADAFamilyNameComboBox.Location = new System.Drawing.Point(143, 57);
		this.m_ADAFamilyNameComboBox.Name = "m_ADAFamilyNameComboBox";
		this.m_ADAFamilyNameComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_ADAFamilyNameComboBox.TabIndex = 5;
		this.m_ADAFamilyNameLabel.AutoSize = true;
		this.m_ADAFamilyNameLabel.Enabled = false;
		this.m_ADAFamilyNameLabel.Location = new System.Drawing.Point(6, 60);
		this.m_ADAFamilyNameLabel.Name = "m_ADAFamilyNameLabel";
		this.m_ADAFamilyNameLabel.Size = new System.Drawing.Size(38, 13);
		this.m_ADAFamilyNameLabel.TabIndex = 4;
		this.m_ADAFamilyNameLabel.Text = "&Name:";
		this.m_ADAFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_ADAFamilyComboBox.Enabled = false;
		this.m_ADAFamilyComboBox.FormattingEnabled = true;
		this.m_ADAFamilyComboBox.Location = new System.Drawing.Point(143, 30);
		this.m_ADAFamilyComboBox.Name = "m_ADAFamilyComboBox";
		this.m_ADAFamilyComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_ADAFamilyComboBox.TabIndex = 2;
		this.m_ADAFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnADAFamilyComboBoxSelectedIndexChanged);
		this.m_ADAFamilyLabel.AutoSize = true;
		this.m_ADAFamilyLabel.Enabled = false;
		this.m_ADAFamilyLabel.Location = new System.Drawing.Point(6, 33);
		this.m_ADAFamilyLabel.Name = "m_ADAFamilyLabel";
		this.m_ADAFamilyLabel.Size = new System.Drawing.Size(39, 13);
		this.m_ADAFamilyLabel.TabIndex = 1;
		this.m_ADAFamilyLabel.Text = "&Family:";
		this.m_BumperTabPage.Controls.Add(this.m_LoadBumperFamilyButton);
		this.m_BumperTabPage.Controls.Add(this.m_BumperHeightTextBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperHeightLabel);
		this.m_BumperTabPage.Controls.Add(this.m_BumperOffsetTextBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperOffsetLabel);
		this.m_BumperTabPage.Controls.Add(this.m_BumperSetbackTextBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperSetbackLabel);
		this.m_BumperTabPage.Controls.Add(this.m_BumperPlaceCheckBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperWidthTextBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperWidthLabel);
		this.m_BumperTabPage.Controls.Add(this.m_BumperFamilyNameComboBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperFamilyNameLabel);
		this.m_BumperTabPage.Controls.Add(this.m_BumperFamilyComboBox);
		this.m_BumperTabPage.Controls.Add(this.m_BumperFamilyLabel);
		this.m_BumperTabPage.Location = new System.Drawing.Point(4, 22);
		this.m_BumperTabPage.Name = "m_BumperTabPage";
		this.m_BumperTabPage.Size = new System.Drawing.Size(412, 193);
		this.m_BumperTabPage.TabIndex = 2;
		this.m_BumperTabPage.Text = "Bumper";
		this.m_BumperTabPage.UseVisualStyleBackColor = true;
		this.m_LoadBumperFamilyButton.Location = new System.Drawing.Point(368, 31);
		this.m_LoadBumperFamilyButton.Name = "m_LoadBumperFamilyButton";
		this.m_LoadBumperFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadBumperFamilyButton.TabIndex = 3;
		this.m_LoadBumperFamilyButton.TabStop = false;
		this.m_LoadBumperFamilyButton.Text = "...";
		this.m_LoadBumperFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadBumperFamilyButton.Click += new System.EventHandler(this.OnLoadBumperFamilyButtonClick);
		this.m_BumperHeightTextBox.Enabled = false;
		this.m_BumperHeightTextBox.Location = new System.Drawing.Point(143, 162);
		this.m_BumperHeightTextBox.Name = "m_BumperHeightTextBox";
		this.m_BumperHeightTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_BumperHeightTextBox.TabIndex = 13;
		this.m_BumperHeightTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnBumperHeightTextBoxKeyDown);
		this.m_BumperHeightTextBox.Leave += new System.EventHandler(this.OnBumperHeightTextBoxLeave);
		this.m_BumperHeightLabel.AutoSize = true;
		this.m_BumperHeightLabel.Enabled = false;
		this.m_BumperHeightLabel.Location = new System.Drawing.Point(6, 165);
		this.m_BumperHeightLabel.Name = "m_BumperHeightLabel";
		this.m_BumperHeightLabel.Size = new System.Drawing.Size(41, 13);
		this.m_BumperHeightLabel.TabIndex = 12;
		this.m_BumperHeightLabel.Text = "&Height:";
		this.m_BumperOffsetTextBox.Enabled = false;
		this.m_BumperOffsetTextBox.Location = new System.Drawing.Point(143, 110);
		this.m_BumperOffsetTextBox.Name = "m_BumperOffsetTextBox";
		this.m_BumperOffsetTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_BumperOffsetTextBox.TabIndex = 9;
		this.m_BumperOffsetTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnBumperOffsetTextBoxKeyDown);
		this.m_BumperOffsetTextBox.Leave += new System.EventHandler(this.OnBumperOffsetTextBoxLeave);
		this.m_BumperOffsetLabel.AutoSize = true;
		this.m_BumperOffsetLabel.Enabled = false;
		this.m_BumperOffsetLabel.Location = new System.Drawing.Point(6, 113);
		this.m_BumperOffsetLabel.Name = "m_BumperOffsetLabel";
		this.m_BumperOffsetLabel.Size = new System.Drawing.Size(38, 13);
		this.m_BumperOffsetLabel.TabIndex = 8;
		this.m_BumperOffsetLabel.Text = "&Offset:";
		this.m_BumperSetbackTextBox.Enabled = false;
		this.m_BumperSetbackTextBox.Location = new System.Drawing.Point(143, 84);
		this.m_BumperSetbackTextBox.Name = "m_BumperSetbackTextBox";
		this.m_BumperSetbackTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_BumperSetbackTextBox.TabIndex = 7;
		this.m_BumperSetbackTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnBumperSetbackTextBoxKeyDown);
		this.m_BumperSetbackTextBox.Leave += new System.EventHandler(this.OnBumperSetbackTextBoxLeave);
		this.m_BumperSetbackLabel.AutoSize = true;
		this.m_BumperSetbackLabel.Enabled = false;
		this.m_BumperSetbackLabel.Location = new System.Drawing.Point(6, 87);
		this.m_BumperSetbackLabel.Name = "m_BumperSetbackLabel";
		this.m_BumperSetbackLabel.Size = new System.Drawing.Size(50, 13);
		this.m_BumperSetbackLabel.TabIndex = 6;
		this.m_BumperSetbackLabel.Text = "&Setback:";
		this.m_BumperPlaceCheckBox.AutoSize = true;
		this.m_BumperPlaceCheckBox.Location = new System.Drawing.Point(7, 7);
		this.m_BumperPlaceCheckBox.Name = "m_BumperPlaceCheckBox";
		this.m_BumperPlaceCheckBox.Size = new System.Drawing.Size(97, 17);
		this.m_BumperPlaceCheckBox.TabIndex = 0;
		this.m_BumperPlaceCheckBox.Text = "Place &Bumpers";
		this.m_BumperPlaceCheckBox.UseVisualStyleBackColor = true;
		this.m_BumperPlaceCheckBox.CheckStateChanged += new System.EventHandler(this.OnBumperPlaceCheckBoxChecked);
		this.m_BumperWidthTextBox.Enabled = false;
		this.m_BumperWidthTextBox.Location = new System.Drawing.Point(143, 136);
		this.m_BumperWidthTextBox.Name = "m_BumperWidthTextBox";
		this.m_BumperWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_BumperWidthTextBox.TabIndex = 11;
		this.m_BumperWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnBumperWidthTextBoxKeyDown);
		this.m_BumperWidthTextBox.Leave += new System.EventHandler(this.OnBumperWidthTextBoxLeave);
		this.m_BumperWidthLabel.AutoSize = true;
		this.m_BumperWidthLabel.Enabled = false;
		this.m_BumperWidthLabel.Location = new System.Drawing.Point(6, 139);
		this.m_BumperWidthLabel.Name = "m_BumperWidthLabel";
		this.m_BumperWidthLabel.Size = new System.Drawing.Size(38, 13);
		this.m_BumperWidthLabel.TabIndex = 10;
		this.m_BumperWidthLabel.Text = "&Width:";
		this.m_BumperFamilyNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_BumperFamilyNameComboBox.Enabled = false;
		this.m_BumperFamilyNameComboBox.FormattingEnabled = true;
		this.m_BumperFamilyNameComboBox.Location = new System.Drawing.Point(143, 57);
		this.m_BumperFamilyNameComboBox.Name = "m_BumperFamilyNameComboBox";
		this.m_BumperFamilyNameComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_BumperFamilyNameComboBox.TabIndex = 5;
		this.m_BumperFamilyNameLabel.AutoSize = true;
		this.m_BumperFamilyNameLabel.Enabled = false;
		this.m_BumperFamilyNameLabel.Location = new System.Drawing.Point(6, 60);
		this.m_BumperFamilyNameLabel.Name = "m_BumperFamilyNameLabel";
		this.m_BumperFamilyNameLabel.Size = new System.Drawing.Size(38, 13);
		this.m_BumperFamilyNameLabel.TabIndex = 4;
		this.m_BumperFamilyNameLabel.Text = "&Name:";
		this.m_BumperFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_BumperFamilyComboBox.Enabled = false;
		this.m_BumperFamilyComboBox.FormattingEnabled = true;
		this.m_BumperFamilyComboBox.Location = new System.Drawing.Point(143, 30);
		this.m_BumperFamilyComboBox.Name = "m_BumperFamilyComboBox";
		this.m_BumperFamilyComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_BumperFamilyComboBox.TabIndex = 2;
		this.m_BumperFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnBumperFamilyComboBoxSelectedIndexChanged);
		this.m_BumperFamilyLabel.AutoSize = true;
		this.m_BumperFamilyLabel.Enabled = false;
		this.m_BumperFamilyLabel.Location = new System.Drawing.Point(6, 33);
		this.m_BumperFamilyLabel.Name = "m_BumperFamilyLabel";
		this.m_BumperFamilyLabel.Size = new System.Drawing.Size(39, 13);
		this.m_BumperFamilyLabel.TabIndex = 1;
		this.m_BumperFamilyLabel.Text = "&Family:";
		this.m_IslandTabPage.Controls.Add(this.m_LoadIslandFamilyButton);
		this.m_IslandTabPage.Controls.Add(this.m_IslandHeightTextBox);
		this.m_IslandTabPage.Controls.Add(this.m_IslandHeightLabel);
		this.m_IslandTabPage.Controls.Add(this.m_IslandPlaceCheckBox);
		this.m_IslandTabPage.Controls.Add(this.m_IslandWidthTextBox);
		this.m_IslandTabPage.Controls.Add(this.m_IslandWidthLabel);
		this.m_IslandTabPage.Controls.Add(this.m_IslandFamilyNameComboBox);
		this.m_IslandTabPage.Controls.Add(this.m_IslandFamilyNameLabel);
		this.m_IslandTabPage.Controls.Add(this.m_IslandFamilyComboBox);
		this.m_IslandTabPage.Controls.Add(this.m_IslandFamilyLabel);
		this.m_IslandTabPage.Location = new System.Drawing.Point(4, 22);
		this.m_IslandTabPage.Name = "m_IslandTabPage";
		this.m_IslandTabPage.Size = new System.Drawing.Size(412, 193);
		this.m_IslandTabPage.TabIndex = 3;
		this.m_IslandTabPage.Text = "Island";
		this.m_IslandTabPage.UseVisualStyleBackColor = true;
		this.m_LoadIslandFamilyButton.Location = new System.Drawing.Point(368, 31);
		this.m_LoadIslandFamilyButton.Name = "m_LoadIslandFamilyButton";
		this.m_LoadIslandFamilyButton.Size = new System.Drawing.Size(24, 20);
		this.m_LoadIslandFamilyButton.TabIndex = 3;
		this.m_LoadIslandFamilyButton.TabStop = false;
		this.m_LoadIslandFamilyButton.Text = "...";
		this.m_LoadIslandFamilyButton.UseVisualStyleBackColor = true;
		this.m_LoadIslandFamilyButton.Click += new System.EventHandler(this.OnLoadIslandFamilyButtonClick);
		this.m_IslandHeightTextBox.Enabled = false;
		this.m_IslandHeightTextBox.Location = new System.Drawing.Point(143, 110);
		this.m_IslandHeightTextBox.Name = "m_IslandHeightTextBox";
		this.m_IslandHeightTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_IslandHeightTextBox.TabIndex = 9;
		this.m_IslandHeightTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnIslandHeightTextBoxKeyDown);
		this.m_IslandHeightTextBox.Leave += new System.EventHandler(this.OnIslandHeightTextBoxLeave);
		this.m_IslandHeightLabel.AutoSize = true;
		this.m_IslandHeightLabel.Enabled = false;
		this.m_IslandHeightLabel.Location = new System.Drawing.Point(6, 113);
		this.m_IslandHeightLabel.Name = "m_IslandHeightLabel";
		this.m_IslandHeightLabel.Size = new System.Drawing.Size(41, 13);
		this.m_IslandHeightLabel.TabIndex = 8;
		this.m_IslandHeightLabel.Text = "&Height:";
		this.m_IslandPlaceCheckBox.AutoSize = true;
		this.m_IslandPlaceCheckBox.Location = new System.Drawing.Point(7, 7);
		this.m_IslandPlaceCheckBox.Name = "m_IslandPlaceCheckBox";
		this.m_IslandPlaceCheckBox.Size = new System.Drawing.Size(89, 17);
		this.m_IslandPlaceCheckBox.TabIndex = 0;
		this.m_IslandPlaceCheckBox.Text = "Place &Islands";
		this.m_IslandPlaceCheckBox.UseVisualStyleBackColor = true;
		this.m_IslandPlaceCheckBox.CheckStateChanged += new System.EventHandler(this.OnIslandPlaceCheckBoxChecked);
		this.m_IslandWidthTextBox.Enabled = false;
		this.m_IslandWidthTextBox.Location = new System.Drawing.Point(143, 84);
		this.m_IslandWidthTextBox.Name = "m_IslandWidthTextBox";
		this.m_IslandWidthTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_IslandWidthTextBox.TabIndex = 7;
		this.m_IslandWidthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnIslandWidthTextBoxKeyDown);
		this.m_IslandWidthTextBox.Leave += new System.EventHandler(this.OnIslandWidthTextBoxLeave);
		this.m_IslandWidthLabel.AutoSize = true;
		this.m_IslandWidthLabel.Enabled = false;
		this.m_IslandWidthLabel.Location = new System.Drawing.Point(6, 87);
		this.m_IslandWidthLabel.Name = "m_IslandWidthLabel";
		this.m_IslandWidthLabel.Size = new System.Drawing.Size(38, 13);
		this.m_IslandWidthLabel.TabIndex = 6;
		this.m_IslandWidthLabel.Text = "&Width:";
		this.m_IslandFamilyNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_IslandFamilyNameComboBox.Enabled = false;
		this.m_IslandFamilyNameComboBox.FormattingEnabled = true;
		this.m_IslandFamilyNameComboBox.Location = new System.Drawing.Point(143, 57);
		this.m_IslandFamilyNameComboBox.Name = "m_IslandFamilyNameComboBox";
		this.m_IslandFamilyNameComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_IslandFamilyNameComboBox.TabIndex = 5;
		this.m_IslandFamilyNameLabel.AutoSize = true;
		this.m_IslandFamilyNameLabel.Enabled = false;
		this.m_IslandFamilyNameLabel.Location = new System.Drawing.Point(6, 60);
		this.m_IslandFamilyNameLabel.Name = "m_IslandFamilyNameLabel";
		this.m_IslandFamilyNameLabel.Size = new System.Drawing.Size(38, 13);
		this.m_IslandFamilyNameLabel.TabIndex = 4;
		this.m_IslandFamilyNameLabel.Text = "&Name:";
		this.m_IslandFamilyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_IslandFamilyComboBox.Enabled = false;
		this.m_IslandFamilyComboBox.FormattingEnabled = true;
		this.m_IslandFamilyComboBox.Location = new System.Drawing.Point(143, 30);
		this.m_IslandFamilyComboBox.Name = "m_IslandFamilyComboBox";
		this.m_IslandFamilyComboBox.Size = new System.Drawing.Size(219, 21);
		this.m_IslandFamilyComboBox.TabIndex = 2;
		this.m_IslandFamilyComboBox.SelectedIndexChanged += new System.EventHandler(this.OnIslandFamilyComboBoxSelectedIndexChanged);
		this.m_IslandFamilyLabel.AutoSize = true;
		this.m_IslandFamilyLabel.Enabled = false;
		this.m_IslandFamilyLabel.Location = new System.Drawing.Point(6, 33);
		this.m_IslandFamilyLabel.Name = "m_IslandFamilyLabel";
		this.m_IslandFamilyLabel.Size = new System.Drawing.Size(39, 13);
		this.m_IslandFamilyLabel.TabIndex = 1;
		this.m_IslandFamilyLabel.Text = "&Family:";
		this.m_ParkingNumberOfSpacesTextBox.Enabled = false;
		this.m_ParkingNumberOfSpacesTextBox.Location = new System.Drawing.Point(171, 361);
		this.m_ParkingNumberOfSpacesTextBox.Name = "m_ParkingNumberOfSpacesTextBox";
		this.m_ParkingNumberOfSpacesTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_ParkingNumberOfSpacesTextBox.TabIndex = 6;
		this.m_ParkingNumberOfSpacesLabel.AutoSize = true;
		this.m_ParkingNumberOfSpacesLabel.Enabled = false;
		this.m_ParkingNumberOfSpacesLabel.Location = new System.Drawing.Point(32, 364);
		this.m_ParkingNumberOfSpacesLabel.Name = "m_ParkingNumberOfSpacesLabel";
		this.m_ParkingNumberOfSpacesLabel.Size = new System.Drawing.Size(98, 13);
		this.m_ParkingNumberOfSpacesLabel.TabIndex = 5;
		this.m_ParkingNumberOfSpacesLabel.Text = "Nu&mber of Spaces:";
		this.m_ParkingByNumberRadioButton.AutoSize = true;
		this.m_ParkingByNumberRadioButton.Location = new System.Drawing.Point(12, 340);
		this.m_ParkingByNumberRadioButton.Name = "m_ParkingByNumberRadioButton";
		this.m_ParkingByNumberRadioButton.Size = new System.Drawing.Size(77, 17);
		this.m_ParkingByNumberRadioButton.TabIndex = 4;
		this.m_ParkingByNumberRadioButton.Text = "By N&umber";
		this.m_ParkingByNumberRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingByNumberRadioButton.CheckedChanged += new System.EventHandler(this.OnParkingOptimizeByNumberOptionChecked);
		this.m_OptimizePanel.Controls.Add(this.m_ParkingChainRadioButton);
		this.m_OptimizePanel.Controls.Add(this.m_ParkingSegmentRadioButton);
		this.m_OptimizePanel.Location = new System.Drawing.Point(32, 310);
		this.m_OptimizePanel.Name = "m_OptimizePanel";
		this.m_OptimizePanel.Size = new System.Drawing.Size(283, 24);
		this.m_OptimizePanel.TabIndex = 3;
		this.m_ParkingChainRadioButton.AutoSize = true;
		this.m_ParkingChainRadioButton.Enabled = false;
		this.m_ParkingChainRadioButton.Location = new System.Drawing.Point(139, 3);
		this.m_ParkingChainRadioButton.Name = "m_ParkingChainRadioButton";
		this.m_ParkingChainRadioButton.Size = new System.Drawing.Size(52, 17);
		this.m_ParkingChainRadioButton.TabIndex = 1;
		this.m_ParkingChainRadioButton.Text = "&Chain";
		this.m_ParkingChainRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingSegmentRadioButton.AutoSize = true;
		this.m_ParkingSegmentRadioButton.Checked = true;
		this.m_ParkingSegmentRadioButton.Enabled = false;
		this.m_ParkingSegmentRadioButton.Location = new System.Drawing.Point(0, 3);
		this.m_ParkingSegmentRadioButton.Name = "m_ParkingSegmentRadioButton";
		this.m_ParkingSegmentRadioButton.Size = new System.Drawing.Size(67, 17);
		this.m_ParkingSegmentRadioButton.TabIndex = 0;
		this.m_ParkingSegmentRadioButton.TabStop = true;
		this.m_ParkingSegmentRadioButton.Text = "&Segment";
		this.m_ParkingSegmentRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingOptimizeRadioButton.AutoSize = true;
		this.m_ParkingOptimizeRadioButton.Checked = true;
		this.m_ParkingOptimizeRadioButton.Location = new System.Drawing.Point(12, 287);
		this.m_ParkingOptimizeRadioButton.Name = "m_ParkingOptimizeRadioButton";
		this.m_ParkingOptimizeRadioButton.Size = new System.Drawing.Size(65, 17);
		this.m_ParkingOptimizeRadioButton.TabIndex = 2;
		this.m_ParkingOptimizeRadioButton.TabStop = true;
		this.m_ParkingOptimizeRadioButton.Text = "&Optimize";
		this.m_ParkingOptimizeRadioButton.UseVisualStyleBackColor = true;
		this.m_ParkingOptimizeRadioButton.CheckedChanged += new System.EventHandler(this.OnParkingOptimizeByNumberOptionChecked);
		this.m_ExistingElementCheckBox.AutoSize = true;
		this.m_ExistingElementCheckBox.Location = new System.Drawing.Point(12, 387);
		this.m_ExistingElementCheckBox.Name = "m_ExistingElementCheckBox";
		this.m_ExistingElementCheckBox.Size = new System.Drawing.Size(103, 17);
		this.m_ExistingElementCheckBox.TabIndex = 7;
		this.m_ExistingElementCheckBox.Text = "&Existing Element";
		this.m_ExistingElementCheckBox.UseVisualStyleBackColor = true;
		this.m_ExistingElementCheckBox.CheckedChanged += new System.EventHandler(this.OnExistingElementCheckBoxChecked);
		this.m_MoveablePanel.Controls.Add(this.m_StartingDistanceLabel);
		this.m_MoveablePanel.Controls.Add(this.m_StartingDistanceTextBox);
		this.m_MoveablePanel.Controls.Add(this.m_DeleteExistingCheckBox);
		this.m_MoveablePanel.Controls.Add(this.m_InsertButton);
		this.m_MoveablePanel.Controls.Add(this.m_CancelButton);
		this.m_MoveablePanel.Location = new System.Drawing.Point(12, 410);
		this.m_MoveablePanel.Name = "m_MoveablePanel";
		this.m_MoveablePanel.Size = new System.Drawing.Size(420, 72);
		this.m_MoveablePanel.TabIndex = 8;
		this.m_StartingDistanceLabel.AutoSize = true;
		this.m_StartingDistanceLabel.Enabled = false;
		this.m_StartingDistanceLabel.Location = new System.Drawing.Point(20, 26);
		this.m_StartingDistanceLabel.Name = "m_StartingDistanceLabel";
		this.m_StartingDistanceLabel.Size = new System.Drawing.Size(91, 13);
		this.m_StartingDistanceLabel.TabIndex = 1;
		this.m_StartingDistanceLabel.Text = "Starting Distance:";
		this.m_StartingDistanceTextBox.Enabled = false;
		this.m_StartingDistanceTextBox.Location = new System.Drawing.Point(159, 23);
		this.m_StartingDistanceTextBox.Name = "m_StartingDistanceTextBox";
		this.m_StartingDistanceTextBox.Size = new System.Drawing.Size(100, 20);
		this.m_StartingDistanceTextBox.TabIndex = 2;
		this.m_StartingDistanceTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnStartingDistanceTextBoxKeyDown);
		this.m_StartingDistanceTextBox.Leave += new System.EventHandler(this.OnStartingDistanceTextBoxLeave);
		this.m_DeleteExistingCheckBox.AutoSize = true;
		this.m_DeleteExistingCheckBox.Enabled = false;
		this.m_DeleteExistingCheckBox.Location = new System.Drawing.Point(20, 0);
		this.m_DeleteExistingCheckBox.Name = "m_DeleteExistingCheckBox";
		this.m_DeleteExistingCheckBox.Size = new System.Drawing.Size(137, 17);
		this.m_DeleteExistingCheckBox.TabIndex = 0;
		this.m_DeleteExistingCheckBox.Text = "Delete E&xisting Element";
		this.m_DeleteExistingCheckBox.UseVisualStyleBackColor = true;
		this.m_InsertButton.Location = new System.Drawing.Point(264, 49);
		this.m_InsertButton.Name = "m_InsertButton";
		this.m_InsertButton.Size = new System.Drawing.Size(75, 23);
		this.m_InsertButton.TabIndex = 3;
		this.m_InsertButton.Text = "&Insert";
		this.m_InsertButton.UseVisualStyleBackColor = true;
		this.m_InsertButton.Click += new System.EventHandler(this.OnInsertButtonClick);
		this.m_CancelButton.Location = new System.Drawing.Point(345, 49);
		this.m_CancelButton.Name = "m_CancelButton";
		this.m_CancelButton.Size = new System.Drawing.Size(75, 23);
		this.m_CancelButton.TabIndex = 4;
		this.m_CancelButton.Text = "Cancel";
		this.m_CancelButton.UseVisualStyleBackColor = true;
		this.m_CancelButton.Click += new System.EventHandler(this.OnCancelButtonClick);
		this.m_ToposurfacePickerPanel.Controls.Add(this.m_SurfaceList);
		this.m_ToposurfacePickerPanel.Controls.Add(this.m_SelectedSurfaceLabel);
		this.m_ToposurfacePickerPanel.Controls.Add(this.m_ToposurfaceCheckBox);
		this.m_ToposurfacePickerPanel.Location = new System.Drawing.Point(12, 237);
		this.m_ToposurfacePickerPanel.Name = "m_ToposurfacePickerPanel";
		this.m_ToposurfacePickerPanel.Size = new System.Drawing.Size(420, 44);
		this.m_ToposurfacePickerPanel.TabIndex = 1;
		this.m_SurfaceList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
		this.m_SurfaceList.Enabled = false;
		this.m_SurfaceList.FormattingEnabled = true;
		this.m_SurfaceList.Location = new System.Drawing.Point(107, 23);
		this.m_SurfaceList.Name = "m_SurfaceList";
		this.m_SurfaceList.Size = new System.Drawing.Size(219, 21);
		this.m_SurfaceList.TabIndex = 2;
		this.m_SelectedSurfaceLabel.AutoSize = true;
		this.m_SelectedSurfaceLabel.Enabled = false;
		this.m_SelectedSurfaceLabel.Location = new System.Drawing.Point(0, 26);
		this.m_SelectedSurfaceLabel.Name = "m_SelectedSurfaceLabel";
		this.m_SelectedSurfaceLabel.Size = new System.Drawing.Size(44, 13);
		this.m_SelectedSurfaceLabel.TabIndex = 1;
		this.m_SelectedSurfaceLabel.Text = "Surface";
		this.m_ToposurfaceCheckBox.AutoSize = true;
		this.m_ToposurfaceCheckBox.Location = new System.Drawing.Point(0, 0);
		this.m_ToposurfaceCheckBox.Name = "m_ToposurfaceCheckBox";
		this.m_ToposurfaceCheckBox.Size = new System.Drawing.Size(110, 17);
		this.m_ToposurfaceCheckBox.TabIndex = 0;
		this.m_ToposurfaceCheckBox.Text = "Pick Toposurface";
		this.m_ToposurfaceCheckBox.UseVisualStyleBackColor = true;
		this.m_ToposurfaceCheckBox.CheckedChanged += new System.EventHandler(this.OnToposurfaceCheckBoxCheckedChanged);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(444, 494);
		base.Controls.Add(this.m_ToposurfacePickerPanel);
		base.Controls.Add(this.m_MoveablePanel);
		base.Controls.Add(this.m_ExistingElementCheckBox);
		base.Controls.Add(this.m_ParkingNumberOfSpacesTextBox);
		base.Controls.Add(this.m_ParkingNumberOfSpacesLabel);
		base.Controls.Add(this.m_ParkingByNumberRadioButton);
		base.Controls.Add(this.m_OptimizePanel);
		base.Controls.Add(this.m_ParkingOptimizeRadioButton);
		base.Controls.Add(this.m_ParkingLotTabControl);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "ParkingLotPlacementForm";
		this.Text = "Parking Lot";
		base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnParkingLotPlacementFormClosing);
		this.m_ParkingSpaceTabPage.ResumeLayout(false);
		this.m_ParkingSpaceTabPage.PerformLayout();
		this.m_ParkingPlacementGroupBox.ResumeLayout(false);
		this.m_ParkingPlacementGroupBox.PerformLayout();
		this.m_ParkingLotTabControl.ResumeLayout(false);
		this.m_ADASpaceTabPage.ResumeLayout(false);
		this.m_ADASpaceTabPage.PerformLayout();
		this.m_BumperTabPage.ResumeLayout(false);
		this.m_BumperTabPage.PerformLayout();
		this.m_IslandTabPage.ResumeLayout(false);
		this.m_IslandTabPage.PerformLayout();
		this.m_OptimizePanel.ResumeLayout(false);
		this.m_OptimizePanel.PerformLayout();
		this.m_MoveablePanel.ResumeLayout(false);
		this.m_MoveablePanel.PerformLayout();
		this.m_ToposurfacePickerPanel.ResumeLayout(false);
		this.m_ToposurfacePickerPanel.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_InsertButton;
		base.CancelButton = this.m_CancelButton;
	}
}
