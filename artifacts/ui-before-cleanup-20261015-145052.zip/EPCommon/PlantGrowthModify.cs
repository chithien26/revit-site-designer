using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Autodesk.Revit.DB;

namespace EPCommon;

public class PlantGrowthModify : EPForm
{
	private Units m_Units;

	private const UnitType m_LengthUnitType = UnitType.UT_Length;

	private const UnitType m_SlopeUnitType = UnitType.UT_Slope;

	private const UnitType m_AngularUnitType = UnitType.UT_Angle;

	private DisplayUnit m_DisplayUnitSystem;

	private FormatOptions m_FormatOptions;

	private UnitSymbolType m_UnitSymbolType;

	private List<FamilySymbolContainer> m_FamilySymbolContainerList;

	private PlantGrowthListView m_ParameterListView = new PlantGrowthListView();

	private int m_nTypeIndex = -1;

	private DecimalSymbol m_DecimalSymbolType;

	private IContainer components;

	private Button m_ButtonOk;

	private Button m_ButtonCancel;

	private Label m_TypeLbl;

	private Label m_lblPlantName;

	public PlantGrowthModify(ref List<FamilySymbolContainer> _FamilyTypeContainerList, Units _Units, DisplayUnit _UnitType, FormatOptions _FormatOption, UnitSymbolType _UnitSymbolType, DecimalSymbol _DecimalSymbolType, int _nTypeIndex)
	{
		InitializeComponent();
		m_FamilySymbolContainerList = _FamilyTypeContainerList;
		m_DisplayUnitSystem = _UnitType;
		m_FormatOptions = _FormatOption;
		m_UnitSymbolType = _UnitSymbolType;
		m_DecimalSymbolType = _DecimalSymbolType;
		m_nTypeIndex = _nTypeIndex;
		m_Units = _Units;
		InitializeData();
		GetDialogPosition();
		m_ParameterListView.OnListViewItemChanged += ParameterListViewOnListViewItemChanged;
		FormClosing += PlantGrowthModifyFormClosing;
	}

	private void PlantGrowthModifyFormClosing(object sender, FormClosingEventArgs e)
	{
		SetDialogPosition();
	}

	private void ParameterListViewOnListViewItemChanged(int _nChangedIndex)
	{
		double num = 0.0;
		int _nReturnedInt = 0;
		string strB = m_ParameterListView.Items[_nChangedIndex].SubItems[0].Text;
		string _strToDisplay = m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text;
		if (string.Compare(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), strB, ignoreCase: true) == 0)
		{
			try
			{
				if (string.Compare(_strToDisplay, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) == 0 || _strToDisplay == string.Empty)
				{
					m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
				}
				else if (RevitGeometry.StrE_GetValidWholeNumber(_strToDisplay, ref _nReturnedInt))
				{
					m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _nReturnedInt.ToString();
				}
				else
				{
					RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
					m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
				}
				return;
			}
			catch (Exception)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
				m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
				m_ParameterListView.SetFocus(_nChangedIndex);
				return;
			}
		}
		if (string.Compare(EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), strB, ignoreCase: true) == 0)
		{
			try
			{
				num = 0.0;
				RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, m_Units, UnitType.UT_Length, ref num);
				RevitGeometry.Units_ConvertDoubleToString(num, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
				return;
			}
			catch (Exception)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
				m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
				m_ParameterListView.SetFocus(_nChangedIndex);
				return;
			}
		}
		if (string.Compare(EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), strB, ignoreCase: true) == 0)
		{
			try
			{
				num = 0.0;
				RevitGeometry.Units_ConvertStringToDouble(_strToDisplay, m_Units, UnitType.UT_Length, ref num);
				RevitGeometry.Units_ConvertDoubleToString(num, m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref _strToDisplay);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = _strToDisplay;
			}
			catch (Exception)
			{
				RevitMessageBox.Show(EPShared.LocalRM.GetString("NeedValidInputFor_") + EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), EPShared.LocalRM.GetString("Error"), MessageBoxIcon.Hand);
				m_ParameterListView.Items[_nChangedIndex].SubItems[1].Text = string.Empty;
				m_ParameterListView.CurrListItem = m_ParameterListView.Items[_nChangedIndex];
				m_ParameterListView.SetFocus(_nChangedIndex);
			}
		}
	}

	private void InitializeData()
	{
		m_ButtonOk.Text = EPShared.LocalRM.GetString("AMP_OKDialog");
		m_ButtonCancel.Text = EPShared.LocalRM.GetString("AMP_CancelDialog");
		m_ParameterListView.View = System.Windows.Forms.View.Details;
		m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Parameter"));
		m_ParameterListView.Columns.Add(EPShared.LocalRM.GetString("Value"));
		Controls.AddRange(new System.Windows.Forms.Control[1] { m_ParameterListView });
		m_ParameterListView.Columns[0].Width = 215;
		m_ParameterListView.Columns[1].Width = 215;
		ListViewItem listViewItem = null;
		string empty = string.Empty;
		Text = EPShared.LocalRM.GetString("ModifyDialog") + " " + EPShared.LocalRM.GetString("PlantDialog");
		m_TypeLbl.Text = EPShared.LocalRM.GetString("FamilyString") + " : " + m_FamilySymbolContainerList[m_nTypeIndex].FamilySymbol.Family.Name;
		m_lblPlantName.Text = EPShared.LocalRM.GetString("PlantTypePlantFamilyParameter") + " : " + m_FamilySymbolContainerList[m_nTypeIndex].FamilySymbol.Name;
		empty = EPShared.LocalRM.GetString("NotAvailableString");
		listViewItem = new ListViewItem();
		listViewItem = m_ParameterListView.Items.Add(EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), string.Empty);
		if (string.Compare(m_FamilySymbolContainerList[m_nTypeIndex].ServiceLife, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			empty = m_FamilySymbolContainerList[m_nTypeIndex].ServiceLife;
		}
		listViewItem.SubItems.Add(empty);
		listViewItem.SubItems[listViewItem.SubItems.Count - 1].Text = empty;
		empty = EPShared.LocalRM.GetString("NotAvailableString");
		listViewItem = new ListViewItem();
		listViewItem = m_ParameterListView.Items.Add(EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), string.Empty);
		if (string.Compare(m_FamilySymbolContainerList[m_nTypeIndex].MaxHeight, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(m_FamilySymbolContainerList[m_nTypeIndex].MaxHeight), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
		}
		listViewItem.SubItems.Add(empty);
		listViewItem.SubItems[listViewItem.SubItems.Count - 1].Text = empty;
		empty = EPShared.LocalRM.GetString("NotAvailableString");
		listViewItem = new ListViewItem();
		listViewItem = m_ParameterListView.Items.Add(EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), string.Empty);
		if (string.Compare(m_FamilySymbolContainerList[m_nTypeIndex].MaxWidth, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0)
		{
			RevitGeometry.Units_ConvertDoubleToString(ValueConversion.ToDouble(m_FamilySymbolContainerList[m_nTypeIndex].MaxWidth), m_FormatOptions.LegacyDisplayUnits(), m_FormatOptions.Accuracy, m_UnitSymbolType, m_Units, ref empty);
		}
		listViewItem.SubItems.Add(empty);
		listViewItem.SubItems[listViewItem.SubItems.Count - 1].Text = empty;
	}

	private void OnButtonOkClicked(object sender, EventArgs e)
	{
		string empty = string.Empty;
		string empty2 = string.Empty;
		SetDialogPosition();
		for (int i = 0; i < m_ParameterListView.Items.Count; i++)
		{
			empty = m_ParameterListView.Items[i].SubItems[0].Text;
			empty2 = m_ParameterListView.Items[i].SubItems[1].Text;
			string empty3 = string.Empty;
			double num = 1.0;
			for (int j = 0; j < m_ParameterListView.Items.Count; j++)
			{
				string strA = m_ParameterListView.Items[j].SubItems[0].Text;
				string text = m_ParameterListView.Items[j].SubItems[1].Text;
				if (string.Compare(strA, EPShared.LocalRM.GetString("GrowthServiceLifePlantFamilyParameter"), ignoreCase: true) == 0)
				{
					num = 1.0;
					empty3 = EPShared.LocalRM.GetString("NotAvailableString");
					if (text != null && text != string.Empty && string.Compare(text, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0 && RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref num))
					{
						empty3 = Convert.ToInt32(num).ToString();
					}
					m_FamilySymbolContainerList[m_nTypeIndex].ServiceLife = empty3;
				}
				else if (string.Compare(strA, EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantHeightPlantFamilyParameter"), ignoreCase: true) == 0)
				{
					num = 1.0;
					empty3 = EPShared.LocalRM.GetString("NotAvailableString");
					if (text != null && text != string.Empty && string.Compare(text, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0 && RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref num))
					{
						empty3 = ValueConversion.ToString(num);
					}
					m_FamilySymbolContainerList[m_nTypeIndex].MaxHeight = empty3;
				}
				else if (string.Compare(strA, EPShared.LocalRM.GetString("MaximumString") + " " + EPShared.LocalRM.GetString("PlantWidthPlantFamilyParameter"), ignoreCase: true) == 0)
				{
					num = 1.0;
					empty3 = EPShared.LocalRM.GetString("NotAvailableString");
					if (text != null && text != string.Empty && string.Compare(text, EPShared.LocalRM.GetString("NotAvailableString"), ignoreCase: true) != 0 && RevitGeometry.Units_ConvertStringToDouble(text, m_Units, UnitType.UT_Length, ref num))
					{
						empty3 = ValueConversion.ToString(num);
					}
					m_FamilySymbolContainerList[m_nTypeIndex].MaxWidth = empty3;
				}
			}
		}
		DialogResult = DialogResult.OK;
	}

	private void OnButtonCancelClicked(object sender, EventArgs e)
	{
		DialogResult = DialogResult.Cancel;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.m_ButtonOk = new System.Windows.Forms.Button();
		this.m_ButtonCancel = new System.Windows.Forms.Button();
		this.m_TypeLbl = new System.Windows.Forms.Label();
		this.m_lblPlantName = new System.Windows.Forms.Label();
		base.SuspendLayout();
		this.m_ButtonOk.Location = new System.Drawing.Point(293, 153);
		this.m_ButtonOk.Name = "m_ButtonOk";
		this.m_ButtonOk.Size = new System.Drawing.Size(75, 23);
		this.m_ButtonOk.TabIndex = 1;
		this.m_ButtonOk.Text = "&OK";
		this.m_ButtonOk.UseVisualStyleBackColor = true;
		this.m_ButtonOk.Click += new System.EventHandler(this.OnButtonOkClicked);
		this.m_ButtonCancel.Location = new System.Drawing.Point(374, 153);
		this.m_ButtonCancel.Name = "m_ButtonCancel";
		this.m_ButtonCancel.Size = new System.Drawing.Size(75, 23);
		this.m_ButtonCancel.TabIndex = 2;
		this.m_ButtonCancel.Text = "&Cancel";
		this.m_ButtonCancel.UseVisualStyleBackColor = true;
		this.m_ButtonCancel.Click += new System.EventHandler(this.OnButtonCancelClicked);
		this.m_TypeLbl.AutoSize = true;
		this.m_TypeLbl.Location = new System.Drawing.Point(9, 9);
		this.m_TypeLbl.Name = "m_TypeLbl";
		this.m_TypeLbl.Size = new System.Drawing.Size(33, 13);
		this.m_TypeLbl.TabIndex = 41;
		this.m_TypeLbl.Text = "LBLT";
		this.m_lblPlantName.AutoSize = true;
		this.m_lblPlantName.Location = new System.Drawing.Point(9, 32);
		this.m_lblPlantName.Name = "m_lblPlantName";
		this.m_lblPlantName.Size = new System.Drawing.Size(33, 13);
		this.m_lblPlantName.TabIndex = 42;
		this.m_lblPlantName.Text = "LBLB";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(452, 183);
		base.Controls.Add(this.m_lblPlantName);
		base.Controls.Add(this.m_TypeLbl);
		base.Controls.Add(this.m_ButtonCancel);
		base.Controls.Add(this.m_ButtonOk);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		base.Name = "PlantGrowthModify";
		this.Text = "PlantGrowthModify";
		base.ResumeLayout(false);
		base.PerformLayout();
		base.AcceptButton = this.m_ButtonOk;
		base.CancelButton = this.m_ButtonCancel;
	}
}
