﻿// Decompiled with JetBrains decompiler
// Type: EPCommon.FamilyTypeWrapper
// Assembly: SiteDesigner, Version=20.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 84104107-DD17-4742-AB85-FA77E5583D5F
// Assembly location: C:\Program Files\Autodesk\Revit Site Designer Extension 2020\SiteDesigner.dll

using Autodesk.Revit.DB;

#nullable disable
namespace EPCommon;

public class FamilyTypeWrapper
{
  private string m_strFamilyTypeName;
  private FamilyType m_FamilyType;

  public FamilyTypeWrapper(FamilyType _FamilyType)
  {
    this.m_FamilyType = _FamilyType;
    this.m_strFamilyTypeName = this.m_FamilyType.Name;
  }

  public FamilyTypeWrapper(string _strFamilyTypeName)
  {
    this.m_strFamilyTypeName = _strFamilyTypeName;
  }

  public string FamilyTypeName
  {
    get => this.m_strFamilyTypeName;
    set => this.m_strFamilyTypeName = value;
  }

  public FamilyType FamilyType
  {
    get => this.m_FamilyType;
    set
    {
      this.m_FamilyType = value;
      this.m_strFamilyTypeName = this.m_FamilyType.Name;
    }
  }
}
